#include <irssi/src/common.h>
#include <irssi/src/lib-config/iconfig.h>

/* private */
int config_error(CONFIG_REC *rec, const char *msg);

