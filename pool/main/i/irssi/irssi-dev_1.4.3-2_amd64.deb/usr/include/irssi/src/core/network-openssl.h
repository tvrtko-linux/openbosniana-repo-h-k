#ifndef IRSSI_CORE_NETWORK_OPENSSL_H
#define IRSSI_CORE_NETWORK_OPENSSL_H

gboolean irssi_ssl_init(void);

#endif /* !IRSSI_CORE_NETWORK_OPENSSL_H */
