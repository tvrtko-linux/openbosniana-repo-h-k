__version__ = '2.17.3'
__date__ = '2021-07-08'
__homepage__ = 'https://mg.pov.lt/irclog2html/'
