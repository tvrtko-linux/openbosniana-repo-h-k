<?php

namespace Icinga\Module\Businessprocess\ProvidedHook\Icingadb;

use Icinga\Module\Icingadb\Hook\IcingadbSupportHook;

class IcingadbSupport extends IcingadbSupportHook
{

}
