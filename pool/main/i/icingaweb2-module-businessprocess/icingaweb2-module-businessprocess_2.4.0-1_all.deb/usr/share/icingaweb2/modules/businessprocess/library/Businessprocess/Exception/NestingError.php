<?php

namespace Icinga\Module\Businessprocess\Exception;

use Icinga\Exception\IcingaException;

class NestingError extends IcingaException
{
}
