<?php

namespace Icinga\Module\Businessprocess\Web\Form\Element;

use Zend_Form_Element_Xhtml;

class FormElement extends Zend_Form_Element_Xhtml
{
}
