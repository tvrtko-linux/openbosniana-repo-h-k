<?php

namespace Icinga\Module\Businessprocess\Exception;

use Icinga\Exception\IcingaException;

class ModificationError extends IcingaException
{
}
