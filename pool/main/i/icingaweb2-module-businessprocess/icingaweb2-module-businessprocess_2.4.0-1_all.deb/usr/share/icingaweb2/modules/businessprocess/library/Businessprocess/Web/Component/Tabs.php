<?php

namespace Icinga\Module\Businessprocess\Web\Component;

use ipl\Html\ValidHtml;

class Tabs extends WtfTabs implements ValidHtml
{
}
