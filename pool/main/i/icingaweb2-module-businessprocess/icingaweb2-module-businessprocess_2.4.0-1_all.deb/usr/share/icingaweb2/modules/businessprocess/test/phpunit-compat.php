<?php

use PHPUnit\Framework\TestCase;

/**
 * @codingStandardsIgnoreStart
 */
class PHPUnit_Framework_TestCase extends TestCase
{
}
