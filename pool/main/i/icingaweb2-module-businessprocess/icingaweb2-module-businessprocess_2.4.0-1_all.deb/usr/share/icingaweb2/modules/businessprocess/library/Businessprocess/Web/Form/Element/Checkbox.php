<?php

namespace Icinga\Module\Businessprocess\Web\Form\Element;

class Checkbox extends \Icinga\Web\Form\Element\Checkbox
{

}
