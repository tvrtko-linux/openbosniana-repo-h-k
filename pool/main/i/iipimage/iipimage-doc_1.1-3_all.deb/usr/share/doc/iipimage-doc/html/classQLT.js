var classQLT =
[
    [ "run", "classQLT.html#ad506fa95c7b29969b372d02e886bbe45", null ]
];