var classMINMAX =
[
    [ "run", "classMINMAX.html#a70aebbcd0a570fb7951c0b7fd4ffa8a9", null ]
];