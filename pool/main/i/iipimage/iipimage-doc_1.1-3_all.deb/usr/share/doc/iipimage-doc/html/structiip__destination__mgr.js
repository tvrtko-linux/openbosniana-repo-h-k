var structiip__destination__mgr =
[
    [ "buffer", "structiip__destination__mgr.html#a35b99ba1627c6fb41dd3cfe8ab8c4929", null ],
    [ "pub", "structiip__destination__mgr.html#ad7067c2a5f663ce429b348567502711a", null ],
    [ "size", "structiip__destination__mgr.html#aa32d322345e39442dd70920a225d98b9", null ],
    [ "source", "structiip__destination__mgr.html#a39557fb6d3960bb476216e732bab8ffe", null ],
    [ "strip_height", "structiip__destination__mgr.html#abe4bc788bf7737a68aecfb123582dd59", null ]
];