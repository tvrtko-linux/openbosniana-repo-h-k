var classLogger =
[
    [ "Logger", "classLogger.html#abc41bfb031d896170c7675fa96a6b30c", null ],
    [ "~Logger", "classLogger.html#acb668a9e186a25fbaad2e4af6d1ed00a", null ],
    [ "close", "classLogger.html#afee2bab560c2db0190c980884d33868c", null ],
    [ "open", "classLogger.html#a9ac4bdff29b02fce14790d903cc598f6", null ],
    [ "types", "classLogger.html#a424be465f9eb007a83e31a92e2c0fcf1", null ]
];