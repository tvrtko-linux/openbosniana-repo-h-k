var classJTL =
[
    [ "run", "classJTL.html#adf2a86fad5ebcbd7b49ac8bb395c31ce", null ],
    [ "send", "classJTL.html#a4e8d019467ce2d0e699d405c9fd05de9", null ]
];