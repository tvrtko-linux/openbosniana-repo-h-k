var classTimer =
[
    [ "Timer", "classTimer.html#a5f16e8da27d2a5a5242dead46de05d97", null ],
    [ "getTime", "classTimer.html#af2edcce6ce6beabcef68400d825d1d61", null ],
    [ "start", "classTimer.html#a3a8b5272198d029779dc9302a54305a8", null ]
];