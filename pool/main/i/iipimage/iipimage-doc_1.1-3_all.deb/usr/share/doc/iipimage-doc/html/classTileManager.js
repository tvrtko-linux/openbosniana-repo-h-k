var classTileManager =
[
    [ "TileManager", "classTileManager.html#ad8b7ce4527d72bc843592a7ec7f7584e", null ],
    [ "getRegion", "classTileManager.html#a0dbed27c6cc15b16f9fc8ccb703ce89e", null ],
    [ "getTile", "classTileManager.html#a22158a283b27639ddf3645cfc83d2586", null ]
];