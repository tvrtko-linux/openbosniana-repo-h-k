var classSPECTRA =
[
    [ "run", "classSPECTRA.html#abb69ba6eba46ebf90b27cb943b7e751c", null ]
];