#### Core team:

- Dianora, Diane Bruce \<db@db.net> ([@DianeBruce](https://github.com/DianeBruce))
- Michael, Michael Wobst \<michael@wobst.fr> ([@miwob](https://github.com/miwob))
- Rodder, Jon Lusky \<lusky@blown.net> ([@jlusky](https://github.com/jlusky))
- Wohali, Joan Touzet \<joant@ieee.org> ([@wohali](https://github.com/wohali))

#### Contributors:

- A1kmm, Andrew Miller \<a1kmm@mware.virtualave.net> ([@A1kmm](https://github.com/A1kmm))
- Adam, Adam \<Adam@anope.org> ([@Adam-](https://github.com/Adam-))
- Adrian Chadd \<adrian@creative.net.au> ([@erikarn](https://github.com/erikarn))
- adx, Piotr Nizynski \<nizynski@sysplex.pl>
- AndroSyn, Aaron Sethman \<androsyn@ratbox.org> ([@synandro](https://github.com/synandro))
- bane, Dragan Dosen \<bane@idolnet.org>
- billy-jon, William Bierman III \<bill@thebiermans.org> ([@wbierman](https://github.com/wbierman))
- bysin, Ben Kittridge \<bkittridge@cfl.rr.com>
- cosine, Patrick Alken \<wnder@uwns.underworld.net>
- cryogen, Stuart Walsh \<stu@ipng.org.uk> ([@cryogen](https://github.com/cryogen))
- David-T, David Taylor \<davidt@yadt.co.uk>
- Dom, Dominic Hargreaves \<dom@earth.li> ([@jmdh](https://github.com/jmdh))
- Fawkes, Christoph Ostermeier \<fawkes@phat-net.de>
- fgeek, Henri Salo \<henri@nerv.fi> ([@fgeek](https://github.com/fgeek))
- fl, Lee Hardy \<lee@leeh.co.uk>
- Garion, Joost Vunderink \<garion@efnet.nl> ([@joostvunderink](https://github.com/joostvunderink))
- Habeeb, David Supuran \<habeeb@cfl.rr.com>
- Hwy101, W. Campbell \<wcampbel@botbay.net>
- jmallett, Juli Mallett \<jmallett@FreeBSD.org> ([@caladri](https://github.com/caladri))
- joshk, Joshua Kwan \<joshk@triplehelix.org> ([@joshk0](https://github.com/joshk0))
- jv, Jakub Vlasek \<jv@pilsedu.cz>
- k9, Jeremy Chadwick \<ircd@jdc.parodius.com>
- kire, Erik Small \<smalle@hawaii.edu>
- knight, Alan LeVee \<alan.levee@prometheus-designs.net>
- kre, Dinko Korunic \<kreator@fly.srk.fer.hr> ([@dkorunic](https://github.com/dkorunic))
- madmax, Paul Lomax \<madmax@efnet.org>
- metalrock, Jack Low \<xxjack12xx@gmail.com>
- r0d3nt, Andrew Strutt \<andrew.strutt@gmail.com> ([@astrutt](https://github.com/astrutt))
- Riedel, Dennis Vink \<dennis@drvink.com> ([@dennisvink](https://github.com/dennisvink))
- scuzzy, David Todd \<scuzzy@aniverse.net>
- spookey, David Colburn \<spookey@spookey.org>
- TimeMr14C, Yusuf Iskenderoglu \<uhc0@stud.uni-karlsruhe.de>
- toot, Toby Verrall \<to7@antipope.fsnet.co.uk>
- vx0, Mark Miller \<mark@oc768.net>
- wiz, Jason Dambrosio \<jason@wiz.cx>
- Xride, S�ren Straarup \<xride@x12.dk>
- zb^3, Alfred Perlstein \<alfred@freebsd.org> ([@splbio](https://github.com/splbio))
