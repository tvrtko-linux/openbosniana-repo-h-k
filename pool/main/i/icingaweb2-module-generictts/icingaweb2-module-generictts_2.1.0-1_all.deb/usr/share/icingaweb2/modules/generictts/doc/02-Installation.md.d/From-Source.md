# Installing Icinga Web GenericTTS Integration from Source

Please see the Icinga Web documentation on
[how to install modules](https://icinga.com/docs/icinga-web-2/latest/doc/08-Modules/#installation) from source.
Make sure you use `generictts` as the module name. The following requirements must also be met.

## Requirements

* [Icinga Web](https://icinga.com/docs/icinga-web/latest/)
<!-- {% include "02-Installation.md" %} -->
