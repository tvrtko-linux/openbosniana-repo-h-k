# Icinga Web GenericTTS Integration

With the Icinga Web GenericTTS integration, you can replace ticket patterns in acknowledgements,
downtimes, and comments with links to your trouble ticket systems.
To do this, you configure one or more unique regular expressions to link to them.

## Installation

To install Icinga Web GenericTTS Integration see [Installation](02-Installation.md).

## License

Icinga Web GenericTTS Integration
and the Icinga Web GenericTTS Integration documentation are licensed under the terms of the
GNU General Public License Version 2.
