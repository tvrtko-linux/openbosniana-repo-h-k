# Icinga Web GenericTTS Integration

With the Icinga Web GenericTTS integration, you can replace ticket patterns in acknowledgements,
downtimes, and comments with links to your trouble ticket systems.
To do this, you configure one or more unique regular expressions to link to them.

## Documentation

Icinga Web GenericTTS Integration documentation is available at [icinga.com/docs](https://icinga.com/docs/icinga-web-generictts-integration/latest/).

## License

Icinga Web GenericTTS Integration
and the Icinga Web GenericTTS Integration documentation are licensed under the terms of the
[GNU General Public License Version 2](LICENSE).
