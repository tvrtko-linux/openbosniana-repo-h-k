<?php
/* Icinga Web 2 | (c) 2014 Icinga Development Team | GPLv2+ */

namespace Icinga\Application\Logger\Writer;

/**
 * Deprecated, compat only.
 *
 * Use Icinga\Application\Logger\Writer\StderrWriter instead.
 */
class StdoutWriter extends StderrWriter
{
}
