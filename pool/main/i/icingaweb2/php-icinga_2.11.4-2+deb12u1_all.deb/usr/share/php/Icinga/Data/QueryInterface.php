<?php
/* Icinga Web 2 | (c) 2013 Icinga Development Team | GPLv2+ */

namespace Icinga\Data;

interface QueryInterface extends Fetchable, Filterable, Paginatable, Sortable
{
}
