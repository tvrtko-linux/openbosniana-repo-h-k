<?php
/* Icinga Web 2 | (c) 2013 Icinga Development Team | GPLv2+ */

namespace Icinga\Exception;

/**
 * Class ConfigurationError
 * @package Icinga\Exception
 */
class ConfigurationError extends IcingaException
{
}
