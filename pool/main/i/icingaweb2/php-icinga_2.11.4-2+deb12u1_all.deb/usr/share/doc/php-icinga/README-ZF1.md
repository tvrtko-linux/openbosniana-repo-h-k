# icingaweb2-vendor-zf1

icingaweb2-vendor-zf1 is [Icinga Web 2](https://www.icinga.org/products/icinga-web-2/)'s fork of
[Zend Framework](https://framework.zend.com/) 1 which is
[end-of-life](https://framework.zend.com/blog/2016-06-28-zf1-eol.html) since Sep 28, 2016.
We've reduced the library to the minimum required by Icinga Web 2 and its modules.
The Icinga Project will provide security and bug fixes.
icingaweb2-vendor-zf1 is based on Zend Framework 1 version 1.12.20.
