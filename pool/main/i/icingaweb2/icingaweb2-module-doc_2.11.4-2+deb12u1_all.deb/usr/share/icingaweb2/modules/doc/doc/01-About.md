# About the Doc Module <a id="doc-module-about"></a>

Please read the following chapters for more insights on this module:

* [Installation](02-Installation.md#doc-module-installation)
* [Module Documentation](03-Module-Documentation.md#module-documentation)
