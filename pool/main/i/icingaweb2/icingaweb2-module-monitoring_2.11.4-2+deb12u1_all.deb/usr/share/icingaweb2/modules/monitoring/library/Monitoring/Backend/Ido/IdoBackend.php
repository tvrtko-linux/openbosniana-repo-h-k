<?php
/* Icinga Web 2 | (c) 2014 Icinga Development Team | GPLv2+ */

namespace Icinga\Module\Monitoring\Backend\Ido;

use Icinga\Module\Monitoring\Backend\MonitoringBackend;

class IdoBackend extends MonitoringBackend
{
}
