<?php

namespace Icinga\Module\Monitoring\DataView;

class Eventgridhosts extends Eventgrid
{
}
