<?php
/* Icinga Web 2 | (c) 2013 Icinga Development Team | GPLv2+ */

namespace Icinga\Module\Monitoring\Web\Hook;

use Icinga\Module\Monitoring\Hook\TimelineProviderHook as BaseHook;

/**
 * Compat only
 *
 * Please implement hooks in our Hook direcory
 */
abstract class TimelineProviderHook extends BaseHook
{
}
