<?php

namespace Icinga\Module\Monitoring\DataView;

class Eventgridservices extends Eventgrid
{
}
