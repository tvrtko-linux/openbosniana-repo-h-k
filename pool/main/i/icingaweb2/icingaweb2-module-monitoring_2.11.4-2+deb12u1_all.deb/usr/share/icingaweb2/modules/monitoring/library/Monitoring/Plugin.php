<?php
/* Icinga Web 2 | (c) 2013 Icinga Development Team | GPLv2+ */

namespace Icinga\Module\Monitoring;

use Icinga\Application\Cli;

require_once ICINGA_LIBDIR . '/Icinga/Application/Cli.php';

class Plugin extends Cli
{
}
