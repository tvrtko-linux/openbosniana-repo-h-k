# About the Translation Module <a id="translation-module-about"></a>

Please read the following chapters for more insights on this module:

* [Installation](02-Installation.md#translation-module-installation)
* [Translations](03-Translation.md#module-translation-introduction)
