# Authorization

## Permissions

Name            | Description
----------------|------------
nagvis/overview | NagVis general overview
nagvis/edit     | Modify all NagVis maps
nagvis/admin    | NagVis administration

## Restrictions

Name              | Description
------------------|------------
nagvis/map/filter | Comma-separated set of case insensitive map name patterns (wildcard: \*) a role is allowed to view
