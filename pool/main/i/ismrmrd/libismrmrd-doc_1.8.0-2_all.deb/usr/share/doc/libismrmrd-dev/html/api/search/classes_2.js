var searchData=
[
  ['dataset_189',['Dataset',['../class_i_s_m_r_m_r_d_1_1_dataset.html',1,'ISMRMRD']]]
];
