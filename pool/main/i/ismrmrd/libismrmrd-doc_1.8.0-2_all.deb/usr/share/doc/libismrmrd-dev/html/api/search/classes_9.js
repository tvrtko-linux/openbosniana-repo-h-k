var searchData=
[
  ['ndarray_217',['NDArray',['../class_i_s_m_r_m_r_d_1_1_n_d_array.html',1,'ISMRMRD']]]
];
