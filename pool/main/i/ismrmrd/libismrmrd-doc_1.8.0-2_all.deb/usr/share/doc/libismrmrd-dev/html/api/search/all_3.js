var searchData=
[
  ['data_21',['data',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___n_d_array.html#ac8cb7b627b7dd7f9f7518f8b912eedd2',1,'ISMRMRD::ISMRMRD_NDArray::data()'],['../class_i_s_m_r_m_r_d_1_1_acquisition.html#a30eedd5fa1b40d5bb279b43ed890436d',1,'ISMRMRD::Acquisition::data(uint16_t sample, uint16_t channel)']]],
  ['data_5fbegin_22',['data_begin',['../class_i_s_m_r_m_r_d_1_1_acquisition.html#acc22aa248d001bc1ba85821fb9bbfe37',1,'ISMRMRD::Acquisition']]],
  ['data_5fend_23',['data_end',['../class_i_s_m_r_m_r_d_1_1_acquisition.html#a407e189a6fea905ce9f906a0e17e8152',1,'ISMRMRD::Acquisition']]],
  ['data_5ftype_24',['data_type',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___image_header.html#a011506febf7397fbcddd4e116e1438dc',1,'ISMRMRD::ISMRMRD_ImageHeader::data_type()'],['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___n_d_array.html#af571f04498a39f465bc1490e817e55d1',1,'ISMRMRD::ISMRMRD_NDArray::data_type()']]],
  ['dataset_25',['Dataset',['../class_i_s_m_r_m_r_d_1_1_dataset.html',1,'ISMRMRD']]],
  ['dataset_2eh_26',['dataset.h',['../dataset_8h.html',1,'']]],
  ['dims_27',['dims',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___n_d_array.html#a71112e02f035b2eac6286e25335088e0',1,'ISMRMRD::ISMRMRD_NDArray']]],
  ['discard_5fpost_28',['discard_post',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___acquisition_header.html#ac07d7cb6643b8a21a3dc90b4ac7efa99',1,'ISMRMRD::ISMRMRD_AcquisitionHeader']]],
  ['discard_5fpre_29',['discard_pre',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___acquisition_header.html#af9c7195e511de6f9707b786a6a5988b2',1,'ISMRMRD::ISMRMRD_AcquisitionHeader']]]
];
