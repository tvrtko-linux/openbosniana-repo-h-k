var searchData=
[
  ['read_5fdir_335',['read_dir',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___acquisition_header.html#adae6d47f99f01e980854d9f669ebf671',1,'ISMRMRD::ISMRMRD_AcquisitionHeader::read_dir()'],['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___image_header.html#aa6c12ff1e279f6d0a11bff57115bb501',1,'ISMRMRD::ISMRMRD_ImageHeader::read_dir()']]],
  ['repetition_336',['repetition',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___encoding_counters.html#a13a2b5ae2b6dc20bd3d252d38114bf22',1,'ISMRMRD::ISMRMRD_EncodingCounters::repetition()'],['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___image_header.html#a444c3e27de43b199eeb6d834475784f1',1,'ISMRMRD::ISMRMRD_ImageHeader::repetition()']]]
];
