var searchData=
[
  ['user_345',['user',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___encoding_counters.html#a763d398d0b3d6cc94ab53482fa2eaff1',1,'ISMRMRD::ISMRMRD_EncodingCounters']]],
  ['user_5ffloat_346',['user_float',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___acquisition_header.html#ac050c61443c062e6b21009c1b29cc9fa',1,'ISMRMRD::ISMRMRD_AcquisitionHeader::user_float()'],['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___image_header.html#abe01e148ea1b822e0bfc66385f369d2f',1,'ISMRMRD::ISMRMRD_ImageHeader::user_float()']]],
  ['user_5fint_347',['user_int',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___acquisition_header.html#a7591494513672889f33023ed7afab53a',1,'ISMRMRD::ISMRMRD_AcquisitionHeader::user_int()'],['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___image_header.html#a1048bcb540de8fa261327865884a2aee',1,'ISMRMRD::ISMRMRD_ImageHeader::user_int()']]]
];
