var searchData=
[
  ['data_311',['data',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___n_d_array.html#ac8cb7b627b7dd7f9f7518f8b912eedd2',1,'ISMRMRD::ISMRMRD_NDArray']]],
  ['data_5ftype_312',['data_type',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___image_header.html#a011506febf7397fbcddd4e116e1438dc',1,'ISMRMRD::ISMRMRD_ImageHeader::data_type()'],['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___n_d_array.html#af571f04498a39f465bc1490e817e55d1',1,'ISMRMRD::ISMRMRD_NDArray::data_type()']]],
  ['dims_313',['dims',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___n_d_array.html#a71112e02f035b2eac6286e25335088e0',1,'ISMRMRD::ISMRMRD_NDArray']]],
  ['discard_5fpost_314',['discard_post',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___acquisition_header.html#ac07d7cb6643b8a21a3dc90b4ac7efa99',1,'ISMRMRD::ISMRMRD_AcquisitionHeader']]],
  ['discard_5fpre_315',['discard_pre',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___acquisition_header.html#af9c7195e511de6f9707b786a6a5988b2',1,'ISMRMRD::ISMRMRD_AcquisitionHeader']]]
];
