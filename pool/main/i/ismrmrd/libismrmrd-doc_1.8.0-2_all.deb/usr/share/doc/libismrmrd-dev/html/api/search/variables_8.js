var searchData=
[
  ['matrix_5fsize_326',['matrix_size',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___image_header.html#a2d04a21ca2922ea5586f35b4d9085646',1,'ISMRMRD::ISMRMRD_ImageHeader']]],
  ['measurement_5fuid_327',['measurement_uid',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___acquisition_header.html#a28de28b569a4b0964b36a11d9902e977',1,'ISMRMRD::ISMRMRD_AcquisitionHeader::measurement_uid()'],['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___image_header.html#af593dc0f27d3de07e6eab9d4f63b6031',1,'ISMRMRD::ISMRMRD_ImageHeader::measurement_uid()'],['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___waveform_header.html#aa429a9a2103bf1124e70c59b60f48c6e',1,'ISMRMRD::ISMRMRD_WaveformHeader::measurement_uid()']]]
];
