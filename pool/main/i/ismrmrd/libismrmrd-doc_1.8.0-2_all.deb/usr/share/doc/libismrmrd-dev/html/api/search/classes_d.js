var searchData=
[
  ['sequenceparameters_237',['SequenceParameters',['../struct_i_s_m_r_m_r_d_1_1_sequence_parameters.html',1,'ISMRMRD']]],
  ['studyinformation_238',['StudyInformation',['../struct_i_s_m_r_m_r_d_1_1_study_information.html',1,'ISMRMRD']]],
  ['subjectinformation_239',['SubjectInformation',['../struct_i_s_m_r_m_r_d_1_1_subject_information.html',1,'ISMRMRD']]]
];
