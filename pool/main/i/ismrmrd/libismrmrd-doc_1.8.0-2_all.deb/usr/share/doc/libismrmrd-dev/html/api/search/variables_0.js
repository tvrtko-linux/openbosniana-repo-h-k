var searchData=
[
  ['acquisition_5ftime_5fstamp_302',['acquisition_time_stamp',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___acquisition_header.html#a5d03d466fe0955e400e3041f12ef17cb',1,'ISMRMRD::ISMRMRD_AcquisitionHeader::acquisition_time_stamp()'],['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___image_header.html#ab1643d5ff7f7d8d8f0df33a687755d10',1,'ISMRMRD::ISMRMRD_ImageHeader::acquisition_time_stamp()']]],
  ['active_5fchannels_303',['active_channels',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___acquisition_header.html#afb843a23328b6c18d7e2d6d5fd999e92',1,'ISMRMRD::ISMRMRD_AcquisitionHeader']]],
  ['attribute_5fstring_5flen_304',['attribute_string_len',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___image_header.html#ae87c2be5d9958825a0bfef12663db089',1,'ISMRMRD::ISMRMRD_ImageHeader']]],
  ['available_5fchannels_305',['available_channels',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___acquisition_header.html#aa2d2ed7b3ff3920e5fe608dfbba0983d',1,'ISMRMRD::ISMRMRD_AcquisitionHeader']]],
  ['average_306',['average',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___encoding_counters.html#a12cd1ae44a4d461fdab47fef56f89689',1,'ISMRMRD::ISMRMRD_EncodingCounters::average()'],['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___image_header.html#affabb229ad8926a90884d522c0019a17',1,'ISMRMRD::ISMRMRD_ImageHeader::average()']]]
];
