var searchData=
[
  ['kspace_5fencode_5fstep_5f1_108',['kspace_encode_step_1',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___encoding_counters.html#a48e4a15ed344d30eb723091f9b8c8932',1,'ISMRMRD::ISMRMRD_EncodingCounters']]],
  ['kspace_5fencode_5fstep_5f2_109',['kspace_encode_step_2',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___encoding_counters.html#a6a9ea1be0f0511e7483a395a384f8327',1,'ISMRMRD::ISMRMRD_EncodingCounters']]]
];
