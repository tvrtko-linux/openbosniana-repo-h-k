var searchData=
[
  ['sample_5ftime_5fus_152',['sample_time_us',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___acquisition_header.html#ae7e48f6c770972ccb32ce5fd83ef4f55',1,'ISMRMRD::ISMRMRD_AcquisitionHeader::sample_time_us()'],['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___waveform_header.html#aa2e9ca63798cc41d4d2af64a0024f691',1,'ISMRMRD::ISMRMRD_WaveformHeader::sample_time_us()']]],
  ['scan_5fcounter_153',['scan_counter',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___acquisition_header.html#adee3cfb24973363a4bcdbc5a9ca872ab',1,'ISMRMRD::ISMRMRD_AcquisitionHeader::scan_counter()'],['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___waveform_header.html#a339616b6cf8d55a2e604df610a7b0b38',1,'ISMRMRD::ISMRMRD_WaveformHeader::scan_counter()']]],
  ['segment_154',['segment',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___encoding_counters.html#a1e399f49555f0d5199bfb432f11f5baa',1,'ISMRMRD::ISMRMRD_EncodingCounters']]],
  ['sequenceparameters_155',['SequenceParameters',['../struct_i_s_m_r_m_r_d_1_1_sequence_parameters.html',1,'ISMRMRD']]],
  ['set_156',['set',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___encoding_counters.html#ad0551ce29c0af9f95b615cb664d6118d',1,'ISMRMRD::ISMRMRD_EncodingCounters::set()'],['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___image_header.html#a06b779c6d87bc5ff561c1640a6af61c5',1,'ISMRMRD::ISMRMRD_ImageHeader::set()']]],
  ['setdata_157',['setData',['../class_i_s_m_r_m_r_d_1_1_acquisition.html#a9d8cc5349aefa08f03e479766bf305a5',1,'ISMRMRD::Acquisition']]],
  ['settraj_158',['setTraj',['../class_i_s_m_r_m_r_d_1_1_acquisition.html#ab5000617e62cae2776c2a78f5f3fed6a',1,'ISMRMRD::Acquisition']]],
  ['slice_159',['slice',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___encoding_counters.html#af5d4a54fcd6ad1e7aa571331c5a91aca',1,'ISMRMRD::ISMRMRD_EncodingCounters::slice()'],['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___image_header.html#a1d4e8fef3cee35d88a6333495376db8e',1,'ISMRMRD::ISMRMRD_ImageHeader::slice()']]],
  ['slice_5fdir_160',['slice_dir',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___acquisition_header.html#ab08705a6e385774d314d9ccdedfff3f8',1,'ISMRMRD::ISMRMRD_AcquisitionHeader::slice_dir()'],['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___image_header.html#aebcbc6d4186fc95a2939191e6953c450',1,'ISMRMRD::ISMRMRD_ImageHeader::slice_dir()']]],
  ['studyinformation_161',['StudyInformation',['../struct_i_s_m_r_m_r_d_1_1_study_information.html',1,'ISMRMRD']]],
  ['subjectinformation_162',['SubjectInformation',['../struct_i_s_m_r_m_r_d_1_1_subject_information.html',1,'ISMRMRD']]]
];
