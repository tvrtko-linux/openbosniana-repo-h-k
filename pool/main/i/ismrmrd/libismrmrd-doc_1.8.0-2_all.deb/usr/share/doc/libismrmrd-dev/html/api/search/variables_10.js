var searchData=
[
  ['waveform_5fid_349',['waveform_id',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___waveform_header.html#ace294e72fe941576388ad7d458a74770',1,'ISMRMRD::ISMRMRD_WaveformHeader']]]
];
