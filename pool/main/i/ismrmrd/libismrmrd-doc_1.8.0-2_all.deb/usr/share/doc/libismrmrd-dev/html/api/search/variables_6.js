var searchData=
[
  ['idx_320',['idx',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___acquisition_header.html#a33bb167ac66b336500ce0d1e13b3edfb',1,'ISMRMRD::ISMRMRD_AcquisitionHeader']]],
  ['image_5findex_321',['image_index',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___image_header.html#a33dfc9e6efecf563001ab8716b4f69d2',1,'ISMRMRD::ISMRMRD_ImageHeader']]],
  ['image_5fseries_5findex_322',['image_series_index',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___image_header.html#acd2ef12118725b967ecb02aaa1224995',1,'ISMRMRD::ISMRMRD_ImageHeader']]],
  ['image_5ftype_323',['image_type',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___image_header.html#a285853df7d65973ba3827fc95fc65749',1,'ISMRMRD::ISMRMRD_ImageHeader']]]
];
