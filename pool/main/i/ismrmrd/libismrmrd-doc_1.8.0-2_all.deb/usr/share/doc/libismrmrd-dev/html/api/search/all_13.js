var searchData=
[
  ['version_177',['version',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___acquisition_header.html#af842b4ed2f9b5f8f65b055d5075506da',1,'ISMRMRD::ISMRMRD_AcquisitionHeader::version()'],['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___image_header.html#a2c0f2e99ae82349909c156d84f1ec1ab',1,'ISMRMRD::ISMRMRD_ImageHeader::version()'],['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___n_d_array.html#ac6550614c6dd6526ad857ee1a7575fe8',1,'ISMRMRD::ISMRMRD_NDArray::version()'],['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___waveform_header.html#a9973ce3c8456b6cadbe9381445d82185',1,'ISMRMRD::ISMRMRD_WaveformHeader::version()']]]
];
