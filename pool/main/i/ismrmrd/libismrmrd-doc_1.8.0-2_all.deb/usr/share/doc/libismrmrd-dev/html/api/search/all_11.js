var searchData=
[
  ['threedimensionalfloat_163',['threeDimensionalFloat',['../struct_i_s_m_r_m_r_d_1_1three_dimensional_float.html',1,'ISMRMRD']]],
  ['time_5fstamp_164',['time_stamp',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___waveform_header.html#a71dd8fab91f7007d8d3d990673919d1c',1,'ISMRMRD::ISMRMRD_WaveformHeader']]],
  ['traj_165',['traj',['../class_i_s_m_r_m_r_d_1_1_acquisition.html#a2b558ed6d3aeae2ee0b561cfd825ed32',1,'ISMRMRD::Acquisition']]],
  ['traj_5fbegin_166',['traj_begin',['../class_i_s_m_r_m_r_d_1_1_acquisition.html#a7b13cb7880745b29aa0b5bdd3ccaf9be',1,'ISMRMRD::Acquisition']]],
  ['traj_5fend_167',['traj_end',['../class_i_s_m_r_m_r_d_1_1_acquisition.html#aa7e81d0fa038de76042368a48221aa82',1,'ISMRMRD::Acquisition']]],
  ['trajectory_5fdimensions_168',['trajectory_dimensions',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___acquisition_header.html#a9ea199274717d77c7293073419f1521c',1,'ISMRMRD::ISMRMRD_AcquisitionHeader']]],
  ['trajectorydescription_169',['TrajectoryDescription',['../struct_i_s_m_r_m_r_d_1_1_trajectory_description.html',1,'ISMRMRD']]]
];
