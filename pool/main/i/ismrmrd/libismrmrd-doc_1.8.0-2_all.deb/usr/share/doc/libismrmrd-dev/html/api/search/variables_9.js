var searchData=
[
  ['ndim_328',['ndim',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___n_d_array.html#adc8e1e91d8c1c476326be62b1c33d51e',1,'ISMRMRD::ISMRMRD_NDArray']]],
  ['number_5fof_5fsamples_329',['number_of_samples',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___acquisition_header.html#ae41f80968bf8659edd4e630c818aad65',1,'ISMRMRD::ISMRMRD_AcquisitionHeader::number_of_samples()'],['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___waveform_header.html#a48188215ec74bee4d7a5ea99236999c0',1,'ISMRMRD::ISMRMRD_WaveformHeader::number_of_samples()']]]
];
