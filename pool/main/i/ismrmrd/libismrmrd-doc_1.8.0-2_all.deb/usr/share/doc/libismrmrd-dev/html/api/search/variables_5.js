var searchData=
[
  ['head_319',['head',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___acquisition.html#ad5193ef75854efef8a587fa88344bd83',1,'ISMRMRD::ISMRMRD_Acquisition']]]
];
