var searchData=
[
  ['time_5fstamp_343',['time_stamp',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___waveform_header.html#a71dd8fab91f7007d8d3d990673919d1c',1,'ISMRMRD::ISMRMRD_WaveformHeader']]],
  ['trajectory_5fdimensions_344',['trajectory_dimensions',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___acquisition_header.html#a9ea199274717d77c7293073419f1521c',1,'ISMRMRD::ISMRMRD_AcquisitionHeader']]]
];
