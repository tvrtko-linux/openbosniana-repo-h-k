var searchData=
[
  ['coillabel_188',['CoilLabel',['../struct_i_s_m_r_m_r_d_1_1_coil_label.html',1,'ISMRMRD']]]
];
