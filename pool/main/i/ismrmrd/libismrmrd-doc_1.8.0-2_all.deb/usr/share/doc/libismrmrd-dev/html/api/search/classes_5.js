var searchData=
[
  ['hdf5_5facquisiton_196',['HDF5_Acquisiton',['../struct_i_s_m_r_m_r_d_1_1_h_d_f5___acquisiton.html',1,'ISMRMRD']]],
  ['hdf5_5fwaveform_197',['HDF5_Waveform',['../struct_i_s_m_r_m_r_d_1_1_h_d_f5___waveform.html',1,'ISMRMRD']]]
];
