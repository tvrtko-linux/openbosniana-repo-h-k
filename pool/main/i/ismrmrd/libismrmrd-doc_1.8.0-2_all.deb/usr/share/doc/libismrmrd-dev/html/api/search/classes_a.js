var searchData=
[
  ['optional_218',['Optional',['../class_i_s_m_r_m_r_d_1_1_optional.html',1,'ISMRMRD']]],
  ['optional_3c_20float_20_3e_219',['Optional&lt; float &gt;',['../class_i_s_m_r_m_r_d_1_1_optional.html',1,'ISMRMRD']]],
  ['optional_3c_20ismrmrd_3a_3aacquisitionsysteminformation_20_3e_220',['Optional&lt; ISMRMRD::AcquisitionSystemInformation &gt;',['../class_i_s_m_r_m_r_d_1_1_optional.html',1,'ISMRMRD']]],
  ['optional_3c_20ismrmrd_3a_3alimit_20_3e_221',['Optional&lt; ISMRMRD::Limit &gt;',['../class_i_s_m_r_m_r_d_1_1_optional.html',1,'ISMRMRD']]],
  ['optional_3c_20ismrmrd_3a_3ameasurementinformation_20_3e_222',['Optional&lt; ISMRMRD::MeasurementInformation &gt;',['../class_i_s_m_r_m_r_d_1_1_optional.html',1,'ISMRMRD']]],
  ['optional_3c_20ismrmrd_3a_3aparallelimaging_20_3e_223',['Optional&lt; ISMRMRD::ParallelImaging &gt;',['../class_i_s_m_r_m_r_d_1_1_optional.html',1,'ISMRMRD']]],
  ['optional_3c_20ismrmrd_3a_3asequenceparameters_20_3e_224',['Optional&lt; ISMRMRD::SequenceParameters &gt;',['../class_i_s_m_r_m_r_d_1_1_optional.html',1,'ISMRMRD']]],
  ['optional_3c_20ismrmrd_3a_3astudyinformation_20_3e_225',['Optional&lt; ISMRMRD::StudyInformation &gt;',['../class_i_s_m_r_m_r_d_1_1_optional.html',1,'ISMRMRD']]],
  ['optional_3c_20ismrmrd_3a_3asubjectinformation_20_3e_226',['Optional&lt; ISMRMRD::SubjectInformation &gt;',['../class_i_s_m_r_m_r_d_1_1_optional.html',1,'ISMRMRD']]],
  ['optional_3c_20ismrmrd_3a_3athreedimensionalfloat_20_3e_227',['Optional&lt; ISMRMRD::threeDimensionalFloat &gt;',['../class_i_s_m_r_m_r_d_1_1_optional.html',1,'ISMRMRD']]],
  ['optional_3c_20ismrmrd_3a_3atrajectorydescription_20_3e_228',['Optional&lt; ISMRMRD::TrajectoryDescription &gt;',['../class_i_s_m_r_m_r_d_1_1_optional.html',1,'ISMRMRD']]],
  ['optional_3c_20ismrmrd_3a_3auserparameters_20_3e_229',['Optional&lt; ISMRMRD::UserParameters &gt;',['../class_i_s_m_r_m_r_d_1_1_optional.html',1,'ISMRMRD']]],
  ['optional_3c_20long_20_3e_230',['Optional&lt; long &gt;',['../class_i_s_m_r_m_r_d_1_1_optional.html',1,'ISMRMRD']]],
  ['optional_3c_20long_20int_20_3e_231',['Optional&lt; long int &gt;',['../class_i_s_m_r_m_r_d_1_1_optional.html',1,'ISMRMRD']]],
  ['optional_3c_20std_3a_3astring_20_3e_232',['Optional&lt; std::string &gt;',['../class_i_s_m_r_m_r_d_1_1_optional.html',1,'ISMRMRD']]],
  ['optional_3c_20std_3a_3avector_3c_20float_20_3e_20_3e_233',['Optional&lt; std::vector&lt; float &gt; &gt;',['../class_i_s_m_r_m_r_d_1_1_optional.html',1,'ISMRMRD']]],
  ['optional_3c_20unsigned_20short_20_3e_234',['Optional&lt; unsigned short &gt;',['../class_i_s_m_r_m_r_d_1_1_optional.html',1,'ISMRMRD']]]
];
