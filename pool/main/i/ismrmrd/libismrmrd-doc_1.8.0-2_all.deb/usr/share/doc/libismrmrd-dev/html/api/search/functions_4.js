var searchData=
[
  ['get_5fdata_5ftype_262',['get_data_type',['../group__cxxapi.html#gaf67d53c80d44b2f283c67e70b24aa186',1,'ISMRMRD']]],
  ['getdataptr_263',['getDataPtr',['../class_i_s_m_r_m_r_d_1_1_acquisition.html#a70d7d35e41a8ddfc6600bb8702a5198c',1,'ISMRMRD::Acquisition']]],
  ['getdatasize_264',['getDataSize',['../class_i_s_m_r_m_r_d_1_1_image.html#aec8e190e240cf091f69a752c764bba37',1,'ISMRMRD::Image']]],
  ['getnumberofdataelements_265',['getNumberOfDataElements',['../class_i_s_m_r_m_r_d_1_1_image.html#a064b30e8bccfa427f9e68f084f38adfe',1,'ISMRMRD::Image']]],
  ['gettrajptr_266',['getTrajPtr',['../class_i_s_m_r_m_r_d_1_1_acquisition.html#a4850648ee7d6a98caa1fc91cfaa36451',1,'ISMRMRD::Acquisition']]]
];
