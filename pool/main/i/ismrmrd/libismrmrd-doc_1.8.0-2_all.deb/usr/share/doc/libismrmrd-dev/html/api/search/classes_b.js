var searchData=
[
  ['parallelimaging_235',['ParallelImaging',['../struct_i_s_m_r_m_r_d_1_1_parallel_imaging.html',1,'ISMRMRD']]]
];
