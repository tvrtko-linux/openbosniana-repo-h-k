var searchData=
[
  ['center_5fsample_307',['center_sample',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___acquisition_header.html#ac43f0783a351175b43ff7a0fb5aed0fd',1,'ISMRMRD::ISMRMRD_AcquisitionHeader']]],
  ['channel_5fmask_308',['channel_mask',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___acquisition_header.html#ad2ef6487369cdccc7dcea8852d461906',1,'ISMRMRD::ISMRMRD_AcquisitionHeader']]],
  ['channels_309',['channels',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___image_header.html#a3adbf9921c3da11b48d4a333c235571d',1,'ISMRMRD::ISMRMRD_ImageHeader::channels()'],['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___waveform_header.html#a7e389a22bd31617df9b62b85b4dadea2',1,'ISMRMRD::ISMRMRD_WaveformHeader::channels()']]],
  ['contrast_310',['contrast',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___encoding_counters.html#ae76ecf0229448670738f3f76d47c4853',1,'ISMRMRD::ISMRMRD_EncodingCounters::contrast()'],['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___image_header.html#af0799b7b2edf3bce89e4a8eeade634c6',1,'ISMRMRD::ISMRMRD_ImageHeader::contrast()']]]
];
