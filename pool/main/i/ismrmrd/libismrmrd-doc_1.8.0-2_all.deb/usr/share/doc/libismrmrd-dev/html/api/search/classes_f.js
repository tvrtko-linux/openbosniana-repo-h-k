var searchData=
[
  ['userparameterdouble_242',['UserParameterDouble',['../struct_i_s_m_r_m_r_d_1_1_user_parameter_double.html',1,'ISMRMRD']]],
  ['userparameterlong_243',['UserParameterLong',['../struct_i_s_m_r_m_r_d_1_1_user_parameter_long.html',1,'ISMRMRD']]],
  ['userparameters_244',['UserParameters',['../struct_i_s_m_r_m_r_d_1_1_user_parameters.html',1,'ISMRMRD']]],
  ['userparameterstring_245',['UserParameterString',['../struct_i_s_m_r_m_r_d_1_1_user_parameter_string.html',1,'ISMRMRD']]]
];
