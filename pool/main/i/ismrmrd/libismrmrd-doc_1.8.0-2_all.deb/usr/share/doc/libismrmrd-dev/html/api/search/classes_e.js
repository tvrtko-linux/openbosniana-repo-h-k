var searchData=
[
  ['threedimensionalfloat_240',['threeDimensionalFloat',['../struct_i_s_m_r_m_r_d_1_1three_dimensional_float.html',1,'ISMRMRD']]],
  ['trajectorydescription_241',['TrajectoryDescription',['../struct_i_s_m_r_m_r_d_1_1_trajectory_description.html',1,'ISMRMRD']]]
];
