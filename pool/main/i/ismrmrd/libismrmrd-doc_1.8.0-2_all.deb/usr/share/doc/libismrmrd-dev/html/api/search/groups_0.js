var searchData=
[
  ['c_20api_372',['C API',['../group__capi.html',1,'']]],
  ['c_2b_2b_20api_373',['C++ API',['../group__cxxapi.html',1,'']]]
];
