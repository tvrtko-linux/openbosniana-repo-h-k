var searchData=
[
  ['setdata_297',['setData',['../class_i_s_m_r_m_r_d_1_1_acquisition.html#a9d8cc5349aefa08f03e479766bf305a5',1,'ISMRMRD::Acquisition']]],
  ['settraj_298',['setTraj',['../class_i_s_m_r_m_r_d_1_1_acquisition.html#ab5000617e62cae2776c2a78f5f3fed6a',1,'ISMRMRD::Acquisition']]]
];
