var searchData=
[
  ['encoding_5fspace_5fref_316',['encoding_space_ref',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___acquisition_header.html#a883fef3c99622400ca51019c9b8a2fcd',1,'ISMRMRD::ISMRMRD_AcquisitionHeader']]]
];
