var searchData=
[
  ['traj_299',['traj',['../class_i_s_m_r_m_r_d_1_1_acquisition.html#a2b558ed6d3aeae2ee0b561cfd825ed32',1,'ISMRMRD::Acquisition']]],
  ['traj_5fbegin_300',['traj_begin',['../class_i_s_m_r_m_r_d_1_1_acquisition.html#a7b13cb7880745b29aa0b5bdd3ccaf9be',1,'ISMRMRD::Acquisition']]],
  ['traj_5fend_301',['traj_end',['../class_i_s_m_r_m_r_d_1_1_acquisition.html#aa7e81d0fa038de76042368a48221aa82',1,'ISMRMRD::Acquisition']]]
];
