var searchData=
[
  ['matrix_5fsize_112',['matrix_size',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___image_header.html#a2d04a21ca2922ea5586f35b4d9085646',1,'ISMRMRD::ISMRMRD_ImageHeader']]],
  ['matrixsize_113',['MatrixSize',['../struct_i_s_m_r_m_r_d_1_1_matrix_size.html',1,'ISMRMRD']]],
  ['measurement_5fuid_114',['measurement_uid',['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___acquisition_header.html#a28de28b569a4b0964b36a11d9902e977',1,'ISMRMRD::ISMRMRD_AcquisitionHeader::measurement_uid()'],['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___image_header.html#af593dc0f27d3de07e6eab9d4f63b6031',1,'ISMRMRD::ISMRMRD_ImageHeader::measurement_uid()'],['../struct_i_s_m_r_m_r_d_1_1_i_s_m_r_m_r_d___waveform_header.html#aa429a9a2103bf1124e70c59b60f48c6e',1,'ISMRMRD::ISMRMRD_WaveformHeader::measurement_uid()']]],
  ['measurementdependency_115',['MeasurementDependency',['../struct_i_s_m_r_m_r_d_1_1_measurement_dependency.html',1,'ISMRMRD']]],
  ['measurementinformation_116',['MeasurementInformation',['../struct_i_s_m_r_m_r_d_1_1_measurement_information.html',1,'ISMRMRD']]],
  ['meta_20attributes_20api_117',['Meta Attributes API',['../group__meta.html',1,'']]],
  ['meta_2eh_118',['meta.h',['../meta_8h.html',1,'']]],
  ['metacontainer_119',['MetaContainer',['../class_i_s_m_r_m_r_d_1_1_meta_container.html',1,'ISMRMRD']]],
  ['metavalue_120',['MetaValue',['../class_i_s_m_r_m_r_d_1_1_meta_value.html',1,'ISMRMRD::MetaValue'],['../class_i_s_m_r_m_r_d_1_1_meta_value.html#a3b3576c43e85b0292dd3eb1ece0deffa',1,'ISMRMRD::MetaValue::MetaValue()'],['../class_i_s_m_r_m_r_d_1_1_meta_value.html#a42cf9b2ee3e251099fc2968dede04357',1,'ISMRMRD::MetaValue::MetaValue(const char *s)'],['../class_i_s_m_r_m_r_d_1_1_meta_value.html#a9f4cf3542e30e7b99c7bbff374909e4d',1,'ISMRMRD::MetaValue::MetaValue(long l)'],['../class_i_s_m_r_m_r_d_1_1_meta_value.html#aaae83e2fbb5fabf912d5f882124eb633',1,'ISMRMRD::MetaValue::MetaValue(double d)']]]
];
