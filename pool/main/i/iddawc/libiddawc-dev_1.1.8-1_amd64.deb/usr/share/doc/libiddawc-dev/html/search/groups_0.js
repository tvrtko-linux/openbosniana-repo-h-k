var searchData=
[
  ['constants_20and_20properties_0',['Constants and properties',['../group__const.html',1,'']]],
  ['core_20functions_1',['Core functions',['../group__core.html',1,'']]]
];
