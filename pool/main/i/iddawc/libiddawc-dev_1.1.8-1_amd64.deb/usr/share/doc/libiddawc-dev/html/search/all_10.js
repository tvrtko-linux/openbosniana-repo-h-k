var searchData=
[
  ['save_5fhttp_5frequest_5fresponse_0',['save_http_request_response',['../struct__i__session.html#ab26a88884d54f7b12d56d2188038af15',1,'_i_session']]],
  ['saved_5frequest_1',['saved_request',['../struct__i__session.html#a96ee05474047bb42b0f9ce58b677123f',1,'_i_session']]],
  ['saved_5fresponse_2',['saved_response',['../struct__i__session.html#ab36f0f4a44bf7ff5e37442f3480bccd4',1,'_i_session']]],
  ['scope_3',['scope',['../struct__i__session.html#ac6e76dafa87b66ca28596df8f673837d',1,'_i_session']]],
  ['server_5fenc_4',['server_enc',['../struct__i__session.html#a3334c65e90f3a79a20bfbf6b17df7d7c',1,'_i_session']]],
  ['server_5fenc_5falg_5',['server_enc_alg',['../struct__i__session.html#a95438cb9c357f7995ad6e3c68d49a1c0',1,'_i_session']]],
  ['server_5fjwks_6',['server_jwks',['../struct__i__session.html#af9a60275d7fe1a3cffa75454c4981119',1,'_i_session']]],
  ['server_5fjwks_5fcache_5fexpiration_7',['server_jwks_cache_expiration',['../struct__i__session.html#abd9b9584185d8f11813ab152ab590167',1,'_i_session']]],
  ['server_5fjwks_5fcache_5fexpires_5fat_8',['server_jwks_cache_expires_at',['../struct__i__session.html#a135d510ef707c10a920d498236493ba7',1,'_i_session']]],
  ['server_5fkid_9',['server_kid',['../struct__i__session.html#ac6408a93cf2095644c8564a0d3d6c337',1,'_i_session']]],
  ['state_10',['state',['../struct__i__session.html#a50e2a5371d92019adc5e0f4a9b10159e',1,'_i_session']]],
  ['struct_20_5fi_5fsession_20definition_11',['struct _i_session definition',['../group__struct.html',1,'']]]
];
