var searchData=
[
  ['openid_5fconfig_0',['openid_config',['../struct__i__session.html#a4bf4fa948532b3fda7a35dab2d67c245',1,'_i_session']]],
  ['openid_5fconfig_5fendpoint_1',['openid_config_endpoint',['../struct__i__session.html#a42c02878f4b2a5f8288bb32a618d7776',1,'_i_session']]],
  ['openid_5fconfig_5fstrict_2',['openid_config_strict',['../struct__i__session.html#a9100b4d58a9bd3cd30540c47b88c8b11',1,'_i_session']]]
];
