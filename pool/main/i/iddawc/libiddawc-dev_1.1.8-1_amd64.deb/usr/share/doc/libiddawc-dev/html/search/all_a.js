var searchData=
[
  ['j_5fauthorization_5fdetails_0',['j_authorization_details',['../struct__i__session.html#a7c15be8a03d165ac293f9a83d80a3d8f',1,'_i_session']]],
  ['j_5fclaims_1',['j_claims',['../struct__i__session.html#a575a9ac186243101762a982ff7524b8d',1,'_i_session']]],
  ['j_5fuserinfo_2',['j_userinfo',['../struct__i__session.html#a5940f4698392b3fc45cf7fefe89f172f',1,'_i_session']]]
];
