var searchData=
[
  ['backchannel_5flogout_5fsession_5frequired_0',['backchannel_logout_session_required',['../struct__i__session.html#ac4d777c1120d43963a39e72a3e946c95',1,'_i_session']]],
  ['backchannel_5flogout_5furi_1',['backchannel_logout_uri',['../struct__i__session.html#a9c00f58300a2cc6a5b8fad8c35de6154',1,'_i_session']]]
];
