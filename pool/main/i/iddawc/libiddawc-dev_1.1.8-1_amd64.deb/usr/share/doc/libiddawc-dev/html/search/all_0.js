var searchData=
[
  ['_5fi_5fsession_0',['_i_session',['../struct__i__session.html',1,'']]]
];
