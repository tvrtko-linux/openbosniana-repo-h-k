var searchData=
[
  ['struct_20_5fi_5fsession_20definition_0',['struct _i_session definition',['../group__struct.html',1,'']]]
];
