var searchData=
[
  ['frontchannel_5flogout_5fsession_5frequired_0',['frontchannel_logout_session_required',['../struct__i__session.html#af23436cc8eca5b431be26d2467e0e38e',1,'_i_session']]],
  ['frontchannel_5flogout_5furi_1',['frontchannel_logout_uri',['../struct__i__session.html#a62a1adfb90c4ade2f38ed745e5a5ab10',1,'_i_session']]]
];
