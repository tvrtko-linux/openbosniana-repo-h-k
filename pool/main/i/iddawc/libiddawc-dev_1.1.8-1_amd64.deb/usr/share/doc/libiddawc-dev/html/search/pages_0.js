var searchData=
[
  ['iddawc_20api_20documentation_0',['Iddawc API documentation',['../index.html',1,'']]]
];
