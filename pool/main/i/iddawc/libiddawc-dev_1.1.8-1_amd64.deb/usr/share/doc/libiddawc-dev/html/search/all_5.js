var searchData=
[
  ['end_5fsession_5fendpoint_0',['end_session_endpoint',['../struct__i__session.html#acbcd49d90c26374f81844606674cce3c',1,'_i_session']]],
  ['error_1',['error',['../struct__i__session.html#a4cff9bfb53809b47a28ce2dc9c7466e2',1,'_i_session']]],
  ['error_5fdescription_2',['error_description',['../struct__i__session.html#a03436b1a7e14d39d87af6be5a6e79242',1,'_i_session']]],
  ['error_5furi_3',['error_uri',['../struct__i__session.html#a7e994eec1f036bda6cf462d31c144c5b',1,'_i_session']]],
  ['expires_5fat_4',['expires_at',['../struct__i__session.html#a05c0735820b059020c7980f3589d5bde',1,'_i_session']]],
  ['expires_5fin_5',['expires_in',['../struct__i__session.html#ab19dce6f077a6939b7e3ff9ccd201c99',1,'_i_session']]]
];
