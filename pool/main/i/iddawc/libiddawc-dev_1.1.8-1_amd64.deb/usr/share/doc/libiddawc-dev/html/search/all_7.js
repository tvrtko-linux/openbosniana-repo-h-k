var searchData=
[
  ['get_20or_20set_20struct_20_5fi_5fsession_20properties_0',['Get or set struct _i_session properties',['../group__properties.html',1,'']]]
];
