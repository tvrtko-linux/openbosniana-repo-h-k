var searchData=
[
  ['key_5ffile_0',['key_file',['../struct__i__session.html#aed44341c218a568ee100a49a9cb61aed',1,'_i_session']]]
];
