var searchData=
[
  ['iddawc_2ec_0',['iddawc.c',['../iddawc_8c.html',1,'']]],
  ['iddawc_2eh_1',['iddawc.h',['../iddawc_8h.html',1,'']]]
];
