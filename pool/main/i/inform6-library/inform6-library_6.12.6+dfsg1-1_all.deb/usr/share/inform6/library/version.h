System_file;

Constant LibSerial       "220219";
Constant LibRelease      "6.12.6";
Constant LIBRARY_VERSION  612;
Constant Grammar__Version 2;
