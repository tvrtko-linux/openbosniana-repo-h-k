var searchData=
[
  ['maj',['maj',['../structmaj.html',1,'']]]
];
