var searchData=
[
  ['cigar_5f',['cigar_',['../structcigar__.html',1,'']]]
];
