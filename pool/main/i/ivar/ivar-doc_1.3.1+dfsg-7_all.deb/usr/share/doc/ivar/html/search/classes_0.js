var searchData=
[
  ['allele',['allele',['../structallele.html',1,'']]],
  ['args_5ft',['args_t',['../structargs__t.html',1,'']]]
];
