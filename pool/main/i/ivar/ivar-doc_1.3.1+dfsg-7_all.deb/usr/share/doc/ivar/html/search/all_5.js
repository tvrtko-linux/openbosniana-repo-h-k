var searchData=
[
  ['primer',['primer',['../classprimer.html',1,'']]]
];
