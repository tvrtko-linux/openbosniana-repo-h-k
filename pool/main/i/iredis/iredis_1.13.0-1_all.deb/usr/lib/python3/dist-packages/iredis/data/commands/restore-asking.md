The `RESTORE-ASKING` command is an internal command.
It is used by a Redis cluster master during slot migration.