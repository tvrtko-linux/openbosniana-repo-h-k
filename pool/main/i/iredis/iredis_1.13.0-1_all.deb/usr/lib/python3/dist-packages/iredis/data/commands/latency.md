This is a container command for latency diagnostics commands.

To see the list of available commands you can call `LATENCY HELP`.