`DEBUG SEGFAULT` performs an invalid memory access that crashes Redis. It is
used to simulate bugs during the development.

@return

@simple-string-reply
