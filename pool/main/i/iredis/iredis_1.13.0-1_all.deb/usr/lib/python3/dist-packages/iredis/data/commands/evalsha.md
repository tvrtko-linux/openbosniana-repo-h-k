Evaluate a script from the server's cache by its SHA1 digest.

The server caches scripts by using the `SCRIPT LOAD` command.
The command is otherwise identical to `EVAL`.

Please refer to the [Redis Programmability](/topics/programmability) and [Introduction to Eval Scripts](/topics/eval-intro) for more information about Lua scripts.
