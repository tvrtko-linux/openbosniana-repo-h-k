This is a container command for object introspection commands.

To see the list of available commands you can call `OBJECT HELP`.
