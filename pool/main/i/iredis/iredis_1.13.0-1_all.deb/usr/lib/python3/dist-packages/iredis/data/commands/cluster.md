This is a container command for Redis Cluster commands.

To see the list of available commands you can call `CLUSTER HELP`.
