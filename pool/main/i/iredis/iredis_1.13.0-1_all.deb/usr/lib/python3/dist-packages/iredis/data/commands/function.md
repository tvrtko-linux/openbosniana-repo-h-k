This is a container command for function commands.

To see the list of available commands you can call `FUNCTION HELP`.