Read-only variant of the `GEORADIUS` command.

This command is identical to the `GEORADIUS` command, except that it doesn't support the optional `STORE` and `STOREDIST` parameters.

@return

@array-reply: An array with each entry being the corresponding result of the subcommand given at the same position.
