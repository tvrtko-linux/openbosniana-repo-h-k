This is a container command for module management commands.

To see the list of available commands you can call `MODULE HELP`.
