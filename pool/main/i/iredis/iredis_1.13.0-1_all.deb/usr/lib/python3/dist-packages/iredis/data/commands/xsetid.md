The `XSETID` command is an internal command.
It is used by a Redis master to replicate the last delivered ID of streams.