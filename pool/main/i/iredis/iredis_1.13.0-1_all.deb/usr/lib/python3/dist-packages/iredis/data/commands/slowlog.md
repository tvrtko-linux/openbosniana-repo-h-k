This is a container command for slow log management commands.

To see the list of available commands you can call `SLOWLOG HELP`.
