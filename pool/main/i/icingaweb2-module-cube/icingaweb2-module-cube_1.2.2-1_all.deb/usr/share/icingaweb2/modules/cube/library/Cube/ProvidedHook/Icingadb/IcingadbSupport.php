<?php

// Icinga Web 2 Cube Module | (c) 2022 Icinga GmbH | GPLv2

namespace Icinga\Module\Cube\ProvidedHook\Icingadb;

use Icinga\Module\Icingadb\Hook\IcingadbSupportHook;

class IcingadbSupport extends IcingadbSupportHook
{
}
