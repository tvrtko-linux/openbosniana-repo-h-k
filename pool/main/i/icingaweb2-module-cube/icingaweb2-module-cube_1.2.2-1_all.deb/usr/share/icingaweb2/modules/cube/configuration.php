<?php

// Icinga Web 2 Cube Module | (c) 2016 Icinga GmbH | GPLv2

$this->menuSection(N_('Reporting'))->add($this->translate('Cube'))->setUrl('cube/hosts')->setPriority(10);
