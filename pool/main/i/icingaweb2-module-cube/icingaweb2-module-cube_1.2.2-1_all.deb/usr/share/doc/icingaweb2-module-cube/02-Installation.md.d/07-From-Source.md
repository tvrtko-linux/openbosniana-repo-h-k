# Installing Icinga Cube from Source
<!-- {% set from_source = True %} -->
<!-- {% include "02-Installation.md" %} -->
