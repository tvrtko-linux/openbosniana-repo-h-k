# Installing Icinga Cube on SLES
<!-- {% set sles = True %} -->
<!-- {% include "02-Installation.md" %} -->
