# Installing Icinga Cube on Debian
<!-- {% set debian = True %} -->
<!-- {% include "02-Installation.md" %} -->
