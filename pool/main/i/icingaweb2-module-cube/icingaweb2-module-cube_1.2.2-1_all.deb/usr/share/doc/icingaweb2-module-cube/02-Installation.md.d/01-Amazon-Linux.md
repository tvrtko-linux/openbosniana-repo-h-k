# Installing Icinga Cube on Amazon Linux
<!-- {% set amazon_linux = True %} -->
<!-- {% include "02-Installation.md" %} -->
