# Installing Icinga Cube on RHEL
<!-- {% set rhel = True %} -->
<!-- {% include "02-Installation.md" %} -->
