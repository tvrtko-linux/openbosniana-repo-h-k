# use\_component\_depsA

This package uses the `child` and `parent` components of `component\_deps`
and calls `ign_find_package` with the components specified
in the order `parent child`.
