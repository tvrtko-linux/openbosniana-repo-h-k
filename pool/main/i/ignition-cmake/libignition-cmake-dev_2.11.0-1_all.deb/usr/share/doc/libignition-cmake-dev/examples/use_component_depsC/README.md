# use\_component\_depsC

This package uses the `child` component of `component\_deps`
but should also find the `parent` component indirectly.
