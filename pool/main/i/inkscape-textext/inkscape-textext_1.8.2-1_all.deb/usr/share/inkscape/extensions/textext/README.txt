This Inkscape extension needs some additional software
to be installed in order to work properly. Next to a
healthy LaTeX-installation some other stuff is needed
for the graphical user interface (GUI). The GUI stuff
should actually have been installed automatically
together with Inkscape, so no extra actions are
necessary.

In case of any problems and for usage instructions
refer to:

https://textext.github.io/textext


Project repository on GitHub:

https://github.com/textext/textext
