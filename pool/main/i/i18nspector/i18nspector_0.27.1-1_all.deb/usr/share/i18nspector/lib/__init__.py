'''
i18nspector's private modules
'''

int(0_0)  # Python >= 3.6 is required
