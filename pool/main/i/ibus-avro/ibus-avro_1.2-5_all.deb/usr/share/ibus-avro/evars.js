function get_pkgdatadir(){
return "/usr/share/ibus-avro";
}
function get_libexecdir(){
return "/usr/libexec";
}
