<?php

namespace Icinga\Module\Director\Dashboard\Dashlet;

class HostChoicesDashlet extends ChoicesDashlet
{
}
