<?php

namespace Icinga\Module\Director\Db;

class HostMembershipHousekeeping extends MembershipHousekeeping
{
    protected $type = 'host';
}
