<?php

namespace Icinga\Module\Director\Clicommands;

use Icinga\Module\Director\Cli\ObjectsCommand;

/**
 * List Icinga Commands
 *
 * Use this command to list Icinga Command objects
 */
class CommandsCommand extends ObjectsCommand
{
}
