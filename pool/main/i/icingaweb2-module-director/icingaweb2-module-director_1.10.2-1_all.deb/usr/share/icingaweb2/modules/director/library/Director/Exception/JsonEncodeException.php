<?php

namespace Icinga\Module\Director\Exception;

class JsonEncodeException extends JsonException
{
}
