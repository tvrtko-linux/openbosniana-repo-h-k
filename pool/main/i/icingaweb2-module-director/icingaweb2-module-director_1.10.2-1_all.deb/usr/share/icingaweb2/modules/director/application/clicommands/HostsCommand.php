<?php

namespace Icinga\Module\Director\Clicommands;

use Icinga\Module\Director\Cli\ObjectsCommand;

/**
 * Manage Icinga Hosts
 *
 * Use this command to list Icinga Host objects
 */
class HostsCommand extends ObjectsCommand
{
}
