<?php

namespace Icinga\Module\Director\Objects;

class HostApplyMatches extends ObjectApplyMatches
{
    protected static $type = 'host';
}
