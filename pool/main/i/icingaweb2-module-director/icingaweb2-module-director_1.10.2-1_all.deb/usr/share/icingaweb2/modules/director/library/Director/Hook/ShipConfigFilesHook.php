<?php

namespace Icinga\Module\Director\Hook;

abstract class ShipConfigFilesHook
{
    public function fetchFiles()
    {
        return array();
    }
}
