var searchData=
[
  ['allocator_0',['Allocator',['../class_iso_spec_1_1_allocator.html',1,'IsoSpec']]],
  ['allocator_3c_20int_20_3e_1',['Allocator&lt; int &gt;',['../class_iso_spec_1_1_allocator.html',1,'IsoSpec']]]
];
