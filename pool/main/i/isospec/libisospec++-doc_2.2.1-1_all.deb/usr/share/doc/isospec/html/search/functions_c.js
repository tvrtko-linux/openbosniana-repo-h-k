var searchData=
[
  ['terminate_5fsearch_0',['terminate_search',['../class_iso_spec_1_1_iso_threshold_generator.html#ac6aa2fff002a76b0beae1995f34ae5f6',1,'IsoSpec::IsoThresholdGenerator::terminate_search()'],['../class_iso_spec_1_1_iso_layered_generator.html#a6c4ea5906136d802859f47cd1b5add8d',1,'IsoSpec::IsoLayeredGenerator::terminate_search()']]]
];
