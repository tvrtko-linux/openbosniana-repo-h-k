var searchData=
[
  ['recalc_0',['recalc',['../class_iso_spec_1_1_iso_layered_generator.html#a9961fe657308ccd66950d99042bf9a85',1,'IsoSpec::IsoLayeredGenerator']]],
  ['reset_1',['reset',['../class_iso_spec_1_1_iso_threshold_generator.html#ab830ffa21469df45a513ff1dcaf5d9e7',1,'IsoSpec::IsoThresholdGenerator']]]
];
