var searchData=
[
  ['marginal_0',['Marginal',['../class_iso_spec_1_1_marginal.html',1,'IsoSpec']]],
  ['marginaltrek_1',['MarginalTrek',['../class_iso_spec_1_1_marginal_trek.html',1,'IsoSpec']]]
];
