var searchData=
[
  ['variance_0',['variance',['../class_iso_spec_1_1_iso.html#a75a213b246dbc869ed782e11ba132a0f',1,'IsoSpec::Iso::variance()'],['../class_iso_spec_1_1_marginal.html#a9181a7b322ac8fe0f252494ba1c67cc7',1,'IsoSpec::Marginal::variance()']]]
];
