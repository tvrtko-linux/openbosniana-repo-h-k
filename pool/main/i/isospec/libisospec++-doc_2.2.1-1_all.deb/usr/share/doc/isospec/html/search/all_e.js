var searchData=
[
  ['savemarginallogsizeestimates_0',['saveMarginalLogSizeEstimates',['../class_iso_spec_1_1_iso.html#a1038a9856b96a2d9acd74d02b6ae9aee',1,'IsoSpec::Iso']]],
  ['ssummator_1',['SSummator',['../class_iso_spec_1_1_s_summator.html',1,'IsoSpec']]],
  ['stddev_2',['stddev',['../class_iso_spec_1_1_iso.html#a368760df31f69da528ac6ebc1b28e5fd',1,'IsoSpec::Iso']]],
  ['summator_3',['Summator',['../class_iso_spec_1_1_summator.html',1,'IsoSpec']]]
];
