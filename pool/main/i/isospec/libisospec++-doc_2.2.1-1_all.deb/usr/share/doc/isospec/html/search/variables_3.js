var searchData=
[
  ['isotopeno_0',['isotopeNo',['../class_iso_spec_1_1_marginal.html#a8dd6415882661f7b9ceedbe09bc200e3',1,'IsoSpec::Marginal']]],
  ['isotopenumbers_1',['isotopeNumbers',['../class_iso_spec_1_1_iso.html#a7235f0afc56dccd13937791a630c45da',1,'IsoSpec::Iso']]]
];
