var searchData=
[
  ['marginal_0',['Marginal',['../class_iso_spec_1_1_marginal.html',1,'IsoSpec::Marginal'],['../class_iso_spec_1_1_marginal.html#a46be0c1cf5b169a54056997ba404183c',1,'IsoSpec::Marginal::Marginal(const double *_masses, const double *_probs, int _isotopeNo, int _atomCnt)'],['../class_iso_spec_1_1_marginal.html#ab90cce4ddb4fdd30a253d48c04a8e3ff',1,'IsoSpec::Marginal::Marginal(const Marginal &amp;other)'],['../class_iso_spec_1_1_marginal.html#ad60fff17fa2c68ea2cd7f183a635379e',1,'IsoSpec::Marginal::Marginal(Marginal &amp;&amp;other)']]],
  ['marginals_1',['marginals',['../class_iso_spec_1_1_iso.html#aea98a8331a2f8a1a6bbcace6124fcfae',1,'IsoSpec::Iso']]],
  ['marginaltrek_2',['MarginalTrek',['../class_iso_spec_1_1_marginal_trek.html',1,'IsoSpec::MarginalTrek'],['../class_iso_spec_1_1_marginal_trek.html#a83e70d522174e4e6724116941fd9c99e',1,'IsoSpec::MarginalTrek::MarginalTrek()']]],
  ['mass_3',['mass',['../class_iso_spec_1_1_iso_generator.html#a34173228ef73e272e2ff0ae6ce58092d',1,'IsoSpec::IsoGenerator::mass()'],['../class_iso_spec_1_1_iso_threshold_generator.html#ae2236accc7dc7a25a723e3c7317659b6',1,'IsoSpec::IsoThresholdGenerator::mass()'],['../class_iso_spec_1_1_iso_layered_generator.html#a212726383af7ce698606df6328b91031',1,'IsoSpec::IsoLayeredGenerator::mass()'],['../class_iso_spec_1_1_iso_stochastic_generator.html#a40312b1cef7d7c5eddf6abaa14143c57',1,'IsoSpec::IsoStochasticGenerator::mass()']]],
  ['mode_5fconf_4',['mode_conf',['../class_iso_spec_1_1_marginal.html#a0dd7f13cc69b32f6fbb45c04c597c893',1,'IsoSpec::Marginal']]],
  ['mode_5flprob_5',['mode_lprob',['../class_iso_spec_1_1_marginal.html#ad6be48488fcbb97b972cfe4b598d3419',1,'IsoSpec::Marginal']]]
];
