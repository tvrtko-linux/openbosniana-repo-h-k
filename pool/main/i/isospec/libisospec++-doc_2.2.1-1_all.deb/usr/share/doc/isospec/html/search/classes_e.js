var searchData=
[
  ['ws_5fmatch_5fres_0',['ws_match_res',['../structws__match__res.html',1,'']]]
];
