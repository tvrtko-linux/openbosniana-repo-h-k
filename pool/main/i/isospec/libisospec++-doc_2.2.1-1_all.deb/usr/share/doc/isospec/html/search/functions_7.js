var searchData=
[
  ['marginal_0',['Marginal',['../class_iso_spec_1_1_marginal.html#a46be0c1cf5b169a54056997ba404183c',1,'IsoSpec::Marginal::Marginal(const double *_masses, const double *_probs, int _isotopeNo, int _atomCnt)'],['../class_iso_spec_1_1_marginal.html#ab90cce4ddb4fdd30a253d48c04a8e3ff',1,'IsoSpec::Marginal::Marginal(const Marginal &amp;other)'],['../class_iso_spec_1_1_marginal.html#ad60fff17fa2c68ea2cd7f183a635379e',1,'IsoSpec::Marginal::Marginal(Marginal &amp;&amp;other)']]],
  ['marginaltrek_1',['MarginalTrek',['../class_iso_spec_1_1_marginal_trek.html#a83e70d522174e4e6724116941fd9c99e',1,'IsoSpec::MarginalTrek']]],
  ['mass_2',['mass',['../class_iso_spec_1_1_iso_generator.html#a34173228ef73e272e2ff0ae6ce58092d',1,'IsoSpec::IsoGenerator::mass()'],['../class_iso_spec_1_1_iso_threshold_generator.html#ae2236accc7dc7a25a723e3c7317659b6',1,'IsoSpec::IsoThresholdGenerator::mass()'],['../class_iso_spec_1_1_iso_layered_generator.html#a212726383af7ce698606df6328b91031',1,'IsoSpec::IsoLayeredGenerator::mass()'],['../class_iso_spec_1_1_iso_stochastic_generator.html#a40312b1cef7d7c5eddf6abaa14143c57',1,'IsoSpec::IsoStochasticGenerator::mass()']]]
];
