var searchData=
[
  ['loggamma_5fnominator_0',['loggamma_nominator',['../class_iso_spec_1_1_marginal.html#aa3fb5ed3a9b63a855d6270287aed7417',1,'IsoSpec::Marginal']]]
];
