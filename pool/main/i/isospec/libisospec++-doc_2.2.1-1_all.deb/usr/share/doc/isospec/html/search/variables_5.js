var searchData=
[
  ['marginals_0',['marginals',['../class_iso_spec_1_1_iso.html#aea98a8331a2f8a1a6bbcace6124fcfae',1,'IsoSpec::Iso']]],
  ['mode_5fconf_1',['mode_conf',['../class_iso_spec_1_1_marginal.html#a0dd7f13cc69b32f6fbb45c04c597c893',1,'IsoSpec::Marginal']]],
  ['mode_5flprob_2',['mode_lprob',['../class_iso_spec_1_1_marginal.html#ad6be48488fcbb97b972cfe4b598d3419',1,'IsoSpec::Marginal']]]
];
