var searchData=
[
  ['extend_0',['extend',['../class_iso_spec_1_1_layered_marginal.html#a773070d719e85fe813577a03b8f75128',1,'IsoSpec::LayeredMarginal']]]
];
