var searchData=
[
  ['fastgetmodelprob_0',['fastGetModeLProb',['../class_iso_spec_1_1_marginal.html#a656a7ee3de43029e3f96fe9cbf791213',1,'IsoSpec::Marginal']]],
  ['fixedenvelope_1',['FixedEnvelope',['../class_iso_spec_1_1_fixed_envelope.html',1,'IsoSpec']]],
  ['fromfasta_2',['FromFASTA',['../class_iso_spec_1_1_iso.html#a72c641e984e7b3b284bc1280f4d56bec',1,'IsoSpec::Iso::FromFASTA(const char *fasta, bool use_nominal_masses=false, bool add_water=true)'],['../class_iso_spec_1_1_iso.html#a4b03504c247c80eadbd509cbf995ede9',1,'IsoSpec::Iso::FromFASTA(const std::string &amp;fasta, bool use_nominal_masses=false, bool add_water=true)']]]
];
