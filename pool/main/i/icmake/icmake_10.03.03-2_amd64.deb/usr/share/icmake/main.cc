#include "main.ih"

int main(int argc, char **argv)
try
{
}
catch (...)
{
    return 1;
}
