SELECT plan(0);
CREATE TABLE icinga_objects (
    object_id numeric DEFAULT '0'::numeric,
    objecttype_id smallint DEFAULT '1'::smallint
);
