CREATE TABLE icinga_outofsla_periods (
    timeperiod_object_id numeric NOT NULL,
    start_time timestamp without time zone NOT NULL,
    end_time timestamp without time zone NOT NULL
);
