#!/usr/bin/env python2
# -*- coding: utf-8 -*-

from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord

from iss import download
from iss.util import cleanup

import pytest


def download_to_fasta():
    output_file_prefix = 'data/.test'
    ftp_url = 'ftp://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/000/737/615/GCF_000737615.1_ASM73761v1/GCF_000737615.1_ASM73761v1_genomic.fna.gz'
    download.assembly_to_fasta(ftp_url, 'data/test_download.fasta')
    cleanup(['data/test_download.fasta'])

@pytest.mark.skip
def test_ncbi():
    output_file_prefix = 'data/.test'
    genome_list = download.ncbi('bacteria', 2, 'data/test_download.fasta')
    cleanup(['data/test_download.fasta'])
