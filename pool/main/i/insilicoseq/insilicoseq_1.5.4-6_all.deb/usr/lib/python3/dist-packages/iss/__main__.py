#!/usr/bin/env python
# -*- coding: utf-8 -*-

from iss.app import main
main()
