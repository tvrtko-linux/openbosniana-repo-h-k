<?php
// Icinga Reporting | (c) 2018 Icinga GmbH | GPLv2

namespace Icinga\Module\Reporting;

class ReportRow
{
    use Dimensions;
    use Values;
}
