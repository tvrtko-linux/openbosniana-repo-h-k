-- Options related to the interface implementation.

options.cache = true
options.charset = ''
options.close = false
options.info = true
options.limit = 0
options.range = math.huge
