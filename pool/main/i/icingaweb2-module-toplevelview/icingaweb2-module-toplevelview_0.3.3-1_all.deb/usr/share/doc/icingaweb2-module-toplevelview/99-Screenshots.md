Screenshots
===========

Tile view with lots of objects:

![](screenshots/tiles.png)

Tile and Tree view with problems:

![](screenshots/tiles-tree-problems.png)

Tree view with no problems (all collapsed):

![](screenshots/tiles-tree-noproblems.png)

Tree view with no problems (expanded by user):

![](screenshots/tiles-tree-noproblems-expanded.png)

Tree view problems on a hostgroup, and the hostgroup details:

![](screenshots/tree-hostgroup.png)

Tree view problems on services, and the service details:

![](screenshots/tree-service.png)

Overview over all defined views, and the open editor:

![](screenshots/overview-and-editor.png)
