#pragma once

// Choose one of the following four options.

// Other options.

// Define to include debugging output in carve.
// #define CARVE_DEBUG

// Write intermediate debugging info in .ply format.
// #define CARVE_DEBUG_WRITE_PLY_DATA

// Define to make carve use exact predicates where available.
// #cmakedefine CARVE_USE_EXACT_PREDICATES
