This is IceS 2
--------------

This is a release of IceS 2.0.3

It's the primary source client for Icecast 2.
It has proven to stable and well featured.

Documentation is in the `doc` subdirectory, and some sample configuration
files exist in the `conf` subdirectory.

To build and install, run

    ./configure
    make
    make install

You _will_ need to edit the config file you choose to use before running
this application.

For help, email us at icecast@xiph.org, icecast-dev@xiph.org, or find us
on IRC at irc.freenode.net, in [#icecast][1].

[1]: https://webchat.freenode.net/?channels=%23icecast
