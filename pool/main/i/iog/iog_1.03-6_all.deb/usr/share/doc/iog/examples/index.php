<html>
<head></head>
<body>
<?

// Index script for IOG (http://www.dynw.com/iog/) contributed by
// Preston Carter [preston@ashenet.net]


echo "<b>Click on host to view transfer stats</b><br><br>";

$directory = "./";
$handle = opendir('.');
closedir($handle);
$handle=opendir('.');
$counter = 0;
while ($file = readdir($handle)) {
// Filter by extension type
$the_type = strrchr($file, "."); 
$allow_file = eregi("html",$the_type);
if ($file != "." and $file != ".." and $allow_file) {
 // Get name without extension
 if ($a=strpos($file,'.')) {
     $ext=substr($file,$a); // . inside
     $file=substr($file,0,$a);
 $myfiles[$counter] = $file;
 // Test for presence of -days, -months
 $ok=(strpos($file,'-month')===FALSE);
 $ok=($ok AND (strpos($file,'-day')===FALSE));
 // if ok, memorize and print
 if ($ok) {
   echo "<a href=\"$directory$file$ext\">$file</a><br>";
   $counter++;
   }
  }
 }
}
closedir($handle);
?>

</body>
</html>

