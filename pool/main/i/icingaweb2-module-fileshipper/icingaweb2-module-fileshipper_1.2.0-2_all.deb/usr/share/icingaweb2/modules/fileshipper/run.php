<?php

$this->provideHook('director/ShipConfigFiles');
$this->provideHook('director/ImportSource');
