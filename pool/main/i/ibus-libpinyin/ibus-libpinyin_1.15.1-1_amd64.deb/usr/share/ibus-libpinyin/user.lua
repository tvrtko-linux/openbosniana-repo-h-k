-- encoding: UTF-8

-- Note: the changes in user.lua script may take effect only after ime restart.