package CType::Native;

use 5.6.0;
use strict;
use warnings;

use bigint;
use CType::Fundamental qw/register_type_attrs/;

register_type_attrs('char', 8, 8, 1, -128, 127);
register_type_attrs('signed char', 8, 8, 1, -128, 127);
register_type_attrs('unsigned char', 8, 8, 0, 0, 255);
register_type_attrs('short', 16, 16, 1, -32768, 32767);
register_type_attrs('unsigned short', 16, 16, 0, 0, 65535);
register_type_attrs('int', 32, 32, 1, -2147483648, 2147483647);
register_type_attrs('unsigned', 32, 32, 0, 0, -1);
register_type_attrs('long', 64, 64, 1, -9223372036854775808, 9223372036854775807);
register_type_attrs('unsigned long', 64, 64, 0, 0, 18446744073709551615);
register_type_attrs('long long', 64, 64, 1, -9223372036854775808, 9223372036854775807);
register_type_attrs('unsigned long long', 64, 64, 0, 0, 18446744073709551615);
register_type_attrs('float', 32, 32, 1, 0, 0);
register_type_attrs('double', 64, 64, 1, 0, 0);
register_type_attrs('long double', 128, 128, 1, 0, 0);
register_type_attrs('_Bool', 8, 8, 0, 0, 0);
register_type_attrs('void *', 64, 64, 0, 0, 0);
register_type_attrs('enum null_enum', 32, 32, 0, 0, 0);

1;
