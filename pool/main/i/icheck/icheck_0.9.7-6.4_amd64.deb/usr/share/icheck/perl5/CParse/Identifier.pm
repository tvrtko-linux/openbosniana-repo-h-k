package CParse::Identifier;

use 5.6.0;
use strict;
use warnings;

use CExpr::Ref;

sub new
  {
    my $this = shift;
    my $class = ref($this) || $this;

    my $name = shift;

    my $self = {name => $name,
               };
    bless $self, $class;
    return $self;
  }

sub name
  {
    my $self = shift;
    return $self->{name};
  }

sub dump_c
  {
    my $self = shift;

    return $self->name;
  }

sub get_identifier
  {
    my $self = shift;
    return $self->name;
  }

sub get_type
  {
    my $self = shift;

    my $namespace = shift;
    my $base_type = shift;
    my $attributes = shift;

    return $base_type;
  }

sub get_expr
  {
    my $self = shift;

    my $namespace = shift;

    return new CExpr::Ref $self->name;
  }

1;
