package CParse::Declarator::Direct;

use 5.6.0;
use strict;
use warnings;

sub new
  {
    my $this = shift;
    my $class = ref($this) || $this;

    my $declarator = shift;
    my $suffixes = shift;

    foreach my $suffix (@$suffixes)
      {
        $suffix->set_declarator($declarator);
        $declarator = $suffix;
      }

    return $declarator;
  }

1;
