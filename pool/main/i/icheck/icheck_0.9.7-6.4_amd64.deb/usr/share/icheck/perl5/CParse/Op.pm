package CParse::Op;

use 5.6.0;
use strict;
use warnings;

sub new
  {
    my $this = shift;

    my $list = shift;
    my $class = shift;

    eval "use $class;";
    while (scalar @$list > 1)
      {
        my $left = shift @$list;
        my $op = shift @$list;
        my $right = shift @$list;

        unless (defined $right)
          {
            die;
          }

        my $new = $class->new($left, $right, $op);
        unshift @$list, $new;
      }

    return $list->[0];
  }

1;
