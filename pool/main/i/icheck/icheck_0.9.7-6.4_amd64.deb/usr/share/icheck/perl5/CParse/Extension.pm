package CParse::Extension;

use 5.6.0;
use strict;
use warnings;

sub new
  {
    my $this = shift;
    my $class = ref($this) || $this;
    my $self = {
               };
    bless $self, $class;
    return $self;
  }

sub dump_c
  {
    my $self = shift;
    return "";
  }

1;
