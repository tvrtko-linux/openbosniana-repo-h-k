package CParse::StorageClass;

use 5.6.0;
use strict;
use warnings;

sub new
  {
    my $this = shift;
    my $class = ref($this) || $this;

    my $sclass = shift;

    my $self = {class => $sclass,
               };
    bless $self, $class;
    return $self;
  }

sub class
  {
    my $self = shift;
    return $self->{class};
  }

sub dump_c
  {
    my $self = shift;

    return $self->class;
  }

1;
