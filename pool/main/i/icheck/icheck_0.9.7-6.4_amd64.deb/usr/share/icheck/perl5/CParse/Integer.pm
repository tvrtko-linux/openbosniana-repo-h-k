package CParse::Integer;

use 5.6.0;
use strict;
use warnings;

use CExpr::Integer;

sub new
  {
    my $this = shift;
    my $class = ref($this) || $this;

    my $value = shift;

    my $self = {value => $value,
               };
    bless $self, $class;
    return $self;
  }

sub dump_c
  {
    my $self = shift;

    return $self->{value};
  }

sub get_expr
  {
    my $self = shift;

    my $namespace = shift;

    return new CExpr::Integer $self->{value};
  }

1;
