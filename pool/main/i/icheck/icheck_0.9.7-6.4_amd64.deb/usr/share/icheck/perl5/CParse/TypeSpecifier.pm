package CParse::TypeSpecifier;

use 5.6.0;
use strict;
use warnings;

sub new
  {
    my $this = shift;
    my $class = ref($this) || $this;

    my $name = shift;

    my $self = {name => $name,
               };
    bless $self, $class;
    return $self;
  }

sub name
  {
    my $self = shift;
    return $self->{name};
  }

sub dump_c
  {
    my $self = shift;

    return $self->{name};
  }

1;
