package CParse::Parser::Token::Identifier;

use 5.6.0;
use strict;
use warnings;

use CParse::Identifier;

sub new
  {
    my $this = shift;
    my $class = ref($this) || $this;

    my $string = shift;
    my $line = shift;
    my $pos = shift;

    my $self = {string => $string,
                line => $line,
                pos => $pos,
               };
    bless $self, $class;
    return $self;
  }

sub line
  {
    my $self = shift;
    return $self->{line};
  }

sub pos
  {
    my $self = shift;
    return $self->{pos};
  }

sub string
  {
    my $self = shift;
    return $self->{string};
  }

sub dump_c
  {
    my $self = shift;

    return $self->{string};
  }

sub process
  {
    my $self = shift;

    return new CParse::Identifier $self->{string};
  }

1;
