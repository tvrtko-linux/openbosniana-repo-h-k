package CParse::Op::Postfix;

use 5.6.0;
use strict;
use warnings;

sub new
  {
    my $this = shift;
    my $class = ref($this) || $this;

    my $prefix = shift;
    my $suffixes = shift;

    foreach my $suffix (@$suffixes)
      {
        $suffix->set_prefix($prefix);
        $prefix = $suffix;
      }

    return $prefix;
  }

1;
