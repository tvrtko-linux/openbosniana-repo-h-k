package CExpr::Integer;

use 5.6.0;
use strict;
use warnings;

use CExpr;

our @ISA = qw/CExpr/;

sub new
  {
    my $this = shift;
    my $class = ref($this) || $this;

    my $value = shift;

    my $self = {value => $value,
               };
    bless $self, $class;
    return $self;
  }

sub dump_c
  {
    my $self = shift;

    return $self->{value};
  }

sub compute
  {
    my $self = shift;
    return $self->{value};
  }

sub get_refs
  {
    my $self = shift;
    return ();
  }

sub layout
  {
  }

1;
