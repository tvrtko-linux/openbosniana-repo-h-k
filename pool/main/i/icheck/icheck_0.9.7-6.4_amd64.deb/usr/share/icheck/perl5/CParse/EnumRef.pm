package CParse::EnumRef;

use 5.6.0;
use strict;
use warnings;

sub new
  {
    my $this = shift;
    my $class = ref($this) || $this;

    my $tag = shift;

    my $self = {tag => $tag,
               };
    bless $self, $class;
    return $self;
  }

sub dump_c
  {
    my $self = shift;

    my $tag = $self->{tag};

    return "enum $tag";
  }

sub get_type
  {
    my $self = shift;
    my $namespace = shift;

    return new CType::Ref 'enum', $self->{tag};
  }

1;
