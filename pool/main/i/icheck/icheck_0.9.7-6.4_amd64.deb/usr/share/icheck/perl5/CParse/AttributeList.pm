package CParse::AttributeList;

use 5.6.0;
use strict;
use warnings;

sub new
  {
    my $this = shift;
    my $class = ref($this) || $this;
    my $attributes = shift;
    my $self = {attributes => $attributes,
               };
    bless $self, $class;
    return $self;
  }

sub attributes
  {
    my $self = shift;
    return @{$self->{attributes}};
  }

sub dump_c
  {
    my $self = shift;

    return "__attribute__((" . join(', ', map {$_->dump_c} @{$self->{attributes}}) . "))";
  }

1;
