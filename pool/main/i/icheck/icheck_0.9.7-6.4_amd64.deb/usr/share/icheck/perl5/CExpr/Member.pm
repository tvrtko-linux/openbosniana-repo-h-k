package CExpr::Member;

use 5.6.0;
use strict;
use warnings;

use CExpr;

our @ISA = qw/CExpr/;

sub new
  {
    my $this = shift;
    my $class = ref($this) || $this;

    my $arg = shift;
    my $member = shift;

    my $self = {arg => $arg,
                member => $member,
               };
    bless $self, $class;
    return $self;
  }

sub dump_c
  {
    my $self = shift;

    my $arg = $self->{arg}->dump_c;
    my $member = $self->{member};

    return "($arg).$member";
  }

sub get_refs
  {
    my $self = shift;
    return ($self->{arg}->get_refs);
  }

sub layout
  {
    my $self = shift;
    my $accept_incomplete = shift;
    my $namespace = shift;
    $self->{arg}->layout($accept_incomplete, $namespace);
  }

1;
