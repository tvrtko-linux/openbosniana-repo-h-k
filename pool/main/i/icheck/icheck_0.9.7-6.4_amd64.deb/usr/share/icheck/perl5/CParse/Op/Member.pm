package CParse::Op::Member;

use 5.6.0;
use strict;
use warnings;

use CParse::Op;

use CExpr::Member;

our @ISA = qw/CParse::Op/;

sub new
  {
    my $this = shift;
    my $class = ref($this) || $this;

    my $member = shift;

    my $self = {member => $member,
               };
    bless $self, $class;
    return $self;
  }

sub set_prefix
  {
    my $self = shift;
    $self->{arg} = shift;
  }

sub args
  {
    my $self = shift;
    return ($self->{arg});
  }

sub dump_c
  {
    my $self = shift;
    my $arg = $self->{arg}->dump_c;
    my $member = $self->{member};

    return "($arg.$member)";
  }

sub get_expr
  {
    my $self = shift;
    my $namespace = shift;

    my $arg = $self->{arg}->get_expr($namespace);

    return new CExpr::Member $arg, $self->{member};
  }

1;
