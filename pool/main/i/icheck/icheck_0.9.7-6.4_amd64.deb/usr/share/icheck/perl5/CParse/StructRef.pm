package CParse::StructRef;

use 5.6.0;
use strict;
use warnings;

use CType::Ref;

sub new
  {
    my $this = shift;
    my $class = ref($this) || $this;

    my $tag = shift;

    my $self = {tag => $tag,
               };
    bless $self, $class;
    return $self;
  }

sub dump_c
  {
    my $self = shift;

    my $tag = $self->{tag};

    return "struct $tag";
  }

sub get_type
  {
    my $self = shift;
    my $namespace = shift;

    return new CType::Ref 'struct', $self->{tag};
  }

1;
