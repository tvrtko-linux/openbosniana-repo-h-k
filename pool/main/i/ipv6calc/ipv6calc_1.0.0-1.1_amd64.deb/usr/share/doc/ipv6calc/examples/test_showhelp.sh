#!/bin/sh

# $Id: 1a14a4f8073d785230cac8446be68c612bdfdcd4 $

echo "==Standard"
./ipv6calc -?

echo "==In"
./ipv6calc --in -?

echo "==Out"
./ipv6calc --out -?

echo "==Action"
./ipv6calc --action -?
