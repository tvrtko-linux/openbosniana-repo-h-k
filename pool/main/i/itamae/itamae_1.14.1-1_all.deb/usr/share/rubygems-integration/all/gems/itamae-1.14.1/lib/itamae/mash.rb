require 'hashie'

module Itamae
  class Mash < Hashie::Mash
    disable_warnings
  end
end
