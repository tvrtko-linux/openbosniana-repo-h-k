module Itamae
  VERSION = "1.14.1"
end
