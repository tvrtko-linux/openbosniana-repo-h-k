
#ifndef strlist_h
#define strlist_h

#include <OS/list.h>
#include <OS/string.h>

declareList(StringList, String)

#endif
