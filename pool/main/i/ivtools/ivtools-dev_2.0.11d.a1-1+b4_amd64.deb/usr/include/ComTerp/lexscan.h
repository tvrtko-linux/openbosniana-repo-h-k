/*
 * LexScan was moved to the Attribute library so it could be utilized 
 * without the ComTerp system.
 */

#include <Attribute/lexscan.h>
