/*
 * ComModule has been moved to the Attribute library so that
 * its derived classes (i.e. LexScan) can be utilized there
 */

#include <Attribute/commodule.h>
