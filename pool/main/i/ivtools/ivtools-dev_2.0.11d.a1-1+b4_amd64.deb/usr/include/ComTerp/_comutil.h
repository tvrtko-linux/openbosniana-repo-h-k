#ifndef __comutil2_h
#define __comutil2_h
// extern "C" {
#include <ComUtil/comutil.h>
// }
#endif /* !defined(__comutil2_h) */
