#ifndef _classid_h
#define _classid_h
#include <Attribute/_comutil.h>
#endif /* !defined(_classid_h) */
