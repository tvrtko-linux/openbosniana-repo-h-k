#ifndef __comterp_h
#define __comterp_h
// extern "C" {
#include <ComUtil/comterp.h>
// }
#endif /* !defined(__comterp_h) */
