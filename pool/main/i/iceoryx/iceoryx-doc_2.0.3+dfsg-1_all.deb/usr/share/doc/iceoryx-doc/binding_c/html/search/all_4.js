var searchData=
[
  ['offeroncreate_0',['offerOnCreate',['../structiox__pub__options__t.html#af000f85e36963c1d4b71e18bd842b767',1,'iox_pub_options_t::offerOnCreate()'],['../structiox__server__options__t.html#aeb23048c2b5780c231be9ad87db794ca',1,'iox_server_options_t::offerOnCreate()']]]
];
