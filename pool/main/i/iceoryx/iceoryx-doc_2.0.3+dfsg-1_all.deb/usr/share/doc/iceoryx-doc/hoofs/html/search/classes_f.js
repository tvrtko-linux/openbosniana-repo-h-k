var searchData=
[
  ['timer_0',['Timer',['../classiox_1_1posix_1_1Timer.html',1,'iox::posix']]],
  ['truncatetocapacity_5ft_1',['TruncateToCapacity_t',['../structiox_1_1cxx_1_1TruncateToCapacity__t.html',1,'iox::cxx']]]
];
