var searchData=
[
  ['queuecapacity_0',['queueCapacity',['../structiox__sub__options__t.html#aaba3f20890904db2304c0cc6e5c2a5c3',1,'iox_sub_options_t']]],
  ['queuefullpolicy_1',['queueFullPolicy',['../structiox__sub__options__t.html#a1329984210044d4d08df9d3558f10eb5',1,'iox_sub_options_t']]]
];
