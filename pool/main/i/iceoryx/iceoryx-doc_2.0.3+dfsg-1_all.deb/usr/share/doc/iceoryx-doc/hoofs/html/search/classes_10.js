var searchData=
[
  ['unique_5fptr_0',['unique_ptr',['../classiox_1_1cxx_1_1unique__ptr.html',1,'iox::cxx']]]
];
