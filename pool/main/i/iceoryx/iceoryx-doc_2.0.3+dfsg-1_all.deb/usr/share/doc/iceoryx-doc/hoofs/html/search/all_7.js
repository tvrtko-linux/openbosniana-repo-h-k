var searchData=
[
  ['has_5ferror_0',['has_error',['../classiox_1_1cxx_1_1expected_3_01ErrorType_01_4.html#aa091885bca74d173de11fbdcdc15de5e',1,'iox::cxx::expected&lt; ErrorType &gt;::has_error()'],['../classiox_1_1cxx_1_1expected_3_01ValueType_00_01ErrorType_01_4.html#adf870a65848485c56af05fb4c2be6576',1,'iox::cxx::expected&lt; ValueType, ErrorType &gt;::has_error()']]],
  ['has_5fvalue_1',['has_value',['../classiox_1_1cxx_1_1optional.html#a6282b0d757b3c3b99b747614807f5002',1,'iox::cxx::optional']]],
  ['haserror_2',['hasError',['../classiox_1_1posix_1_1Timer.html#a0bb8216de4aebc75355eeb1085e45fd2',1,'iox::posix::Timer']]],
  ['hasexpired_3',['hasExpired',['../classiox_1_1cxx_1_1DeadlineTimer.html#a0af57395b1a91767e40977e44613d75d',1,'iox::cxx::DeadlineTimer']]],
  ['hasinstance_4',['hasInstance',['../classiox_1_1cxx_1_1PoorMansHeap.html#ad2dc067846d3a372a9871bf38c0a6350',1,'iox::cxx::PoorMansHeap']]]
];
