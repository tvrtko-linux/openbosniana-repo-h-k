var searchData=
[
  ['namedpipe_0',['NamedPipe',['../classiox_1_1posix_1_1NamedPipe.html',1,'iox::posix::NamedPipe'],['../classiox_1_1posix_1_1NamedPipe.html#a242ef1e8d09c1be77239ee4130aaa81f',1,'iox::posix::NamedPipe::NamedPipe()']]],
  ['newinstance_1',['newInstance',['../classiox_1_1cxx_1_1PoorMansHeap.html#ad3824e73edd0b5a300eb8fa44c8baa03',1,'iox::cxx::PoorMansHeap']]],
  ['newtype_2',['NewType',['../classiox_1_1cxx_1_1NewType.html',1,'iox::cxx::NewType&lt; T, Policies &gt;'],['../classiox_1_1cxx_1_1NewType.html#ac8968c5d10a9afd75405dd27663401f2',1,'iox::cxx::NewType::NewType() noexcept'],['../classiox_1_1cxx_1_1NewType.html#a45ea4090d81f68a988b7cac33efe4829',1,'iox::cxx::NewType::NewType(const T &amp;rhs) noexcept'],['../classiox_1_1cxx_1_1NewType.html#ab62b4ba36c11ae14aa4bdb3c985a9007',1,'iox::cxx::NewType::NewType(const NewType &amp;rhs) noexcept'],['../classiox_1_1cxx_1_1NewType.html#abaa7e49a7b4d2e41e38dae7c291fe3d2',1,'iox::cxx::NewType::NewType(NewType &amp;&amp;rhs) noexcept']]],
  ['not_5fnull_3',['not_null',['../structiox_1_1cxx_1_1not__null.html',1,'iox::cxx']]],
  ['now_4',['now',['../classiox_1_1posix_1_1Timer.html#a902f23f37e9c1354e235a40b5e9918bc',1,'iox::posix::Timer']]],
  ['nullopt_5ft_5',['nullopt_t',['../structiox_1_1cxx_1_1nullopt__t.html',1,'iox::cxx']]]
];
