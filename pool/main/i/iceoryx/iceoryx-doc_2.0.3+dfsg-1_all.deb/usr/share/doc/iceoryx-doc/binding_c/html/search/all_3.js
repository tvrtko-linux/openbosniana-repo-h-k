var searchData=
[
  ['nodename_0',['nodeName',['../structiox__client__options__t.html#ab4ab9a6672b40866860b3208e7b3eed3',1,'iox_client_options_t::nodeName()'],['../structiox__pub__options__t.html#a051243c64aac57b38846701304f2e80e',1,'iox_pub_options_t::nodeName()'],['../structiox__server__options__t.html#a6d1e11878e5ca6eae6c873425558c401',1,'iox_server_options_t::nodeName()'],['../structiox__sub__options__t.html#accfecc9798d076b64045f4cef910a61d',1,'iox_sub_options_t::nodeName()']]]
];
