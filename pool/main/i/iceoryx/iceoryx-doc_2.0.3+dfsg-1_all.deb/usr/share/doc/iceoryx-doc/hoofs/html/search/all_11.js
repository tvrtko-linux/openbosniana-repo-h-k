var searchData=
[
  ['unique_5fptr_0',['unique_ptr',['../classiox_1_1cxx_1_1unique__ptr.html',1,'iox::cxx::unique_ptr&lt; T &gt;'],['../classiox_1_1cxx_1_1unique__ptr.html#a4a8ae8e219927240352782dfdf1dbfe9',1,'iox::cxx::unique_ptr::unique_ptr(function_ref&lt; void(T *)&gt; &amp;&amp;deleter) noexcept'],['../classiox_1_1cxx_1_1unique__ptr.html#a152f0aa4760e8dffd590fd945ed42e2e',1,'iox::cxx::unique_ptr::unique_ptr(T *const ptr, function_ref&lt; void(T *)&gt; &amp;&amp;deleter) noexcept']]],
  ['unlinkifexists_1',['unlinkIfExists',['../classiox_1_1posix_1_1NamedPipe.html#a4150fdcc3970fb1a0574f68eec2cb8d4',1,'iox::posix::NamedPipe']]],
  ['unsafe_5fappend_2',['unsafe_append',['../classiox_1_1cxx_1_1string.html#a65d338071a8f44644f3a8180cac0e5be',1,'iox::cxx::string']]],
  ['unsafe_5fassign_3',['unsafe_assign',['../classiox_1_1cxx_1_1string.html#a6daa82912e4c25aff5332349830ab78c',1,'iox::cxx::string::unsafe_assign(const char *const str) noexcept'],['../classiox_1_1cxx_1_1string.html#a8ba014888a073548c4963254eb9b9a5b',1,'iox::cxx::string::unsafe_assign(const std::string &amp;str) noexcept']]]
];
