var searchData=
[
  ['variant_0',['variant',['../classiox_1_1cxx_1_1variant.html',1,'iox::cxx']]],
  ['variant_3c_20concurrent_3a_3afifo_3c_20valuetype_2c_20capacity_20_3e_2c_20concurrent_3a_3asofi_3c_20valuetype_2c_20capacity_20_3e_2c_20concurrent_3a_3aresizeablelockfreequeue_3c_20valuetype_2c_20capacity_20_3e_2c_20concurrent_3a_3aresizeablelockfreequeue_3c_20valuetype_2c_20capacity_20_3e_20_3e_1',['variant&lt; concurrent::FiFo&lt; ValueType, Capacity &gt;, concurrent::SoFi&lt; ValueType, Capacity &gt;, concurrent::ResizeableLockFreeQueue&lt; ValueType, Capacity &gt;, concurrent::ResizeableLockFreeQueue&lt; ValueType, Capacity &gt; &gt;',['../classiox_1_1cxx_1_1variant.html',1,'iox::cxx']]],
  ['variant_3c_20errortype_20_3e_2',['variant&lt; ErrorType &gt;',['../classiox_1_1cxx_1_1variant.html',1,'iox::cxx']]],
  ['variant_3c_20valuetype_2c_20errortype_20_3e_3',['variant&lt; ValueType, ErrorType &gt;',['../classiox_1_1cxx_1_1variant.html',1,'iox::cxx']]],
  ['variantqueue_4',['VariantQueue',['../classiox_1_1cxx_1_1VariantQueue.html',1,'iox::cxx']]],
  ['vector_5',['vector',['../classiox_1_1cxx_1_1vector.html',1,'iox::cxx']]],
  ['vector_3c_20bufferindex_2c_20maxcapacity_20_3e_6',['vector&lt; BufferIndex, MaxCapacity &gt;',['../classiox_1_1cxx_1_1vector.html',1,'iox::cxx']]]
];
