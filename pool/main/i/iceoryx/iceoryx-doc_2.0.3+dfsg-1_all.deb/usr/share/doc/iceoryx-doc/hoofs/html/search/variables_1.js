var searchData=
[
  ['value_0',['value',['../structiox_1_1posix_1_1PosixCallResult.html#aad5a9693d3ccaf1861d9382317ba7a39',1,'iox::posix::PosixCallResult']]]
];
