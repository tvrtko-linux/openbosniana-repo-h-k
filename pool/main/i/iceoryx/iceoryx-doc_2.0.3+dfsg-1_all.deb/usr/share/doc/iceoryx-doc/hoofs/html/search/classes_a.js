var searchData=
[
  ['namedpipe_0',['NamedPipe',['../classiox_1_1posix_1_1NamedPipe.html',1,'iox::posix']]],
  ['newtype_1',['NewType',['../classiox_1_1cxx_1_1NewType.html',1,'iox::cxx']]],
  ['not_5fnull_2',['not_null',['../structiox_1_1cxx_1_1not__null.html',1,'iox::cxx']]],
  ['nullopt_5ft_3',['nullopt_t',['../structiox_1_1cxx_1_1nullopt__t.html',1,'iox::cxx']]]
];
