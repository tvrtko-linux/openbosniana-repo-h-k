var searchData=
[
  ['deserialization_5ffailed_0',['DESERIALIZATION_FAILED',['../classiox_1_1cxx_1_1Serialization.html#a3f0d4596a26b451d67ab599b9758fcd9ad9879aa18c4eb0c077ba32c4096c4901',1,'iox::cxx::Serialization']]]
];
