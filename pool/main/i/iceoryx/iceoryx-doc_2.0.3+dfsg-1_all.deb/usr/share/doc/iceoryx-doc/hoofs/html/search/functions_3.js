var searchData=
[
  ['data_0',['data',['../classiox_1_1cxx_1_1vector.html#a18e0103883d9c918cef19f7906b32328',1,'iox::cxx::vector::data() noexcept'],['../classiox_1_1cxx_1_1vector.html#aee4e7d7bb6f17fd08c264de6cf84e4eb',1,'iox::cxx::vector::data() const noexcept']]],
  ['deadlinetimer_1',['DeadlineTimer',['../classiox_1_1cxx_1_1DeadlineTimer.html#a704d5c09572a6fc6c61fc07550e7f3f7',1,'iox::cxx::DeadlineTimer']]],
  ['deleteinstance_2',['deleteInstance',['../classiox_1_1cxx_1_1PoorMansHeap.html#a6c87aa771f669421d57700b1f17e7a1d',1,'iox::cxx::PoorMansHeap']]],
  ['destroy_3',['destroy',['../classiox_1_1posix_1_1NamedPipe.html#a96ebb3b7491df82e75b56ca2ead2a3a8',1,'iox::posix::NamedPipe']]]
];
