var indexSectionsWithContent =
{
  0: "chinoqrs",
  1: "i",
  2: "chinoqrs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Variables"
};

