var searchData=
[
  ['value_5ftype_0',['value_type',['../classiox_1_1cxx_1_1NewType.html#a36110d2cc95837b008153591d6ff866c',1,'iox::cxx::NewType']]]
];
