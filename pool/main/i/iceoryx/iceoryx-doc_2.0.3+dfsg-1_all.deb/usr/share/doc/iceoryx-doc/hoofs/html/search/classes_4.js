var searchData=
[
  ['error_0',['error',['../structiox_1_1cxx_1_1error.html',1,'iox::cxx']]],
  ['errorhandler_1',['ErrorHandler',['../classiox_1_1ErrorHandler.html',1,'iox']]],
  ['expected_3c_20errortype_20_3e_2',['expected&lt; ErrorType &gt;',['../classiox_1_1cxx_1_1expected_3_01ErrorType_01_4.html',1,'iox::cxx']]],
  ['expected_3c_20valuetype_2c_20errortype_20_3e_3',['expected&lt; ValueType, ErrorType &gt;',['../classiox_1_1cxx_1_1expected_3_01ValueType_00_01ErrorType_01_4.html',1,'iox::cxx']]],
  ['expected_3c_20void_2c_20errortype_20_3e_4',['expected&lt; void, ErrorType &gt;',['../classiox_1_1cxx_1_1expected_3_01void_00_01ErrorType_01_4.html',1,'iox::cxx']]]
];
