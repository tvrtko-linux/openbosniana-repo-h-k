var searchData=
[
  ['thistype_0',['ThisType',['../classiox_1_1cxx_1_1NewType.html#ab80165278b15b47ed1cfd9ad0a22baa3',1,'iox::cxx::NewType']]],
  ['type_5ft_1',['Type_t',['../structiox_1_1cxx_1_1BestFittingType.html#af2cfda9d2a4b9d13c0dff54ab0fdc844',1,'iox::cxx::BestFittingType']]]
];
