var searchData=
[
  ['historycapacity_0',['historyCapacity',['../structiox__pub__options__t.html#af95ab9664e4359acf517297e7ec511fb',1,'iox_pub_options_t']]],
  ['historyrequest_1',['historyRequest',['../structiox__sub__options__t.html#a855bef6f930f03078207ab49e9da591d',1,'iox_sub_options_t']]]
];
