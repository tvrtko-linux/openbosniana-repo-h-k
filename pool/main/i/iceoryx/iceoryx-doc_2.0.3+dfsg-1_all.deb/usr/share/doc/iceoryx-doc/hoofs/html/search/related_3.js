var searchData=
[
  ['registersignalhandler_0',['registerSignalHandler',['../classiox_1_1posix_1_1SignalGuard.html#ac0c2b50164900847b3dc69067c383c54',1,'iox::posix::SignalGuard']]]
];
