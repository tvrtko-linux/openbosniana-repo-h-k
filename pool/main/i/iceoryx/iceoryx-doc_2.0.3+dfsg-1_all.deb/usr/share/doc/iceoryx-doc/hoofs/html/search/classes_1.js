var searchData=
[
  ['bestfittingtype_0',['BestFittingType',['../structiox_1_1cxx_1_1BestFittingType.html',1,'iox::cxx']]]
];
