var searchData=
[
  ['clienttooslowpolicy_0',['clientTooSlowPolicy',['../structiox__server__options__t.html#ab25630af0c0931a0886913614c08b0a3',1,'iox_server_options_t']]],
  ['connectoncreate_1',['connectOnCreate',['../structiox__client__options__t.html#ae57383f3e45f18894d745292b9ce6270',1,'iox_client_options_t']]]
];
