var searchData=
[
  ['errnum_0',['errnum',['../structiox_1_1posix_1_1PosixCallResult.html#a687434fa3cf2d11efa687b11d086afb5',1,'iox::posix::PosixCallResult']]]
];
