prefix = "/usr"
datadir = "/usr/share"
localedir = "/usr/share/locale"
