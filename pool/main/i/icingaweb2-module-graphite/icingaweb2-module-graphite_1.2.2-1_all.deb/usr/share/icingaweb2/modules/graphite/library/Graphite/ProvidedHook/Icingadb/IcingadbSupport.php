<?php

namespace Icinga\Module\Graphite\ProvidedHook\Icingadb;

use Icinga\Module\Icingadb\Hook\IcingadbSupportHook;

class IcingadbSupport extends IcingadbSupportHook
{
}
