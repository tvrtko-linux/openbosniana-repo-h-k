var searchData=
[
  ['k_0',['k',['../structsnow3g__key__schedule__s.html#ae0ca8cd2581836c0297b34eea1effb12',1,'snow3g_key_schedule_s']]],
  ['kasumi_5finit_5ff8_5fkey_5fsched_1',['kasumi_init_f8_key_sched',['../structIMB__MGR.html#ab32d67f27cb6f06980080e09db133b24',1,'IMB_MGR']]],
  ['kasumi_5finit_5ff9_5fkey_5fsched_2',['kasumi_init_f9_key_sched',['../structIMB__MGR.html#a58ad87104b08ba5b56fc65928677a639',1,'IMB_MGR']]],
  ['kasumi_5fkey_5fsched_5fsize_3',['kasumi_key_sched_size',['../structIMB__MGR.html#abd0c855a3e43df48f5f21686a095f358',1,'IMB_MGR']]],
  ['kasumi_5fuia1_4',['KASUMI_UIA1',['../structIMB__JOB.html#a11f452fba9d5cad2b2cdb929b7f244e9',1,'IMB_JOB']]],
  ['key_5flen_5fin_5fbytes_5',['key_len_in_bytes',['../structIMB__JOB.html#abdd8a58a37e8d2daa1c2d333b826a65c',1,'IMB_JOB']]],
  ['keyexp_5f128_6',['keyexp_128',['../structIMB__MGR.html#a7c97c5361b90abe325db55530b6f198e',1,'IMB_MGR']]],
  ['keyexp_5f192_7',['keyexp_192',['../structIMB__MGR.html#a2bd7444a318de06b5f53178abf9c37ff',1,'IMB_MGR']]],
  ['keyexp_5f256_8',['keyexp_256',['../structIMB__MGR.html#a431e99ddb3837a32bedb6cd426054bcc',1,'IMB_MGR']]]
];
