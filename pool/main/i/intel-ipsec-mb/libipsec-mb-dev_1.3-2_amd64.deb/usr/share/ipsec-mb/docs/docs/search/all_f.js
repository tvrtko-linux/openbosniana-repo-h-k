var searchData=
[
  ['partial_5fblock_5fenc_5fkey_0',['partial_block_enc_key',['../structgcm__context__data.html#a2e52ea863c681afe1d3370a987e252f0',1,'gcm_context_data']]],
  ['partial_5fblock_5flength_1',['partial_block_length',['../structgcm__context__data.html#a97411247efd14ab01e7e0da6587bfa0c',1,'gcm_context_data']]],
  ['poly1305_2',['POLY1305',['../structIMB__JOB.html#a15f9c1a5ab25dca6e3a550ff00ad2419',1,'IMB_JOB']]],
  ['poly_5fkey_3',['poly_key',['../structchacha20__poly1305__context__data.html#a9ac4fafe2ca37395264f728c8e99a9b1',1,'chacha20_poly1305_context_data']]],
  ['poly_5fscratch_4',['poly_scratch',['../structchacha20__poly1305__context__data.html#a908d80ce2c35792099dbc967818b9abd',1,'chacha20_poly1305_context_data']]]
];
