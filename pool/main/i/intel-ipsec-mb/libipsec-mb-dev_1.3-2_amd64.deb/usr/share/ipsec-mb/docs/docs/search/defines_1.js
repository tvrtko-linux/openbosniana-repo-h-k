var searchData=
[
  ['declare_5faligned_0',['DECLARE_ALIGNED',['../intel-ipsec-mb_8h.html#ad920a47ed8f57af8b2cf6bcd18a3e41c',1,'intel-ipsec-mb.h']]]
];
