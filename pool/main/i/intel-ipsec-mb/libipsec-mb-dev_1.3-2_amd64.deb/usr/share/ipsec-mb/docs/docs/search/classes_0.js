var searchData=
[
  ['chacha20_5fpoly1305_5fcontext_5fdata_0',['chacha20_poly1305_context_data',['../structchacha20__poly1305__context__data.html',1,'']]]
];
