var searchData=
[
  ['last_5fblock_5fcount_0',['last_block_count',['../structchacha20__poly1305__context__data.html#add03511d1f95376b3ac64a7916c27368',1,'chacha20_poly1305_context_data']]],
  ['last_5fks_1',['last_ks',['../structchacha20__poly1305__context__data.html#afc74af4af99449f0b9f01338ae723c1a',1,'chacha20_poly1305_context_data']]],
  ['len_2',['len',['../structIMB__SGL__IOV.html#a3a3662456b91011eb0585667492acc88',1,'IMB_SGL_IOV']]],
  ['low_3',['low',['../structimb__uint128__t.html#a30e60cc86acb6eafaa4079c0e46ba622',1,'imb_uint128_t']]]
];
