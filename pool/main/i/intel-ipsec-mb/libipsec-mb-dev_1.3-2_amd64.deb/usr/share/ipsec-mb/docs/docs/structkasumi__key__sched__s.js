var structkasumi__key__sched__s =
[
    [ "msk16", "structkasumi__key__sched__s.html#a091988e7975015d654ccb6904c4fdf39", null ],
    [ "sk16", "structkasumi__key__sched__s.html#a7e69de411b81753c10776442bbe03100", null ]
];