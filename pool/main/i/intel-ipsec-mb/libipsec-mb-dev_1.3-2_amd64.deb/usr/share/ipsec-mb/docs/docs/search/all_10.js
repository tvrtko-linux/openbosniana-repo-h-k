var searchData=
[
  ['queue_5fsize_0',['queue_size',['../structIMB__MGR.html#a5a35c9c2a1c8eb5b4aa239a3b04f4fbf',1,'IMB_MGR']]],
  ['queue_5fsize_5favx_1',['queue_size_avx',['../intel-ipsec-mb_8h.html#a800c395d326e718a2b520d0bb91cbb89',1,'intel-ipsec-mb.h']]],
  ['queue_5fsize_5favx2_2',['queue_size_avx2',['../intel-ipsec-mb_8h.html#a8a540000c08366ad47d95e23ed5b2918',1,'intel-ipsec-mb.h']]],
  ['queue_5fsize_5favx512_3',['queue_size_avx512',['../intel-ipsec-mb_8h.html#a51c0426a4b57c9e7db2b091692dff472',1,'intel-ipsec-mb.h']]],
  ['queue_5fsize_5fsse_4',['queue_size_sse',['../intel-ipsec-mb_8h.html#a80f792744558de173ea97d722c58e5c1',1,'intel-ipsec-mb.h']]],
  ['queue_5fsize_5ft_5',['queue_size_t',['../intel-ipsec-mb_8h.html#a9884ae92b598dd504f7d0ef8be5051d6',1,'intel-ipsec-mb.h']]]
];
