var globals_func =
[
    [ "a", "globals_func.html", null ],
    [ "d", "globals_func_d.html", null ],
    [ "f", "globals_func_f.html", null ],
    [ "g", "globals_func_g.html", null ],
    [ "i", "globals_func_i.html", null ],
    [ "k", "globals_func_k.html", null ],
    [ "m", "globals_func_m.html", null ],
    [ "q", "globals_func_q.html", null ],
    [ "s", "globals_func_s.html", null ],
    [ "z", "globals_func_z.html", null ]
];