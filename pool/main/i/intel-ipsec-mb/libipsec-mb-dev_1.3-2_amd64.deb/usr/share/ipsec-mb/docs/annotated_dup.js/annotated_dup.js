var annotated_dup =
[
    [ "chacha20_poly1305_context_data", "structchacha20__poly1305__context__data.html", "structchacha20__poly1305__context__data" ],
    [ "gcm_context_data", "structgcm__context__data.html", "structgcm__context__data" ],
    [ "gcm_key_data", "structgcm__key__data.html", "structgcm__key__data" ],
    [ "IMB_JOB", "structIMB__JOB.html", "structIMB__JOB" ],
    [ "IMB_MGR", "structIMB__MGR.html", "structIMB__MGR" ],
    [ "IMB_SGL_IOV", "structIMB__SGL__IOV.html", "structIMB__SGL__IOV" ],
    [ "imb_uint128_t", "structimb__uint128__t.html", "structimb__uint128__t" ],
    [ "kasumi_key_sched_s", "structkasumi__key__sched__s.html", "structkasumi__key__sched__s" ],
    [ "snow3g_key_schedule_s", "structsnow3g__key__schedule__s.html", "structsnow3g__key__schedule__s" ]
];