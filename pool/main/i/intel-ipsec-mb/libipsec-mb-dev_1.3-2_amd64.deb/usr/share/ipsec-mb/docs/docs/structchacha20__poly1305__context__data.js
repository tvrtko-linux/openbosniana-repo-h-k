var structchacha20__poly1305__context__data =
[
    [ "aad_len", "structchacha20__poly1305__context__data.html#a7b5edcebc9a6bec3776daf6d13bf950c", null ],
    [ "hash", "structchacha20__poly1305__context__data.html#ae12447b2fd2e9f8a6f09f443bd303887", null ],
    [ "hash_len", "structchacha20__poly1305__context__data.html#ade4568d041695b318df773787872127f", null ],
    [ "IV", "structchacha20__poly1305__context__data.html#ac0d1657fc57308900691369362c56658", null ],
    [ "last_block_count", "structchacha20__poly1305__context__data.html#add03511d1f95376b3ac64a7916c27368", null ],
    [ "last_ks", "structchacha20__poly1305__context__data.html#afc74af4af99449f0b9f01338ae723c1a", null ],
    [ "poly_key", "structchacha20__poly1305__context__data.html#a9ac4fafe2ca37395264f728c8e99a9b1", null ],
    [ "poly_scratch", "structchacha20__poly1305__context__data.html#a908d80ce2c35792099dbc967818b9abd", null ],
    [ "remain_ct_bytes", "structchacha20__poly1305__context__data.html#a74e971fe76c8b946e30e8f0c8cce111a", null ],
    [ "remain_ks_bytes", "structchacha20__poly1305__context__data.html#a84693b96048f6130a749b633c65e2105", null ]
];