var globals_dup =
[
    [ "_", "globals.html", null ],
    [ "a", "globals_a.html", null ],
    [ "c", "globals_c.html", null ],
    [ "d", "globals_d.html", null ],
    [ "f", "globals_f.html", null ],
    [ "g", "globals_g.html", null ],
    [ "h", "globals_h.html", null ],
    [ "i", "globals_i.html", null ],
    [ "k", "globals_k.html", null ],
    [ "m", "globals_m.html", null ],
    [ "q", "globals_q.html", null ],
    [ "s", "globals_s.html", null ],
    [ "x", "globals_x.html", null ],
    [ "z", "globals_z.html", null ]
];