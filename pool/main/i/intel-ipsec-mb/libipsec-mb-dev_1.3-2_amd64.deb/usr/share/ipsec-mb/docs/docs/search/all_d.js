var searchData=
[
  ['next_5fiv_0',['next_iv',['../structIMB__JOB.html#a5d473d9cb01f8e2818a6f5f0c9483bd7',1,'IMB_JOB']]],
  ['next_5fjob_1',['next_job',['../structIMB__MGR.html#a106ebd60d876e56bfc6bcc03d20acce4',1,'IMB_MGR']]],
  ['num_5fsgl_5fio_5fsegs_2',['num_sgl_io_segs',['../structIMB__JOB.html#a1d0a6baa8d8f7d9714fe86fe7085b8bb',1,'IMB_JOB']]]
];
