var searchData=
[
  ['gcm_5fcontext_5fdata_0',['gcm_context_data',['../structgcm__context__data.html',1,'']]],
  ['gcm_5fkey_5fdata_1',['gcm_key_data',['../structgcm__key__data.html',1,'']]]
];
