var structgcm__context__data =
[
    [ "aad_hash", "structgcm__context__data.html#a98c22f35eb0b4d368e2f454b347ed3b9", null ],
    [ "aad_length", "structgcm__context__data.html#ab1dadabcbd2002738ec7db7da332e04f", null ],
    [ "current_counter", "structgcm__context__data.html#a2a454a5e44422aaec135dc7807aa55a4", null ],
    [ "in_length", "structgcm__context__data.html#a0d9e72f85aba9363fcb4f2d757342aa2", null ],
    [ "orig_IV", "structgcm__context__data.html#a84bac4eabc12b81d26898b6fe6728a63", null ],
    [ "partial_block_enc_key", "structgcm__context__data.html#a2e52ea863c681afe1d3370a987e252f0", null ],
    [ "partial_block_length", "structgcm__context__data.html#a97411247efd14ab01e7e0da6587bfa0c", null ]
];