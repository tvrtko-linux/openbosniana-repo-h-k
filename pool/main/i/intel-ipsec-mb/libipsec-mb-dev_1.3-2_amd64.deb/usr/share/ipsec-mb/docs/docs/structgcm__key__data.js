var structgcm__key__data =
[
    [ "avx2_avx512", "structgcm__key__data.html#a3f231fdc1d521cd15c111667e4aea818", null ],
    [ "expanded_keys", "structgcm__key__data.html#aa5bda4f55b8393be151cfe28a9dc1ca9", null ],
    [ "ghash_keys", "structgcm__key__data.html#af5adb4225d569050207cfcfe00fe273a", null ],
    [ "shifted_hkey", "structgcm__key__data.html#a73b61a77635c0357b36b83aaf69d1237", null ],
    [ "shifted_hkey_k", "structgcm__key__data.html#a570a82f076ceb5da6719d1a554584820", null ],
    [ "sse_avx", "structgcm__key__data.html#a908988e25607cd3e092bfcea9964deb1", null ],
    [ "vaes_avx512", "structgcm__key__data.html#a7ad44e105b23e41b7f79530b6370e509", null ]
];