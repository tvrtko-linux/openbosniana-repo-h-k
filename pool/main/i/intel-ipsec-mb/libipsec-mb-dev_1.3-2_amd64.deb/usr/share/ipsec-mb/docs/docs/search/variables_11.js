var searchData=
[
  ['remain_5fct_5fbytes_0',['remain_ct_bytes',['../structchacha20__poly1305__context__data.html#a74e971fe76c8b946e30e8f0c8cce111a',1,'chacha20_poly1305_context_data']]],
  ['remain_5fks_5fbytes_1',['remain_ks_bytes',['../structchacha20__poly1305__context__data.html#a84693b96048f6130a749b633c65e2105',1,'chacha20_poly1305_context_data']]],
  ['reserved_2',['reserved',['../structIMB__JOB.html#a9d5e67861edf38dfa23160b650c7caa9',1,'IMB_JOB::reserved()'],['../structIMB__MGR.html#a136697eb37d5a06eeada0f338abd8b51',1,'IMB_MGR::reserved()']]]
];
