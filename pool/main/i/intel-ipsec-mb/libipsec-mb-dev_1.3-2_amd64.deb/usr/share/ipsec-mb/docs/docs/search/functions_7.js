var searchData=
[
  ['queue_5fsize_5favx_0',['queue_size_avx',['../intel-ipsec-mb_8h.html#a800c395d326e718a2b520d0bb91cbb89',1,'intel-ipsec-mb.h']]],
  ['queue_5fsize_5favx2_1',['queue_size_avx2',['../intel-ipsec-mb_8h.html#a8a540000c08366ad47d95e23ed5b2918',1,'intel-ipsec-mb.h']]],
  ['queue_5fsize_5favx512_2',['queue_size_avx512',['../intel-ipsec-mb_8h.html#a51c0426a4b57c9e7db2b091692dff472',1,'intel-ipsec-mb.h']]],
  ['queue_5fsize_5fsse_3',['queue_size_sse',['../intel-ipsec-mb_8h.html#a80f792744558de173ea97d722c58e5c1',1,'intel-ipsec-mb.h']]]
];
