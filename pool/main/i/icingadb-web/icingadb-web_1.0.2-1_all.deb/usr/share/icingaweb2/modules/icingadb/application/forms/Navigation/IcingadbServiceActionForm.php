<?php

/* Icinga DB Web | (c) 2021 Icinga GmbH | GPLv2 */

namespace Icinga\Module\Icingadb\Forms\Navigation;

class IcingadbServiceActionForm extends ActionForm
{
    protected $restriction = 'icingadb/filter/services';
}
