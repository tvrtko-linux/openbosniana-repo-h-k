<?php

/* Icinga DB Web | (c) 2021 Icinga GmbH | GPLv2 */

namespace Icinga\Module\Icingadb\Web\Navigation;

class IcingadbServiceAction extends Action
{
}
