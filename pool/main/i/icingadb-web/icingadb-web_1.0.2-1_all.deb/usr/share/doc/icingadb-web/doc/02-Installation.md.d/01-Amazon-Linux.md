# Installing Icinga DB Web on Amazon Linux
<!-- {% set amazon_linux = True %} -->
<!-- {% include "02-Installation.md" %} -->
