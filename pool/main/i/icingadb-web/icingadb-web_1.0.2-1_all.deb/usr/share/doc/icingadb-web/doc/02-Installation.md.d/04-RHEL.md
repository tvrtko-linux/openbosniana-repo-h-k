# Installing Icinga DB Web on RHEL
<!-- {% set rhel = True %} -->
<!-- {% include "02-Installation.md" %} -->
