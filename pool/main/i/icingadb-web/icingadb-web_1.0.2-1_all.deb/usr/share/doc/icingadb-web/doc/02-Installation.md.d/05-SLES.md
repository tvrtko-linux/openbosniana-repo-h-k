# Installing Icinga DB Web on SLES
<!-- {% set sles = True %} -->
<!-- {% include "02-Installation.md" %} -->
