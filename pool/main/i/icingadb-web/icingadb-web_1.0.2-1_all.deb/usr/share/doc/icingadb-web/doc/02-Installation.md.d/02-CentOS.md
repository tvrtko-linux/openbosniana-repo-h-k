# Installing Icinga DB Web on CentOS
<!-- {% set centos = True %} -->
<!-- {% include "02-Installation.md" %} -->
