# Installing Icinga DB Web on Ubuntu
<!-- {% set ubuntu = True %} -->
<!-- {% include "02-Installation.md" %} -->
