# Installing Icinga DB Web on Debian
<!-- {% set debian = True %} -->
<!-- {% include "02-Installation.md" %} -->
