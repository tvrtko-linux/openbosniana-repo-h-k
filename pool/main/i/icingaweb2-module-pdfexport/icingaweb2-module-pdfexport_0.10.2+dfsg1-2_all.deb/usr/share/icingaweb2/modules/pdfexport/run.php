<?php

/* Icinga PDF Export | (c) 2018 Icinga GmbH | GPLv2 */

/** @var \Icinga\Application\Modules\Module $this */

$this->provideHook('Pdfexport');

require_once 'vendor/autoload.php';
