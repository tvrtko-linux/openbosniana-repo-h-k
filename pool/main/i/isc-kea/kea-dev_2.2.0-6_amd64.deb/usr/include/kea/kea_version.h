#define EXTENDED_VERSION "tarball"
#define PACKAGE_VERSION_TYPE "stable"
