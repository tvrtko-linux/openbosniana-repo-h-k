# icingaweb2-module-boxydash
An "at a view" dashboard showing the overall view of your icinga implementation

![demo view](https://raw.githubusercontent.com/morgajel/icingaweb2-module-boxydash/master/demo.png)




# Installation
Simply check this out to /usr/share/icingaweb2/modules/boxydash then symlink to it from /etc/icingaweb2/enabledModules/boxydash

it should now appear in 
  icingacli modules list

as well as your web interface.
