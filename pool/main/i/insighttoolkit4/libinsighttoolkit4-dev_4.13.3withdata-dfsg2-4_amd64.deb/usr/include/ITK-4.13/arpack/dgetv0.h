extern int v3p_netlib_dgetv0_(
  v3p_netlib_integer *ido,
  char *bmat,
  v3p_netlib_integer *itry,
  v3p_netlib_logical *initv,
  v3p_netlib_integer *n,
  v3p_netlib_integer *j,
  v3p_netlib_doublereal *v,
  v3p_netlib_integer *ldv,
  v3p_netlib_doublereal *resid,
  v3p_netlib_doublereal *rnorm,
  v3p_netlib_integer *ipntr,
  v3p_netlib_doublereal *workd,
  v3p_netlib_integer *ierr,
  v3p_netlib_ftnlen bmat_len
  );
