/*========================== begin_copyright_notice ============================

Copyright (C) 2017-2021 Intel Corporation

SPDX-License-Identifier: MIT

============================= end_copyright_notice ===========================*/

#ifndef _IGA_HPP
#define _IGA_HPP

#include "iga.h"
#include "iga_types_ext.hpp"
#include "iga_types_swsb.hpp"

#include "kv.hpp"

#endif
