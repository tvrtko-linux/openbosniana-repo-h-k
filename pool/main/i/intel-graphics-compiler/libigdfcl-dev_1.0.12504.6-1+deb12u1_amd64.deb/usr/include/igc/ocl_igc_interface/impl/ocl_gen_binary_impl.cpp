/*========================== begin_copyright_notice ============================

Copyright (C) 2017-2021 Intel Corporation

SPDX-License-Identifier: MIT

============================= end_copyright_notice ===========================*/

#include "ocl_igc_interface/ocl_gen_binary.h"
#include "ocl_igc_interface/impl/ocl_gen_binary_impl.h"

#include "cif/macros/enable.h"

namespace IGC {

}

#include "cif/macros/disable.h"
