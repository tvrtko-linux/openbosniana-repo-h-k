# Welcome to VST 3 SDK Interfaces

Here are located all VST interfaces definitions (including VST Component/Controller, UI, Test).

## License & Usage guidelines

More details are found at [www.steinberg.net/sdklicenses_vst3](http://www.steinberg.net/sdklicenses_vst3)

----
Return to [VST 3 SDK](https://github.com/steinbergmedia/vst3sdk)