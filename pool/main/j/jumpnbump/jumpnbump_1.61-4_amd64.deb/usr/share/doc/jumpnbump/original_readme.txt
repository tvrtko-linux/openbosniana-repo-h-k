                        JUMP 'N BUMP

                by Brainchild Design in 1998


Jump 'n Bump is e-mailware. That means you're supposed to
send us an e-mail. Write for example where you're from and
what you thought about this game. If you do that, you will
greatly encourage us to make more games for you!

We encourage you to spread this game to all your friends!
You are also allowed to put this game on your homepage,
on CD:s and magazines. You may even charge money for it.
It would be nice though, if you sent us a copy of your
article, so we know about it.


                 Code by Mattias Brynervall
               Graphics by Andreas Brynervall
                    and Martin Magnusson
                   Music by Anders Nilsson


                         INSTRUCTIONS

Leap over the log, and bound off to the right to play.
The different rabbits are controlled with:

                     DOTT    LEFT/RIGHT/UP
                     JIFFY   A/D/W
                     FIZZ    Mouse Buttons
                     MIJJI   Joystick

Jump around like crazy and try to get on top of the others.


                           HOMEPAGE

               http://www.algonet.se/~mattiasb


                       BRAINCHILD DESIGN

Brainchild Design tries to make games with great gameplay.
"Simple but yet addictive" is something of a guideline.
Brainchild Designs members are:

           Andreas Brynervall   andreasb@acc.umu.se
           Mattias Brynervall   matbr656@student.liu.se
             Martin Magnusson   marma102@student.liu.se
               Anders Nilsson   equel@swipnet.se

Andreas, Mattias and Martin are old friends from school in
Nybro, in the south of Sweden. Anders joined a bit later. 
He's from Malmö, and we met eachother over the internet.
Now we really don't know where he is, and we have no contact
with him. Where are you, Anders?


                          SECRETS

Oh, there are some secrets in Jump 'n Bump.
Try and see if you can find them!
If you can't, you could always write and ask us...


                       TECHNICAL INFO

Program code in C and ASM. Compiled with DJGPP and NASM.
Graphics drawn in Deluxe Paint 2 and Paint Shop Pro 5.
Music made with Fasttracker 2.
Readme written in Notepad.


               DON'T FORGET TO SEND AN E-MAIL!