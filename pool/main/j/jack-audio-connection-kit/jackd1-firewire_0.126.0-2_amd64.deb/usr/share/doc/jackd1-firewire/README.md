Welcome to JACK, the Jack Audio Connection Kit.

Please see the JACK [website](https://jackaudio.org/) and [wiki](https://github.com/jackaudio/jackaudio.github.com/wiki) for more information. 
There are also the #jack and #lad chat channels on [libera.chat IRC](https://web.libera.chat/#jack).
