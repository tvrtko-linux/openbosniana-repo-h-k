var indexSectionsWithContent =
{
  0: "abcdefghijlmnoprstuwxy",
  1: "j",
  2: "bcdemprt",
  3: "jo",
  4: "abcdefghilmnoprstuwxy",
  5: "j",
  6: "j",
  7: "j",
  8: "bj",
  9: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "groups",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Modules",
  9: "Pages"
};

