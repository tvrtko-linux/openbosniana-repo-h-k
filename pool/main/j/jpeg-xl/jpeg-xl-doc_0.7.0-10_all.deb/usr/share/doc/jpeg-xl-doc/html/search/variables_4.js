var searchData=
[
  ['endianness_0',['endianness',['../structJxlPixelFormat.html#ae2c031a81e9890dc1d337c220c5903b9',1,'JxlPixelFormat']]],
  ['exponent_5fbits_5fper_5fsample_1',['exponent_bits_per_sample',['../structJxlBasicInfo.html#aa7479ee10d546e8075c5a791869f8b2f',1,'JxlBasicInfo::exponent_bits_per_sample()'],['../structJxlExtraChannelInfo.html#aab9c03b9a09ab6b05bd267a701c8e38c',1,'JxlExtraChannelInfo::exponent_bits_per_sample()']]],
  ['extensions_2',['extensions',['../structJxlHeaderExtensions.html#ae76f196d02126e2b8a25596c7b6f4fa9',1,'JxlHeaderExtensions']]]
];
