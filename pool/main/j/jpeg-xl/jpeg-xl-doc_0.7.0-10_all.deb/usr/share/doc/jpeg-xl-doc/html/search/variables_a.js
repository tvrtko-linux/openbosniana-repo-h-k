var searchData=
[
  ['min_5fnits_0',['min_nits',['../structJxlBasicInfo.html#a67cdfc6e579ff7c1cee8b2f184317caa',1,'JxlBasicInfo']]]
];
