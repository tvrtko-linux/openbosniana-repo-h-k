var searchData=
[
  ['white_5fpoint_0',['white_point',['../structJxlColorEncoding.html#a80761b6ff85a5db063c5cd847e49cd96',1,'JxlColorEncoding']]],
  ['white_5fpoint_5fxy_1',['white_point_xy',['../structJxlColorEncoding.html#a1e891dc1363c328abe89cf1cd5f898c0',1,'JxlColorEncoding']]]
];
