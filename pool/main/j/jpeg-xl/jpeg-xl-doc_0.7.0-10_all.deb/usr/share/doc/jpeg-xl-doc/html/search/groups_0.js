var searchData=
[
  ['butteraugli_20metric_0',['Butteraugli metric',['../group__libjxl__butteraugli.html',1,'']]]
];
