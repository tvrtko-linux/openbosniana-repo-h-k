var searchData=
[
  ['data_5ftype_0',['data_type',['../structJxlPixelFormat.html#aa9d5363908ebfb847f63f03273845898',1,'JxlPixelFormat']]],
  ['decode_2eh_1',['decode.h',['../decode_8h.html',1,'']]],
  ['decode_5fcxx_2eh_2',['decode_cxx.h',['../decode__cxx_8h.html',1,'']]],
  ['deprecated_20list_3',['Deprecated List',['../deprecated.html',1,'']]],
  ['destroy_4',['destroy',['../structJxlCmsInterface.html#a4f7b3d762418ff23bc98dc1dc5e59333',1,'JxlCmsInterface']]],
  ['dim_5fshift_5',['dim_shift',['../structJxlExtraChannelInfo.html#a6e6a814a8713a2b78faa2b45421bfdc7',1,'JxlExtraChannelInfo']]],
  ['duration_6',['duration',['../structJxlFrameHeader.html#ae3632efe9ed4bf064642d3dd3e5bb486',1,'JxlFrameHeader']]]
];
