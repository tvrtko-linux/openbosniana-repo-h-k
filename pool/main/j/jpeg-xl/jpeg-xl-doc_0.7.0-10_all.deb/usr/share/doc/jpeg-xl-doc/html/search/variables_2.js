var searchData=
[
  ['cfa_5fchannel_0',['cfa_channel',['../structJxlExtraChannelInfo.html#a277e497b7d48c088e5ff888ee79822a7',1,'JxlExtraChannelInfo']]],
  ['clamp_1',['clamp',['../structJxlBlendInfo.html#a8dbe3a0818cd0d7ca3a881736f87320d',1,'JxlBlendInfo']]],
  ['color_5fencoding_2',['color_encoding',['../structJxlColorProfile.html#a7bdca354288b793ca880bc89ea552fd9',1,'JxlColorProfile']]],
  ['color_5fspace_3',['color_space',['../structJxlColorEncoding.html#ac835a19d9dc9078284b6ad2e7f975bb7',1,'JxlColorEncoding']]],
  ['crop_5fx0_4',['crop_x0',['../structJxlLayerInfo.html#a900f52caed02a129c0ecef807580ff01',1,'JxlLayerInfo']]],
  ['crop_5fy0_5',['crop_y0',['../structJxlLayerInfo.html#aec94e2ba532959b7160ff5285d39c8bb',1,'JxlLayerInfo']]]
];
