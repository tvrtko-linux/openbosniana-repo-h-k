var searchData=
[
  ['jpeg_20xl_20common_20definitions_0',['JPEG XL common definitions',['../group__libjxl__common.html',1,'']]],
  ['jpeg_20xl_20decoder_1',['JPEG XL Decoder',['../group__libjxl__decoder.html',1,'']]],
  ['jpeg_20xl_20encoder_2',['JPEG XL Encoder',['../group__libjxl__encoder.html',1,'']]],
  ['jpeg_20xl_20library_20_28libjxl_29_3',['JPEG XL library (libjxl)',['../group__libjxl.html',1,'']]],
  ['jpeg_20xl_20multi_2dthread_20library_20_28libjxl_5fthreads_29_4',['JPEG XL Multi-thread library (libjxl_threads)',['../group__libjxl__threads.html',1,'']]]
];
