var searchData=
[
  ['align_0',['align',['../structJxlPixelFormat.html#a7c40a722d5d220640317b83520e8488a',1,'JxlPixelFormat']]],
  ['alloc_1',['alloc',['../structJxlMemoryManagerStruct.html#abcacc8ca00de5d004802411ff8213dcc',1,'JxlMemoryManagerStruct']]],
  ['alpha_2',['alpha',['../structJxlBlendInfo.html#a5d8c00040c955a3033d63ecf746f321d',1,'JxlBlendInfo']]],
  ['alpha_5fbits_3',['alpha_bits',['../structJxlBasicInfo.html#a055327db05a80c307b8cec7e7d01cd06',1,'JxlBasicInfo']]],
  ['alpha_5fexponent_5fbits_4',['alpha_exponent_bits',['../structJxlBasicInfo.html#a909eb39a36eb29e59419e13b9fa3a609',1,'JxlBasicInfo']]],
  ['alpha_5fpremultiplied_5',['alpha_premultiplied',['../structJxlBasicInfo.html#a70e9bd0a3bdcd3c3fdc1aaa6d6ac9dbe',1,'JxlBasicInfo::alpha_premultiplied()'],['../structJxlExtraChannelInfo.html#affc51f743cbfea1520e6dc5504a1c5e5',1,'JxlExtraChannelInfo::alpha_premultiplied()']]],
  ['animation_6',['animation',['../structJxlBasicInfo.html#af75240d5b5a13629bf15a77ea3fc130a',1,'JxlBasicInfo']]]
];
