var searchData=
[
  ['padding_0',['padding',['../structJxlBasicInfo.html#ac869b6fe24e38e2cc14cb6ef87f3e0a6',1,'JxlBasicInfo']]],
  ['parallel_5frunner_2eh_1',['parallel_runner.h',['../parallel__runner_8h.html',1,'']]],
  ['preview_2',['preview',['../structJxlBasicInfo.html#ae8ed2d78620e2bb129ae6e97444d83f6',1,'JxlBasicInfo']]],
  ['primaries_3',['primaries',['../structJxlColorEncoding.html#a4adb4c3376298e9f7b10e15557149582',1,'JxlColorEncoding']]],
  ['primaries_5fblue_5fxy_4',['primaries_blue_xy',['../structJxlColorEncoding.html#a14cb5aa22d560a53679857a25b38b3d8',1,'JxlColorEncoding']]],
  ['primaries_5fgreen_5fxy_5',['primaries_green_xy',['../structJxlColorEncoding.html#a505a1060d05800fbe7988e24c17d3e17',1,'JxlColorEncoding']]],
  ['primaries_5fred_5fxy_6',['primaries_red_xy',['../structJxlColorEncoding.html#acc60fa4adbc49b24bd4a88fd907745a4',1,'JxlColorEncoding']]]
];
