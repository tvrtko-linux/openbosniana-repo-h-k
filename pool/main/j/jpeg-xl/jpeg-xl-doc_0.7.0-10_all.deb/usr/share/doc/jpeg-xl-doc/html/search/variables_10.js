var searchData=
[
  ['timecode_0',['timecode',['../structJxlFrameHeader.html#ae9efb12da522373c34467a4d142aed3b',1,'JxlFrameHeader']]],
  ['tps_5fdenominator_1',['tps_denominator',['../structJxlAnimationHeader.html#a59137adf62abbdde79851fc159359468',1,'JxlAnimationHeader']]],
  ['tps_5fnumerator_2',['tps_numerator',['../structJxlAnimationHeader.html#af071d9e7d3e25f356bde7837f573d1b0',1,'JxlAnimationHeader']]],
  ['transfer_5ffunction_3',['transfer_function',['../structJxlColorEncoding.html#a0d84afc1150b73a3991efeabd427b45e',1,'JxlColorEncoding']]],
  ['type_4',['type',['../structJxlExtraChannelInfo.html#a19f3ecdea88ee49030974df7e6d173ce',1,'JxlExtraChannelInfo']]]
];
