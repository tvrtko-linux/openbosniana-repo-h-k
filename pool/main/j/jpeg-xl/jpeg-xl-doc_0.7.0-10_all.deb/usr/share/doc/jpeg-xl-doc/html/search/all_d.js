var searchData=
[
  ['opaque_0',['opaque',['../structJxlMemoryManagerStruct.html#a52c39b276e4c2c1c4a5e0cbba25885cc',1,'JxlMemoryManagerStruct']]],
  ['operator_28_29_1',['operator()',['../structJxlButteraugliApiDestroyStruct.html#a086918873c18543aab502e940bd794dd',1,'JxlButteraugliApiDestroyStruct::operator()()'],['../structJxlButteraugliResultDestroyStruct.html#abedcdf86ca822c3e0b4392700bce7c43',1,'JxlButteraugliResultDestroyStruct::operator()()'],['../structJxlDecoderDestroyStruct.html#aa5c19dd0a905b896bbf7a05606eae8d7',1,'JxlDecoderDestroyStruct::operator()()'],['../structJxlEncoderDestroyStruct.html#a98c41735279e777f2922b27f4c3e931f',1,'JxlEncoderDestroyStruct::operator()()'],['../structJxlResizableParallelRunnerDestroyStruct.html#a7f6b921b89a92267b3fea7179b06f830',1,'JxlResizableParallelRunnerDestroyStruct::operator()()'],['../structJxlThreadParallelRunnerDestroyStruct.html#af3c121dc159b53d43d1818075d23b829',1,'JxlThreadParallelRunnerDestroyStruct::operator()()']]],
  ['orientation_2',['orientation',['../structJxlBasicInfo.html#a8059c9364574d1456a2e44a27f5809d1',1,'JxlBasicInfo']]]
];
