var searchData=
[
  ['cfa_5fchannel_0',['cfa_channel',['../structJxlExtraChannelInfo.html#a277e497b7d48c088e5ff888ee79822a7',1,'JxlExtraChannelInfo']]],
  ['clamp_1',['clamp',['../structJxlBlendInfo.html#a8dbe3a0818cd0d7ca3a881736f87320d',1,'JxlBlendInfo']]],
  ['cms_5finterface_2eh_2',['cms_interface.h',['../cms__interface_8h.html',1,'']]],
  ['codestream_5fheader_2eh_3',['codestream_header.h',['../codestream__header_8h.html',1,'']]],
  ['color_5fencoding_4',['color_encoding',['../structJxlColorProfile.html#a7bdca354288b793ca880bc89ea552fd9',1,'JxlColorProfile']]],
  ['color_5fencoding_2eh_5',['color_encoding.h',['../color__encoding_8h.html',1,'']]],
  ['color_5fspace_6',['color_space',['../structJxlColorEncoding.html#ac835a19d9dc9078284b6ad2e7f975bb7',1,'JxlColorEncoding']]],
  ['crop_5fx0_7',['crop_x0',['../structJxlLayerInfo.html#a900f52caed02a129c0ecef807580ff01',1,'JxlLayerInfo']]],
  ['crop_5fy0_8',['crop_y0',['../structJxlLayerInfo.html#aec94e2ba532959b7160ff5285d39c8bb',1,'JxlLayerInfo']]]
];
