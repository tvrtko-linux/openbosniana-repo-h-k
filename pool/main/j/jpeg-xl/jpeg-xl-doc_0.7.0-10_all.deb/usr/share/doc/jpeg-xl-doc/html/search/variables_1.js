var searchData=
[
  ['bits_5fper_5fsample_0',['bits_per_sample',['../structJxlBasicInfo.html#a9e7c445f98c97f3bd770600d13b8d95b',1,'JxlBasicInfo::bits_per_sample()'],['../structJxlExtraChannelInfo.html#a6605541997464250049daffb6b066a49',1,'JxlExtraChannelInfo::bits_per_sample()']]],
  ['blend_5finfo_1',['blend_info',['../structJxlLayerInfo.html#a4a7662e68386c51f2d172664856944e6',1,'JxlLayerInfo']]],
  ['blendmode_2',['blendmode',['../structJxlBlendInfo.html#a1fcb1b084bb049bb7aa7cc13dad676e7',1,'JxlBlendInfo']]]
];
