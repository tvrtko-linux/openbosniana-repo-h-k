var searchData=
[
  ['free_0',['free',['../structJxlMemoryManagerStruct.html#a026a4f48c1e581c6a8ed9fee56aa2f84',1,'JxlMemoryManagerStruct']]]
];
