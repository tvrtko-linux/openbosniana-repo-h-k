var searchData=
[
  ['xsize_0',['xsize',['../structJxlPreviewHeader.html#a5fdcacf0d21a2079baab22ed3dbbf2d6',1,'JxlPreviewHeader::xsize()'],['../structJxlIntrinsicSizeHeader.html#aa7f087953c4110e43dd468cca399cd11',1,'JxlIntrinsicSizeHeader::xsize()'],['../structJxlBasicInfo.html#adaa8f9e5bd7d74f65b8d02ce88da2bb1',1,'JxlBasicInfo::xsize()'],['../structJxlLayerInfo.html#a38f74fb5150add2ca4427b1c03ec6e20',1,'JxlLayerInfo::xsize()']]]
];
