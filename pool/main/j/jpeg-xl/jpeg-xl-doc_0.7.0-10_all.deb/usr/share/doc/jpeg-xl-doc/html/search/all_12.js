var searchData=
[
  ['uses_5foriginal_5fprofile_0',['uses_original_profile',['../structJxlBasicInfo.html#a03ec6be8eeb1c46051d9187760ec7c43',1,'JxlBasicInfo']]]
];
