var searchData=
[
  ['layer_5finfo_0',['layer_info',['../structJxlFrameHeader.html#a22bb2a17a30445000e542fbf2b5723c4',1,'JxlFrameHeader']]],
  ['linear_5fbelow_1',['linear_below',['../structJxlBasicInfo.html#af237b93acb9bfc847142d747ada573d2',1,'JxlBasicInfo']]]
];
