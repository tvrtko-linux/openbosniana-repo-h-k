var searchData=
[
  ['gamma_0',['gamma',['../structJxlColorEncoding.html#ac05da6bc09d9e188aacfb5c53cdef698',1,'JxlColorEncoding']]],
  ['get_5fdst_5fbuf_1',['get_dst_buf',['../structJxlCmsInterface.html#a83fa60c6aca3de359cec50cc87dff009',1,'JxlCmsInterface']]],
  ['get_5fsrc_5fbuf_2',['get_src_buf',['../structJxlCmsInterface.html#a0a475e8eead8a85f7ffb74d232dbb2ea',1,'JxlCmsInterface']]]
];
