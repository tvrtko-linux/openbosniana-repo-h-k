var searchData=
[
  ['name_5flength_0',['name_length',['../structJxlExtraChannelInfo.html#aaa1f102f868c5161082344eac70f305a',1,'JxlExtraChannelInfo::name_length()'],['../structJxlFrameHeader.html#aa257ecf5d41805a8661c6d8098140f7d',1,'JxlFrameHeader::name_length()']]],
  ['num_5fchannels_1',['num_channels',['../structJxlColorProfile.html#acae6749959df66993a7b0ec2300f9319',1,'JxlColorProfile::num_channels()'],['../structJxlPixelFormat.html#aa87d21c59f259aa4f3036c5afdf9d8aa',1,'JxlPixelFormat::num_channels()']]],
  ['num_5fcolor_5fchannels_2',['num_color_channels',['../structJxlBasicInfo.html#aa8b8277050891f496ca912df8c74d895',1,'JxlBasicInfo']]],
  ['num_5fextra_5fchannels_3',['num_extra_channels',['../structJxlBasicInfo.html#ae1d0001bcaf4d7637a8e9d4b483fad22',1,'JxlBasicInfo']]],
  ['num_5floops_4',['num_loops',['../structJxlAnimationHeader.html#aba4de38ad477e57e3ebf25d5cdc78b69',1,'JxlAnimationHeader']]]
];
