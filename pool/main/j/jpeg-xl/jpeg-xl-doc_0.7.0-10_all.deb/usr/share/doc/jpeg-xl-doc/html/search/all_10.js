var searchData=
[
  ['save_5fas_5freference_0',['save_as_reference',['../structJxlLayerInfo.html#a488b967f477505885b283832f2576743',1,'JxlLayerInfo']]],
  ['source_1',['source',['../structJxlBlendInfo.html#a345d0be7bda698f4f3e07684a65feb0a',1,'JxlBlendInfo']]],
  ['spot_5fcolor_2',['spot_color',['../structJxlExtraChannelInfo.html#a5f11ef50d592ad54e2edc3f925113ac1',1,'JxlExtraChannelInfo']]]
];
