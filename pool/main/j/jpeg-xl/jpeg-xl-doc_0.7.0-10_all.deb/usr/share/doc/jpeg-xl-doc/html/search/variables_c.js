var searchData=
[
  ['opaque_0',['opaque',['../structJxlMemoryManagerStruct.html#a52c39b276e4c2c1c4a5e0cbba25885cc',1,'JxlMemoryManagerStruct']]],
  ['orientation_1',['orientation',['../structJxlBasicInfo.html#a8059c9364574d1456a2e44a27f5809d1',1,'JxlBasicInfo']]]
];
