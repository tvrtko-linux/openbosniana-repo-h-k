var searchData=
[
  ['data_5ftype_0',['data_type',['../structJxlPixelFormat.html#aa9d5363908ebfb847f63f03273845898',1,'JxlPixelFormat']]],
  ['destroy_1',['destroy',['../structJxlCmsInterface.html#a4f7b3d762418ff23bc98dc1dc5e59333',1,'JxlCmsInterface']]],
  ['dim_5fshift_2',['dim_shift',['../structJxlExtraChannelInfo.html#a6e6a814a8713a2b78faa2b45421bfdc7',1,'JxlExtraChannelInfo']]],
  ['duration_3',['duration',['../structJxlFrameHeader.html#ae3632efe9ed4bf064642d3dd3e5bb486',1,'JxlFrameHeader']]]
];
