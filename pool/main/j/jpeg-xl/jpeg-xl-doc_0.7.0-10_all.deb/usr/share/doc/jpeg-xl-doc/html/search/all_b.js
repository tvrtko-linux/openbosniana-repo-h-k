var searchData=
[
  ['memory_5fmanager_2eh_0',['memory_manager.h',['../memory__manager_8h.html',1,'']]],
  ['min_5fnits_1',['min_nits',['../structJxlBasicInfo.html#a67cdfc6e579ff7c1cee8b2f184317caa',1,'JxlBasicInfo']]]
];
