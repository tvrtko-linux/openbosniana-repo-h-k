var searchData=
[
  ['icc_0',['icc',['../structJxlColorProfile.html#a1c8dfb8700717032aa577e3b882e30da',1,'JxlColorProfile']]],
  ['init_1',['init',['../structJxlCmsInterface.html#a3a5d07217d01470723e866205afbf944',1,'JxlCmsInterface']]],
  ['init_5fdata_2',['init_data',['../structJxlCmsInterface.html#ad87017fc687b9912b89ea7145b9d93c1',1,'JxlCmsInterface']]],
  ['intensity_5ftarget_3',['intensity_target',['../structJxlBasicInfo.html#afd6fe15db1ccd8f7fc612661ada46843',1,'JxlBasicInfo']]],
  ['intrinsic_5fxsize_4',['intrinsic_xsize',['../structJxlBasicInfo.html#ad39b1aef716127bf27364482e7d4eb52',1,'JxlBasicInfo']]],
  ['intrinsic_5fysize_5',['intrinsic_ysize',['../structJxlBasicInfo.html#a42452d05a46e5ad60a236f4becc47e15',1,'JxlBasicInfo']]],
  ['is_5flast_6',['is_last',['../structJxlFrameHeader.html#a3362aa303e57bbfdaa4140436b746521',1,'JxlFrameHeader']]]
];
