var searchData=
[
  ['have_5fanimation_0',['have_animation',['../structJxlBasicInfo.html#a799b7f1cb129af1600f664ca3a039be4',1,'JxlBasicInfo']]],
  ['have_5fcontainer_1',['have_container',['../structJxlBasicInfo.html#afbf2154433842096fe3fe939e9ff7be2',1,'JxlBasicInfo']]],
  ['have_5fcrop_2',['have_crop',['../structJxlLayerInfo.html#a52b38beae67d3661bfb142c4b58773d6',1,'JxlLayerInfo']]],
  ['have_5fpreview_3',['have_preview',['../structJxlBasicInfo.html#ae3cf4ad8a914bc4f90b8544e8725f7e1',1,'JxlBasicInfo']]],
  ['have_5ftimecodes_4',['have_timecodes',['../structJxlAnimationHeader.html#a5033d5d1835eb28b398164a54278feae',1,'JxlAnimationHeader']]]
];
