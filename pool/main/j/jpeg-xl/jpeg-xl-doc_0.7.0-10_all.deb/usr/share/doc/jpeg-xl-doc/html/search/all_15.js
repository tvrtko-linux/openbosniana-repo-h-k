var searchData=
[
  ['ysize_0',['ysize',['../structJxlPreviewHeader.html#a70cbb47c2a28a15b11d803be533ad3a1',1,'JxlPreviewHeader::ysize()'],['../structJxlIntrinsicSizeHeader.html#a8cecd484b4cf1705f8b218c4de6e42a6',1,'JxlIntrinsicSizeHeader::ysize()'],['../structJxlBasicInfo.html#a0b26fb249aec229f488168da89e42edb',1,'JxlBasicInfo::ysize()'],['../structJxlLayerInfo.html#a558e3adcf042e1e132a6568b899a71c5',1,'JxlLayerInfo::ysize()']]]
];
