var searchData=
[
  ['relative_5fto_5fmax_5fdisplay_0',['relative_to_max_display',['../structJxlBasicInfo.html#a721c7a6271093551116a1643c54ab5af',1,'JxlBasicInfo']]],
  ['rendering_5fintent_1',['rendering_intent',['../structJxlColorEncoding.html#a90729cc3c35f9830afcd651d46d84ffb',1,'JxlColorEncoding']]],
  ['run_2',['run',['../structJxlCmsInterface.html#a9a24b14207f12c27f22a78696fa133d9',1,'JxlCmsInterface']]]
];
