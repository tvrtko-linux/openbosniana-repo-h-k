**JAligner** is an open-source Java implementation of the [Needleman–Wunsch](http://en.wikipedia.org/wiki/Needleman-Wunsch_algorithm) and [Smith-Waterman](http://en.wikipedia.org/wiki/Smith-Waterman_algorithm) algorithms for biological pairwise [sequence alignment](http://en.wikipedia.org/wiki/Sequence_alignment) with the affine gap penalty model.

