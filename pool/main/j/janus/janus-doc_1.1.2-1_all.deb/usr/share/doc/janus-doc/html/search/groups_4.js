var searchData=
[
  ['plugin_20api_0',['Plugin API',['../group__pluginapi.html',1,'']]],
  ['plugins_1',['Plugins',['../group__plugins.html',1,'']]],
  ['protocols_2',['Protocols',['../group__protocols.html',1,'']]]
];
