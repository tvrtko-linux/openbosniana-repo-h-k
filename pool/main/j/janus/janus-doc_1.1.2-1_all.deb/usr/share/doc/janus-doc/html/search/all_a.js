var searchData=
[
  ['keep_5falive_5finterval_0',['keep_alive_interval',['../structjanus__mqtt__context.html#a551238c47ea62da5c1da682842418083',1,'janus_mqtt_context::keep_alive_interval()'],['../structjanus__mqttevh__context.html#a35452bf9255bdf375f332688a9d7bcd9',1,'janus_mqttevh_context::keep_alive_interval()']]],
  ['keep_5fprivate_5fhost_1',['keep_private_host',['../structjanus__options.html#ac4c76126ca29f9b0b28a9f98ca521220',1,'janus_options']]],
  ['key_5ffile_2',['key_file',['../structjanus__mqtt__context.html#a5622cc3c42a1c52638d89c7d1643bc1e',1,'janus_mqtt_context::key_file()'],['../structjanus__mqttevh__context.html#a751764689801a733c17fce72c7f6c23f',1,'janus_mqttevh_context::key_file()']]],
  ['keyframe_3',['keyframe',['../structjanus__streaming__rtp__source__stream.html#ab40476c0637e80c7aa1f62e241495d33',1,'janus_streaming_rtp_source_stream']]],
  ['kicked_4',['kicked',['../structjanus__videoroom__publisher.html#ac4ccc472d1537805cfcf19569300ceaa',1,'janus_videoroom_publisher::kicked()'],['../structjanus__videoroom__subscriber.html#a781cfcae26cc34dc260f0c0eaa49ecb4',1,'janus_videoroom_subscriber::kicked()']]]
];
