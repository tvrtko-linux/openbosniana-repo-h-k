var searchData=
[
  ['buffer_5fsamples_0',['BUFFER_SAMPLES',['../janus__audiobridge_8c.html#a26ea4db54e582d52795474df3ebb981a',1,'janus_audiobridge.c']]],
  ['buffer_5fsize_1',['BUFFER_SIZE',['../janus__nanomsg_8c.html#a6b20d41d6252e9871430c242cb1a56e7',1,'BUFFER_SIZE():&#160;janus_nanomsg.c'],['../janus__pfunix_8c.html#a6b20d41d6252e9871430c242cb1a56e7',1,'BUFFER_SIZE():&#160;janus_pfunix.c']]]
];
