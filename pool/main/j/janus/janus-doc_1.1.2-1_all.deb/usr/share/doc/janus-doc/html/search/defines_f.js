var searchData=
[
  ['thread_5fname_0',['THREAD_NAME',['../log_8c.html#a39b697d20f65f09553d3b9bb00e0a724',1,'log.c']]],
  ['timer_5fabstime_1',['TIMER_ABSTIME',['../mach__gettime_8h.html#adde83d9ea51f12d4149f016eededde54',1,'mach_gettime.h']]]
];
