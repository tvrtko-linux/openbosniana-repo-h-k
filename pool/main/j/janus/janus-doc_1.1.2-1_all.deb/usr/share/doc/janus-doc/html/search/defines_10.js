var searchData=
[
  ['unix_5fpath_5fmax_0',['UNIX_PATH_MAX',['../janus__pfunix_8c.html#a7baab2aa5bf8eb14b6128e0f16634837',1,'janus_pfunix.c']]]
];
