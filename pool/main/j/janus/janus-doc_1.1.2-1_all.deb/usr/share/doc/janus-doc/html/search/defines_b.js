var searchData=
[
  ['opus_5fpacket_5fduration_0',['OPUS_PACKET_DURATION',['../pp-opus_8c.html#a4486dc9c16f3fe59aa5044b56feca5bc',1,'pp-opus.c']]],
  ['opus_5fpt_1',['OPUS_PT',['../rtp_8c.html#a0cc1ad5d56d50ec4c02c61e3384db197',1,'rtp.c']]],
  ['opus_5fsamples_2',['OPUS_SAMPLES',['../janus__audiobridge_8c.html#af5fbd251f87a0471e77d245783402708',1,'janus_audiobridge.c']]],
  ['opusred_5fpt_3',['OPUSRED_PT',['../rtp_8c.html#a85ab0331724d2d8c1a91e5b4204c9b57',1,'rtp.c']]]
];
