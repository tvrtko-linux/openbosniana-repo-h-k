var searchData=
[
  ['remote_5fpublisher_5fbase_5fssrc_0',['REMOTE_PUBLISHER_BASE_SSRC',['../janus__videoroom_8c.html#a025300ddf278b79286e5a76b573eaa8c',1,'janus_videoroom.c']]],
  ['remote_5fpublisher_5fssrc_5fstep_1',['REMOTE_PUBLISHER_SSRC_STEP',['../janus__videoroom_8c.html#ad7349db4f5551ee4c97f2879db1c87c3',1,'janus_videoroom.c']]],
  ['rtp_5faudio_5fskew_5fth_5fms_2',['RTP_AUDIO_SKEW_TH_MS',['../rtp_8h.html#aaf95285276e0f12287c1d242d02448cb',1,'rtp.h']]],
  ['rtp_5fheader_5fsize_3',['RTP_HEADER_SIZE',['../rtp_8h.html#a6c15f00883c80c429d7ac945209fbba3',1,'rtp.h']]],
  ['rtp_5fvideo_5fskew_5fth_5fms_4',['RTP_VIDEO_SKEW_TH_MS',['../rtp_8h.html#ad07e54c1552704de34295c460089fe4a',1,'rtp.h']]]
];
