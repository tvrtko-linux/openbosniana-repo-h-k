var searchData=
[
  ['initial_5fbufsz_0',['INITIAL_BUFSZ',['../log_8c.html#abbb1175212a4cac0a169383404b8eb78',1,'log.c']]],
  ['isac16_5fpt_1',['ISAC16_PT',['../rtp_8c.html#a72bfed46b694fc2a685cd7c1435159aa',1,'rtp.c']]],
  ['isac32_5fpt_2',['ISAC32_PT',['../rtp_8c.html#a2a8003d4fee036f7dd2e202e995acf8f',1,'rtp.c']]]
];
