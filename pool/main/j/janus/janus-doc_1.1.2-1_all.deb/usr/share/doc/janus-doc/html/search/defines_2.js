var searchData=
[
  ['case_5fstr_0',['CASE_STR',['../text2pcap_8c.html#a89b8eabdbf31f95f1662c3044def6fe5',1,'CASE_STR():&#160;text2pcap.c'],['../janus__websockets_8c.html#a89b8eabdbf31f95f1662c3044def6fe5',1,'CASE_STR():&#160;janus_websockets.c'],['../janus__wsevh_8c.html#a89b8eabdbf31f95f1662c3044def6fe5',1,'CASE_STR():&#160;janus_wsevh.c']]],
  ['clock_5fmonotonic_1',['CLOCK_MONOTONIC',['../mach__gettime_8h.html#a6fb83f5e91e704391ff796553d5e0f46',1,'mach_gettime.h']]],
  ['clock_5frealtime_2',['CLOCK_REALTIME',['../mach__gettime_8h.html#a922ce1ae64374c9410c8a999e25e82af',1,'mach_gettime.h']]]
];
