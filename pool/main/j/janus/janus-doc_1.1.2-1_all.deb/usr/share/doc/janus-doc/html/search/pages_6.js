var searchData=
[
  ['license_0',['License',['../COPYING.html',1,'']]],
  ['lua_20plugin_20documentation_1',['Lua plugin documentation',['../lua.html',1,'']]]
];
