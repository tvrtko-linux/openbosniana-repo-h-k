var searchData=
[
  ['ntohll_0',['ntohll',['../record_8c.html#a3cfcf123d4ead264289232f91f2c9ca5',1,'ntohll():&#160;record.c'],['../janus__recordplay_8c.html#a3cfcf123d4ead264289232f91f2c9ca5',1,'ntohll():&#160;janus_recordplay.c'],['../janus-pp-rec_8c.html#a3cfcf123d4ead264289232f91f2c9ca5',1,'ntohll():&#160;janus-pp-rec.c'],['../mjr2pcap_8c.html#a3cfcf123d4ead264289232f91f2c9ca5',1,'ntohll():&#160;mjr2pcap.c'],['../pcap2mjr_8c.html#a3cfcf123d4ead264289232f91f2c9ca5',1,'ntohll():&#160;pcap2mjr.c']]],
  ['nua_5fhmagic_5ft_1',['NUA_HMAGIC_T',['../janus__sip_8c.html#a81d0d204a472008463e436c4dd142ca2',1,'janus_sip.c']]],
  ['nua_5fmagic_5ft_2',['NUA_MAGIC_T',['../janus__sip_8c.html#a12350de8944c89f8ba4ac89c26e2736b',1,'janus_sip.c']]]
];
