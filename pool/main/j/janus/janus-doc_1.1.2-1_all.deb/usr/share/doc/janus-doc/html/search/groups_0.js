var searchData=
[
  ['core_0',['Core',['../group__core.html',1,'']]]
];
