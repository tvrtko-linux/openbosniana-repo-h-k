var searchData=
[
  ['plugins_20documentation_0',['Plugins documentation',['../pluginslist.html',1,'']]]
];
