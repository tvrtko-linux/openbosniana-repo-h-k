var searchData=
[
  ['duktape_20plugin_20api_0',['Duktape plugin API',['../group__jspapi.html',1,'']]]
];
