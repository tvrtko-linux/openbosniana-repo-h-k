var searchData=
[
  ['pcma_5fpt_0',['PCMA_PT',['../rtp_8c.html#a5c07ad4b361ff5935a1e3a61f3e0988a',1,'rtp.c']]],
  ['pcmu_5fpt_1',['PCMU_PT',['../rtp_8c.html#ab52766a3b582e91c126a75f259e6dec0',1,'rtp.c']]]
];
