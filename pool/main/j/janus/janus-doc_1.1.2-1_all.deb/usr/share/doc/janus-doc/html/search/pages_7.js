var searchData=
[
  ['nosip_20plugin_20documentation_0',['NoSIP plugin documentation',['../nosip.html',1,'']]]
];
