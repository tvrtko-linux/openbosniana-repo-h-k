var searchData=
[
  ['ogg_5fflush_0',['ogg_flush',['../janus__voicemail_8c.html#ae6863815324fdeeaaeeecfeef6acdcda',1,'janus_voicemail.c']]],
  ['ogg_5fwrite_1',['ogg_write',['../janus__voicemail_8c.html#a357bf48e3e1e898bb67fe7ab6e13b866',1,'janus_voicemail.c']]],
  ['op_5ffree_2',['op_free',['../janus__voicemail_8c.html#afa4a02b6fca6d2567325b1f916ec0c98',1,'janus_voicemail.c']]],
  ['op_5ffrom_5fpkt_3',['op_from_pkt',['../janus__voicemail_8c.html#a1ff2830c7bfd3a26f91e709d13d3ec1a',1,'janus_voicemail.c']]],
  ['op_5fopushead_4',['op_opushead',['../janus__voicemail_8c.html#a9cf0f38063442dc526ee450771cfc087',1,'janus_voicemail.c']]],
  ['op_5fopustags_5',['op_opustags',['../janus__voicemail_8c.html#aa6f86a4ab599df02e16ad3636c450ce5',1,'janus_voicemail.c']]]
];
