var searchData=
[
  ['admin_2fmonitor_20api_0',['Admin/Monitor API',['../admin.html',1,'']]],
  ['audiobridge_20plugin_20documentation_1',['AudioBridge plugin documentation',['../audiobridge.html',1,'']]],
  ['authenticating_20the_20janus_20api_2',['Authenticating the Janus API',['../auth.html',1,'']]]
];
