var searchData=
[
  ['g711_5fsamples_0',['G711_SAMPLES',['../janus__audiobridge_8c.html#a33b9be0a41e88ee12617ab9a59210d2e',1,'janus_audiobridge.c']]],
  ['g722_5fpt_1',['G722_PT',['../rtp_8c.html#ade205f76b9085dba0121f07629b470cb',1,'rtp.c']]]
];
