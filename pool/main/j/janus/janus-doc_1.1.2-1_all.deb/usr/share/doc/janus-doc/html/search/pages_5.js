var searchData=
[
  ['janus_20_2d_20general_20purpose_20webrtc_20server_0',['Janus - General purpose WebRTC server',['../index.html',1,'']]],
  ['janus_20as_20a_20daemon_2fservice_1',['Janus as a daemon/service',['../service.html',1,'']]],
  ['janus_20textroom_20documentation_2',['Janus TextRoom documentation',['../textroom.html',1,'']]],
  ['javascript_20_28duktape_29_20plugin_20documentation_3',['JavaScript (Duktape) plugin documentation',['../duktape.html',1,'']]],
  ['javascript_20api_4',['JavaScript API',['../JS.html',1,'']]]
];
