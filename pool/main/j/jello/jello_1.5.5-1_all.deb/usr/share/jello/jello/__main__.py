import jello.cli

jello.cli.main()
