"""jello - query JSON at the command line with python syntax"""


__version__ = '1.5.5'
AUTHOR = 'Kelly Brazil'
WEBSITE = 'https://github.com/kellyjonbrazil/jello'
COPYRIGHT = '© 2020-2023 Kelly Brazil'
LICENSE = 'MIT License'
