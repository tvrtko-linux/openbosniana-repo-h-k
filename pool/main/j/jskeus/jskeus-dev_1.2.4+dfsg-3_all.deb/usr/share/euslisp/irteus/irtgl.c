/* ./irtgl.c :  entry=irtgl */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "irtgl.h"
#pragma init (register_irtgl)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___irtgl();
extern pointer build_quote_vector();
static int register_irtgl()
  { add_module_initializer("___irtgl", ___irtgl);}

static pointer irtglF1set_stereo_gl_attribute();
static pointer irtglF2reset_gl_attribute();
static pointer irtglF3delete_displaylist_id();
static pointer irtglF4transpose_image_rows();
static pointer irtglF5draw_globjects();
static pointer irtglF6draw_glbody();
static pointer irtglF7find_color();
static pointer irtglF8transparent();
static pointer irtglF9make_glvertices_from_faceset();
static pointer irtglF10make_glvertices_from_faces();
static pointer irtglF11_dump_wrl_shape();
static pointer irtglF12write_wrl_from_glvertices();

/*set-stereo-gl-attribute*/
static pointer irtglF1set_stereo_gl_attribute(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	ctx->vsp=local+0;
	w=(pointer)irtglF2reset_gl_attribute(ctx,0,local+0); /*reset-gl-attribute*/
	local[0]= loadglobal(fqv[0]);
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)ADD1(ctx,1,local+0); /*1+*/
	local[0]= w;
	local[1]= fqv[1];
	local[2]= fqv[2];
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,3,local+0,&ftab[0],fqv[3]); /*make-array*/
	local[0]= w;
	local[1]= local[0];
	local[2]= loadglobal(fqv[0]);
	ctx->vsp=local+3;
	w=(pointer)VECREPLACE(ctx,2,local+1); /*system::vector-replace*/
	local[1]= local[0];
	local[2]= loadglobal(fqv[0]);
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SUB1(ctx,1,local+2); /*1-*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)6L);
	ctx->vsp=local+4;
	w=(pointer)SETELT(ctx,3,local+1); /*setelt*/
	local[1]= local[0];
	storeglobal(fqv[0],local[1]);
	w = local[1];
	local[0]= w;
irtglBLK13:
	ctx->vsp=local; return(local[0]);}

/*reset-gl-attribute*/
static pointer irtglF2reset_gl_attribute(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= makeint((eusinteger_t)4L);
	local[1]= makeint((eusinteger_t)8L);
	local[2]= makeint((eusinteger_t)1L);
	local[3]= makeint((eusinteger_t)9L);
	local[4]= makeint((eusinteger_t)1L);
	local[5]= makeint((eusinteger_t)10L);
	local[6]= makeint((eusinteger_t)1L);
	local[7]= makeint((eusinteger_t)5L);
	local[8]= makeint((eusinteger_t)12L);
	local[9]= makeint((eusinteger_t)1L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKINTVECTOR(ctx,11,local+0); /*integer-vector*/
	local[0]= w;
	storeglobal(fqv[0],w);
	w = local[0];
	local[0]= w;
irtglBLK14:
	ctx->vsp=local; return(local[0]);}

/*delete-displaylist-id*/
static pointer irtglF3delete_displaylist_id(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	if (!isnum(w)) goto irtglCON17;
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,2,local+0,&ftab[1],fqv[4]); /*gldeletelists*/
	local[0]= w;
	goto irtglCON16;
irtglCON17:
	local[0]= NIL;
	local[1]= argv[0];
irtglWHL19:
	if (local[1]==NIL) goto irtglWHX20;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= loadglobal(fqv[5]);
	local[4]= fqv[6];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtglCLO22,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[2])(ctx,4,local+2,&ftab[2],fqv[7]); /*find*/
	local[2]= w;
	if (local[2]==NIL) goto irtglIF23;
	local[3]= local[2];
	local[4]= fqv[8];
	local[5]= fqv[9];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	ctx->vsp=local+4;
	w=(*ftab[3])(ctx,1,local+3,&ftab[3],fqv[10]); /*glislist*/
	if (w==NIL) goto irtglCON26;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,2,local+3,&ftab[1],fqv[4]); /*gldeletelists*/
	local[3]= w;
	goto irtglCON25;
irtglCON26:
	local[3]= fqv[11];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SIGERROR(ctx,2,local+3); /*error*/
	local[3]= w;
	goto irtglCON25;
irtglCON27:
	local[3]= NIL;
irtglCON25:
	goto irtglIF24;
irtglIF23:
	local[3]= fqv[12];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SIGERROR(ctx,2,local+3); /*error*/
	local[3]= w;
irtglIF24:
	w = local[3];
	goto irtglWHL19;
irtglWHX20:
	local[2]= NIL;
irtglBLK21:
	w = NIL;
	local[0]= w;
	goto irtglCON16;
irtglCON18:
	local[0]= NIL;
irtglCON16:
	w = local[0];
	local[0]= w;
irtglBLK15:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtglCLO22(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[8];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	w = *(ovafptr(w,fqv[13]));
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*transpose-image-rows*/
static pointer irtglF4transpose_image_rows(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto irtglENT30;}
	local[0]= NIL;
irtglENT30:
irtglENT29:
	if (n>2) maerror();
	local[1]= argv[0];
	local[2]= fqv[14];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[15];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[16];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[17];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	if (local[0]==NIL) goto irtglCON32;
	local[4]= argv[0];
	local[5]= fqv[14];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[0];
	local[6]= fqv[14];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	if (w!=local[4]) goto irtglAND35;
	local[4]= argv[0];
	local[5]= fqv[15];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[0];
	local[6]= fqv[15];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	if (w!=local[4]) goto irtglAND35;
	local[4]= argv[0];
	local[5]= fqv[16];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[0];
	local[6]= fqv[16];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	if (w!=local[4]) goto irtglAND35;
	goto irtglIF33;
irtglAND35:
	local[4]= fqv[18];
	ctx->vsp=local+5;
	w=(pointer)SIGERROR(ctx,1,local+4); /*error*/
	local[4]= w;
	goto irtglIF34;
irtglIF33:
	local[4]= NIL;
irtglIF34:
	local[4]= local[1];
	local[5]= local[2];
	local[6]= local[3];
	local[7]= local[0];
	local[8]= fqv[17];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[4])(ctx,4,local+4,&ftab[4],fqv[19]); /*ctranspose-image-rows*/
	local[4]= local[0];
	goto irtglCON31;
irtglCON32:
	local[4]= local[1];
	local[5]= local[2];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(*ftab[4])(ctx,3,local+4,&ftab[4],fqv[19]); /*ctranspose-image-rows*/
	local[4]= argv[0];
	goto irtglCON31;
irtglCON36:
	local[4]= NIL;
irtglCON31:
	w = local[4];
	local[0]= w;
irtglBLK28:
	ctx->vsp=local; return(local[0]);}

/*:color*/
static pointer irtglM37glviewsurface_color(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtglENT40;}
	local[0]= NIL;
irtglENT40:
irtglENT39:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtglIF41;
	local[1]= argv[0];
	local[2]= fqv[20];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto irtglIF42;
irtglIF41:
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,4,local+1); /*float-vector*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)2816L);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(*ftab[5])(ctx,2,local+2,&ftab[5],fqv[21]); /*glgetfloatv*/
	local[2]= local[1];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)3L);
	ctx->vsp=local+5;
	w=(pointer)SUBSEQ(ctx,3,local+2); /*subseq*/
	local[1]= w;
irtglIF42:
	w = local[1];
	local[0]= w;
irtglBLK38:
	ctx->vsp=local; return(local[0]);}

/*:line-width*/
static pointer irtglM43glviewsurface_line_width(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtglENT46;}
	local[0]= NIL;
irtglENT46:
irtglENT45:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtglIF47;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)EUSFLOAT(ctx,1,local+1); /*float*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,1,local+1,&ftab[6],fqv[22]); /*gllinewidth*/
	local[1]= w;
	goto irtglIF48;
irtglIF47:
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)MKFLTVEC(ctx,1,local+1); /*float-vector*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)2849L);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(*ftab[5])(ctx,2,local+2,&ftab[5],fqv[21]); /*glgetfloatv*/
	local[2]= local[1];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[1]= w;
irtglIF48:
	w = local[1];
	local[0]= w;
irtglBLK44:
	ctx->vsp=local; return(local[0]);}

/*:point-size*/
static pointer irtglM49glviewsurface_point_size(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtglENT52;}
	local[0]= NIL;
irtglENT52:
irtglENT51:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtglIF53;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)EUSFLOAT(ctx,1,local+1); /*float*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[7])(ctx,1,local+1,&ftab[7],fqv[23]); /*glpointsize*/
	local[1]= w;
	goto irtglIF54;
irtglIF53:
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)MKFLTVEC(ctx,1,local+1); /*float-vector*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)2833L);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(*ftab[5])(ctx,2,local+2,&ftab[5],fqv[21]); /*glgetfloatv*/
	local[2]= local[1];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[1]= w;
irtglIF54:
	w = local[1];
	local[0]= w;
irtglBLK50:
	ctx->vsp=local; return(local[0]);}

/*:3d-point*/
static pointer irtglM55glviewsurface_3d_point(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[24], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtglKEY57;
	local[0] = T;
irtglKEY57:
	if (n & (1<<1)) goto irtglKEY58;
	local[1] = T;
irtglKEY58:
	if (local[0]==NIL) goto irtglIF59;
	local[2]= makeint((eusinteger_t)2929L);
	ctx->vsp=local+3;
	w=(*ftab[8])(ctx,1,local+2,&ftab[8],fqv[25]); /*gldisable*/
	local[2]= w;
	goto irtglIF60;
irtglIF59:
	local[2]= NIL;
irtglIF60:
	if (local[1]==NIL) goto irtglIF61;
	local[2]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+3;
	w=(*ftab[8])(ctx,1,local+2,&ftab[8],fqv[25]); /*gldisable*/
	local[2]= w;
	goto irtglIF62;
irtglIF61:
	local[2]= NIL;
irtglIF62:
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(*ftab[9])(ctx,1,local+2,&ftab[9],fqv[26]); /*glbegin*/
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(*ftab[10])(ctx,1,local+2,&ftab[10],fqv[27]); /*glvertex3fv*/
	ctx->vsp=local+2;
	w=(*ftab[11])(ctx,0,local+2,&ftab[11],fqv[28]); /*glend*/
	if (local[0]==NIL) goto irtglIF63;
	local[2]= makeint((eusinteger_t)2929L);
	ctx->vsp=local+3;
	w=(*ftab[12])(ctx,1,local+2,&ftab[12],fqv[29]); /*glenable*/
	local[2]= w;
	goto irtglIF64;
irtglIF63:
	local[2]= NIL;
irtglIF64:
	if (local[1]==NIL) goto irtglIF65;
	local[2]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+3;
	w=(*ftab[12])(ctx,1,local+2,&ftab[12],fqv[29]); /*glenable*/
	local[2]= w;
	goto irtglIF66;
irtglIF65:
	local[2]= NIL;
irtglIF66:
	w = local[2];
	local[0]= w;
irtglBLK56:
	ctx->vsp=local; return(local[0]);}

/*:3d-line*/
static pointer irtglM67glviewsurface_3d_line(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[30], &argv[4], n-4, local+0, 0);
	if (n & (1<<0)) goto irtglKEY69;
	local[0] = T;
irtglKEY69:
	if (n & (1<<1)) goto irtglKEY70;
	local[1] = T;
irtglKEY70:
	if (local[0]==NIL) goto irtglIF71;
	local[2]= makeint((eusinteger_t)2929L);
	ctx->vsp=local+3;
	w=(*ftab[8])(ctx,1,local+2,&ftab[8],fqv[25]); /*gldisable*/
	local[2]= w;
	goto irtglIF72;
irtglIF71:
	local[2]= NIL;
irtglIF72:
	if (local[1]==NIL) goto irtglIF73;
	local[2]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+3;
	w=(*ftab[8])(ctx,1,local+2,&ftab[8],fqv[25]); /*gldisable*/
	local[2]= w;
	goto irtglIF74;
irtglIF73:
	local[2]= NIL;
irtglIF74:
	local[2]= makeint((eusinteger_t)3L);
	ctx->vsp=local+3;
	w=(*ftab[9])(ctx,1,local+2,&ftab[9],fqv[26]); /*glbegin*/
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(*ftab[10])(ctx,1,local+2,&ftab[10],fqv[27]); /*glvertex3fv*/
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(*ftab[10])(ctx,1,local+2,&ftab[10],fqv[27]); /*glvertex3fv*/
	ctx->vsp=local+2;
	w=(*ftab[11])(ctx,0,local+2,&ftab[11],fqv[28]); /*glend*/
	if (local[0]==NIL) goto irtglIF75;
	local[2]= makeint((eusinteger_t)2929L);
	ctx->vsp=local+3;
	w=(*ftab[12])(ctx,1,local+2,&ftab[12],fqv[29]); /*glenable*/
	local[2]= w;
	goto irtglIF76;
irtglIF75:
	local[2]= NIL;
irtglIF76:
	if (local[1]==NIL) goto irtglIF77;
	local[2]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+3;
	w=(*ftab[12])(ctx,1,local+2,&ftab[12],fqv[29]); /*glenable*/
	local[2]= w;
	goto irtglIF78;
irtglIF77:
	local[2]= NIL;
irtglIF78:
	w = local[2];
	local[0]= w;
irtglBLK68:
	ctx->vsp=local; return(local[0]);}

/*:3d-lines*/
static pointer irtglM79glviewsurface_3d_lines(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[31], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtglKEY81;
	local[0] = T;
irtglKEY81:
	if (n & (1<<1)) goto irtglKEY82;
	local[1] = T;
irtglKEY82:
	if (local[0]==NIL) goto irtglIF83;
	local[2]= makeint((eusinteger_t)2929L);
	ctx->vsp=local+3;
	w=(*ftab[8])(ctx,1,local+2,&ftab[8],fqv[25]); /*gldisable*/
	local[2]= w;
	goto irtglIF84;
irtglIF83:
	local[2]= NIL;
irtglIF84:
	if (local[1]==NIL) goto irtglIF85;
	local[2]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+3;
	w=(*ftab[8])(ctx,1,local+2,&ftab[8],fqv[25]); /*gldisable*/
	local[2]= w;
	goto irtglIF86;
irtglIF85:
	local[2]= NIL;
irtglIF86:
	local[2]= makeint((eusinteger_t)3L);
	ctx->vsp=local+3;
	w=(*ftab[9])(ctx,1,local+2,&ftab[9],fqv[26]); /*glbegin*/
	local[2]= NIL;
	local[3]= argv[2];
irtglWHL87:
	if (local[3]==NIL) goto irtglWHX88;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(*ftab[10])(ctx,1,local+4,&ftab[10],fqv[27]); /*glvertex3fv*/
	goto irtglWHL87;
irtglWHX88:
	local[4]= NIL;
irtglBLK89:
	w = NIL;
	ctx->vsp=local+2;
	w=(*ftab[11])(ctx,0,local+2,&ftab[11],fqv[28]); /*glend*/
	if (local[0]==NIL) goto irtglIF90;
	local[2]= makeint((eusinteger_t)2929L);
	ctx->vsp=local+3;
	w=(*ftab[12])(ctx,1,local+2,&ftab[12],fqv[29]); /*glenable*/
	local[2]= w;
	goto irtglIF91;
irtglIF90:
	local[2]= NIL;
irtglIF91:
	if (local[1]==NIL) goto irtglIF92;
	local[2]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+3;
	w=(*ftab[12])(ctx,1,local+2,&ftab[12],fqv[29]); /*glenable*/
	local[2]= w;
	goto irtglIF93;
irtglIF92:
	local[2]= NIL;
irtglIF93:
	w = local[2];
	local[0]= w;
irtglBLK80:
	ctx->vsp=local; return(local[0]);}

/*:makecurrent*/
static pointer irtglM94glviewsurface_makecurrent(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[32]);
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= argv[0]->c.obj.iv[15];
	ctx->vsp=local+3;
	w=(*ftab[13])(ctx,3,local+0,&ftab[13],fqv[33]); /*glxmakecurrent*/
	local[0]= w;
irtglBLK95:
	ctx->vsp=local; return(local[0]);}

/*:redraw*/
static pointer irtglM96glviewsurface_redraw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtglRST98:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0];
	local[2]= fqv[34];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[0]= w;
irtglBLK97:
	ctx->vsp=local; return(local[0]);}

/*:flush*/
static pointer irtglM99glviewsurface_flush(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[9];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[35];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[36]));
	local[2]= fqv[34];
	ctx->vsp=local+3;
	w=(pointer)SENDMESSAGE(ctx,3,local+0); /*send-message*/
	local[0]= w;
irtglBLK100:
	ctx->vsp=local; return(local[0]);}

/*:write-to-image-file*/
static pointer irtglM101glviewsurface_write_to_image_file(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[37], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtglKEY103;
	local[0] = makeint((eusinteger_t)0L);
irtglKEY103:
	if (n & (1<<1)) goto irtglKEY104;
	local[1] = makeint((eusinteger_t)0L);
irtglKEY104:
	if (n & (1<<2)) goto irtglKEY105;
	local[2] = argv[0]->c.obj.iv[5];
irtglKEY105:
	if (n & (1<<3)) goto irtglKEY106;
	local[3] = argv[0]->c.obj.iv[6];
irtglKEY106:
	local[4]= argv[0];
	local[5]= fqv[38];
	local[6]= fqv[39];
	local[7]= local[0];
	local[8]= fqv[40];
	local[9]= local[1];
	local[10]= fqv[15];
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)SUB1(ctx,1,local+11); /*1-*/
	local[11]= w;
	local[12]= fqv[14];
	local[13]= local[3];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,10,local+4); /*send*/
	local[4]= w;
	local[5]= argv[2];
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(*ftab[14])(ctx,2,local+5,&ftab[14],fqv[41]); /*image::write-image-file*/
	local[0]= w;
irtglBLK102:
	ctx->vsp=local; return(local[0]);}

/*:getglimage*/
static pointer irtglM107glviewsurface_getglimage(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[42], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtglKEY109;
	local[0] = makeint((eusinteger_t)0L);
irtglKEY109:
	if (n & (1<<1)) goto irtglKEY110;
	local[1] = makeint((eusinteger_t)0L);
irtglKEY110:
	if (n & (1<<2)) goto irtglKEY111;
	local[2] = argv[0]->c.obj.iv[5];
irtglKEY111:
	if (n & (1<<3)) goto irtglKEY112;
	local[3] = argv[0]->c.obj.iv[6];
irtglKEY112:
	if (n & (1<<4)) goto irtglKEY113;
	local[6]= local[2];
	local[7]= local[3];
	local[8]= makeint((eusinteger_t)3L);
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,3,local+6); /***/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[15])(ctx,1,local+6,&ftab[15],fqv[43]); /*make-string*/
	local[4] = w;
irtglKEY113:
	if (n & (1<<5)) goto irtglKEY114;
	local[5] = NIL;
irtglKEY114:
	local[6]= loadglobal(fqv[44]);
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,1,local+6); /*instantiate*/
	local[6]= w;
	local[7]= local[6];
	local[8]= fqv[45];
	local[9]= local[2];
	local[10]= local[3];
	local[11]= local[4];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,5,local+7); /*send*/
	w = local[6];
	local[6]= w;
	local[7]= argv[0];
	local[8]= fqv[9];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= makeint((eusinteger_t)1028L);
	ctx->vsp=local+8;
	w=(*ftab[16])(ctx,1,local+7,&ftab[16],fqv[46]); /*glreadbuffer*/
	local[7]= makeint((eusinteger_t)3333L);
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(*ftab[17])(ctx,2,local+7,&ftab[17],fqv[47]); /*glpixelstorei*/
	local[7]= local[0];
	local[8]= local[1];
	local[9]= local[2];
	local[10]= local[3];
	local[11]= makeint((eusinteger_t)6407L);
	local[12]= makeint((eusinteger_t)5121L);
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(*ftab[18])(ctx,7,local+7,&ftab[18],fqv[48]); /*glreadpixels*/
	if (local[5]==NIL) goto irtglIF115;
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(*ftab[19])(ctx,1,local+7,&ftab[19],fqv[49]); /*user::dvector2float-bytestring*/
	local[7]= w;
	local[8]= local[0];
	local[9]= local[1];
	local[10]= local[2];
	local[11]= local[3];
	local[12]= makeint((eusinteger_t)6402L);
	local[13]= makeint((eusinteger_t)5126L);
	local[14]= local[7];
	ctx->vsp=local+15;
	w=(*ftab[18])(ctx,7,local+8,&ftab[18],fqv[48]); /*glreadpixels*/
	local[8]= local[7];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(*ftab[20])(ctx,2,local+8,&ftab[20],fqv[50]); /*user::float-bytestring2dvector*/
	local[7]= w;
	goto irtglIF116;
irtglIF115:
	local[7]= NIL;
irtglIF116:
	local[7]= local[6];
	ctx->vsp=local+8;
	w=(pointer)irtglF4transpose_image_rows(ctx,1,local+7); /*transpose-image-rows*/
	w = local[6];
	local[0]= w;
irtglBLK108:
	ctx->vsp=local; return(local[0]);}

/*:string*/
static pointer irtglM117glviewsurface_string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	if (n>=6) { local[0]=(argv[5]); goto irtglENT120;}
	local[0]= loadglobal(fqv[51]);
irtglENT120:
irtglENT119:
	if (n>6) maerror();
	local[1]= argv[0];
	local[2]= fqv[9];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= makeint((eusinteger_t)5889L);
	ctx->vsp=local+2;
	w=(*ftab[21])(ctx,1,local+1,&ftab[21],fqv[52]); /*glmatrixmode*/
	ctx->vsp=local+1;
	w=(*ftab[22])(ctx,0,local+1,&ftab[22],fqv[53]); /*glpushmatrix*/
	local[1]= argv[0];
	local[2]= fqv[54];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[55];
	ctx->vsp=local+3;
	w=(pointer)GETPROP(ctx,2,local+1); /*get*/
	local[1]= w;
	if (local[0]==local[1]) goto irtglIF121;
	local[1]= argv[0];
	local[2]= local[0];
	local[3]= fqv[55];
	ctx->vsp=local+4;
	w=(pointer)PUTPROP(ctx,3,local+1); /*putprop*/
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)32L);
	local[3]= makeint((eusinteger_t)96L);
	local[4]= makeint((eusinteger_t)1000L);
	w = makeint((eusinteger_t)32L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[4]= (pointer)((eusinteger_t)local[4] + (eusinteger_t)w);
	ctx->vsp=local+5;
	w=(*ftab[23])(ctx,4,local+1,&ftab[23],fqv[56]); /*glxusexfont*/
	local[1]= w;
	goto irtglIF122;
irtglIF121:
	local[1]= NIL;
irtglIF122:
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)ROUND(ctx,1,local+1); /*round*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[14];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)ROUND(ctx,1,local+3); /*round*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,2,local+2); /*-*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[24])(ctx,2,local+1,&ftab[24],fqv[57]); /*glrasterpos2i*/
	local[1]= makeint((eusinteger_t)1000L);
	ctx->vsp=local+2;
	w=(*ftab[25])(ctx,1,local+1,&ftab[25],fqv[58]); /*gllistbase*/
	local[1]= argv[4];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)5121L);
	local[3]= argv[4];
	ctx->vsp=local+4;
	w=(*ftab[26])(ctx,3,local+1,&ftab[26],fqv[59]); /*glcalllists*/
	local[1]= argv[0];
	local[2]= fqv[60];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= makeint((eusinteger_t)5889L);
	ctx->vsp=local+2;
	w=(*ftab[21])(ctx,1,local+1,&ftab[21],fqv[52]); /*glmatrixmode*/
	ctx->vsp=local+1;
	w=(*ftab[27])(ctx,0,local+1,&ftab[27],fqv[61]); /*glpopmatrix*/
	local[1]= makeint((eusinteger_t)5888L);
	ctx->vsp=local+2;
	w=(*ftab[21])(ctx,1,local+1,&ftab[21],fqv[52]); /*glmatrixmode*/
	local[0]= w;
irtglBLK118:
	ctx->vsp=local; return(local[0]);}

/*draw-globjects*/
static pointer irtglF5draw_globjects(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[62], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtglKEY124;
	local[0] = T;
irtglKEY124:
	if (n & (1<<1)) goto irtglKEY125;
	local[1] = T;
irtglKEY125:
	if (n & (1<<2)) goto irtglKEY126;
	local[2] = makeint((eusinteger_t)150L);
irtglKEY126:
	if (n & (1<<3)) goto irtglKEY127;
	local[3] = NIL;
irtglKEY127:
	if (n & (1<<4)) goto irtglKEY128;
	local[4] = fqv[63];
irtglKEY128:
	local[5]= NIL;
	local[6]= argv[0];
	local[7]= fqv[64];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= fqv[8];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[28])(ctx,2,local+6,&ftab[28],fqv[65]); /*resetperspective*/
	if (local[0]==NIL) goto irtglIF129;
	local[6]= argv[0];
	local[7]= fqv[8];
	local[8]= fqv[66];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	goto irtglIF130;
irtglIF129:
	local[6]= NIL;
irtglIF130:
	local[6]= argv[0];
	local[7]= fqv[8];
	local[8]= fqv[67];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[5] = w;
	if (local[2]==NIL) goto irtglIF131;
	w = local[2];
	if (!isnum(w)) goto irtglIF133;
	local[6]= local[2];
	goto irtglIF134;
irtglIF133:
	local[6]= makeint((eusinteger_t)150L);
irtglIF134:
	local[7]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+8;
	w=(*ftab[8])(ctx,1,local+7,&ftab[8],fqv[25]); /*gldisable*/
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(*ftab[9])(ctx,1,local+7,&ftab[9],fqv[26]); /*glbegin*/
	local[7]= fqv[68];
	ctx->vsp=local+8;
	w=(*ftab[29])(ctx,1,local+7,&ftab[29],fqv[69]); /*glcolor3fv*/
	local[7]= fqv[70];
	ctx->vsp=local+8;
	w=(*ftab[10])(ctx,1,local+7,&ftab[10],fqv[27]); /*glvertex3fv*/
	local[7]= local[6];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[10])(ctx,1,local+7,&ftab[10],fqv[27]); /*glvertex3fv*/
	local[7]= fqv[71];
	ctx->vsp=local+8;
	w=(*ftab[29])(ctx,1,local+7,&ftab[29],fqv[69]); /*glcolor3fv*/
	local[7]= fqv[72];
	ctx->vsp=local+8;
	w=(*ftab[10])(ctx,1,local+7,&ftab[10],fqv[27]); /*glvertex3fv*/
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[6];
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[10])(ctx,1,local+7,&ftab[10],fqv[27]); /*glvertex3fv*/
	local[7]= fqv[73];
	ctx->vsp=local+8;
	w=(*ftab[29])(ctx,1,local+7,&ftab[29],fqv[69]); /*glcolor3fv*/
	local[7]= fqv[74];
	ctx->vsp=local+8;
	w=(*ftab[10])(ctx,1,local+7,&ftab[10],fqv[27]); /*glvertex3fv*/
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[10])(ctx,1,local+7,&ftab[10],fqv[27]); /*glvertex3fv*/
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(*ftab[11])(ctx,1,local+7,&ftab[11],fqv[28]); /*glend*/
	local[7]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+8;
	w=(*ftab[12])(ctx,1,local+7,&ftab[12],fqv[29]); /*glenable*/
	local[6]= w;
	goto irtglIF132;
irtglIF131:
	local[6]= NIL;
irtglIF132:
	if (local[3]==NIL) goto irtglIF135;
	w = local[3];
	if (!isnum(w)) goto irtglIF137;
	local[6]= local[3];
	goto irtglIF138;
irtglIF137:
	local[6]= makeint((eusinteger_t)1000L);
irtglIF138:
	local[7]= makeint((eusinteger_t)5000L);
	local[8]= local[7];
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,1,local+8); /*-*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+10;
	w=(*ftab[8])(ctx,1,local+9,&ftab[8],fqv[25]); /*gldisable*/
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(*ftab[9])(ctx,1,local+9,&ftab[9],fqv[26]); /*glbegin*/
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(*ftab[29])(ctx,1,local+9,&ftab[29],fqv[69]); /*glcolor3fv*/
	local[9]= local[8];
irtglTAG140:
	local[10]= local[9];
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)GREATERP(ctx,2,local+10); /*>*/
	if (w==NIL) goto irtglIF141;
	w = NIL;
	ctx->vsp=local+10;
	local[9]=w;
	goto irtglBLK139;
	goto irtglIF142;
irtglIF141:
	local[10]= NIL;
irtglIF142:
	local[10]= local[8];
irtglTAG144:
	local[11]= local[10];
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(pointer)GREATERP(ctx,2,local+11); /*>*/
	if (w==NIL) goto irtglIF145;
	w = NIL;
	ctx->vsp=local+11;
	local[10]=w;
	goto irtglBLK143;
	goto irtglIF146;
irtglIF145:
	local[11]= NIL;
irtglIF146:
	local[11]= local[10];
	local[12]= local[8];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)MKFLTVEC(ctx,3,local+11); /*float-vector*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[10])(ctx,1,local+11,&ftab[10],fqv[27]); /*glvertex3fv*/
	local[11]= local[10];
	local[12]= local[7];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)MKFLTVEC(ctx,3,local+11); /*float-vector*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[10])(ctx,1,local+11,&ftab[10],fqv[27]); /*glvertex3fv*/
	local[11]= local[8];
	local[12]= local[9];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)MKFLTVEC(ctx,3,local+11); /*float-vector*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[10])(ctx,1,local+11,&ftab[10],fqv[27]); /*glvertex3fv*/
	local[11]= local[7];
	local[12]= local[9];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)MKFLTVEC(ctx,3,local+11); /*float-vector*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[10])(ctx,1,local+11,&ftab[10],fqv[27]); /*glvertex3fv*/
	local[11]= local[10];
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	local[11]= w;
	local[10] = local[11];
	w = NIL;
	ctx->vsp=local+11;
	goto irtglTAG144;
	w = NIL;
	local[10]= w;
irtglBLK143:
	local[10]= local[9];
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[10]= w;
	local[9] = local[10];
	w = NIL;
	ctx->vsp=local+10;
	goto irtglTAG140;
	w = NIL;
	local[9]= w;
irtglBLK139:
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(*ftab[11])(ctx,1,local+9,&ftab[11],fqv[28]); /*glend*/
	local[9]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+10;
	w=(*ftab[12])(ctx,1,local+9,&ftab[12],fqv[29]); /*glenable*/
	local[6]= w;
	goto irtglIF136;
irtglIF135:
	local[6]= NIL;
irtglIF136:
	local[6]= makeint((eusinteger_t)3042L);
	ctx->vsp=local+7;
	w=(*ftab[8])(ctx,1,local+6,&ftab[8],fqv[25]); /*gldisable*/
	local[6]= argv[0];
	local[7]= fqv[8];
	local[8]= fqv[67];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= NIL;
	local[7]= argv[1];
irtglWHL147:
	if (local[7]==NIL) goto irtglWHX148;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= local[6];
	local[9]= fqv[75];
	ctx->vsp=local+10;
	w=(*ftab[30])(ctx,2,local+8,&ftab[30],fqv[76]); /*find-method*/
	if (w==NIL) goto irtglCON151;
	local[8]= local[6];
	local[9]= fqv[75];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	goto irtglCON150;
irtglCON151:
	local[8]= local[6];
	local[9]= loadglobal(fqv[77]);
	ctx->vsp=local+10;
	w=(pointer)DERIVEDP(ctx,2,local+8); /*derivedp*/
	if (w==NIL) goto irtglCON152;
	local[8]= argv[0];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)irtglF6draw_glbody(ctx,2,local+8); /*draw-glbody*/
	local[8]= w;
	goto irtglCON150;
irtglCON152:
	local[8]= local[6];
	local[9]= fqv[78];
	ctx->vsp=local+10;
	w=(*ftab[30])(ctx,2,local+8,&ftab[30],fqv[76]); /*find-method*/
	if (w==NIL) goto irtglCON153;
	local[8]= local[6];
	local[9]= fqv[78];
	local[10]= fqv[79];
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= w;
	goto irtglCON150;
irtglCON153:
	local[8]= fqv[80];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(*ftab[31])(ctx,2,local+8,&ftab[31],fqv[81]); /*warn*/
	local[8]= w;
	goto irtglCON150;
irtglCON154:
	local[8]= NIL;
irtglCON150:
	goto irtglWHL147;
irtglWHX148:
	local[8]= NIL;
irtglBLK149:
	w = NIL;
	if (local[1]==NIL) goto irtglIF155;
	local[6]= argv[0];
	local[7]= fqv[8];
	local[8]= fqv[34];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	goto irtglIF156;
irtglIF155:
	local[6]= NIL;
irtglIF156:
	w = local[6];
	local[0]= w;
irtglBLK123:
	ctx->vsp=local; return(local[0]);}

/*draw-glbody*/
static pointer irtglF6draw_glbody(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[8];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= *(ovafptr(w,fqv[13]));
	local[1]= local[0];
	local[2]= argv[1];
	local[3]= fqv[82];
	ctx->vsp=local+4;
	w=(pointer)GETPROP(ctx,2,local+2); /*get*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)ASSQ(ctx,2,local+1); /*assq*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	local[2]= local[0];
	local[3]= argv[1];
	local[4]= fqv[83];
	ctx->vsp=local+5;
	w=(pointer)GETPROP(ctx,2,local+3); /*get*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)ASSQ(ctx,2,local+2); /*assq*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.cdr;
	local[3]= argv[1];
	local[4]= fqv[84];
	ctx->vsp=local+5;
	w=(pointer)GETPROP(ctx,2,local+3); /*get*/
	local[3]= w;
	if (local[3]!=NIL) goto irtglIF158;
	local[4]= makeflt(5.0000000000000000000000e-01);
	local[5]= makeflt(5.0000000000000000000000e-01);
	local[6]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,3,local+4); /*float-vector*/
	local[3] = w;
	local[4]= local[3];
	goto irtglIF159;
irtglIF158:
	local[4]= NIL;
irtglIF159:
	local[4]= local[3];
	ctx->vsp=local+5;
	w=(pointer)VECTORP(ctx,1,local+4); /*vectorp*/
	if (w!=NIL) goto irtglIF160;
	local[4]= local[3];
	ctx->vsp=local+5;
	w=(pointer)irtglF7find_color(ctx,1,local+4); /*find-color*/
	local[3] = w;
	local[4]= argv[1];
	local[5]= local[3];
	local[6]= fqv[84];
	ctx->vsp=local+7;
	w=(pointer)PUTPROP(ctx,3,local+4); /*putprop*/
	local[4]= w;
	goto irtglIF161;
irtglIF160:
	local[4]= NIL;
irtglIF161:
	if (local[1]==NIL) goto irtglCON163;
	local[4]= argv[1];
	local[5]= fqv[85];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= fqv[86];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[22])(ctx,0,local+5,&ftab[22],fqv[53]); /*glpushmatrix*/
	local[5]= local[4];
	local[6]= loadglobal(fqv[87]);
	ctx->vsp=local+7;
	w=(pointer)TRANSPOSE(ctx,2,local+5); /*transpose*/
	local[5]= w->c.obj.iv[1];
	ctx->vsp=local+6;
	w=(*ftab[32])(ctx,1,local+5,&ftab[32],fqv[88]); /*glmultmatrixf*/
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(*ftab[33])(ctx,1,local+5,&ftab[33],fqv[89]); /*glcalllist*/
	ctx->vsp=local+5;
	w=(*ftab[27])(ctx,0,local+5,&ftab[27],fqv[61]); /*glpopmatrix*/
	local[4]= w;
	goto irtglCON162;
irtglCON163:
	if (local[2]==NIL) goto irtglCON164;
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(*ftab[34])(ctx,1,local+4,&ftab[34],fqv[90]); /*glgenlists*/
	local[4]= w;
	local[5]= local[4];
	local[6]= makeint((eusinteger_t)4864L);
	ctx->vsp=local+7;
	w=(*ftab[35])(ctx,2,local+5,&ftab[35],fqv[91]); /*glnewlist*/
	local[5]= makeint((eusinteger_t)4294967295L);
	ctx->vsp=local+6;
	w=(*ftab[36])(ctx,1,local+5,&ftab[36],fqv[92]); /*glpushattrib*/
	local[5]= makeint((eusinteger_t)2929L);
	ctx->vsp=local+6;
	w=(*ftab[37])(ctx,1,local+5,&ftab[37],fqv[93]); /*gldepthfunc*/
	local[5]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+6;
	w=(*ftab[8])(ctx,1,local+5,&ftab[8],fqv[25]); /*gldisable*/
	local[5]= fqv[94];
	ctx->vsp=local+6;
	w=(*ftab[29])(ctx,1,local+5,&ftab[29],fqv[69]); /*glcolor3fv*/
	local[5]= NIL;
	local[6]= argv[1];
	local[7]= fqv[95];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
irtglWHL165:
	if (local[6]==NIL) goto irtglWHX166;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(*ftab[9])(ctx,1,local+7,&ftab[9],fqv[26]); /*glbegin*/
	local[7]= NIL;
	local[8]= local[5];
	local[9]= fqv[96];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
irtglWHL168:
	if (local[8]==NIL) goto irtglWHX169;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[9];
	local[7] = w;
	local[9]= argv[1];
	local[10]= fqv[97];
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[10])(ctx,1,local+9,&ftab[10],fqv[27]); /*glvertex3fv*/
	goto irtglWHL168;
irtglWHX169:
	local[9]= NIL;
irtglBLK170:
	w = NIL;
	ctx->vsp=local+7;
	w=(*ftab[11])(ctx,0,local+7,&ftab[11],fqv[28]); /*glend*/
	goto irtglWHL165;
irtglWHX166:
	local[7]= NIL;
irtglBLK167:
	w = NIL;
	local[5]= makeint((eusinteger_t)32823L);
	ctx->vsp=local+6;
	w=(*ftab[12])(ctx,1,local+5,&ftab[12],fqv[29]); /*glenable*/
	local[5]= makeint((eusinteger_t)1032L);
	local[6]= makeint((eusinteger_t)6914L);
	ctx->vsp=local+7;
	w=(*ftab[38])(ctx,2,local+5,&ftab[38],fqv[98]); /*glpolygonmode*/
	local[5]= makeflt(1.0000000000000000000000e+00);
	local[6]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(*ftab[39])(ctx,2,local+5,&ftab[39],fqv[99]); /*glpolygonoffset*/
	local[5]= fqv[100];
	ctx->vsp=local+6;
	w=(*ftab[29])(ctx,1,local+5,&ftab[29],fqv[69]); /*glcolor3fv*/
	local[5]= makeint((eusinteger_t)2884L);
	ctx->vsp=local+6;
	w=(*ftab[12])(ctx,1,local+5,&ftab[12],fqv[29]); /*glenable*/
	local[5]= makeint((eusinteger_t)1028L);
	ctx->vsp=local+6;
	w=(*ftab[40])(ctx,1,local+5,&ftab[40],fqv[101]); /*glcullface*/
	local[5]= NIL;
	local[6]= argv[1];
	local[7]= fqv[95];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
irtglWHL171:
	if (local[6]==NIL) goto irtglWHX172;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= makeint((eusinteger_t)9L);
	ctx->vsp=local+8;
	w=(*ftab[9])(ctx,1,local+7,&ftab[9],fqv[26]); /*glbegin*/
	local[7]= argv[1];
	local[8]= fqv[102];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)TRANSPOSE(ctx,1,local+7); /*transpose*/
	local[7]= w;
	local[8]= local[5];
	local[9]= fqv[103];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)TRANSFORM(ctx,2,local+7); /*transform*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[41])(ctx,1,local+7,&ftab[41],fqv[104]); /*glnormal3fv*/
	local[7]= NIL;
	local[8]= local[5];
	local[9]= fqv[105];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
irtglWHL174:
	if (local[8]==NIL) goto irtglWHX175;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[9];
	local[7] = w;
	local[9]= argv[1];
	local[10]= fqv[97];
	local[11]= local[7];
	local[12]= fqv[106];
	local[13]= local[5];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[10])(ctx,1,local+9,&ftab[10],fqv[27]); /*glvertex3fv*/
	goto irtglWHL174;
irtglWHX175:
	local[9]= NIL;
irtglBLK176:
	w = NIL;
	ctx->vsp=local+7;
	w=(*ftab[11])(ctx,0,local+7,&ftab[11],fqv[28]); /*glend*/
	goto irtglWHL171;
irtglWHX172:
	local[7]= NIL;
irtglBLK173:
	w = NIL;
	local[5]= makeint((eusinteger_t)2884L);
	ctx->vsp=local+6;
	w=(*ftab[8])(ctx,1,local+5,&ftab[8],fqv[25]); /*gldisable*/
	local[5]= makeint((eusinteger_t)32823L);
	ctx->vsp=local+6;
	w=(*ftab[8])(ctx,1,local+5,&ftab[8],fqv[25]); /*gldisable*/
	local[5]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+6;
	w=(*ftab[12])(ctx,1,local+5,&ftab[12],fqv[29]); /*glenable*/
	ctx->vsp=local+5;
	w=(*ftab[42])(ctx,0,local+5,&ftab[42],fqv[107]); /*glpopattrib*/
	ctx->vsp=local+5;
	w=(*ftab[43])(ctx,0,local+5,&ftab[43],fqv[108]); /*glendlist*/
	local[5]= argv[1];
	local[6]= local[0];
	w = local[4];
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= argv[1];
	local[8]= fqv[82];
	ctx->vsp=local+9;
	w=(pointer)GETPROP(ctx,2,local+7); /*get*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[82];
	ctx->vsp=local+8;
	w=(pointer)PUTPROP(ctx,3,local+5); /*putprop*/
	local[5]= argv[0];
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(pointer)irtglF6draw_glbody(ctx,2,local+5); /*draw-glbody*/
	local[4]= w;
	goto irtglCON162;
irtglCON164:
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(*ftab[34])(ctx,1,local+4,&ftab[34],fqv[90]); /*glgenlists*/
	local[4]= w;
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)4L);
	ctx->vsp=local+7;
	w=(pointer)NUMEQUAL(ctx,2,local+5); /*=*/
	local[5]= w;
	if (w==NIL) goto irtglAND178;
	local[5]= local[3];
	local[6]= makeint((eusinteger_t)3L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)LESSP(ctx,2,local+5); /*<*/
	local[5]= w;
irtglAND178:
	local[6]= argv[1];
	local[7]= fqv[109];
	ctx->vsp=local+8;
	w=(pointer)GETPROP(ctx,2,local+6); /*get*/
	if (w==NIL) goto irtglIF179;
	local[6]= loadglobal(fqv[110]);
	local[7]= argv[1];
	local[8]= fqv[109];
	ctx->vsp=local+9;
	w=(pointer)GETPROP(ctx,2,local+7); /*get*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,2,local+6); /*instantiate*/
	local[6]= w;
	goto irtglIF180;
irtglIF179:
	local[6]= NIL;
irtglIF180:
	local[7]= NIL;
	local[8]= local[4];
	local[9]= makeint((eusinteger_t)4864L);
	ctx->vsp=local+10;
	w=(*ftab[35])(ctx,2,local+8,&ftab[35],fqv[91]); /*glnewlist*/
	if (local[5]==NIL) goto irtglIF181;
	local[8]= makeint((eusinteger_t)3042L);
	ctx->vsp=local+9;
	w=(*ftab[12])(ctx,1,local+8,&ftab[12],fqv[29]); /*glenable*/
	local[8]= makeint((eusinteger_t)770L);
	local[9]= makeint((eusinteger_t)771L);
	ctx->vsp=local+10;
	w=(*ftab[44])(ctx,2,local+8,&ftab[44],fqv[111]); /*glblendfunc*/
	local[8]= w;
	goto irtglIF182;
irtglIF181:
	local[8]= NIL;
irtglIF182:
	local[8]= makeint((eusinteger_t)1032L);
	local[9]= makeint((eusinteger_t)5634L);
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(*ftab[45])(ctx,3,local+8,&ftab[45],fqv[112]); /*glmaterialfv*/
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)LENGTH(ctx,1,local+8); /*length*/
	local[8]= w;
	w = makeint((eusinteger_t)0L);
	if ((eusinteger_t)local[8] <= (eusinteger_t)w) goto irtglIF183;
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)LENGTH(ctx,1,local+8); /*length*/
	local[8]= w;
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(*ftab[46])(ctx,2,local+8,&ftab[46],fqv[113]); /*glgentexturesext*/
	local[8]= w;
	goto irtglIF184;
irtglIF183:
	local[8]= NIL;
irtglIF184:
	local[8]= NIL;
	local[9]= argv[1];
	local[10]= fqv[95];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
irtglWHL185:
	if (local[9]==NIL) goto irtglWHX186;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= local[8];
	local[11]= fqv[114];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	if (w==NIL) goto irtglCON189;
	local[10]= local[8];
	local[11]= fqv[115];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	if (w!=NIL) goto irtglCON189;
	local[10]= local[8];
	local[11]= fqv[109];
	ctx->vsp=local+12;
	w=(pointer)GETPROP(ctx,2,local+10); /*get*/
	local[10]= w;
	local[11]= local[8];
	local[12]= fqv[116];
	ctx->vsp=local+13;
	w=(pointer)GETPROP(ctx,2,local+11); /*get*/
	local[11]= w;
	local[12]= local[10];
	local[13]= loadglobal(fqv[44]);
	ctx->vsp=local+14;
	w=(pointer)DERIVEDP(ctx,2,local+12); /*derivedp*/
	if (w==NIL) goto irtglCON191;
	local[12]= makeint((eusinteger_t)6407L);
	goto irtglCON190;
irtglCON191:
	local[12]= local[10];
	local[13]= loadglobal(fqv[117]);
	ctx->vsp=local+14;
	w=(pointer)DERIVEDP(ctx,2,local+12); /*derivedp*/
	if (w==NIL) goto irtglCON192;
	local[12]= makeint((eusinteger_t)6409L);
	goto irtglCON190;
irtglCON192:
	local[12]= NIL;
irtglCON190:
	if (local[10]==NIL) goto irtglIF193;
	local[13]= local[10];
	local[14]= fqv[118];
	ctx->vsp=local+15;
	w=(pointer)GETPROP(ctx,2,local+13); /*get*/
	if (w!=NIL) goto irtglIF195;
	local[13]= local[6];
	local[14]= local[10];
	local[15]= argv[1];
	local[16]= fqv[109];
	ctx->vsp=local+17;
	w=(pointer)GETPROP(ctx,2,local+15); /*get*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(*ftab[47])(ctx,2,local+14,&ftab[47],fqv[119]); /*position*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	local[14]= local[10];
	local[15]= fqv[15];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= w;
	local[15]= local[10];
	local[16]= fqv[14];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	local[16]= local[10];
	local[17]= fqv[120];
	ctx->vsp=local+18;
	w=(pointer)GETPROP(ctx,2,local+16); /*get*/
	local[16]= w;
	if (w!=NIL) goto irtglOR197;
	local[16]= makeint((eusinteger_t)256L);
irtglOR197:
	local[17]= local[10];
	local[18]= fqv[121];
	ctx->vsp=local+19;
	w=(pointer)GETPROP(ctx,2,local+17); /*get*/
	local[17]= w;
	if (w!=NIL) goto irtglOR198;
	local[17]= makeint((eusinteger_t)256L);
irtglOR198:
	local[18]= makeint((eusinteger_t)1L);
	local[19]= local[14];
	local[20]= makeint((eusinteger_t)2L);
	ctx->vsp=local+21;
	w=(pointer)LOG(ctx,2,local+19); /*log*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)CEILING(ctx,1,local+19); /*ceiling*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)ASH(ctx,2,local+18); /*ash*/
	local[18]= w;
	local[19]= makeint((eusinteger_t)1L);
	local[20]= local[15];
	local[21]= makeint((eusinteger_t)2L);
	ctx->vsp=local+22;
	w=(pointer)LOG(ctx,2,local+20); /*log*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)CEILING(ctx,1,local+20); /*ceiling*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)ASH(ctx,2,local+19); /*ash*/
	local[19]= w;
	local[20]= local[10];
	local[21]= local[14];
	local[22]= local[18];
	ctx->vsp=local+23;
	w=(pointer)NUMEQUAL(ctx,2,local+21); /*=*/
	if (w==NIL) goto irtglAND201;
	local[21]= local[15];
	local[22]= local[19];
	ctx->vsp=local+23;
	w=(pointer)NUMEQUAL(ctx,2,local+21); /*=*/
	if (w==NIL) goto irtglAND201;
	goto irtglIF199;
irtglAND201:
	local[21]= NIL;
	local[22]= NIL;
	local[23]= local[20];
	local[24]= fqv[122];
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,2,local+23); /*send*/
	local[23]= w;
	local[24]= NIL;
	local[25]= local[12];
	local[26]= makeint((eusinteger_t)6407L);
	ctx->vsp=local+27;
	w=(pointer)NUMEQUAL(ctx,2,local+25); /*=*/
	if (w==NIL) goto irtglCON203;
	local[25]= local[20];
	local[26]= fqv[123];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,2,local+25); /*send*/
	local[25]= w;
	local[26]= makeint((eusinteger_t)8L);
	ctx->vsp=local+27;
	w=(pointer)QUOTIENT(ctx,2,local+25); /*/*/
	local[22] = w;
	local[25]= local[22];
	local[26]= makeint((eusinteger_t)3L);
	ctx->vsp=local+27;
	w=(pointer)NUMEQUAL(ctx,2,local+25); /*=*/
	if (w!=NIL) goto irtglIF204;
	local[25]= fqv[124];
	ctx->vsp=local+26;
	w=(pointer)SIGERROR(ctx,1,local+25); /*error*/
	local[25]= w;
	goto irtglIF205;
irtglIF204:
	local[25]= NIL;
irtglIF205:
	goto irtglCON202;
irtglCON203:
	local[25]= local[12];
	local[26]= makeint((eusinteger_t)6409L);
	ctx->vsp=local+27;
	w=(pointer)NUMEQUAL(ctx,2,local+25); /*=*/
	if (w==NIL) goto irtglCON206;
	local[22] = makeint((eusinteger_t)1L);
	local[25]= local[22];
	goto irtglCON202;
irtglCON206:
	local[25]= fqv[125];
	local[26]= local[12];
	local[27]= local[20];
	ctx->vsp=local+28;
	w=(pointer)SIGERROR(ctx,3,local+25); /*error*/
	local[25]= w;
	goto irtglCON202;
irtglCON207:
	local[25]= NIL;
irtglCON202:
	local[25]= local[18];
	local[26]= local[19];
	ctx->vsp=local+27;
	w=(pointer)TIMES(ctx,2,local+25); /***/
	local[25]= w;
	local[26]= local[16];
	local[27]= local[17];
	ctx->vsp=local+28;
	w=(pointer)TIMES(ctx,2,local+26); /***/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)QUOTIENT(ctx,2,local+25); /*/*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(pointer)SQRT(ctx,1,local+25); /*sqrt*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(pointer)ROUND(ctx,1,local+25); /*round*/
	local[24] = w;
	local[25]= local[24];
	w = makeint((eusinteger_t)1L);
	if ((eusinteger_t)local[25] <= (eusinteger_t)w) goto irtglIF208;
	local[25]= makeint((eusinteger_t)1L);
	local[26]= local[18];
	local[27]= local[24];
	ctx->vsp=local+28;
	w=(pointer)QUOTIENT(ctx,2,local+26); /*/*/
	local[26]= w;
	local[27]= makeint((eusinteger_t)2L);
	ctx->vsp=local+28;
	w=(pointer)LOG(ctx,2,local+26); /*log*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)CEILING(ctx,1,local+26); /*ceiling*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)ASH(ctx,2,local+25); /*ash*/
	local[18] = w;
	local[25]= makeint((eusinteger_t)1L);
	local[26]= local[19];
	local[27]= local[24];
	ctx->vsp=local+28;
	w=(pointer)QUOTIENT(ctx,2,local+26); /*/*/
	local[26]= w;
	local[27]= makeint((eusinteger_t)2L);
	ctx->vsp=local+28;
	w=(pointer)LOG(ctx,2,local+26); /*log*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)CEILING(ctx,1,local+26); /*ceiling*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)ASH(ctx,2,local+25); /*ash*/
	local[19] = w;
	local[25]= local[19];
	goto irtglIF209;
irtglIF208:
	local[25]= NIL;
irtglIF209:
	local[25]= local[18];
	local[26]= local[19];
	local[27]= local[22];
	ctx->vsp=local+28;
	w=(pointer)TIMES(ctx,3,local+25); /***/
	local[25]= w;
	ctx->vsp=local+26;
	w=(*ftab[15])(ctx,1,local+25,&ftab[15],fqv[43]); /*make-string*/
	local[21] = w;
	local[25]= local[12];
	local[26]= local[14];
	local[27]= local[15];
	local[28]= makeint((eusinteger_t)5121L);
	local[29]= local[20];
	local[30]= fqv[17];
	ctx->vsp=local+31;
	w=(pointer)SEND(ctx,2,local+29); /*send*/
	local[29]= w;
	local[30]= local[18];
	local[31]= local[19];
	local[32]= makeint((eusinteger_t)5121L);
	local[33]= local[21];
	ctx->vsp=local+34;
	w=(*ftab[48])(ctx,9,local+25,&ftab[48],fqv[126]); /*gluscaleimage*/
	local[25]= local[20];
	ctx->vsp=local+26;
	w=(pointer)GETCLASS(ctx,1,local+25); /*class*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(pointer)INSTANTIATE(ctx,1,local+25); /*instantiate*/
	local[25]= w;
	local[26]= local[25];
	local[27]= fqv[45];
	local[28]= local[18];
	local[29]= local[19];
	local[30]= local[21];
	ctx->vsp=local+31;
	w=(pointer)SEND(ctx,5,local+26); /*send*/
	w = local[25];
	local[20] = w;
	local[25]= local[20];
	local[26]= fqv[122];
	local[27]= local[23];
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,3,local+25); /*send*/
	local[21]= w;
	goto irtglIF200;
irtglIF199:
	local[21]= NIL;
irtglIF200:
	local[21]= makeint((eusinteger_t)3553L);
	local[22]= local[13];
	ctx->vsp=local+23;
	w=(*ftab[49])(ctx,2,local+21,&ftab[49],fqv[127]); /*glbindtextureext*/
	local[21]= makeint((eusinteger_t)3553L);
	local[22]= makeint((eusinteger_t)0L);
	local[23]= makeint((eusinteger_t)6407L);
	local[24]= local[20];
	local[25]= fqv[15];
	ctx->vsp=local+26;
	w=(pointer)SEND(ctx,2,local+24); /*send*/
	local[24]= w;
	local[25]= local[20];
	local[26]= fqv[14];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,2,local+25); /*send*/
	local[25]= w;
	local[26]= makeint((eusinteger_t)0L);
	local[27]= local[12];
	local[28]= makeint((eusinteger_t)5121L);
	local[29]= local[20];
	local[30]= fqv[17];
	ctx->vsp=local+31;
	w=(pointer)SEND(ctx,2,local+29); /*send*/
	local[29]= w;
	ctx->vsp=local+30;
	w=(*ftab[50])(ctx,9,local+21,&ftab[50],fqv[128]); /*glteximage2d*/
	local[21]= local[10];
	local[22]= local[13];
	local[23]= fqv[118];
	ctx->vsp=local+24;
	w=(pointer)PUTPROP(ctx,3,local+21); /*putprop*/
	local[13]= w;
	goto irtglIF196;
irtglIF195:
	local[13]= NIL;
irtglIF196:
	local[13]= makeint((eusinteger_t)3317L);
	local[14]= makeint((eusinteger_t)1L);
	ctx->vsp=local+15;
	w=(*ftab[17])(ctx,2,local+13,&ftab[17],fqv[47]); /*glpixelstorei*/
	local[13]= makeint((eusinteger_t)3553L);
	local[14]= makeint((eusinteger_t)10242L);
	local[15]= makeint((eusinteger_t)10497L);
	ctx->vsp=local+16;
	w=(*ftab[51])(ctx,3,local+13,&ftab[51],fqv[129]); /*gltexparameteri*/
	local[13]= makeint((eusinteger_t)3553L);
	local[14]= makeint((eusinteger_t)10243L);
	local[15]= makeint((eusinteger_t)10497L);
	ctx->vsp=local+16;
	w=(*ftab[51])(ctx,3,local+13,&ftab[51],fqv[129]); /*gltexparameteri*/
	local[13]= makeint((eusinteger_t)3553L);
	local[14]= makeint((eusinteger_t)10241L);
	local[15]= makeint((eusinteger_t)9728L);
	ctx->vsp=local+16;
	w=(*ftab[51])(ctx,3,local+13,&ftab[51],fqv[129]); /*gltexparameteri*/
	local[13]= makeint((eusinteger_t)3553L);
	local[14]= makeint((eusinteger_t)10240L);
	local[15]= makeint((eusinteger_t)9728L);
	ctx->vsp=local+16;
	w=(*ftab[51])(ctx,3,local+13,&ftab[51],fqv[129]); /*gltexparameteri*/
	local[13]= makeint((eusinteger_t)8960L);
	local[14]= makeint((eusinteger_t)8704L);
	local[15]= makeint((eusinteger_t)8449L);
	ctx->vsp=local+16;
	w=(*ftab[52])(ctx,3,local+13,&ftab[52],fqv[130]); /*gltexenvi*/
	local[13]= makeint((eusinteger_t)3553L);
	ctx->vsp=local+14;
	w=(*ftab[12])(ctx,1,local+13,&ftab[12],fqv[29]); /*glenable*/
	local[13]= makeint((eusinteger_t)3553L);
	local[14]= local[10];
	local[15]= fqv[118];
	ctx->vsp=local+16;
	w=(pointer)GETPROP(ctx,2,local+14); /*get*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(*ftab[49])(ctx,2,local+13,&ftab[49],fqv[127]); /*glbindtextureext*/
	local[13]= w;
	goto irtglIF194;
irtglIF193:
	local[13]= NIL;
irtglIF194:
	local[13]= makeint((eusinteger_t)9L);
	ctx->vsp=local+14;
	w=(*ftab[9])(ctx,1,local+13,&ftab[9],fqv[26]); /*glbegin*/
	local[13]= argv[1];
	local[14]= fqv[102];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)TRANSPOSE(ctx,1,local+13); /*transpose*/
	local[13]= w;
	local[14]= local[8];
	local[15]= fqv[103];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)TRANSFORM(ctx,2,local+13); /*transform*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(*ftab[41])(ctx,1,local+13,&ftab[41],fqv[104]); /*glnormal3fv*/
	local[13]= NIL;
	local[14]= local[8];
	local[15]= fqv[105];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= w;
irtglWHL210:
	if (local[14]==NIL) goto irtglWHX211;
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14] = (w)->c.cons.cdr;
	w = local[15];
	local[13] = w;
	if (local[11]==NIL) goto irtglIF213;
	local[15]= local[13];
	local[16]= local[11];
	ctx->vsp=local+17;
	w=(*ftab[53])(ctx,2,local+15,&ftab[53],fqv[131]); /*gethash*/
	local[7] = w;
	if (local[7]==NIL) goto irtglIF213;
	local[15]= local[7];
	ctx->vsp=local+16;
	w=(*ftab[54])(ctx,1,local+15,&ftab[54],fqv[132]); /*gltexcoord2fv*/
	local[15]= w;
	goto irtglIF214;
irtglIF213:
	local[15]= NIL;
irtglIF214:
	local[15]= argv[1];
	local[16]= fqv[97];
	local[17]= local[13];
	local[18]= fqv[106];
	local[19]= local[8];
	ctx->vsp=local+20;
	w=(pointer)SEND(ctx,3,local+17); /*send*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(*ftab[10])(ctx,1,local+15,&ftab[10],fqv[27]); /*glvertex3fv*/
	goto irtglWHL210;
irtglWHX211:
	local[15]= NIL;
irtglBLK212:
	w = NIL;
	ctx->vsp=local+13;
	w=(*ftab[11])(ctx,0,local+13,&ftab[11],fqv[28]); /*glend*/
	if (local[10]==NIL) goto irtglIF215;
	local[13]= makeint((eusinteger_t)3553L);
	ctx->vsp=local+14;
	w=(*ftab[8])(ctx,1,local+13,&ftab[8],fqv[25]); /*gldisable*/
	local[13]= makeint((eusinteger_t)3553L);
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(*ftab[49])(ctx,2,local+13,&ftab[49],fqv[127]); /*glbindtextureext*/
	local[13]= w;
	goto irtglIF216;
irtglIF215:
	local[13]= NIL;
irtglIF216:
	w = local[13];
	local[10]= w;
	goto irtglCON188;
irtglCON189:
	local[10]= local[8];
	local[11]= fqv[115];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	local[11]= NIL;
	ctx->vsp=local+12;
	local[12]= makeclosure(codevec,quotevec,irtglCLO218,env,argv,local);
	local[13]= local[8];
	local[14]= fqv[96];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.cdr;
	ctx->vsp=local+14;
	w=(pointer)MAPCAR(ctx,2,local+12); /*mapcar*/
	local[11] = w;
	local[12]= loadglobal(fqv[133]);
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(*ftab[55])(ctx,2,local+12,&ftab[55],fqv[134]); /*glutessbeginpolygon*/
	local[12]= loadglobal(fqv[133]);
	ctx->vsp=local+13;
	w=(*ftab[56])(ctx,1,local+12,&ftab[56],fqv[135]); /*glutessbegincontour*/
	local[12]= local[8];
	local[13]= fqv[103];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(*ftab[41])(ctx,1,local+12,&ftab[41],fqv[104]); /*glnormal3fv*/
	ctx->vsp=local+12;
	local[12]= makeclosure(codevec,quotevec,irtglCLO219,env,argv,local);
	local[13]= local[11];
	ctx->vsp=local+14;
	w=(pointer)MAPC(ctx,2,local+12); /*mapc*/
	local[12]= loadglobal(fqv[133]);
	ctx->vsp=local+13;
	w=(*ftab[57])(ctx,1,local+12,&ftab[57],fqv[136]); /*glutessendcontour*/
	local[12]= loadglobal(fqv[133]);
	ctx->vsp=local+13;
	w=(*ftab[56])(ctx,1,local+12,&ftab[56],fqv[135]); /*glutessbegincontour*/
	if (local[10]==NIL) goto irtglIF220;
	local[12]= NIL;
	local[13]= local[10];
	w = local[12];
	ctx->vsp=local+14;
	bindspecial(ctx,fqv[137],w);
irtglWHL222:
	if (local[13]==NIL) goto irtglWHX223;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13] = (w)->c.cons.cdr;
	w = local[17];
	local[17]= w;
	storeglobal(fqv[137],w);
	ctx->vsp=local+17;
	local[17]= makeclosure(codevec,quotevec,irtglCLO225,env,argv,local);
	local[18]= loadglobal(fqv[137]);
	local[19]= fqv[96];
	ctx->vsp=local+20;
	w=(pointer)SEND(ctx,2,local+18); /*send*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)MAPCAR(ctx,2,local+17); /*mapcar*/
	local[17]= w;
	local[18]= loadglobal(fqv[133]);
	local[19]= makeint((eusinteger_t)100122L);
	ctx->vsp=local+20;
	w=(*ftab[58])(ctx,2,local+18,&ftab[58],fqv[138]); /*glunextcontour*/
	ctx->vsp=local+18;
	local[18]= makeclosure(codevec,quotevec,irtglCLO226,env,argv,local);
	local[19]= local[17];
	ctx->vsp=local+20;
	w=(pointer)MAPC(ctx,2,local+18); /*mapc*/
	local[18]= local[11];
	local[19]= local[17];
	ctx->vsp=local+20;
	w=(pointer)NCONC(ctx,2,local+18); /*nconc*/
	goto irtglWHL222;
irtglWHX223:
	local[17]= NIL;
irtglBLK224:
	local[17]= NIL;
	ctx->vsp=local+18;
	unbindx(ctx,1);
	w = local[17];
	local[12]= w;
	goto irtglIF221;
irtglIF220:
	local[12]= NIL;
irtglIF221:
	local[12]= loadglobal(fqv[133]);
	ctx->vsp=local+13;
	w=(*ftab[57])(ctx,1,local+12,&ftab[57],fqv[136]); /*glutessendcontour*/
	local[12]= loadglobal(fqv[133]);
	ctx->vsp=local+13;
	w=(*ftab[59])(ctx,1,local+12,&ftab[59],fqv[139]); /*glutessendpolygon*/
	local[12]= (pointer)get_sym_func(fqv[140]);
	local[13]= local[11];
	ctx->vsp=local+14;
	w=(pointer)MAPC(ctx,2,local+12); /*mapc*/
	local[10]= w;
	goto irtglCON188;
irtglCON217:
	local[10]= NIL;
irtglCON188:
	goto irtglWHL185;
irtglWHX186:
	local[10]= NIL;
irtglBLK187:
	w = NIL;
	if (local[5]==NIL) goto irtglIF227;
	local[8]= makeint((eusinteger_t)3042L);
	ctx->vsp=local+9;
	w=(*ftab[8])(ctx,1,local+8,&ftab[8],fqv[25]); /*gldisable*/
	local[8]= w;
	goto irtglIF228;
irtglIF227:
	local[8]= NIL;
irtglIF228:
	ctx->vsp=local+8;
	w=(*ftab[43])(ctx,0,local+8,&ftab[43],fqv[108]); /*glendlist*/
	local[8]= argv[1];
	local[9]= local[0];
	w = local[4];
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= argv[1];
	local[11]= fqv[82];
	ctx->vsp=local+12;
	w=(pointer)GETPROP(ctx,2,local+10); /*get*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[82];
	ctx->vsp=local+11;
	w=(pointer)PUTPROP(ctx,3,local+8); /*putprop*/
	local[8]= argv[0];
	local[9]= argv[1];
	ctx->vsp=local+10;
	w=(pointer)irtglF6draw_glbody(ctx,2,local+8); /*draw-glbody*/
	local[4]= w;
	goto irtglCON162;
irtglCON177:
	local[4]= NIL;
irtglCON162:
	w = local[4];
	local[0]= w;
irtglBLK157:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtglCLO218(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[1];
	local[1]= fqv[97];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	argv[0] = w;
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= NIL;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(*ftab[60])(ctx,5,local+0,&ftab[60],fqv[141]); /*alloctessinfo*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtglCLO219(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= loadglobal(fqv[133]);
	local[1]= argv[0];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[61])(ctx,3,local+0,&ftab[61],fqv[142]); /*glutessvertex*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtglCLO225(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[1];
	local[1]= fqv[97];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	argv[0] = w;
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= NIL;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(*ftab[60])(ctx,5,local+0,&ftab[60],fqv[141]); /*alloctessinfo*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtglCLO226(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= loadglobal(fqv[133]);
	local[1]= argv[0];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[61])(ctx,3,local+0,&ftab[61],fqv[142]); /*glutessvertex*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*find-color*/
static pointer irtglF7find_color(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= NIL;
	if (argv[0]!=NIL) goto irtglCON231;
	local[2]= NIL;
	goto irtglCON230;
irtglCON231:
	local[2]= argv[0];
	local[3]= loadglobal(fqv[143]);
	ctx->vsp=local+4;
	w=(pointer)DERIVEDP(ctx,2,local+2); /*derivedp*/
	if (w==NIL) goto irtglCON232;
	local[2]= argv[0];
	local[3]= fqv[144];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	goto irtglCON230;
irtglCON232:
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)VECTORP(ctx,1,local+2); /*vectorp*/
	if (w==NIL) goto irtglCON233;
	local[2]= argv[0];
	goto irtglCON230;
irtglCON233:
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)LISTP(ctx,1,local+2); /*listp*/
	if (w==NIL) goto irtglCON234;
	local[2]= argv[0];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	local[3]= makeflt(2.5500000000000000000000e+02);
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	local[4]= makeflt(2.5500000000000000000000e+02);
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= makeflt(2.5500000000000000000000e+02);
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[2]= w;
	goto irtglCON230;
irtglCON234:
	w = argv[0];
	if (!issymbol(w)) goto irtglCON235;
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtglCLO236,env,argv,local);
	local[3]= loadglobal(fqv[145]);
	ctx->vsp=local+4;
	w=(*ftab[62])(ctx,2,local+2,&ftab[62],fqv[146]); /*find-if*/
	local[1] = w;
	if (local[1]==NIL) goto irtglIF237;
	local[2]= local[1];
	local[3]= fqv[144];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	goto irtglIF238;
irtglIF237:
	local[2]= fqv[147];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[31])(ctx,2,local+2,&ftab[31],fqv[81]); /*warn*/
	local[2]= w;
irtglIF238:
	goto irtglCON230;
irtglCON235:
	local[2]= argv[0];
	goto irtglCON230;
irtglCON239:
	local[2]= NIL;
irtglCON230:
	local[0] = local[2];
	if (local[0]!=NIL) goto irtglIF240;
	local[2]= makeflt(5.0000000000000000000000e-01);
	local[3]= makeflt(5.0000000000000000000000e-01);
	local[4]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[0] = w;
	local[2]= local[0];
	goto irtglIF241;
irtglIF240:
	local[2]= NIL;
irtglIF241:
	w = local[0];
	local[0]= w;
irtglBLK229:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtglCLO236(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[122];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	w = ((env->c.clo.env1[0])==(local[0])?T:NIL);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*transparent*/
static pointer irtglF8transparent(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[0];
	local[3]= fqv[84];
	ctx->vsp=local+4;
	w=(pointer)GETPROP(ctx,2,local+2); /*get*/
	local[0] = w;
	if (local[0]==NIL) goto irtglIF243;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)VECTORP(ctx,1,local+2); /*vectorp*/
	if (w!=NIL) goto irtglIF245;
	local[2]= fqv[148];
	local[3]= argv[0];
	local[4]= argv[1];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[81]); /*warn*/
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)irtglF7find_color(ctx,1,local+2); /*find-color*/
	local[0] = w;
	local[2]= local[0];
	goto irtglIF246;
irtglIF245:
	local[2]= NIL;
irtglIF246:
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
	if (makeint((eusinteger_t)3L)!=local[2]) goto irtglIF247;
	local[2]= loadglobal(fqv[149]);
	local[3]= local[0];
	local[4]= fqv[150];
	ctx->vsp=local+5;
	w=(pointer)CONCATENATE(ctx,3,local+2); /*concatenate*/
	local[0] = w;
	local[2]= local[0];
	goto irtglIF248;
irtglIF247:
	local[2]= NIL;
irtglIF248:
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)3L);
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)SETELT(ctx,3,local+2); /*setelt*/
	local[2]= argv[0];
	local[3]= local[0];
	local[4]= fqv[84];
	ctx->vsp=local+5;
	w=(pointer)PUTPROP(ctx,3,local+2); /*putprop*/
	local[2]= argv[0];
	local[3]= fqv[82];
	ctx->vsp=local+4;
	w=(pointer)GETPROP(ctx,2,local+2); /*get*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)irtglF3delete_displaylist_id(ctx,1,local+2); /*delete-displaylist-id*/
	local[2]= argv[0];
	local[3]= NIL;
	local[4]= fqv[82];
	ctx->vsp=local+5;
	w=(pointer)PUTPROP(ctx,3,local+2); /*putprop*/
	local[2]= local[0];
	goto irtglIF244;
irtglIF243:
	local[2]= NIL;
irtglIF244:
	w = local[2];
	local[0]= w;
irtglBLK242:
	ctx->vsp=local; return(local[0]);}

/*:draw-on*/
static pointer irtglM249polygon_draw_on(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[151], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtglKEY251;
	local[0] = loadglobal(fqv[152]);
irtglKEY251:
	if (n & (1<<1)) goto irtglKEY252;
	local[1] = NIL;
irtglKEY252:
	if (n & (1<<2)) goto irtglKEY253;
	local[2] = makeint((eusinteger_t)1L);
irtglKEY253:
	if (n & (1<<3)) goto irtglKEY254;
	local[3] = fqv[153];
irtglKEY254:
	if (local[1]==NIL) goto irtglIF255;
	local[4]= local[0];
	local[5]= fqv[8];
	local[6]= fqv[9];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto irtglIF256;
irtglIF255:
	local[4]= NIL;
irtglIF256:
	local[4]= local[0];
	local[5]= fqv[8];
	local[6]= fqv[154];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= local[0];
	local[6]= fqv[8];
	local[7]= fqv[67];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,3,local+6); /*float-vector*/
	local[6]= w;
	local[7]= local[0];
	local[8]= fqv[8];
	local[9]= fqv[154];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[7]= local[0];
	local[8]= fqv[8];
	local[9]= fqv[67];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[7]= local[0];
	local[8]= fqv[8];
	local[9]= fqv[155];
	local[10]= argv[0];
	local[11]= fqv[96];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[7]= local[0];
	local[8]= fqv[8];
	local[9]= fqv[154];
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[7]= local[0];
	local[8]= fqv[8];
	local[9]= fqv[67];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	if (local[1]==NIL) goto irtglIF257;
	local[7]= local[0];
	local[8]= fqv[8];
	local[9]= fqv[34];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	goto irtglIF258;
irtglIF257:
	local[7]= NIL;
irtglIF258:
	w = local[7];
	local[0]= w;
irtglBLK250:
	ctx->vsp=local; return(local[0]);}

/*:draw-on*/
static pointer irtglM259line_draw_on(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[156], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtglKEY261;
	local[0] = loadglobal(fqv[152]);
irtglKEY261:
	if (n & (1<<1)) goto irtglKEY262;
	local[1] = NIL;
irtglKEY262:
	if (n & (1<<2)) goto irtglKEY263;
	local[2] = makeint((eusinteger_t)1L);
irtglKEY263:
	if (n & (1<<3)) goto irtglKEY264;
	local[3] = fqv[157];
irtglKEY264:
	if (local[1]==NIL) goto irtglIF265;
	local[4]= local[0];
	local[5]= fqv[8];
	local[6]= fqv[9];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto irtglIF266;
irtglIF265:
	local[4]= NIL;
irtglIF266:
	local[4]= local[0];
	local[5]= fqv[8];
	local[6]= fqv[154];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= local[0];
	local[6]= fqv[8];
	local[7]= fqv[67];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,3,local+6); /*float-vector*/
	local[6]= w;
	local[7]= local[0];
	local[8]= fqv[8];
	local[9]= fqv[154];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[7]= local[0];
	local[8]= fqv[8];
	local[9]= fqv[67];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[7]= local[0];
	local[8]= fqv[8];
	local[9]= fqv[158];
	local[10]= argv[0]->c.obj.iv[1];
	local[11]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,5,local+7); /*send*/
	local[7]= local[0];
	local[8]= fqv[8];
	local[9]= fqv[154];
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[7]= local[0];
	local[8]= fqv[8];
	local[9]= fqv[67];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	if (local[1]==NIL) goto irtglIF267;
	local[7]= local[0];
	local[8]= fqv[8];
	local[9]= fqv[34];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	goto irtglIF268;
irtglIF267:
	local[7]= NIL;
irtglIF268:
	w = local[7];
	local[0]= w;
irtglBLK260:
	ctx->vsp=local; return(local[0]);}

/*:set-color*/
static pointer irtglM269faceset_set_color(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtglENT272;}
	local[0]= NIL;
irtglENT272:
irtglENT271:
	if (n>4) maerror();
	local[1]= argv[0];
	local[2]= fqv[82];
	ctx->vsp=local+3;
	w=(pointer)GETPROP(ctx,2,local+1); /*get*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)irtglF3delete_displaylist_id(ctx,1,local+1); /*delete-displaylist-id*/
	local[1]= argv[0];
	local[2]= NIL;
	local[3]= fqv[82];
	ctx->vsp=local+4;
	w=(pointer)PUTPROP(ctx,3,local+1); /*putprop*/
	if (local[0]==NIL) goto irtglCON274;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)irtglF7find_color(ctx,1,local+1); /*find-color*/
	local[1]= w;
	local[2]= loadglobal(fqv[149]);
	local[3]= local[1];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,1,local+4); /*float-vector*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)CONCATENATE(ctx,3,local+2); /*concatenate*/
	local[1] = w;
	local[2]= argv[0];
	local[3]= local[1];
	local[4]= fqv[84];
	ctx->vsp=local+5;
	w=(pointer)PUTPROP(ctx,3,local+2); /*putprop*/
	local[1]= w;
	goto irtglCON273;
irtglCON274:
	local[1]= argv[0];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)irtglF7find_color(ctx,1,local+2); /*find-color*/
	local[2]= w;
	local[3]= fqv[84];
	ctx->vsp=local+4;
	w=(pointer)PUTPROP(ctx,3,local+1); /*putprop*/
	local[1]= w;
	goto irtglCON273;
irtglCON275:
	local[1]= NIL;
irtglCON273:
	w = local[1];
	local[0]= w;
irtglBLK270:
	ctx->vsp=local; return(local[0]);}

/*:draw-on*/
static pointer irtglM276faceset_draw_on(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[159], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtglKEY278;
	local[0] = loadglobal(fqv[152]);
irtglKEY278:
	if (n & (1<<1)) goto irtglKEY279;
	local[1] = NIL;
irtglKEY279:
	if (n & (1<<2)) goto irtglKEY280;
	local[2] = makeint((eusinteger_t)1L);
irtglKEY280:
	if (n & (1<<3)) goto irtglKEY281;
	local[3] = fqv[160];
irtglKEY281:
	if (local[1]==NIL) goto irtglIF282;
	local[4]= local[0];
	local[5]= fqv[8];
	local[6]= fqv[9];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto irtglIF283;
irtglIF282:
	local[4]= NIL;
irtglIF283:
	local[4]= local[0];
	local[5]= fqv[8];
	local[6]= fqv[154];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= local[0];
	local[6]= fqv[8];
	local[7]= fqv[67];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= local[0];
	local[7]= fqv[8];
	local[8]= fqv[154];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= local[0];
	local[7]= fqv[8];
	local[8]= fqv[67];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= NIL;
	local[7]= argv[0];
	local[8]= fqv[95];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
irtglWHL284:
	if (local[7]==NIL) goto irtglWHX285;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= local[0];
	local[9]= fqv[8];
	local[10]= fqv[155];
	local[11]= local[6];
	local[12]= fqv[96];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	goto irtglWHL284;
irtglWHX285:
	local[8]= NIL;
irtglBLK286:
	w = NIL;
	local[6]= local[0];
	local[7]= fqv[8];
	local[8]= fqv[154];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= local[0];
	local[7]= fqv[8];
	local[8]= fqv[67];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	if (local[1]==NIL) goto irtglIF287;
	local[6]= local[0];
	local[7]= fqv[8];
	local[8]= fqv[34];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	goto irtglIF288;
irtglIF287:
	local[6]= NIL;
irtglIF288:
	w = local[6];
	local[0]= w;
irtglBLK277:
	ctx->vsp=local; return(local[0]);}

/*:paste-texture-to-face*/
static pointer irtglM289faceset_paste_texture_to_face(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[161], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtglKEY291;
	local[0] = NIL;
irtglKEY291:
	if (n & (1<<1)) goto irtglKEY292;
	local[1] = NIL;
irtglKEY292:
	if (n & (1<<2)) goto irtglKEY293;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,2,local+3); /*float-vector*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,2,local+4); /*float-vector*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)1L);
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,2,local+5); /*float-vector*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)1L);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,2,local+6); /*float-vector*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,4,local+3); /*list*/
	local[2] = w;
irtglKEY293:
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	if (local[1]==NIL) goto irtglCON295;
	local[3] = local[1];
	local[9]= local[3];
	goto irtglCON294;
irtglCON295:
	local[9]= local[0];
	local[10]= argv[0];
	local[11]= fqv[109];
	ctx->vsp=local+12;
	w=(pointer)GETPROP(ctx,2,local+10); /*get*/
	local[10]= w;
	local[11]= fqv[122];
	ctx->vsp=local+12;
	w=(*ftab[63])(ctx,2,local+10,&ftab[63],fqv[162]); /*send-all*/
	local[10]= w;
	local[11]= fqv[163];
	local[12]= (pointer)get_sym_func(fqv[164]);
	ctx->vsp=local+13;
	w=(*ftab[64])(ctx,4,local+9,&ftab[64],fqv[165]); /*member*/
	if (w==NIL) goto irtglCON296;
	local[9]= local[0];
	local[10]= argv[0];
	local[11]= fqv[109];
	ctx->vsp=local+12;
	w=(pointer)GETPROP(ctx,2,local+10); /*get*/
	local[10]= w;
	local[11]= fqv[163];
	local[12]= (pointer)get_sym_func(fqv[164]);
	local[13]= fqv[6];
	ctx->vsp=local+14;
	local[14]= makeclosure(codevec,quotevec,irtglCLO297,env,argv,local);
	ctx->vsp=local+15;
	w=(*ftab[64])(ctx,6,local+9,&ftab[64],fqv[165]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.car;
	local[9]= local[3];
	goto irtglCON294;
irtglCON296:
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(*ftab[65])(ctx,1,local+9,&ftab[65],fqv[166]); /*probe-file*/
	if (w==NIL) goto irtglCON298;
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(*ftab[66])(ctx,1,local+9,&ftab[66],fqv[167]); /*user::read-image-file*/
	local[3] = w;
	local[9]= local[3];
	goto irtglCON294;
irtglCON298:
	local[9]= NIL;
	local[10]= fqv[168];
	local[11]= loadglobal(fqv[169]);
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,4,local+9); /*format*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[65])(ctx,1,local+9,&ftab[65],fqv[166]); /*probe-file*/
	if (w==NIL) goto irtglCON299;
	local[9]= NIL;
	local[10]= fqv[170];
	local[11]= loadglobal(fqv[169]);
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,4,local+9); /*format*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[66])(ctx,1,local+9,&ftab[66],fqv[167]); /*user::read-image-file*/
	local[3] = w;
	local[9]= local[3];
	goto irtglCON294;
irtglCON299:
	local[9]= NIL;
	local[10]= fqv[171];
	local[11]= loadglobal(fqv[169]);
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,4,local+9); /*format*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[65])(ctx,1,local+9,&ftab[65],fqv[166]); /*probe-file*/
	if (w==NIL) goto irtglCON300;
	local[9]= NIL;
	local[10]= fqv[172];
	local[11]= loadglobal(fqv[169]);
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,4,local+9); /*format*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[66])(ctx,1,local+9,&ftab[66],fqv[167]); /*user::read-image-file*/
	local[3] = w;
	local[9]= local[3];
	goto irtglCON294;
irtglCON300:
	local[9]= fqv[173];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(*ftab[31])(ctx,2,local+9,&ftab[31],fqv[81]); /*warn*/
	w = NIL;
	ctx->vsp=local+9;
	local[0]=w;
	goto irtglBLK290;
	goto irtglCON294;
irtglCON301:
	local[9]= NIL;
irtglCON294:
	local[9]= argv[2];
	local[10]= local[3];
	local[11]= fqv[109];
	ctx->vsp=local+12;
	w=(pointer)PUTPROP(ctx,3,local+9); /*putprop*/
	local[9]= local[3];
	local[10]= argv[0];
	local[11]= fqv[109];
	ctx->vsp=local+12;
	w=(pointer)GETPROP(ctx,2,local+10); /*get*/
	if (memq(local[9],w)!=NIL) goto irtglIF302;
	local[9]= argv[0];
	local[10]= argv[0];
	local[11]= fqv[109];
	ctx->vsp=local+12;
	w=(pointer)GETPROP(ctx,2,local+10); /*get*/
	local[10]= w;
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)APPEND(ctx,2,local+10); /*append*/
	local[10]= w;
	local[11]= fqv[109];
	ctx->vsp=local+12;
	w=(pointer)PUTPROP(ctx,3,local+9); /*putprop*/
	local[9]= w;
	goto irtglIF303;
irtglIF302:
	local[9]= NIL;
irtglIF303:
	local[9]= argv[2];
	local[10]= fqv[163];
	local[11]= (pointer)get_sym_func(fqv[164]);
	ctx->vsp=local+12;
	w=(*ftab[67])(ctx,2,local+10,&ftab[67],fqv[174]); /*make-hash-table*/
	local[10]= w;
	local[11]= fqv[116];
	ctx->vsp=local+12;
	w=(pointer)PUTPROP(ctx,3,local+9); /*putprop*/
	local[9]= argv[0];
	local[10]= fqv[82];
	ctx->vsp=local+11;
	w=(pointer)GETPROP(ctx,2,local+9); /*get*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)irtglF3delete_displaylist_id(ctx,1,local+9); /*delete-displaylist-id*/
	local[9]= argv[0];
	local[10]= NIL;
	local[11]= fqv[82];
	ctx->vsp=local+12;
	w=(pointer)PUTPROP(ctx,3,local+9); /*putprop*/
	local[9]= NIL;
	local[10]= argv[2];
	local[11]= fqv[105];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
irtglWHL304:
	if (local[10]==NIL) goto irtglWHX305;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10] = (w)->c.cons.cdr;
	w = local[11];
	local[9] = w;
	local[11]= local[9];
	local[12]= argv[2];
	local[13]= fqv[116];
	ctx->vsp=local+14;
	w=(pointer)GETPROP(ctx,2,local+12); /*get*/
	local[12]= w;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[13];
	local[13]= w;
	ctx->vsp=local+14;
	w=(*ftab[68])(ctx,3,local+11,&ftab[68],fqv[175]); /*sethash*/
	goto irtglWHL304;
irtglWHX305:
	local[11]= NIL;
irtglBLK306:
	w = NIL;
	local[0]= w;
irtglBLK290:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtglCLO297(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[122];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:vertices*/
static pointer irtglM307coordinates_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[176];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
irtglBLK308:
	ctx->vsp=local; return(local[0]);}

/*:draw-on*/
static pointer irtglM309coordinates_draw_on(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[177], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtglKEY311;
	local[0] = loadglobal(fqv[152]);
irtglKEY311:
	if (n & (1<<1)) goto irtglKEY312;
	local[1] = NIL;
irtglKEY312:
	if (n & (1<<2)) goto irtglKEY313;
	local[5]= argv[0];
	local[6]= fqv[15];
	ctx->vsp=local+7;
	w=(pointer)GETPROP(ctx,2,local+5); /*get*/
	local[2] = w;
irtglKEY313:
	if (n & (1<<3)) goto irtglKEY314;
	local[5]= argv[0];
	local[6]= fqv[67];
	ctx->vsp=local+7;
	w=(pointer)GETPROP(ctx,2,local+5); /*get*/
	local[3] = w;
irtglKEY314:
	if (n & (1<<4)) goto irtglKEY315;
	local[5]= argv[0];
	local[6]= fqv[178];
	ctx->vsp=local+7;
	w=(pointer)GETPROP(ctx,2,local+5); /*get*/
	local[4] = w;
irtglKEY315:
	if (local[1]==NIL) goto irtglIF316;
	local[5]= local[0];
	local[6]= fqv[8];
	local[7]= fqv[9];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	goto irtglIF317;
irtglIF316:
	local[5]= NIL;
irtglIF317:
	local[5]= local[0];
	local[6]= fqv[8];
	local[7]= fqv[154];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= local[0];
	local[7]= fqv[8];
	local[8]= fqv[67];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	local[8]= NIL;
	if (local[2]!=NIL) goto irtglIF318;
	local[2] = makeint((eusinteger_t)1L);
	local[9]= local[2];
	goto irtglIF319;
irtglIF318:
	local[9]= NIL;
irtglIF319:
	if (local[3]!=NIL) goto irtglIF320;
	local[3] = fqv[179];
	local[9]= local[3];
	goto irtglIF321;
irtglIF320:
	local[9]= NIL;
irtglIF321:
	if (local[4]!=NIL) goto irtglIF322;
	local[4] = makeint((eusinteger_t)50L);
	local[9]= local[4];
	goto irtglIF323;
irtglIF322:
	local[9]= NIL;
irtglIF323:
	local[9]= makeflt(2.9999999999999982236432e-01);
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeflt(6.9999999999999973354647e-01);
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)MKFLTVEC(ctx,3,local+9); /*float-vector*/
	local[8] = w;
	local[9]= local[0];
	local[10]= fqv[8];
	local[11]= fqv[154];
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,4,local+9); /*send*/
	local[9]= local[0];
	local[10]= fqv[8];
	local[11]= fqv[67];
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,4,local+9); /*send*/
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)3L);
irtglWHL324:
	local[11]= local[9];
	w = local[10];
	if ((eusinteger_t)local[11] >= (eusinteger_t)w) goto irtglWHX325;
	local[11]= local[7];
	local[12]= local[9];
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(pointer)SETELT(ctx,3,local+11); /*setelt*/
	local[11]= local[0];
	local[12]= fqv[8];
	local[13]= fqv[158];
	local[14]= argv[0];
	local[15]= fqv[176];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= w;
	local[15]= argv[0];
	local[16]= fqv[180];
	local[17]= local[7];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,5,local+11); /*send*/
	local[11]= local[7];
	local[12]= local[9];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)SETELT(ctx,3,local+11); /*setelt*/
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[9] = w;
	goto irtglWHL324;
irtglWHX325:
	local[11]= NIL;
irtglBLK326:
	w = NIL;
	local[9]= local[7];
	local[10]= makeint((eusinteger_t)2L);
	local[11]= local[4];
	ctx->vsp=local+12;
	w=(pointer)SETELT(ctx,3,local+9); /*setelt*/
	local[9]= local[0];
	local[10]= fqv[8];
	local[11]= fqv[158];
	local[12]= argv[0];
	local[13]= fqv[180];
	local[14]= local[7];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= w;
	local[13]= argv[0];
	local[14]= fqv[180];
	local[15]= local[8];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,5,local+9); /*send*/
	local[9]= local[8];
	local[10]= makeint((eusinteger_t)1L);
	local[11]= local[8];
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SETELT(ctx,3,local+9); /*setelt*/
	local[9]= local[8];
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)SETELT(ctx,3,local+9); /*setelt*/
	local[9]= local[0];
	local[10]= fqv[8];
	local[11]= fqv[158];
	local[12]= argv[0];
	local[13]= fqv[180];
	local[14]= local[7];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= w;
	local[13]= argv[0];
	local[14]= fqv[180];
	local[15]= local[8];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,5,local+9); /*send*/
	local[9]= local[0];
	local[10]= fqv[8];
	local[11]= fqv[154];
	local[12]= local[5];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,4,local+9); /*send*/
	local[9]= local[0];
	local[10]= fqv[8];
	local[11]= fqv[67];
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,4,local+9); /*send*/
	if (local[1]==NIL) goto irtglIF327;
	local[9]= local[0];
	local[10]= fqv[8];
	local[11]= fqv[34];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	goto irtglIF328;
irtglIF327:
	local[9]= NIL;
irtglIF328:
	w = local[9];
	local[0]= w;
irtglBLK310:
	ctx->vsp=local; return(local[0]);}

/*:vertices*/
static pointer irtglM329float_vector_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
irtglBLK330:
	ctx->vsp=local; return(local[0]);}

/*:draw-on*/
static pointer irtglM331float_vector_draw_on(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[181], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtglKEY333;
	local[0] = loadglobal(fqv[152]);
irtglKEY333:
	if (n & (1<<1)) goto irtglKEY334;
	local[1] = NIL;
irtglKEY334:
	if (n & (1<<2)) goto irtglKEY335;
	local[2] = makeint((eusinteger_t)1L);
irtglKEY335:
	if (n & (1<<3)) goto irtglKEY336;
	local[3] = fqv[182];
irtglKEY336:
	if (n & (1<<4)) goto irtglKEY337;
	local[4] = makeint((eusinteger_t)50L);
irtglKEY337:
	if (local[1]==NIL) goto irtglIF338;
	local[5]= local[0];
	local[6]= fqv[8];
	local[7]= fqv[9];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	goto irtglIF339;
irtglIF338:
	local[5]= NIL;
irtglIF339:
	local[5]= local[0];
	local[6]= fqv[8];
	local[7]= fqv[154];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= local[0];
	local[7]= fqv[8];
	local[8]= fqv[67];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	local[8]= local[0];
	local[9]= fqv[8];
	local[10]= fqv[154];
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= local[0];
	local[9]= fqv[8];
	local[10]= fqv[67];
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)3L);
irtglWHL340:
	local[10]= local[8];
	w = local[9];
	if ((eusinteger_t)local[10] >= (eusinteger_t)w) goto irtglWHX341;
	local[10]= local[7];
	local[11]= local[8];
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(pointer)SETELT(ctx,3,local+10); /*setelt*/
	local[10]= local[0];
	local[11]= fqv[8];
	local[12]= fqv[158];
	local[13]= argv[0];
	local[14]= argv[0];
	local[15]= local[7];
	ctx->vsp=local+16;
	w=(pointer)VPLUS(ctx,2,local+14); /*v+*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,5,local+10); /*send*/
	local[10]= local[7];
	local[11]= local[8];
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(pointer)SETELT(ctx,3,local+10); /*setelt*/
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	goto irtglWHL340;
irtglWHX341:
	local[10]= NIL;
irtglBLK342:
	w = NIL;
	local[8]= local[0];
	local[9]= fqv[8];
	local[10]= fqv[154];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= local[0];
	local[9]= fqv[8];
	local[10]= fqv[67];
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	if (local[1]==NIL) goto irtglIF343;
	local[8]= local[0];
	local[9]= fqv[8];
	local[10]= fqv[34];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	goto irtglIF344;
irtglIF343:
	local[8]= NIL;
irtglIF344:
	w = local[8];
	local[0]= w;
irtglBLK332:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtglM345glvertices_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtglRST347:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[183], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtglKEY348;
	local[1] = NIL;
irtglKEY348:
	argv[0]->c.obj.iv[8] = argv[2];
	argv[0]->c.obj.iv[9] = local[1];
	local[2]= (pointer)get_sym_func(fqv[184]);
	local[3]= argv[0];
	local[4]= *(ovafptr(argv[1],fqv[36]));
	local[5]= fqv[45];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)APPLY(ctx,5,local+2); /*apply*/
	w = argv[0];
	local[0]= w;
irtglBLK346:
	ctx->vsp=local; return(local[0]);}

/*:filename*/
static pointer irtglM349glvertices_filename(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtglENT352;}
	local[0]= NIL;
irtglENT352:
irtglENT351:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtglIF353;
	argv[0]->c.obj.iv[9] = local[0];
	local[1]= argv[0]->c.obj.iv[9];
	goto irtglIF354;
irtglIF353:
	local[1]= NIL;
irtglIF354:
	w = argv[0]->c.obj.iv[9];
	local[0]= w;
irtglBLK350:
	ctx->vsp=local; return(local[0]);}

/*:set-color*/
static pointer irtglM355glvertices_set_color(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtglENT358;}
	local[0]= NIL;
irtglENT358:
irtglENT357:
	if (n>4) maerror();
	local[1]= argv[0];
	local[2]= fqv[82];
	ctx->vsp=local+3;
	w=(pointer)GETPROP(ctx,2,local+1); /*get*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)irtglF3delete_displaylist_id(ctx,1,local+1); /*delete-displaylist-id*/
	local[1]= argv[0];
	local[2]= NIL;
	local[3]= fqv[82];
	ctx->vsp=local+4;
	w=(pointer)PUTPROP(ctx,3,local+1); /*putprop*/
	local[1]= argv[0];
	local[2]= local[0];
	local[3]= fqv[185];
	ctx->vsp=local+4;
	w=(pointer)PUTPROP(ctx,3,local+1); /*putprop*/
	if (argv[2]==NIL) goto irtglIF359;
	local[1]= argv[0];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)irtglF7find_color(ctx,1,local+2); /*find-color*/
	local[2]= w;
	local[3]= fqv[84];
	ctx->vsp=local+4;
	w=(pointer)PUTPROP(ctx,3,local+1); /*putprop*/
	local[1]= w;
	goto irtglIF360;
irtglIF359:
	local[1]= argv[0];
	local[2]= NIL;
	local[3]= fqv[84];
	ctx->vsp=local+4;
	w=(pointer)PUTPROP(ctx,3,local+1); /*putprop*/
	local[1]= w;
irtglIF360:
	w = local[1];
	local[0]= w;
irtglBLK356:
	ctx->vsp=local; return(local[0]);}

/*:get-meshinfo*/
static pointer irtglM361glvertices_get_meshinfo(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtglENT364;}
	local[0]= makeint((eusinteger_t)-1L);
irtglENT364:
irtglENT363:
	if (n>4) maerror();
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)LESSP(ctx,2,local+1); /*<*/
	if (w==NIL) goto irtglIF365;
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtglCLO367,env,argv,local);
	local[2]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	ctx->vsp=local+1;
	local[0]=w;
	goto irtglBLK362;
	goto irtglIF366;
irtglIF365:
	local[1]= NIL;
irtglIF366:
	local[1]= argv[2];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[69])(ctx,2,local+1,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
irtglBLK362:
	ctx->vsp=local; return(local[0]);}

/*:set-meshinfo*/
static pointer irtglM368glvertices_set_meshinfo(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto irtglENT371;}
	local[0]= makeint((eusinteger_t)-1L);
irtglENT371:
irtglENT370:
	if (n>5) maerror();
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)LESSP(ctx,2,local+1); /*<*/
	if (w==NIL) goto irtglIF372;
	local[1]= NIL;
	local[2]= argv[0]->c.obj.iv[8];
irtglWHL374:
	if (local[2]==NIL) goto irtglWHX375;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= argv[2];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(*ftab[69])(ctx,2,local+3,&ftab[69],fqv[186]); /*assoc*/
	local[3]= w;
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(*ftab[70])(ctx,2,local+3,&ftab[70],fqv[187]); /*delete*/
	local[3]= local[1];
	local[4]= argv[2];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,2,local+4); /*list*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)NCONC(ctx,2,local+3); /*nconc*/
	goto irtglWHL374;
irtglWHX375:
	local[3]= NIL;
irtglBLK376:
	w = NIL;
	w = NIL;
	ctx->vsp=local+1;
	local[0]=w;
	goto irtglBLK369;
	goto irtglIF373;
irtglIF372:
	local[1]= NIL;
irtglIF373:
	local[1]= argv[0]->c.obj.iv[8];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= argv[2];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(*ftab[69])(ctx,2,local+2,&ftab[69],fqv[186]); /*assoc*/
	local[2]= w;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(*ftab[70])(ctx,2,local+2,&ftab[70],fqv[187]); /*delete*/
	local[2]= local[1];
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,2,local+3); /*list*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)NCONC(ctx,2,local+2); /*nconc*/
	local[2]= argv[0];
	local[3]= fqv[188];
	local[4]= argv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[0]= w;
irtglBLK369:
	ctx->vsp=local; return(local[0]);}

/*:get-material*/
static pointer irtglM377glvertices_get_material(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtglENT380;}
	local[0]= makeint((eusinteger_t)-1L);
irtglENT380:
irtglENT379:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[188];
	local[3]= fqv[189];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
irtglBLK378:
	ctx->vsp=local; return(local[0]);}

/*:set-material*/
static pointer irtglM381glvertices_set_material(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtglENT384;}
	local[0]= makeint((eusinteger_t)-1L);
irtglENT384:
irtglENT383:
	if (n>4) maerror();
	local[1]= argv[0];
	local[2]= fqv[190];
	local[3]= fqv[189];
	local[4]= argv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[0]= w;
irtglBLK382:
	ctx->vsp=local; return(local[0]);}

/*:actual-vertices*/
static pointer irtglM385glvertices_actual_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[0]->c.obj.iv[8];
irtglWHL387:
	if (local[2]==NIL) goto irtglWHX388;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= fqv[96];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(*ftab[69])(ctx,2,local+3,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	if (local[3]==NIL) goto irtglIF390;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[3];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(*ftab[71])(ctx,2,local+5,&ftab[71],fqv[191]); /*array-dimension*/
	local[5]= w;
irtglWHL392:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto irtglWHX393;
	local[6]= local[3];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(*ftab[72])(ctx,2,local+6,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[6]= w;
	w = local[0];
	ctx->vsp=local+7;
	local[0] = cons(ctx,local[6],w);
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto irtglWHL392;
irtglWHX393:
	local[6]= NIL;
irtglBLK394:
	w = NIL;
	local[4]= w;
	goto irtglIF391;
irtglIF390:
	local[4]= NIL;
irtglIF391:
	w = local[4];
	goto irtglWHL387;
irtglWHX388:
	local[3]= NIL;
irtglBLK389:
	w = NIL;
	w = local[0];
	local[0]= w;
irtglBLK386:
	ctx->vsp=local; return(local[0]);}

/*:calc-bounding-box*/
static pointer irtglM395glvertices_calc_bounding_box(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[193];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+2;
	w=(*ftab[73])(ctx,2,local+0,&ftab[73],fqv[194]); /*make-bounding-box*/
	argv[0]->c.obj.iv[10] = w;
	w = argv[0]->c.obj.iv[10];
	local[0]= w;
irtglBLK396:
	ctx->vsp=local; return(local[0]);}

/*:vertices*/
static pointer irtglM397glvertices_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[10]!=NIL) goto irtglIF399;
	local[0]= argv[0];
	local[1]= fqv[195];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto irtglIF400;
irtglIF399:
	local[0]= NIL;
irtglIF400:
	local[0]= argv[0]->c.obj.iv[10];
	local[1]= fqv[196];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[96];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
irtglBLK398:
	ctx->vsp=local; return(local[0]);}

/*:reset-offset-from-parent*/
static pointer irtglM401glvertices_reset_offset_from_parent(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[197];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[198];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[199];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	w = argv[0];
	local[0]= w;
irtglBLK402:
	ctx->vsp=local; return(local[0]);}

/*:expand-vertices*/
static pointer irtglM403glvertices_expand_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[0]->c.obj.iv[8];
irtglWHL405:
	if (local[2]==NIL) goto irtglWHX406;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= argv[0];
	local[4]= fqv[200];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	w = local[0];
	ctx->vsp=local+4;
	local[0] = cons(ctx,local[3],w);
	goto irtglWHL405;
irtglWHX406:
	local[3]= NIL;
irtglBLK407:
	w = NIL;
	argv[0]->c.obj.iv[8] = local[0];
	w = argv[0]->c.obj.iv[8];
	local[0]= w;
irtglBLK404:
	ctx->vsp=local; return(local[0]);}

/*:expand-vertices-info*/
static pointer irtglM408glvertices_expand_vertices_info(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= fqv[201];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(*ftab[69])(ctx,2,local+0,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= fqv[96];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(*ftab[69])(ctx,2,local+1,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= loadglobal(fqv[149]);
	local[3]= makeint((eusinteger_t)3L);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,2,local+2); /*instantiate*/
	local[2]= w;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	local[4]= local[1];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(*ftab[71])(ctx,2,local+4,&ftab[71],fqv[191]); /*array-dimension*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)GREATERP(ctx,2,local+3); /*>*/
	if (w==NIL) goto irtglIF410;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)3L);
	ctx->vsp=local+5;
	w=(*ftab[74])(ctx,2,local+3,&ftab[74],fqv[202]); /*make-matrix*/
	local[3]= w;
	local[4]= loadglobal(fqv[110]);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)INSTANTIATE(ctx,2,local+4); /*instantiate*/
	local[4]= w;
	local[5]= fqv[96];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(*ftab[69])(ctx,2,local+5,&ftab[69],fqv[186]); /*assoc*/
	local[5]= w;
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(*ftab[70])(ctx,2,local+5,&ftab[70],fqv[187]); /*delete*/
	argv[2] = w;
	local[5]= fqv[201];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(*ftab[69])(ctx,2,local+5,&ftab[69],fqv[186]); /*assoc*/
	local[5]= w;
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(*ftab[70])(ctx,2,local+5,&ftab[70],fqv[187]); /*delete*/
	argv[2] = w;
	local[5]= fqv[203];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(*ftab[69])(ctx,2,local+5,&ftab[69],fqv[186]); /*assoc*/
	local[5]= w;
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(*ftab[70])(ctx,2,local+5,&ftab[70],fqv[187]); /*delete*/
	argv[2] = w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
irtglWHL412:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto irtglWHX413;
	local[7]= local[4];
	local[8]= local[5];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)SETELT(ctx,3,local+7); /*setelt*/
	local[7]= local[1];
	local[8]= local[0];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(*ftab[72])(ctx,3,local+7,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[7]= local[3];
	local[8]= local[5];
	local[9]= local[2];
	local[10]= T;
	ctx->vsp=local+11;
	w=(*ftab[72])(ctx,4,local+7,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto irtglWHL412;
irtglWHX413:
	local[7]= NIL;
irtglBLK414:
	w = NIL;
	local[5]= argv[2];
	local[6]= fqv[96];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,2,local+6); /*list*/
	local[6]= w;
	local[7]= fqv[201];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,2,local+6); /*list*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)NCONC(ctx,2,local+5); /*nconc*/
	argv[2] = w;
	w = argv[2];
	local[3]= w;
	goto irtglIF411;
irtglIF410:
	local[3]= argv[2];
irtglIF411:
	w = local[3];
	local[0]= w;
irtglBLK409:
	ctx->vsp=local; return(local[0]);}

/*:use-flat-shader*/
static pointer irtglM415glvertices_use_flat_shader(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= argv[0]->c.obj.iv[8];
irtglWHL417:
	if (local[1]==NIL) goto irtglWHX418;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= local[0];
	local[3]= fqv[204];
	local[4]= T;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,2,local+3); /*list*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)NCONC(ctx,2,local+2); /*nconc*/
	goto irtglWHL417;
irtglWHX418:
	local[2]= NIL;
irtglBLK419:
	w = NIL;
	local[0]= w;
irtglBLK416:
	ctx->vsp=local; return(local[0]);}

/*:use-smooth-shader*/
static pointer irtglM420glvertices_use_smooth_shader(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= argv[0]->c.obj.iv[8];
irtglWHL422:
	if (local[1]==NIL) goto irtglWHX423;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= fqv[204];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(*ftab[69])(ctx,2,local+2,&ftab[69],fqv[186]); /*assoc*/
	local[2]= w;
	if (local[2]==NIL) goto irtglIF425;
	local[3]= local[2];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[70])(ctx,2,local+3,&ftab[70],fqv[187]); /*delete*/
	local[3]= w;
	goto irtglIF426;
irtglIF425:
	local[3]= NIL;
irtglIF426:
	w = local[3];
	goto irtglWHL422;
irtglWHX423:
	local[2]= NIL;
irtglBLK424:
	w = NIL;
	local[0]= w;
irtglBLK421:
	ctx->vsp=local; return(local[0]);}

/*:calc-normals*/
static pointer irtglM427glvertices_calc_normals(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtglENT432;}
	local[0]= NIL;
irtglENT432:
	if (n>=4) { local[1]=(argv[3]); goto irtglENT431;}
	local[1]= T;
irtglENT431:
	if (n>=5) { local[2]=(argv[4]); goto irtglENT430;}
	local[2]= T;
irtglENT430:
irtglENT429:
	if (n>5) maerror();
	local[3]= NIL;
	local[4]= argv[0]->c.obj.iv[8];
irtglWHL433:
	if (local[4]==NIL) goto irtglWHX434;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= fqv[203];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(*ftab[69])(ctx,2,local+5,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= fqv[205];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(*ftab[69])(ctx,2,local+6,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	local[7]= fqv[201];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(*ftab[69])(ctx,2,local+7,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= fqv[96];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(*ftab[69])(ctx,2,local+8,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= loadglobal(fqv[149]);
	local[10]= makeint((eusinteger_t)3L);
	ctx->vsp=local+11;
	w=(pointer)INSTANTIATE(ctx,2,local+9); /*instantiate*/
	local[9]= w;
	local[10]= loadglobal(fqv[149]);
	local[11]= makeint((eusinteger_t)3L);
	ctx->vsp=local+12;
	w=(pointer)INSTANTIATE(ctx,2,local+10); /*instantiate*/
	local[10]= w;
	local[11]= loadglobal(fqv[149]);
	local[12]= makeint((eusinteger_t)3L);
	ctx->vsp=local+13;
	w=(pointer)INSTANTIATE(ctx,2,local+11); /*instantiate*/
	local[11]= w;
	local[12]= loadglobal(fqv[149]);
	local[13]= makeint((eusinteger_t)3L);
	ctx->vsp=local+14;
	w=(pointer)INSTANTIATE(ctx,2,local+12); /*instantiate*/
	local[12]= w;
	local[13]= loadglobal(fqv[149]);
	local[14]= makeint((eusinteger_t)3L);
	ctx->vsp=local+15;
	w=(pointer)INSTANTIATE(ctx,2,local+13); /*instantiate*/
	local[13]= w;
	local[14]= loadglobal(fqv[149]);
	local[15]= makeint((eusinteger_t)3L);
	ctx->vsp=local+16;
	w=(pointer)INSTANTIATE(ctx,2,local+14); /*instantiate*/
	local[14]= w;
	local[15]= local[6];
	local[16]= local[15];
	if (fqv[206]!=local[16]) goto irtglIF436;
	local[6] = makeint((eusinteger_t)3L);
	local[16]= local[6];
	goto irtglIF437;
irtglIF436:
	local[16]= local[15];
	if (fqv[207]!=local[16]) goto irtglIF438;
	local[6] = makeint((eusinteger_t)4L);
	local[16]= local[6];
	goto irtglIF439;
irtglIF438:
	local[16]= local[15];
	if (fqv[208]!=local[16]) goto irtglIF440;
	local[6] = makeint((eusinteger_t)2L);
	local[16]= local[6];
	goto irtglIF441;
irtglIF440:
	local[16]= local[15];
	if (fqv[209]!=local[16]) goto irtglIF442;
	local[6] = makeint((eusinteger_t)3L);
	local[16]= fqv[210];
	ctx->vsp=local+17;
	w=(*ftab[31])(ctx,1,local+16,&ftab[31],fqv[81]); /*warn*/
	local[16]= w;
	goto irtglIF443;
irtglIF442:
	if (T==NIL) goto irtglIF444;
	local[16]= fqv[211];
	ctx->vsp=local+17;
	w=(*ftab[31])(ctx,1,local+16,&ftab[31],fqv[81]); /*warn*/
	w = NIL;
	ctx->vsp=local+16;
	local[0]=w;
	goto irtglBLK428;
	goto irtglIF445;
irtglIF444:
	local[16]= NIL;
irtglIF445:
irtglIF443:
irtglIF441:
irtglIF439:
irtglIF437:
	w = local[16];
	if (local[5]==NIL) goto irtglAND448;
	if (local[0]!=NIL) goto irtglAND448;
	goto irtglIF446;
irtglAND448:
	if (local[1]==NIL) goto irtglIF449;
	local[15]= argv[0];
	local[16]= fqv[200];
	local[17]= local[3];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[15]= fqv[201];
	local[16]= local[3];
	ctx->vsp=local+17;
	w=(*ftab[69])(ctx,2,local+15,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.car;
	local[15]= fqv[96];
	local[16]= local[3];
	ctx->vsp=local+17;
	w=(*ftab[69])(ctx,2,local+15,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.car;
	local[15]= local[8];
	goto irtglIF450;
irtglIF449:
	local[15]= NIL;
irtglIF450:
	if (local[5]==NIL) goto irtglIF451;
	local[15]= fqv[203];
	local[16]= local[3];
	ctx->vsp=local+17;
	w=(*ftab[69])(ctx,2,local+15,&ftab[69],fqv[186]); /*assoc*/
	local[15]= w;
	local[16]= local[3];
	ctx->vsp=local+17;
	w=(*ftab[70])(ctx,2,local+15,&ftab[70],fqv[187]); /*delete*/
	local[15]= w;
	goto irtglIF452;
irtglIF451:
	local[15]= NIL;
irtglIF452:
	local[15]= local[8];
	local[16]= makeint((eusinteger_t)0L);
	ctx->vsp=local+17;
	w=(*ftab[71])(ctx,2,local+15,&ftab[71],fqv[191]); /*array-dimension*/
	local[15]= w;
	local[16]= local[15];
	local[17]= makeint((eusinteger_t)3L);
	ctx->vsp=local+18;
	w=(*ftab[74])(ctx,2,local+16,&ftab[74],fqv[202]); /*make-matrix*/
	local[5] = w;
	if (local[7]==NIL) goto irtglCON454;
	local[16]= makeint((eusinteger_t)0L);
	local[17]= local[7];
	ctx->vsp=local+18;
	w=(pointer)LENGTH(ctx,1,local+17); /*length*/
	local[17]= w;
	local[18]= local[6];
	ctx->vsp=local+19;
	w=(pointer)QUOTIENT(ctx,2,local+17); /*/*/
	local[17]= w;
irtglWHL455:
	local[18]= local[16];
	w = local[17];
	if ((eusinteger_t)local[18] >= (eusinteger_t)w) goto irtglWHX456;
	local[18]= local[8];
	local[19]= local[7];
	local[20]= local[6];
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	local[21]= makeint((eusinteger_t)0L);
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[19]= w;
	local[20]= local[9];
	ctx->vsp=local+21;
	w=(*ftab[72])(ctx,3,local+18,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[18]= local[8];
	local[19]= local[7];
	local[20]= local[6];
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	local[21]= makeint((eusinteger_t)1L);
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[19]= w;
	local[20]= local[10];
	ctx->vsp=local+21;
	w=(*ftab[72])(ctx,3,local+18,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[18]= local[8];
	local[19]= local[7];
	local[20]= local[6];
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	local[21]= makeint((eusinteger_t)2L);
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[19]= w;
	local[20]= local[11];
	ctx->vsp=local+21;
	w=(*ftab[72])(ctx,3,local+18,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[18]= local[10];
	local[19]= local[9];
	local[20]= local[12];
	ctx->vsp=local+21;
	w=(pointer)VMINUS(ctx,3,local+18); /*v-*/
	local[18]= w;
	local[19]= local[11];
	local[20]= local[9];
	local[21]= local[13];
	ctx->vsp=local+22;
	w=(pointer)VMINUS(ctx,3,local+19); /*v-*/
	local[19]= w;
	local[20]= local[14];
	ctx->vsp=local+21;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+18); /*v**/
	local[18]= local[14];
	local[19]= local[14];
	ctx->vsp=local+20;
	w=(pointer)VNORMALIZE(ctx,2,local+18); /*normalize-vector*/
	local[18]= local[5];
	local[19]= local[7];
	local[20]= local[6];
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	local[21]= makeint((eusinteger_t)0L);
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[19]= w;
	local[20]= local[14];
	local[21]= T;
	ctx->vsp=local+22;
	w=(*ftab[72])(ctx,4,local+18,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[18]= local[5];
	local[19]= local[7];
	local[20]= local[6];
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	local[21]= makeint((eusinteger_t)1L);
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[19]= w;
	local[20]= local[14];
	local[21]= T;
	ctx->vsp=local+22;
	w=(*ftab[72])(ctx,4,local+18,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[18]= local[5];
	local[19]= local[7];
	local[20]= local[6];
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	local[21]= makeint((eusinteger_t)2L);
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[19]= w;
	local[20]= local[14];
	local[21]= T;
	ctx->vsp=local+22;
	w=(*ftab[72])(ctx,4,local+18,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[18]= local[16];
	ctx->vsp=local+19;
	w=(pointer)ADD1(ctx,1,local+18); /*1+*/
	local[16] = w;
	goto irtglWHL455;
irtglWHX456:
	local[18]= NIL;
irtglBLK457:
	w = NIL;
	local[16]= w;
	goto irtglCON453;
irtglCON454:
	local[16]= makeint((eusinteger_t)0L);
	local[17]= local[15];
	local[18]= local[6];
	ctx->vsp=local+19;
	w=(pointer)QUOTIENT(ctx,2,local+17); /*/*/
	local[17]= w;
irtglWHL459:
	local[18]= local[16];
	w = local[17];
	if ((eusinteger_t)local[18] >= (eusinteger_t)w) goto irtglWHX460;
	local[18]= local[8];
	local[19]= local[6];
	local[20]= local[16];
	ctx->vsp=local+21;
	w=(pointer)TIMES(ctx,2,local+19); /***/
	local[19]= w;
	local[20]= makeint((eusinteger_t)0L);
	ctx->vsp=local+21;
	w=(pointer)PLUS(ctx,2,local+19); /*+*/
	local[19]= w;
	local[20]= local[9];
	ctx->vsp=local+21;
	w=(*ftab[72])(ctx,3,local+18,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[18]= local[8];
	local[19]= local[6];
	local[20]= local[16];
	ctx->vsp=local+21;
	w=(pointer)TIMES(ctx,2,local+19); /***/
	local[19]= w;
	local[20]= makeint((eusinteger_t)1L);
	ctx->vsp=local+21;
	w=(pointer)PLUS(ctx,2,local+19); /*+*/
	local[19]= w;
	local[20]= local[10];
	ctx->vsp=local+21;
	w=(*ftab[72])(ctx,3,local+18,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[18]= local[8];
	local[19]= local[6];
	local[20]= local[16];
	ctx->vsp=local+21;
	w=(pointer)TIMES(ctx,2,local+19); /***/
	local[19]= w;
	local[20]= makeint((eusinteger_t)2L);
	ctx->vsp=local+21;
	w=(pointer)PLUS(ctx,2,local+19); /*+*/
	local[19]= w;
	local[20]= local[11];
	ctx->vsp=local+21;
	w=(*ftab[72])(ctx,3,local+18,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[18]= local[10];
	local[19]= local[9];
	local[20]= local[12];
	ctx->vsp=local+21;
	w=(pointer)VMINUS(ctx,3,local+18); /*v-*/
	local[18]= w;
	local[19]= local[11];
	local[20]= local[9];
	local[21]= local[13];
	ctx->vsp=local+22;
	w=(pointer)VMINUS(ctx,3,local+19); /*v-*/
	local[19]= w;
	local[20]= local[14];
	ctx->vsp=local+21;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+18); /*v**/
	local[18]= local[14];
	local[19]= local[14];
	ctx->vsp=local+20;
	w=(pointer)VNORMALIZE(ctx,2,local+18); /*normalize-vector*/
	local[18]= local[5];
	local[19]= local[7];
	local[20]= local[6];
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	local[21]= makeint((eusinteger_t)0L);
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[19]= w;
	local[20]= local[14];
	local[21]= T;
	ctx->vsp=local+22;
	w=(*ftab[72])(ctx,4,local+18,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[18]= local[5];
	local[19]= local[7];
	local[20]= local[6];
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	local[21]= makeint((eusinteger_t)1L);
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[19]= w;
	local[20]= local[14];
	local[21]= T;
	ctx->vsp=local+22;
	w=(*ftab[72])(ctx,4,local+18,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[18]= local[5];
	local[19]= local[7];
	local[20]= local[6];
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	local[21]= makeint((eusinteger_t)2L);
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[19]= w;
	local[20]= local[14];
	local[21]= T;
	ctx->vsp=local+22;
	w=(*ftab[72])(ctx,4,local+18,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[18]= local[16];
	ctx->vsp=local+19;
	w=(pointer)ADD1(ctx,1,local+18); /*1+*/
	local[16] = w;
	goto irtglWHL459;
irtglWHX460:
	local[18]= NIL;
irtglBLK461:
	w = NIL;
	local[16]= w;
	goto irtglCON453;
irtglCON458:
	local[16]= NIL;
irtglCON453:
	local[16]= local[3];
	local[17]= fqv[203];
	local[18]= local[5];
	ctx->vsp=local+19;
	w=(pointer)LIST(ctx,2,local+17); /*list*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)LIST(ctx,1,local+17); /*list*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)NCONC(ctx,2,local+16); /*nconc*/
	if (local[2]==NIL) goto irtglIF462;
	local[16]= local[3];
	local[17]= fqv[204];
	local[18]= T;
	ctx->vsp=local+19;
	w=(pointer)LIST(ctx,2,local+17); /*list*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)LIST(ctx,1,local+17); /*list*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)NCONC(ctx,2,local+16); /*nconc*/
	local[16]= w;
	goto irtglIF463;
irtglIF462:
	local[16]= NIL;
irtglIF463:
	w = local[16];
	local[15]= w;
	goto irtglIF447;
irtglIF446:
	local[15]= NIL;
irtglIF447:
	w = local[15];
	goto irtglWHL433;
irtglWHX434:
	local[5]= NIL;
irtglBLK435:
	w = NIL;
	local[0]= w;
irtglBLK428:
	ctx->vsp=local; return(local[0]);}

/*:mirror-axis*/
static pointer irtglM464glvertices_mirror_axis(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[212], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtglKEY466;
	local[0] = T;
irtglKEY466:
	if (n & (1<<1)) goto irtglKEY467;
	local[1] = T;
irtglKEY467:
	if (n & (1<<2)) goto irtglKEY468;
	local[2] = fqv[40];
irtglKEY468:
	local[3]= local[2];
	local[4]= local[3];
	if (fqv[39]!=local[4]) goto irtglIF469;
	local[2] = makeint((eusinteger_t)0L);
	local[4]= local[2];
	goto irtglIF470;
irtglIF469:
	local[4]= local[3];
	if (fqv[40]!=local[4]) goto irtglIF471;
	local[2] = makeint((eusinteger_t)1L);
	local[4]= local[2];
	goto irtglIF472;
irtglIF471:
	local[4]= local[3];
	if (fqv[213]!=local[4]) goto irtglIF473;
	local[2] = makeint((eusinteger_t)2L);
	local[4]= local[2];
	goto irtglIF474;
irtglIF473:
	local[4]= NIL;
irtglIF474:
irtglIF472:
irtglIF470:
	w = local[4];
	local[3]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+4;
	w=(pointer)COPYOBJ(ctx,1,local+3); /*copy-object*/
	local[3]= w;
	local[4]= loadglobal(fqv[149]);
	local[5]= makeint((eusinteger_t)3L);
	ctx->vsp=local+6;
	w=(pointer)INSTANTIATE(ctx,2,local+4); /*instantiate*/
	local[4]= w;
	local[5]= NIL;
	local[6]= local[3];
irtglWHL475:
	if (local[6]==NIL) goto irtglWHX476;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= fqv[96];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(*ftab[69])(ctx,2,local+7,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= local[7];
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(*ftab[71])(ctx,2,local+8,&ftab[71],fqv[191]); /*array-dimension*/
	local[8]= w;
	if (local[8]==NIL) goto irtglIF478;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= local[8];
irtglWHL480:
	local[11]= local[9];
	w = local[10];
	if ((eusinteger_t)local[11] >= (eusinteger_t)w) goto irtglWHX481;
	local[11]= local[7];
	local[12]= local[9];
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(*ftab[72])(ctx,3,local+11,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[11]= local[4];
	local[12]= local[2];
	local[13]= local[4];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)MINUS(ctx,1,local+13); /*-*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SETELT(ctx,3,local+11); /*setelt*/
	local[11]= local[7];
	local[12]= local[9];
	local[13]= local[4];
	local[14]= T;
	ctx->vsp=local+15;
	w=(*ftab[72])(ctx,4,local+11,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[9] = w;
	goto irtglWHL480;
irtglWHX481:
	local[11]= NIL;
irtglBLK482:
	w = NIL;
	if (local[1]==NIL) goto irtglIF483;
	local[9]= fqv[201];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(*ftab[69])(ctx,2,local+9,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= local[9];
	ctx->vsp=local+11;
	w=(pointer)LENGTH(ctx,1,local+10); /*length*/
	local[10]= w;
	local[11]= makeint((eusinteger_t)3L);
	ctx->vsp=local+12;
	w=(pointer)QUOTIENT(ctx,2,local+10); /*/*/
	local[10]= w;
	local[11]= NIL;
	local[12]= NIL;
	local[13]= NIL;
	local[14]= makeint((eusinteger_t)0L);
	local[15]= local[10];
irtglWHL485:
	local[16]= local[14];
	w = local[15];
	if ((eusinteger_t)local[16] >= (eusinteger_t)w) goto irtglWHX486;
	local[16]= local[9];
	local[17]= local[14];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)3L)); i=intval(local[17]);
		local[17]=(makeint(i * j));}
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[11] = w;
	local[16]= local[9];
	local[17]= local[14];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)3L)); i=intval(local[17]);
		local[17]=(makeint(i * j));}
	w = makeint((eusinteger_t)1L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[17]= (pointer)((eusinteger_t)local[17] + (eusinteger_t)w);
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[12] = w;
	local[16]= local[9];
	local[17]= local[14];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)3L)); i=intval(local[17]);
		local[17]=(makeint(i * j));}
	w = makeint((eusinteger_t)2L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[17]= (pointer)((eusinteger_t)local[17] + (eusinteger_t)w);
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[13] = w;
	local[16]= local[9];
	local[17]= local[14];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)3L)); i=intval(local[17]);
		local[17]=(makeint(i * j));}
	local[18]= local[13];
	ctx->vsp=local+19;
	w=(pointer)SETELT(ctx,3,local+16); /*setelt*/
	local[16]= local[9];
	local[17]= local[14];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)3L)); i=intval(local[17]);
		local[17]=(makeint(i * j));}
	w = makeint((eusinteger_t)1L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[17]= (pointer)((eusinteger_t)local[17] + (eusinteger_t)w);
	local[18]= local[12];
	ctx->vsp=local+19;
	w=(pointer)SETELT(ctx,3,local+16); /*setelt*/
	local[16]= local[9];
	local[17]= local[14];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)3L)); i=intval(local[17]);
		local[17]=(makeint(i * j));}
	w = makeint((eusinteger_t)2L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[17]= (pointer)((eusinteger_t)local[17] + (eusinteger_t)w);
	local[18]= local[11];
	ctx->vsp=local+19;
	w=(pointer)SETELT(ctx,3,local+16); /*setelt*/
	local[16]= local[14];
	ctx->vsp=local+17;
	w=(pointer)ADD1(ctx,1,local+16); /*1+*/
	local[14] = w;
	goto irtglWHL485;
irtglWHX486:
	local[16]= NIL;
irtglBLK487:
	w = NIL;
	local[9]= w;
	goto irtglIF484;
irtglIF483:
	local[9]= NIL;
irtglIF484:
	goto irtglIF479;
irtglIF478:
	local[9]= NIL;
irtglIF479:
	w = local[9];
	goto irtglWHL475;
irtglWHX476:
	local[7]= NIL;
irtglBLK477:
	w = NIL;
	if (local[0]==NIL) goto irtglIF488;
	local[5]= loadglobal(fqv[214]);
	ctx->vsp=local+6;
	w=(pointer)INSTANTIATE(ctx,1,local+5); /*instantiate*/
	local[5]= w;
	local[6]= local[5];
	local[7]= fqv[45];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	w = local[5];
	local[5]= w;
	goto irtglIF489;
irtglIF488:
	argv[0]->c.obj.iv[8] = local[3];
	local[5]= argv[0];
irtglIF489:
	w = local[5];
	local[0]= w;
irtglBLK465:
	ctx->vsp=local; return(local[0]);}

/*:convert-to-faces*/
static pointer irtglM490glvertices_convert_to_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtglRST492:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[215], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtglKEY493;
	local[1] = fqv[216];
irtglKEY493:
	local[2]= NIL;
	local[3]= NIL;
	local[4]= argv[0]->c.obj.iv[8];
irtglWHL494:
	if (local[4]==NIL) goto irtglWHX495;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= fqv[96];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(*ftab[69])(ctx,2,local+5,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= fqv[203];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(*ftab[69])(ctx,2,local+6,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	local[7]= fqv[201];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(*ftab[69])(ctx,2,local+7,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= local[7];
	ctx->vsp=local+9;
	w=(pointer)LENGTH(ctx,1,local+8); /*length*/
	local[8]= w;
	local[9]= fqv[205];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(*ftab[69])(ctx,2,local+9,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= NIL;
	local[11]= NIL;
	local[12]= local[9];
	local[13]= local[12];
	if (fqv[206]!=local[13]) goto irtglIF497;
	local[10] = makeint((eusinteger_t)3L);
	local[13]= local[10];
	goto irtglIF498;
irtglIF497:
	local[13]= local[12];
	if (fqv[207]!=local[13]) goto irtglIF499;
	local[10] = makeint((eusinteger_t)4L);
	local[13]= local[10];
	goto irtglIF500;
irtglIF499:
	if (T==NIL) goto irtglIF501;
	local[13]= fqv[217];
	local[14]= local[9];
	ctx->vsp=local+15;
	w=(*ftab[31])(ctx,2,local+13,&ftab[31],fqv[81]); /*warn*/
	w = NIL;
	ctx->vsp=local+13;
	local[0]=w;
	goto irtglBLK491;
	goto irtglIF502;
irtglIF501:
	local[13]= NIL;
irtglIF502:
irtglIF500:
irtglIF498:
	w = local[13];
	local[12]= local[8];
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)QUOTIENT(ctx,2,local+12); /*/*/
	local[12]= w;
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)TIMES(ctx,2,local+12); /***/
	local[8] = w;
	if (local[7]==NIL) goto irtglCON504;
	local[12]= makeint((eusinteger_t)0L);
	local[13]= makeint((eusinteger_t)0L);
irtglTAG506:
	local[14]= local[13];
	local[15]= local[8];
	ctx->vsp=local+16;
	w=(pointer)GREQP(ctx,2,local+14); /*>=*/
	if (w==NIL) goto irtglIF507;
	w = NIL;
	ctx->vsp=local+14;
	local[12]=w;
	goto irtglBLK505;
	goto irtglIF508;
irtglIF507:
	local[14]= NIL;
irtglIF508:
	local[14]= NIL;
	local[15]= NIL;
	local[16]= makeint((eusinteger_t)0L);
	local[17]= local[10];
irtglWHL509:
	local[18]= local[16];
	w = local[17];
	if ((eusinteger_t)local[18] >= (eusinteger_t)w) goto irtglWHX510;
	local[18]= local[5];
	local[19]= local[7];
	local[20]= local[13];
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(*ftab[72])(ctx,2,local+18,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[18]= w;
	w = local[14];
	ctx->vsp=local+19;
	local[14] = cons(ctx,local[18],w);
	if (local[6]==NIL) goto irtglIF512;
	local[18]= local[6];
	local[19]= local[7];
	local[20]= local[13];
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(*ftab[72])(ctx,2,local+18,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[18]= w;
	w = local[15];
	ctx->vsp=local+19;
	local[15] = cons(ctx,local[18],w);
	local[18]= local[15];
	goto irtglIF513;
irtglIF512:
	local[18]= NIL;
irtglIF513:
	local[18]= local[16];
	ctx->vsp=local+19;
	w=(pointer)ADD1(ctx,1,local+18); /*1+*/
	local[16] = w;
	goto irtglWHL509;
irtglWHX510:
	local[18]= NIL;
irtglBLK511:
	w = NIL;
	local[16]= local[1];
	local[17]= local[16];
	if (fqv[218]!=local[17]) goto irtglIF514;
	ctx->vsp=local+17;
	local[17]= makeclosure(codevec,quotevec,irtglCLO516,env,argv,local);
	local[18]= local[14];
	ctx->vsp=local+19;
	w=(pointer)NREVERSE(ctx,1,local+18); /*nreverse*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)MAPCAR(ctx,2,local+17); /*mapcar*/
	local[17]= w;
	goto irtglIF515;
irtglIF514:
	local[17]= local[16];
	if (fqv[216]!=local[17]) goto irtglIF517;
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)NREVERSE(ctx,1,local+17); /*nreverse*/
	local[17]= w;
	goto irtglIF518;
irtglIF517:
	if (T==NIL) goto irtglIF519;
	local[17]= NIL;
	goto irtglIF520;
irtglIF519:
	local[17]= NIL;
irtglIF520:
irtglIF518:
irtglIF515:
	w = local[17];
	local[14] = w;
	local[16]= loadglobal(fqv[219]);
	ctx->vsp=local+17;
	w=(pointer)INSTANTIATE(ctx,1,local+16); /*instantiate*/
	local[16]= w;
	local[17]= local[16];
	local[18]= fqv[45];
	local[19]= fqv[96];
	local[20]= local[14];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,4,local+17); /*send*/
	w = local[16];
	local[16]= w;
	goto irtglCON521;
irtglCON522:
	local[16]= NIL;
irtglCON521:
	w = local[11];
	ctx->vsp=local+17;
	local[11] = cons(ctx,local[16],w);
	w = local[11];
	local[14]= local[12];
	local[15]= makeint((eusinteger_t)1L);
	ctx->vsp=local+16;
	w=(pointer)PLUS(ctx,2,local+14); /*+*/
	local[14]= w;
	local[15]= local[13];
	local[16]= local[10];
	ctx->vsp=local+17;
	w=(pointer)PLUS(ctx,2,local+15); /*+*/
	local[15]= w;
	local[12] = local[14];
	local[13] = local[15];
	w = NIL;
	ctx->vsp=local+14;
	goto irtglTAG506;
	w = NIL;
	local[12]= w;
irtglBLK505:
	goto irtglCON503;
irtglCON504:
	local[12]= makeint((eusinteger_t)0L);
	local[13]= makeint((eusinteger_t)0L);
irtglTAG525:
	local[14]= local[13];
	local[15]= local[5];
	local[16]= makeint((eusinteger_t)0L);
	ctx->vsp=local+17;
	w=(*ftab[71])(ctx,2,local+15,&ftab[71],fqv[191]); /*array-dimension*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)GREQP(ctx,2,local+14); /*>=*/
	if (w==NIL) goto irtglIF526;
	w = NIL;
	ctx->vsp=local+14;
	local[12]=w;
	goto irtglBLK524;
	goto irtglIF527;
irtglIF526:
	local[14]= NIL;
irtglIF527:
	local[14]= NIL;
	local[15]= NIL;
	local[16]= makeint((eusinteger_t)0L);
	local[17]= local[10];
irtglWHL528:
	local[18]= local[16];
	w = local[17];
	if ((eusinteger_t)local[18] >= (eusinteger_t)w) goto irtglWHX529;
	local[18]= local[5];
	local[19]= local[13];
	local[20]= local[16];
	ctx->vsp=local+21;
	w=(pointer)PLUS(ctx,2,local+19); /*+*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(*ftab[72])(ctx,2,local+18,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[18]= w;
	w = local[14];
	ctx->vsp=local+19;
	local[14] = cons(ctx,local[18],w);
	if (local[6]==NIL) goto irtglIF531;
	local[18]= local[6];
	local[19]= local[13];
	local[20]= local[16];
	ctx->vsp=local+21;
	w=(pointer)PLUS(ctx,2,local+19); /*+*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(*ftab[72])(ctx,2,local+18,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[18]= w;
	w = local[15];
	ctx->vsp=local+19;
	local[15] = cons(ctx,local[18],w);
	local[18]= local[15];
	goto irtglIF532;
irtglIF531:
	local[18]= NIL;
irtglIF532:
	local[18]= local[16];
	ctx->vsp=local+19;
	w=(pointer)ADD1(ctx,1,local+18); /*1+*/
	local[16] = w;
	goto irtglWHL528;
irtglWHX529:
	local[18]= NIL;
irtglBLK530:
	w = NIL;
	local[16]= local[1];
	local[17]= local[16];
	if (fqv[218]!=local[17]) goto irtglIF533;
	ctx->vsp=local+17;
	local[17]= makeclosure(codevec,quotevec,irtglCLO535,env,argv,local);
	local[18]= local[14];
	ctx->vsp=local+19;
	w=(pointer)NREVERSE(ctx,1,local+18); /*nreverse*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)MAPCAR(ctx,2,local+17); /*mapcar*/
	local[17]= w;
	goto irtglIF534;
irtglIF533:
	local[17]= local[16];
	if (fqv[216]!=local[17]) goto irtglIF536;
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)NREVERSE(ctx,1,local+17); /*nreverse*/
	local[17]= w;
	goto irtglIF537;
irtglIF536:
	if (T==NIL) goto irtglIF538;
	local[17]= NIL;
	goto irtglIF539;
irtglIF538:
	local[17]= NIL;
irtglIF539:
irtglIF537:
irtglIF534:
	w = local[17];
	local[14] = w;
	local[16]= loadglobal(fqv[219]);
	ctx->vsp=local+17;
	w=(pointer)INSTANTIATE(ctx,1,local+16); /*instantiate*/
	local[16]= w;
	local[17]= local[16];
	local[18]= fqv[45];
	local[19]= fqv[96];
	local[20]= local[14];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,4,local+17); /*send*/
	w = local[16];
	local[16]= w;
	goto irtglCON540;
irtglCON541:
	local[16]= NIL;
irtglCON540:
	w = local[11];
	ctx->vsp=local+17;
	local[11] = cons(ctx,local[16],w);
	w = local[11];
	local[14]= local[12];
	local[15]= makeint((eusinteger_t)1L);
	ctx->vsp=local+16;
	w=(pointer)PLUS(ctx,2,local+14); /*+*/
	local[14]= w;
	local[15]= local[13];
	local[16]= local[10];
	ctx->vsp=local+17;
	w=(pointer)PLUS(ctx,2,local+15); /*+*/
	local[15]= w;
	local[12] = local[14];
	local[13] = local[15];
	w = NIL;
	ctx->vsp=local+14;
	goto irtglTAG525;
	w = NIL;
	local[12]= w;
irtglBLK524:
	goto irtglCON503;
irtglCON523:
	local[12]= NIL;
irtglCON503:
	local[12]= local[11];
	ctx->vsp=local+13;
	w=(pointer)NREVERSE(ctx,1,local+12); /*nreverse*/
	local[12]= w;
	w = local[2];
	ctx->vsp=local+13;
	local[2] = cons(ctx,local[12],w);
	w = local[2];
	goto irtglWHL494;
irtglWHX495:
	local[5]= NIL;
irtglBLK496:
	w = NIL;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)NREVERSE(ctx,1,local+3); /*nreverse*/
	local[0]= w;
irtglBLK491:
	ctx->vsp=local; return(local[0]);}

/*:faces*/
static pointer irtglM542glvertices_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[220];
	local[2]= fqv[221];
	local[3]= fqv[218];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[75])(ctx,1,local+0,&ftab[75],fqv[222]); /*flatten*/
	local[0]= w;
irtglBLK543:
	ctx->vsp=local; return(local[0]);}

/*:convert-to-faceset*/
static pointer irtglM544glvertices_convert_to_faceset(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtglRST546:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= loadglobal(fqv[77]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[45];
	local[4]= fqv[95];
	local[5]= (pointer)get_sym_func(fqv[223]);
	local[6]= argv[0];
	local[7]= fqv[220];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)APPLY(ctx,4,local+5); /*apply*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[75])(ctx,1,local+5,&ftab[75],fqv[222]); /*flatten*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	w = local[1];
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[224];
	local[4]= argv[0];
	local[5]= fqv[85];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	w = local[1];
	local[0]= w;
irtglBLK545:
	ctx->vsp=local; return(local[0]);}

/*:set-offset*/
static pointer irtglM547glvertices_set_offset(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[225], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtglKEY549;
	local[0] = NIL;
irtglKEY549:
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,3,local+1); /*float-vector*/
	local[1]= w;
	local[2]= argv[2];
	local[3]= fqv[176];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[2];
	local[4]= fqv[102];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= NIL;
	if (local[0]==NIL) goto irtglIF550;
	local[5]= loadglobal(fqv[214]);
	ctx->vsp=local+6;
	w=(pointer)INSTANTIATE(ctx,1,local+5); /*instantiate*/
	local[5]= w;
	local[6]= local[5];
	local[7]= fqv[45];
	local[8]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+9;
	w=(pointer)COPYOBJ(ctx,1,local+8); /*copy-object*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	w = local[5];
	local[4] = w;
	local[5]= local[4];
	goto irtglIF551;
irtglIF550:
	local[4] = argv[0];
	local[5]= local[4];
irtglIF551:
	local[5]= NIL;
	local[6]= *(ovafptr(local[4],fqv[226]));
irtglWHL552:
	if (local[6]==NIL) goto irtglWHX553;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= fqv[96];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(*ftab[69])(ctx,2,local+7,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= fqv[203];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(*ftab[69])(ctx,2,local+8,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= local[2];
	local[10]= local[3];
	local[11]= local[7];
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(*ftab[76])(ctx,4,local+9,&ftab[76],fqv[227]); /*user::c-coords-transform-vector*/
	if (local[8]==NIL) goto irtglIF555;
	local[9]= local[1];
	local[10]= local[3];
	local[11]= local[8];
	local[12]= local[8];
	ctx->vsp=local+13;
	w=(*ftab[76])(ctx,4,local+9,&ftab[76],fqv[227]); /*user::c-coords-transform-vector*/
	local[9]= w;
	goto irtglIF556;
irtglIF555:
	local[9]= NIL;
irtglIF556:
	w = local[9];
	goto irtglWHL552;
irtglWHX553:
	local[7]= NIL;
irtglBLK554:
	w = NIL;
	w = local[4];
	local[0]= w;
irtglBLK548:
	ctx->vsp=local; return(local[0]);}

/*:convert-to-world*/
static pointer irtglM557glvertices_convert_to_world(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[228], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtglKEY559;
	local[0] = NIL;
irtglKEY559:
	local[1]= argv[0];
	local[2]= fqv[198];
	local[3]= argv[0];
	local[4]= fqv[85];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= fqv[229];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[199];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[85];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	w = local[1];
	local[0]= w;
irtglBLK558:
	ctx->vsp=local; return(local[0]);}

/*:glvertices*/
static pointer irtglM560glvertices_glvertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtglENT564;}
	local[0]= NIL;
irtglENT564:
	if (n>=4) { local[1]=(argv[3]); goto irtglENT563;}
	local[1]= (pointer)get_sym_func(fqv[230]);
irtglENT563:
irtglENT562:
	if (n>4) maerror();
	local[2]= NIL;
	if (local[0]==NIL) goto irtglCON566;
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,irtglCLO567,env,argv,local);
	local[4]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+5;
	w=(*ftab[62])(ctx,2,local+3,&ftab[62],fqv[146]); /*find-if*/
	local[3]= w;
	if (local[3]==NIL) goto irtglIF568;
	local[4]= loadglobal(fqv[214]);
	ctx->vsp=local+5;
	w=(pointer)INSTANTIATE(ctx,1,local+4); /*instantiate*/
	local[4]= w;
	local[5]= local[4];
	local[6]= fqv[45];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	w = local[4];
	local[2] = w;
	local[4]= local[2];
	goto irtglIF569;
irtglIF568:
	local[4]= NIL;
irtglIF569:
	w = local[4];
	local[3]= w;
	goto irtglCON565;
irtglCON566:
	local[3]= NIL;
	local[4]= argv[0]->c.obj.iv[8];
irtglWHL571:
	if (local[4]==NIL) goto irtglWHX572;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= loadglobal(fqv[214]);
	ctx->vsp=local+6;
	w=(pointer)INSTANTIATE(ctx,1,local+5); /*instantiate*/
	local[5]= w;
	local[6]= local[5];
	local[7]= fqv[45];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	w = local[5];
	local[5]= w;
	w = local[2];
	ctx->vsp=local+6;
	local[2] = cons(ctx,local[5],w);
	goto irtglWHL571;
irtglWHX572:
	local[5]= NIL;
irtglBLK573:
	w = NIL;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)NREVERSE(ctx,1,local+3); /*nreverse*/
	local[2] = w;
	local[3]= local[2];
	goto irtglCON565;
irtglCON570:
	local[3]= NIL;
irtglCON565:
	w = local[2];
	local[0]= w;
irtglBLK561:
	ctx->vsp=local; return(local[0]);}

/*:append-glvertices*/
static pointer irtglM574glvertices_append_glvertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	if (!!iscons(w)) goto irtglIF576;
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	argv[2] = w;
	local[0]= argv[2];
	goto irtglIF577;
irtglIF576:
	local[0]= NIL;
irtglIF577:
	local[0]= NIL;
	local[1]= argv[0];
	local[2]= fqv[85];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= NIL;
	local[3]= argv[2];
irtglWHL578:
	if (local[3]==NIL) goto irtglWHX579;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= *(ovafptr(local[2],fqv[226]));
	ctx->vsp=local+5;
	w=(pointer)COPYOBJ(ctx,1,local+4); /*copy-object*/
	local[4]= w;
	local[5]= local[1];
	local[6]= fqv[231];
	local[7]= local[2];
	local[8]= fqv[85];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= loadglobal(fqv[214]);
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,1,local+6); /*instantiate*/
	local[6]= w;
	local[7]= local[6];
	local[8]= fqv[45];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	w = local[6];
	local[6]= w;
	local[7]= local[6];
	local[8]= fqv[198];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= local[0];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)APPEND(ctx,2,local+7); /*append*/
	local[0] = w;
	w = local[0];
	goto irtglWHL578;
irtglWHX579:
	local[4]= NIL;
irtglBLK580:
	w = NIL;
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)APPEND(ctx,2,local+2); /*append*/
	argv[0]->c.obj.iv[8] = w;
	local[2]= argv[0];
	local[3]= fqv[195];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	w = argv[0];
	local[0]= w;
irtglBLK575:
	ctx->vsp=local; return(local[0]);}

/*:draw-on*/
static pointer irtglM581glvertices_draw_on(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[232], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtglKEY583;
	local[0] = loadglobal(fqv[152]);
irtglKEY583:
	w = NIL;
	local[0]= w;
irtglBLK582:
	ctx->vsp=local; return(local[0]);}

/*:draw*/
static pointer irtglM584glvertices_draw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtglRST586:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	local[1]= NIL;
	local[2]= argv[0];
	local[3]= fqv[85];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= fqv[86];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[185];
	ctx->vsp=local+5;
	w=(pointer)GETPROP(ctx,2,local+3); /*get*/
	local[3]= w;
	local[4]= NIL;
	local[5]= argv[2];
	local[6]= fqv[8];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= *(ovafptr(w,fqv[13]));
	local[6]= argv[2];
	local[7]= fqv[8];
	local[8]= fqv[9];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= makeint((eusinteger_t)4294967295L);
	ctx->vsp=local+7;
	w=(*ftab[36])(ctx,1,local+6,&ftab[36],fqv[92]); /*glpushattrib*/
	ctx->vsp=local+6;
	w=(*ftab[22])(ctx,0,local+6,&ftab[22],fqv[53]); /*glpushmatrix*/
	local[6]= local[2];
	local[7]= loadglobal(fqv[87]);
	ctx->vsp=local+8;
	w=(pointer)TRANSPOSE(ctx,2,local+6); /*transpose*/
	local[6]= w->c.obj.iv[1];
	ctx->vsp=local+7;
	w=(*ftab[32])(ctx,1,local+6,&ftab[32],fqv[88]); /*glmultmatrixf*/
	local[6]= makeint((eusinteger_t)2898L);
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(*ftab[77])(ctx,2,local+6,&ftab[77],fqv[233]); /*gllightmodeli*/
	local[6]= local[5];
	local[7]= argv[0];
	local[8]= fqv[82];
	ctx->vsp=local+9;
	w=(pointer)GETPROP(ctx,2,local+7); /*get*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)ASSQ(ctx,2,local+6); /*assq*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	if (local[1]==NIL) goto irtglCON588;
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(*ftab[33])(ctx,1,local+6,&ftab[33],fqv[89]); /*glcalllist*/
	local[6]= w;
	goto irtglCON587;
irtglCON588:
	local[6]= argv[0];
	local[7]= fqv[84];
	ctx->vsp=local+8;
	w=(pointer)GETPROP(ctx,2,local+6); /*get*/
	local[4] = w;
	if (local[4]==NIL) goto irtglIF590;
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)VECTORP(ctx,1,local+6); /*vectorp*/
	if (w!=NIL) goto irtglIF590;
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)irtglF7find_color(ctx,1,local+6); /*find-color*/
	local[4] = w;
	local[6]= argv[0];
	local[7]= local[4];
	local[8]= fqv[84];
	ctx->vsp=local+9;
	w=(pointer)PUTPROP(ctx,3,local+6); /*putprop*/
	local[6]= w;
	goto irtglIF591;
irtglIF590:
	local[6]= NIL;
irtglIF591:
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(*ftab[34])(ctx,1,local+6,&ftab[34],fqv[90]); /*glgenlists*/
	local[1] = w;
	local[6]= local[1];
	local[7]= makeint((eusinteger_t)4864L);
	ctx->vsp=local+8;
	w=(*ftab[35])(ctx,2,local+6,&ftab[35],fqv[91]); /*glnewlist*/
	if (local[3]==NIL) goto irtglIF592;
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(*ftab[78])(ctx,1,local+6,&ftab[78],fqv[234]); /*gldepthmask*/
	local[6]= makeint((eusinteger_t)3042L);
	ctx->vsp=local+7;
	w=(*ftab[12])(ctx,1,local+6,&ftab[12],fqv[29]); /*glenable*/
	local[6]= makeint((eusinteger_t)770L);
	local[7]= makeint((eusinteger_t)771L);
	ctx->vsp=local+8;
	w=(*ftab[44])(ctx,2,local+6,&ftab[44],fqv[111]); /*glblendfunc*/
	local[6]= w;
	goto irtglIF593;
irtglIF592:
	local[6]= NIL;
irtglIF593:
	local[6]= NIL;
	local[7]= argv[0]->c.obj.iv[8];
irtglWHL594:
	if (local[7]==NIL) goto irtglWHX595;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= fqv[205];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(*ftab[69])(ctx,2,local+8,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= fqv[189];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(*ftab[69])(ctx,2,local+9,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= fqv[96];
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(*ftab[69])(ctx,2,local+10,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= fqv[203];
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(*ftab[69])(ctx,2,local+11,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= fqv[201];
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(*ftab[69])(ctx,2,local+12,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= fqv[235];
	local[14]= local[6];
	ctx->vsp=local+15;
	w=(*ftab[69])(ctx,2,local+13,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	local[14]= fqv[204];
	local[15]= local[6];
	ctx->vsp=local+16;
	w=(*ftab[69])(ctx,2,local+14,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	local[15]= NIL;
	if (local[14]==NIL) goto irtglIF597;
	local[16]= makeint((eusinteger_t)7424L);
	ctx->vsp=local+17;
	w=(*ftab[12])(ctx,1,local+16,&ftab[12],fqv[29]); /*glenable*/
	local[16]= makeint((eusinteger_t)7424L);
	ctx->vsp=local+17;
	w=(*ftab[79])(ctx,1,local+16,&ftab[79],fqv[236]); /*glshademodel*/
	local[16]= w;
	goto irtglIF598;
irtglIF597:
	local[16]= NIL;
irtglIF598:
	if (local[4]==NIL) goto irtglCON600;
	local[16]= local[4];
	ctx->vsp=local+17;
	w=(*ftab[29])(ctx,1,local+16,&ftab[29],fqv[69]); /*glcolor3fv*/
	if (local[3]==NIL) goto irtglCON602;
	local[16]= makeint((eusinteger_t)1029L);
	local[17]= makeint((eusinteger_t)5634L);
	local[18]= loadglobal(fqv[149]);
	local[19]= local[4];
	local[20]= local[3];
	ctx->vsp=local+21;
	w=(pointer)MKFLTVEC(ctx,1,local+20); /*float-vector*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)CONCATENATE(ctx,3,local+18); /*concatenate*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[45])(ctx,3,local+16,&ftab[45],fqv[112]); /*glmaterialfv*/
	local[16]= makeint((eusinteger_t)1028L);
	local[17]= makeint((eusinteger_t)5634L);
	local[18]= makeint((eusinteger_t)0L);
	local[19]= makeint((eusinteger_t)0L);
	local[20]= makeint((eusinteger_t)0L);
	local[21]= makeint((eusinteger_t)0L);
	ctx->vsp=local+22;
	w=(pointer)MKFLTVEC(ctx,4,local+18); /*float-vector*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[45])(ctx,3,local+16,&ftab[45],fqv[112]); /*glmaterialfv*/
	local[16]= w;
	goto irtglCON601;
irtglCON602:
	local[16]= makeint((eusinteger_t)1029L);
	local[17]= makeint((eusinteger_t)5634L);
	local[18]= local[4];
	ctx->vsp=local+19;
	w=(*ftab[45])(ctx,3,local+16,&ftab[45],fqv[112]); /*glmaterialfv*/
	local[16]= makeint((eusinteger_t)1028L);
	local[17]= makeint((eusinteger_t)5634L);
	local[18]= makeflt(7.9999999999999982236432e-01);
	local[19]= makeflt(0.0000000000000000000000e+00);
	local[20]= makeflt(5.4000000000000003552714e-01);
	ctx->vsp=local+21;
	w=(pointer)MKFLTVEC(ctx,3,local+18); /*float-vector*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[45])(ctx,3,local+16,&ftab[45],fqv[112]); /*glmaterialfv*/
	local[16]= w;
	goto irtglCON601;
irtglCON603:
	local[16]= NIL;
irtglCON601:
	goto irtglCON599;
irtglCON600:
	if (local[9]==NIL) goto irtglCON604;
	local[16]= fqv[67];
	local[17]= local[9];
	ctx->vsp=local+18;
	w=(*ftab[69])(ctx,2,local+16,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	local[17]= fqv[237];
	local[18]= local[9];
	ctx->vsp=local+19;
	w=(*ftab[69])(ctx,2,local+17,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	local[18]= fqv[144];
	local[19]= local[9];
	ctx->vsp=local+20;
	w=(*ftab[69])(ctx,2,local+18,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.car;
	local[19]= fqv[238];
	local[20]= local[9];
	ctx->vsp=local+21;
	w=(*ftab[69])(ctx,2,local+19,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19]= (w)->c.cons.car;
	local[20]= fqv[239];
	local[21]= local[9];
	ctx->vsp=local+22;
	w=(*ftab[69])(ctx,2,local+20,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.car;
	local[21]= fqv[240];
	local[22]= local[9];
	ctx->vsp=local+23;
	w=(*ftab[69])(ctx,2,local+21,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21]= (w)->c.cons.car;
	local[22]= fqv[241];
	local[23]= local[9];
	ctx->vsp=local+24;
	w=(*ftab[69])(ctx,2,local+22,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22]= (w)->c.cons.car;
	local[23]= fqv[242];
	local[24]= local[9];
	ctx->vsp=local+25;
	w=(*ftab[69])(ctx,2,local+23,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15] = (w)->c.cons.car;
	if (local[16]==NIL) goto irtglIF605;
	local[23]= local[16];
	ctx->vsp=local+24;
	w=(*ftab[29])(ctx,1,local+23,&ftab[29],fqv[69]); /*glcolor3fv*/
	local[23]= makeint((eusinteger_t)1029L);
	local[24]= makeint((eusinteger_t)5634L);
	if (local[3]==NIL) goto irtglIF607;
	local[25]= loadglobal(fqv[149]);
	local[26]= local[16];
	local[27]= local[3];
	ctx->vsp=local+28;
	w=(pointer)MKFLTVEC(ctx,1,local+27); /*float-vector*/
	local[27]= w;
	ctx->vsp=local+28;
	w=(pointer)CONCATENATE(ctx,3,local+25); /*concatenate*/
	local[25]= w;
	goto irtglIF608;
irtglIF607:
	local[25]= local[16];
irtglIF608:
	ctx->vsp=local+26;
	w=(*ftab[45])(ctx,3,local+23,&ftab[45],fqv[112]); /*glmaterialfv*/
	local[23]= w;
	goto irtglIF606;
irtglIF605:
	local[23]= NIL;
irtglIF606:
	if (local[17]==NIL) goto irtglIF609;
	if (local[3]==NIL) goto irtglIF611;
	local[23]= local[17];
	local[24]= makeint((eusinteger_t)3L);
	local[25]= local[3];
	ctx->vsp=local+26;
	w=(pointer)SETELT(ctx,3,local+23); /*setelt*/
	local[23]= w;
	goto irtglIF612;
irtglIF611:
	local[23]= NIL;
irtglIF612:
	local[23]= makeint((eusinteger_t)1029L);
	local[24]= makeint((eusinteger_t)4608L);
	local[25]= local[17];
	ctx->vsp=local+26;
	w=(*ftab[45])(ctx,3,local+23,&ftab[45],fqv[112]); /*glmaterialfv*/
	local[23]= w;
	goto irtglIF610;
irtglIF609:
	local[23]= NIL;
irtglIF610:
	if (local[18]==NIL) goto irtglIF613;
	if (local[3]==NIL) goto irtglIF615;
	local[23]= local[18];
	local[24]= makeint((eusinteger_t)3L);
	local[25]= local[3];
	ctx->vsp=local+26;
	w=(pointer)SETELT(ctx,3,local+23); /*setelt*/
	local[23]= w;
	goto irtglIF616;
irtglIF615:
	local[23]= NIL;
irtglIF616:
	local[23]= makeint((eusinteger_t)1029L);
	local[24]= makeint((eusinteger_t)4609L);
	local[25]= local[18];
	ctx->vsp=local+26;
	w=(*ftab[45])(ctx,3,local+23,&ftab[45],fqv[112]); /*glmaterialfv*/
	local[23]= w;
	goto irtglIF614;
irtglIF613:
	local[23]= NIL;
irtglIF614:
	if (local[19]==NIL) goto irtglIF617;
	if (local[3]==NIL) goto irtglIF619;
	local[23]= local[19];
	local[24]= makeint((eusinteger_t)3L);
	local[25]= local[3];
	ctx->vsp=local+26;
	w=(pointer)SETELT(ctx,3,local+23); /*setelt*/
	local[23]= w;
	goto irtglIF620;
irtglIF619:
	local[23]= NIL;
irtglIF620:
	local[23]= makeint((eusinteger_t)1029L);
	local[24]= makeint((eusinteger_t)4610L);
	local[25]= local[19];
	ctx->vsp=local+26;
	w=(*ftab[45])(ctx,3,local+23,&ftab[45],fqv[112]); /*glmaterialfv*/
	local[23]= w;
	goto irtglIF618;
irtglIF617:
	local[23]= NIL;
irtglIF618:
	if (local[20]==NIL) goto irtglIF621;
	if (local[3]==NIL) goto irtglIF623;
	local[23]= local[20];
	local[24]= makeint((eusinteger_t)3L);
	local[25]= local[3];
	ctx->vsp=local+26;
	w=(pointer)SETELT(ctx,3,local+23); /*setelt*/
	local[23]= w;
	goto irtglIF624;
irtglIF623:
	local[23]= NIL;
irtglIF624:
	local[23]= makeint((eusinteger_t)1029L);
	local[24]= makeint((eusinteger_t)5632L);
	local[25]= local[20];
	ctx->vsp=local+26;
	w=(*ftab[45])(ctx,3,local+23,&ftab[45],fqv[112]); /*glmaterialfv*/
	local[23]= w;
	goto irtglIF622;
irtglIF621:
	local[23]= NIL;
irtglIF622:
	if (local[21]==NIL) goto irtglCON626;
	local[23]= makeint((eusinteger_t)1029L);
	local[24]= makeint((eusinteger_t)5633L);
	local[25]= local[21];
	ctx->vsp=local+26;
	w=(*ftab[80])(ctx,3,local+23,&ftab[80],fqv[243]); /*glmaterialf*/
	local[23]= w;
	goto irtglCON625;
irtglCON626:
	local[23]= makeint((eusinteger_t)1029L);
	local[24]= makeint((eusinteger_t)5633L);
	local[25]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+26;
	w=(*ftab[80])(ctx,3,local+23,&ftab[80],fqv[243]); /*glmaterialf*/
	local[23]= makeint((eusinteger_t)1029L);
	local[24]= makeint((eusinteger_t)4610L);
	local[25]= makeint((eusinteger_t)0L);
	local[26]= makeint((eusinteger_t)0L);
	local[27]= makeint((eusinteger_t)0L);
	local[28]= makeint((eusinteger_t)0L);
	ctx->vsp=local+29;
	w=(pointer)MKFLTVEC(ctx,4,local+25); /*float-vector*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(*ftab[45])(ctx,3,local+23,&ftab[45],fqv[112]); /*glmaterialfv*/
	local[23]= w;
	goto irtglCON625;
irtglCON627:
	local[23]= NIL;
irtglCON625:
	if (local[15]==NIL) goto irtglIF628;
	if (local[13]==NIL) goto irtglIF628;
	local[23]= local[15];
	local[24]= fqv[15];
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,2,local+23); /*send*/
	local[23]= w;
	local[24]= local[15];
	local[25]= fqv[14];
	ctx->vsp=local+26;
	w=(pointer)SEND(ctx,2,local+24); /*send*/
	local[24]= w;
	local[25]= local[15];
	local[26]= fqv[17];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,2,local+25); /*send*/
	local[25]= w;
	local[26]= makeint((eusinteger_t)3317L);
	local[27]= makeint((eusinteger_t)1L);
	ctx->vsp=local+28;
	w=(*ftab[17])(ctx,2,local+26,&ftab[17],fqv[47]); /*glpixelstorei*/
	local[26]= local[15];
	local[27]= loadglobal(fqv[117]);
	ctx->vsp=local+28;
	w=(pointer)DERIVEDP(ctx,2,local+26); /*derivedp*/
	if (w==NIL) goto irtglCON631;
	local[26]= makeint((eusinteger_t)3553L);
	local[27]= makeint((eusinteger_t)0L);
	local[28]= makeint((eusinteger_t)6407L);
	local[29]= local[23];
	local[30]= local[24];
	local[31]= makeint((eusinteger_t)0L);
	local[32]= makeint((eusinteger_t)6409L);
	local[33]= makeint((eusinteger_t)5121L);
	local[34]= local[25];
	ctx->vsp=local+35;
	w=(*ftab[50])(ctx,9,local+26,&ftab[50],fqv[128]); /*glteximage2d*/
	local[26]= w;
	goto irtglCON630;
irtglCON631:
	local[26]= local[15];
	local[27]= loadglobal(fqv[44]);
	ctx->vsp=local+28;
	w=(pointer)DERIVEDP(ctx,2,local+26); /*derivedp*/
	if (w==NIL) goto irtglCON632;
	local[26]= makeint((eusinteger_t)3553L);
	local[27]= makeint((eusinteger_t)0L);
	local[28]= makeint((eusinteger_t)6407L);
	local[29]= local[23];
	local[30]= local[24];
	local[31]= makeint((eusinteger_t)0L);
	local[32]= makeint((eusinteger_t)6407L);
	local[33]= makeint((eusinteger_t)5121L);
	local[34]= local[25];
	ctx->vsp=local+35;
	w=(*ftab[50])(ctx,9,local+26,&ftab[50],fqv[128]); /*glteximage2d*/
	local[26]= w;
	goto irtglCON630;
irtglCON632:
	local[26]= local[15];
	local[27]= loadglobal(fqv[244]);
	ctx->vsp=local+28;
	w=(pointer)DERIVEDP(ctx,2,local+26); /*derivedp*/
	if (w==NIL) goto irtglCON633;
	local[26]= makeint((eusinteger_t)3553L);
	local[27]= makeint((eusinteger_t)0L);
	local[28]= makeint((eusinteger_t)6408L);
	local[29]= local[23];
	local[30]= local[24];
	local[31]= makeint((eusinteger_t)0L);
	local[32]= makeint((eusinteger_t)6408L);
	local[33]= makeint((eusinteger_t)5121L);
	local[34]= local[25];
	ctx->vsp=local+35;
	w=(*ftab[50])(ctx,9,local+26,&ftab[50],fqv[128]); /*glteximage2d*/
	local[26]= w;
	goto irtglCON630;
irtglCON633:
	local[26]= NIL;
irtglCON630:
	local[26]= makeint((eusinteger_t)3553L);
	local[27]= makeint((eusinteger_t)10242L);
	local[28]= makeint((eusinteger_t)10497L);
	ctx->vsp=local+29;
	w=(*ftab[51])(ctx,3,local+26,&ftab[51],fqv[129]); /*gltexparameteri*/
	local[26]= makeint((eusinteger_t)3553L);
	local[27]= makeint((eusinteger_t)10243L);
	local[28]= makeint((eusinteger_t)10497L);
	ctx->vsp=local+29;
	w=(*ftab[51])(ctx,3,local+26,&ftab[51],fqv[129]); /*gltexparameteri*/
	local[26]= makeint((eusinteger_t)3553L);
	local[27]= makeint((eusinteger_t)10241L);
	local[28]= makeint((eusinteger_t)9728L);
	ctx->vsp=local+29;
	w=(*ftab[51])(ctx,3,local+26,&ftab[51],fqv[129]); /*gltexparameteri*/
	local[26]= makeint((eusinteger_t)3553L);
	local[27]= makeint((eusinteger_t)10240L);
	local[28]= makeint((eusinteger_t)9728L);
	ctx->vsp=local+29;
	w=(*ftab[51])(ctx,3,local+26,&ftab[51],fqv[129]); /*gltexparameteri*/
	local[26]= makeint((eusinteger_t)8960L);
	local[27]= makeint((eusinteger_t)8704L);
	local[28]= makeint((eusinteger_t)8448L);
	ctx->vsp=local+29;
	w=(*ftab[52])(ctx,3,local+26,&ftab[52],fqv[130]); /*gltexenvi*/
	local[26]= makeint((eusinteger_t)3553L);
	ctx->vsp=local+27;
	w=(*ftab[12])(ctx,1,local+26,&ftab[12],fqv[29]); /*glenable*/
	local[23]= w;
	goto irtglIF629;
irtglIF628:
	local[23]= NIL;
irtglIF629:
	if (local[3]==NIL) goto irtglIF634;
	local[23]= makeint((eusinteger_t)1028L);
	local[24]= makeint((eusinteger_t)5634L);
	local[25]= makeint((eusinteger_t)0L);
	local[26]= makeint((eusinteger_t)0L);
	local[27]= makeint((eusinteger_t)0L);
	local[28]= makeint((eusinteger_t)0L);
	ctx->vsp=local+29;
	w=(pointer)MKFLTVEC(ctx,4,local+25); /*float-vector*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(*ftab[45])(ctx,3,local+23,&ftab[45],fqv[112]); /*glmaterialfv*/
	local[23]= w;
	goto irtglIF635;
irtglIF634:
	local[23]= NIL;
irtglIF635:
	w = local[23];
	local[16]= w;
	goto irtglCON599;
irtglCON604:
	local[16]= makeint((eusinteger_t)1029L);
	local[17]= makeint((eusinteger_t)4608L);
	local[18]= makeflt(1.9999999999999995559108e-01);
	local[19]= makeflt(1.9999999999999995559108e-01);
	local[20]= makeflt(1.9999999999999995559108e-01);
	local[21]= makeflt(9.9999999999999977795540e-02);
	ctx->vsp=local+22;
	w=(pointer)MKFLTVEC(ctx,4,local+18); /*float-vector*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[45])(ctx,3,local+16,&ftab[45],fqv[112]); /*glmaterialfv*/
	local[16]= makeint((eusinteger_t)1029L);
	local[17]= makeint((eusinteger_t)4609L);
	local[18]= makeint((eusinteger_t)1L);
	local[19]= makeint((eusinteger_t)1L);
	local[20]= makeint((eusinteger_t)1L);
	local[21]= makeint((eusinteger_t)1L);
	ctx->vsp=local+22;
	w=(pointer)MKFLTVEC(ctx,4,local+18); /*float-vector*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[45])(ctx,3,local+16,&ftab[45],fqv[112]); /*glmaterialfv*/
	local[16]= makeint((eusinteger_t)1029L);
	local[17]= makeint((eusinteger_t)4610L);
	local[18]= makeflt(1.9999999999999995559108e-01);
	local[19]= makeflt(1.9999999999999995559108e-01);
	local[20]= makeflt(1.9999999999999995559108e-01);
	local[21]= makeflt(9.9999999999999977795540e-02);
	ctx->vsp=local+22;
	w=(pointer)MKFLTVEC(ctx,4,local+18); /*float-vector*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[45])(ctx,3,local+16,&ftab[45],fqv[112]); /*glmaterialfv*/
	local[16]= makeint((eusinteger_t)1029L);
	local[17]= makeint((eusinteger_t)5632L);
	local[18]= makeflt(9.9999999999999977795540e-02);
	local[19]= makeflt(9.9999999999999977795540e-02);
	local[20]= makeflt(9.9999999999999977795540e-02);
	local[21]= makeflt(9.9999999999999977795540e-02);
	ctx->vsp=local+22;
	w=(pointer)MKFLTVEC(ctx,4,local+18); /*float-vector*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[45])(ctx,3,local+16,&ftab[45],fqv[112]); /*glmaterialfv*/
	local[16]= makeint((eusinteger_t)1028L);
	local[17]= makeint((eusinteger_t)4608L);
	local[18]= makeflt(7.9999999999999982236432e-01);
	local[19]= makeflt(0.0000000000000000000000e+00);
	local[20]= makeflt(5.4000000000000003552714e-01);
	local[21]= makeint((eusinteger_t)1L);
	ctx->vsp=local+22;
	w=(pointer)MKFLTVEC(ctx,4,local+18); /*float-vector*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[45])(ctx,3,local+16,&ftab[45],fqv[112]); /*glmaterialfv*/
	local[16]= makeint((eusinteger_t)1028L);
	local[17]= makeint((eusinteger_t)4609L);
	local[18]= makeflt(7.9999999999999982236432e-01);
	local[19]= makeflt(0.0000000000000000000000e+00);
	local[20]= makeflt(5.4000000000000003552714e-01);
	local[21]= makeint((eusinteger_t)1L);
	ctx->vsp=local+22;
	w=(pointer)MKFLTVEC(ctx,4,local+18); /*float-vector*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[45])(ctx,3,local+16,&ftab[45],fqv[112]); /*glmaterialfv*/
	local[16]= makeint((eusinteger_t)1028L);
	local[17]= makeint((eusinteger_t)4610L);
	local[18]= makeflt(1.9999999999999995559108e-01);
	local[19]= makeflt(1.9999999999999995559108e-01);
	local[20]= makeflt(1.9999999999999995559108e-01);
	local[21]= makeint((eusinteger_t)1L);
	ctx->vsp=local+22;
	w=(pointer)MKFLTVEC(ctx,4,local+18); /*float-vector*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[45])(ctx,3,local+16,&ftab[45],fqv[112]); /*glmaterialfv*/
	local[16]= makeint((eusinteger_t)1028L);
	local[17]= makeint((eusinteger_t)5632L);
	local[18]= makeflt(9.9999999999999977795540e-02);
	local[19]= makeflt(9.9999999999999977795540e-02);
	local[20]= makeflt(9.9999999999999977795540e-02);
	local[21]= makeint((eusinteger_t)1L);
	ctx->vsp=local+22;
	w=(pointer)MKFLTVEC(ctx,4,local+18); /*float-vector*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[45])(ctx,3,local+16,&ftab[45],fqv[112]); /*glmaterialfv*/
	local[16]= w;
	goto irtglCON599;
irtglCON636:
	local[16]= NIL;
irtglCON599:
	if (local[15]==NIL) goto irtglAND639;
	if (local[13]==NIL) goto irtglAND639;
	goto irtglIF637;
irtglAND639:
	local[13] = NIL;
	local[16]= local[13];
	goto irtglIF638;
irtglIF637:
	local[16]= NIL;
irtglIF638:
	local[16]= makeint((eusinteger_t)32884L);
	ctx->vsp=local+17;
	w=(*ftab[81])(ctx,1,local+16,&ftab[81],fqv[245]); /*glenableclientstate*/
	local[16]= makeint((eusinteger_t)3L);
	local[17]= makeint((eusinteger_t)5130L);
	local[18]= makeint((eusinteger_t)0L);
	local[19]= local[10]->c.obj.iv[1];
	ctx->vsp=local+20;
	w=(*ftab[82])(ctx,4,local+16,&ftab[82],fqv[246]); /*glvertexpointer*/
	if (local[11]==NIL) goto irtglIF640;
	local[16]= makeint((eusinteger_t)32885L);
	ctx->vsp=local+17;
	w=(*ftab[81])(ctx,1,local+16,&ftab[81],fqv[245]); /*glenableclientstate*/
	local[16]= makeint((eusinteger_t)5130L);
	local[17]= makeint((eusinteger_t)0L);
	local[18]= local[11]->c.obj.iv[1];
	ctx->vsp=local+19;
	w=(*ftab[83])(ctx,3,local+16,&ftab[83],fqv[247]); /*glnormalpointer*/
	local[16]= w;
	goto irtglIF641;
irtglIF640:
	local[16]= NIL;
irtglIF641:
	if (local[13]==NIL) goto irtglIF642;
	local[16]= makeint((eusinteger_t)32888L);
	ctx->vsp=local+17;
	w=(*ftab[81])(ctx,1,local+16,&ftab[81],fqv[245]); /*glenableclientstate*/
	local[16]= makeint((eusinteger_t)2L);
	local[17]= makeint((eusinteger_t)5130L);
	local[18]= makeint((eusinteger_t)0L);
	local[19]= local[13];
	ctx->vsp=local+20;
	w=(*ftab[84])(ctx,4,local+16,&ftab[84],fqv[248]); /*gltexcoordpointer*/
	local[16]= w;
	goto irtglIF643;
irtglIF642:
	local[16]= NIL;
irtglIF643:
	local[16]= NIL;
	local[17]= local[8];
	local[18]= local[17];
	if (fqv[206]!=local[18]) goto irtglIF644;
	local[16] = makeint((eusinteger_t)4L);
	local[18]= local[16];
	goto irtglIF645;
irtglIF644:
	local[18]= local[17];
	if (fqv[207]!=local[18]) goto irtglIF646;
	local[16] = makeint((eusinteger_t)7L);
	local[18]= local[16];
	goto irtglIF647;
irtglIF646:
	local[18]= local[17];
	if (fqv[208]!=local[18]) goto irtglIF648;
	local[16] = makeint((eusinteger_t)1L);
	local[18]= local[16];
	goto irtglIF649;
irtglIF648:
	local[18]= local[17];
	if (fqv[209]!=local[18]) goto irtglIF650;
	local[16] = makeint((eusinteger_t)4L);
	local[18]= fqv[249];
	ctx->vsp=local+19;
	w=(*ftab[31])(ctx,1,local+18,&ftab[31],fqv[81]); /*warn*/
	local[18]= w;
	goto irtglIF651;
irtglIF650:
	if (T==NIL) goto irtglIF652;
	local[18]= fqv[250];
	ctx->vsp=local+19;
	w=(*ftab[31])(ctx,1,local+18,&ftab[31],fqv[81]); /*warn*/
	local[18]= local[8];
	goto irtglIF653;
irtglIF652:
	local[18]= NIL;
irtglIF653:
irtglIF651:
irtglIF649:
irtglIF647:
irtglIF645:
	w = local[18];
	if (local[16]==NIL) goto irtglIF654;
	if (local[12]==NIL) goto irtglCON657;
	local[17]= local[16];
	local[18]= local[12];
	ctx->vsp=local+19;
	w=(pointer)LENGTH(ctx,1,local+18); /*length*/
	local[18]= w;
	local[19]= makeint((eusinteger_t)5125L);
	local[20]= local[12];
	ctx->vsp=local+21;
	w=(*ftab[85])(ctx,1,local+20,&ftab[85],fqv[251]); /*user::lvector2integer-bytestring*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(*ftab[86])(ctx,4,local+17,&ftab[86],fqv[252]); /*gldrawelements*/
	local[17]= w;
	goto irtglCON656;
irtglCON657:
	local[17]= local[16];
	local[18]= makeint((eusinteger_t)0L);
	local[19]= local[10];
	local[20]= makeint((eusinteger_t)0L);
	ctx->vsp=local+21;
	w=(*ftab[71])(ctx,2,local+19,&ftab[71],fqv[191]); /*array-dimension*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(*ftab[87])(ctx,3,local+17,&ftab[87],fqv[253]); /*gldrawarrays*/
	local[17]= w;
	goto irtglCON656;
irtglCON658:
	local[17]= NIL;
irtglCON656:
	goto irtglIF655;
irtglIF654:
	local[17]= NIL;
irtglIF655:
	w = local[17];
	if (local[13]==NIL) goto irtglIF659;
	local[16]= makeint((eusinteger_t)3553L);
	ctx->vsp=local+17;
	w=(*ftab[8])(ctx,1,local+16,&ftab[8],fqv[25]); /*gldisable*/
	local[16]= makeint((eusinteger_t)32888L);
	ctx->vsp=local+17;
	w=(*ftab[88])(ctx,1,local+16,&ftab[88],fqv[254]); /*gldisableclientstate*/
	local[16]= w;
	goto irtglIF660;
irtglIF659:
	local[16]= NIL;
irtglIF660:
	if (local[11]==NIL) goto irtglIF661;
	local[16]= makeint((eusinteger_t)32885L);
	ctx->vsp=local+17;
	w=(*ftab[88])(ctx,1,local+16,&ftab[88],fqv[254]); /*gldisableclientstate*/
	local[16]= w;
	goto irtglIF662;
irtglIF661:
	local[16]= NIL;
irtglIF662:
	local[16]= makeint((eusinteger_t)32884L);
	ctx->vsp=local+17;
	w=(*ftab[88])(ctx,1,local+16,&ftab[88],fqv[254]); /*gldisableclientstate*/
	if (local[14]==NIL) goto irtglIF663;
	local[16]= makeint((eusinteger_t)7425L);
	ctx->vsp=local+17;
	w=(*ftab[12])(ctx,1,local+16,&ftab[12],fqv[29]); /*glenable*/
	local[16]= makeint((eusinteger_t)7425L);
	ctx->vsp=local+17;
	w=(*ftab[79])(ctx,1,local+16,&ftab[79],fqv[236]); /*glshademodel*/
	local[16]= w;
	goto irtglIF664;
irtglIF663:
	local[16]= NIL;
irtglIF664:
	w = local[16];
	goto irtglWHL594;
irtglWHX595:
	local[8]= NIL;
irtglBLK596:
	w = NIL;
	if (local[3]==NIL) goto irtglIF665;
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(*ftab[78])(ctx,1,local+6,&ftab[78],fqv[234]); /*gldepthmask*/
	local[6]= makeint((eusinteger_t)3042L);
	ctx->vsp=local+7;
	w=(*ftab[8])(ctx,1,local+6,&ftab[8],fqv[25]); /*gldisable*/
	local[6]= w;
	goto irtglIF666;
irtglIF665:
	local[6]= NIL;
irtglIF666:
	ctx->vsp=local+6;
	w=(*ftab[43])(ctx,0,local+6,&ftab[43],fqv[108]); /*glendlist*/
	local[6]= argv[0];
	local[7]= local[5];
	w = local[1];
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= argv[0];
	local[9]= fqv[82];
	ctx->vsp=local+10;
	w=(pointer)GETPROP(ctx,2,local+8); /*get*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[82];
	ctx->vsp=local+9;
	w=(pointer)PUTPROP(ctx,3,local+6); /*putprop*/
	local[1] = NIL;
	local[6]= local[1];
	goto irtglCON587;
irtglCON589:
	local[6]= NIL;
irtglCON587:
	local[6]= makeint((eusinteger_t)2898L);
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(*ftab[77])(ctx,2,local+6,&ftab[77],fqv[233]); /*gllightmodeli*/
	ctx->vsp=local+6;
	w=(*ftab[27])(ctx,0,local+6,&ftab[27],fqv[61]); /*glpopmatrix*/
	ctx->vsp=local+6;
	w=(*ftab[42])(ctx,0,local+6,&ftab[42],fqv[107]); /*glpopattrib*/
	if (local[1]!=NIL) goto irtglIF667;
	local[6]= argv[0];
	local[7]= fqv[75];
	local[8]= argv[2];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	goto irtglIF668;
irtglIF667:
	local[6]= NIL;
irtglIF668:
	w = local[6];
	local[0]= w;
irtglBLK585:
	ctx->vsp=local; return(local[0]);}

/*:collision-check-objects*/
static pointer irtglM669glvertices_collision_check_objects(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtglRST671:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	w = NIL;
	local[0]= w;
irtglBLK670:
	ctx->vsp=local; return(local[0]);}

/*:box*/
static pointer irtglM672glvertices_box(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[10]!=NIL) goto irtglIF674;
	local[0]= argv[0];
	local[1]= fqv[195];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto irtglIF675;
irtglIF674:
	local[0]= NIL;
irtglIF675:
	w = argv[0]->c.obj.iv[10];
	local[0]= w;
irtglBLK673:
	ctx->vsp=local; return(local[0]);}

/*:make-pqpmodel*/
static pointer irtglM676glvertices_make_pqpmodel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[255], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtglKEY678;
	local[0] = makeint((eusinteger_t)0L);
irtglKEY678:
	ctx->vsp=local+1;
	w=(*ftab[89])(ctx,0,local+1,&ftab[89],fqv[256]); /*geometry::pqpmakemodel*/
	local[1]= w;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= NIL;
	local[7]= argv[0]->c.obj.iv[8];
irtglWHL679:
	if (local[7]==NIL) goto irtglWHX680;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= fqv[205];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(*ftab[69])(ctx,2,local+8,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= local[8];
	if (fqv[206]==local[9]) goto irtglIF682;
	local[9]= fqv[257];
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(*ftab[31])(ctx,2,local+9,&ftab[31],fqv[81]); /*warn*/
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(*ftab[90])(ctx,1,local+9,&ftab[90],fqv[258]); /*geometry::pqpdeletemodel*/
	w = NIL;
	ctx->vsp=local+9;
	local[0]=w;
	goto irtglBLK677;
	goto irtglIF683;
irtglIF682:
	local[9]= NIL;
irtglIF683:
	w = local[9];
	goto irtglWHL679;
irtglWHX680:
	local[8]= NIL;
irtglBLK681:
	w = NIL;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,3,local+6); /*float-vector*/
	local[2] = w;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,3,local+6); /*float-vector*/
	local[3] = w;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,3,local+6); /*float-vector*/
	local[4] = w;
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(*ftab[91])(ctx,1,local+6,&ftab[91],fqv[259]); /*geometry::pqpbeginmodel*/
	local[6]= NIL;
	local[7]= argv[0]->c.obj.iv[8];
irtglWHL684:
	if (local[7]==NIL) goto irtglWHX685;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= fqv[96];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(*ftab[69])(ctx,2,local+8,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= fqv[201];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(*ftab[69])(ctx,2,local+9,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= local[9];
	ctx->vsp=local+11;
	w=(pointer)LENGTH(ctx,1,local+10); /*length*/
	local[10]= w;
	local[11]= makeint((eusinteger_t)3L);
	ctx->vsp=local+12;
	w=(pointer)QUOTIENT(ctx,2,local+10); /*/*/
	local[10]= w;
	local[11]= makeint((eusinteger_t)3L);
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	if (local[9]==NIL) goto irtglCON688;
	local[11]= makeint((eusinteger_t)0L);
irtglTAG690:
	local[12]= local[11];
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)GREQP(ctx,2,local+12); /*>=*/
	if (w==NIL) goto irtglIF691;
	w = NIL;
	ctx->vsp=local+12;
	local[11]=w;
	goto irtglBLK689;
	goto irtglIF692;
irtglIF691:
	local[12]= NIL;
irtglIF692:
	local[12]= local[8];
	local[13]= local[9];
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(*ftab[72])(ctx,3,local+12,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[12]= local[8];
	local[13]= local[9];
	local[14]= local[11];
	local[15]= makeint((eusinteger_t)1L);
	ctx->vsp=local+16;
	w=(pointer)PLUS(ctx,2,local+14); /*+*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(*ftab[72])(ctx,3,local+12,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[12]= local[8];
	local[13]= local[9];
	local[14]= local[11];
	local[15]= makeint((eusinteger_t)2L);
	ctx->vsp=local+16;
	w=(pointer)PLUS(ctx,2,local+14); /*+*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(*ftab[72])(ctx,3,local+12,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[12]= local[0];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)NUMEQUAL(ctx,2,local+12); /*=*/
	if (w!=NIL) goto irtglIF693;
	local[12]= local[2];
	local[13]= local[0];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)VNORMALIZE(ctx,1,local+14); /*normalize-vector*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SCALEVEC(ctx,2,local+13); /*scale*/
	local[13]= w;
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)VPLUS(ctx,3,local+12); /*v+*/
	local[12]= local[3];
	local[13]= local[0];
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)VNORMALIZE(ctx,1,local+14); /*normalize-vector*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SCALEVEC(ctx,2,local+13); /*scale*/
	local[13]= w;
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)VPLUS(ctx,3,local+12); /*v+*/
	local[12]= local[4];
	local[13]= local[0];
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(pointer)VNORMALIZE(ctx,1,local+14); /*normalize-vector*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SCALEVEC(ctx,2,local+13); /*scale*/
	local[13]= w;
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(pointer)VPLUS(ctx,3,local+12); /*v+*/
	local[12]= w;
	goto irtglIF694;
irtglIF693:
	local[12]= NIL;
irtglIF694:
	local[12]= local[1];
	local[13]= local[2];
	local[14]= local[3];
	local[15]= local[4];
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(*ftab[92])(ctx,5,local+12,&ftab[92],fqv[260]); /*geometry::pqpaddtri*/
	local[12]= local[5];
	ctx->vsp=local+13;
	w=(pointer)ADD1(ctx,1,local+12); /*1+*/
	local[5] = w;
	local[12]= local[11];
	local[13]= makeint((eusinteger_t)3L);
	ctx->vsp=local+14;
	w=(pointer)PLUS(ctx,2,local+12); /*+*/
	local[12]= w;
	local[11] = local[12];
	w = NIL;
	ctx->vsp=local+12;
	goto irtglTAG690;
	w = NIL;
	local[11]= w;
irtglBLK689:
	goto irtglCON687;
irtglCON688:
	local[11]= makeint((eusinteger_t)0L);
irtglTAG697:
	local[12]= local[11];
	local[13]= local[8];
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(*ftab[71])(ctx,2,local+13,&ftab[71],fqv[191]); /*array-dimension*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)GREQP(ctx,2,local+12); /*>=*/
	if (w==NIL) goto irtglIF698;
	w = NIL;
	ctx->vsp=local+12;
	local[11]=w;
	goto irtglBLK696;
	goto irtglIF699;
irtglIF698:
	local[12]= NIL;
irtglIF699:
	local[12]= local[8];
	local[13]= local[11];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(*ftab[72])(ctx,3,local+12,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[12]= local[8];
	local[13]= local[11];
	local[14]= makeint((eusinteger_t)1L);
	ctx->vsp=local+15;
	w=(pointer)PLUS(ctx,2,local+13); /*+*/
	local[13]= w;
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(*ftab[72])(ctx,3,local+12,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[12]= local[8];
	local[13]= local[11];
	local[14]= makeint((eusinteger_t)2L);
	ctx->vsp=local+15;
	w=(pointer)PLUS(ctx,2,local+13); /*+*/
	local[13]= w;
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(*ftab[72])(ctx,3,local+12,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[12]= local[0];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)NUMEQUAL(ctx,2,local+12); /*=*/
	if (w!=NIL) goto irtglIF700;
	local[12]= local[2];
	local[13]= local[0];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)VNORMALIZE(ctx,1,local+14); /*normalize-vector*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SCALEVEC(ctx,2,local+13); /*scale*/
	local[13]= w;
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)VPLUS(ctx,3,local+12); /*v+*/
	local[12]= local[3];
	local[13]= local[0];
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)VNORMALIZE(ctx,1,local+14); /*normalize-vector*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SCALEVEC(ctx,2,local+13); /*scale*/
	local[13]= w;
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)VPLUS(ctx,3,local+12); /*v+*/
	local[12]= local[4];
	local[13]= local[0];
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(pointer)VNORMALIZE(ctx,1,local+14); /*normalize-vector*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SCALEVEC(ctx,2,local+13); /*scale*/
	local[13]= w;
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(pointer)VPLUS(ctx,3,local+12); /*v+*/
	local[12]= w;
	goto irtglIF701;
irtglIF700:
	local[12]= NIL;
irtglIF701:
	local[12]= local[1];
	local[13]= local[2];
	local[14]= local[3];
	local[15]= local[4];
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(*ftab[92])(ctx,5,local+12,&ftab[92],fqv[260]); /*geometry::pqpaddtri*/
	local[12]= local[5];
	ctx->vsp=local+13;
	w=(pointer)ADD1(ctx,1,local+12); /*1+*/
	local[5] = w;
	local[12]= local[11];
	local[13]= makeint((eusinteger_t)3L);
	ctx->vsp=local+14;
	w=(pointer)PLUS(ctx,2,local+12); /*+*/
	local[12]= w;
	local[11] = local[12];
	w = NIL;
	ctx->vsp=local+12;
	goto irtglTAG697;
	w = NIL;
	local[11]= w;
irtglBLK696:
	goto irtglCON687;
irtglCON695:
	local[11]= NIL;
irtglCON687:
	w = local[11];
	goto irtglWHL684;
irtglWHX685:
	local[8]= NIL;
irtglBLK686:
	w = NIL;
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(*ftab[93])(ctx,1,local+6,&ftab[93],fqv[261]); /*geometry::pqpendmodel*/
	w = local[1];
	local[0]= w;
irtglBLK677:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtglCLO367(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[2];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[69])(ctx,2,local+0,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtglCLO516(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[180];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtglCLO535(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[180];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtglCLO567(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env2[1];
	local[1]= env->c.clo.env2[0];
	local[2]= fqv[122];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[69])(ctx,2,local+2,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)FUNCALL(ctx,3,local+0); /*funcall*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:glvertices*/
static pointer irtglM702glbody_glvertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtglRST704:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[16];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[94])(ctx,2,local+1,&ftab[94],fqv[262]); /*user::forward-message-to*/
	local[0]= w;
irtglBLK703:
	ctx->vsp=local; return(local[0]);}

/*:draw*/
static pointer irtglM705glbody_draw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	if (argv[0]->c.obj.iv[16]==NIL) goto irtglIF707;
	local[0]= argv[0]->c.obj.iv[16];
	local[1]= fqv[75];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto irtglIF708;
irtglIF707:
	local[0]= NIL;
irtglIF708:
	w = local[0];
	local[0]= w;
irtglBLK706:
	ctx->vsp=local; return(local[0]);}

/*:set-color*/
static pointer irtglM709glbody_set_color(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtglRST711:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[184]);
	local[2]= argv[0];
	local[3]= *(ovafptr(argv[1],fqv[36]));
	local[4]= fqv[263];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,5,local+1); /*apply*/
	if (argv[0]->c.obj.iv[16]==NIL) goto irtglIF712;
	local[1]= (pointer)get_sym_func(fqv[223]);
	local[2]= argv[0]->c.obj.iv[16];
	local[3]= fqv[263];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[1]= w;
	goto irtglIF713;
irtglIF712:
	local[1]= NIL;
irtglIF713:
	w = local[1];
	local[0]= w;
irtglBLK710:
	ctx->vsp=local; return(local[0]);}

/*make-glvertices-from-faceset*/
static pointer irtglF9make_glvertices_from_faceset(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[264], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto irtglKEY715;
	local[0] = NIL;
irtglKEY715:
	local[1]= NIL;
	if (local[0]==NIL) goto irtglCON717;
	local[1] = local[0];
	local[2]= local[1];
	goto irtglCON716;
irtglCON717:
	local[2]= argv[0];
	local[3]= fqv[84];
	ctx->vsp=local+4;
	w=(pointer)GETPROP(ctx,2,local+2); /*get*/
	if (w==NIL) goto irtglCON718;
	local[2]= argv[0];
	local[3]= fqv[84];
	ctx->vsp=local+4;
	w=(pointer)GETPROP(ctx,2,local+2); /*get*/
	local[2]= w;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)VECTORP(ctx,1,local+3); /*vectorp*/
	if (w!=NIL) goto irtglIF719;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)irtglF7find_color(ctx,1,local+3); /*find-color*/
	local[2] = w;
	local[3]= local[2];
	goto irtglIF720;
irtglIF719:
	local[3]= NIL;
irtglIF720:
	local[3]= fqv[237];
	local[4]= local[2];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= local[2];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= local[2];
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,3,local+4); /*float-vector*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,2,local+3); /*list*/
	local[3]= w;
	local[4]= fqv[144];
	local[5]= local[2];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= local[2];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= local[2];
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,2,local+4); /*list*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,2,local+3); /*list*/
	local[1] = w;
	w = local[1];
	local[2]= w;
	goto irtglCON716;
irtglCON718:
	local[2]= fqv[237];
	local[3]= makeflt(6.4999999999999991118216e-01);
	local[4]= makeflt(6.4999999999999991118216e-01);
	local[5]= makeflt(6.4999999999999991118216e-01);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,2,local+2); /*list*/
	local[2]= w;
	local[3]= fqv[144];
	local[4]= makeflt(6.4999999999999991118216e-01);
	local[5]= makeflt(6.4999999999999991118216e-01);
	local[6]= makeflt(6.4999999999999991118216e-01);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,3,local+4); /*float-vector*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,2,local+3); /*list*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,2,local+2); /*list*/
	local[1] = w;
	local[2]= local[1];
	goto irtglCON716;
irtglCON721:
	local[2]= NIL;
irtglCON716:
	local[2]= argv[0];
	local[3]= fqv[95];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= fqv[189];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)irtglF10make_glvertices_from_faces(ctx,3,local+2); /*make-glvertices-from-faces*/
	local[0]= w;
irtglBLK714:
	ctx->vsp=local; return(local[0]);}

/*make-glvertices-from-faces*/
static pointer irtglF10make_glvertices_from_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[265], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto irtglKEY723;
	local[0] = NIL;
irtglKEY723:
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtglCLO724,env,argv,local);
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[75])(ctx,1,local+1,&ftab[75],fqv[222]); /*flatten*/
	argv[0] = w;
	local[1]= makeint((eusinteger_t)3L);
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	{ eusinteger_t i,j;
		j=intval(w); i=intval(local[1]);
		local[1]=(makeint(i * j));}
	local[2]= makeint((eusinteger_t)3L);
	ctx->vsp=local+3;
	w=(*ftab[74])(ctx,2,local+1,&ftab[74],fqv[202]); /*make-matrix*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)3L);
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	{ eusinteger_t i,j;
		j=intval(w); i=intval(local[2]);
		local[2]=(makeint(i * j));}
	local[3]= makeint((eusinteger_t)3L);
	ctx->vsp=local+4;
	w=(*ftab[74])(ctx,2,local+2,&ftab[74],fqv[202]); /*make-matrix*/
	local[2]= w;
	local[3]= loadglobal(fqv[110]);
	local[4]= makeint((eusinteger_t)3L);
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	{ eusinteger_t i,j;
		j=intval(w); i=intval(local[4]);
		local[4]=(makeint(i * j));}
	ctx->vsp=local+5;
	w=(pointer)INSTANTIATE(ctx,2,local+3); /*instantiate*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= NIL;
	local[6]= argv[0];
irtglWHL725:
	if (local[6]==NIL) goto irtglWHX726;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= local[5];
	local[8]= fqv[103];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)VNORMALIZE(ctx,1,local+7); /*normalize-vector*/
	local[7]= w;
	local[8]= local[5];
	local[9]= fqv[96];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[1];
	local[10]= local[4];
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= T;
	ctx->vsp=local+13;
	w=(*ftab[72])(ctx,4,local+9,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[9]= local[2];
	local[10]= local[4];
	local[11]= local[7];
	local[12]= T;
	ctx->vsp=local+13;
	w=(*ftab[72])(ctx,4,local+9,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[4] = w;
	local[9]= local[1];
	local[10]= local[4];
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= T;
	ctx->vsp=local+13;
	w=(*ftab[72])(ctx,4,local+9,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[9]= local[2];
	local[10]= local[4];
	local[11]= local[7];
	local[12]= T;
	ctx->vsp=local+13;
	w=(*ftab[72])(ctx,4,local+9,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[4] = w;
	local[9]= local[1];
	local[10]= local[4];
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= T;
	ctx->vsp=local+13;
	w=(*ftab[72])(ctx,4,local+9,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[9]= local[2];
	local[10]= local[4];
	local[11]= local[7];
	local[12]= T;
	ctx->vsp=local+13;
	w=(*ftab[72])(ctx,4,local+9,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[4] = w;
	w = local[4];
	goto irtglWHL725;
irtglWHX726:
	local[7]= NIL;
irtglBLK727:
	w = NIL;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
irtglWHL728:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto irtglWHX729;
	local[7]= local[3];
	local[8]= local[5];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)SETELT(ctx,3,local+7); /*setelt*/
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto irtglWHL728;
irtglWHX729:
	local[7]= NIL;
irtglBLK730:
	w = NIL;
	local[5]= fqv[205];
	local[6]= fqv[206];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,2,local+5); /*list*/
	local[5]= w;
	local[6]= fqv[96];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,2,local+6); /*list*/
	local[6]= w;
	local[7]= fqv[203];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	local[8]= fqv[201];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,2,local+8); /*list*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,4,local+5); /*list*/
	local[5]= w;
	if (local[0]==NIL) goto irtglIF731;
	local[6]= fqv[189];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,2,local+6); /*list*/
	local[6]= w;
	w = local[5];
	ctx->vsp=local+7;
	local[5] = cons(ctx,local[6],w);
	local[6]= local[5];
	goto irtglIF732;
irtglIF731:
	local[6]= NIL;
irtglIF732:
	local[6]= loadglobal(fqv[214]);
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,1,local+6); /*instantiate*/
	local[6]= w;
	local[7]= local[6];
	local[8]= fqv[45];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	w = local[6];
	local[0]= w;
irtglBLK722:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtglCLO724(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[95])(ctx,1,local+0,&ftab[95],fqv[266]); /*geometry::face-to-triangle-aux*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*_dump-wrl-shape*/
static pointer irtglF11_dump_wrl_shape(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[267], &argv[2], n-2, local+0, 1);
	if (n & (1<<0)) goto irtglKEY734;
	local[0] = makeflt(1.0000000000000000000000e+00);
irtglKEY734:
	if (n & (1<<1)) goto irtglKEY735;
	local[1] = NIL;
irtglKEY735:
	if (n & (1<<2)) goto irtglKEY736;
	local[2] = NIL;
irtglKEY736:
	if (n & (1<<3)) goto irtglKEY737;
	local[3] = NIL;
irtglKEY737:
	local[4]= fqv[205];
	local[5]= argv[1];
	ctx->vsp=local+6;
	w=(*ftab[69])(ctx,2,local+4,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= fqv[201];
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(*ftab[69])(ctx,2,local+5,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= fqv[96];
	local[7]= argv[1];
	ctx->vsp=local+8;
	w=(*ftab[69])(ctx,2,local+6,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	local[7]= fqv[189];
	local[8]= argv[1];
	ctx->vsp=local+9;
	w=(*ftab[69])(ctx,2,local+7,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= fqv[235];
	local[9]= argv[1];
	ctx->vsp=local+10;
	w=(*ftab[69])(ctx,2,local+8,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= fqv[203];
	local[10]= argv[1];
	ctx->vsp=local+11;
	w=(*ftab[69])(ctx,2,local+9,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= local[6]->c.obj.iv[1];
	ctx->vsp=local+11;
	w=(pointer)LENGTH(ctx,1,local+10); /*length*/
	local[10]= w;
	local[11]= makeint((eusinteger_t)3L);
	ctx->vsp=local+12;
	w=(pointer)QUOTIENT(ctx,2,local+10); /*/*/
	local[10]= w;
	local[11]= argv[0];
	local[12]= fqv[268];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,2,local+11); /*format*/
	local[11]= fqv[67];
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(*ftab[69])(ctx,2,local+11,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= fqv[237];
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(*ftab[69])(ctx,2,local+12,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= fqv[144];
	local[14]= local[7];
	ctx->vsp=local+15;
	w=(*ftab[69])(ctx,2,local+13,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	local[14]= fqv[238];
	local[15]= local[7];
	ctx->vsp=local+16;
	w=(*ftab[69])(ctx,2,local+14,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	local[15]= fqv[239];
	local[16]= local[7];
	ctx->vsp=local+17;
	w=(*ftab[69])(ctx,2,local+15,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	local[16]= fqv[240];
	local[17]= local[7];
	ctx->vsp=local+18;
	w=(*ftab[69])(ctx,2,local+16,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	local[17]= fqv[241];
	local[18]= local[7];
	ctx->vsp=local+19;
	w=(*ftab[69])(ctx,2,local+17,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	local[18]= fqv[269];
	local[19]= local[7];
	ctx->vsp=local+20;
	w=(*ftab[69])(ctx,2,local+18,&ftab[69],fqv[186]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.car;
	local[19]= argv[0];
	local[20]= fqv[270];
	ctx->vsp=local+21;
	w=(pointer)XFORMAT(ctx,2,local+19); /*format*/
	if (local[13]==NIL) goto irtglIF738;
	local[19]= argv[0];
	local[20]= fqv[271];
	local[21]= local[13];
	local[22]= makeint((eusinteger_t)0L);
	ctx->vsp=local+23;
	w=(pointer)ELT(ctx,2,local+21); /*elt*/
	local[21]= w;
	local[22]= local[13];
	local[23]= makeint((eusinteger_t)1L);
	ctx->vsp=local+24;
	w=(pointer)ELT(ctx,2,local+22); /*elt*/
	local[22]= w;
	local[23]= local[13];
	local[24]= makeint((eusinteger_t)2L);
	ctx->vsp=local+25;
	w=(pointer)ELT(ctx,2,local+23); /*elt*/
	local[23]= w;
	ctx->vsp=local+24;
	w=(pointer)XFORMAT(ctx,5,local+19); /*format*/
	local[19]= w;
	goto irtglIF739;
irtglIF738:
	local[19]= NIL;
irtglIF739:
	if (local[1]==NIL) goto irtglIF740;
	if (local[12]==NIL) goto irtglIF740;
	local[19]= argv[0];
	local[20]= fqv[272];
	local[21]= local[12];
	local[22]= makeint((eusinteger_t)0L);
	ctx->vsp=local+23;
	w=(pointer)ELT(ctx,2,local+21); /*elt*/
	local[21]= w;
	local[22]= local[12];
	local[23]= makeint((eusinteger_t)1L);
	ctx->vsp=local+24;
	w=(pointer)ELT(ctx,2,local+22); /*elt*/
	local[22]= w;
	local[23]= local[12];
	local[24]= makeint((eusinteger_t)2L);
	ctx->vsp=local+25;
	w=(pointer)ELT(ctx,2,local+23); /*elt*/
	local[23]= w;
	ctx->vsp=local+24;
	w=(pointer)XFORMAT(ctx,5,local+19); /*format*/
	local[19]= w;
	goto irtglIF741;
irtglIF740:
	local[19]= NIL;
irtglIF741:
	if (local[14]==NIL) goto irtglIF742;
	local[19]= argv[0];
	local[20]= fqv[273];
	local[21]= local[14];
	local[22]= makeint((eusinteger_t)0L);
	ctx->vsp=local+23;
	w=(pointer)ELT(ctx,2,local+21); /*elt*/
	local[21]= w;
	local[22]= local[14];
	local[23]= makeint((eusinteger_t)1L);
	ctx->vsp=local+24;
	w=(pointer)ELT(ctx,2,local+22); /*elt*/
	local[22]= w;
	local[23]= local[14];
	local[24]= makeint((eusinteger_t)2L);
	ctx->vsp=local+25;
	w=(pointer)ELT(ctx,2,local+23); /*elt*/
	local[23]= w;
	ctx->vsp=local+24;
	w=(pointer)XFORMAT(ctx,5,local+19); /*format*/
	local[19]= w;
	goto irtglIF743;
irtglIF742:
	local[19]= NIL;
irtglIF743:
	if (local[15]==NIL) goto irtglIF744;
	local[19]= argv[0];
	local[20]= fqv[274];
	local[21]= local[15];
	local[22]= makeint((eusinteger_t)0L);
	ctx->vsp=local+23;
	w=(pointer)ELT(ctx,2,local+21); /*elt*/
	local[21]= w;
	local[22]= local[15];
	local[23]= makeint((eusinteger_t)1L);
	ctx->vsp=local+24;
	w=(pointer)ELT(ctx,2,local+22); /*elt*/
	local[22]= w;
	local[23]= local[15];
	local[24]= makeint((eusinteger_t)2L);
	ctx->vsp=local+25;
	w=(pointer)ELT(ctx,2,local+23); /*elt*/
	local[23]= w;
	ctx->vsp=local+24;
	w=(pointer)XFORMAT(ctx,5,local+19); /*format*/
	local[19]= w;
	goto irtglIF745;
irtglIF744:
	local[19]= NIL;
irtglIF745:
	if (local[16]==NIL) goto irtglIF746;
	local[19]= argv[0];
	local[20]= fqv[275];
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)XFORMAT(ctx,3,local+19); /*format*/
	local[19]= w;
	goto irtglIF747;
irtglIF746:
	local[19]= NIL;
irtglIF747:
	if (local[17]==NIL) goto irtglIF748;
	local[19]= argv[0];
	local[20]= fqv[276];
	local[21]= local[17];
	ctx->vsp=local+22;
	w=(pointer)XFORMAT(ctx,3,local+19); /*format*/
	local[19]= w;
	goto irtglIF749;
irtglIF748:
	local[19]= NIL;
irtglIF749:
	local[19]= argv[0];
	local[20]= fqv[277];
	ctx->vsp=local+21;
	w=(pointer)XFORMAT(ctx,2,local+19); /*format*/
	local[19]= argv[0];
	local[20]= fqv[278];
	ctx->vsp=local+21;
	w=(pointer)XFORMAT(ctx,2,local+19); /*format*/
	local[19]= argv[0];
	local[20]= fqv[279];
	ctx->vsp=local+21;
	w=(pointer)XFORMAT(ctx,2,local+19); /*format*/
	local[11]= argv[0];
	local[12]= fqv[280];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,2,local+11); /*format*/
	local[11]= makeint((eusinteger_t)0L);
	local[12]= makeint((eusinteger_t)0L);
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)MKFLTVEC(ctx,3,local+11); /*float-vector*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)0L);
	local[13]= local[10];
irtglWHL750:
	local[14]= local[12];
	w = local[13];
	if ((eusinteger_t)local[14] >= (eusinteger_t)w) goto irtglWHX751;
	local[14]= local[6];
	local[15]= local[12];
	local[16]= local[11];
	ctx->vsp=local+17;
	w=(*ftab[72])(ctx,3,local+14,&ftab[72],fqv[192]); /*user::c-matrix-row*/
	local[14]= argv[0];
	local[15]= fqv[281];
	local[16]= local[0];
	local[17]= local[11];
	local[18]= makeint((eusinteger_t)0L);
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)TIMES(ctx,2,local+16); /***/
	local[16]= w;
	local[17]= local[0];
	local[18]= local[11];
	local[19]= makeint((eusinteger_t)1L);
	ctx->vsp=local+20;
	w=(pointer)ELT(ctx,2,local+18); /*elt*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)TIMES(ctx,2,local+17); /***/
	local[17]= w;
	local[18]= local[0];
	local[19]= local[11];
	local[20]= makeint((eusinteger_t)2L);
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)TIMES(ctx,2,local+18); /***/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)XFORMAT(ctx,5,local+14); /*format*/
	local[14]= local[12];
	ctx->vsp=local+15;
	w=(pointer)ADD1(ctx,1,local+14); /*1+*/
	local[12] = w;
	goto irtglWHL750;
irtglWHX751:
	local[14]= NIL;
irtglBLK752:
	w = NIL;
	local[11]= argv[0];
	local[12]= fqv[282];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,2,local+11); /*format*/
	if (local[2]==NIL) goto irtglIF753;
	if (local[9]==NIL) goto irtglIF753;
	local[11]= NIL;
	goto irtglIF754;
irtglIF753:
	local[11]= NIL;
irtglIF754:
	if (local[3]==NIL) goto irtglIF755;
	if (local[8]==NIL) goto irtglIF755;
	local[11]= NIL;
	goto irtglIF756;
irtglIF755:
	local[11]= NIL;
irtglIF756:
	local[11]= argv[0];
	local[12]= fqv[283];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,2,local+11); /*format*/
	local[11]= makeint((eusinteger_t)0L);
	local[12]= local[5];
	ctx->vsp=local+13;
	w=(pointer)LENGTH(ctx,1,local+12); /*length*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)3L);
	ctx->vsp=local+14;
	w=(pointer)QUOTIENT(ctx,2,local+12); /*/*/
	local[12]= w;
irtglWHL757:
	local[13]= local[11];
	w = local[12];
	if ((eusinteger_t)local[13] >= (eusinteger_t)w) goto irtglWHX758;
	local[13]= argv[0];
	local[14]= fqv[284];
	local[15]= local[5];
	local[16]= local[11];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)3L)); i=intval(local[16]);
		local[16]=(makeint(i * j));}
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	local[16]= local[5];
	local[17]= local[11];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)3L)); i=intval(local[17]);
		local[17]=(makeint(i * j));}
	w = makeint((eusinteger_t)1L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[17]= (pointer)((eusinteger_t)local[17] + (eusinteger_t)w);
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	local[17]= local[5];
	local[18]= local[11];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)3L)); i=intval(local[18]);
		local[18]=(makeint(i * j));}
	w = makeint((eusinteger_t)2L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[18]= (pointer)((eusinteger_t)local[18] + (eusinteger_t)w);
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)XFORMAT(ctx,5,local+13); /*format*/
	local[13]= local[11];
	ctx->vsp=local+14;
	w=(pointer)ADD1(ctx,1,local+13); /*1+*/
	local[11] = w;
	goto irtglWHL757;
irtglWHX758:
	local[13]= NIL;
irtglBLK759:
	w = NIL;
	local[11]= argv[0];
	local[12]= fqv[285];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,2,local+11); /*format*/
	local[0]= w;
irtglBLK733:
	ctx->vsp=local; return(local[0]);}

/*write-wrl-from-glvertices*/
static pointer irtglF12write_wrl_from_glvertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtglRST761:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= *(ovafptr(argv[1],fqv[226]));
	local[2]= argv[0];
	local[3]= fqv[286];
	local[4]= fqv[287];
	ctx->vsp=local+5;
	w=(*ftab[96])(ctx,3,local+2,&ftab[96],fqv[288]); /*open*/
	local[2]= w;
	ctx->vsp=local+3;
	w = makeclosure(codevec,quotevec,irtglUWP762,env,argv,local);
	local[3]=(pointer)(ctx->protfp); local[4]=w;
	ctx->protfp=(struct protectframe *)(local+3);
	local[5]= local[2];
	local[6]= fqv[289];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,2,local+5); /*format*/
	local[5]= local[2];
	local[6]= fqv[290];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,2,local+5); /*format*/
	local[5]= NIL;
	local[6]= local[1];
irtglWHL763:
	if (local[6]==NIL) goto irtglWHX764;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= (pointer)get_sym_func(fqv[291]);
	local[8]= local[2];
	local[9]= local[5];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)APPLY(ctx,4,local+7); /*apply*/
	goto irtglWHL763;
irtglWHX764:
	local[7]= NIL;
irtglBLK765:
	w = NIL;
	local[5]= local[2];
	local[6]= fqv[292];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,2,local+5); /*format*/
	local[5]= local[2];
	local[6]= fqv[293];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,2,local+5); /*format*/
	ctx->vsp=local+5;
	irtglUWP762(ctx,0,local+5,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[0]= w;
irtglBLK760:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtglUWP762(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[2];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___irtgl(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[294];
	ctx->vsp=local+1;
	w=(*ftab[97])(ctx,1,local+0,&ftab[97],fqv[295]); /*require*/
	local[0]= fqv[296];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtglIF766;
	local[0]= fqv[297];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[298],w);
	goto irtglIF767;
irtglIF766:
	local[0]= fqv[299];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtglIF767:
	local[0]= NIL;
	ctx->vsp=local+1;
	w=(*ftab[98])(ctx,0,local+1,&ftab[98],fqv[300]); /*system::sysmod*/
	local[0] = w;
	local[1]= fqv[99];
	local[2]= fqv[301];
	local[3]= fqv[209];
	local[4]= fqv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[99])(ctx,4,local+2,&ftab[99],fqv[302]); /*make-foreign-code*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETFUNC(ctx,2,local+1); /*lisp::setfunc*/
	local[1]= fqv[303];
	local[2]= fqv[304];
	local[3]= makeint((eusinteger_t)10752L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= fqv[305];
	local[2]= fqv[304];
	local[3]= makeint((eusinteger_t)10753L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= fqv[306];
	local[2]= fqv[304];
	local[3]= makeint((eusinteger_t)10754L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= fqv[307];
	local[2]= fqv[304];
	local[3]= makeint((eusinteger_t)32823L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= fqv[308];
	local[2]= fqv[304];
	local[3]= makeint((eusinteger_t)32824L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= fqv[309];
	local[2]= fqv[304];
	local[3]= makeint((eusinteger_t)32823L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= fqv[310];
	local[2]= fqv[304];
	local[3]= makeint((eusinteger_t)32824L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= fqv[311];
	local[2]= fqv[304];
	local[3]= makeint((eusinteger_t)32825L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= fqv[245];
	local[2]= fqv[312];
	local[3]= fqv[209];
	local[4]= fqv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[99])(ctx,4,local+2,&ftab[99],fqv[302]); /*make-foreign-code*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETFUNC(ctx,2,local+1); /*lisp::setfunc*/
	local[1]= fqv[254];
	local[2]= fqv[313];
	local[3]= fqv[209];
	local[4]= fqv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[99])(ctx,4,local+2,&ftab[99],fqv[302]); /*make-foreign-code*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETFUNC(ctx,2,local+1); /*lisp::setfunc*/
	local[1]= fqv[246];
	local[2]= fqv[314];
	local[3]= fqv[209];
	local[4]= fqv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[99])(ctx,4,local+2,&ftab[99],fqv[302]); /*make-foreign-code*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETFUNC(ctx,2,local+1); /*lisp::setfunc*/
	local[1]= fqv[315];
	local[2]= fqv[316];
	local[3]= fqv[209];
	local[4]= fqv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[99])(ctx,4,local+2,&ftab[99],fqv[302]); /*make-foreign-code*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETFUNC(ctx,2,local+1); /*lisp::setfunc*/
	local[1]= fqv[247];
	local[2]= fqv[317];
	local[3]= fqv[209];
	local[4]= fqv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[99])(ctx,4,local+2,&ftab[99],fqv[302]); /*make-foreign-code*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETFUNC(ctx,2,local+1); /*lisp::setfunc*/
	local[1]= fqv[248];
	local[2]= fqv[318];
	local[3]= fqv[209];
	local[4]= fqv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[99])(ctx,4,local+2,&ftab[99],fqv[302]); /*make-foreign-code*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETFUNC(ctx,2,local+1); /*lisp::setfunc*/
	local[1]= fqv[252];
	local[2]= fqv[319];
	local[3]= fqv[209];
	local[4]= fqv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[99])(ctx,4,local+2,&ftab[99],fqv[302]); /*make-foreign-code*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETFUNC(ctx,2,local+1); /*lisp::setfunc*/
	local[1]= fqv[320];
	local[2]= fqv[321];
	local[3]= fqv[209];
	local[4]= fqv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[99])(ctx,4,local+2,&ftab[99],fqv[302]); /*make-foreign-code*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETFUNC(ctx,2,local+1); /*lisp::setfunc*/
	local[1]= fqv[253];
	local[2]= fqv[322];
	local[3]= fqv[209];
	local[4]= fqv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[99])(ctx,4,local+2,&ftab[99],fqv[302]); /*make-foreign-code*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETFUNC(ctx,2,local+1); /*lisp::setfunc*/
	local[1]= fqv[323];
	local[2]= fqv[304];
	local[3]= makeint((eusinteger_t)32884L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= fqv[324];
	local[2]= fqv[304];
	local[3]= makeint((eusinteger_t)32885L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= fqv[325];
	local[2]= fqv[304];
	local[3]= makeint((eusinteger_t)32888L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= fqv[326];
	local[2]= fqv[304];
	local[3]= makeint((eusinteger_t)32889L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= fqv[327];
	local[2]= fqv[304];
	local[3]= makeint((eusinteger_t)32886L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= fqv[328];
	local[2]= fqv[304];
	local[3]= makeint((eusinteger_t)32887L);
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[329],module,irtglF1set_stereo_gl_attribute,fqv[330]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[331],module,irtglF2reset_gl_attribute,fqv[332]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[333],module,irtglF3delete_displaylist_id,fqv[334]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[335],module,irtglF4transpose_image_rows,fqv[336]);
	local[0]= fqv[20];
	local[1]= loadglobal(fqv[337]);
	local[2]= fqv[338];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[69])(ctx,2,local+0,&ftab[69],fqv[186]); /*assoc*/
	if (w!=NIL) goto irtglIF768;
	local[0]= fqv[67];
	local[1]= loadglobal(fqv[337]);
	local[2]= fqv[338];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[69])(ctx,2,local+0,&ftab[69],fqv[186]); /*assoc*/
	local[0]= w;
	local[1]= fqv[20];
	ctx->vsp=local+2;
	w=(pointer)RPLACA(ctx,2,local+0); /*rplaca*/
	local[0]= w;
	goto irtglIF769;
irtglIF768:
	local[0]= NIL;
irtglIF769:
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM37glviewsurface_color,fqv[67],fqv[337],fqv[339]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM43glviewsurface_line_width,fqv[154],fqv[337],fqv[340]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM49glviewsurface_point_size,fqv[341],fqv[337],fqv[342]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM55glviewsurface_3d_point,fqv[343],fqv[337],fqv[344]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM67glviewsurface_3d_line,fqv[158],fqv[337],fqv[345]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM79glviewsurface_3d_lines,fqv[155],fqv[337],fqv[346]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM94glviewsurface_makecurrent,fqv[9],fqv[337],fqv[347]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM96glviewsurface_redraw,fqv[348],fqv[337],fqv[349]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM99glviewsurface_flush,fqv[34],fqv[337],fqv[350]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM101glviewsurface_write_to_image_file,fqv[351],fqv[337],fqv[352]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM107glviewsurface_getglimage,fqv[38],fqv[337],fqv[353]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM117glviewsurface_string,fqv[354],fqv[337],fqv[355]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[356],module,irtglF5draw_globjects,fqv[357]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[358],module,irtglF6draw_glbody,fqv[359]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[360],module,irtglF7find_color,fqv[361]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[362],module,irtglF8transparent,fqv[363]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM249polygon_draw_on,fqv[78],fqv[364],fqv[365]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM259line_draw_on,fqv[78],fqv[366],fqv[367]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM269faceset_set_color,fqv[263],fqv[77],fqv[368]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM276faceset_draw_on,fqv[78],fqv[77],fqv[369]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM289faceset_paste_texture_to_face,fqv[370],fqv[77],fqv[371]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM307coordinates_vertices,fqv[96],fqv[372],fqv[373]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM309coordinates_draw_on,fqv[78],fqv[372],fqv[374]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM329float_vector_vertices,fqv[96],fqv[149],fqv[375]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM331float_vector_draw_on,fqv[78],fqv[149],fqv[376]);
	local[0]= fqv[214];
	local[1]= fqv[377];
	local[2]= fqv[214];
	local[3]= fqv[378];
	local[4]= loadglobal(fqv[379]);
	local[5]= fqv[380];
	local[6]= fqv[381];
	local[7]= fqv[382];
	local[8]= NIL;
	local[9]= fqv[1];
	local[10]= NIL;
	local[11]= fqv[178];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[383];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[100])(ctx,13,local+2,&ftab[100],fqv[384]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM345glvertices_init,fqv[45],fqv[214],fqv[385]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM349glvertices_filename,fqv[269],fqv[214],fqv[386]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM355glvertices_set_color,fqv[263],fqv[214],fqv[387]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM361glvertices_get_meshinfo,fqv[188],fqv[214],fqv[388]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM368glvertices_set_meshinfo,fqv[190],fqv[214],fqv[389]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM377glvertices_get_material,fqv[390],fqv[214],fqv[391]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM381glvertices_set_material,fqv[392],fqv[214],fqv[393]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM385glvertices_actual_vertices,fqv[193],fqv[214],fqv[394]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM395glvertices_calc_bounding_box,fqv[195],fqv[214],fqv[395]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM397glvertices_vertices,fqv[96],fqv[214],fqv[396]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM401glvertices_reset_offset_from_parent,fqv[397],fqv[214],fqv[398]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM403glvertices_expand_vertices,fqv[399],fqv[214],fqv[400]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM408glvertices_expand_vertices_info,fqv[200],fqv[214],fqv[401]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM415glvertices_use_flat_shader,fqv[402],fqv[214],fqv[403]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM420glvertices_use_smooth_shader,fqv[404],fqv[214],fqv[405]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM427glvertices_calc_normals,fqv[406],fqv[214],fqv[407]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM464glvertices_mirror_axis,fqv[408],fqv[214],fqv[409]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM490glvertices_convert_to_faces,fqv[220],fqv[214],fqv[410]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM542glvertices_faces,fqv[95],fqv[214],fqv[411]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM544glvertices_convert_to_faceset,fqv[412],fqv[214],fqv[413]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM547glvertices_set_offset,fqv[198],fqv[214],fqv[414]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM557glvertices_convert_to_world,fqv[415],fqv[214],fqv[416]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM560glvertices_glvertices,fqv[417],fqv[214],fqv[418]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM574glvertices_append_glvertices,fqv[419],fqv[214],fqv[420]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM581glvertices_draw_on,fqv[78],fqv[214],fqv[421]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM584glvertices_draw,fqv[75],fqv[214],fqv[422]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM669glvertices_collision_check_objects,fqv[423],fqv[214],fqv[424]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM672glvertices_box,fqv[425],fqv[214],fqv[426]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM676glvertices_make_pqpmodel,fqv[427],fqv[214],fqv[428]);
	local[0]= fqv[429];
	local[1]= fqv[377];
	local[2]= fqv[429];
	local[3]= fqv[378];
	local[4]= loadglobal(fqv[430]);
	local[5]= fqv[380];
	local[6]= fqv[431];
	local[7]= fqv[382];
	local[8]= NIL;
	local[9]= fqv[1];
	local[10]= NIL;
	local[11]= fqv[178];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[383];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[100])(ctx,13,local+2,&ftab[100],fqv[384]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM702glbody_glvertices,fqv[417],fqv[429],fqv[432]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM705glbody_draw,fqv[75],fqv[429],fqv[433]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtglM709glbody_set_color,fqv[263],fqv[429],fqv[434]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[435],module,irtglF9make_glvertices_from_faceset,fqv[436]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[437],module,irtglF10make_glvertices_from_faces,fqv[438]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[291],module,irtglF11_dump_wrl_shape,fqv[439]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[440],module,irtglF12write_wrl_from_glvertices,fqv[441]);
	local[0]= fqv[442];
	local[1]= fqv[443];
	ctx->vsp=local+2;
	w=(*ftab[101])(ctx,2,local+0,&ftab[101],fqv[444]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<102; i++) ftab[i]=fcallx;
}
