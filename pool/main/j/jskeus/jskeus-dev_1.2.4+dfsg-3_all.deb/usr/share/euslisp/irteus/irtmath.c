/* ./irtmath.c :  entry=irtmath */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "irtmath.h"
#pragma init (register_irtmath)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___irtmath();
extern pointer build_quote_vector();
static int register_irtmath()
  { add_module_initializer("___irtmath", ___irtmath);}

static pointer irtmathF1inverse_matrix();
static pointer irtmathF2inverse_matrix_complex();
static pointer irtmathF3m__complex();
static pointer irtmathF4diagonal();
static pointer irtmathF5minor_matrix();
static pointer irtmathF6atan2();
static pointer irtmathF7outer_product_matrix();
static pointer irtmathF8matrix2quaternion();
static pointer irtmathF9quaternion2matrix();
static pointer irtmathF10matrix_log();
static pointer irtmathF11matrix_exponent();
static pointer irtmathF12midrot();
static pointer irtmathF13pseudo_inverse();
static pointer irtmathF14pseudo_inverse_org();
static pointer irtmathF15sr_inverse();
static pointer irtmathF16sr_inverse_org();
static pointer irtmathF17manipulability();
static pointer irtmathF18random_gauss();
static pointer irtmathF19gaussian_random();
static pointer irtmathF20eigen_decompose();
static pointer irtmathF21eigen_decompose_complex();
static pointer irtmathF22solve_non_zero_vector_from_det0_matrix();
static pointer irtmathF23lms();
static pointer irtmathF24lms_estimate();
static pointer irtmathF25lms_error();
static pointer irtmathF26lmeds();
static pointer irtmathF27lmeds_error();
static pointer irtmathF28lmeds_error_mat();
static pointer irtmathF29concatenate_matrix_column();
static pointer irtmathF30concatenate_matrix_row();
static pointer irtmathF31concatenate_matrix_diagonal();
static pointer irtmathF32vector_variance();
static pointer irtmathF33covariance_matrix();
static pointer irtmathF34normalize_vector();

/*inverse-matrix*/
static pointer irtmathF1inverse_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(*ftab[0])(ctx,2,local+0,&ftab[0],fqv[0]); /*array-dimension*/
	local[0]= w;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,1,local+1,&ftab[1],fqv[1]); /*unit-matrix*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(*ftab[2])(ctx,2,local+2,&ftab[2],fqv[2]); /*lu-decompose2*/
	local[2]= w;
	local[3]= NIL;
	local[4]= local[0];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[3])(ctx,2,local+4,&ftab[3],fqv[3]); /*make-matrix*/
	local[4]= w;
	local[5]= loadglobal(fqv[4]);
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,2,local+5); /*instantiate*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)0L);
	if (local[2]!=NIL) goto irtmathIF36;
	local[7]= fqv[5];
	ctx->vsp=local+8;
	w=(*ftab[4])(ctx,1,local+7,&ftab[4],fqv[6]); /*warn*/
	w = local[1];
	ctx->vsp=local+7;
	local[0]=w;
	goto irtmathBLK35;
	goto irtmathIF37;
irtmathIF36:
	local[7]= NIL;
irtmathIF37:
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[0];
irtmathWHL38:
	local[9]= local[7];
	w = local[8];
	if ((eusinteger_t)local[9] >= (eusinteger_t)w) goto irtmathWHX39;
	local[9]= argv[0];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(*ftab[2])(ctx,2,local+9,&ftab[2],fqv[2]); /*lu-decompose2*/
	local[2] = w;
	local[9]= local[5];
	local[10]= local[7];
	local[11]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+12;
	w=(pointer)ASET(ctx,3,local+9); /*aset*/
	local[9]= local[1];
	local[10]= local[2];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(*ftab[5])(ctx,3,local+9,&ftab[5],fqv[7]); /*lu-solve2*/
	local[3] = w;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= local[0];
irtmathWHL41:
	local[11]= local[9];
	w = local[10];
	if ((eusinteger_t)local[11] >= (eusinteger_t)w) goto irtmathWHX42;
	local[11]= local[4];
	local[12]= local[9];
	local[13]= local[7];
	local[14]= local[3];
	local[15]= local[9];
	ctx->vsp=local+16;
	w=(pointer)AREF(ctx,2,local+14); /*aref*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)ASET(ctx,4,local+11); /*aset*/
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[9] = w;
	goto irtmathWHL41;
irtmathWHX42:
	local[11]= NIL;
irtmathBLK43:
	w = NIL;
	local[9]= local[5];
	local[10]= local[7];
	local[11]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+12;
	w=(pointer)ASET(ctx,3,local+9); /*aset*/
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[7] = w;
	goto irtmathWHL38;
irtmathWHX39:
	local[9]= NIL;
irtmathBLK40:
	w = NIL;
	w = local[4];
	local[0]= w;
irtmathBLK35:
	ctx->vsp=local; return(local[0]);}

/*inverse-matrix-complex*/
static pointer irtmathF2inverse_matrix_complex(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(*ftab[6])(ctx,1,local+6,&ftab[6],fqv[8]); /*array-dimensions*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	local[7]= local[0];
	local[8]= makeflt(-1.0000000000000000000000e+00);
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(*ftab[7])(ctx,2,local+8,&ftab[7],fqv[9]); /*scale-matrix*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)irtmathF30concatenate_matrix_row(ctx,2,local+7); /*concatenate-matrix-row*/
	local[7]= w;
	local[8]= local[1];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)irtmathF30concatenate_matrix_row(ctx,2,local+8); /*concatenate-matrix-row*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)irtmathF29concatenate_matrix_column(ctx,2,local+7); /*concatenate-matrix-column*/
	local[4] = w;
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(*ftab[8])(ctx,1,local+7,&ftab[8],fqv[10]); /*matrix-determinant*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)NUMEQUAL(ctx,2,local+7); /*=*/
	if (w==NIL) goto irtmathIF45;
	local[7]= fqv[11];
	ctx->vsp=local+8;
	w=(*ftab[4])(ctx,1,local+7,&ftab[4],fqv[6]); /*warn*/
	w = NIL;
	ctx->vsp=local+7;
	local[0]=w;
	goto irtmathBLK44;
	goto irtmathIF46;
irtmathIF45:
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)irtmathF1inverse_matrix(ctx,1,local+7); /*inverse-matrix*/
	local[7]= w;
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(*ftab[1])(ctx,1,local+8,&ftab[1],fqv[1]); /*unit-matrix*/
	local[8]= w;
	local[9]= local[6];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(*ftab[3])(ctx,2,local+9,&ftab[3],fqv[3]); /*make-matrix*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)irtmathF29concatenate_matrix_column(ctx,2,local+8); /*concatenate-matrix-column*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MATTIMES(ctx,2,local+7); /*m**/
	local[5] = w;
	local[7]= local[6];
	ctx->vsp=local+8;
	w=(*ftab[1])(ctx,1,local+7,&ftab[1],fqv[1]); /*unit-matrix*/
	local[7]= w;
	local[8]= local[6];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(*ftab[3])(ctx,2,local+8,&ftab[3],fqv[3]); /*make-matrix*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)irtmathF30concatenate_matrix_row(ctx,2,local+7); /*concatenate-matrix-row*/
	local[7]= w;
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)MATTIMES(ctx,2,local+7); /*m**/
	local[2] = w;
	local[7]= local[6];
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(*ftab[3])(ctx,2,local+7,&ftab[3],fqv[3]); /*make-matrix*/
	local[7]= w;
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(*ftab[1])(ctx,1,local+8,&ftab[1],fqv[1]); /*unit-matrix*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)irtmathF30concatenate_matrix_row(ctx,2,local+7); /*concatenate-matrix-row*/
	local[7]= w;
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)MATTIMES(ctx,2,local+7); /*m**/
	local[3] = w;
	local[7]= local[2];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
irtmathIF46:
	w = local[7];
	local[0]= w;
irtmathBLK44:
	ctx->vsp=local; return(local[0]);}

/*m*-complex*/
static pointer irtmathF3m__complex(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= local[0];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)MATTIMES(ctx,2,local+4); /*m**/
	local[4]= w;
	local[5]= local[1];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)MATTIMES(ctx,2,local+5); /*m**/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[9])(ctx,2,local+4,&ftab[9],fqv[12]); /*m-*/
	local[4]= w;
	local[5]= local[0];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)MATTIMES(ctx,2,local+5); /*m**/
	local[5]= w;
	local[6]= local[1];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)MATTIMES(ctx,2,local+6); /*m**/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[10])(ctx,2,local+5,&ftab[10],fqv[13]); /*m+*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,2,local+4); /*list*/
	local[0]= w;
irtmathBLK47:
	ctx->vsp=local; return(local[0]);}

/*diagonal*/
static pointer irtmathF4diagonal(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	local[1]= local[0];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[3])(ctx,2,local+1,&ftab[3],fqv[3]); /*make-matrix*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= local[0];
irtmathWHL49:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto irtmathWHX50;
	local[4]= local[1];
	local[5]= local[2];
	local[6]= local[2];
	local[7]= argv[0];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)ASET(ctx,4,local+4); /*aset*/
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto irtmathWHL49;
irtmathWHX50:
	local[4]= NIL;
irtmathBLK51:
	w = NIL;
	w = local[1];
	local[0]= w;
irtmathBLK48:
	ctx->vsp=local; return(local[0]);}

/*minor-matrix*/
static pointer irtmathF5minor_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(*ftab[0])(ctx,2,local+0,&ftab[0],fqv[0]); /*array-dimension*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)SUB1(ctx,1,local+0); /*1-*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,2,local+1,&ftab[0],fqv[0]); /*array-dimension*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)SUB1(ctx,1,local+1); /*1-*/
	local[1]= w;
	local[2]= local[0];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(*ftab[3])(ctx,2,local+2,&ftab[3],fqv[3]); /*make-matrix*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
irtmathTAG54:
	local[5]= local[3];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)NUMEQUAL(ctx,2,local+5); /*=*/
	if (w==NIL) goto irtmathIF55;
	w = NIL;
	ctx->vsp=local+5;
	local[3]=w;
	goto irtmathBLK53;
	goto irtmathIF56;
irtmathIF55:
	local[5]= NIL;
irtmathIF56:
	local[5]= local[4];
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(pointer)NUMEQUAL(ctx,2,local+5); /*=*/
	if (w==NIL) goto irtmathIF57;
	local[5]= local[4];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[4] = w;
	local[5]= local[4];
	goto irtmathIF58;
irtmathIF57:
	local[5]= NIL;
irtmathIF58:
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
irtmathTAG60:
	local[7]= local[5];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)NUMEQUAL(ctx,2,local+7); /*=*/
	if (w==NIL) goto irtmathIF61;
	w = NIL;
	ctx->vsp=local+7;
	local[5]=w;
	goto irtmathBLK59;
	goto irtmathIF62;
irtmathIF61:
	local[7]= NIL;
irtmathIF62:
	local[7]= local[6];
	local[8]= argv[2];
	ctx->vsp=local+9;
	w=(pointer)NUMEQUAL(ctx,2,local+7); /*=*/
	if (w==NIL) goto irtmathIF63;
	local[7]= local[6];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[6] = w;
	local[7]= local[6];
	goto irtmathIF64;
irtmathIF63:
	local[7]= NIL;
irtmathIF64:
	local[7]= local[2];
	local[8]= local[3];
	local[9]= local[5];
	local[10]= argv[0];
	local[11]= local[4];
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(pointer)AREF(ctx,3,local+10); /*aref*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)ASET(ctx,4,local+7); /*aset*/
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[7]= w;
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[8]= w;
	local[5] = local[7];
	local[6] = local[8];
	w = NIL;
	ctx->vsp=local+7;
	goto irtmathTAG60;
	w = NIL;
	local[5]= w;
irtmathBLK59:
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[5]= w;
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[6]= w;
	local[3] = local[5];
	local[4] = local[6];
	w = NIL;
	ctx->vsp=local+5;
	goto irtmathTAG54;
	w = NIL;
	local[3]= w;
irtmathBLK53:
	w = local[2];
	local[0]= w;
irtmathBLK52:
	ctx->vsp=local; return(local[0]);}

/*atan2*/
static pointer irtmathF6atan2(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeflt(9.9999999999999964869129e-11);
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,1,local+1); /*-*/
	local[1]= w;
	local[2]= argv[1];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)GREATERP(ctx,2,local+2); /*>*/
	if (w==NIL) goto irtmathIF66;
	local[2]= argv[0];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)ATAN(ctx,1,local+2); /*atan*/
	ctx->vsp=local+2;
	local[0]=w;
	goto irtmathBLK65;
	goto irtmathIF67;
irtmathIF66:
	local[2]= NIL;
irtmathIF67:
	local[2]= argv[1];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,2,local+2); /*<*/
	if (w==NIL) goto irtmathIF68;
	local[2]= argv[0];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)GREATERP(ctx,2,local+2); /*>*/
	if (w==NIL) goto irtmathIF70;
	local[2]= makeflt(3.1415926535897931159980e+00);
	local[3]= argv[0];
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)ATAN(ctx,1,local+3); /*atan*/
	{ double x,y;
		y=fltval(w); x=fltval(local[2]);
		local[2]=(makeflt(x + y));}
	w = local[2];
	ctx->vsp=local+2;
	local[0]=w;
	goto irtmathBLK65;
	goto irtmathIF71;
irtmathIF70:
	local[2]= argv[0];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)ATAN(ctx,1,local+2); /*atan*/
	local[2]= w;
	{ double x,y;
		y=fltval(makeflt(3.1415926535897931159980e+00)); x=fltval(local[2]);
		local[2]=(makeflt(x - y));}
	w = local[2];
	ctx->vsp=local+2;
	local[0]=w;
	goto irtmathBLK65;
irtmathIF71:
	goto irtmathIF69;
irtmathIF68:
	local[2]= NIL;
irtmathIF69:
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)ABS(ctx,1,local+2); /*abs*/
	local[2]= w;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,2,local+2); /*<*/
	if (w==NIL) goto irtmathIF72;
	w = makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+2;
	local[0]=w;
	goto irtmathBLK65;
	goto irtmathIF73;
irtmathIF72:
	local[2]= NIL;
irtmathIF73:
	local[2]= argv[0];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)GREATERP(ctx,2,local+2); /*>*/
	if (w==NIL) goto irtmathIF74;
	local[2]= makeflt(1.5707963267948965579990e+00);
	goto irtmathIF75;
irtmathIF74:
	local[2]= makeflt(-1.5707963267948965579990e+00);
irtmathIF75:
	w = local[2];
	local[0]= w;
irtmathBLK65:
	ctx->vsp=local; return(local[0]);}

/*outer-product-matrix*/
static pointer irtmathF7outer_product_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto irtmathENT78;}
	local[0]= makeint((eusinteger_t)3L);
	ctx->vsp=local+1;
	w=(*ftab[1])(ctx,1,local+0,&ftab[1],fqv[1]); /*unit-matrix*/
	local[0]= w;
irtmathENT78:
irtmathENT77:
	if (n>2) maerror();
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,4,local+1); /*aset*/
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)1L);
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,1,local+4); /*-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,4,local+1); /*aset*/
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)2L);
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,4,local+1); /*aset*/
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)1L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,4,local+1); /*aset*/
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)1L);
	local[3]= makeint((eusinteger_t)1L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,4,local+1); /*aset*/
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)1L);
	local[3]= makeint((eusinteger_t)2L);
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,1,local+4); /*-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,4,local+1); /*aset*/
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)2L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,1,local+4); /*-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,4,local+1); /*aset*/
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)2L);
	local[3]= makeint((eusinteger_t)1L);
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,4,local+1); /*aset*/
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)2L);
	local[3]= makeint((eusinteger_t)2L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,4,local+1); /*aset*/
	w = local[0];
	local[0]= w;
irtmathBLK76:
	ctx->vsp=local; return(local[0]);}

/*matrix2quaternion*/
static pointer irtmathF8matrix2quaternion(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= makeint((eusinteger_t)1L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)1L);
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= makeint((eusinteger_t)2L);
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,4,local+5); /*+*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)4L);
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)1L);
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= makeint((eusinteger_t)1L);
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,1,local+8); /*-*/
	local[8]= w;
	local[9]= argv[0];
	local[10]= makeint((eusinteger_t)2L);
	local[11]= makeint((eusinteger_t)2L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,1,local+9); /*-*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,4,local+6); /*+*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)4L);
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)1L);
	local[8]= argv[0];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,1,local+8); /*-*/
	local[8]= w;
	local[9]= argv[0];
	local[10]= makeint((eusinteger_t)1L);
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	local[10]= argv[0];
	local[11]= makeint((eusinteger_t)2L);
	local[12]= makeint((eusinteger_t)2L);
	ctx->vsp=local+13;
	w=(pointer)AREF(ctx,3,local+10); /*aref*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)MINUS(ctx,1,local+10); /*-*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,4,local+7); /*+*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)4L);
	ctx->vsp=local+9;
	w=(pointer)QUOTIENT(ctx,2,local+7); /*/*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)1L);
	local[9]= argv[0];
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,1,local+9); /*-*/
	local[9]= w;
	local[10]= argv[0];
	local[11]= makeint((eusinteger_t)1L);
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(pointer)AREF(ctx,3,local+10); /*aref*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)MINUS(ctx,1,local+10); /*-*/
	local[10]= w;
	local[11]= argv[0];
	local[12]= makeint((eusinteger_t)2L);
	local[13]= makeint((eusinteger_t)2L);
	ctx->vsp=local+14;
	w=(pointer)AREF(ctx,3,local+11); /*aref*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,4,local+8); /*+*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)4L);
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	local[8]= w;
	local[9]= local[5];
	local[10]= local[6];
	local[11]= local[7];
	local[12]= local[8];
	ctx->vsp=local+13;
	w=(pointer)MAX(ctx,4,local+9); /*max*/
	local[4] = w;
	local[9]= local[4];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(*ftab[11])(ctx,2,local+9,&ftab[11],fqv[14]); /*eps=*/
	if (w==NIL) goto irtmathCON81;
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)SQRT(ctx,1,local+9); /*sqrt*/
	local[0] = w;
	local[9]= argv[0];
	local[10]= makeint((eusinteger_t)2L);
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	local[10]= argv[0];
	local[11]= makeint((eusinteger_t)1L);
	local[12]= makeint((eusinteger_t)2L);
	ctx->vsp=local+13;
	w=(pointer)AREF(ctx,3,local+10); /*aref*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)MINUS(ctx,2,local+9); /*-*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)4L);
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[1] = w;
	local[9]= argv[0];
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)2L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	local[10]= argv[0];
	local[11]= makeint((eusinteger_t)2L);
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(pointer)AREF(ctx,3,local+10); /*aref*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)MINUS(ctx,2,local+9); /*-*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)4L);
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[2] = w;
	local[9]= argv[0];
	local[10]= makeint((eusinteger_t)1L);
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	local[10]= argv[0];
	local[11]= makeint((eusinteger_t)0L);
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(pointer)AREF(ctx,3,local+10); /*aref*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)MINUS(ctx,2,local+9); /*-*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)4L);
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[3] = w;
	local[9]= local[3];
	goto irtmathCON80;
irtmathCON81:
	local[9]= local[4];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(*ftab[11])(ctx,2,local+9,&ftab[11],fqv[14]); /*eps=*/
	if (w==NIL) goto irtmathCON82;
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)SQRT(ctx,1,local+9); /*sqrt*/
	local[1] = w;
	local[9]= argv[0];
	local[10]= makeint((eusinteger_t)2L);
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	local[10]= argv[0];
	local[11]= makeint((eusinteger_t)1L);
	local[12]= makeint((eusinteger_t)2L);
	ctx->vsp=local+13;
	w=(pointer)AREF(ctx,3,local+10); /*aref*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)MINUS(ctx,2,local+9); /*-*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)4L);
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[0] = w;
	local[9]= argv[0];
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	local[10]= argv[0];
	local[11]= makeint((eusinteger_t)1L);
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(pointer)AREF(ctx,3,local+10); /*aref*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)4L);
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[2] = w;
	local[9]= argv[0];
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)2L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	local[10]= argv[0];
	local[11]= makeint((eusinteger_t)2L);
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(pointer)AREF(ctx,3,local+10); /*aref*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)4L);
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[3] = w;
	local[9]= local[3];
	goto irtmathCON80;
irtmathCON82:
	local[9]= local[4];
	local[10]= local[7];
	ctx->vsp=local+11;
	w=(*ftab[11])(ctx,2,local+9,&ftab[11],fqv[14]); /*eps=*/
	if (w==NIL) goto irtmathCON83;
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)SQRT(ctx,1,local+9); /*sqrt*/
	local[2] = w;
	local[9]= argv[0];
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)2L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	local[10]= argv[0];
	local[11]= makeint((eusinteger_t)2L);
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(pointer)AREF(ctx,3,local+10); /*aref*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)MINUS(ctx,2,local+9); /*-*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)4L);
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[0] = w;
	local[9]= argv[0];
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	local[10]= argv[0];
	local[11]= makeint((eusinteger_t)1L);
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(pointer)AREF(ctx,3,local+10); /*aref*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)4L);
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[1] = w;
	local[9]= argv[0];
	local[10]= makeint((eusinteger_t)1L);
	local[11]= makeint((eusinteger_t)2L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	local[10]= argv[0];
	local[11]= makeint((eusinteger_t)2L);
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(pointer)AREF(ctx,3,local+10); /*aref*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)4L);
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[3] = w;
	local[9]= local[3];
	goto irtmathCON80;
irtmathCON83:
	local[9]= local[4];
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(*ftab[11])(ctx,2,local+9,&ftab[11],fqv[14]); /*eps=*/
	if (w==NIL) goto irtmathCON84;
	local[9]= local[8];
	ctx->vsp=local+10;
	w=(pointer)SQRT(ctx,1,local+9); /*sqrt*/
	local[3] = w;
	local[9]= argv[0];
	local[10]= makeint((eusinteger_t)1L);
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	local[10]= argv[0];
	local[11]= makeint((eusinteger_t)0L);
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(pointer)AREF(ctx,3,local+10); /*aref*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)MINUS(ctx,2,local+9); /*-*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)4L);
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[0] = w;
	local[9]= argv[0];
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)2L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	local[10]= argv[0];
	local[11]= makeint((eusinteger_t)2L);
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(pointer)AREF(ctx,3,local+10); /*aref*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)4L);
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[1] = w;
	local[9]= argv[0];
	local[10]= makeint((eusinteger_t)1L);
	local[11]= makeint((eusinteger_t)2L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	local[10]= argv[0];
	local[11]= makeint((eusinteger_t)2L);
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(pointer)AREF(ctx,3,local+10); /*aref*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)4L);
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[2] = w;
	local[9]= local[2];
	goto irtmathCON80;
irtmathCON84:
	local[9]= fqv[15];
	ctx->vsp=local+10;
	w=(*ftab[4])(ctx,1,local+9,&ftab[4],fqv[6]); /*warn*/
	local[9]= w;
	goto irtmathCON80;
irtmathCON85:
	local[9]= NIL;
irtmathCON80:
	local[9]= local[0];
	local[10]= local[1];
	local[11]= local[2];
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)MKFLTVEC(ctx,4,local+9); /*float-vector*/
	local[0]= w;
irtmathBLK79:
	ctx->vsp=local; return(local[0]);}

/*quaternion2matrix*/
static pointer irtmathF9quaternion2matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= makeint((eusinteger_t)3L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)VINNERPRODUCT(ctx,2,local+4); /*v.*/
	local[4]= w;
	local[5]= makeflt(1.0000000000000000000000e+00);
	local[6]= makeflt(9.9999999999999950039964e-03);
	ctx->vsp=local+7;
	w=(*ftab[11])(ctx,3,local+4,&ftab[11],fqv[14]); /*eps=*/
	if (w!=NIL) goto irtmathIF87;
	local[4]= makeint((eusinteger_t)1L);
	local[5]= fqv[16];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(*ftab[12])(ctx,3,local+4,&ftab[12],fqv[17]); /*warning-message*/
	local[4]= w;
	goto irtmathIF88;
irtmathIF87:
	local[4]= NIL;
irtmathIF88:
	local[4]= makeint((eusinteger_t)3L);
	local[5]= makeint((eusinteger_t)3L);
	local[6]= local[0];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	local[7]= local[1];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	local[8]= local[2];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,1,local+8); /*-*/
	local[8]= w;
	local[9]= local[3];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,1,local+9); /*-*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,4,local+6); /*+*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)2L);
	local[8]= local[1];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	local[9]= local[0];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,2,local+8); /*-*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	local[8]= makeint((eusinteger_t)2L);
	local[9]= local[1];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	local[10]= local[0];
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,3,local+6); /*float-vector*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)2L);
	local[8]= local[1];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	local[9]= local[0];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	local[8]= local[0];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	local[9]= local[1];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,1,local+9); /*-*/
	local[9]= w;
	local[10]= local[2];
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	local[11]= local[3];
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)MINUS(ctx,1,local+11); /*-*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,4,local+8); /*+*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)2L);
	local[10]= local[2];
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	local[11]= local[0];
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)MINUS(ctx,2,local+10); /*-*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)2L);
	local[9]= local[1];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	local[10]= local[0];
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)MINUS(ctx,2,local+9); /*-*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	local[9]= makeint((eusinteger_t)2L);
	local[10]= local[2];
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	local[11]= local[0];
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	local[10]= local[0];
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	local[11]= local[1];
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)MINUS(ctx,1,local+11); /*-*/
	local[11]= w;
	local[12]= local[2];
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(pointer)TIMES(ctx,2,local+12); /***/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)MINUS(ctx,1,local+12); /*-*/
	local[12]= w;
	local[13]= local[3];
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)TIMES(ctx,2,local+13); /***/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)PLUS(ctx,4,local+10); /*+*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,3,local+6); /*list*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[3])(ctx,3,local+4,&ftab[3],fqv[3]); /*make-matrix*/
	local[0]= w;
irtmathBLK86:
	ctx->vsp=local; return(local[0]);}

/*matrix-log*/
static pointer irtmathF10matrix_log(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)irtmathF8matrix2quaternion(ctx,1,local+0); /*matrix2quaternion*/
	local[0]= w;
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)1L);
	local[4]= makeint((eusinteger_t)4L);
	ctx->vsp=local+5;
	w=(pointer)SUBSEQ(ctx,3,local+2); /*subseq*/
	local[2]= w;
	local[3]= makeflt(2.0000000000000000000000e+00);
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)VNORM(ctx,1,local+4); /*norm*/
	local[4]= w;
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)ATAN(ctx,2,local+4); /*atan*/
	{ double x,y;
		y=fltval(w); x=fltval(local[3]);
		local[3]=(makeflt(x * y));}
	local[4]= local[3];
	local[5]= makeflt(3.1415926535897931159980e+00);
	ctx->vsp=local+6;
	w=(pointer)GREATERP(ctx,2,local+4); /*>*/
	if (w==NIL) goto irtmathCON91;
	local[4]= local[3];
	local[5]= makeflt(6.2831853071795862319959e+00);
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[3] = w;
	local[4]= local[3];
	goto irtmathCON90;
irtmathCON91:
	local[4]= local[3];
	local[5]= makeflt(-3.1415926535897931159980e+00);
	ctx->vsp=local+6;
	w=(pointer)LESSP(ctx,2,local+4); /*<*/
	if (w==NIL) goto irtmathCON92;
	local[4]= local[3];
	local[5]= makeflt(6.2831853071795862319959e+00);
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[3] = w;
	local[4]= local[3];
	goto irtmathCON90;
irtmathCON92:
	local[4]= NIL;
irtmathCON90:
	local[4]= local[3];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)irtmathF34normalize_vector(ctx,1,local+5); /*normalize-vector*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SCALEVEC(ctx,2,local+4); /*scale*/
	local[0]= w;
irtmathBLK89:
	ctx->vsp=local; return(local[0]);}

/*matrix-exponent*/
static pointer irtmathF11matrix_exponent(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto irtmathENT95;}
	local[0]= makeflt(1.0000000000000000000000e+00);
irtmathENT95:
irtmathENT94:
	if (n>2) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)VNORM(ctx,1,local+3); /*norm*/
	local[1] = w;
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)irtmathF34normalize_vector(ctx,1,local+3); /*normalize-vector*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)irtmathF7outer_product_matrix(ctx,1,local+3); /*outer-product-matrix*/
	local[2] = w;
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,0,local+3,&ftab[1],fqv[1]); /*unit-matrix*/
	local[3]= w;
	local[4]= local[1];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SIN(ctx,1,local+4); /*sin*/
	local[4]= w;
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(*ftab[7])(ctx,2,local+4,&ftab[7],fqv[9]); /*scale-matrix*/
	local[4]= w;
	local[5]= makeflt(1.0000000000000000000000e+00);
	local[6]= local[1];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)COS(ctx,1,local+6); /*cos*/
	{ double x,y;
		y=fltval(w); x=fltval(local[5]);
		local[5]=(makeflt(x - y));}
	local[6]= local[2];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)MATTIMES(ctx,2,local+6); /*m**/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[7])(ctx,2,local+5,&ftab[7],fqv[9]); /*scale-matrix*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[10])(ctx,2,local+4,&ftab[10],fqv[13]); /*m+*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[10])(ctx,2,local+3,&ftab[10],fqv[13]); /*m+*/
	local[0]= w;
irtmathBLK93:
	ctx->vsp=local; return(local[0]);}

/*midrot*/
static pointer irtmathF12midrot(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)TRANSPOSE(ctx,1,local+2); /*transpose*/
	local[2]= w;
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)MATTIMES(ctx,2,local+2); /*m**/
	local[0] = w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)irtmathF10matrix_log(ctx,1,local+2); /*matrix-log*/
	local[1] = w;
	local[2]= local[1];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)irtmathF11matrix_exponent(ctx,2,local+2); /*matrix-exponent*/
	local[0] = w;
	local[2]= argv[1];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)MATTIMES(ctx,2,local+2); /*m**/
	local[0]= w;
irtmathBLK96:
	ctx->vsp=local; return(local[0]);}

/*pseudo-inverse*/
static pointer irtmathF13pseudo_inverse(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto irtmathENT102;}
	local[0]= NIL;
irtmathENT102:
	if (n>=3) { local[1]=(argv[2]); goto irtmathENT101;}
	local[1]= NIL;
irtmathENT101:
	if (n>=4) { local[2]=(argv[3]); goto irtmathENT100;}
	local[2]= NIL;
irtmathENT100:
	if (n>=5) { local[3]=(argv[4]); goto irtmathENT99;}
	local[3]= NIL;
irtmathENT99:
irtmathENT98:
	if (n>5) maerror();
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(*ftab[0])(ctx,2,local+4,&ftab[0],fqv[0]); /*array-dimension*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(*ftab[0])(ctx,2,local+5,&ftab[0],fqv[0]); /*array-dimension*/
	local[5]= w;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	if (local[1]!=NIL) goto irtmathIF103;
	local[9]= local[5];
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(*ftab[3])(ctx,2,local+9,&ftab[3],fqv[3]); /*make-matrix*/
	local[1] = w;
	local[9]= local[1];
	goto irtmathIF104;
irtmathIF103:
	local[9]= NIL;
irtmathIF104:
	if (local[0]!=NIL) goto irtmathIF105;
	local[9]= argv[0];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(*ftab[13])(ctx,2,local+9,&ftab[13],fqv[18]); /*pseudo-inverse2*/
	ctx->vsp=local+9;
	local[0]=w;
	goto irtmathBLK97;
	goto irtmathIF106;
irtmathIF105:
	local[9]= NIL;
irtmathIF106:
	local[9]= local[4];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)MAX(ctx,2,local+9); /*max*/
	local[6] = w;
	if (local[2]!=NIL) goto irtmathIF107;
	local[9]= local[6];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(*ftab[3])(ctx,2,local+9,&ftab[3],fqv[3]); /*make-matrix*/
	local[2] = w;
	local[9]= local[2];
	goto irtmathIF108;
irtmathIF107:
	local[9]= NIL;
irtmathIF108:
	if (local[3]!=NIL) goto irtmathIF109;
	local[9]= local[4];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(*ftab[3])(ctx,2,local+9,&ftab[3],fqv[3]); /*make-matrix*/
	local[3] = w;
	local[9]= local[3];
	goto irtmathIF110;
irtmathIF109:
	local[9]= NIL;
irtmathIF110:
	local[9]= makeint((eusinteger_t)0L);
	local[10]= local[6];
irtmathWHL111:
	local[11]= local[9];
	w = local[10];
	if ((eusinteger_t)local[11] >= (eusinteger_t)w) goto irtmathWHX112;
	local[11]= local[2];
	local[12]= local[9];
	local[13]= local[9];
	local[14]= local[0];
	local[15]= local[9];
	ctx->vsp=local+16;
	w=(pointer)AREF(ctx,2,local+14); /*aref*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SQRT(ctx,1,local+14); /*sqrt*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)ASET(ctx,4,local+11); /*aset*/
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[9] = w;
	goto irtmathWHL111;
irtmathWHX112:
	local[11]= NIL;
irtmathBLK113:
	w = NIL;
	local[9]= local[4];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)LSEQP(ctx,2,local+9); /*<=*/
	if (w==NIL) goto irtmathIF114;
	local[9]= argv[0];
	local[10]= local[2];
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)MATTIMES(ctx,3,local+9); /*m**/
	local[9]= w;
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(*ftab[13])(ctx,2,local+9,&ftab[13],fqv[18]); /*pseudo-inverse2*/
	local[7] = w;
	if (local[7]==NIL) goto irtmathIF116;
	local[9]= local[2];
	local[10]= local[7];
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)MATTIMES(ctx,3,local+9); /*m**/
	local[9]= w;
	goto irtmathIF117;
irtmathIF116:
	local[9]= NIL;
irtmathIF117:
	goto irtmathIF115;
irtmathIF114:
	local[9]= local[2];
	local[10]= argv[0];
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)MATTIMES(ctx,3,local+9); /*m**/
	local[9]= w;
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(*ftab[13])(ctx,2,local+9,&ftab[13],fqv[18]); /*pseudo-inverse2*/
	local[7] = w;
	if (local[7]==NIL) goto irtmathIF118;
	local[9]= local[7];
	local[10]= local[2];
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)MATTIMES(ctx,3,local+9); /*m**/
	local[9]= w;
	goto irtmathIF119;
irtmathIF118:
	local[9]= NIL;
irtmathIF119:
irtmathIF115:
	w = local[9];
	local[0]= w;
irtmathBLK97:
	ctx->vsp=local; return(local[0]);}

/*pseudo-inverse-org*/
static pointer irtmathF14pseudo_inverse_org(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto irtmathENT124;}
	local[0]= NIL;
irtmathENT124:
	if (n>=3) { local[1]=(argv[2]); goto irtmathENT123;}
	local[1]= NIL;
irtmathENT123:
	if (n>=4) { local[2]=(argv[3]); goto irtmathENT122;}
	local[2]= NIL;
irtmathENT122:
irtmathENT121:
	if (n>4) maerror();
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= argv[0];
	ctx->vsp=local+10;
	w=(*ftab[6])(ctx,1,local+9,&ftab[6],fqv[8]); /*array-dimensions*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.car;
	local[9]= argv[0];
	ctx->vsp=local+10;
	w=(*ftab[14])(ctx,1,local+9,&ftab[14],fqv[19]); /*sv-decompose*/
	local[4] = w;
	if (local[4]!=NIL) goto irtmathIF125;
	local[9]= fqv[20];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(*ftab[4])(ctx,2,local+9,&ftab[4],fqv[6]); /*warn*/
	w = NIL;
	ctx->vsp=local+9;
	local[0]=w;
	goto irtmathBLK120;
	goto irtmathIF126;
irtmathIF125:
	local[9]= NIL;
irtmathIF126:
	local[9]= local[4];
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[5] = w;
	local[9]= local[4];
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[6] = w;
	local[9]= local[4];
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[7] = w;
	if (local[1]!=NIL) goto irtmathIF127;
	local[9]= local[3];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(*ftab[3])(ctx,2,local+9,&ftab[3],fqv[3]); /*make-matrix*/
	local[1] = w;
	local[9]= local[1];
	goto irtmathIF128;
irtmathIF127:
	local[9]= NIL;
irtmathIF128:
	if (local[2]!=NIL) goto irtmathIF129;
	local[9]= local[3];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(*ftab[6])(ctx,1,local+10,&ftab[6],fqv[8]); /*array-dimensions*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	ctx->vsp=local+11;
	w=(*ftab[3])(ctx,2,local+9,&ftab[3],fqv[3]); /*make-matrix*/
	local[2] = w;
	local[9]= local[2];
	goto irtmathIF130;
irtmathIF129:
	local[9]= NIL;
irtmathIF130:
	if (local[0]!=NIL) goto irtmathIF131;
	local[9]= local[3];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(*ftab[6])(ctx,1,local+10,&ftab[6],fqv[8]); /*array-dimensions*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	ctx->vsp=local+11;
	w=(*ftab[3])(ctx,2,local+9,&ftab[3],fqv[3]); /*make-matrix*/
	local[0] = w;
	local[9]= local[0];
	goto irtmathIF132;
irtmathIF131:
	local[9]= NIL;
irtmathIF132:
	local[9]= local[1]->c.obj.iv[1];
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(*ftab[15])(ctx,2,local+9,&ftab[15],fqv[21]); /*fill*/
	local[9]= local[6];
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[8] = w;
	local[9]= local[8];
	local[10]= makeflt(9.9999999999999991239646e-05);
	ctx->vsp=local+11;
	w=(pointer)GREATERP(ctx,2,local+9); /*>*/
	if (w==NIL) goto irtmathIF133;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= local[3];
irtmathWHL135:
	local[11]= local[9];
	w = local[10];
	if ((eusinteger_t)local[11] >= (eusinteger_t)w) goto irtmathWHX136;
	local[11]= local[6];
	local[12]= local[9];
	local[13]= local[9];
	ctx->vsp=local+14;
	w=(pointer)AREF(ctx,3,local+11); /*aref*/
	local[11]= w;
	local[12]= local[8];
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	local[11]= w;
	local[12]= makeflt(9.9999999999999991239646e-05);
	ctx->vsp=local+13;
	w=(pointer)GREATERP(ctx,2,local+11); /*>*/
	if (w==NIL) goto irtmathIF138;
	local[11]= local[1];
	local[12]= local[9];
	local[13]= local[9];
	local[14]= makeflt(1.0000000000000000000000e+00);
	local[15]= local[6];
	local[16]= local[9];
	local[17]= local[9];
	ctx->vsp=local+18;
	w=(pointer)AREF(ctx,3,local+15); /*aref*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)QUOTIENT(ctx,2,local+14); /*/*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)ASET(ctx,4,local+11); /*aset*/
	local[11]= w;
	goto irtmathIF139;
irtmathIF138:
	local[11]= NIL;
irtmathIF139:
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[9] = w;
	goto irtmathWHL135;
irtmathWHX136:
	local[11]= NIL;
irtmathBLK137:
	w = NIL;
	local[9]= w;
	goto irtmathIF134;
irtmathIF133:
	local[9]= NIL;
irtmathIF134:
	local[9]= local[7];
	local[10]= local[1];
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)MATTIMES(ctx,3,local+9); /*m**/
	local[9]= w;
	local[10]= local[5];
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)TRANSPOSE(ctx,2,local+10); /*transpose*/
	local[10]= w;
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(pointer)MATTIMES(ctx,3,local+9); /*m**/
	local[0] = w;
	w = local[0];
	local[0]= w;
irtmathBLK120:
	ctx->vsp=local; return(local[0]);}

/*sr-inverse*/
static pointer irtmathF15sr_inverse(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto irtmathENT152;}
	local[0]= makeflt(1.0000000000000000000000e+00);
irtmathENT152:
	if (n>=3) { local[1]=(argv[2]); goto irtmathENT151;}
	local[1]= NIL;
irtmathENT151:
	if (n>=4) { local[2]=(argv[3]); goto irtmathENT150;}
	local[2]= NIL;
irtmathENT150:
	if (n>=5) { local[3]=(argv[4]); goto irtmathENT149;}
	local[3]= NIL;
irtmathENT149:
	if (n>=6) { local[4]=(argv[5]); goto irtmathENT148;}
	local[4]= NIL;
irtmathENT148:
	if (n>=7) { local[5]=(argv[6]); goto irtmathENT147;}
	local[5]= NIL;
irtmathENT147:
	if (n>=8) { local[6]=(argv[7]); goto irtmathENT146;}
	local[6]= NIL;
irtmathENT146:
	if (n>=9) { local[7]=(argv[8]); goto irtmathENT145;}
	local[7]= NIL;
irtmathENT145:
	if (n>=10) { local[8]=(argv[9]); goto irtmathENT144;}
	local[8]= NIL;
irtmathENT144:
	if (n>=11) { local[9]=(argv[10]); goto irtmathENT143;}
	local[9]= NIL;
irtmathENT143:
	if (n>=12) { local[10]=(argv[11]); goto irtmathENT142;}
	local[10]= NIL;
irtmathENT142:
irtmathENT141:
	if (n>12) maerror();
	local[11]= argv[0];
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(*ftab[0])(ctx,2,local+11,&ftab[0],fqv[0]); /*array-dimension*/
	local[11]= w;
	local[12]= argv[0];
	local[13]= makeint((eusinteger_t)1L);
	ctx->vsp=local+14;
	w=(*ftab[0])(ctx,2,local+12,&ftab[0],fqv[0]); /*array-dimension*/
	local[12]= w;
	if (local[4]!=NIL) goto irtmathIF153;
	local[13]= local[12];
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(*ftab[3])(ctx,2,local+13,&ftab[3],fqv[3]); /*make-matrix*/
	local[4] = w;
	local[13]= local[4];
	goto irtmathIF154;
irtmathIF153:
	local[13]= NIL;
irtmathIF154:
	if (local[1]!=NIL) goto irtmathIF155;
	if (local[9]!=NIL) goto irtmathIF157;
	local[13]= local[11];
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(*ftab[3])(ctx,2,local+13,&ftab[3],fqv[3]); /*make-matrix*/
	local[9] = w;
	local[13]= local[9];
	goto irtmathIF158;
irtmathIF157:
	local[13]= NIL;
irtmathIF158:
	if (local[10]!=NIL) goto irtmathIF159;
	local[13]= local[11];
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(*ftab[3])(ctx,2,local+13,&ftab[3],fqv[3]); /*make-matrix*/
	local[10] = w;
	local[13]= local[10];
	goto irtmathIF160;
irtmathIF159:
	local[13]= NIL;
irtmathIF160:
	local[13]= argv[0];
	local[14]= local[0];
	local[15]= local[9];
	local[16]= local[4];
	local[17]= local[10];
	ctx->vsp=local+18;
	w=(pointer)irtmathF16sr_inverse_org(ctx,5,local+13); /*sr-inverse-org*/
	ctx->vsp=local+13;
	local[0]=w;
	goto irtmathBLK140;
	goto irtmathIF156;
irtmathIF155:
	local[13]= NIL;
irtmathIF156:
	if (local[2]!=NIL) goto irtmathIF161;
	local[13]= local[12];
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(*ftab[3])(ctx,2,local+13,&ftab[3],fqv[3]); /*make-matrix*/
	local[2] = w;
	local[13]= local[2];
	goto irtmathIF162;
irtmathIF161:
	local[13]= NIL;
irtmathIF162:
	if (local[3]!=NIL) goto irtmathIF163;
	local[13]= local[12];
	local[14]= local[12];
	ctx->vsp=local+15;
	w=(*ftab[3])(ctx,2,local+13,&ftab[3],fqv[3]); /*make-matrix*/
	local[3] = w;
	local[13]= local[3];
	goto irtmathIF164;
irtmathIF163:
	local[13]= NIL;
irtmathIF164:
	if (local[8]!=NIL) goto irtmathIF165;
	local[13]= local[11];
	local[14]= local[12];
	ctx->vsp=local+15;
	w=(*ftab[3])(ctx,2,local+13,&ftab[3],fqv[3]); /*make-matrix*/
	local[8] = w;
	local[13]= local[8];
	goto irtmathIF166;
irtmathIF165:
	local[13]= NIL;
irtmathIF166:
	local[13]= local[0];
	local[14]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+15;
	w=(pointer)NUMEQUAL(ctx,2,local+13); /*=*/
	if (w==NIL) goto irtmathIF167;
	local[13]= argv[0];
	local[14]= local[1];
	local[15]= local[2];
	local[16]= local[3];
	local[17]= local[8];
	ctx->vsp=local+18;
	w=(pointer)irtmathF13pseudo_inverse(ctx,5,local+13); /*pseudo-inverse*/
	ctx->vsp=local+13;
	local[0]=w;
	goto irtmathBLK140;
	goto irtmathIF168;
irtmathIF167:
	local[13]= NIL;
irtmathIF168:
	if (local[5]!=NIL) goto irtmathIF169;
	local[13]= local[11];
	ctx->vsp=local+14;
	w=(*ftab[1])(ctx,1,local+13,&ftab[1],fqv[1]); /*unit-matrix*/
	local[5] = w;
	local[13]= local[5];
	goto irtmathIF170;
irtmathIF169:
	local[13]= local[5]->c.obj.iv[1];
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(*ftab[15])(ctx,2,local+13,&ftab[15],fqv[21]); /*fill*/
	local[13]= makeint((eusinteger_t)0L);
	local[14]= local[11];
irtmathWHL171:
	local[15]= local[13];
	w = local[14];
	if ((eusinteger_t)local[15] >= (eusinteger_t)w) goto irtmathWHX172;
	local[15]= local[5];
	local[16]= local[13];
	local[17]= local[13];
	local[18]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+19;
	w=(pointer)ASET(ctx,4,local+15); /*aset*/
	local[15]= local[13];
	ctx->vsp=local+16;
	w=(pointer)ADD1(ctx,1,local+15); /*1+*/
	local[13] = w;
	goto irtmathWHL171;
irtmathWHX172:
	local[15]= NIL;
irtmathBLK173:
	w = NIL;
	local[13]= w;
irtmathIF170:
	if (local[6]!=NIL) goto irtmathIF174;
	local[13]= local[11];
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(*ftab[3])(ctx,2,local+13,&ftab[3],fqv[3]); /*make-matrix*/
	local[6] = w;
	local[13]= local[6];
	goto irtmathIF175;
irtmathIF174:
	local[13]= NIL;
irtmathIF175:
	if (local[7]!=NIL) goto irtmathIF176;
	local[13]= local[12];
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(*ftab[3])(ctx,2,local+13,&ftab[3],fqv[3]); /*make-matrix*/
	local[7] = w;
	local[13]= local[7];
	goto irtmathIF177;
irtmathIF176:
	local[13]= NIL;
irtmathIF177:
	local[13]= makeint((eusinteger_t)0L);
	local[14]= local[12];
irtmathWHL178:
	local[15]= local[13];
	w = local[14];
	if ((eusinteger_t)local[15] >= (eusinteger_t)w) goto irtmathWHX179;
	local[15]= local[3];
	local[16]= local[13];
	local[17]= local[13];
	local[18]= local[1];
	local[19]= local[13];
	ctx->vsp=local+20;
	w=(pointer)AREF(ctx,2,local+18); /*aref*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)ASET(ctx,4,local+15); /*aset*/
	local[15]= local[13];
	ctx->vsp=local+16;
	w=(pointer)ADD1(ctx,1,local+15); /*1+*/
	local[13] = w;
	goto irtmathWHL178;
irtmathWHX179:
	local[15]= NIL;
irtmathBLK180:
	w = NIL;
	local[13]= local[3];
	local[14]= argv[0];
	local[15]= local[4];
	ctx->vsp=local+16;
	w=(pointer)TRANSPOSE(ctx,2,local+14); /*transpose*/
	local[14]= w;
	local[15]= local[7];
	ctx->vsp=local+16;
	w=(pointer)MATTIMES(ctx,3,local+13); /*m**/
	local[13]= w;
	local[14]= argv[0];
	local[15]= local[7];
	local[16]= local[6];
	ctx->vsp=local+17;
	w=(pointer)MATTIMES(ctx,3,local+14); /*m**/
	local[14]= w;
	local[15]= local[0];
	local[16]= local[5];
	local[17]= local[5];
	ctx->vsp=local+18;
	w=(*ftab[7])(ctx,3,local+15,&ftab[7],fqv[9]); /*scale-matrix*/
	local[15]= w;
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(*ftab[10])(ctx,3,local+14,&ftab[10],fqv[13]); /*m+*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)irtmathF1inverse_matrix(ctx,1,local+14); /*inverse-matrix*/
	local[14]= w;
	local[15]= local[2];
	ctx->vsp=local+16;
	w=(pointer)MATTIMES(ctx,3,local+13); /*m**/
	w = local[2];
	local[0]= w;
irtmathBLK140:
	ctx->vsp=local; return(local[0]);}

/*sr-inverse-org*/
static pointer irtmathF16sr_inverse_org(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto irtmathENT186;}
	local[0]= makeint((eusinteger_t)1L);
irtmathENT186:
	if (n>=3) { local[1]=(argv[2]); goto irtmathENT185;}
	local[1]= NIL;
irtmathENT185:
	if (n>=4) { local[2]=(argv[3]); goto irtmathENT184;}
	local[2]= NIL;
irtmathENT184:
	if (n>=5) { local[3]=(argv[4]); goto irtmathENT183;}
	local[3]= NIL;
irtmathENT183:
irtmathENT182:
	if (n>5) maerror();
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[6])(ctx,1,local+4,&ftab[6],fqv[8]); /*array-dimensions*/
	local[4]= w;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	if (local[1]!=NIL) goto irtmathIF187;
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(*ftab[1])(ctx,1,local+7,&ftab[1],fqv[1]); /*unit-matrix*/
	local[1] = w;
	local[7]= local[1];
	goto irtmathIF188;
irtmathIF187:
	local[7]= local[1]->c.obj.iv[1];
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(*ftab[15])(ctx,2,local+7,&ftab[15],fqv[21]); /*fill*/
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[5];
irtmathWHL189:
	local[9]= local[7];
	w = local[8];
	if ((eusinteger_t)local[9] >= (eusinteger_t)w) goto irtmathWHX190;
	local[9]= local[1];
	local[10]= local[7];
	local[11]= local[7];
	local[12]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+13;
	w=(pointer)ASET(ctx,4,local+9); /*aset*/
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[7] = w;
	goto irtmathWHL189;
irtmathWHX190:
	local[9]= NIL;
irtmathBLK191:
	w = NIL;
	local[7]= w;
irtmathIF188:
	if (local[2]!=NIL) goto irtmathIF192;
	local[7]= local[6];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(*ftab[3])(ctx,2,local+7,&ftab[3],fqv[3]); /*make-matrix*/
	local[2] = w;
	local[7]= local[2];
	goto irtmathIF193;
irtmathIF192:
	local[7]= NIL;
irtmathIF193:
	if (local[3]!=NIL) goto irtmathIF194;
	local[7]= local[5];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(*ftab[3])(ctx,2,local+7,&ftab[3],fqv[3]); /*make-matrix*/
	local[3] = w;
	local[7]= local[3];
	goto irtmathIF195;
irtmathIF194:
	local[7]= NIL;
irtmathIF195:
	local[7]= argv[0];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)TRANSPOSE(ctx,2,local+7); /*transpose*/
	local[2] = w;
	local[7]= local[2];
	local[8]= argv[0];
	local[9]= local[2];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)MATTIMES(ctx,3,local+8); /*m**/
	local[8]= w;
	local[9]= local[0];
	local[10]= local[1];
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(*ftab[7])(ctx,3,local+9,&ftab[7],fqv[9]); /*scale-matrix*/
	local[9]= w;
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(*ftab[10])(ctx,3,local+8,&ftab[10],fqv[13]); /*m+*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)irtmathF1inverse_matrix(ctx,1,local+8); /*inverse-matrix*/
	local[8]= w;
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)MATTIMES(ctx,3,local+7); /*m**/
	local[0]= w;
irtmathBLK181:
	ctx->vsp=local; return(local[0]);}

/*manipulability*/
static pointer irtmathF17manipulability(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto irtmathENT199;}
	local[0]= NIL;
irtmathENT199:
	if (n>=3) { local[1]=(argv[2]); goto irtmathENT198;}
	local[1]= NIL;
irtmathENT198:
irtmathENT197:
	if (n>3) maerror();
	local[2]= argv[0];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(*ftab[0])(ctx,2,local+2,&ftab[0],fqv[0]); /*array-dimension*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(*ftab[0])(ctx,2,local+3,&ftab[0],fqv[0]); /*array-dimension*/
	local[3]= w;
	if (local[0]!=NIL) goto irtmathIF200;
	local[4]= local[2];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(*ftab[3])(ctx,2,local+4,&ftab[3],fqv[3]); /*make-matrix*/
	local[0] = w;
	local[4]= local[0];
	goto irtmathIF201;
irtmathIF200:
	local[4]= NIL;
irtmathIF201:
	if (local[1]!=NIL) goto irtmathIF202;
	local[4]= local[3];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(*ftab[3])(ctx,2,local+4,&ftab[3],fqv[3]); /*make-matrix*/
	local[1] = w;
	local[4]= local[1];
	goto irtmathIF203;
irtmathIF202:
	local[4]= NIL;
irtmathIF203:
	local[4]= makeflt(0.0000000000000000000000e+00);
	local[5]= argv[0];
	local[6]= argv[0];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)TRANSPOSE(ctx,2,local+6); /*transpose*/
	local[6]= w;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)MATTIMES(ctx,3,local+5); /*m**/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[8])(ctx,1,local+5,&ftab[8],fqv[10]); /*matrix-determinant*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MAX(ctx,2,local+4); /*max*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SQRT(ctx,1,local+4); /*sqrt*/
	local[0]= w;
irtmathBLK196:
	ctx->vsp=local; return(local[0]);}

/*random-gauss*/
static pointer irtmathF18random_gauss(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto irtmathENT207;}
	local[0]= makeint((eusinteger_t)0L);
irtmathENT207:
	if (n>=2) { local[1]=(argv[1]); goto irtmathENT206;}
	local[1]= makeint((eusinteger_t)1L);
irtmathENT206:
irtmathENT205:
	if (n>2) maerror();
	local[2]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+3;
	w=(pointer)RANDOM(ctx,1,local+2); /*random*/
	local[2]= w;
	local[3]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+4;
	w=(pointer)RANDOM(ctx,1,local+3); /*random*/
	local[3]= w;
	local[4]= makeflt(-2.0000000000000000000000e+00);
	local[5]= local[1];
	local[6]= local[1];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)LOG(ctx,1,local+7); /*log*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,4,local+4); /***/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SQRT(ctx,1,local+4); /*sqrt*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)2L);
	local[6]= makeflt(3.1415926535897931159980e+00);
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,3,local+5); /***/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)COS(ctx,1,local+5); /*cos*/
	{ double x,y;
		y=fltval(w); x=fltval(local[4]);
		local[4]=(makeflt(x * y));}
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[0]= w;
irtmathBLK204:
	ctx->vsp=local; return(local[0]);}

/*gaussian-random*/
static pointer irtmathF19gaussian_random(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto irtmathENT211;}
	local[0]= makeint((eusinteger_t)0L);
irtmathENT211:
	if (n>=3) { local[1]=(argv[2]); goto irtmathENT210;}
	local[1]= makeint((eusinteger_t)1L);
irtmathENT210:
irtmathENT209:
	if (n>3) maerror();
	local[2]= loadglobal(fqv[4]);
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,2,local+2); /*instantiate*/
	local[2]= w;
	w = local[0];
	if (!isnum(w)) goto irtmathIF212;
	local[3]= argv[0];
	local[4]= fqv[22];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[16])(ctx,3,local+3,&ftab[16],fqv[23]); /*make-list*/
	local[0] = w;
	local[3]= local[0];
	goto irtmathIF213;
irtmathIF212:
	local[3]= NIL;
irtmathIF213:
	w = local[1];
	if (!isnum(w)) goto irtmathIF214;
	local[3]= argv[0];
	local[4]= fqv[22];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(*ftab[16])(ctx,3,local+3,&ftab[16],fqv[23]); /*make-list*/
	local[1] = w;
	local[3]= local[1];
	goto irtmathIF215;
irtmathIF214:
	local[3]= NIL;
irtmathIF215:
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[0];
irtmathWHL216:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto irtmathWHX217;
	local[5]= local[2];
	local[6]= local[3];
	local[7]= local[0];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	local[8]= local[1];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)irtmathF18random_gauss(ctx,2,local+7); /*random-gauss*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)ASET(ctx,3,local+5); /*aset*/
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto irtmathWHL216;
irtmathWHX217:
	local[5]= NIL;
irtmathBLK218:
	w = NIL;
	w = local[2];
	local[0]= w;
irtmathBLK208:
	ctx->vsp=local; return(local[0]);}

/*eigen-decompose*/
static pointer irtmathF20eigen_decompose(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[17])(ctx,1,local+0,&ftab[17],fqv[24]); /*qr-decompose*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	local[2]= local[1];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(*ftab[3])(ctx,2,local+2,&ftab[3],fqv[3]); /*make-matrix*/
	local[2]= w;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= NIL;
	local[10]= NIL;
	local[11]= makeint((eusinteger_t)10L);
	local[12]= NIL;
	local[13]= NIL;
	local[14]= local[0];
	local[15]= (pointer)get_sym_func(fqv[25]);
	ctx->vsp=local+16;
	w=(pointer)SORT(ctx,2,local+14); /*sort*/
	local[0] = w;
	local[14]= makeint((eusinteger_t)0L);
	local[15]= local[1];
irtmathWHL220:
	local[16]= local[14];
	w = local[15];
	if ((eusinteger_t)local[16] >= (eusinteger_t)w) goto irtmathWHX221;
	local[16]= argv[0];
	local[17]= local[0];
	local[18]= local[14];
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)MINUS(ctx,1,local+17); /*-*/
	local[17]= w;
	local[18]= local[1];
	ctx->vsp=local+19;
	w=(*ftab[1])(ctx,1,local+18,&ftab[1],fqv[1]); /*unit-matrix*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[7])(ctx,2,local+17,&ftab[7],fqv[9]); /*scale-matrix*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(*ftab[10])(ctx,2,local+16,&ftab[10],fqv[13]); /*m+*/
	local[3] = w;
	local[16]= local[3];
	ctx->vsp=local+17;
	w=(*ftab[18])(ctx,1,local+16,&ftab[18],fqv[26]); /*copy-matrix*/
	local[4] = w;
	local[16]= local[3];
	ctx->vsp=local+17;
	w=(pointer)LU_DECOMPOSE(ctx,1,local+16); /*lu-decompose*/
	local[7] = w;
	if (local[7]==NIL) goto irtmathIF223;
	local[16]= loadglobal(fqv[4]);
	local[17]= local[1];
	ctx->vsp=local+18;
	w=(pointer)INSTANTIATE(ctx,2,local+16); /*instantiate*/
	local[5] = w;
irtmathWHL225:
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(pointer)VNORM(ctx,1,local+16); /*norm*/
	local[16]= w;
	local[17]= makeint((eusinteger_t)0L);
	ctx->vsp=local+18;
	w=(*ftab[11])(ctx,2,local+16,&ftab[11],fqv[14]); /*eps=*/
	if (w==NIL) goto irtmathWHX226;
	local[16]= makeint((eusinteger_t)0L);
	local[17]= local[1];
irtmathWHL228:
	local[18]= local[16];
	w = local[17];
	if ((eusinteger_t)local[18] >= (eusinteger_t)w) goto irtmathWHX229;
	local[18]= local[5];
	local[19]= local[16];
	local[20]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+21;
	w=(pointer)RANDOM(ctx,1,local+20); /*random*/
	local[20]= w;
	local[21]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+22;
	w=(pointer)MINUS(ctx,2,local+20); /*-*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)SETELT(ctx,3,local+18); /*setelt*/
	local[18]= local[16];
	ctx->vsp=local+19;
	w=(pointer)ADD1(ctx,1,local+18); /*1+*/
	local[16] = w;
	goto irtmathWHL228;
irtmathWHX229:
	local[18]= NIL;
irtmathBLK230:
	w = NIL;
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(pointer)irtmathF34normalize_vector(ctx,1,local+16); /*normalize-vector*/
	local[5] = w;
	goto irtmathWHL225;
irtmathWHX226:
	local[16]= NIL;
irtmathBLK227:
	local[6] = local[5];
	local[10] = makeint((eusinteger_t)0L);
irtmathTAG232:
	local[16]= local[3];
	local[17]= local[7];
	local[18]= local[5];
	ctx->vsp=local+19;
	w=(pointer)LU_SOLVE(ctx,3,local+16); /*lu-solve*/
	local[5] = w;
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(pointer)irtmathF34normalize_vector(ctx,1,local+16); /*normalize-vector*/
	local[5] = w;
	local[16]= local[10];
	ctx->vsp=local+17;
	w=(pointer)ADD1(ctx,1,local+16); /*1+*/
	local[10] = w;
	local[16]= local[10];
	local[17]= local[11];
	ctx->vsp=local+18;
	w=(pointer)GREQP(ctx,2,local+16); /*>=*/
	if (w!=NIL) goto irtmathOR235;
	local[16]= local[6];
	local[17]= local[5];
	ctx->vsp=local+18;
	w=(pointer)VDISTANCE(ctx,2,local+16); /*distance*/
	local[16]= w;
	local[17]= makeint((eusinteger_t)0L);
	ctx->vsp=local+18;
	w=(*ftab[11])(ctx,2,local+16,&ftab[11],fqv[14]); /*eps=*/
	if (w!=NIL) goto irtmathOR235;
	goto irtmathIF233;
irtmathOR235:
	w = NIL;
	ctx->vsp=local+16;
	local[16]=w;
	goto irtmathBLK231;
	goto irtmathIF234;
irtmathIF233:
	local[16]= NIL;
irtmathIF234:
	local[16]= local[10];
	local[17]= local[11];
	local[18]= makeint((eusinteger_t)2L);
	ctx->vsp=local+19;
	w=(pointer)QUOTIENT(ctx,2,local+17); /*/*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)GREATERP(ctx,2,local+16); /*>*/
	if (w==NIL) goto irtmathIF236;
	local[16]= makeflt(1.0000000000000000000000e+00);
	local[17]= local[7];
	local[18]= loadglobal(fqv[4]);
	ctx->vsp=local+19;
	w=(pointer)COERCE(ctx,2,local+17); /*coerce*/
	local[17]= w;
	local[18]= local[3];
	local[19]= local[7];
	local[20]= local[5];
	ctx->vsp=local+21;
	w=(pointer)LU_SOLVE(ctx,3,local+18); /*lu-solve*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)VINNERPRODUCT(ctx,2,local+17); /*v.*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)QUOTIENT(ctx,2,local+16); /*/*/
	local[13] = w;
	local[16]= local[0];
	local[17]= local[14];
	local[18]= local[0];
	local[19]= local[14];
	ctx->vsp=local+20;
	w=(pointer)ELT(ctx,2,local+18); /*elt*/
	local[18]= w;
	local[19]= local[13];
	ctx->vsp=local+20;
	w=(pointer)PLUS(ctx,2,local+18); /*+*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)SETELT(ctx,3,local+16); /*setelt*/
	local[16]= argv[0];
	local[17]= local[0];
	local[18]= local[14];
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)MINUS(ctx,1,local+17); /*-*/
	local[17]= w;
	local[18]= local[1];
	ctx->vsp=local+19;
	w=(*ftab[1])(ctx,1,local+18,&ftab[1],fqv[1]); /*unit-matrix*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[7])(ctx,2,local+17,&ftab[7],fqv[9]); /*scale-matrix*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(*ftab[10])(ctx,2,local+16,&ftab[10],fqv[13]); /*m+*/
	local[3] = w;
	local[16]= local[3];
	ctx->vsp=local+17;
	w=(pointer)LU_DECOMPOSE(ctx,1,local+16); /*lu-decompose*/
	local[7] = w;
	if (local[7]!=NIL) goto irtmathIF238;
	w = NIL;
	ctx->vsp=local+16;
	local[16]=w;
	goto irtmathBLK231;
	goto irtmathIF239;
irtmathIF238:
	local[16]= NIL;
irtmathIF239:
	goto irtmathIF237;
irtmathIF236:
	local[16]= NIL;
irtmathIF237:
	local[6] = local[5];
	ctx->vsp=local+16;
	goto irtmathTAG232;
	local[16]= NIL;
irtmathBLK231:
	local[16]= local[10];
	local[17]= local[11];
	ctx->vsp=local+18;
	w=(pointer)GREQP(ctx,2,local+16); /*>=*/
	if (w==NIL) goto irtmathIF240;
	local[7] = NIL;
	local[16]= local[7];
	goto irtmathIF241;
irtmathIF240:
	local[16]= NIL;
irtmathIF241:
	goto irtmathIF224;
irtmathIF223:
	local[16]= NIL;
irtmathIF224:
	if (local[7]!=NIL) goto irtmathIF242;
	local[16]= local[4];
	ctx->vsp=local+17;
	w=(*ftab[14])(ctx,1,local+16,&ftab[14],fqv[19]); /*sv-decompose*/
	local[8] = w;
	local[16]= local[8];
	local[17]= makeint((eusinteger_t)1L);
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[9] = w;
	local[16]= makeint((eusinteger_t)0L);
	local[17]= local[9];
	ctx->vsp=local+18;
	w=(pointer)LENGTH(ctx,1,local+17); /*length*/
	local[17]= w;
irtmathWHL244:
	local[18]= local[16];
	w = local[17];
	if ((eusinteger_t)local[18] >= (eusinteger_t)w) goto irtmathWHX245;
	local[18]= local[9];
	local[19]= local[16];
	ctx->vsp=local+20;
	w=(pointer)ELT(ctx,2,local+18); /*elt*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)ABS(ctx,1,local+18); /*abs*/
	local[18]= w;
	local[19]= makeflt(9.9999999999999991239646e-05);
	ctx->vsp=local+20;
	w=(pointer)LESSP(ctx,2,local+18); /*<*/
	if (w==NIL) goto irtmathIF247;
	local[18]= local[8];
	local[19]= makeint((eusinteger_t)2L);
	ctx->vsp=local+20;
	w=(pointer)ELT(ctx,2,local+18); /*elt*/
	local[18]= w;
	local[19]= local[16];
	ctx->vsp=local+20;
	w=(*ftab[19])(ctx,2,local+18,&ftab[19],fqv[27]); /*matrix-column*/
	local[5] = w;
	local[18]= local[5];
	goto irtmathIF248;
irtmathIF247:
	local[18]= NIL;
irtmathIF248:
	local[18]= local[16];
	ctx->vsp=local+19;
	w=(pointer)ADD1(ctx,1,local+18); /*1+*/
	local[16] = w;
	goto irtmathWHL244;
irtmathWHX245:
	local[18]= NIL;
irtmathBLK246:
	w = NIL;
	local[16]= w;
	goto irtmathIF243;
irtmathIF242:
	local[16]= NIL;
irtmathIF243:
	local[16]= local[2];
	local[17]= local[14];
	local[18]= local[5];
	ctx->vsp=local+19;
	w=(*ftab[20])(ctx,3,local+16,&ftab[20],fqv[28]); /*set-matrix-column*/
	local[16]= local[14];
	ctx->vsp=local+17;
	w=(pointer)ADD1(ctx,1,local+16); /*1+*/
	local[14] = w;
	goto irtmathWHL220;
irtmathWHX221:
	local[16]= NIL;
irtmathBLK222:
	w = NIL;
	local[14]= local[0];
	local[15]= local[2];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,2,local+14); /*list*/
	local[0]= w;
irtmathBLK219:
	ctx->vsp=local; return(local[0]);}

/*eigen-decompose-complex*/
static pointer irtmathF21eigen_decompose_complex(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[17])(ctx,1,local+0,&ftab[17],fqv[24]); /*qr-decompose*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,1,local+1,&ftab[17],fqv[24]); /*qr-decompose*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(*ftab[16])(ctx,1,local+3,&ftab[16],fqv[23]); /*make-list*/
	local[3]= w;
	local[4]= local[2];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(*ftab[3])(ctx,2,local+4,&ftab[3],fqv[3]); /*make-matrix*/
	local[4]= w;
	local[5]= local[2];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(*ftab[3])(ctx,2,local+5,&ftab[3],fqv[3]); /*make-matrix*/
	local[5]= w;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= NIL;
	local[10]= NIL;
	local[11]= NIL;
	local[12]= NIL;
	local[13]= NIL;
	local[14]= NIL;
	local[15]= NIL;
	local[16]= NIL;
	local[17]= makeint((eusinteger_t)0L);
	local[18]= local[2];
irtmathWHL250:
	local[19]= local[17];
	w = local[18];
	if ((eusinteger_t)local[19] >= (eusinteger_t)w) goto irtmathWHX251;
	local[19]= local[3];
	local[20]= local[17];
	local[21]= local[0];
	local[22]= local[17];
	ctx->vsp=local+23;
	w=(pointer)ELT(ctx,2,local+21); /*elt*/
	local[21]= w;
	local[22]= local[1];
	local[23]= local[17];
	ctx->vsp=local+24;
	w=(pointer)ELT(ctx,2,local+22); /*elt*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)MKFLTVEC(ctx,2,local+21); /*float-vector*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)SETELT(ctx,3,local+19); /*setelt*/
	local[19]= local[17];
	ctx->vsp=local+20;
	w=(pointer)ADD1(ctx,1,local+19); /*1+*/
	local[17] = w;
	goto irtmathWHL250;
irtmathWHX251:
	local[19]= NIL;
irtmathBLK252:
	w = NIL;
	local[17]= local[3];
	ctx->vsp=local+18;
	local[18]= makeclosure(codevec,quotevec,irtmathCLO253,env,argv,local);
	ctx->vsp=local+19;
	w=(pointer)SORT(ctx,2,local+17); /*sort*/
	local[17]= makeint((eusinteger_t)0L);
	local[18]= local[2];
irtmathWHL254:
	local[19]= local[17];
	w = local[18];
	if ((eusinteger_t)local[19] >= (eusinteger_t)w) goto irtmathWHX255;
	local[19]= local[3];
	local[20]= local[17];
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[6] = w;
	local[19]= local[6];
	local[20]= makeint((eusinteger_t)0L);
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[7] = w;
	local[19]= local[6];
	local[20]= makeint((eusinteger_t)1L);
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[8] = w;
	local[19]= local[0];
	local[20]= local[17];
	local[21]= local[7];
	ctx->vsp=local+22;
	w=(pointer)SETELT(ctx,3,local+19); /*setelt*/
	local[19]= local[1];
	local[20]= local[17];
	local[21]= local[8];
	ctx->vsp=local+22;
	w=(pointer)SETELT(ctx,3,local+19); /*setelt*/
	local[19]= argv[0];
	local[20]= local[7];
	ctx->vsp=local+21;
	w=(pointer)MINUS(ctx,1,local+20); /*-*/
	local[20]= w;
	local[21]= local[2];
	ctx->vsp=local+22;
	w=(*ftab[1])(ctx,1,local+21,&ftab[1],fqv[1]); /*unit-matrix*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(*ftab[7])(ctx,2,local+20,&ftab[7],fqv[9]); /*scale-matrix*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(*ftab[10])(ctx,2,local+19,&ftab[10],fqv[13]); /*m+*/
	local[9] = w;
	local[19]= local[8];
	local[20]= local[2];
	ctx->vsp=local+21;
	w=(*ftab[1])(ctx,1,local+20,&ftab[1],fqv[1]); /*unit-matrix*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(*ftab[7])(ctx,2,local+19,&ftab[7],fqv[9]); /*scale-matrix*/
	local[10] = w;
	local[19]= local[8];
	ctx->vsp=local+20;
	w=(pointer)MINUS(ctx,1,local+19); /*-*/
	local[19]= w;
	local[20]= local[2];
	ctx->vsp=local+21;
	w=(*ftab[1])(ctx,1,local+20,&ftab[1],fqv[1]); /*unit-matrix*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(*ftab[7])(ctx,2,local+19,&ftab[7],fqv[9]); /*scale-matrix*/
	local[11] = w;
	local[19]= argv[0];
	local[20]= local[7];
	ctx->vsp=local+21;
	w=(pointer)MINUS(ctx,1,local+20); /*-*/
	local[20]= w;
	local[21]= local[2];
	ctx->vsp=local+22;
	w=(*ftab[1])(ctx,1,local+21,&ftab[1],fqv[1]); /*unit-matrix*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(*ftab[7])(ctx,2,local+20,&ftab[7],fqv[9]); /*scale-matrix*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(*ftab[10])(ctx,2,local+19,&ftab[10],fqv[13]); /*m+*/
	local[12] = w;
	local[19]= local[9];
	local[20]= local[10];
	ctx->vsp=local+21;
	w=(pointer)irtmathF30concatenate_matrix_row(ctx,2,local+19); /*concatenate-matrix-row*/
	local[19]= w;
	local[20]= local[11];
	local[21]= local[12];
	ctx->vsp=local+22;
	w=(pointer)irtmathF30concatenate_matrix_row(ctx,2,local+20); /*concatenate-matrix-row*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)irtmathF29concatenate_matrix_column(ctx,2,local+19); /*concatenate-matrix-column*/
	local[13] = w;
	local[19]= local[13];
	ctx->vsp=local+20;
	w=(pointer)irtmathF22solve_non_zero_vector_from_det0_matrix(ctx,1,local+19); /*solve-non-zero-vector-from-det0-matrix*/
	local[14] = w;
	local[19]= local[2];
	ctx->vsp=local+20;
	w=(*ftab[1])(ctx,1,local+19,&ftab[1],fqv[1]); /*unit-matrix*/
	local[19]= w;
	local[20]= local[2];
	local[21]= local[2];
	ctx->vsp=local+22;
	w=(*ftab[3])(ctx,2,local+20,&ftab[3],fqv[3]); /*make-matrix*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)irtmathF30concatenate_matrix_row(ctx,2,local+19); /*concatenate-matrix-row*/
	local[19]= w;
	local[20]= local[14];
	ctx->vsp=local+21;
	w=(pointer)TRANSFORM(ctx,2,local+19); /*transform*/
	local[15] = w;
	local[19]= local[2];
	local[20]= local[2];
	ctx->vsp=local+21;
	w=(*ftab[3])(ctx,2,local+19,&ftab[3],fqv[3]); /*make-matrix*/
	local[19]= w;
	local[20]= local[2];
	ctx->vsp=local+21;
	w=(*ftab[1])(ctx,1,local+20,&ftab[1],fqv[1]); /*unit-matrix*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)irtmathF30concatenate_matrix_row(ctx,2,local+19); /*concatenate-matrix-row*/
	local[19]= w;
	local[20]= local[14];
	ctx->vsp=local+21;
	w=(pointer)TRANSFORM(ctx,2,local+19); /*transform*/
	local[16] = w;
	local[19]= local[4];
	local[20]= local[17];
	local[21]= local[15];
	ctx->vsp=local+22;
	w=(*ftab[20])(ctx,3,local+19,&ftab[20],fqv[28]); /*set-matrix-column*/
	local[19]= local[5];
	local[20]= local[17];
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(*ftab[20])(ctx,3,local+19,&ftab[20],fqv[28]); /*set-matrix-column*/
	local[19]= local[17];
	ctx->vsp=local+20;
	w=(pointer)ADD1(ctx,1,local+19); /*1+*/
	local[17] = w;
	goto irtmathWHL254;
irtmathWHX255:
	local[19]= NIL;
irtmathBLK256:
	w = NIL;
	local[17]= local[0];
	local[18]= local[1];
	ctx->vsp=local+19;
	w=(pointer)LIST(ctx,2,local+17); /*list*/
	local[17]= w;
	local[18]= local[4];
	local[19]= local[5];
	ctx->vsp=local+20;
	w=(pointer)LIST(ctx,2,local+18); /*list*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)LIST(ctx,2,local+17); /*list*/
	local[0]= w;
irtmathBLK249:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmathCLO253(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	local[1]= argv[1];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*solve-non-zero-vector-from-det0-matrix*/
static pointer irtmathF22solve_non_zero_vector_from_det0_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[8])(ctx,1,local+0,&ftab[8],fqv[10]); /*matrix-determinant*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(*ftab[11])(ctx,2,local+0,&ftab[11],fqv[14]); /*eps=*/
	if (w!=NIL) goto irtmathIF258;
	local[0]= fqv[29];
	ctx->vsp=local+1;
	w=(*ftab[4])(ctx,1,local+0,&ftab[4],fqv[6]); /*warn*/
	w = NIL;
	ctx->vsp=local+0;
	local[0]=w;
	goto irtmathBLK257;
	goto irtmathIF259;
irtmathIF258:
	local[0]= NIL;
irtmathIF259:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[6])(ctx,1,local+0,&ftab[6],fqv[8]); /*array-dimensions*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= makeint((eusinteger_t)10L);
	local[1] = argv[0];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(*ftab[18])(ctx,1,local+10,&ftab[18],fqv[26]); /*copy-matrix*/
	local[2] = w;
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)LU_DECOMPOSE(ctx,1,local+10); /*lu-decompose*/
	local[5] = w;
	if (local[5]==NIL) goto irtmathIF260;
	local[10]= loadglobal(fqv[4]);
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(pointer)INSTANTIATE(ctx,2,local+10); /*instantiate*/
	local[3] = w;
irtmathWHL262:
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)VNORM(ctx,1,local+10); /*norm*/
	local[10]= w;
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(*ftab[11])(ctx,2,local+10,&ftab[11],fqv[14]); /*eps=*/
	if (w==NIL) goto irtmathWHX263;
	local[10]= makeint((eusinteger_t)0L);
	local[11]= local[0];
irtmathWHL265:
	local[12]= local[10];
	w = local[11];
	if ((eusinteger_t)local[12] >= (eusinteger_t)w) goto irtmathWHX266;
	local[12]= local[3];
	local[13]= local[10];
	local[14]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+15;
	w=(pointer)RANDOM(ctx,1,local+14); /*random*/
	local[14]= w;
	local[15]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+16;
	w=(pointer)MINUS(ctx,2,local+14); /*-*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SETELT(ctx,3,local+12); /*setelt*/
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)ADD1(ctx,1,local+12); /*1+*/
	local[10] = w;
	goto irtmathWHL265;
irtmathWHX266:
	local[12]= NIL;
irtmathBLK267:
	w = NIL;
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)irtmathF34normalize_vector(ctx,1,local+10); /*normalize-vector*/
	local[3] = w;
	goto irtmathWHL262;
irtmathWHX263:
	local[10]= NIL;
irtmathBLK264:
	local[4] = local[3];
	local[8] = makeint((eusinteger_t)0L);
irtmathTAG269:
	local[10]= local[1];
	local[11]= local[5];
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)LU_SOLVE(ctx,3,local+10); /*lu-solve*/
	local[3] = w;
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)irtmathF34normalize_vector(ctx,1,local+10); /*normalize-vector*/
	local[3] = w;
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	local[10]= local[8];
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)GREQP(ctx,2,local+10); /*>=*/
	if (w!=NIL) goto irtmathOR272;
	local[10]= local[4];
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)VDISTANCE(ctx,2,local+10); /*distance*/
	local[10]= w;
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(*ftab[11])(ctx,2,local+10,&ftab[11],fqv[14]); /*eps=*/
	if (w!=NIL) goto irtmathOR272;
	goto irtmathIF270;
irtmathOR272:
	w = NIL;
	ctx->vsp=local+10;
	local[10]=w;
	goto irtmathBLK268;
	goto irtmathIF271;
irtmathIF270:
	local[10]= NIL;
irtmathIF271:
	local[10]= local[8];
	local[11]= local[9];
	local[12]= makeint((eusinteger_t)2L);
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)GREATERP(ctx,2,local+10); /*>*/
	if (w==NIL) goto irtmathIF273;
	local[1] = argv[0];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)LU_DECOMPOSE(ctx,1,local+10); /*lu-decompose*/
	local[5] = w;
	if (local[5]!=NIL) goto irtmathIF275;
	w = NIL;
	ctx->vsp=local+10;
	local[10]=w;
	goto irtmathBLK268;
	goto irtmathIF276;
irtmathIF275:
	local[10]= NIL;
irtmathIF276:
	goto irtmathIF274;
irtmathIF273:
	local[10]= NIL;
irtmathIF274:
	local[4] = local[3];
	ctx->vsp=local+10;
	goto irtmathTAG269;
	local[10]= NIL;
irtmathBLK268:
	local[10]= local[8];
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)GREQP(ctx,2,local+10); /*>=*/
	if (w==NIL) goto irtmathIF277;
	local[5] = NIL;
	local[10]= local[5];
	goto irtmathIF278;
irtmathIF277:
	local[10]= NIL;
irtmathIF278:
	goto irtmathIF261;
irtmathIF260:
	local[10]= NIL;
irtmathIF261:
	if (local[5]!=NIL) goto irtmathIF279;
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(*ftab[14])(ctx,1,local+10,&ftab[14],fqv[19]); /*sv-decompose*/
	local[6] = w;
	local[10]= local[6];
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[7] = w;
	local[10]= makeint((eusinteger_t)0L);
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
irtmathWHL281:
	local[12]= local[10];
	w = local[11];
	if ((eusinteger_t)local[12] >= (eusinteger_t)w) goto irtmathWHX282;
	local[12]= local[7];
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)ABS(ctx,1,local+12); /*abs*/
	local[12]= w;
	local[13]= makeflt(9.9999999999999991239646e-05);
	ctx->vsp=local+14;
	w=(pointer)LESSP(ctx,2,local+12); /*<*/
	if (w==NIL) goto irtmathIF284;
	local[12]= local[6];
	local[13]= makeint((eusinteger_t)2L);
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(*ftab[19])(ctx,2,local+12,&ftab[19],fqv[27]); /*matrix-column*/
	local[3] = w;
	local[12]= local[3];
	goto irtmathIF285;
irtmathIF284:
	local[12]= NIL;
irtmathIF285:
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)ADD1(ctx,1,local+12); /*1+*/
	local[10] = w;
	goto irtmathWHL281;
irtmathWHX282:
	local[12]= NIL;
irtmathBLK283:
	w = NIL;
	local[10]= w;
	goto irtmathIF280;
irtmathIF279:
	local[10]= NIL;
irtmathIF280:
	w = local[3];
	local[0]= w;
irtmathBLK257:
	ctx->vsp=local; return(local[0]);}

/*lms*/
static pointer irtmathF23lms(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[21])(ctx,1,local+0,&ftab[21],fqv[30]); /*vector-mean*/
	local[0]= w;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= NIL;
	local[10]= local[1];
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[3])(ctx,2,local+10,&ftab[3],fqv[3]); /*make-matrix*/
	local[3] = w;
	local[10]= makeint((eusinteger_t)0L);
	local[11]= local[1];
irtmathWHL287:
	local[12]= local[10];
	w = local[11];
	if ((eusinteger_t)local[12] >= (eusinteger_t)w) goto irtmathWHX288;
	local[12]= local[3];
	local[13]= local[10];
	local[14]= argv[0];
	local[15]= local[10];
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[14]= w;
	local[15]= local[0];
	ctx->vsp=local+16;
	w=(pointer)VMINUS(ctx,2,local+14); /*v-*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(*ftab[22])(ctx,3,local+12,&ftab[22],fqv[31]); /*set-matrix-row*/
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)ADD1(ctx,1,local+12); /*1+*/
	local[10] = w;
	goto irtmathWHL287;
irtmathWHX288:
	local[12]= NIL;
irtmathBLK289:
	w = NIL;
	local[10]= makeflt(1.0000000000000000000000e+00);
	local[11]= local[1];
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(pointer)MINUS(ctx,2,local+11); /*-*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)QUOTIENT(ctx,2,local+10); /*/*/
	local[10]= w;
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)TRANSPOSE(ctx,1,local+11); /*transpose*/
	local[11]= w;
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)MATTIMES(ctx,2,local+11); /*m**/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[7])(ctx,2,local+10,&ftab[7],fqv[9]); /*scale-matrix*/
	local[4] = w;
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)irtmathF20eigen_decompose(ctx,1,local+10); /*eigen-decompose*/
	local[5] = w;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.car;
	local[10]= local[6];
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[8] = w;
	local[10]= local[7];
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(*ftab[19])(ctx,2,local+10,&ftab[19],fqv[27]); /*matrix-column*/
	local[9] = w;
	local[10]= makeint((eusinteger_t)0L);
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
irtmathWHL290:
	local[12]= local[10];
	w = local[11];
	if ((eusinteger_t)local[12] >= (eusinteger_t)w) goto irtmathWHX291;
	local[12]= local[8];
	local[13]= local[6];
	local[14]= local[10];
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)GREATERP(ctx,2,local+12); /*>*/
	if (w==NIL) goto irtmathIF293;
	local[12]= local[6];
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[8] = w;
	local[12]= local[7];
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(*ftab[19])(ctx,2,local+12,&ftab[19],fqv[27]); /*matrix-column*/
	local[9] = w;
	local[12]= local[9];
	goto irtmathIF294;
irtmathIF293:
	local[12]= NIL;
irtmathIF294:
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)ADD1(ctx,1,local+12); /*1+*/
	local[10] = w;
	goto irtmathWHL290;
irtmathWHX291:
	local[12]= NIL;
irtmathBLK292:
	w = NIL;
	local[10]= local[9];
	local[11]= local[0];
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)VINNERPRODUCT(ctx,2,local+11); /*v.*/
	local[11]= makeflt(-(fltval(w)));
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,2,local+10); /*list*/
	local[0]= w;
irtmathBLK286:
	ctx->vsp=local; return(local[0]);}

/*lms-estimate*/
static pointer irtmathF24lms_estimate(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)VINNERPRODUCT(ctx,2,local+0); /*v.*/
	local[0]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	local[0]= w;
irtmathBLK295:
	ctx->vsp=local; return(local[0]);}

/*lms-error*/
static pointer irtmathF25lms_error(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[1];
irtmathWHL297:
	if (local[3]==NIL) goto irtmathWHX298;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= argv[0];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)irtmathF24lms_estimate(ctx,2,local+4); /*lms-estimate*/
	local[1] = w;
	local[4]= local[0];
	local[5]= local[1];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[0] = w;
	goto irtmathWHL297;
irtmathWHX298:
	local[4]= NIL;
irtmathBLK299:
	w = NIL;
	local[2]= local[0];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[0]= w;
irtmathBLK296:
	ctx->vsp=local; return(local[0]);}

/*lmeds*/
static pointer irtmathF26lmeds(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[32], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto irtmathKEY301;
	local[0] = makeint((eusinteger_t)5L);
irtmathKEY301:
	if (n & (1<<1)) goto irtmathKEY302;
	local[1] = makeflt(2.9999999999999982236432e-01);
irtmathKEY302:
	if (n & (1<<2)) goto irtmathKEY303;
	local[2] = NIL;
irtmathKEY303:
	if (n & (1<<3)) goto irtmathKEY304;
	local[3] = NIL;
irtmathKEY304:
	if (n & (1<<4)) goto irtmathKEY305;
	local[4] = (pointer)get_sym_func(fqv[33]);
irtmathKEY305:
	if (n & (1<<5)) goto irtmathKEY306;
	local[5] = (pointer)get_sym_func(fqv[34]);
irtmathKEY306:
	if (n & (1<<6)) goto irtmathKEY307;
	local[6] = (pointer)get_sym_func(fqv[35]);
irtmathKEY307:
	local[7]= NIL;
	local[8]= NIL;
	local[9]= NIL;
	local[10]= NIL;
	local[11]= NIL;
	local[12]= NIL;
	local[13]= NIL;
	local[14]= NIL;
	local[15]= NIL;
	local[16]= argv[0];
	ctx->vsp=local+17;
	w=(pointer)LENGTH(ctx,1,local+16); /*length*/
	local[7] = w;
	local[16]= makeint((eusinteger_t)2L);
	local[17]= local[0];
	ctx->vsp=local+18;
	w=(pointer)MAX(ctx,2,local+16); /*max*/
	local[16]= w;
	local[17]= local[7];
	ctx->vsp=local+18;
	w=(pointer)MIN(ctx,2,local+16); /*min*/
	local[0] = w;
	local[10] = NIL;
	local[11] = NIL;
	local[15] = NIL;
	if (local[2]==NIL) goto irtmathIF308;
	local[12] = local[2];
	local[16]= local[12];
	goto irtmathIF309;
irtmathIF308:
	local[16]= makeflt(9.9999999999999950039964e-03);
	ctx->vsp=local+17;
	w=(pointer)LOG(ctx,1,local+16); /*log*/
	local[16]= w;
	local[17]= makeint((eusinteger_t)1L);
	local[18]= makeint((eusinteger_t)1L);
	local[19]= local[1];
	ctx->vsp=local+20;
	w=(pointer)MINUS(ctx,2,local+18); /*-*/
	local[18]= w;
	local[19]= local[0];
	ctx->vsp=local+20;
	w=(*ftab[23])(ctx,2,local+18,&ftab[23],fqv[36]); /*expt*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)MINUS(ctx,2,local+17); /*-*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)LOG(ctx,1,local+17); /*log*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)QUOTIENT(ctx,2,local+16); /*/*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)CEILING(ctx,1,local+16); /*ceiling*/
	local[12] = w;
	local[16]= local[12];
irtmathIF309:
	local[16]= makeint((eusinteger_t)0L);
	local[17]= local[12];
irtmathWHL310:
	local[18]= local[16];
	w = local[17];
	if ((eusinteger_t)local[18] >= (eusinteger_t)w) goto irtmathWHX311;
	local[13] = NIL;
	local[18]= makeint((eusinteger_t)0L);
	local[19]= local[0];
irtmathWHL313:
	local[20]= local[18];
	w = local[19];
	if ((eusinteger_t)local[20] >= (eusinteger_t)w) goto irtmathWHX314;
	local[20]= local[7];
	ctx->vsp=local+21;
	w=(pointer)RANDOM(ctx,1,local+20); /*random*/
	local[8] = w;
irtmathWHL316:
	local[20]= local[8];
	local[21]= local[13];
	ctx->vsp=local+22;
	w=(*ftab[24])(ctx,2,local+20,&ftab[24],fqv[37]); /*find*/
	if (w==NIL) goto irtmathWHX317;
	local[20]= local[7];
	ctx->vsp=local+21;
	w=(pointer)RANDOM(ctx,1,local+20); /*random*/
	local[8] = w;
	goto irtmathWHL316;
irtmathWHX317:
	local[20]= NIL;
irtmathBLK318:
	local[20]= local[8];
	w = local[13];
	ctx->vsp=local+21;
	local[13] = cons(ctx,local[20],w);
	local[20]= local[18];
	ctx->vsp=local+21;
	w=(pointer)ADD1(ctx,1,local+20); /*1+*/
	local[18] = w;
	goto irtmathWHL313;
irtmathWHX314:
	local[20]= NIL;
irtmathBLK315:
	w = NIL;
	local[18]= local[13];
	w = local[14];
	ctx->vsp=local+19;
	local[14] = cons(ctx,local[18],w);
	local[18]= local[16];
	ctx->vsp=local+19;
	w=(pointer)ADD1(ctx,1,local+18); /*1+*/
	local[16] = w;
	goto irtmathWHL310;
irtmathWHX311:
	local[18]= NIL;
irtmathBLK312:
	w = NIL;
	local[16]= NIL;
	local[17]= local[14];
irtmathWHL319:
	if (local[17]==NIL) goto irtmathWHX320;
	w=local[17];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.car;
	w=local[17];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17] = (w)->c.cons.cdr;
	w = local[18];
	local[16] = w;
	local[15] = NIL;
	local[18]= NIL;
	local[19]= local[16];
irtmathWHL322:
	if (local[19]==NIL) goto irtmathWHX323;
	w=local[19];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.car;
	w=local[19];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19] = (w)->c.cons.cdr;
	w = local[20];
	local[18] = w;
	local[20]= argv[0];
	local[21]= local[18];
	ctx->vsp=local+22;
	w=(pointer)ELT(ctx,2,local+20); /*elt*/
	local[20]= w;
	w = local[15];
	ctx->vsp=local+21;
	local[15] = cons(ctx,local[20],w);
	goto irtmathWHL322;
irtmathWHX323:
	local[20]= NIL;
irtmathBLK324:
	w = NIL;
	local[18]= local[4];
	local[19]= local[15];
	ctx->vsp=local+20;
	w=(pointer)FUNCALL(ctx,2,local+18); /*funcall*/
	local[9] = w;
	local[18]= local[9];
	w = local[10];
	ctx->vsp=local+19;
	local[10] = cons(ctx,local[18],w);
	if (local[3]==NIL) goto irtmathIF325;
	local[18]= local[5];
	local[19]= local[9];
	local[20]= argv[0];
	local[21]= local[3];
	local[22]= fqv[38];
	local[23]= local[6];
	ctx->vsp=local+24;
	w=(pointer)FUNCALL(ctx,6,local+18); /*funcall*/
	local[18]= w;
	w = local[11];
	ctx->vsp=local+19;
	local[11] = cons(ctx,local[18],w);
	local[18]= local[11];
	goto irtmathIF326;
irtmathIF325:
	local[18]= local[5];
	local[19]= local[9];
	local[20]= argv[0];
	local[21]= fqv[38];
	local[22]= local[6];
	ctx->vsp=local+23;
	w=(pointer)FUNCALL(ctx,5,local+18); /*funcall*/
	local[18]= w;
	w = local[11];
	ctx->vsp=local+19;
	local[11] = cons(ctx,local[18],w);
	local[18]= local[11];
irtmathIF326:
	goto irtmathWHL319;
irtmathWHX320:
	local[18]= NIL;
irtmathBLK321:
	w = NIL;
	local[16]= local[10];
	local[17]= local[11];
	ctx->vsp=local+18;
	local[18]= makeclosure(codevec,quotevec,irtmathCLO327,env,argv,local);
	if (local[3]==NIL) goto irtmathIF328;
	local[19]= (pointer)get_sym_func(fqv[39]);
	goto irtmathIF329;
irtmathIF328:
	local[19]= (pointer)get_sym_func(fqv[40]);
irtmathIF329:
	ctx->vsp=local+20;
	w=(*ftab[25])(ctx,3,local+17,&ftab[25],fqv[41]); /*find-extream*/
	local[17]= w;
	local[18]= local[11];
	ctx->vsp=local+19;
	w=(*ftab[26])(ctx,2,local+17,&ftab[26],fqv[42]); /*position*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[0]= w;
irtmathBLK300:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmathCLO327(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*lmeds-error*/
static pointer irtmathF27lmeds_error(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[43], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtmathKEY331;
	local[0] = (pointer)get_sym_func(fqv[35]);
irtmathKEY331:
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= argv[1];
irtmathWHL332:
	if (local[4]==NIL) goto irtmathWHX333;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[0];
	local[6]= argv[0];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)FUNCALL(ctx,3,local+5); /*funcall*/
	local[1] = w;
	local[5]= local[1];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	w = local[2];
	ctx->vsp=local+6;
	local[2] = cons(ctx,local[5],w);
	goto irtmathWHL332;
irtmathWHX333:
	local[5]= NIL;
irtmathBLK334:
	w = NIL;
	local[3]= local[2];
	local[4]= (pointer)get_sym_func(fqv[40]);
	ctx->vsp=local+5;
	w=(pointer)SORT(ctx,2,local+3); /*sort*/
	local[3]= w;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[0]= w;
irtmathBLK330:
	ctx->vsp=local; return(local[0]);}

/*lmeds-error-mat*/
static pointer irtmathF28lmeds_error_mat(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[44], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtmathKEY336;
	local[0] = (pointer)get_sym_func(fqv[35]);
irtmathKEY336:
	local[1]= argv[1];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,2,local+1,&ftab[0],fqv[0]); /*array-dimension*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[2]= w;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[1];
irtmathWHL337:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto irtmathWHX338;
	local[7]= argv[1];
	local[8]= local[5];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(*ftab[27])(ctx,3,local+7,&ftab[27],fqv[45]); /*c-matrix-row*/
	local[7]= local[0];
	local[8]= argv[0];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)FUNCALL(ctx,3,local+7); /*funcall*/
	local[3] = w;
	local[7]= local[3];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	w = local[4];
	ctx->vsp=local+8;
	local[4] = cons(ctx,local[7],w);
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto irtmathWHL337;
irtmathWHX338:
	local[7]= NIL;
irtmathBLK339:
	w = NIL;
	local[5]= local[4];
	local[6]= (pointer)get_sym_func(fqv[40]);
	ctx->vsp=local+7;
	w=(pointer)SORT(ctx,2,local+5); /*sort*/
	local[5]= w;
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[0]= w;
irtmathBLK335:
	ctx->vsp=local; return(local[0]);}

/*concatenate-matrix-column*/
static pointer irtmathF29concatenate_matrix_column(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
irtmathRST341:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= NIL;
	local[2]= NIL;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(*ftab[0])(ctx,2,local+3,&ftab[0],fqv[0]); /*array-dimension*/
	local[3]= w;
	local[4]= NIL;
	local[5]= local[0];
irtmathWHL342:
	if (local[5]==NIL) goto irtmathWHX343;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= local[4];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(*ftab[0])(ctx,2,local+6,&ftab[0],fqv[0]); /*array-dimension*/
	local[6]= w;
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)NUMEQUAL(ctx,2,local+6); /*=*/
	if (w!=NIL) goto irtmathIF345;
	local[6]= fqv[46];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtmathCLO347,env,argv,local);
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)MAPCAR(ctx,2,local+7); /*mapcar*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SIGERROR(ctx,2,local+6); /*error*/
	local[6]= w;
	goto irtmathIF346;
irtmathIF345:
	local[6]= NIL;
irtmathIF346:
	if (local[4]==NIL) goto irtmathIF348;
	local[6]= local[4];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(*ftab[19])(ctx,2,local+6,&ftab[19],fqv[27]); /*matrix-column*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
	goto irtmathIF349;
irtmathIF348:
	local[6]= makeint((eusinteger_t)0L);
irtmathIF349:
	local[1] = local[6];
	local[6]= makeint((eusinteger_t)0L);
	local[7]= local[1];
irtmathWHL350:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto irtmathWHX351;
	local[8]= local[4];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(*ftab[28])(ctx,2,local+8,&ftab[28],fqv[47]); /*matrix-row*/
	local[8]= w;
	w = local[2];
	ctx->vsp=local+9;
	local[2] = cons(ctx,local[8],w);
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto irtmathWHL350;
irtmathWHX351:
	local[8]= NIL;
irtmathBLK352:
	w = NIL;
	goto irtmathWHL342;
irtmathWHX343:
	local[6]= NIL;
irtmathBLK344:
	w = NIL;
	if (local[2]==NIL) goto irtmathIF353;
	local[4]= (pointer)get_sym_func(fqv[48]);
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)REVERSE(ctx,1,local+5); /*reverse*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,2,local+4); /*apply*/
	local[4]= w;
	goto irtmathIF354;
irtmathIF353:
	local[4]= NIL;
irtmathIF354:
	w = local[4];
	local[0]= w;
irtmathBLK340:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmathCLO347(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(*ftab[0])(ctx,2,local+0,&ftab[0],fqv[0]); /*array-dimension*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*concatenate-matrix-row*/
static pointer irtmathF30concatenate_matrix_row(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
irtmathRST356:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= NIL;
	local[2]= NIL;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(*ftab[0])(ctx,2,local+3,&ftab[0],fqv[0]); /*array-dimension*/
	local[3]= w;
	local[4]= NIL;
	local[5]= local[0];
irtmathWHL357:
	if (local[5]==NIL) goto irtmathWHX358;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= local[4];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(*ftab[0])(ctx,2,local+6,&ftab[0],fqv[0]); /*array-dimension*/
	local[6]= w;
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)NUMEQUAL(ctx,2,local+6); /*=*/
	if (w!=NIL) goto irtmathIF360;
	local[6]= fqv[49];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtmathCLO362,env,argv,local);
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)MAPCAR(ctx,2,local+7); /*mapcar*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SIGERROR(ctx,2,local+6); /*error*/
	local[6]= w;
	goto irtmathIF361;
irtmathIF360:
	local[6]= NIL;
irtmathIF361:
	if (local[4]==NIL) goto irtmathIF363;
	local[6]= local[4];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(*ftab[28])(ctx,2,local+6,&ftab[28],fqv[47]); /*matrix-row*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
	goto irtmathIF364;
irtmathIF363:
	local[6]= makeint((eusinteger_t)0L);
irtmathIF364:
	local[1] = local[6];
	local[6]= makeint((eusinteger_t)0L);
	local[7]= local[1];
irtmathWHL365:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto irtmathWHX366;
	local[8]= local[4];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(*ftab[19])(ctx,2,local+8,&ftab[19],fqv[27]); /*matrix-column*/
	local[8]= w;
	w = local[2];
	ctx->vsp=local+9;
	local[2] = cons(ctx,local[8],w);
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto irtmathWHL365;
irtmathWHX366:
	local[8]= NIL;
irtmathBLK367:
	w = NIL;
	goto irtmathWHL357;
irtmathWHX358:
	local[6]= NIL;
irtmathBLK359:
	w = NIL;
	if (local[2]==NIL) goto irtmathIF368;
	local[4]= (pointer)get_sym_func(fqv[48]);
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)REVERSE(ctx,1,local+5); /*reverse*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,2,local+4); /*apply*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)TRANSPOSE(ctx,1,local+4); /*transpose*/
	local[4]= w;
	goto irtmathIF369;
irtmathIF368:
	local[4]= NIL;
irtmathIF369:
	w = local[4];
	local[0]= w;
irtmathBLK355:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmathCLO362(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(*ftab[0])(ctx,2,local+0,&ftab[0],fqv[0]); /*array-dimension*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*concatenate-matrix-diagonal*/
static pointer irtmathF31concatenate_matrix_diagonal(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
irtmathRST371:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= local[0];
irtmathWHL372:
	if (local[7]==NIL) goto irtmathWHX373;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	if (local[6]==NIL) goto irtmathIF375;
	local[8]= local[6];
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(*ftab[28])(ctx,2,local+8,&ftab[28],fqv[47]); /*matrix-row*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LENGTH(ctx,1,local+8); /*length*/
	local[8]= w;
	goto irtmathIF376;
irtmathIF375:
	local[8]= makeint((eusinteger_t)0L);
irtmathIF376:
	w = local[3];
	ctx->vsp=local+9;
	local[3] = cons(ctx,local[8],w);
	goto irtmathWHL372;
irtmathWHX373:
	local[8]= NIL;
irtmathBLK374:
	w = NIL;
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)REVERSE(ctx,1,local+6); /*reverse*/
	local[3] = w;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
irtmathWHL377:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto irtmathWHX378;
	local[8]= local[6];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)NTH(ctx,2,local+8); /*nth*/
	local[1] = w;
	if (local[1]==NIL) goto irtmathIF380;
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(*ftab[19])(ctx,2,local+8,&ftab[19],fqv[27]); /*matrix-column*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LENGTH(ctx,1,local+8); /*length*/
	local[8]= w;
	goto irtmathIF381;
irtmathIF380:
	local[8]= makeint((eusinteger_t)0L);
irtmathIF381:
	local[2] = local[8];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[2];
irtmathWHL382:
	local[10]= local[8];
	w = local[9];
	if ((eusinteger_t)local[10] >= (eusinteger_t)w) goto irtmathWHX383;
	local[5] = NIL;
	local[10]= makeint((eusinteger_t)0L);
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
irtmathWHL385:
	local[12]= local[10];
	w = local[11];
	if ((eusinteger_t)local[12] >= (eusinteger_t)w) goto irtmathWHX386;
	local[12]= local[6];
	if (local[10]!=local[12]) goto irtmathIF388;
	local[12]= local[1];
	local[13]= local[8];
	ctx->vsp=local+14;
	w=(*ftab[28])(ctx,2,local+12,&ftab[28],fqv[47]); /*matrix-row*/
	local[12]= w;
	w = local[5];
	ctx->vsp=local+13;
	local[5] = cons(ctx,local[12],w);
	local[12]= local[5];
	goto irtmathIF389;
irtmathIF388:
	local[12]= local[10];
	local[13]= local[3];
	ctx->vsp=local+14;
	w=(pointer)NTH(ctx,2,local+12); /*nth*/
	local[12]= w;
	local[13]= fqv[50];
	local[14]= loadglobal(fqv[4]);
	local[15]= fqv[22];
	local[16]= makeint((eusinteger_t)0L);
	ctx->vsp=local+17;
	w=(*ftab[29])(ctx,5,local+12,&ftab[29],fqv[51]); /*make-array*/
	local[12]= w;
	w = local[5];
	ctx->vsp=local+13;
	local[5] = cons(ctx,local[12],w);
	local[12]= local[5];
irtmathIF389:
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)ADD1(ctx,1,local+12); /*1+*/
	local[10] = w;
	goto irtmathWHL385;
irtmathWHX386:
	local[12]= NIL;
irtmathBLK387:
	w = NIL;
	local[10]= (pointer)get_sym_func(fqv[52]);
	local[11]= loadglobal(fqv[4]);
	local[12]= local[5];
	ctx->vsp=local+13;
	w=(pointer)REVERSE(ctx,1,local+12); /*reverse*/
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	ctx->vsp=local+12;
	w=(pointer)APPLY(ctx,2,local+10); /*apply*/
	local[10]= w;
	w = local[4];
	ctx->vsp=local+11;
	local[4] = cons(ctx,local[10],w);
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	goto irtmathWHL382;
irtmathWHX383:
	local[10]= NIL;
irtmathBLK384:
	w = NIL;
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto irtmathWHL377;
irtmathWHX378:
	local[8]= NIL;
irtmathBLK379:
	w = NIL;
	if (local[4]==NIL) goto irtmathIF390;
	local[6]= (pointer)get_sym_func(fqv[48]);
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)REVERSE(ctx,1,local+7); /*reverse*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,2,local+6); /*apply*/
	local[6]= w;
	goto irtmathIF391;
irtmathIF390:
	local[6]= NIL;
irtmathIF391:
	w = local[6];
	local[0]= w;
irtmathBLK370:
	ctx->vsp=local; return(local[0]);}

/*vector-variance*/
static pointer irtmathF32vector_variance(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	local[1]= local[0];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[3])(ctx,3,local+1,&ftab[3],fqv[3]); /*make-matrix*/
	local[1]= w;
	local[2]= loadglobal(fqv[4]);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,2,local+2); /*instantiate*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
irtmathWHL393:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto irtmathWHX394;
	local[5]= local[2];
	local[6]= local[3];
	local[7]= local[1];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(*ftab[19])(ctx,2,local+7,&ftab[19],fqv[27]); /*matrix-column*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[30])(ctx,1,local+7,&ftab[30],fqv[53]); /*variance*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SETELT(ctx,3,local+5); /*setelt*/
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto irtmathWHL393;
irtmathWHX394:
	local[5]= NIL;
irtmathBLK395:
	w = NIL;
	w = local[2];
	local[0]= w;
irtmathBLK392:
	ctx->vsp=local; return(local[0]);}

/*covariance-matrix*/
static pointer irtmathF33covariance_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[1] = w;
	local[2]= local[1];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(*ftab[3])(ctx,2,local+2,&ftab[3],fqv[3]); /*make-matrix*/
	local[0] = w;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= local[1];
irtmathWHL397:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto irtmathWHX398;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[1];
irtmathWHL400:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto irtmathWHX401;
	local[6]= local[0];
	local[7]= local[2];
	local[8]= local[4];
	local[9]= argv[0];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	local[10]= argv[0];
	local[11]= local[4];
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[31])(ctx,2,local+9,&ftab[31],fqv[54]); /*covariance*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)ASET(ctx,4,local+6); /*aset*/
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto irtmathWHL400;
irtmathWHX401:
	local[6]= NIL;
irtmathBLK402:
	w = NIL;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto irtmathWHL397;
irtmathWHX398:
	local[4]= NIL;
irtmathBLK399:
	w = local[0];
	local[0]= w;
irtmathBLK396:
	ctx->vsp=local; return(local[0]);}

/*normalize-vector*/
static pointer irtmathF34normalize_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto irtmathENT406;}
	local[0]= NIL;
irtmathENT406:
	if (n>=3) { local[1]=(argv[2]); goto irtmathENT405;}
	local[1]= makeflt(9.9999999999999949376344e-21);
irtmathENT405:
irtmathENT404:
	if (n>3) maerror();
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)VNORM(ctx,1,local+2); /*norm*/
	local[2]= w;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,2,local+2); /*<*/
	if (w==NIL) goto irtmathIF407;
	if (local[0]==NIL) goto irtmathIF409;
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(*ftab[15])(ctx,2,local+2,&ftab[15],fqv[21]); /*fill*/
	local[2]= w;
	goto irtmathIF410;
irtmathIF409:
	local[2]= loadglobal(fqv[4]);
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,2,local+2); /*instantiate*/
	local[2]= w;
irtmathIF410:
	goto irtmathIF408;
irtmathIF407:
	if (local[0]==NIL) goto irtmathIF411;
	local[2]= argv[0];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)VNORMALIZE(ctx,2,local+2); /*normalize-vector-org*/
	local[2]= w;
	goto irtmathIF412;
irtmathIF411:
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)VNORMALIZE(ctx,1,local+2); /*normalize-vector-org*/
	local[2]= w;
irtmathIF412:
irtmathIF408:
	w = local[2];
	local[0]= w;
irtmathBLK403:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___irtmath(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	ctx->vsp=local+0;
	compfun(ctx,fqv[55],module,irtmathF1inverse_matrix,fqv[56]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[57],module,irtmathF2inverse_matrix_complex,fqv[58]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[59],module,irtmathF3m__complex,fqv[60]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[61],module,irtmathF4diagonal,fqv[62]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[63],module,irtmathF5minor_matrix,fqv[64]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[65],module,irtmathF6atan2,fqv[66]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[67],module,irtmathF7outer_product_matrix,fqv[68]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[69],module,irtmathF8matrix2quaternion,fqv[70]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[71],module,irtmathF9quaternion2matrix,fqv[72]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[73],module,irtmathF10matrix_log,fqv[74]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[75],module,irtmathF11matrix_exponent,fqv[76]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[77],module,irtmathF12midrot,fqv[78]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[79],module,irtmathF13pseudo_inverse,fqv[80]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[81],module,irtmathF14pseudo_inverse_org,fqv[82]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[83],module,irtmathF15sr_inverse,fqv[84]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[85],module,irtmathF16sr_inverse_org,fqv[86]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[87],module,irtmathF17manipulability,fqv[88]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[89],module,irtmathF18random_gauss,fqv[90]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[91],module,irtmathF19gaussian_random,fqv[92]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[93],module,irtmathF20eigen_decompose,fqv[94]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[95],module,irtmathF21eigen_decompose_complex,fqv[96]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[97],module,irtmathF22solve_non_zero_vector_from_det0_matrix,fqv[98]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[33],module,irtmathF23lms,fqv[99]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[35],module,irtmathF24lms_estimate,fqv[100]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[101],module,irtmathF25lms_error,fqv[102]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[103],module,irtmathF26lmeds,fqv[104]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[34],module,irtmathF27lmeds_error,fqv[105]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[106],module,irtmathF28lmeds_error_mat,fqv[107]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[108],module,irtmathF29concatenate_matrix_column,fqv[109]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[110],module,irtmathF30concatenate_matrix_row,fqv[111]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[112],module,irtmathF31concatenate_matrix_diagonal,fqv[113]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[114],module,irtmathF32vector_variance,fqv[115]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[116],module,irtmathF33covariance_matrix,fqv[117]);
	local[0]= fqv[118];
	ctx->vsp=local+1;
	w=(pointer)FBOUNDP(ctx,1,local+0); /*fboundp*/
	if (w!=NIL) goto irtmathIF413;
	local[0]= fqv[119];
	local[1]= fqv[120];
	ctx->vsp=local+2;
	w=(*ftab[32])(ctx,2,local+0,&ftab[32],fqv[121]); /*remprop*/
	local[0]= fqv[118];
	local[1]= fqv[119];
	ctx->vsp=local+2;
	w=(pointer)SYMFUNC(ctx,1,local+1); /*symbol-function*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)SETFUNC(ctx,2,local+0); /*lisp::setfunc*/
	local[0]= fqv[118];
	local[1]= fqv[122];
	ctx->vsp=local+2;
	w=(*ftab[33])(ctx,2,local+0,&ftab[33],fqv[123]); /*compiler::def-builtin-entry*/
	local[0]= w;
	goto irtmathIF414;
irtmathIF413:
	local[0]= NIL;
irtmathIF414:
	ctx->vsp=local+0;
	compfun(ctx,fqv[119],module,irtmathF34normalize_vector,fqv[124]);
	local[0]= fqv[125];
	local[1]= fqv[126];
	ctx->vsp=local+2;
	w=(*ftab[34])(ctx,2,local+0,&ftab[34],fqv[127]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<35; i++) ftab[i]=fcallx;
}
