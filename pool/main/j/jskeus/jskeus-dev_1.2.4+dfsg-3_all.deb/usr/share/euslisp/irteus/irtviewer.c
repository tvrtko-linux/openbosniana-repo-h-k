/* ./irtviewer.c :  entry=irtviewer */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "irtviewer.h"
#pragma init (register_irtviewer)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___irtviewer();
extern pointer build_quote_vector();
static int register_irtviewer()
  { add_module_initializer("___irtviewer", ___irtviewer);}

static pointer irtvieweF776make_lr_ud_coords();
static pointer irtvieweF777make_mpeg_from_images();
static pointer irtvieweF778make_animgif_from_images();
static pointer irtvieweF779draw_things();
static pointer irtvieweF780objects();
static pointer irtvieweF781make_irtviewer();
static pointer irtvieweF782make_irtviewer_dummy();

/*make-lr-ud-coords*/
static pointer irtvieweF776make_lr_ud_coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	ctx->vsp=local+0;
	w=(*ftab[0])(ctx,0,local+0,&ftab[0],fqv[0]); /*geometry:make-coords*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[1];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[1])(ctx,1,local+3,&ftab[1],fqv[2]); /*deg2rad*/
	local[3]= w;
	local[4]= fqv[3];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= local[0];
	local[2]= fqv[1];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(*ftab[1])(ctx,1,local+3,&ftab[1],fqv[2]); /*deg2rad*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,1,local+3); /*-*/
	local[3]= w;
	local[4]= fqv[4];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	w = local[0];
	local[0]= w;
irtvieweBLK783:
	ctx->vsp=local; return(local[0]);}

/*:draw-circle*/
static pointer irtvieweM784geometry_viewer_draw_circle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[5], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtvieweKEY786;
	local[0] = makeint((eusinteger_t)50L);
irtvieweKEY786:
	if (n & (1<<1)) goto irtvieweKEY787;
	local[1] = NIL;
irtvieweKEY787:
	if (n & (1<<2)) goto irtvieweKEY788;
	local[2] = NIL;
irtvieweKEY788:
	if (n & (1<<3)) goto irtvieweKEY789;
	local[3] = makeflt(6.2831853071795862319959e+00);
irtvieweKEY789:
	if (n & (1<<4)) goto irtvieweKEY790;
	local[4] = fqv[6];
irtvieweKEY790:
	local[5]= makeint((eusinteger_t)16L);
	local[6]= local[3];
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[6]= w;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= local[5];
irtvieweWHL791:
	local[11]= local[9];
	w = local[10];
	if ((eusinteger_t)local[11] >= (eusinteger_t)w) goto irtvieweWHX792;
	local[11]= argv[2];
	local[12]= fqv[7];
	local[13]= local[0];
	local[14]= local[9];
	local[15]= local[6];
	ctx->vsp=local+16;
	w=(pointer)TIMES(ctx,2,local+14); /***/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SIN(ctx,1,local+14); /*sin*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)TIMES(ctx,2,local+13); /***/
	local[13]= w;
	local[14]= local[0];
	local[15]= local[9];
	local[16]= local[6];
	ctx->vsp=local+17;
	w=(pointer)TIMES(ctx,2,local+15); /***/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)COS(ctx,1,local+15); /*cos*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)TIMES(ctx,2,local+14); /***/
	local[14]= w;
	local[15]= makeint((eusinteger_t)0L);
	ctx->vsp=local+16;
	w=(pointer)MKFLTVEC(ctx,3,local+13); /*float-vector*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	local[8] = w;
	if (local[7]==NIL) goto irtvieweIF794;
	local[11]= argv[0];
	local[12]= fqv[8];
	local[13]= local[7];
	local[14]= local[8];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,4,local+11); /*send*/
	local[11]= w;
	goto irtvieweIF795;
irtvieweIF794:
	local[11]= NIL;
irtvieweIF795:
	local[7] = local[8];
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[9] = w;
	goto irtvieweWHL791;
irtvieweWHX792:
	local[11]= NIL;
irtvieweBLK793:
	w = NIL;
	local[9]= argv[2];
	local[10]= fqv[7];
	local[11]= local[0];
	local[12]= local[5];
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(pointer)TIMES(ctx,2,local+12); /***/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)SIN(ctx,1,local+12); /*sin*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	local[12]= local[0];
	local[13]= local[5];
	local[14]= local[6];
	ctx->vsp=local+15;
	w=(pointer)TIMES(ctx,2,local+13); /***/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)COS(ctx,1,local+13); /*cos*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)TIMES(ctx,2,local+12); /***/
	local[12]= w;
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)MKFLTVEC(ctx,3,local+11); /*float-vector*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[8] = w;
	if (local[2]==NIL) goto irtvieweIF796;
	local[9]= argv[0];
	local[10]= fqv[9];
	local[11]= local[7];
	local[12]= local[8];
	local[13]= T;
	local[14]= NIL;
	local[15]= fqv[10];
	local[16]= local[4];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,8,local+9); /*send*/
	local[9]= w;
	goto irtvieweIF797;
irtvieweIF796:
	local[9]= argv[0];
	local[10]= fqv[8];
	local[11]= local[7];
	local[12]= local[8];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,4,local+9); /*send*/
	local[9]= w;
irtvieweIF797:
	if (local[1]==NIL) goto irtvieweIF798;
	local[9]= argv[0];
	local[10]= fqv[11];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	goto irtvieweIF799;
irtvieweIF798:
	local[9]= NIL;
irtvieweIF799:
	w = local[9];
	local[0]= w;
irtvieweBLK785:
	ctx->vsp=local; return(local[0]);}

/*:draw-objects*/
static pointer irtvieweM800geometry_viewer_draw_objects(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtvieweRST802:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[12]);
	local[2]= argv[0];
	local[3]= fqv[13];
	ctx->vsp=local+4;
	w=(pointer)GETPROP(ctx,2,local+2); /*get*/
	local[2]= w;
	local[3]= fqv[14];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[0]= w;
irtvieweBLK801:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer irtvieweM803irtviewer_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtvieweRST805:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[15], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtvieweKEY806;
	local[1] = fqv[16];
irtvieweKEY806:
	if (n & (1<<1)) goto irtvieweKEY807;
	local[10]= fqv[17];
	ctx->vsp=local+11;
	w=(pointer)GENSYM(ctx,1,local+10); /*gensym*/
	local[2] = w;
irtvieweKEY807:
	if (n & (1<<2)) goto irtvieweKEY808;
	local[3] = makeflt(2.0000000000000000000000e+02);
irtvieweKEY808:
	if (n & (1<<3)) goto irtvieweKEY809;
	local[4] = makeflt(5.0000000000000000000000e+04);
irtvieweKEY809:
	if (n & (1<<4)) goto irtvieweKEY810;
	local[5] = makeint((eusinteger_t)500L);
irtvieweKEY810:
	if (n & (1<<5)) goto irtvieweKEY811;
	local[6] = makeint((eusinteger_t)500L);
irtvieweKEY811:
	if (n & (1<<6)) goto irtvieweKEY812;
	local[7] = makeint((eusinteger_t)150L);
irtvieweKEY812:
	if (n & (1<<7)) goto irtvieweKEY813;
	local[8] = NIL;
irtvieweKEY813:
	if (n & (1<<8)) goto irtvieweKEY814;
	local[9] = fqv[18];
irtvieweKEY814:
	argv[0]->c.obj.iv[29] = makeint((eusinteger_t)60L);
	argv[0]->c.obj.iv[30] = makeint((eusinteger_t)20L);
	local[10]= makeint((eusinteger_t)700L);
	local[11]= makeint((eusinteger_t)400L);
	local[12]= makeint((eusinteger_t)250L);
	ctx->vsp=local+13;
	w=(pointer)MKFLTVEC(ctx,3,local+10); /*float-vector*/
	argv[0]->c.obj.iv[31] = w;
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)0L);
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(pointer)MKFLTVEC(ctx,3,local+10); /*float-vector*/
	argv[0]->c.obj.iv[32] = w;
	argv[0]->c.obj.iv[34] = local[7];
	argv[0]->c.obj.iv[35] = local[8];
	argv[0]->c.obj.iv[36] = local[9];
	argv[0]->c.obj.iv[38] = NIL;
	local[10]= (pointer)get_sym_func(fqv[19]);
	local[11]= argv[0];
	local[12]= *(ovafptr(argv[1],fqv[20]));
	local[13]= fqv[21];
	local[14]= fqv[22];
	local[15]= local[5];
	local[16]= fqv[23];
	local[17]= local[6];
	local[18]= fqv[24];
	local[19]= local[1];
	local[20]= fqv[25];
	local[21]= fqv[26];
	local[22]= local[0];
	ctx->vsp=local+23;
	w=(pointer)APPLY(ctx,13,local+10); /*apply*/
	local[10]= local[4];
	storeglobal(fqv[27],local[10]);
	local[10]= local[3];
	storeglobal(fqv[28],local[10]);
	local[10]= (pointer)get_sym_func(fqv[29]);
	local[11]= fqv[30];
	local[12]= argv[0];
	local[13]= fqv[31];
	local[14]= makeint((eusinteger_t)0L);
	local[15]= fqv[4];
	local[16]= makeint((eusinteger_t)0L);
	local[17]= fqv[22];
	local[18]= local[5];
	local[19]= fqv[23];
	local[20]= local[6];
	local[21]= fqv[24];
	local[22]= local[1];
	local[23]= fqv[32];
	local[24]= local[2];
	local[25]= local[0];
	ctx->vsp=local+26;
	w=(pointer)APPLY(ctx,16,local+10); /*apply*/
	argv[0]->c.obj.iv[25] = w;
	local[10]= argv[0]->c.obj.iv[25];
	local[11]= argv[0];
	local[12]= fqv[13];
	ctx->vsp=local+13;
	w=(pointer)PUTPROP(ctx,3,local+10); /*putprop*/
	local[10]= argv[0]->c.obj.iv[25];
	storeglobal(fqv[33],local[10]);
	local[10]= makeflt(9.9999999999999977795540e-02);
	local[11]= makeflt(9.9999999999999977795540e-02);
	local[12]= makeflt(9.9999999999999977795540e-02);
	local[13]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+14;
	w=(pointer)MKFLTVEC(ctx,4,local+10); /*float-vector*/
	local[10]= w;
	local[11]= makeflt(1.0000000000000000000000e+00);
	local[12]= makeflt(1.0000000000000000000000e+00);
	local[13]= makeflt(1.0000000000000000000000e+00);
	local[14]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+15;
	w=(pointer)MKFLTVEC(ctx,4,local+11); /*float-vector*/
	local[11]= w;
	local[12]= makeflt(9.9999999999999977795540e-02);
	local[13]= makeflt(9.9999999999999977795540e-02);
	local[14]= makeflt(9.9999999999999977795540e-02);
	local[15]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+16;
	w=(pointer)MKFLTVEC(ctx,4,local+12); /*float-vector*/
	local[12]= w;
	local[13]= makeflt(1.0000000000000000000000e+00);
	local[14]= makeflt(6.9999999999999973354647e-01);
	local[15]= makeflt(3.9999999999999991118216e-01);
	local[16]= makeflt(2.5000000000000000000000e-01);
	local[17]= loadglobal(fqv[34]);
	ctx->vsp=local+18;
	w=(pointer)INSTANTIATE(ctx,1,local+17); /*instantiate*/
	local[17]= w;
	local[18]= local[17];
	local[19]= fqv[21];
	local[20]= makeint((eusinteger_t)0L);
	local[21]= fqv[35];
	local[22]= local[13];
	local[23]= local[10];
	ctx->vsp=local+24;
	w=(pointer)SCALEVEC(ctx,2,local+22); /*scale*/
	local[22]= w;
	local[23]= fqv[36];
	local[24]= local[13];
	local[25]= local[11];
	ctx->vsp=local+26;
	w=(pointer)SCALEVEC(ctx,2,local+24); /*scale*/
	local[24]= w;
	local[25]= fqv[37];
	local[26]= local[13];
	local[27]= local[12];
	ctx->vsp=local+28;
	w=(pointer)SCALEVEC(ctx,2,local+26); /*scale*/
	local[26]= w;
	local[27]= fqv[38];
	local[28]= makeflt(4.0000000000000000000000e+03);
	local[29]= makeflt(3.0000000000000000000000e+03);
	local[30]= makeflt(0.0000000000000000000000e+00);
	local[31]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+32;
	w=(pointer)MKFLTVEC(ctx,4,local+28); /*float-vector*/
	local[28]= w;
	ctx->vsp=local+29;
	w=(pointer)SEND(ctx,11,local+18); /*send*/
	w = local[17];
	local[17]= w;
	storeglobal(fqv[39],w);
	local[17]= loadglobal(fqv[34]);
	ctx->vsp=local+18;
	w=(pointer)INSTANTIATE(ctx,1,local+17); /*instantiate*/
	local[17]= w;
	local[18]= local[17];
	local[19]= fqv[21];
	local[20]= makeint((eusinteger_t)1L);
	local[21]= fqv[35];
	local[22]= local[14];
	local[23]= local[10];
	ctx->vsp=local+24;
	w=(pointer)SCALEVEC(ctx,2,local+22); /*scale*/
	local[22]= w;
	local[23]= fqv[36];
	local[24]= local[14];
	local[25]= local[11];
	ctx->vsp=local+26;
	w=(pointer)SCALEVEC(ctx,2,local+24); /*scale*/
	local[24]= w;
	local[25]= fqv[37];
	local[26]= local[14];
	local[27]= local[12];
	ctx->vsp=local+28;
	w=(pointer)SCALEVEC(ctx,2,local+26); /*scale*/
	local[26]= w;
	local[27]= fqv[38];
	local[28]= makeflt(-4.0000000000000000000000e+03);
	local[29]= makeflt(-2.0000000000000000000000e+03);
	local[30]= makeflt(-2.0000000000000000000000e+03);
	local[31]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+32;
	w=(pointer)MKFLTVEC(ctx,4,local+28); /*float-vector*/
	local[28]= w;
	ctx->vsp=local+29;
	w=(pointer)SEND(ctx,11,local+18); /*send*/
	w = local[17];
	local[17]= w;
	storeglobal(fqv[40],w);
	local[17]= loadglobal(fqv[34]);
	ctx->vsp=local+18;
	w=(pointer)INSTANTIATE(ctx,1,local+17); /*instantiate*/
	local[17]= w;
	local[18]= local[17];
	local[19]= fqv[21];
	local[20]= makeint((eusinteger_t)2L);
	local[21]= fqv[35];
	local[22]= local[15];
	local[23]= local[10];
	ctx->vsp=local+24;
	w=(pointer)SCALEVEC(ctx,2,local+22); /*scale*/
	local[22]= w;
	local[23]= fqv[36];
	local[24]= local[15];
	local[25]= local[11];
	ctx->vsp=local+26;
	w=(pointer)SCALEVEC(ctx,2,local+24); /*scale*/
	local[24]= w;
	local[25]= fqv[37];
	local[26]= local[15];
	local[27]= local[12];
	ctx->vsp=local+28;
	w=(pointer)SCALEVEC(ctx,2,local+26); /*scale*/
	local[26]= w;
	local[27]= fqv[38];
	local[28]= makeflt(-2.0000000000000000000000e+03);
	local[29]= makeflt(-2.0000000000000000000000e+03);
	local[30]= makeflt(2.5000000000000000000000e+03);
	local[31]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+32;
	w=(pointer)MKFLTVEC(ctx,4,local+28); /*float-vector*/
	local[28]= w;
	ctx->vsp=local+29;
	w=(pointer)SEND(ctx,11,local+18); /*send*/
	w = local[17];
	local[17]= w;
	storeglobal(fqv[41],w);
	local[17]= loadglobal(fqv[34]);
	ctx->vsp=local+18;
	w=(pointer)INSTANTIATE(ctx,1,local+17); /*instantiate*/
	local[17]= w;
	local[18]= local[17];
	local[19]= fqv[21];
	local[20]= makeint((eusinteger_t)3L);
	local[21]= fqv[35];
	local[22]= local[16];
	local[23]= local[10];
	ctx->vsp=local+24;
	w=(pointer)SCALEVEC(ctx,2,local+22); /*scale*/
	local[22]= w;
	local[23]= fqv[36];
	local[24]= local[16];
	local[25]= local[11];
	ctx->vsp=local+26;
	w=(pointer)SCALEVEC(ctx,2,local+24); /*scale*/
	local[24]= w;
	local[25]= fqv[37];
	local[26]= local[16];
	local[27]= local[12];
	ctx->vsp=local+28;
	w=(pointer)SCALEVEC(ctx,2,local+26); /*scale*/
	local[26]= w;
	local[27]= fqv[38];
	local[28]= makeflt(0.0000000000000000000000e+00);
	local[29]= makeflt(0.0000000000000000000000e+00);
	local[30]= makeflt(0.0000000000000000000000e+00);
	local[31]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+32;
	w=(pointer)MKFLTVEC(ctx,4,local+28); /*float-vector*/
	local[28]= w;
	ctx->vsp=local+29;
	w=(pointer)SEND(ctx,11,local+18); /*send*/
	w = local[17];
	local[17]= w;
	storeglobal(fqv[42],w);
	w = local[17];
	local[10]= loadglobal(fqv[39]);
	local[11]= fqv[43];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= loadglobal(fqv[40]);
	local[11]= fqv[43];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= loadglobal(fqv[41]);
	local[11]= fqv[43];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= loadglobal(fqv[42]);
	local[11]= fqv[43];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= argv[0]->c.obj.iv[25];
	local[11]= fqv[44];
	local[12]= fqv[45];
	local[13]= fqv[46];
	local[14]= fqv[47];
	local[15]= argv[0];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,6,local+10); /*send*/
	local[10]= argv[0]->c.obj.iv[25];
	local[11]= fqv[44];
	local[12]= fqv[45];
	local[13]= fqv[48];
	local[14]= fqv[49];
	local[15]= argv[0];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,6,local+10); /*send*/
	local[10]= argv[0]->c.obj.iv[25];
	local[11]= fqv[44];
	local[12]= fqv[45];
	local[13]= fqv[50];
	local[14]= fqv[51];
	local[15]= argv[0];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,6,local+10); /*send*/
	local[10]= argv[0]->c.obj.iv[25];
	local[11]= fqv[44];
	local[12]= fqv[45];
	local[13]= fqv[52];
	local[14]= fqv[51];
	local[15]= argv[0];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,6,local+10); /*send*/
	local[10]= argv[0];
	local[11]= fqv[53];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= argv[0];
	local[11]= fqv[14];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	w = argv[0];
	local[0]= w;
irtvieweBLK804:
	ctx->vsp=local; return(local[0]);}

/*:viewer*/
static pointer irtvieweM815irtviewer_viewer(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtvieweRST817:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[25];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[54]); /*user::forward-message-to*/
	local[0]= w;
irtvieweBLK816:
	ctx->vsp=local; return(local[0]);}

/*:redraw*/
static pointer irtvieweM818irtviewer_redraw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[14];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
irtvieweBLK819:
	ctx->vsp=local; return(local[0]);}

/*:expose*/
static pointer irtvieweM820irtviewer_expose(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[55],w);
	local[3]= NIL;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtvieweBLK821:
	ctx->vsp=local; return(local[0]);}

/*:resize*/
static pointer irtvieweM822irtviewer_resize(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	argv[0]->c.obj.iv[5] = argv[2];
	argv[0]->c.obj.iv[6] = argv[3];
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[20]));
	local[2]= fqv[56];
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)SENDMESSAGE(ctx,5,local+0); /*send-message*/
	local[0]= argv[0]->c.obj.iv[25];
	local[1]= fqv[44];
	local[2]= fqv[56];
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,5,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[25];
	local[1]= fqv[44];
	local[2]= fqv[57];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[25];
	local[1]= fqv[44];
	local[2]= fqv[58];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[2];
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)MAX(ctx,2,local+0); /*max*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[25];
	local[2]= fqv[59];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[56];
	local[3]= fqv[22];
	local[4]= local[0];
	local[5]= fqv[23];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,1,local+6); /*-*/
	local[6]= w;
	local[7]= fqv[60];
	local[8]= argv[2];
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	local[8]= w;
	local[9]= fqv[61];
	local[10]= argv[3];
	local[11]= makeint((eusinteger_t)2L);
	ctx->vsp=local+12;
	w=(pointer)QUOTIENT(ctx,2,local+10); /*/*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,10,local+1); /*send*/
	local[0]= argv[0];
	local[1]= fqv[62];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
irtvieweBLK823:
	ctx->vsp=local; return(local[0]);}

/*:configurenotify*/
static pointer irtvieweM824irtviewer_configurenotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[55],w);
	if (loadglobal(fqv[63])==NIL) goto irtvieweIF826;
	local[3]= fqv[64];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[3])(ctx,2,local+3,&ftab[3],fqv[65]); /*warn*/
	local[3]= w;
	goto irtvieweIF827;
irtvieweIF826:
	local[3]= NIL;
irtvieweIF827:
	local[3]= argv[0];
	local[4]= loadglobal(fqv[66]);
	local[5]= fqv[22];
	ctx->vsp=local+6;
	w=(pointer)SENDMESSAGE(ctx,3,local+3); /*send-message*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= loadglobal(fqv[66]);
	local[6]= fqv[23];
	ctx->vsp=local+7;
	w=(pointer)SENDMESSAGE(ctx,3,local+4); /*send-message*/
	local[4]= w;
	local[5]= local[3];
	local[6]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+7;
	w=(*ftab[4])(ctx,2,local+5,&ftab[4],fqv[67]); /*/=*/
	if (w!=NIL) goto irtvieweOR830;
	local[5]= local[4];
	local[6]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+7;
	w=(*ftab[4])(ctx,2,local+5,&ftab[4],fqv[67]); /*/=*/
	if (w!=NIL) goto irtvieweOR830;
	goto irtvieweIF828;
irtvieweOR830:
	local[5]= argv[0];
	local[6]= fqv[56];
	local[7]= local[3];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= w;
	goto irtvieweIF829;
irtvieweIF828:
	local[5]= NIL;
irtvieweIF829:
	w = local[5];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtvieweBLK825:
	ctx->vsp=local; return(local[0]);}

/*:viewtarget*/
static pointer irtvieweM831irtviewer_viewtarget(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtvieweENT834;}
	local[0]= NIL;
irtvieweENT834:
irtvieweENT833:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtvieweIF835;
	argv[0]->c.obj.iv[32] = local[0];
	local[1]= argv[0]->c.obj.iv[32];
	goto irtvieweIF836;
irtvieweIF835:
	local[1]= NIL;
irtvieweIF836:
	w = argv[0]->c.obj.iv[32];
	local[0]= w;
irtvieweBLK832:
	ctx->vsp=local; return(local[0]);}

/*:viewpoint*/
static pointer irtvieweM837irtviewer_viewpoint(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtvieweENT840;}
	local[0]= NIL;
irtvieweENT840:
irtvieweENT839:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtvieweIF841;
	argv[0]->c.obj.iv[31] = local[0];
	local[1]= argv[0]->c.obj.iv[31];
	goto irtvieweIF842;
irtvieweIF841:
	local[1]= NIL;
irtvieweIF842:
	w = argv[0]->c.obj.iv[31];
	local[0]= w;
irtvieweBLK838:
	ctx->vsp=local; return(local[0]);}

/*:look1*/
static pointer irtvieweM843irtviewer_look1(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtvieweENT848;}
	local[0]= argv[0]->c.obj.iv[32];
irtvieweENT848:
	if (n>=4) { local[1]=(argv[3]); goto irtvieweENT847;}
	local[1]= argv[0]->c.obj.iv[29];
irtvieweENT847:
	if (n>=5) { local[2]=(argv[4]); goto irtvieweENT846;}
	local[2]= argv[0]->c.obj.iv[30];
irtvieweENT846:
irtvieweENT845:
	if (n>5) maerror();
	local[3]= local[1];
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)irtvieweF776make_lr_ud_coords(ctx,2,local+3); /*make-lr-ud-coords*/
	local[3]= w;
	local[4]= local[0];
	local[5]= local[3];
	local[6]= fqv[7];
	local[7]= argv[0]->c.obj.iv[31];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)VMINUS(ctx,2,local+7); /*v-*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)VNORM(ctx,1,local+7); /*norm*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)VPLUS(ctx,2,local+4); /*v+*/
	local[4]= w;
	local[5]= local[3];
	local[6]= fqv[68];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= argv[0];
	local[7]= fqv[69];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= argv[0];
	local[7]= fqv[70];
	local[8]= fqv[71];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	if (w==NIL) goto irtvieweIF849;
	local[6]= argv[0];
	local[7]= fqv[70];
	local[8]= fqv[71];
	local[9]= fqv[72];
	local[10]= argv[0]->c.obj.iv[31];
	local[11]= local[0];
	local[12]= local[5];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,7,local+6); /*send*/
	local[6]= w;
	goto irtvieweIF850;
irtvieweIF849:
	local[6]= NIL;
irtvieweIF850:
	w = local[6];
	local[0]= w;
irtvieweBLK844:
	ctx->vsp=local; return(local[0]);}

/*:look-all*/
static pointer irtvieweM851irtviewer_look_all(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtvieweENT854;}
	local[0]= NIL;
irtvieweENT854:
irtvieweENT853:
	if (n>3) maerror();
	local[1]= local[0];
	local[2]= loadglobal(fqv[73]);
	ctx->vsp=local+3;
	w=(pointer)DERIVEDP(ctx,2,local+1); /*derivedp*/
	local[1]= w;
	if (w!=NIL) goto irtvieweCON855;
irtvieweCON856:
	if (local[0]!=NIL) goto irtvieweCON857;
	local[1]= argv[0]->c.obj.iv[27];
	local[2]= fqv[74];
	ctx->vsp=local+3;
	w=(*ftab[5])(ctx,2,local+1,&ftab[5],fqv[75]); /*send-all*/
	local[1]= argv[0]->c.obj.iv[27];
	local[2]= fqv[76];
	ctx->vsp=local+3;
	w=(*ftab[5])(ctx,2,local+1,&ftab[5],fqv[75]); /*send-all*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,1,local+1,&ftab[6],fqv[77]); /*flatten*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[7])(ctx,1,local+1,&ftab[7],fqv[78]); /*geometry:make-bounding-box*/
	local[0] = w;
	local[1]= local[0];
	goto irtvieweCON855;
irtvieweCON857:
	if (local[0]==NIL) goto irtvieweCON858;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)irtvieweF779draw_things(ctx,1,local+1); /*draw-things*/
	local[1]= w;
	local[2]= fqv[76];
	ctx->vsp=local+3;
	w=(*ftab[5])(ctx,2,local+1,&ftab[5],fqv[75]); /*send-all*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,1,local+1,&ftab[6],fqv[77]); /*flatten*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[7])(ctx,1,local+1,&ftab[7],fqv[78]); /*geometry:make-bounding-box*/
	local[0] = w;
	local[1]= local[0];
	goto irtvieweCON855;
irtvieweCON858:
	local[1]= NIL;
irtvieweCON855:
	if (local[0]==NIL) goto irtvieweIF859;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= local[0];
	local[5]= fqv[79];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[1] = w;
	local[4]= (pointer)get_sym_func(fqv[80]);
	local[5]= local[0];
	local[6]= fqv[81];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= loadglobal(fqv[82]);
	ctx->vsp=local+7;
	w=(pointer)COERCE(ctx,2,local+5); /*coerce*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,2,local+4); /*apply*/
	local[4]= w;
	local[5]= makeflt(5.0000000000000000000000e-01);
	local[6]= argv[0];
	local[7]= fqv[70];
	local[8]= fqv[71];
	local[9]= fqv[83];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)TAN(ctx,1,local+6); /*tan*/
	{ double x,y;
		y=fltval(w); x=fltval(local[5]);
		local[5]=(makeflt(x * y));}
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[3] = w;
	local[4]= local[3];
	local[5]= loadglobal(fqv[27]);
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)GREATERP(ctx,2,local+4); /*>*/
	if (w!=NIL) goto irtvieweOR863;
	local[4]= local[3];
	local[5]= loadglobal(fqv[27]);
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	local[5]= makeflt(1.0000000000000000208167e-03);
	ctx->vsp=local+6;
	w=(pointer)LESSP(ctx,2,local+4); /*<*/
	if (w!=NIL) goto irtvieweOR863;
	goto irtvieweIF861;
irtvieweOR863:
	local[4]= makeint((eusinteger_t)2L);
	local[5]= fqv[84];
	local[6]= local[3];
	local[7]= loadglobal(fqv[27]);
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[8])(ctx,3,local+4,&ftab[8],fqv[85]); /*warning-message*/
	local[4]= local[3];
	local[5]= loadglobal(fqv[27]);
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	local[5]= loadglobal(fqv[28]);
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	storeglobal(fqv[28],w);
	local[4]= local[3];
	local[5]= loadglobal(fqv[27]);
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	local[5]= loadglobal(fqv[27]);
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	storeglobal(fqv[27],w);
	goto irtvieweIF862;
irtvieweIF861:
	local[4]= NIL;
irtvieweIF862:
	local[4]= loadglobal(fqv[27]);
	local[5]= makeflt(7.9999999999999982236432e-01);
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	local[5]= loadglobal(fqv[28]);
	local[6]= makeflt(1.5000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)MAX(ctx,2,local+5); /*max*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MIN(ctx,2,local+4); /*min*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[31];
	local[6]= argv[0]->c.obj.iv[32];
	ctx->vsp=local+7;
	w=(pointer)VMINUS(ctx,2,local+5); /*v-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)VNORMALIZE(ctx,1,local+5); /*normalize-vector*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SCALEVEC(ctx,2,local+4); /*scale*/
	local[2] = w;
	local[4]= argv[0];
	local[5]= fqv[86];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= argv[0];
	local[5]= fqv[69];
	local[6]= local[1];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)VPLUS(ctx,2,local+6); /*v+*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[1]= w;
	goto irtvieweIF860;
irtvieweIF859:
	local[1]= NIL;
irtvieweIF860:
	local[1]= argv[0];
	local[2]= fqv[53];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[14];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[0]= w;
irtvieweBLK852:
	ctx->vsp=local; return(local[0]);}

/*:move-viewing-around-viewtarget*/
static pointer irtvieweM864irtviewer_move_viewing_around_viewtarget(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=8) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[55],w);
	local[3]= loadglobal(fqv[55]);
	ctx->vsp=local+4;
	w=(*ftab[9])(ctx,1,local+3,&ftab[9],fqv[87]); /*event-middle*/
	if (w==NIL) goto irtvieweCON867;
	local[3]= argv[0]->c.obj.iv[31];
	local[4]= argv[0]->c.obj.iv[32];
	ctx->vsp=local+5;
	w=(pointer)VMINUS(ctx,2,local+3); /*v-*/
	local[3]= w;
	local[4]= argv[7];
	local[5]= fqv[71];
	local[6]= fqv[7];
	local[7]= makeflt(1.0000000000000000208167e-03);
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)VNORM(ctx,1,local+8); /*norm*/
	{ double x,y;
		y=fltval(w); x=fltval(local[7]);
		local[7]=(makeflt(x * y));}
	local[8]= makeint((eusinteger_t)-1L);
	local[9]= argv[5];
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	local[9]= argv[6];
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SCALEVEC(ctx,2,local+7); /*scale*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[86];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= local[4];
	local[7]= argv[0]->c.obj.iv[31];
	ctx->vsp=local+8;
	w=(pointer)VMINUS(ctx,2,local+6); /*v-*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= fqv[69];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= argv[0];
	local[8]= fqv[86];
	local[9]= local[5];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)VPLUS(ctx,2,local+9); /*v+*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[3]= w;
	goto irtvieweCON866;
irtvieweCON867:
	local[3]= loadglobal(fqv[55]);
	ctx->vsp=local+4;
	w=(*ftab[10])(ctx,1,local+3,&ftab[10],fqv[88]); /*event-right*/
	if (w!=NIL) goto irtvieweOR869;
	local[3]= makeint((eusinteger_t)60L);
	local[4]= argv[3];
	local[5]= argv[7];
	local[6]= fqv[44];
	local[7]= fqv[22];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)60L);
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LESSP(ctx,3,local+3); /*<*/
	if (w==NIL) goto irtvieweAND870;
	local[3]= makeint((eusinteger_t)60L);
	local[4]= argv[4];
	local[5]= argv[7];
	local[6]= fqv[44];
	local[7]= fqv[23];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)60L);
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LESSP(ctx,3,local+3); /*<*/
	if (w==NIL) goto irtvieweAND870;
	local[3]= loadglobal(fqv[55]);
	ctx->vsp=local+4;
	w=(*ftab[11])(ctx,1,local+3,&ftab[11],fqv[89]); /*event-left*/
	if (w==NIL) goto irtvieweAND870;
	goto irtvieweOR869;
irtvieweAND870:
	goto irtvieweCON868;
irtvieweOR869:
	local[3]= argv[0]->c.obj.iv[29];
	local[4]= argv[5];
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	argv[0]->c.obj.iv[29] = w;
	local[3]= argv[0]->c.obj.iv[30];
	local[4]= argv[6];
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	argv[0]->c.obj.iv[30] = w;
	local[3]= argv[0]->c.obj.iv[30];
	goto irtvieweCON866;
irtvieweCON868:
	local[3]= argv[3];
	local[4]= argv[7];
	local[5]= fqv[44];
	local[6]= fqv[22];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)60L);
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)GREATERP(ctx,2,local+3); /*>*/
	if (w!=NIL) goto irtvieweOR872;
	local[3]= argv[4];
	local[4]= makeint((eusinteger_t)60L);
	ctx->vsp=local+5;
	w=(pointer)LESSP(ctx,2,local+3); /*<*/
	if (w!=NIL) goto irtvieweOR872;
	goto irtvieweCON871;
irtvieweOR872:
	local[3]= argv[0]->c.obj.iv[31];
	local[4]= argv[0]->c.obj.iv[32];
	ctx->vsp=local+5;
	w=(pointer)VMINUS(ctx,2,local+3); /*v-*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[69];
	local[6]= argv[0]->c.obj.iv[31];
	local[7]= makeflt(9.9999999999999950039964e-03);
	local[8]= argv[4];
	local[9]= makeint((eusinteger_t)60L);
	ctx->vsp=local+10;
	w=(pointer)LESSP(ctx,2,local+8); /*<*/
	if (w==NIL) goto irtvieweIF873;
	local[8]= argv[5];
	goto irtvieweIF874;
irtvieweIF873:
	local[8]= argv[6];
irtvieweIF874:
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)VNORM(ctx,1,local+9); /*norm*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,3,local+7); /***/
	local[7]= w;
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)VNORMALIZE(ctx,1,local+8); /*normalize-vector*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SCALEVEC(ctx,2,local+7); /*scale*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)VPLUS(ctx,2,local+6); /*v+*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[3]= w;
	goto irtvieweCON866;
irtvieweCON871:
	local[3]= argv[4];
	local[4]= argv[7];
	local[5]= fqv[44];
	local[6]= fqv[23];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)60L);
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)GREATERP(ctx,2,local+3); /*>*/
	if (w!=NIL) goto irtvieweOR876;
	local[3]= argv[3];
	local[4]= makeint((eusinteger_t)60L);
	ctx->vsp=local+5;
	w=(pointer)LESSP(ctx,2,local+3); /*<*/
	if (w!=NIL) goto irtvieweOR876;
	goto irtvieweCON875;
irtvieweOR876:
	local[3]= argv[0]->c.obj.iv[31];
	local[4]= argv[0]->c.obj.iv[32];
	ctx->vsp=local+5;
	w=(pointer)VMINUS(ctx,2,local+3); /*v-*/
	local[3]= w;
	local[4]= argv[7];
	local[5]= fqv[71];
	local[6]= fqv[7];
	local[7]= makeflt(1.0000000000000000208167e-03);
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)VNORM(ctx,1,local+8); /*norm*/
	{ double x,y;
		y=fltval(w); x=fltval(local[7]);
		local[7]=(makeflt(x * y));}
	local[8]= argv[3];
	local[9]= makeint((eusinteger_t)60L);
	ctx->vsp=local+10;
	w=(pointer)LESSP(ctx,2,local+8); /*<*/
	if (w==NIL) goto irtvieweIF877;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= argv[6];
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[8]= w;
	goto irtvieweIF878;
irtvieweIF877:
	local[8]= makeint((eusinteger_t)-1L);
	local[9]= argv[5];
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[8]= w;
irtvieweIF878:
	ctx->vsp=local+9;
	w=(pointer)SCALEVEC(ctx,2,local+7); /*scale*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[86];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= local[4];
	local[7]= argv[0]->c.obj.iv[31];
	ctx->vsp=local+8;
	w=(pointer)VMINUS(ctx,2,local+6); /*v-*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= fqv[69];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= argv[0];
	local[8]= fqv[86];
	local[9]= local[5];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)VPLUS(ctx,2,local+9); /*v+*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[3]= w;
	goto irtvieweCON866;
irtvieweCON875:
	local[3]= NIL;
irtvieweCON866:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtvieweBLK865:
	ctx->vsp=local; return(local[0]);}

/*:set-cursor-pos-event*/
static pointer irtvieweM879irtviewer_set_cursor_pos_event(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[55],w);
	local[3]= loadglobal(fqv[55]);
	ctx->vsp=local+4;
	w=(*ftab[12])(ctx,1,local+3,&ftab[12],fqv[90]); /*event-pos*/
	argv[0]->c.obj.iv[28] = w;
	local[3]= argv[0]->c.obj.iv[28];
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtvieweBLK880:
	ctx->vsp=local; return(local[0]);}

/*:move-coords-event*/
static pointer irtvieweM881irtviewer_move_coords_event(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[55],w);
	if (argv[0]->c.obj.iv[28]!=NIL) goto irtvieweIF883;
	local[3]= loadglobal(fqv[55]);
	ctx->vsp=local+4;
	w=(*ftab[12])(ctx,1,local+3,&ftab[12],fqv[90]); /*event-pos*/
	argv[0]->c.obj.iv[28] = w;
	local[3]= argv[0]->c.obj.iv[28];
	goto irtvieweIF884;
irtvieweIF883:
	local[3]= NIL;
irtvieweIF884:
	local[3]= loadglobal(fqv[55]);
	ctx->vsp=local+4;
	w=(*ftab[12])(ctx,1,local+3,&ftab[12],fqv[90]); /*event-pos*/
	local[3]= w;
	local[4]= local[3];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= local[3];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= local[4];
	local[7]= argv[0]->c.obj.iv[28];
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	local[7]= local[5];
	local[8]= argv[0]->c.obj.iv[28];
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,2,local+7); /*-*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= fqv[91];
	local[10]= loadglobal(fqv[55]);
	local[11]= local[4];
	local[12]= local[5];
	local[13]= local[6];
	local[14]= local[7];
	local[15]= argv[0]->c.obj.iv[25];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,8,local+8); /*send*/
	local[8]= argv[0];
	local[9]= fqv[53];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= argv[0];
	local[9]= fqv[14];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	argv[0]->c.obj.iv[28] = local[3];
	w = argv[0]->c.obj.iv[28];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtvieweBLK882:
	ctx->vsp=local; return(local[0]);}

/*:draw-event*/
static pointer irtvieweM885irtviewer_draw_event(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[55],w);
	local[3]= argv[0];
	local[4]= fqv[14];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtvieweBLK886:
	ctx->vsp=local; return(local[0]);}

/*:draw-objects*/
static pointer irtvieweM887irtviewer_draw_objects(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtvieweRST889:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[25];
	local[2]= fqv[44];
	local[3]= fqv[57];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	if (argv[0]->c.obj.iv[38]==NIL) goto irtvieweIF890;
	local[1]= argv[0];
	local[2]= fqv[92];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	goto irtvieweIF891;
irtvieweIF890:
	local[1]= NIL;
irtvieweIF891:
	local[1]= (pointer)get_sym_func(fqv[93]);
	local[2]= argv[0]->c.obj.iv[25];
	local[3]= argv[0]->c.obj.iv[27];
	local[4]= fqv[94];
	local[5]= argv[0]->c.obj.iv[34];
	local[6]= fqv[95];
	local[7]= argv[0]->c.obj.iv[35];
	local[8]= fqv[96];
	local[9]= argv[0]->c.obj.iv[36];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)APPLY(ctx,10,local+1); /*apply*/
	local[0]= w;
irtvieweBLK888:
	ctx->vsp=local; return(local[0]);}

/*:objects*/
static pointer irtvieweM892irtviewer_objects(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtvieweRST894:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	if (local[0]==NIL) goto irtvieweIF895;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car!=NIL) goto irtvieweCON898;
	argv[0]->c.obj.iv[26] = NIL;
	local[1]= argv[0]->c.obj.iv[26];
	goto irtvieweCON897;
irtvieweCON898:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!iscons(w)) goto irtvieweCON899;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[26] = (w)->c.cons.car;
	local[1]= argv[0]->c.obj.iv[26];
	goto irtvieweCON897;
irtvieweCON899:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!!iscons(w)) goto irtvieweCON900;
	local[1]= local[0];
	local[2]= argv[0]->c.obj.iv[26];
	ctx->vsp=local+3;
	w=(pointer)APPEND(ctx,2,local+1); /*append*/
	argv[0]->c.obj.iv[26] = w;
	local[1]= argv[0]->c.obj.iv[26];
	goto irtvieweCON897;
irtvieweCON900:
	local[1]= NIL;
irtvieweCON897:
	goto irtvieweIF896;
irtvieweIF895:
	local[1]= NIL;
irtvieweIF896:
	local[1]= argv[0]->c.obj.iv[26];
	local[2]= fqv[74];
	ctx->vsp=local+3;
	w=(*ftab[5])(ctx,2,local+1,&ftab[5],fqv[75]); /*send-all*/
	local[1]= argv[0]->c.obj.iv[26];
	ctx->vsp=local+2;
	w=(pointer)irtvieweF779draw_things(ctx,1,local+1); /*draw-things*/
	argv[0]->c.obj.iv[27] = w;
	w = argv[0]->c.obj.iv[26];
	local[0]= w;
irtvieweBLK893:
	ctx->vsp=local; return(local[0]);}

/*:select-drawmode*/
static pointer irtvieweM901irtviewer_select_drawmode(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	if (argv[0]->c.obj.iv[33]==local[0]) goto irtvieweIF903;
	local[0]= argv[0];
	local[1]= fqv[70];
	local[2]= fqv[44];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= *(ovafptr(w,fqv[97]));
	local[1]= NIL;
	local[2]= argv[0]->c.obj.iv[27];
irtvieweWHL905:
	if (local[2]==NIL) goto irtvieweWHX906;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= local[1];
	local[4]= fqv[98];
	ctx->vsp=local+5;
	w=(pointer)GETPROP(ctx,2,local+3); /*get*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[13])(ctx,1,local+3,&ftab[13],fqv[99]); /*gl::delete-displaylist-id*/
	local[3]= local[1];
	local[4]= NIL;
	local[5]= fqv[98];
	ctx->vsp=local+6;
	w=(pointer)PUTPROP(ctx,3,local+3); /*putprop*/
	local[3]= argv[2];
	local[4]= local[3];
	if (fqv[100]!=local[4]) goto irtvieweIF908;
	local[4]= local[1];
	local[5]= local[0];
	w = T;
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	local[5]= w;
	local[6]= fqv[101];
	ctx->vsp=local+7;
	w=(pointer)PUTPROP(ctx,3,local+4); /*putprop*/
	local[4]= w;
	goto irtvieweIF909;
irtvieweIF908:
	if (T==NIL) goto irtvieweIF910;
	local[4]= local[1];
	local[5]= NIL;
	local[6]= fqv[101];
	ctx->vsp=local+7;
	w=(pointer)PUTPROP(ctx,3,local+4); /*putprop*/
	local[4]= w;
	goto irtvieweIF911;
irtvieweIF910:
	local[4]= NIL;
irtvieweIF911:
irtvieweIF909:
	w = local[4];
	goto irtvieweWHL905;
irtvieweWHX906:
	local[3]= NIL;
irtvieweBLK907:
	w = NIL;
	local[0]= w;
	goto irtvieweIF904;
irtvieweIF903:
	local[0]= NIL;
irtvieweIF904:
	argv[0]->c.obj.iv[33] = argv[2];
	w = argv[0]->c.obj.iv[33];
	local[0]= w;
irtvieweBLK902:
	ctx->vsp=local; return(local[0]);}

/*:flush*/
static pointer irtvieweM912irtviewer_flush(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[25]==NIL) goto irtvieweIF914;
	local[0]= argv[0]->c.obj.iv[25];
	local[1]= fqv[44];
	local[2]= fqv[102];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto irtvieweIF915;
irtvieweIF914:
	local[0]= NIL;
irtvieweIF915:
	w = local[0];
	local[0]= w;
irtvieweBLK913:
	ctx->vsp=local; return(local[0]);}

/*:change-background*/
static pointer irtvieweM916irtviewer_change_background(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[70];
	local[2]= fqv[44];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[57];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= argv[2];
	local[2]= local[1];
	*(ovafptr(local[0],fqv[103])) = local[2];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(*ftab[14])(ctx,1,local+1,&ftab[14],fqv[104]); /*gl:glclearcolorfv*/
	local[0]= w;
irtvieweBLK917:
	ctx->vsp=local; return(local[0]);}

/*:draw-origin*/
static pointer irtvieweM918irtviewer_draw_origin(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtvieweENT921;}
	local[0]= fqv[105];
irtvieweENT921:
irtvieweENT920:
	if (n>3) maerror();
	local[1]= local[0];
	if (fqv[105]==local[1]) goto irtvieweIF922;
	argv[0]->c.obj.iv[34] = local[0];
	local[1]= argv[0]->c.obj.iv[34];
	goto irtvieweIF923;
irtvieweIF922:
	local[1]= argv[0]->c.obj.iv[34];
irtvieweIF923:
	w = local[1];
	local[0]= w;
irtvieweBLK919:
	ctx->vsp=local; return(local[0]);}

/*:draw-floor*/
static pointer irtvieweM924irtviewer_draw_floor(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtvieweENT927;}
	local[0]= fqv[105];
irtvieweENT927:
irtvieweENT926:
	if (n>3) maerror();
	local[1]= local[0];
	if (fqv[105]==local[1]) goto irtvieweIF928;
	argv[0]->c.obj.iv[35] = local[0];
	local[1]= argv[0]->c.obj.iv[35];
	goto irtvieweIF929;
irtvieweIF928:
	local[1]= argv[0]->c.obj.iv[35];
irtvieweIF929:
	w = local[1];
	local[0]= w;
irtvieweBLK925:
	ctx->vsp=local; return(local[0]);}

/*:floor-color*/
static pointer irtvieweM930irtviewer_floor_color(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtvieweENT933;}
	local[0]= fqv[105];
irtvieweENT933:
irtvieweENT932:
	if (n>3) maerror();
	local[1]= local[0];
	if (fqv[105]==local[1]) goto irtvieweIF934;
	argv[0]->c.obj.iv[36] = local[0];
	local[1]= argv[0]->c.obj.iv[36];
	goto irtvieweIF935;
irtvieweIF934:
	local[1]= argv[0]->c.obj.iv[36];
irtvieweIF935:
	w = local[1];
	local[0]= w;
irtvieweBLK931:
	ctx->vsp=local; return(local[0]);}

/*make-mpeg-from-images*/
static pointer irtvieweF777make_mpeg_from_images(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[106], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtvieweKEY937;
	local[0] = T;
irtvieweKEY937:
	if (n & (1<<1)) goto irtvieweKEY938;
	local[1] = makeint((eusinteger_t)1L);
irtvieweKEY938:
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[15])(ctx,1,local+3,&ftab[15],fqv[107]); /*pathname-name*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)65536L);
	ctx->vsp=local+5;
	w=(pointer)RANDOM(ctx,1,local+4); /*random*/
	local[4]= w;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= fqv[108];
	ctx->vsp=local+8;
	w=(pointer)SYSTEM(ctx,1,local+7); /*unix:system*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(*ftab[4])(ctx,2,local+7,&ftab[4],fqv[67]); /*/=*/
	if (w==NIL) goto irtvieweIF939;
	local[7]= makeint((eusinteger_t)1L);
	local[8]= fqv[109];
	ctx->vsp=local+9;
	w=(*ftab[8])(ctx,2,local+7,&ftab[8],fqv[85]); /*warning-message*/
	w = NIL;
	ctx->vsp=local+7;
	local[0]=w;
	goto irtvieweBLK936;
	goto irtvieweIF940;
irtvieweIF939:
	local[7]= NIL;
irtvieweIF940:
	local[7]= fqv[110];
	ctx->vsp=local+8;
	w=(pointer)SYSTEM(ctx,1,local+7); /*unix:system*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(*ftab[4])(ctx,2,local+7,&ftab[4],fqv[67]); /*/=*/
	if (w==NIL) goto irtvieweIF941;
	local[7]= makeint((eusinteger_t)1L);
	local[8]= fqv[111];
	ctx->vsp=local+9;
	w=(*ftab[8])(ctx,2,local+7,&ftab[8],fqv[85]); /*warning-message*/
	w = NIL;
	ctx->vsp=local+7;
	local[0]=w;
	goto irtvieweBLK936;
	goto irtvieweIF942;
irtvieweIF941:
	local[7]= NIL;
irtvieweIF942:
	local[7]= fqv[112];
	local[8]= local[3];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
	w = makeint((eusinteger_t)4L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[9]= (pointer)((eusinteger_t)local[9] - (eusinteger_t)w);
	ctx->vsp=local+10;
	w=(pointer)SUBSEQ(ctx,2,local+8); /*subseq*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[16])(ctx,2,local+7,&ftab[16],fqv[113]); /*string=*/
	if (w==NIL) goto irtvieweIF943;
	local[7]= local[3];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
	w = makeint((eusinteger_t)4L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[9]= (pointer)((eusinteger_t)local[9] - (eusinteger_t)w);
	ctx->vsp=local+10;
	w=(pointer)SUBSEQ(ctx,3,local+7); /*subseq*/
	local[3] = w;
	local[7]= local[3];
	goto irtvieweIF944;
irtvieweIF943:
	local[7]= NIL;
irtvieweIF944:
	local[7]= NIL;
	local[8]= argv[1];
irtvieweWHL945:
	if (local[8]==NIL) goto irtvieweWHX946;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[9];
	local[7] = w;
	local[9]= NIL;
	local[10]= fqv[114];
	local[11]= local[3];
	local[12]= local[4];
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(pointer)XFORMAT(ctx,5,local+9); /*format*/
	local[5] = w;
	local[9]= local[7];
	local[10]= fqv[22];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[17])(ctx,1,local+9,&ftab[17],fqv[115]); /*oddp*/
	if (w==NIL) goto irtvieweCON949;
	local[9]= NIL;
	local[10]= fqv[116];
	local[11]= local[3];
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,4,local+9); /*format*/
	local[9]= w;
	local[10]= local[7];
	ctx->vsp=local+11;
	w=(*ftab[18])(ctx,2,local+9,&ftab[18],fqv[117]); /*user::write-image-file*/
	local[9]= NIL;
	local[10]= fqv[118];
	local[11]= NIL;
	local[12]= fqv[119];
	local[13]= local[3];
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(pointer)XFORMAT(ctx,4,local+11); /*format*/
	local[11]= w;
	local[12]= local[7];
	local[13]= fqv[22];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)2L);
	ctx->vsp=local+14;
	w=(pointer)QUOTIENT(ctx,2,local+12); /*/*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)ROUND(ctx,1,local+12); /*round*/
	local[12]= w;
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)2L)); i=intval(local[12]);
		local[12]=(makeint(i * j));}
	local[13]= local[7];
	local[14]= fqv[23];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	local[14]= makeint((eusinteger_t)2L);
	ctx->vsp=local+15;
	w=(pointer)QUOTIENT(ctx,2,local+13); /*/*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)ROUND(ctx,1,local+13); /*round*/
	local[13]= w;
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)2L)); i=intval(local[13]);
		local[13]=(makeint(i * j));}
	local[14]= local[5];
	ctx->vsp=local+15;
	w=(pointer)XFORMAT(ctx,6,local+9); /*format*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SYSTEM(ctx,1,local+9); /*unix:system*/
	local[9]= w;
	goto irtvieweCON948;
irtvieweCON949:
	local[9]= local[5];
	local[10]= local[7];
	ctx->vsp=local+11;
	w=(*ftab[18])(ctx,2,local+9,&ftab[18],fqv[117]); /*user::write-image-file*/
	local[9]= w;
	goto irtvieweCON948;
irtvieweCON950:
	local[9]= NIL;
irtvieweCON948:
	local[9]= T;
	local[10]= fqv[120];
	local[11]= local[5];
	local[12]= argv[1];
	ctx->vsp=local+13;
	w=(pointer)LENGTH(ctx,1,local+12); /*length*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)13L);
	ctx->vsp=local+14;
	w=(pointer)XFORMAT(ctx,5,local+9); /*format*/
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[2] = w;
	goto irtvieweWHL945;
irtvieweWHX946:
	local[9]= NIL;
irtvieweBLK947:
	w = NIL;
	local[7]= NIL;
	local[8]= fqv[121];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)XFORMAT(ctx,3,local+7); /*format*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SYSTEM(ctx,1,local+7); /*unix:system*/
	local[7]= NIL;
	local[8]= fqv[122];
	local[9]= makeint((eusinteger_t)25L);
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[9]= w;
	local[10]= local[3];
	local[11]= local[4];
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,6,local+7); /*format*/
	local[6] = w;
	if (loadglobal(fqv[63])==NIL) goto irtvieweIF951;
	local[7]= local[6];
	ctx->vsp=local+8;
	w=(*ftab[3])(ctx,1,local+7,&ftab[3],fqv[65]); /*warn*/
	local[7]= w;
	goto irtvieweIF952;
irtvieweIF951:
	local[7]= NIL;
irtvieweIF952:
	local[7]= local[6];
	ctx->vsp=local+8;
	w=(pointer)SYSTEM(ctx,1,local+7); /*unix:system*/
	local[7]= T;
	local[8]= fqv[123];
	local[9]= local[3];
	local[10]= argv[1];
	ctx->vsp=local+11;
	w=(pointer)LENGTH(ctx,1,local+10); /*length*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,4,local+7); /*format*/
	if (local[0]==NIL) goto irtvieweIF953;
	local[7]= NIL;
	local[8]= fqv[124];
	local[9]= local[3];
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,4,local+7); /*format*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SYSTEM(ctx,1,local+7); /*unix:system*/
	local[7]= w;
	goto irtvieweIF954;
irtvieweIF953:
	local[7]= NIL;
irtvieweIF954:
	w = local[7];
	local[0]= w;
irtvieweBLK936:
	ctx->vsp=local; return(local[0]);}

/*make-animgif-from-images*/
static pointer irtvieweF778make_animgif_from_images(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[125], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtvieweKEY956;
	local[0] = T;
irtvieweKEY956:
	if (n & (1<<1)) goto irtvieweKEY957;
	local[1] = NIL;
irtvieweKEY957:
	if (n & (1<<2)) goto irtvieweKEY958;
	local[2] = T;
irtvieweKEY958:
	if (n & (1<<3)) goto irtvieweKEY959;
	local[3] = makeint((eusinteger_t)10L);
irtvieweKEY959:
	if (n & (1<<4)) goto irtvieweKEY960;
	local[4] = fqv[126];
irtvieweKEY960:
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(*ftab[15])(ctx,1,local+6,&ftab[15],fqv[107]); /*pathname-name*/
	local[6]= w;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= fqv[127];
	local[10]= NIL;
	local[11]= fqv[128];
	ctx->vsp=local+12;
	w=(pointer)SYSTEM(ctx,1,local+11); /*unix:system*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(*ftab[4])(ctx,2,local+11,&ftab[4],fqv[67]); /*/=*/
	if (w==NIL) goto irtvieweIF961;
	local[11]= makeint((eusinteger_t)1L);
	local[12]= fqv[129];
	ctx->vsp=local+13;
	w=(*ftab[8])(ctx,2,local+11,&ftab[8],fqv[85]); /*warning-message*/
	w = NIL;
	ctx->vsp=local+11;
	local[0]=w;
	goto irtvieweBLK955;
	goto irtvieweIF962;
irtvieweIF961:
	local[11]= NIL;
irtvieweIF962:
	local[11]= fqv[130];
	ctx->vsp=local+12;
	w=(pointer)SYSTEM(ctx,1,local+11); /*unix:system*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(*ftab[4])(ctx,2,local+11,&ftab[4],fqv[67]); /*/=*/
	if (w==NIL) goto irtvieweIF963;
	local[11]= makeint((eusinteger_t)1L);
	local[12]= fqv[131];
	ctx->vsp=local+13;
	w=(*ftab[8])(ctx,2,local+11,&ftab[8],fqv[85]); /*warning-message*/
	w = NIL;
	ctx->vsp=local+11;
	local[0]=w;
	goto irtvieweBLK955;
	goto irtvieweIF964;
irtvieweIF963:
	local[11]= NIL;
irtvieweIF964:
	local[11]= fqv[132];
	local[12]= local[6];
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(pointer)LENGTH(ctx,1,local+13); /*length*/
	local[13]= w;
	w = makeint((eusinteger_t)4L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[13]= (pointer)((eusinteger_t)local[13] - (eusinteger_t)w);
	ctx->vsp=local+14;
	w=(pointer)SUBSEQ(ctx,2,local+12); /*subseq*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(*ftab[16])(ctx,2,local+11,&ftab[16],fqv[113]); /*string=*/
	if (w==NIL) goto irtvieweIF965;
	local[11]= local[6];
	local[12]= makeint((eusinteger_t)0L);
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(pointer)LENGTH(ctx,1,local+13); /*length*/
	local[13]= w;
	w = makeint((eusinteger_t)4L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[13]= (pointer)((eusinteger_t)local[13] - (eusinteger_t)w);
	ctx->vsp=local+14;
	w=(pointer)SUBSEQ(ctx,3,local+11); /*subseq*/
	local[6] = w;
	local[11]= local[6];
	goto irtvieweIF966;
irtvieweIF965:
	local[11]= NIL;
irtvieweIF966:
	local[11]= NIL;
	local[12]= fqv[133];
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(pointer)XFORMAT(ctx,3,local+11); /*format*/
	local[7] = w;
	local[11]= NIL;
	local[12]= argv[1];
irtvieweWHL967:
	if (local[12]==NIL) goto irtvieweWHX968;
	w=local[12];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	w=local[12];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12] = (w)->c.cons.cdr;
	w = local[13];
	local[11] = w;
	local[13]= NIL;
	local[14]= fqv[134];
	local[15]= local[6];
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(pointer)XFORMAT(ctx,4,local+13); /*format*/
	local[8] = w;
	local[13]= NIL;
	local[14]= fqv[135];
	local[15]= local[5];
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,3,local+13); /*format*/
	local[7] = w;
	local[13]= loadglobal(fqv[136]);
	local[14]= local[9];
	local[15]= fqv[137];
	local[16]= local[7];
	ctx->vsp=local+17;
	w=(pointer)CONCATENATE(ctx,4,local+13); /*concatenate*/
	local[9] = w;
	local[13]= local[8];
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(*ftab[18])(ctx,2,local+13,&ftab[18],fqv[117]); /*user::write-image-file*/
	local[13]= T;
	local[14]= fqv[138];
	local[15]= local[8];
	local[16]= argv[1];
	ctx->vsp=local+17;
	w=(pointer)LENGTH(ctx,1,local+16); /*length*/
	local[16]= w;
	local[17]= makeint((eusinteger_t)13L);
	ctx->vsp=local+18;
	w=(pointer)XFORMAT(ctx,5,local+13); /*format*/
	local[13]= T;
	ctx->vsp=local+14;
	w=(pointer)FINOUT(ctx,1,local+13); /*finish-output*/
	local[13]= NIL;
	local[14]= fqv[139];
	local[15]= local[8];
	local[16]= local[7];
	ctx->vsp=local+17;
	w=(pointer)XFORMAT(ctx,4,local+13); /*format*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SYSTEM(ctx,1,local+13); /*unix:system*/
	if (local[0]==NIL) goto irtvieweIF970;
	local[13]= NIL;
	local[14]= fqv[140];
	local[15]= local[8];
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,3,local+13); /*format*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SYSTEM(ctx,1,local+13); /*unix:system*/
	local[13]= w;
	goto irtvieweIF971;
irtvieweIF970:
	local[13]= NIL;
irtvieweIF971:
	local[13]= local[5];
	ctx->vsp=local+14;
	w=(pointer)ADD1(ctx,1,local+13); /*1+*/
	local[5] = w;
	goto irtvieweWHL967;
irtvieweWHX968:
	local[13]= NIL;
irtvieweBLK969:
	w = NIL;
	local[11]= NIL;
	local[12]= fqv[141];
	local[13]= local[3];
	if (local[1]==NIL) goto irtvieweIF972;
	local[14]= NIL;
	local[15]= fqv[142];
	local[16]= local[4];
	ctx->vsp=local+17;
	w=(pointer)XFORMAT(ctx,3,local+14); /*format*/
	local[14]= w;
	goto irtvieweIF973;
irtvieweIF972:
	local[14]= fqv[143];
irtvieweIF973:
	if (local[2]==NIL) goto irtvieweIF974;
	local[15]= fqv[144];
	goto irtvieweIF975;
irtvieweIF974:
	local[15]= fqv[145];
irtvieweIF975:
	local[16]= local[9];
	local[17]= local[6];
	ctx->vsp=local+18;
	w=(pointer)XFORMAT(ctx,7,local+11); /*format*/
	local[10] = w;
	if (loadglobal(fqv[63])==NIL) goto irtvieweIF976;
	local[11]= local[10];
	ctx->vsp=local+12;
	w=(*ftab[3])(ctx,1,local+11,&ftab[3],fqv[65]); /*warn*/
	local[11]= w;
	goto irtvieweIF977;
irtvieweIF976:
	local[11]= NIL;
irtvieweIF977:
	local[11]= local[10];
	ctx->vsp=local+12;
	w=(pointer)SYSTEM(ctx,1,local+11); /*unix:system*/
	local[11]= T;
	local[12]= fqv[146];
	local[13]= local[6];
	local[14]= argv[1];
	ctx->vsp=local+15;
	w=(pointer)LENGTH(ctx,1,local+14); /*length*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)XFORMAT(ctx,4,local+11); /*format*/
	if (local[0]==NIL) goto irtvieweIF978;
	local[11]= NIL;
	local[12]= fqv[147];
	local[13]= local[9];
	ctx->vsp=local+14;
	w=(pointer)XFORMAT(ctx,3,local+11); /*format*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SYSTEM(ctx,1,local+11); /*unix:system*/
	local[11]= w;
	goto irtvieweIF979;
irtvieweIF978:
	local[11]= NIL;
irtvieweIF979:
	w = local[11];
	local[0]= w;
irtvieweBLK955:
	ctx->vsp=local; return(local[0]);}

/*:logging*/
static pointer irtvieweM980irtviewer_logging(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtvieweENT983;}
	local[0]= fqv[148];
irtvieweENT983:
irtvieweENT982:
	if (n>3) maerror();
	local[1]= local[0];
	local[2]= local[1];
	w = fqv[149];
	if (memq(local[2],w)==NIL) goto irtvieweIF984;
	local[2]= argv[0];
	local[3]= fqv[150];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	goto irtvieweIF985;
irtvieweIF984:
	local[2]= local[1];
	w = fqv[151];
	if (memq(local[2],w)==NIL) goto irtvieweIF986;
	argv[0]->c.obj.iv[38] = T;
	local[2]= argv[0];
	local[3]= fqv[92];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	goto irtvieweIF987;
irtvieweIF986:
	local[2]= local[1];
	w = fqv[152];
	if (memq(local[2],w)==NIL) goto irtvieweIF988;
	local[2]= argv[0];
	local[3]= fqv[153];
	local[4]= fqv[154];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[153];
	local[4]= fqv[155];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto irtvieweIF989;
irtvieweIF988:
	local[2]= local[1];
	w = fqv[156];
	if (memq(local[2],w)==NIL) goto irtvieweIF990;
	local[2]= argv[0];
	local[3]= fqv[92];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	argv[0]->c.obj.iv[38] = NIL;
	local[2]= argv[0]->c.obj.iv[38];
	goto irtvieweIF991;
irtvieweIF990:
	local[2]= NIL;
irtvieweIF991:
irtvieweIF989:
irtvieweIF987:
irtvieweIF985:
	w = local[2];
	local[0]= w;
irtvieweBLK981:
	ctx->vsp=local; return(local[0]);}

/*:clear-log*/
static pointer irtvieweM992irtviewer_clear_log(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[150];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
irtvieweBLK993:
	ctx->vsp=local; return(local[0]);}

/*:push-image*/
static pointer irtvieweM994irtviewer_push_image(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[25];
	local[1]= fqv[44];
	local[2]= fqv[157];
	local[3]= fqv[22];
	local[4]= argv[0]->c.obj.iv[25];
	local[5]= fqv[44];
	local[6]= fqv[22];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	local[5]= fqv[23];
	local[6]= argv[0]->c.obj.iv[25];
	local[7]= fqv[44];
	local[8]= fqv[23];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,7,local+0); /*send*/
	local[0]= w;
	w = argv[0]->c.obj.iv[37];
	ctx->vsp=local+1;
	argv[0]->c.obj.iv[37] = cons(ctx,local[0],w);
	w = argv[0]->c.obj.iv[37];
	local[0]= w;
irtvieweBLK995:
	ctx->vsp=local; return(local[0]);}

/*:clear-image-sequence*/
static pointer irtvieweM996irtviewer_clear_image_sequence(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	argv[0]->c.obj.iv[37] = NIL;
	w = argv[0]->c.obj.iv[37];
	local[0]= w;
irtvieweBLK997:
	ctx->vsp=local; return(local[0]);}

/*:image-sequence*/
static pointer irtvieweM998irtviewer_image_sequence(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[37];
	ctx->vsp=local+1;
	w=(pointer)REVERSE(ctx,1,local+0); /*reverse*/
	local[0]= w;
irtvieweBLK999:
	ctx->vsp=local; return(local[0]);}

/*:save-mpeg*/
static pointer irtvieweM1000irtviewer_save_mpeg(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[158], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtvieweKEY1002;
	local[0] = fqv[159];
irtvieweKEY1002:
	if (n & (1<<1)) goto irtvieweKEY1003;
	local[1] = makeint((eusinteger_t)5L);
irtvieweKEY1003:
	if (n & (1<<2)) goto irtvieweKEY1004;
	local[2] = T;
irtvieweKEY1004:
	local[3]= argv[0];
	local[4]= fqv[70];
	local[5]= fqv[44];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= *(ovafptr(w,fqv[103]));
	local[4]= argv[0];
	local[5]= fqv[160];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	if (w!=NIL) goto irtvieweIF1005;
	local[4]= argv[0];
	local[5]= fqv[92];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	goto irtvieweIF1006;
irtvieweIF1005:
	local[4]= NIL;
irtvieweIF1006:
	local[4]= local[0];
	local[5]= argv[0];
	local[6]= fqv[160];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= fqv[161];
	local[7]= local[1];
	local[8]= fqv[162];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)irtvieweF777make_mpeg_from_images(ctx,6,local+4); /*make-mpeg-from-images*/
	local[0]= w;
irtvieweBLK1001:
	ctx->vsp=local; return(local[0]);}

/*:save-animgif*/
static pointer irtvieweM1007irtviewer_save_animgif(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[163], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtvieweKEY1009;
	local[0] = fqv[164];
irtvieweKEY1009:
	if (n & (1<<1)) goto irtvieweKEY1010;
	local[1] = makeint((eusinteger_t)5L);
irtvieweKEY1010:
	if (n & (1<<2)) goto irtvieweKEY1011;
	local[2] = T;
irtvieweKEY1011:
	if (n & (1<<3)) goto irtvieweKEY1012;
	local[3] = T;
irtvieweKEY1012:
	if (n & (1<<4)) goto irtvieweKEY1013;
	local[4] = T;
irtvieweKEY1013:
	local[5]= argv[0];
	local[6]= fqv[70];
	local[7]= fqv[44];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= *(ovafptr(w,fqv[103]));
	local[6]= argv[0];
	local[7]= fqv[160];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	if (w!=NIL) goto irtvieweIF1014;
	local[6]= argv[0];
	local[7]= fqv[92];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	goto irtvieweIF1015;
irtvieweIF1014:
	local[6]= NIL;
irtvieweIF1015:
	local[6]= local[0];
	local[7]= argv[0];
	local[8]= fqv[160];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= fqv[161];
	local[9]= local[1];
	local[10]= fqv[165];
	local[11]= local[3];
	local[12]= fqv[162];
	local[13]= local[4];
	local[14]= fqv[166];
	local[15]= local[2];
	local[16]= fqv[167];
	local[17]= local[5];
	ctx->vsp=local+18;
	w=(*ftab[19])(ctx,1,local+17,&ftab[19],fqv[168]); /*float-vector-p*/
	if (w==NIL) goto irtvieweCON1017;
	local[17]= NIL;
	local[18]= fqv[169];
	local[19]= makeint((eusinteger_t)255L);
	local[20]= makeint((eusinteger_t)1L);
	local[21]= local[5];
	local[22]= makeint((eusinteger_t)0L);
	ctx->vsp=local+23;
	w=(pointer)ELT(ctx,2,local+21); /*elt*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)MIN(ctx,2,local+20); /*min*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)TIMES(ctx,2,local+19); /***/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)ROUND(ctx,1,local+19); /*round*/
	local[19]= w;
	local[20]= makeint((eusinteger_t)255L);
	local[21]= makeint((eusinteger_t)1L);
	local[22]= local[5];
	local[23]= makeint((eusinteger_t)1L);
	ctx->vsp=local+24;
	w=(pointer)ELT(ctx,2,local+22); /*elt*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)MIN(ctx,2,local+21); /*min*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)ROUND(ctx,1,local+20); /*round*/
	local[20]= w;
	local[21]= makeint((eusinteger_t)255L);
	local[22]= makeint((eusinteger_t)1L);
	local[23]= local[5];
	local[24]= makeint((eusinteger_t)2L);
	ctx->vsp=local+25;
	w=(pointer)ELT(ctx,2,local+23); /*elt*/
	local[23]= w;
	ctx->vsp=local+24;
	w=(pointer)MIN(ctx,2,local+22); /*min*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)TIMES(ctx,2,local+21); /***/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)ROUND(ctx,1,local+21); /*round*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)XFORMAT(ctx,5,local+17); /*format*/
	local[17]= w;
	goto irtvieweCON1016;
irtvieweCON1017:
	local[17]= fqv[170];
	goto irtvieweCON1016;
irtvieweCON1018:
	local[17]= NIL;
irtvieweCON1016:
	ctx->vsp=local+18;
	w=(pointer)irtvieweF778make_animgif_from_images(ctx,12,local+6); /*make-animgif-from-images*/
	local[0]= w;
irtvieweBLK1008:
	ctx->vsp=local; return(local[0]);}

/*:save-animgif*/
static pointer irtvieweM1019irtviewer_save_animgif(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[171], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtvieweKEY1021;
	local[0] = fqv[172];
irtvieweKEY1021:
	if (n & (1<<1)) goto irtvieweKEY1022;
	local[1] = makeint((eusinteger_t)5L);
irtvieweKEY1022:
	if (n & (1<<2)) goto irtvieweKEY1023;
	local[2] = T;
irtvieweKEY1023:
	if (n & (1<<3)) goto irtvieweKEY1024;
	local[3] = T;
irtvieweKEY1024:
	if (n & (1<<4)) goto irtvieweKEY1025;
	local[4] = T;
irtvieweKEY1025:
	local[5]= argv[0];
	local[6]= fqv[70];
	local[7]= fqv[44];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= *(ovafptr(w,fqv[103]));
	local[6]= argv[0];
	local[7]= fqv[160];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	if (w!=NIL) goto irtvieweIF1026;
	local[6]= argv[0];
	local[7]= fqv[92];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	goto irtvieweIF1027;
irtvieweIF1026:
	local[6]= NIL;
irtvieweIF1027:
	local[6]= local[0];
	local[7]= argv[0];
	local[8]= fqv[160];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= fqv[161];
	local[9]= local[1];
	local[10]= fqv[165];
	local[11]= local[3];
	local[12]= fqv[162];
	local[13]= local[4];
	local[14]= fqv[166];
	local[15]= local[2];
	local[16]= fqv[167];
	local[17]= local[5];
	ctx->vsp=local+18;
	w=(*ftab[19])(ctx,1,local+17,&ftab[19],fqv[168]); /*float-vector-p*/
	if (w==NIL) goto irtvieweCON1029;
	local[17]= NIL;
	local[18]= fqv[173];
	local[19]= makeint((eusinteger_t)255L);
	local[20]= makeint((eusinteger_t)1L);
	local[21]= local[5];
	local[22]= makeint((eusinteger_t)0L);
	ctx->vsp=local+23;
	w=(pointer)ELT(ctx,2,local+21); /*elt*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)MIN(ctx,2,local+20); /*min*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)TIMES(ctx,2,local+19); /***/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)ROUND(ctx,1,local+19); /*round*/
	local[19]= w;
	local[20]= makeint((eusinteger_t)255L);
	local[21]= makeint((eusinteger_t)1L);
	local[22]= local[5];
	local[23]= makeint((eusinteger_t)1L);
	ctx->vsp=local+24;
	w=(pointer)ELT(ctx,2,local+22); /*elt*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)MIN(ctx,2,local+21); /*min*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)ROUND(ctx,1,local+20); /*round*/
	local[20]= w;
	local[21]= makeint((eusinteger_t)255L);
	local[22]= makeint((eusinteger_t)1L);
	local[23]= local[5];
	local[24]= makeint((eusinteger_t)2L);
	ctx->vsp=local+25;
	w=(pointer)ELT(ctx,2,local+23); /*elt*/
	local[23]= w;
	ctx->vsp=local+24;
	w=(pointer)MIN(ctx,2,local+22); /*min*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)TIMES(ctx,2,local+21); /***/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)ROUND(ctx,1,local+21); /*round*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)XFORMAT(ctx,5,local+17); /*format*/
	local[17]= w;
	goto irtvieweCON1028;
irtvieweCON1029:
	local[17]= fqv[174];
	goto irtvieweCON1028;
irtvieweCON1030:
	local[17]= NIL;
irtvieweCON1028:
	ctx->vsp=local+18;
	w=(pointer)irtvieweF778make_animgif_from_images(ctx,12,local+6); /*make-animgif-from-images*/
	local[0]= w;
irtvieweBLK1020:
	ctx->vsp=local; return(local[0]);}

/*:save-image*/
static pointer irtvieweM1031irtviewer_save_image(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[25];
	local[2]= fqv[44];
	local[3]= fqv[157];
	local[4]= fqv[22];
	local[5]= argv[0]->c.obj.iv[25];
	local[6]= fqv[44];
	local[7]= fqv[22];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	local[6]= fqv[23];
	local[7]= argv[0]->c.obj.iv[25];
	local[8]= fqv[44];
	local[9]= fqv[23];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,7,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[18])(ctx,2,local+0,&ftab[18],fqv[117]); /*user::write-image-file*/
	local[0]= w;
irtvieweBLK1032:
	ctx->vsp=local; return(local[0]);}

/*draw-things*/
static pointer irtvieweF779draw_things(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	if (!!iscons(w)) goto irtvieweCON1035;
	if (argv[0]!=NIL) goto irtvieweCON1037;
	local[0]= NIL;
	goto irtvieweCON1036;
irtvieweCON1037:
	local[0]= argv[0];
	local[1]= fqv[175];
	ctx->vsp=local+2;
	w=(*ftab[20])(ctx,2,local+0,&ftab[20],fqv[176]); /*find-method*/
	if (w==NIL) goto irtvieweCON1038;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto irtvieweCON1036;
irtvieweCON1038:
	local[0]= argv[0];
	local[1]= fqv[177];
	ctx->vsp=local+2;
	w=(*ftab[20])(ctx,2,local+0,&ftab[20],fqv[176]); /*find-method*/
	if (w==NIL) goto irtvieweCON1039;
	local[0]= argv[0];
	local[1]= fqv[177];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto irtvieweCON1036;
irtvieweCON1039:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto irtvieweCON1036;
irtvieweCON1040:
	local[0]= NIL;
irtvieweCON1036:
	goto irtvieweCON1034;
irtvieweCON1035:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	ctx->vsp=local+1;
	w=(pointer)irtvieweF779draw_things(ctx,1,local+0); /*draw-things*/
	local[0]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	ctx->vsp=local+2;
	w=(pointer)irtvieweF779draw_things(ctx,1,local+1); /*draw-things*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPEND(ctx,2,local+0); /*append*/
	local[0]= w;
	goto irtvieweCON1034;
irtvieweCON1041:
	local[0]= NIL;
irtvieweCON1034:
	w = local[0];
	local[0]= w;
irtvieweBLK1033:
	ctx->vsp=local; return(local[0]);}

/*:look*/
static pointer irtvieweM1042viewing_look(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtvieweENT1046;}
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
irtvieweENT1046:
	if (n>=5) { local[1]=(argv[4]); goto irtvieweENT1045;}
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,3,local+1); /*float-vector*/
	local[1]= w;
irtvieweENT1045:
irtvieweENT1044:
	if (n>5) maerror();
	local[2]= local[0];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)VMINUS(ctx,2,local+2); /*v-*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)VNORMALIZE(ctx,1,local+2); /*normalize-vector*/
	local[2]= w;
	local[3]= local[2];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+3); /*v**/
	local[3]= w;
	local[4]= NIL;
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)VNORM(ctx,1,local+5); /*norm*/
	local[5]= w;
	local[6]= loadglobal(fqv[178]);
	ctx->vsp=local+7;
	w=(pointer)LESSP(ctx,2,local+5); /*<*/
	if (w==NIL) goto irtvieweIF1047;
	local[5]= local[2];
	local[6]= makeint((eusinteger_t)-1L);
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,3,local+6); /*float-vector*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+5); /*v**/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)VNORMALIZE(ctx,1,local+5); /*normalize-vector*/
	local[4] = w;
	local[5]= local[4];
	goto irtvieweIF1048;
irtvieweIF1047:
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)VNORMALIZE(ctx,1,local+5); /*normalize-vector*/
	local[4] = w;
	local[5]= local[4];
irtvieweIF1048:
	local[5]= local[4];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+5); /*v**/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)VNORMALIZE(ctx,1,local+5); /*normalize-vector*/
	local[1] = w;
	local[5]= makeflt(-1.0000000000000000000000e+00);
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)SCALEVEC(ctx,2,local+5); /*scale*/
	local[2] = w;
	local[5]= loadglobal(fqv[179]);
	local[6]= local[4];
	local[7]= local[1];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)CONCATENATE(ctx,4,local+5); /*concatenate*/
	local[5]= w;
	local[6]= w;
	w = argv[0]->c.obj.iv[1];
	w->c.obj.iv[1] = local[6];
	local[5]= argv[0]->c.obj.iv[1];
	local[6]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+7;
	w=(pointer)TRANSPOSE(ctx,2,local+5); /*transpose*/
	local[5]= argv[0];
	local[6]= fqv[180];
	local[7]= argv[2];
	local[8]= fqv[181];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= argv[0];
	local[6]= fqv[74];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[0]= w;
irtvieweBLK1043:
	ctx->vsp=local; return(local[0]);}

/*objects*/
static pointer irtvieweF780objects(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto irtvieweENT1052;}
	local[0]= T;
irtvieweENT1052:
	if (n>=2) { local[1]=(argv[1]); goto irtvieweENT1051;}
	local[1]= NIL;
irtvieweENT1051:
irtvieweENT1050:
	if (n>2) maerror();
	if (local[0]==NIL) goto irtvieweIF1053;
	local[2]= fqv[182];
	ctx->vsp=local+3;
	w=(pointer)BOUNDP(ctx,1,local+2); /*boundp*/
	if (w!=NIL) goto irtvieweIF1053;
	if (local[1]!=NIL) goto irtvieweIF1053;
	local[2]= fqv[183];
	ctx->vsp=local+3;
	w=(*ftab[3])(ctx,1,local+2,&ftab[3],fqv[65]); /*warn*/
	ctx->vsp=local+2;
	w=(pointer)irtvieweF781make_irtviewer(ctx,0,local+2); /*make-irtviewer*/
	local[2]= w;
	goto irtvieweIF1054;
irtvieweIF1053:
	local[2]= NIL;
irtvieweIF1054:
	if (local[1]!=NIL) goto irtvieweIF1055;
	local[1] = loadglobal(fqv[182]);
	local[2]= local[1];
	goto irtvieweIF1056;
irtvieweIF1055:
	local[2]= NIL;
irtvieweIF1056:
	local[2]= NIL;
	local[3]= local[0];
	if (T!=local[3]) goto irtvieweIF1057;
	local[3]= local[1];
	local[4]= fqv[184];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[2] = w;
	local[3]= local[2];
	goto irtvieweIF1058;
irtvieweIF1057:
	local[3]= local[1];
	local[4]= fqv[184];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[2] = w;
	local[3]= local[2];
irtvieweIF1058:
	local[3]= local[1];
	local[4]= fqv[185];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	w = local[2];
	local[0]= w;
irtvieweBLK1049:
	ctx->vsp=local; return(local[0]);}

/*make-irtviewer*/
static pointer irtvieweF781make_irtviewer(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
irtvieweRST1060:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	if (loadglobal(fqv[186])==NIL) goto irtvieweOR1063;
	local[1]= loadglobal(fqv[186]);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)NUMEQUAL(ctx,2,local+1); /*=*/
	if (w!=NIL) goto irtvieweOR1063;
	goto irtvieweCON1062;
irtvieweOR1063:
	local[1]= makeint((eusinteger_t)1L);
	local[2]= fqv[187];
	ctx->vsp=local+3;
	w=(*ftab[8])(ctx,2,local+1,&ftab[8],fqv[85]); /*warning-message*/
	local[1]= loadglobal(fqv[188]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	storeglobal(fqv[182],w);
	local[1]= loadglobal(fqv[189]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	storeglobal(fqv[33],w);
	local[1]= loadglobal(fqv[33]);
	local[2]= loadglobal(fqv[182]);
	local[3]= fqv[13];
	ctx->vsp=local+4;
	w=(pointer)PUTPROP(ctx,3,local+1); /*putprop*/
	local[1]= w;
	goto irtvieweCON1061;
irtvieweCON1062:
	local[1]= (pointer)get_sym_func(fqv[12]);
	local[2]= loadglobal(fqv[190]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= fqv[21];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[1]= w;
	storeglobal(fqv[182],w);
	goto irtvieweCON1061;
irtvieweCON1064:
	local[1]= NIL;
irtvieweCON1061:
	w = loadglobal(fqv[182]);
	local[0]= w;
irtvieweBLK1059:
	ctx->vsp=local; return(local[0]);}

/*:nomethod*/
static pointer irtvieweM1065viewer_dummy_nomethod(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtvieweRST1067:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	w = T;
	local[0]= w;
irtvieweBLK1066:
	ctx->vsp=local; return(local[0]);}

/*:objects*/
static pointer irtvieweM1068irtviewer_dummy_objects(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtvieweRST1070:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	if (local[0]==NIL) goto irtvieweIF1071;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car!=NIL) goto irtvieweCON1074;
	argv[0]->c.obj.iv[1] = NIL;
	local[1]= argv[0]->c.obj.iv[1];
	goto irtvieweCON1073;
irtvieweCON1074:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!iscons(w)) goto irtvieweCON1075;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[1] = (w)->c.cons.car;
	local[1]= argv[0]->c.obj.iv[1];
	goto irtvieweCON1073;
irtvieweCON1075:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!!iscons(w)) goto irtvieweCON1076;
	local[1]= local[0];
	local[2]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(pointer)APPEND(ctx,2,local+1); /*append*/
	argv[0]->c.obj.iv[1] = w;
	local[1]= argv[0]->c.obj.iv[1];
	goto irtvieweCON1073;
irtvieweCON1076:
	local[1]= NIL;
irtvieweCON1073:
	goto irtvieweIF1072;
irtvieweIF1071:
	local[1]= NIL;
irtvieweIF1072:
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= fqv[74];
	ctx->vsp=local+3;
	w=(*ftab[5])(ctx,2,local+1,&ftab[5],fqv[75]); /*send-all*/
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)irtvieweF779draw_things(ctx,1,local+1); /*x::draw-things*/
	argv[0]->c.obj.iv[2] = w;
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtvieweBLK1069:
	ctx->vsp=local; return(local[0]);}

/*:nomethod*/
static pointer irtvieweM1077irtviewer_dummy_nomethod(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtvieweRST1079:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	w = T;
	local[0]= w;
irtvieweBLK1078:
	ctx->vsp=local; return(local[0]);}

/*make-irtviewer-dummy*/
static pointer irtvieweF782make_irtviewer_dummy(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
irtvieweRST1081:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= makeint((eusinteger_t)1L);
	local[2]= fqv[191];
	ctx->vsp=local+3;
	w=(*ftab[8])(ctx,2,local+1,&ftab[8],fqv[85]); /*warning-message*/
	local[1]= loadglobal(fqv[192]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	storeglobal(fqv[182],w);
	w = local[1];
	local[0]= w;
irtvieweBLK1080:
	ctx->vsp=local; return(local[0]);}

/*with-save-mpeg*/
static pointer irtvieweF1082(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtvieweRST1084:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= fqv[193];
	local[2]= fqv[194];
	local[3]= fqv[12];
	local[4]= fqv[182];
	local[5]= fqv[153];
	local[6]= fqv[154];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[12];
	local[5]= fqv[182];
	local[6]= fqv[153];
	local[7]= fqv[155];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= local[0];
	local[6]= fqv[12];
	local[7]= fqv[182];
	local[8]= fqv[195];
	local[9]= fqv[196];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[12];
	local[8]= fqv[182];
	local[9]= fqv[153];
	local[10]= fqv[197];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)APPEND(ctx,2,local+5); /*append*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
irtvieweBLK1083:
	ctx->vsp=local; return(local[0]);}

/*with-save-animgif*/
static pointer irtvieweF1085(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtvieweRST1087:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= fqv[193];
	local[2]= fqv[194];
	local[3]= fqv[12];
	local[4]= fqv[182];
	local[5]= fqv[153];
	local[6]= fqv[154];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[12];
	local[5]= fqv[182];
	local[6]= fqv[153];
	local[7]= fqv[155];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= local[0];
	local[6]= fqv[12];
	local[7]= fqv[182];
	local[8]= fqv[198];
	local[9]= fqv[196];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[12];
	local[8]= fqv[182];
	local[9]= fqv[153];
	local[10]= fqv[197];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)APPEND(ctx,2,local+5); /*append*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
irtvieweBLK1086:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___irtviewer(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[199];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtvieweIF1088;
	local[0]= fqv[200];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[201],w);
	goto irtvieweIF1089;
irtvieweIF1088:
	local[0]= fqv[202];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtvieweIF1089:
	ctx->vsp=local+0;
	compfun(ctx,fqv[203],module,irtvieweF776make_lr_ud_coords,fqv[204]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM784geometry_viewer_draw_circle,fqv[205],fqv[206],fqv[207]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM800geometry_viewer_draw_objects,fqv[14],fqv[206],fqv[208]);
	local[0]= fqv[42];
	local[1]= fqv[209];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto irtvieweIF1090;
	local[0]= fqv[42];
	local[1]= fqv[209];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[42];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto irtvieweIF1092;
	local[0]= fqv[42];
	local[1]= fqv[210];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto irtvieweIF1093;
irtvieweIF1092:
	local[0]= NIL;
irtvieweIF1093:
	local[0]= fqv[42];
	goto irtvieweIF1091;
irtvieweIF1090:
	local[0]= NIL;
irtvieweIF1091:
	local[0]= fqv[190];
	local[1]= fqv[210];
	local[2]= fqv[190];
	local[3]= fqv[211];
	local[4]= loadglobal(fqv[212]);
	local[5]= fqv[213];
	local[6]= fqv[214];
	local[7]= fqv[215];
	local[8]= NIL;
	local[9]= fqv[216];
	local[10]= NIL;
	local[11]= fqv[217];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[218];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[21])(ctx,13,local+2,&ftab[21],fqv[219]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM803irtviewer_create,fqv[21],fqv[190],fqv[220]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM815irtviewer_viewer,fqv[70],fqv[190],fqv[221]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM818irtviewer_redraw,fqv[62],fqv[190],fqv[222]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM820irtviewer_expose,fqv[223],fqv[190],fqv[224]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM822irtviewer_resize,fqv[56],fqv[190],fqv[225]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM824irtviewer_configurenotify,fqv[226],fqv[190],fqv[227]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM831irtviewer_viewtarget,fqv[86],fqv[190],fqv[228]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM837irtviewer_viewpoint,fqv[69],fqv[190],fqv[229]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM843irtviewer_look1,fqv[53],fqv[190],fqv[230]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM851irtviewer_look_all,fqv[185],fqv[190],fqv[231]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM864irtviewer_move_viewing_around_viewtarget,fqv[91],fqv[190],fqv[232]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM879irtviewer_set_cursor_pos_event,fqv[49],fqv[190],fqv[233]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM881irtviewer_move_coords_event,fqv[51],fqv[190],fqv[234]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM885irtviewer_draw_event,fqv[47],fqv[190],fqv[235]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM887irtviewer_draw_objects,fqv[14],fqv[190],fqv[236]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM892irtviewer_objects,fqv[184],fqv[190],fqv[237]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM901irtviewer_select_drawmode,fqv[238],fqv[190],fqv[239]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM912irtviewer_flush,fqv[11],fqv[190],fqv[240]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM916irtviewer_change_background,fqv[241],fqv[190],fqv[242]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM918irtviewer_draw_origin,fqv[94],fqv[190],fqv[243]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM924irtviewer_draw_floor,fqv[95],fqv[190],fqv[244]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM930irtviewer_floor_color,fqv[96],fqv[190],fqv[245]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[246],module,irtvieweF777make_mpeg_from_images,fqv[247]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[248],module,irtvieweF778make_animgif_from_images,fqv[249]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM980irtviewer_logging,fqv[153],fqv[190],fqv[250]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM992irtviewer_clear_log,fqv[251],fqv[190],fqv[252]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM994irtviewer_push_image,fqv[92],fqv[190],fqv[253]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM996irtviewer_clear_image_sequence,fqv[150],fqv[190],fqv[254]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM998irtviewer_image_sequence,fqv[160],fqv[190],fqv[255]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM1000irtviewer_save_mpeg,fqv[195],fqv[190],fqv[256]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM1007irtviewer_save_animgif,fqv[198],fqv[190],fqv[257]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM1019irtviewer_save_animgif,fqv[198],fqv[190],fqv[258]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM1031irtviewer_save_image,fqv[259],fqv[190],fqv[260]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[261],module,irtvieweF779draw_things,fqv[262]);
	local[0]= fqv[263];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtvieweIF1094;
	local[0]= fqv[264];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[201],w);
	goto irtvieweIF1095;
irtvieweIF1094:
	local[0]= fqv[265];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtvieweIF1095:
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM1042viewing_look,fqv[72],fqv[266],fqv[267]);
	local[0]= fqv[268];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtvieweIF1096;
	local[0]= fqv[269];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[201],w);
	goto irtvieweIF1097;
irtvieweIF1096:
	local[0]= fqv[270];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtvieweIF1097:
	ctx->vsp=local+0;
	compfun(ctx,fqv[271],module,irtvieweF780objects,fqv[272]);
	local[0]= fqv[273];
	ctx->vsp=local+1;
	w=(pointer)PROCLAIM(ctx,1,local+0); /*proclaim*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[274],module,irtvieweF781make_irtviewer,fqv[275]);
	local[0]= fqv[189];
	local[1]= fqv[210];
	local[2]= fqv[189];
	local[3]= fqv[211];
	local[4]= loadglobal(fqv[276]);
	local[5]= fqv[213];
	local[6]= fqv[194];
	local[7]= fqv[215];
	local[8]= NIL;
	local[9]= fqv[216];
	local[10]= NIL;
	local[11]= fqv[217];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[218];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[21])(ctx,13,local+2,&ftab[21],fqv[219]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM1065viewer_dummy_nomethod,fqv[277],fqv[189],fqv[278]);
	local[0]= fqv[188];
	local[1]= fqv[210];
	local[2]= fqv[188];
	local[3]= fqv[211];
	local[4]= loadglobal(fqv[276]);
	local[5]= fqv[213];
	local[6]= fqv[279];
	local[7]= fqv[215];
	local[8]= NIL;
	local[9]= fqv[216];
	local[10]= NIL;
	local[11]= fqv[217];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[218];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[21])(ctx,13,local+2,&ftab[21],fqv[219]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM1068irtviewer_dummy_objects,fqv[184],fqv[188],fqv[280]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtvieweM1077irtviewer_dummy_nomethod,fqv[277],fqv[188],fqv[281]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[282],module,irtvieweF782make_irtviewer_dummy,fqv[283]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[284],module,irtvieweF1082,fqv[285]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[286],module,irtvieweF1085,fqv[287]);
	local[0]= fqv[288];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtvieweIF1098;
	local[0]= fqv[289];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[201],w);
	goto irtvieweIF1099;
irtvieweIF1098:
	local[0]= fqv[290];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtvieweIF1099:
	local[0]= fqv[291];
	local[1]= fqv[292];
	ctx->vsp=local+2;
	w=(*ftab[22])(ctx,2,local+0,&ftab[22],fqv[293]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<23; i++) ftab[i]=fcallx;
}
