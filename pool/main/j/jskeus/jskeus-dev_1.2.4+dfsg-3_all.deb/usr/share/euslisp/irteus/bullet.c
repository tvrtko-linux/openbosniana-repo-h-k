/* ./bullet.c :  entry=bullet */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "bullet.h"
#pragma init (register_bullet)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___bullet();
extern pointer build_quote_vector();
static int register_bullet()
  { add_module_initializer("___bullet", ___bullet);}

static pointer bulletF531bt_make_model_from_body();
static pointer bulletF532bt_collision_distance();
static pointer bulletF533bt_collision_check();

/*bt-make-model-from-body*/
static pointer bulletF531bt_make_model_from_body(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[0], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto bulletKEY535;
	local[2]= argv[0];
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[0] = w;
bulletKEY535:
	if (n & (1<<1)) goto bulletKEY536;
	local[1] = makeint((eusinteger_t)0L);
bulletKEY536:
	local[2]= NIL;
	local[3]= fqv[2];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[0])(ctx,2,local+3,&ftab[0],fqv[3]); /*assoc*/
	if (w==NIL) goto bulletCON538;
	local[3]= makeflt(1.0000000000000000208167e-03);
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,1,local+4,&ftab[1],fqv[4]); /*radius-of-sphere*/
	local[4]= w;
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[2])(ctx,1,local+3,&ftab[2],fqv[5]); /*btmakespheremodel*/
	local[2] = w;
	local[3]= local[2];
	goto bulletCON537;
bulletCON538:
	local[3]= fqv[6];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[0])(ctx,2,local+3,&ftab[0],fqv[3]); /*assoc*/
	if (w==NIL) goto bulletCON539;
	local[3]= makeflt(1.0000000000000000208167e-03);
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[3])(ctx,1,local+4,&ftab[3],fqv[7]); /*x-of-cube*/
	local[4]= w;
	local[5]= local[1];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	local[4]= makeflt(1.0000000000000000208167e-03);
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(*ftab[4])(ctx,1,local+5,&ftab[4],fqv[8]); /*y-of-cube*/
	local[5]= w;
	local[6]= local[1];
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	local[5]= makeflt(1.0000000000000000208167e-03);
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(*ftab[5])(ctx,1,local+6,&ftab[5],fqv[9]); /*z-of-cube*/
	local[6]= w;
	local[7]= local[1];
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,2,local+6); /*+*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[6])(ctx,3,local+3,&ftab[6],fqv[10]); /*btmakeboxmodel*/
	local[2] = w;
	local[3]= local[2];
	goto bulletCON537;
bulletCON539:
	local[3]= fqv[11];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[0])(ctx,2,local+3,&ftab[0],fqv[3]); /*assoc*/
	if (w==NIL) goto bulletCON540;
	local[3]= makeflt(1.0000000000000000208167e-03);
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[7])(ctx,1,local+4,&ftab[7],fqv[12]); /*radius-of-cylinder*/
	local[4]= w;
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	local[4]= makeflt(1.0000000000000000208167e-03);
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(*ftab[8])(ctx,1,local+5,&ftab[8],fqv[13]); /*height-of-cylinder*/
	local[5]= w;
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[9])(ctx,2,local+3,&ftab[9],fqv[14]); /*btmakecylindermodel*/
	local[2] = w;
	local[3]= local[2];
	goto bulletCON537;
bulletCON540:
	local[3]= makeflt(1.0000000000000000208167e-03);
	local[4]= (pointer)get_sym_func(fqv[15]);
	local[5]= (pointer)get_sym_func(fqv[16]);
	local[6]= loadglobal(fqv[17]);
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,bulletCLO542,env,argv,local);
	local[8]= argv[0];
	local[9]= fqv[18];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MAPCAR(ctx,2,local+7); /*mapcar*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,3,local+5); /*apply*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,2,local+4); /*apply*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SCALEVEC(ctx,2,local+3); /*scale*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[18];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[10])(ctx,2,local+3,&ftab[10],fqv[19]); /*btmakemeshmodel*/
	local[2] = w;
	local[3]= local[1];
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)GREATERP(ctx,2,local+3); /*>*/
	if (w==NIL) goto bulletIF543;
	local[3]= local[2];
	local[4]= makeflt(1.0000000000000000208167e-03);
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[11])(ctx,2,local+3,&ftab[11],fqv[20]); /*btsetmargin*/
	local[3]= w;
	goto bulletIF544;
bulletIF543:
	local[3]= NIL;
bulletIF544:
	goto bulletCON537;
bulletCON541:
	local[3]= NIL;
bulletCON537:
	w = local[2];
	local[0]= w;
bulletBLK534:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer bulletCLO542(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[21];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:make-btmodel*/
static pointer bulletM545cascaded_coords_make_btmodel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[22], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto bulletKEY547;
	local[0] = makeint((eusinteger_t)0L);
bulletKEY547:
	if (n & (1<<1)) goto bulletKEY548;
	local[1] = NIL;
bulletKEY548:
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	if (local[1]==NIL) goto bulletCON550;
	local[8]= local[1];
	local[9]= fqv[18];
	ctx->vsp=local+10;
	w=(*ftab[12])(ctx,2,local+8,&ftab[12],fqv[23]); /*send-all*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[13])(ctx,1,local+8,&ftab[13],fqv[24]); /*flatten*/
	local[2] = w;
	local[8]= makeflt(1.0000000000000000208167e-03);
	local[9]= (pointer)get_sym_func(fqv[15]);
	local[10]= (pointer)get_sym_func(fqv[16]);
	local[11]= loadglobal(fqv[17]);
	ctx->vsp=local+12;
	local[12]= makeclosure(codevec,quotevec,bulletCLO551,env,argv,local);
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(pointer)MAPCAR(ctx,2,local+12); /*mapcar*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)APPLY(ctx,3,local+10); /*apply*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)APPLY(ctx,2,local+9); /*apply*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,2,local+8); /*scale*/
	local[8]= w;
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[10])(ctx,2,local+8,&ftab[10],fqv[19]); /*btmakemeshmodel*/
	local[3] = w;
	local[8]= local[3];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(*ftab[11])(ctx,2,local+8,&ftab[11],fqv[20]); /*btsetmargin*/
	local[8]= w;
	goto bulletCON549;
bulletCON550:
	local[8]= argv[0];
	local[9]= loadglobal(fqv[25]);
	ctx->vsp=local+10;
	w=(pointer)DERIVEDP(ctx,2,local+8); /*derivedp*/
	if (w==NIL) goto bulletCON552;
	local[8]= argv[0];
	local[9]= fqv[26];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)bulletF531bt_make_model_from_body(ctx,3,local+8); /*bt-make-model-from-body*/
	local[3] = w;
	local[8]= local[3];
	goto bulletCON549;
bulletCON552:
	local[8]= argv[0];
	local[9]= fqv[27];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= fqv[18];
	ctx->vsp=local+10;
	w=(*ftab[12])(ctx,2,local+8,&ftab[12],fqv[23]); /*send-all*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[13])(ctx,1,local+8,&ftab[13],fqv[24]); /*flatten*/
	local[2] = w;
	local[8]= makeflt(1.0000000000000000208167e-03);
	local[9]= (pointer)get_sym_func(fqv[15]);
	local[10]= (pointer)get_sym_func(fqv[16]);
	local[11]= loadglobal(fqv[17]);
	ctx->vsp=local+12;
	local[12]= makeclosure(codevec,quotevec,bulletCLO554,env,argv,local);
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(pointer)MAPCAR(ctx,2,local+12); /*mapcar*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)APPLY(ctx,3,local+10); /*apply*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)APPLY(ctx,2,local+9); /*apply*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,2,local+8); /*scale*/
	local[8]= w;
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[10])(ctx,2,local+8,&ftab[10],fqv[19]); /*btmakemeshmodel*/
	local[3] = w;
	local[8]= local[3];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(*ftab[11])(ctx,2,local+8,&ftab[11],fqv[20]); /*btsetmargin*/
	local[8]= w;
	goto bulletCON549;
bulletCON553:
	local[8]= NIL;
bulletCON549:
	local[8]= argv[0];
	local[9]= local[3];
	local[10]= fqv[28];
	ctx->vsp=local+11;
	w=(pointer)PUTPROP(ctx,3,local+8); /*putprop*/
	w = local[3];
	local[0]= w;
bulletBLK546:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer bulletCLO551(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[21];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer bulletCLO554(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[21];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*bt-collision-distance*/
static pointer bulletF532bt_collision_distance(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[29], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto bulletKEY556;
	local[0] = makeint((eusinteger_t)0L);
bulletKEY556:
	if (n & (1<<1)) goto bulletKEY557;
	local[1] = NIL;
bulletKEY557:
	if (n & (1<<2)) goto bulletKEY558;
	local[2] = NIL;
bulletKEY558:
	local[3]= argv[0];
	local[4]= fqv[28];
	ctx->vsp=local+5;
	w=(pointer)GETPROP(ctx,2,local+3); /*get*/
	local[3]= w;
	local[4]= argv[1];
	local[5]= fqv[28];
	ctx->vsp=local+6;
	w=(pointer)GETPROP(ctx,2,local+4); /*get*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[30];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[14])(ctx,1,local+5,&ftab[14],fqv[31]); /*user::matrix2quaternion*/
	local[5]= w;
	local[6]= makeflt(1.0000000000000000208167e-03);
	local[7]= argv[0];
	local[8]= fqv[32];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SCALEVEC(ctx,2,local+6); /*scale*/
	local[6]= w;
	local[7]= argv[1];
	local[8]= fqv[30];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[14])(ctx,1,local+7,&ftab[14],fqv[31]); /*user::matrix2quaternion*/
	local[7]= w;
	local[8]= makeflt(1.0000000000000000208167e-03);
	local[9]= argv[1];
	local[10]= fqv[32];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,2,local+8); /*scale*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,1,local+9); /*float-vector*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)0L);
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(pointer)MKFLTVEC(ctx,3,local+10); /*float-vector*/
	local[10]= w;
	local[11]= makeint((eusinteger_t)0L);
	local[12]= makeint((eusinteger_t)0L);
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)MKFLTVEC(ctx,3,local+11); /*float-vector*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)0L);
	local[13]= makeint((eusinteger_t)0L);
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(pointer)MKFLTVEC(ctx,3,local+12); /*float-vector*/
	local[12]= w;
	local[13]= NIL;
	if (local[1]!=NIL) goto bulletIF559;
	local[1] = local[0];
	local[14]= local[1];
	goto bulletIF560;
bulletIF559:
	local[14]= NIL;
bulletIF560:
	if (local[3]!=NIL) goto bulletIF561;
	local[14]= argv[0];
	local[15]= fqv[33];
	local[16]= fqv[34];
	local[17]= local[0];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,4,local+14); /*send*/
	local[3] = w;
	local[14]= local[3];
	goto bulletIF562;
bulletIF561:
	local[14]= NIL;
bulletIF562:
	if (local[4]!=NIL) goto bulletIF563;
	local[14]= argv[1];
	local[15]= fqv[33];
	local[16]= fqv[34];
	local[17]= local[1];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,4,local+14); /*send*/
	local[4] = w;
	local[14]= local[4];
	goto bulletIF564;
bulletIF563:
	local[14]= NIL;
bulletIF564:
	local[14]= local[3];
	local[15]= local[4];
	local[16]= local[6];
	local[17]= local[5];
	local[18]= local[8];
	local[19]= local[7];
	local[20]= local[9];
	local[21]= local[10];
	local[22]= local[11];
	local[23]= local[12];
	ctx->vsp=local+24;
	w=(*ftab[15])(ctx,10,local+14,&ftab[15],fqv[35]); /*btcalccollisiondistance*/
	local[14]= makeflt(1.0000000000000000000000e+03);
	local[15]= local[9];
	local[16]= makeint((eusinteger_t)0L);
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)TIMES(ctx,2,local+14); /***/
	local[14]= w;
	local[15]= makeflt(1.0000000000000000000000e+03);
	local[16]= local[11];
	ctx->vsp=local+17;
	w=(pointer)SCALEVEC(ctx,2,local+15); /*scale*/
	local[15]= w;
	local[16]= makeflt(1.0000000000000000000000e+03);
	local[17]= local[12];
	ctx->vsp=local+18;
	w=(pointer)SCALEVEC(ctx,2,local+16); /*scale*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,3,local+14); /*list*/
	local[0]= w;
bulletBLK555:
	ctx->vsp=local; return(local[0]);}

/*bt-collision-check*/
static pointer bulletF533bt_collision_check(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[36], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto bulletKEY566;
	local[0] = makeint((eusinteger_t)0L);
bulletKEY566:
	if (n & (1<<1)) goto bulletKEY567;
	local[1] = NIL;
bulletKEY567:
	local[2]= argv[0];
	local[3]= argv[1];
	local[4]= fqv[34];
	local[5]= local[0];
	local[6]= fqv[37];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)bulletF532bt_collision_distance(ctx,6,local+2); /*bt-collision-distance*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)GREATERP(ctx,2,local+2); /*>*/
	if (w==NIL) goto bulletIF568;
	local[2]= makeint((eusinteger_t)0L);
	goto bulletIF569;
bulletIF568:
	local[2]= makeint((eusinteger_t)1L);
bulletIF569:
	w = local[2];
	local[0]= w;
bulletBLK565:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___bullet(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[38];
	ctx->vsp=local+1;
	w=(*ftab[16])(ctx,1,local+0,&ftab[16],fqv[39]); /*require*/
	local[0]= fqv[40];
	ctx->vsp=local+1;
	w=(*ftab[16])(ctx,1,local+0,&ftab[16],fqv[39]); /*require*/
	local[0]= fqv[41];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto bulletIF570;
	local[0]= fqv[42];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[43],w);
	goto bulletIF571;
bulletIF570:
	local[0]= fqv[44];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
bulletIF571:
	local[0]= fqv[45];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[46],module,bulletF531bt_make_model_from_body,fqv[47]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,bulletM545cascaded_coords_make_btmodel,fqv[33],fqv[48],fqv[49]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[50],module,bulletF532bt_collision_distance,fqv[51]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[52],module,bulletF533bt_collision_check,fqv[53]);
	local[0]= fqv[54];
	local[1]= fqv[55];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[56]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<18; i++) ftab[i]=fcallx;
}
