/* ./irtgeo.c :  entry=irtgeo */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "irtgeo.h"
#pragma init (register_irtgeo)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___irtgeo();
extern pointer build_quote_vector();
static int register_irtgeo()
  { add_module_initializer("___irtgeo", ___irtgeo);}

static pointer irtgeoF1midcoords();
static pointer irtgeoF2transform_coords();
static pointer irtgeoF3orient_coords_to_axis();
static pointer irtgeoF4face_to_triangle_aux();
static pointer irtgeoF5face_to_triangle();
static pointer irtgeoF6face_to_tessel_triangle();
static pointer irtgeoF7face_to_triangle_rest_polygon();
static pointer irtgeoF8face_to_triangle_make_simple();
static pointer irtgeoF9body_to_faces();
static pointer irtgeoF10body_to_triangles();
static pointer irtgeoF11triangle_to_triangle();
static pointer irtgeoF12make_sphere();
static pointer irtgeoF13make_ring();
static pointer irtgeoF14make_fan_cylinder();
static pointer irtgeoF15x_of_cube();
static pointer irtgeoF16y_of_cube();
static pointer irtgeoF17z_of_cube();
static pointer irtgeoF18height_of_cylinder();
static pointer irtgeoF19radius_of_cylinder();
static pointer irtgeoF20radius_of_sphere();
static pointer irtgeoF21make_faceset_from_vertices();
static pointer irtgeoF22matrix_to_euler_angle();
static pointer irtgeoF23quaternion_from_two_vectors();

/*midcoords*/
static pointer irtgeoF1midcoords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= fqv[0];
	local[1]= argv[0];
	local[2]= argv[1];
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[2];
	local[4]= fqv[1];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[0])(ctx,3,local+1,&ftab[0],fqv[2]); /*midpoint*/
	local[1]= w;
	local[2]= fqv[3];
	local[3]= argv[0];
	local[4]= argv[1];
	local[5]= fqv[4];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= argv[2];
	local[6]= fqv[4];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[1])(ctx,3,local+3,&ftab[1],fqv[5]); /*user::midrot*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[2])(ctx,4,local+0,&ftab[2],fqv[6]); /*make-coords*/
	local[0]= w;
irtgeoBLK24:
	ctx->vsp=local; return(local[0]);}

/*:worldcoords*/
static pointer irtgeoM25line_worldcoords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[0];
	local[1]= makeflt(5.0000000000000000000000e-01);
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(*ftab[0])(ctx,3,local+1,&ftab[0],fqv[2]); /*midpoint*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[6]); /*make-coords*/
	local[0]= w;
irtgeoBLK26:
	ctx->vsp=local; return(local[0]);}

/*:axis*/
static pointer irtgeoM27coordinates_axis(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[7];
	local[2]= argv[2];
	local[3]= local[2];
	if (fqv[8]!=local[3]) goto irtgeoIF29;
	local[3]= fqv[9];
	goto irtgeoIF30;
irtgeoIF29:
	local[3]= local[2];
	if (fqv[10]!=local[3]) goto irtgeoIF31;
	local[3]= fqv[11];
	goto irtgeoIF32;
irtgeoIF31:
	local[3]= local[2];
	if (fqv[12]!=local[3]) goto irtgeoIF33;
	local[3]= fqv[13];
	goto irtgeoIF34;
irtgeoIF33:
	local[3]= NIL;
irtgeoIF34:
irtgeoIF32:
irtgeoIF30:
	w = local[3];
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
irtgeoBLK28:
	ctx->vsp=local; return(local[0]);}

/*:difference-position*/
static pointer irtgeoM35coordinates_difference_position(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[14], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtgeoKEY37;
	local[0] = T;
irtgeoKEY37:
	local[1]= argv[0];
	local[2]= fqv[15];
	local[3]= argv[2];
	local[4]= fqv[1];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= local[0];
	local[3]= local[2];
	w = fqv[16];
	if (memq(local[3],w)==NIL) goto irtgeoIF38;
	local[3]= local[1];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)SETELT(ctx,3,local+3); /*setelt*/
	local[3]= w;
	goto irtgeoIF39;
irtgeoIF38:
	local[3]= local[2];
	w = fqv[17];
	if (memq(local[3],w)==NIL) goto irtgeoIF40;
	local[3]= local[1];
	local[4]= makeint((eusinteger_t)1L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)SETELT(ctx,3,local+3); /*setelt*/
	local[3]= w;
	goto irtgeoIF41;
irtgeoIF40:
	local[3]= local[2];
	w = fqv[18];
	if (memq(local[3],w)==NIL) goto irtgeoIF42;
	local[3]= local[1];
	local[4]= makeint((eusinteger_t)2L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)SETELT(ctx,3,local+3); /*setelt*/
	local[3]= w;
	goto irtgeoIF43;
irtgeoIF42:
	local[3]= local[2];
	w = fqv[19];
	if (memq(local[3],w)==NIL) goto irtgeoIF44;
	local[3]= local[1];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)SETELT(ctx,3,local+3); /*setelt*/
	local[3]= local[1];
	local[4]= makeint((eusinteger_t)1L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)SETELT(ctx,3,local+3); /*setelt*/
	local[3]= w;
	goto irtgeoIF45;
irtgeoIF44:
	local[3]= local[2];
	w = fqv[20];
	if (memq(local[3],w)==NIL) goto irtgeoIF46;
	local[3]= local[1];
	local[4]= makeint((eusinteger_t)1L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)SETELT(ctx,3,local+3); /*setelt*/
	local[3]= local[1];
	local[4]= makeint((eusinteger_t)2L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)SETELT(ctx,3,local+3); /*setelt*/
	local[3]= w;
	goto irtgeoIF47;
irtgeoIF46:
	local[3]= local[2];
	w = fqv[21];
	if (memq(local[3],w)==NIL) goto irtgeoIF48;
	local[3]= local[1];
	local[4]= makeint((eusinteger_t)2L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)SETELT(ctx,3,local+3); /*setelt*/
	local[3]= local[1];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)SETELT(ctx,3,local+3); /*setelt*/
	local[3]= w;
	goto irtgeoIF49;
irtgeoIF48:
	local[3]= NIL;
irtgeoIF49:
irtgeoIF47:
irtgeoIF45:
irtgeoIF43:
irtgeoIF41:
irtgeoIF39:
	w = local[3];
	w = local[1];
	local[0]= w;
irtgeoBLK36:
	ctx->vsp=local; return(local[0]);}

/*:difference-rotation*/
static pointer irtgeoM50coordinates_difference_rotation(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[22], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtgeoKEY52;
	local[0] = T;
irtgeoKEY52:
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtgeoFLET53,env,argv,local);
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= local[0];
	local[7]= local[6];
	w = fqv[23];
	if (memq(local[7],w)==NIL) goto irtgeoIF54;
	local[7]= argv[0];
	local[8]= fqv[24];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[4] = w;
	local[7]= argv[2];
	local[8]= fqv[24];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[5] = w;
	local[7]= argv[0];
	local[8]= fqv[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)TRANSPOSE(ctx,1,local+7); /*transpose*/
	local[7]= w;
	local[8]= local[4];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)VINNERPRODUCT(ctx,2,local+8); /*v.*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[3])(ctx,1,local+8,&ftab[3],fqv[25]); /*acos*/
	local[8]= w;
	local[9]= local[4];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+9); /*v**/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[4])(ctx,1,local+9,&ftab[4],fqv[26]); /*normalize-vector*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,2,local+8); /*scale*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)TRANSFORM(ctx,2,local+7); /*transform*/
	local[3] = w;
	local[7]= local[3];
	goto irtgeoIF55;
irtgeoIF54:
	local[7]= local[6];
	w = fqv[27];
	if (memq(local[7],w)==NIL) goto irtgeoIF56;
	local[7]= local[0];
	local[8]= local[7];
	if (fqv[28]!=local[8]) goto irtgeoIF58;
	local[8]= fqv[8];
	goto irtgeoIF59;
irtgeoIF58:
	local[8]= local[7];
	if (fqv[29]!=local[8]) goto irtgeoIF60;
	local[8]= fqv[10];
	goto irtgeoIF61;
irtgeoIF60:
	local[8]= local[7];
	if (fqv[30]!=local[8]) goto irtgeoIF62;
	local[8]= fqv[12];
	goto irtgeoIF63;
irtgeoIF62:
	local[8]= NIL;
irtgeoIF63:
irtgeoIF61:
irtgeoIF59:
	w = local[8];
	local[7]= w;
	local[8]= NIL;
	local[9]= NIL;
	local[10]= argv[0];
	local[11]= fqv[24];
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[8] = w;
	local[10]= argv[2];
	local[11]= fqv[24];
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[9] = w;
	local[10]= argv[0];
	local[11]= argv[2];
	local[12]= local[7];
	w = local[1];
	ctx->vsp=local+13;
	w=irtgeoFLET53(ctx,3,local+10,w);
	if (w!=NIL) goto irtgeoIF64;
	local[10]= local[9];
	ctx->vsp=local+11;
	w=(pointer)VMINUS(ctx,1,local+10); /*v-*/
	local[9] = w;
	local[10]= local[9];
	goto irtgeoIF65;
irtgeoIF64:
	local[10]= NIL;
irtgeoIF65:
	local[10]= argv[0];
	local[11]= fqv[4];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)TRANSPOSE(ctx,1,local+10); /*transpose*/
	local[10]= w;
	local[11]= local[8];
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)VINNERPRODUCT(ctx,2,local+11); /*v.*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[3])(ctx,1,local+11,&ftab[3],fqv[25]); /*acos*/
	local[11]= w;
	local[12]= local[8];
	local[13]= local[9];
	ctx->vsp=local+14;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+12); /*v**/
	local[12]= w;
	ctx->vsp=local+13;
	w=(*ftab[4])(ctx,1,local+12,&ftab[4],fqv[26]); /*normalize-vector*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)SCALEVEC(ctx,2,local+11); /*scale*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)TRANSFORM(ctx,2,local+10); /*transform*/
	local[3] = w;
	w = local[3];
	local[7]= w;
	goto irtgeoIF57;
irtgeoIF56:
	local[7]= local[6];
	w = fqv[31];
	if (memq(local[7],w)==NIL) goto irtgeoIF66;
	local[7]= argv[2];
	local[8]= fqv[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= argv[2];
	local[10]= local[0];
	local[11]= local[10];
	if (fqv[32]!=local[11]) goto irtgeoIF70;
	local[11]= fqv[10];
	goto irtgeoIF71;
irtgeoIF70:
	local[11]= local[10];
	if (fqv[33]!=local[11]) goto irtgeoIF72;
	local[11]= fqv[12];
	goto irtgeoIF73;
irtgeoIF72:
	local[11]= local[10];
	if (fqv[34]!=local[11]) goto irtgeoIF74;
	local[11]= fqv[8];
	goto irtgeoIF75;
irtgeoIF74:
	local[11]= NIL;
irtgeoIF75:
irtgeoIF73:
irtgeoIF71:
	w = local[11];
	local[10]= w;
	w = local[1];
	ctx->vsp=local+11;
	w=irtgeoFLET53(ctx,3,local+8,w);
	if (w!=NIL) goto irtgeoIF68;
	local[8]= local[7];
	local[9]= makeflt(3.1415926535897931159980e+00);
	local[10]= local[0];
	local[11]= local[10];
	if (fqv[32]!=local[11]) goto irtgeoIF76;
	local[11]= fqv[8];
	goto irtgeoIF77;
irtgeoIF76:
	local[11]= local[10];
	if (fqv[33]!=local[11]) goto irtgeoIF78;
	local[11]= fqv[10];
	goto irtgeoIF79;
irtgeoIF78:
	local[11]= local[10];
	if (fqv[34]!=local[11]) goto irtgeoIF80;
	local[11]= fqv[12];
	goto irtgeoIF81;
irtgeoIF80:
	local[11]= NIL;
irtgeoIF81:
irtgeoIF79:
irtgeoIF77:
	w = local[11];
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)ROTMAT(ctx,3,local+8); /*rotate-matrix*/
	local[7] = w;
	local[8]= local[7];
	goto irtgeoIF69;
irtgeoIF68:
	local[8]= NIL;
irtgeoIF69:
	local[8]= argv[0];
	local[9]= fqv[4];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)TRANSPOSE(ctx,1,local+8); /*transpose*/
	local[8]= w;
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)MATTIMES(ctx,2,local+8); /*m**/
	local[2] = w;
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(*ftab[5])(ctx,1,local+8,&ftab[5],fqv[35]); /*user::matrix-log*/
	local[3] = w;
	w = local[3];
	local[7]= w;
	goto irtgeoIF67;
irtgeoIF66:
	local[7]= local[6];
	if (fqv[36]!=local[7]) goto irtgeoIF82;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[3] = w;
	local[7]= local[3];
	goto irtgeoIF83;
irtgeoIF82:
	if (T==NIL) goto irtgeoIF84;
	local[7]= argv[0];
	local[8]= fqv[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)TRANSPOSE(ctx,1,local+7); /*transpose*/
	local[7]= w;
	local[8]= argv[2];
	local[9]= fqv[4];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MATTIMES(ctx,2,local+7); /*m**/
	local[2] = w;
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(*ftab[5])(ctx,1,local+7,&ftab[5],fqv[35]); /*user::matrix-log*/
	local[3] = w;
	local[7]= local[3];
	goto irtgeoIF85;
irtgeoIF84:
	local[7]= NIL;
irtgeoIF85:
irtgeoIF83:
irtgeoIF67:
irtgeoIF57:
irtgeoIF55:
	w = local[7];
	w = local[3];
	local[0]= w;
irtgeoBLK51:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgeoFLET53(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[24];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= argv[1];
	local[2]= fqv[24];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(pointer)VMINUS(ctx,1,local+2); /*v-*/
	local[2]= w;
	local[3]= local[0];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)VINNERPRODUCT(ctx,2,local+3); /*v.*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[3])(ctx,1,local+3,&ftab[3],fqv[25]); /*acos*/
	local[3]= w;
	local[4]= local[0];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+4); /*v**/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[4])(ctx,1,local+4,&ftab[4],fqv[26]); /*normalize-vector*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SCALEVEC(ctx,2,local+3); /*scale*/
	local[3]= w;
	local[4]= local[0];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)VINNERPRODUCT(ctx,2,local+4); /*v.*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[3])(ctx,1,local+4,&ftab[3],fqv[25]); /*acos*/
	local[4]= w;
	local[5]= local[0];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+5); /*v**/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[4])(ctx,1,local+5,&ftab[4],fqv[26]); /*normalize-vector*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SCALEVEC(ctx,2,local+4); /*scale*/
	local[4]= w;
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)VNORM(ctx,1,local+5); /*norm*/
	local[5]= w;
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)VNORM(ctx,1,local+6); /*norm*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LESSP(ctx,2,local+5); /*<*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:move-to*/
static pointer irtgeoM86coordinates_move_to(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtgeoENT89;}
	local[0]= fqv[37];
irtgeoENT89:
irtgeoENT88:
	if (n>4) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(*ftab[6])(ctx,1,local+3,&ftab[6],fqv[38]); /*coordinates-p*/
	if (w!=NIL) goto irtgeoIF90;
	local[3]= fqv[39];
	ctx->vsp=local+4;
	w=(pointer)SIGERROR(ctx,1,local+3); /*error*/
	local[3]= w;
	goto irtgeoIF91;
irtgeoIF90:
	local[3]= NIL;
irtgeoIF91:
	local[3]= local[0];
	w = fqv[40];
	if (memq(local[3],w)!=NIL) goto irtgeoOR94;
	local[3]= local[0];
	if (argv[0]==local[3]) goto irtgeoOR94;
	goto irtgeoCON93;
irtgeoOR94:
	local[3]= argv[0];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)irtgeoF2transform_coords(ctx,2,local+3); /*transform-coords*/
	local[2] = w;
	local[3]= argv[0];
	local[4]= fqv[41];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto irtgeoCON92;
irtgeoCON93:
	local[3]= local[0];
	w = fqv[42];
	if (memq(local[3],w)!=NIL) goto irtgeoOR96;
	local[3]= local[0];
	local[4]= loadglobal(fqv[43]);
	ctx->vsp=local+5;
	w=(pointer)EQUAL(ctx,2,local+3); /*equal*/
	if (w!=NIL) goto irtgeoOR96;
	goto irtgeoCON95;
irtgeoOR96:
	local[3]= argv[0];
	local[4]= fqv[41];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto irtgeoCON92;
irtgeoCON95:
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(*ftab[6])(ctx,1,local+3,&ftab[6],fqv[38]); /*coordinates-p*/
	if (w==NIL) goto irtgeoCON97;
	local[3]= local[0];
	local[4]= fqv[44];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)irtgeoF2transform_coords(ctx,2,local+3); /*transform-coords*/
	local[2] = w;
	local[3]= argv[0];
	local[4]= fqv[45];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= fqv[46];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= local[2];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+3); /*transform-coords*/
	local[3]= argv[0];
	local[4]= fqv[41];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto irtgeoCON92;
irtgeoCON97:
	local[3]= NIL;
irtgeoCON92:
	w = local[3];
	local[0]= w;
irtgeoBLK87:
	ctx->vsp=local; return(local[0]);}

/*:transformation*/
static pointer irtgeoM98coordinates_transformation(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtgeoENT101;}
	local[0]= fqv[37];
irtgeoENT101:
irtgeoENT100:
	if (n>4) maerror();
	local[1]= argv[2];
	local[2]= fqv[44];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	argv[2] = w;
	local[1]= argv[0];
	local[2]= fqv[44];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[46];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= NIL;
	local[4]= local[0];
	w = fqv[47];
	if (memq(local[4],w)!=NIL) goto irtgeoOR104;
	local[4]= local[0];
	if (argv[0]==local[4]) goto irtgeoOR104;
	goto irtgeoCON103;
irtgeoOR104:
	local[4]= local[2];
	local[5]= argv[2];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+4); /*transform-coords*/
	local[4]= w;
	goto irtgeoCON102;
irtgeoCON103:
	local[4]= local[0];
	w = fqv[48];
	if (memq(local[4],w)!=NIL) goto irtgeoOR106;
	local[4]= local[0];
	if (loadglobal(fqv[43])==local[4]) goto irtgeoOR106;
	goto irtgeoCON105;
irtgeoOR106:
	local[4]= argv[2];
	local[5]= local[2];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+4); /*transform-coords*/
	local[4]= w;
	goto irtgeoCON102;
irtgeoCON105:
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[6])(ctx,1,local+4,&ftab[6],fqv[38]); /*coordinates-p*/
	if (w==NIL) goto irtgeoCON107;
	local[4]= local[0];
	local[5]= fqv[44];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[3] = w;
	local[4]= argv[2];
	local[5]= local[2];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+4); /*transform-coords*/
	local[4]= local[3];
	local[5]= fqv[46];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[2];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+4); /*transform-coords*/
	local[4]= local[2];
	local[5]= local[3];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+4); /*transform-coords*/
	local[4]= w;
	goto irtgeoCON102;
irtgeoCON107:
	local[4]= argv[0];
	local[5]= fqv[49];
	local[6]= fqv[50];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	goto irtgeoCON102;
irtgeoCON108:
	local[4]= NIL;
irtgeoCON102:
	w = local[2];
	local[0]= w;
irtgeoBLK99:
	ctx->vsp=local; return(local[0]);}

/*:transform*/
static pointer irtgeoM109coordinates_transform(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtgeoENT112;}
	local[0]= fqv[37];
irtgeoENT112:
irtgeoENT111:
	if (n>4) maerror();
	local[1]= local[0];
	w = fqv[51];
	if (memq(local[1],w)!=NIL) goto irtgeoOR115;
	local[1]= local[0];
	if (argv[0]==local[1]) goto irtgeoOR115;
	goto irtgeoCON114;
irtgeoOR115:
	local[1]= argv[0];
	local[2]= argv[2];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+1); /*transform-coords*/
	local[1]= w;
	goto irtgeoCON113;
irtgeoCON114:
	local[1]= local[0];
	w = fqv[52];
	if (memq(local[1],w)!=NIL) goto irtgeoOR117;
	local[1]= local[0];
	if (loadglobal(fqv[43])==local[1]) goto irtgeoOR117;
	goto irtgeoCON116;
irtgeoOR117:
	local[1]= argv[2];
	local[2]= argv[0];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+1); /*transform-coords*/
	local[1]= w;
	goto irtgeoCON113;
irtgeoCON116:
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,1,local+1,&ftab[6],fqv[38]); /*coordinates-p*/
	if (w==NIL) goto irtgeoCON118;
	local[1]= local[0];
	local[2]= fqv[46];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+1); /*transform-coords*/
	local[1]= argv[2];
	local[2]= argv[0];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+1); /*transform-coords*/
	local[1]= local[0];
	local[2]= fqv[44];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+1); /*transform-coords*/
	local[1]= w;
	goto irtgeoCON113;
irtgeoCON118:
	local[1]= argv[0];
	local[2]= fqv[49];
	local[3]= fqv[53];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto irtgeoCON113;
irtgeoCON119:
	local[1]= NIL;
irtgeoCON113:
	local[1]= argv[0];
	local[2]= fqv[41];
	local[3]= argv[0]->c.obj.iv[1];
	local[4]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
irtgeoBLK110:
	ctx->vsp=local; return(local[0]);}

/*:move-coords*/
static pointer irtgeoM120coordinates_move_coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[54];
	local[2]= argv[3];
	local[3]= fqv[55];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[44];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
irtgeoBLK121:
	ctx->vsp=local; return(local[0]);}

/*:worldcoords*/
static pointer irtgeoM122cascaded_coords_worldcoords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[7]==NIL) goto irtgeoIF124;
	if (argv[0]->c.obj.iv[3]==NIL) goto irtgeoIF126;
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= fqv[44];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+3;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+0); /*transform-coords*/
	local[0]= w;
	goto irtgeoIF127;
irtgeoIF126:
	local[0]= argv[0]->c.obj.iv[5];
	local[1]= fqv[56];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
irtgeoIF127:
	local[0]= argv[0];
	local[1]= fqv[57];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	argv[0]->c.obj.iv[7] = NIL;
	local[0]= argv[0]->c.obj.iv[7];
	goto irtgeoIF125;
irtgeoIF124:
	local[0]= NIL;
irtgeoIF125:
	w = argv[0]->c.obj.iv[5];
	local[0]= w;
irtgeoBLK123:
	ctx->vsp=local; return(local[0]);}

/*:transformation*/
static pointer irtgeoM128cascaded_coords_transformation(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtgeoENT131;}
	local[0]= fqv[37];
irtgeoENT131:
irtgeoENT130:
	if (n>4) maerror();
	local[1]= argv[2];
	local[2]= fqv[44];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[44];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= local[2];
	local[4]= fqv[46];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= local[0];
	w = fqv[58];
	if (memq(local[6],w)!=NIL) goto irtgeoOR134;
	local[6]= local[0];
	if (argv[0]==local[6]) goto irtgeoOR134;
	goto irtgeoCON133;
irtgeoOR134:
	local[6]= local[3];
	local[7]= local[1];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+6); /*transform-coords*/
	local[6]= w;
	goto irtgeoCON132;
irtgeoCON133:
	local[6]= local[0];
	w = fqv[59];
	if (memq(local[6],w)!=NIL) goto irtgeoOR136;
	local[6]= local[0];
	if (argv[0]->c.obj.iv[3]==local[6]) goto irtgeoOR136;
	goto irtgeoCON135;
irtgeoOR136:
	local[6]= argv[0];
	local[7]= *(ovafptr(argv[1],fqv[60]));
	local[8]= fqv[46];
	ctx->vsp=local+9;
	w=(pointer)SENDMESSAGE(ctx,3,local+6); /*send-message*/
	local[4] = w;
	local[6]= local[1];
	local[7]= local[4];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+6); /*transform-coords*/
	local[6]= local[3];
	local[7]= local[4];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+6); /*transform-coords*/
	local[6]= argv[0];
	local[7]= local[4];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+6); /*transform-coords*/
	local[6]= w;
	goto irtgeoCON132;
irtgeoCON135:
	local[6]= local[0];
	w = fqv[61];
	if (memq(local[6],w)!=NIL) goto irtgeoOR138;
	local[6]= local[0];
	local[7]= loadglobal(fqv[43]);
	ctx->vsp=local+8;
	w=(pointer)EQUAL(ctx,2,local+6); /*equal*/
	if (w!=NIL) goto irtgeoOR138;
	goto irtgeoCON137;
irtgeoOR138:
	local[6]= local[1];
	local[7]= local[3];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+6); /*transform-coords*/
	local[6]= w;
	goto irtgeoCON132;
irtgeoCON137:
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(*ftab[6])(ctx,1,local+6,&ftab[6],fqv[38]); /*coordinates-p*/
	if (w==NIL) goto irtgeoCON139;
	local[6]= local[0];
	local[7]= fqv[44];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[5] = w;
	local[6]= local[3];
	local[7]= local[5];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+6); /*transform-coords*/
	local[6]= local[1];
	local[7]= local[3];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+6); /*transform-coords*/
	local[6]= local[5];
	local[7]= fqv[46];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= local[3];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+6); /*transform-coords*/
	local[6]= w;
	goto irtgeoCON132;
irtgeoCON139:
	local[6]= argv[0];
	local[7]= fqv[49];
	local[8]= fqv[62];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= w;
	goto irtgeoCON132;
irtgeoCON140:
	local[6]= NIL;
irtgeoCON132:
	w = local[6];
	local[0]= w;
irtgeoBLK129:
	ctx->vsp=local; return(local[0]);}

/*:transform*/
static pointer irtgeoM141cascaded_coords_transform(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtgeoENT144;}
	local[0]= fqv[37];
irtgeoENT144:
irtgeoENT143:
	if (n>4) maerror();
	local[1]= local[0];
	w = fqv[63];
	if (memq(local[1],w)!=NIL) goto irtgeoOR147;
	local[1]= local[0];
	if (argv[0]==local[1]) goto irtgeoOR147;
	goto irtgeoCON146;
irtgeoOR147:
	local[1]= argv[0];
	local[2]= argv[2];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+1); /*transform-coords*/
	local[1]= w;
	goto irtgeoCON145;
irtgeoCON146:
	local[1]= local[0];
	w = fqv[64];
	if (memq(local[1],w)!=NIL) goto irtgeoOR149;
	local[1]= local[0];
	if (argv[0]->c.obj.iv[3]==local[1]) goto irtgeoOR149;
	goto irtgeoCON148;
irtgeoOR149:
	local[1]= argv[2];
	local[2]= argv[0];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+1); /*transform-coords*/
	local[1]= w;
	goto irtgeoCON145;
irtgeoCON148:
	local[1]= local[0];
	w = fqv[65];
	if (memq(local[1],w)!=NIL) goto irtgeoOR151;
	local[1]= local[0];
	local[2]= loadglobal(fqv[43]);
	ctx->vsp=local+3;
	w=(pointer)EQUAL(ctx,2,local+1); /*equal*/
	if (w!=NIL) goto irtgeoOR151;
	goto irtgeoCON150;
irtgeoOR151:
	local[1]= argv[0];
	local[2]= fqv[45];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= local[1];
	local[3]= argv[0];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+2); /*transform-coords*/
	local[2]= argv[2];
	local[3]= argv[0];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+2); /*transform-coords*/
	local[2]= local[1];
	local[3]= fqv[46];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+2); /*transform-coords*/
	local[1]= w;
	goto irtgeoCON145;
irtgeoCON150:
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,1,local+1,&ftab[6],fqv[38]); /*coordinates-p*/
	if (w==NIL) goto irtgeoCON152;
	local[1]= argv[0];
	local[2]= fqv[45];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= local[1];
	local[3]= argv[0];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+2); /*transform-coords*/
	local[2]= local[0];
	local[3]= fqv[46];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+2); /*transform-coords*/
	local[2]= argv[2];
	local[3]= argv[0];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+2); /*transform-coords*/
	local[2]= local[0];
	local[3]= fqv[44];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+2); /*transform-coords*/
	local[2]= local[1];
	local[3]= fqv[46];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+2); /*transform-coords*/
	local[1]= w;
	goto irtgeoCON145;
irtgeoCON152:
	local[1]= argv[0];
	local[2]= fqv[49];
	local[3]= fqv[66];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto irtgeoCON145;
irtgeoCON153:
	local[1]= NIL;
irtgeoCON145:
	local[1]= argv[0];
	local[2]= fqv[41];
	local[3]= argv[0]->c.obj.iv[1];
	local[4]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
irtgeoBLK142:
	ctx->vsp=local; return(local[0]);}

/*:move-to*/
static pointer irtgeoM154cascaded_coords_move_to(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtgeoENT157;}
	local[0]= fqv[37];
irtgeoENT157:
irtgeoENT156:
	if (n>4) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(*ftab[6])(ctx,1,local+3,&ftab[6],fqv[38]); /*coordinates-p*/
	if (w!=NIL) goto irtgeoIF158;
	local[3]= fqv[67];
	ctx->vsp=local+4;
	w=(pointer)SIGERROR(ctx,1,local+3); /*error*/
	local[3]= w;
	goto irtgeoIF159;
irtgeoIF158:
	local[3]= NIL;
irtgeoIF159:
	local[3]= local[0];
	w = fqv[68];
	if (memq(local[3],w)!=NIL) goto irtgeoOR162;
	local[3]= local[0];
	if (argv[0]==local[3]) goto irtgeoOR162;
	goto irtgeoCON161;
irtgeoOR162:
	local[3]= argv[0];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)irtgeoF2transform_coords(ctx,2,local+3); /*transform-coords*/
	local[2] = w;
	local[3]= argv[0];
	local[4]= fqv[41];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto irtgeoCON160;
irtgeoCON161:
	local[3]= local[0];
	w = fqv[69];
	if (memq(local[3],w)!=NIL) goto irtgeoOR164;
	local[3]= local[0];
	if (argv[0]->c.obj.iv[3]==local[3]) goto irtgeoOR164;
	goto irtgeoCON163;
irtgeoOR164:
	local[3]= argv[0];
	local[4]= fqv[41];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto irtgeoCON160;
irtgeoCON163:
	local[3]= local[0];
	w = fqv[70];
	if (memq(local[3],w)!=NIL) goto irtgeoOR166;
	local[3]= local[0];
	local[4]= loadglobal(fqv[43]);
	ctx->vsp=local+5;
	w=(pointer)EQUAL(ctx,2,local+3); /*equal*/
	if (w!=NIL) goto irtgeoOR166;
	goto irtgeoCON165;
irtgeoOR166:
	local[3]= argv[0];
	local[4]= fqv[45];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= fqv[46];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)irtgeoF2transform_coords(ctx,2,local+3); /*transform-coords*/
	local[2] = w;
	local[3]= argv[0];
	local[4]= fqv[41];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto irtgeoCON160;
irtgeoCON165:
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(*ftab[6])(ctx,1,local+3,&ftab[6],fqv[38]); /*coordinates-p*/
	if (w==NIL) goto irtgeoCON167;
	local[3]= local[0];
	local[4]= fqv[44];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)irtgeoF2transform_coords(ctx,2,local+3); /*transform-coords*/
	local[2] = w;
	local[3]= argv[0];
	local[4]= fqv[45];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= fqv[46];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= local[2];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)irtgeoF2transform_coords(ctx,3,local+3); /*transform-coords*/
	local[3]= argv[0];
	local[4]= fqv[41];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto irtgeoCON160;
irtgeoCON167:
	local[3]= NIL;
irtgeoCON160:
	w = local[3];
	local[0]= w;
irtgeoBLK155:
	ctx->vsp=local; return(local[0]);}

/*transform-coords*/
static pointer irtgeoF2transform_coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgeoENT170;}
	local[0]= argv[0];
	local[1]= fqv[71];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= loadglobal(fqv[72]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[41];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[7])(ctx,1,local+4,&ftab[7],fqv[73]); /*unit-matrix*/
	local[4]= w;
	local[5]= loadglobal(fqv[74]);
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,2,local+5); /*instantiate*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	w = local[1];
	local[0]= w;
irtgeoENT170:
irtgeoENT169:
	if (n>3) maerror();
	local[1]= argv[0];
	if (local[0]!=local[1]) goto irtgeoIF171;
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= argv[1]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)TRANSFORM(ctx,2,local+2); /*transform*/
	local[2]= w;
	local[3]= local[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)VPLUS(ctx,3,local+1); /*v+*/
	local[1]= w;
	goto irtgeoIF172;
irtgeoIF171:
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= argv[1]->c.obj.iv[2];
	local[4]= local[0]->c.obj.iv[2];
	ctx->vsp=local+5;
	w=(pointer)TRANSFORM(ctx,3,local+2); /*transform*/
	local[2]= w;
	local[3]= local[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)VPLUS(ctx,3,local+1); /*v+*/
	local[1]= w;
irtgeoIF172:
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= argv[1]->c.obj.iv[1];
	local[3]= local[0]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(*ftab[8])(ctx,3,local+1,&ftab[8],fqv[75]); /*user::rotm3**/
	w = local[0];
	local[0]= w;
irtgeoBLK168:
	ctx->vsp=local; return(local[0]);}

/*:rotate-vector*/
static pointer irtgeoM173coordinates_rotate_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtgeoENT176;}
	local[0]= NIL;
irtgeoENT176:
irtgeoENT175:
	if (n>4) maerror();
	if (local[0]==NIL) goto irtgeoIF177;
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= argv[2];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)TRANSFORM(ctx,3,local+1); /*transform*/
	local[1]= w;
	goto irtgeoIF178;
irtgeoIF177:
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)TRANSFORM(ctx,2,local+1); /*transform*/
	local[1]= w;
irtgeoIF178:
	w = local[1];
	local[0]= w;
irtgeoBLK174:
	ctx->vsp=local; return(local[0]);}

/*:inverse-rotate-vector*/
static pointer irtgeoM179coordinates_inverse_rotate_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtgeoENT182;}
	local[0]= NIL;
irtgeoENT182:
irtgeoENT181:
	if (n>4) maerror();
	if (local[0]==NIL) goto irtgeoIF183;
	local[1]= argv[2];
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)TRANSFORM(ctx,3,local+1); /*transform*/
	local[1]= w;
	goto irtgeoIF184;
irtgeoIF183:
	local[1]= argv[2];
	local[2]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(pointer)TRANSFORM(ctx,2,local+1); /*transform*/
	local[1]= w;
irtgeoIF184:
	w = local[1];
	local[0]= w;
irtgeoBLK180:
	ctx->vsp=local; return(local[0]);}

/*:rotate-vector*/
static pointer irtgeoM185cascaded_coords_rotate_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtgeoENT188;}
	local[0]= NIL;
irtgeoENT188:
irtgeoENT187:
	if (n>4) maerror();
	local[1]= argv[0];
	local[2]= fqv[44];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[7];
	local[3]= argv[2];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
irtgeoBLK186:
	ctx->vsp=local; return(local[0]);}

/*:inverse-rotate-vector*/
static pointer irtgeoM189cascaded_coords_inverse_rotate_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtgeoENT192;}
	local[0]= NIL;
irtgeoENT192:
irtgeoENT191:
	if (n>4) maerror();
	local[1]= argv[0];
	local[2]= fqv[44];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[76];
	local[3]= argv[2];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
irtgeoBLK190:
	ctx->vsp=local; return(local[0]);}

/*:inverse-transform-vector*/
static pointer irtgeoM193coordinates_inverse_transform_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtgeoENT198;}
	local[0]= NIL;
irtgeoENT198:
	if (n>=5) { local[1]=(argv[4]); goto irtgeoENT197;}
	local[1]= NIL;
irtgeoENT197:
	if (n>=6) { local[2]=(argv[5]); goto irtgeoENT196;}
	local[2]= NIL;
irtgeoENT196:
irtgeoENT195:
	if (n>6) maerror();
	if (local[2]==NIL) goto irtgeoIF199;
	local[3]= argv[0]->c.obj.iv[1];
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)TRANSPOSE(ctx,2,local+3); /*transpose*/
	local[3]= w;
	goto irtgeoIF200;
irtgeoIF199:
	local[3]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(pointer)TRANSPOSE(ctx,1,local+3); /*transpose*/
	local[3]= w;
irtgeoIF200:
	if (local[0]==NIL) goto irtgeoIF201;
	if (local[1]==NIL) goto irtgeoIF201;
	if (local[2]==NIL) goto irtgeoIF201;
	local[4]= local[3];
	local[5]= argv[2];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)TRANSFORM(ctx,3,local+4); /*transform*/
	local[4]= w;
	local[5]= local[3];
	local[6]= argv[0]->c.obj.iv[2];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)TRANSFORM(ctx,3,local+5); /*transform*/
	local[5]= w;
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)VMINUS(ctx,3,local+4); /*v-*/
	local[4]= w;
	goto irtgeoIF202;
irtgeoIF201:
	local[4]= local[3];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)TRANSFORM(ctx,2,local+4); /*transform*/
	local[4]= w;
	local[5]= local[3];
	local[6]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+7;
	w=(pointer)TRANSFORM(ctx,2,local+5); /*transform*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)VMINUS(ctx,2,local+4); /*v-*/
	local[4]= w;
irtgeoIF202:
	w = local[4];
	local[0]= w;
irtgeoBLK194:
	ctx->vsp=local; return(local[0]);}

/*:inverse-transform-vector*/
static pointer irtgeoM203cascaded_coords_inverse_transform_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtgeoENT208;}
	local[0]= NIL;
irtgeoENT208:
	if (n>=5) { local[1]=(argv[4]); goto irtgeoENT207;}
	local[1]= NIL;
irtgeoENT207:
	if (n>=6) { local[2]=(argv[5]); goto irtgeoENT206;}
	local[2]= NIL;
irtgeoENT206:
irtgeoENT205:
	if (n>6) maerror();
	local[3]= argv[0];
	local[4]= fqv[44];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= fqv[15];
	local[5]= argv[2];
	local[6]= local[0];
	local[7]= local[1];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,6,local+3); /*send*/
	local[0]= w;
irtgeoBLK204:
	ctx->vsp=local; return(local[0]);}

/*orient-coords-to-axis*/
static pointer irtgeoF3orient_coords_to_axis(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgeoENT212;}
	local[0]= fqv[12];
irtgeoENT212:
	if (n>=4) { local[1]=(argv[3]); goto irtgeoENT211;}
	local[1]= loadglobal(fqv[77]);
irtgeoENT211:
irtgeoENT210:
	if (n>4) maerror();
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(*ftab[4])(ctx,1,local+2,&ftab[4],fqv[26]); /*normalize-vector*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[7];
	local[5]= local[0];
	local[6]= local[5];
	if (fqv[8]!=local[6]) goto irtgeoIF213;
	local[6]= fqv[78];
	goto irtgeoIF214;
irtgeoIF213:
	local[6]= local[5];
	if (fqv[79]!=local[6]) goto irtgeoIF215;
	local[6]= fqv[80];
	goto irtgeoIF216;
irtgeoIF215:
	local[6]= local[5];
	if (fqv[10]!=local[6]) goto irtgeoIF217;
	local[6]= fqv[81];
	goto irtgeoIF218;
irtgeoIF217:
	local[6]= local[5];
	if (fqv[82]!=local[6]) goto irtgeoIF219;
	local[6]= fqv[83];
	goto irtgeoIF220;
irtgeoIF219:
	local[6]= local[5];
	if (fqv[12]!=local[6]) goto irtgeoIF221;
	local[6]= fqv[84];
	goto irtgeoIF222;
irtgeoIF221:
	local[6]= local[5];
	if (fqv[85]!=local[6]) goto irtgeoIF223;
	local[6]= fqv[86];
	goto irtgeoIF224;
irtgeoIF223:
	if (T==NIL) goto irtgeoIF225;
	local[6]= local[0];
	goto irtgeoIF226;
irtgeoIF225:
	local[6]= NIL;
irtgeoIF226:
irtgeoIF224:
irtgeoIF222:
irtgeoIF220:
irtgeoIF218:
irtgeoIF216:
irtgeoIF214:
	w = local[6];
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	local[4]= local[3];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+4); /*v**/
	local[4]= w;
	local[5]= local[2];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)VINNERPRODUCT(ctx,2,local+5); /*v.*/
	local[5]= w;
	local[6]= local[5];
	local[7]= makeflt(1.0000000000000000000000e+00);
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(*ftab[9])(ctx,3,local+6,&ftab[9],fqv[87]); /*eps=*/
	if (w==NIL) goto irtgeoCON228;
	w = argv[0];
	ctx->vsp=local+6;
	local[0]=w;
	goto irtgeoBLK209;
	goto irtgeoCON227;
irtgeoCON228:
	local[6]= local[5];
	local[7]= makeflt(-1.0000000000000000000000e+00);
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(*ftab[9])(ctx,3,local+6,&ftab[9],fqv[87]); /*eps=*/
	if (w==NIL) goto irtgeoCON229;
	local[6]= NIL;
	local[7]= fqv[88];
	local[8]= fqv[89];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
irtgeoWHL231:
	if (local[7]==NIL) goto irtgeoWHX232;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= local[3];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)VINNERPRODUCT(ctx,2,local+8); /*v.*/
	local[8]= w;
	local[9]= local[8];
	ctx->vsp=local+10;
	w=(pointer)ABS(ctx,1,local+9); /*abs*/
	local[9]= w;
	local[10]= makeflt(1.0000000000000000000000e+00);
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(*ftab[9])(ctx,3,local+9,&ftab[9],fqv[87]); /*eps=*/
	if (w!=NIL) goto irtgeoIF234;
	local[9]= local[6];
	local[10]= local[8];
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)SCALEVEC(ctx,2,local+10); /*scale*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)VMINUS(ctx,2,local+9); /*v-*/
	local[4] = w;
	w = NIL;
	ctx->vsp=local+9;
	local[6]=w;
	goto irtgeoBLK230;
	goto irtgeoIF235;
irtgeoIF234:
	local[9]= NIL;
irtgeoIF235:
	w = local[9];
	goto irtgeoWHL231;
irtgeoWHX232:
	local[8]= NIL;
irtgeoBLK233:
	w = NIL;
	local[6]= w;
irtgeoBLK230:
	goto irtgeoCON227;
irtgeoCON229:
	local[6]= T;
	if (local[6]!=NIL) goto irtgeoCON227;
irtgeoCON236:
	local[6]= NIL;
irtgeoCON227:
	local[6]= argv[0];
	local[7]= fqv[90];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(*ftab[3])(ctx,1,local+8,&ftab[3],fqv[25]); /*acos*/
	local[8]= w;
	local[9]= local[4];
	local[10]= fqv[91];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,5,local+6); /*send*/
	w = argv[0];
	local[0]= w;
irtgeoBLK209:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtgeoM237bodyset_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtgeoRST239:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[92], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtgeoKEY240;
	local[3]= NIL;
	local[4]= fqv[93];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)ADDRESS(ctx,1,local+5); /*system:address*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,3,local+3); /*format*/
	local[3]= w;
	local[4]= fqv[94];
	ctx->vsp=local+5;
	w=(pointer)INTERN(ctx,2,local+3); /*intern*/
	local[1] = w;
irtgeoKEY240:
	if (n & (1<<1)) goto irtgeoKEY241;
	local[2] = NIL;
irtgeoKEY241:
	local[3]= (pointer)get_sym_func(fqv[95]);
	local[4]= argv[0];
	local[5]= *(ovafptr(argv[1],fqv[60]));
	local[6]= fqv[96];
	local[7]= fqv[97];
	local[8]= local[1];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)APPLY(ctx,7,local+3); /*apply*/
	local[3]= argv[2];
	local[4]= fqv[98];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	argv[0]->c.obj.iv[8] = local[2];
	if (argv[0]->c.obj.iv[8]==NIL) goto irtgeoIF242;
	local[3]= argv[0];
	local[4]= fqv[99];
	w=argv[0]->c.obj.iv[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto irtgeoIF243;
irtgeoIF242:
	local[3]= NIL;
irtgeoIF243:
	local[3]= argv[0];
	local[4]= fqv[44];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	w = argv[0];
	local[0]= w;
irtgeoBLK238:
	ctx->vsp=local; return(local[0]);}

/*:bodies*/
static pointer irtgeoM244bodyset_bodies(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtgeoRST246:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[8];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[10])(ctx,2,local+1,&ftab[10],fqv[100]); /*user::forward-message-to-all*/
	local[0]= w;
irtgeoBLK245:
	ctx->vsp=local; return(local[0]);}

/*:faces*/
static pointer irtgeoM247bodyset_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[8];
	local[1]= fqv[101];
	ctx->vsp=local+2;
	w=(*ftab[11])(ctx,2,local+0,&ftab[11],fqv[102]); /*send-all*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[12])(ctx,1,local+0,&ftab[12],fqv[103]); /*flatten*/
	local[0]= w;
irtgeoBLK248:
	ctx->vsp=local; return(local[0]);}

/*:worldcoords*/
static pointer irtgeoM249bodyset_worldcoords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[7]==NIL) goto irtgeoIF251;
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[60]));
	local[2]= fqv[44];
	ctx->vsp=local+3;
	w=(pointer)SENDMESSAGE(ctx,3,local+0); /*send-message*/
	local[0]= NIL;
	local[1]= argv[0]->c.obj.iv[8];
irtgeoWHL253:
	if (local[1]==NIL) goto irtgeoWHX254;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= local[0];
	local[3]= fqv[44];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	goto irtgeoWHL253;
irtgeoWHX254:
	local[2]= NIL;
irtgeoBLK255:
	w = NIL;
	local[0]= w;
	goto irtgeoIF252;
irtgeoIF251:
	local[0]= NIL;
irtgeoIF252:
	w = argv[0]->c.obj.iv[5];
	local[0]= w;
irtgeoBLK250:
	ctx->vsp=local; return(local[0]);}

/*:draw-on*/
static pointer irtgeoM256bodyset_draw_on(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtgeoRST258:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= NIL;
	local[2]= argv[0]->c.obj.iv[8];
irtgeoWHL259:
	if (local[2]==NIL) goto irtgeoWHX260;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= (pointer)get_sym_func(fqv[104]);
	local[4]= local[1];
	local[5]= fqv[105];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)APPLY(ctx,4,local+3); /*apply*/
	goto irtgeoWHL259;
irtgeoWHX260:
	local[3]= NIL;
irtgeoBLK261:
	w = NIL;
	local[0]= w;
irtgeoBLK257:
	ctx->vsp=local; return(local[0]);}

/*face-to-triangle-aux*/
static pointer irtgeoF4face_to_triangle_aux(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	if (argv[0]!=NIL) goto irtgeoCON264;
	local[0]= NIL;
	goto irtgeoCON263;
irtgeoCON264:
	local[0]= argv[0];
	local[1]= fqv[106];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	if (makeint((eusinteger_t)3L)!=local[0]) goto irtgeoCON265;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto irtgeoCON263;
irtgeoCON265:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)irtgeoF5face_to_triangle(ctx,1,local+0); /*face-to-triangle*/
	local[0]= w;
	goto irtgeoCON263;
irtgeoCON266:
	local[0]= NIL;
irtgeoCON263:
	w = local[0];
	local[0]= w;
irtgeoBLK262:
	ctx->vsp=local; return(local[0]);}

/*face-to-triangle*/
static pointer irtgeoF5face_to_triangle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[107]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto irtgeoIF268;
	local[0]= argv[0];
	local[1]= fqv[108];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	if (w==NIL) goto irtgeoIF268;
	local[0]= argv[0];
	local[1]= fqv[108];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	if (w==NIL) goto irtgeoIF270;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)irtgeoF8face_to_triangle_make_simple(ctx,1,local+0); /*face-to-triangle-make-simple*/
	argv[0] = w;
	local[0]= argv[0];
	goto irtgeoIF271;
irtgeoIF270:
	local[0]= NIL;
irtgeoIF271:
	goto irtgeoIF269;
irtgeoIF268:
	local[0]= NIL;
irtgeoIF269:
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[0];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)irtgeoF6face_to_tessel_triangle(ctx,2,local+1); /*face-to-tessel-triangle*/
	local[1]= w;
irtgeoWHL272:
	if (local[1]!=NIL) goto irtgeoWHX273;
	local[2]= local[0];
	local[3]= argv[0];
	local[4]= fqv[109];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)GREQP(ctx,2,local+2); /*>=*/
	if (w==NIL) goto irtgeoIF275;
	w = NIL;
	ctx->vsp=local+2;
	local[0]=w;
	goto irtgeoBLK267;
	goto irtgeoIF276;
irtgeoIF275:
	local[2]= NIL;
irtgeoIF276:
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	local[2]= argv[0];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)irtgeoF6face_to_tessel_triangle(ctx,2,local+2); /*face-to-tessel-triangle*/
	local[1] = w;
	goto irtgeoWHL272;
irtgeoWHX273:
	local[2]= NIL;
irtgeoBLK274:
	local[2]= local[1];
	local[3]= argv[0];
	local[4]= local[0];
	local[5]= local[1];
	local[6]= fqv[106];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)irtgeoF7face_to_triangle_rest_polygon(ctx,3,local+3); /*face-to-triangle-rest-polygon*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)irtgeoF4face_to_triangle_aux(ctx,1,local+3); /*face-to-triangle-aux*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	local[0]= w;
irtgeoBLK267:
	ctx->vsp=local; return(local[0]);}

/*face-to-tessel-triangle*/
static pointer irtgeoF6face_to_tessel_triangle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgeoENT279;}
	local[0]= makeflt(9.9999999999999964869129e-11);
irtgeoENT279:
	w = local[0];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[77],w);
irtgeoENT278:
	if (n>3) maerror();
	local[3]= argv[0];
	local[4]= fqv[109];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
	local[5]= argv[1];
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SUB1(ctx,1,local+5); /*1-*/
	local[5]= w;
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)MOD(ctx,2,local+5); /*mod*/
	local[5]= w;
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)NTH(ctx,2,local+5); /*nth*/
	local[5]= w;
	local[6]= argv[1];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)MOD(ctx,2,local+6); /*mod*/
	local[6]= w;
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)NTH(ctx,2,local+6); /*nth*/
	local[6]= w;
	local[7]= argv[1];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[7]= w;
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)MOD(ctx,2,local+7); /*mod*/
	local[7]= w;
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)NTH(ctx,2,local+7); /*nth*/
	local[7]= w;
	local[8]= local[6];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)VMINUS(ctx,2,local+8); /*v-*/
	local[8]= w;
	local[9]= local[7];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)VMINUS(ctx,2,local+9); /*v-*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+8); /*v**/
	local[8]= w;
	local[9]= argv[0];
	local[10]= fqv[110];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)VINNERPRODUCT(ctx,2,local+8); /*v.*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)GREATERP(ctx,2,local+8); /*>*/
	if (w!=NIL) goto irtgeoIF280;
	w = NIL;
	ctx->vsp=local+8;
	unwind(ctx,local+0);
	local[0]=w;
	goto irtgeoBLK277;
	goto irtgeoIF281;
irtgeoIF280:
	local[8]= NIL;
irtgeoIF281:
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtgeoCLO282,env,argv,local);
	local[9]= local[5];
	local[10]= local[6];
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,3,local+9); /*list*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MAPCAR(ctx,2,local+8); /*mapcar*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[13])(ctx,1,local+8,&ftab[13],fqv[111]); /*make-face-from-vertices*/
	local[8]= w;
	local[9]= local[5];
	local[10]= local[6];
	local[11]= local[7];
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(*ftab[14])(ctx,2,local+11,&ftab[14],fqv[112]); /*remove*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[14])(ctx,2,local+10,&ftab[14],fqv[112]); /*remove*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[14])(ctx,2,local+9,&ftab[14],fqv[112]); /*remove*/
	local[9]= w;
	local[10]= NIL;
	ctx->vsp=local+11;
	local[11]= makeclosure(codevec,quotevec,irtgeoCLO284,env,argv,local);
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(*ftab[15])(ctx,2,local+11,&ftab[15],fqv[113]); /*every*/
	local[11]= w;
	if (w==NIL) goto irtgeoAND283;
	ctx->vsp=local+11;
	local[11]= makeclosure(codevec,quotevec,irtgeoCLO285,env,argv,local);
	local[12]= local[8];
	local[13]= fqv[106];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(*ftab[15])(ctx,2,local+11,&ftab[15],fqv[113]); /*every*/
	local[11]= w;
	if (w==NIL) goto irtgeoAND283;
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
	w = makeint((eusinteger_t)3L);
	if ((eusinteger_t)local[11] <= (eusinteger_t)w) goto irtgeoIF286;
	ctx->vsp=local+11;
	local[11]= makeclosure(codevec,quotevec,irtgeoCLO288,env,argv,local);
	local[12]= loadglobal(fqv[107]);
	ctx->vsp=local+13;
	w=(pointer)INSTANTIATE(ctx,1,local+12); /*instantiate*/
	local[12]= w;
	local[13]= local[12];
	local[14]= fqv[96];
	local[15]= fqv[109];
	local[16]= local[9];
	ctx->vsp=local+17;
	w=(pointer)BUTLAST(ctx,1,local+16); /*butlast*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,4,local+13); /*send*/
	w = local[12];
	local[12]= w;
	local[13]= fqv[106];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(*ftab[15])(ctx,2,local+11,&ftab[15],fqv[113]); /*every*/
	local[11]= w;
	goto irtgeoIF287;
irtgeoIF286:
	local[11]= T;
irtgeoIF287:
irtgeoAND283:
	local[10] = local[11];
	if (local[10]==NIL) goto irtgeoIF289;
	local[11]= local[8];
	goto irtgeoIF290;
irtgeoIF289:
	local[11]= NIL;
irtgeoIF290:
	w = local[11];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtgeoBLK277:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgeoCLO282(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtgeoCLO291,env,argv,local);
	local[2]= env->c.clo.env1[0];
	local[3]= fqv[106];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MAPCAN(ctx,2,local+1); /*mapcan*/
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgeoCLO291(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= argv[0];
	local[2]= fqv[109];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (memq(local[0],w)==NIL) goto irtgeoIF292;
	local[0]= loadglobal(fqv[114]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[96];
	local[3]= fqv[115];
	local[4]= argv[0];
	local[5]= fqv[115];
	local[6]= env->c.clo.env0->c.clo.env1[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= fqv[116];
	local[6]= argv[0];
	local[7]= fqv[116];
	local[8]= env->c.clo.env0->c.clo.env1[0];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	w = local[0];
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto irtgeoIF293;
irtgeoIF292:
	local[0]= NIL;
irtgeoIF293:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgeoCLO284(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[117];
	local[1]= env->c.clo.env2[8];
	local[2]= fqv[118];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	w = ((((w)==(local[0])?T:NIL))==NIL?T:NIL);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgeoCLO285(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtgeoCLO294,env,argv,local);
	local[1]= env->c.clo.env2[9];
	ctx->vsp=local+2;
	w=(*ftab[15])(ctx,2,local+0,&ftab[15],fqv[113]); /*every*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgeoCLO294(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[119];
	local[2]= argv[0];
	local[3]= loadglobal(fqv[77]);
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	local[1]= local[0];
	if (local[1]==NIL) goto irtgeoAND295;
	local[1]= makeflt(0.0000000000000000000000e+00);
	local[2]= local[0];
	local[3]= makeflt(1.0000000000000000000000e+00);
	local[4]= loadglobal(fqv[77]);
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,1,local+4); /*-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[16])(ctx,4,local+1,&ftab[16],fqv[120]); /*eps-in-range*/
	local[1]= w;
irtgeoAND295:
	w = ((local[1])==NIL?T:NIL);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgeoCLO288(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env2[5];
	local[1]= env->c.clo.env2[7];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[121]); /*make-line*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[122];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= ((local[1])==NIL?T:NIL);
	if (local[2]!=NIL) goto irtgeoOR296;
	local[2]= local[1];
	local[2]= ((fqv[123])==(local[2])?T:NIL);
	if (local[2]!=NIL) goto irtgeoOR296;
	local[2]= local[1];
	local[2]= ((fqv[124])==(local[2])?T:NIL);
	if (local[2]!=NIL) goto irtgeoOR296;
	w = local[1];
	local[2]= (iscons(w)?T:NIL);
	if (local[2]==NIL) goto irtgeoAND297;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[2]= ((fqv[125])==(local[2])?T:NIL);
	if (local[2]==NIL) goto irtgeoAND297;
	local[2]= makeflt(0.0000000000000000000000e+00);
	local[3]= local[1];
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	local[4]= makeflt(1.0000000000000000000000e+00);
	local[5]= loadglobal(fqv[77]);
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,1,local+5); /*-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[16])(ctx,4,local+2,&ftab[16],fqv[120]); /*eps-in-range*/
	local[2]= ((w)==NIL?T:NIL);
	if (local[2]==NIL) goto irtgeoAND297;
	local[2]= makeflt(0.0000000000000000000000e+00);
	local[3]= local[1];
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	local[4]= makeflt(1.0000000000000000000000e+00);
	local[5]= loadglobal(fqv[77]);
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,1,local+5); /*-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[16])(ctx,4,local+2,&ftab[16],fqv[120]); /*eps-in-range*/
	local[2]= ((w)==NIL?T:NIL);
irtgeoAND297:
irtgeoOR296:
	w = local[2];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*face-to-triangle-rest-polygon*/
static pointer irtgeoF7face_to_triangle_rest_polygon(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[109];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)BUTLAST(ctx,1,local+0); /*butlast*/
	local[0]= w;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	local[2]= argv[1];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)MOD(ctx,2,local+2); /*mod*/
	local[2]= w;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)NTH(ctx,2,local+2); /*nth*/
	local[2]= w;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(*ftab[14])(ctx,2,local+2,&ftab[14],fqv[112]); /*remove*/
	local[2]= w;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	w = makeint((eusinteger_t)2L);
	if ((eusinteger_t)local[3] > (eusinteger_t)w) goto irtgeoIF299;
	w = NIL;
	ctx->vsp=local+3;
	local[0]=w;
	goto irtgeoBLK298;
	goto irtgeoIF300;
irtgeoIF299:
	local[3]= NIL;
irtgeoIF300:
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,irtgeoCLO301,env,argv,local);
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)MAPCAR(ctx,2,local+3); /*mapcar*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[13])(ctx,1,local+3,&ftab[13],fqv[111]); /*make-face-from-vertices*/
	local[0]= w;
irtgeoBLK298:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgeoCLO301(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtgeoCLO302,env,argv,local);
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtgeoCLO303,env,argv,local);
	local[3]= env->c.clo.env1[0];
	local[4]= fqv[106];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[2]= w;
	local[3]= env->c.clo.env1[2];
	ctx->vsp=local+4;
	w=(pointer)APPEND(ctx,2,local+2); /*append*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MAPCAN(ctx,2,local+1); /*mapcan*/
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgeoCLO302(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= argv[0];
	local[2]= fqv[109];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (memq(local[0],w)==NIL) goto irtgeoIF304;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto irtgeoIF305;
irtgeoIF304:
	local[0]= NIL;
irtgeoIF305:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgeoCLO303(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= loadglobal(fqv[114]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[96];
	local[3]= fqv[115];
	local[4]= argv[0];
	local[5]= fqv[115];
	local[6]= env->c.clo.env0->c.clo.env1[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= fqv[116];
	local[6]= argv[0];
	local[7]= fqv[116];
	local[8]= env->c.clo.env0->c.clo.env1[0];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*face-to-triangle-make-simple*/
static pointer irtgeoF8face_to_triangle_make_simple(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
irtgeoWHL307:
	local[7]= argv[0];
	local[8]= fqv[108];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[0] = w;
	if (local[0]==NIL) goto irtgeoWHX308;
	local[3] = NIL;
	local[7]= NIL;
	local[8]= local[0];
irtgeoWHL310:
	if (local[8]==NIL) goto irtgeoWHX311;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[9];
	local[7] = w;
	local[9]= (pointer)get_sym_func(fqv[126]);
	local[10]= argv[0];
	local[11]= fqv[109];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.cdr;
	local[11]= local[7];
	local[12]= fqv[109];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.cdr;
	ctx->vsp=local+12;
	w=(*ftab[18])(ctx,3,local+9,&ftab[18],fqv[127]); /*user::mapjoin*/
	local[2] = w;
	local[9]= NIL;
	local[10]= local[2];
irtgeoWHL313:
	if (local[10]==NIL) goto irtgeoWHX314;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10] = (w)->c.cons.cdr;
	w = local[11];
	local[9] = w;
	ctx->vsp=local+11;
	local[11]= makeclosure(codevec,quotevec,irtgeoCLO316,env,argv,local);
	local[12]= local[0];
	local[13]= fqv[106];
	ctx->vsp=local+14;
	w=(*ftab[11])(ctx,2,local+12,&ftab[11],fqv[102]); /*send-all*/
	local[12]= w;
	local[13]= argv[0];
	local[14]= fqv[106];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)APPEND(ctx,2,local+12); /*append*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(*ftab[12])(ctx,1,local+12,&ftab[12],fqv[103]); /*flatten*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)MAPCAN(ctx,2,local+11); /*mapcan*/
	local[6] = w;
	if (local[6]!=NIL) goto irtgeoIF317;
	if (local[3]==NIL) goto irtgeoIF319;
	local[11]= local[3];
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.cdr;
	ctx->vsp=local+14;
	w=(pointer)VDISTANCE(ctx,2,local+12); /*distance*/
	local[1] = w;
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(pointer)GREATERP(ctx,2,local+11); /*>*/
	if (w==NIL) goto irtgeoIF321;
	local[3] = local[1];
	local[4] = local[9];
	local[5] = local[7];
	local[11]= local[5];
	goto irtgeoIF322;
irtgeoIF321:
	local[11]= NIL;
irtgeoIF322:
	goto irtgeoIF320;
irtgeoIF319:
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.cdr;
	ctx->vsp=local+13;
	w=(pointer)VDISTANCE(ctx,2,local+11); /*distance*/
	local[3] = w;
	local[4] = local[9];
	local[5] = local[7];
	local[11]= local[5];
irtgeoIF320:
	goto irtgeoIF318;
irtgeoIF317:
	local[11]= NIL;
irtgeoIF318:
	goto irtgeoWHL313;
irtgeoWHX314:
	local[11]= NIL;
irtgeoBLK315:
	w = NIL;
	goto irtgeoWHL310;
irtgeoWHX311:
	local[9]= NIL;
irtgeoBLK312:
	w = NIL;
	if (local[3]==NIL) goto irtgeoIF323;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= argv[0];
	local[9]= fqv[109];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[19])(ctx,2,local+7,&ftab[19],fqv[128]); /*position*/
	local[7]= w;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.cdr;
	local[9]= local[5];
	local[10]= fqv[109];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[19])(ctx,2,local+8,&ftab[19],fqv[128]); /*position*/
	local[8]= w;
	local[9]= loadglobal(fqv[107]);
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,1,local+9); /*instantiate*/
	local[9]= w;
	local[10]= local[9];
	local[11]= fqv[96];
	local[12]= fqv[109];
	local[13]= argv[0];
	local[14]= fqv[109];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	local[14]= makeint((eusinteger_t)0L);
	local[15]= local[7];
	ctx->vsp=local+16;
	w=(pointer)SUBSEQ(ctx,3,local+13); /*subseq*/
	local[13]= w;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	ctx->vsp=local+15;
	w=(pointer)COPYOBJ(ctx,1,local+14); /*copy-object*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	local[14]= w;
	local[15]= local[5];
	local[16]= fqv[109];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)BUTLAST(ctx,1,local+15); /*butlast*/
	local[15]= w;
	local[16]= local[8];
	ctx->vsp=local+17;
	w=(pointer)SUBSEQ(ctx,2,local+15); /*subseq*/
	local[15]= w;
	local[16]= local[5];
	local[17]= fqv[109];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[16]= w;
	local[17]= makeint((eusinteger_t)0L);
	local[18]= local[8];
	ctx->vsp=local+19;
	w=(pointer)SUBSEQ(ctx,3,local+16); /*subseq*/
	local[16]= w;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.cdr;
	ctx->vsp=local+18;
	w=(pointer)COPYOBJ(ctx,1,local+17); /*copy-object*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)LIST(ctx,1,local+17); /*list*/
	local[17]= w;
	local[18]= argv[0];
	local[19]= fqv[109];
	ctx->vsp=local+20;
	w=(pointer)SEND(ctx,2,local+18); /*send*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)BUTLAST(ctx,1,local+18); /*butlast*/
	local[18]= w;
	local[19]= local[7];
	ctx->vsp=local+20;
	w=(pointer)SUBSEQ(ctx,2,local+18); /*subseq*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)NCONC(ctx,6,local+13); /*nconc*/
	local[13]= w;
	local[14]= fqv[108];
	local[15]= local[5];
	local[16]= local[0];
	ctx->vsp=local+17;
	w=(*ftab[14])(ctx,2,local+15,&ftab[14],fqv[112]); /*remove*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,6,local+10); /*send*/
	w = local[9];
	argv[0] = w;
	w = argv[0];
	local[7]= w;
	goto irtgeoIF324;
irtgeoIF323:
	local[7]= fqv[129];
	local[8]= argv[0];
	ctx->vsp=local+9;
	w=(*ftab[20])(ctx,2,local+7,&ftab[20],fqv[130]); /*warn*/
	w = NIL;
	ctx->vsp=local+7;
	local[7]=w;
	goto irtgeoBLK309;
irtgeoIF324:
	goto irtgeoWHL307;
irtgeoWHX308:
	local[7]= NIL;
irtgeoBLK309:
	w = argv[0];
	local[0]= w;
irtgeoBLK306:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgeoCLO316(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= *(ovafptr(argv[0],fqv[131]));
	local[1]= *(ovafptr(argv[0],fqv[132]));
	w=env->c.clo.env2[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=env->c.clo.env2[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	ctx->vsp=local+4;
	w=(pointer)LINEINTERSECTION3(ctx,4,local+0); /*line-intersection3*/
	local[0]= w;
	local[1]= makeflt(0.0000000000000000000000e+00);
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+4;
	w=(pointer)LSEQP(ctx,3,local+1); /*<=*/
	if (w==NIL) goto irtgeoIF325;
	local[1]= makeflt(0.0000000000000000000000e+00);
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,3,local+1); /*<*/
	if (w==NIL) goto irtgeoIF325;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[1]= w;
	goto irtgeoIF326;
irtgeoIF325:
	local[1]= NIL;
irtgeoIF326:
	w = local[1];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*body-to-faces*/
static pointer irtgeoF9body_to_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= NIL;
	ctx->vsp=local+2;
	w=(pointer)irtgeoF10body_to_triangles(ctx,2,local+0); /*body-to-triangles*/
	local[0]= w;
irtgeoBLK327:
	ctx->vsp=local; return(local[0]);}

/*body-to-triangles*/
static pointer irtgeoF10body_to_triangles(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto irtgeoENT330;}
	local[0]= makeint((eusinteger_t)50L);
irtgeoENT330:
irtgeoENT329:
	if (n>2) maerror();
	local[1]= NIL;
	local[2]= NIL;
	storeglobal(fqv[133],local[2]);
	local[2]= NIL;
	storeglobal(fqv[134],local[2]);
	local[2]= NIL;
	local[3]= argv[0];
	local[4]= fqv[101];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
irtgeoWHL331:
	if (local[3]==NIL) goto irtgeoWHX332;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= local[1];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtgeoCLO334,env,argv,local);
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)irtgeoF5face_to_triangle(ctx,1,local+6); /*face-to-triangle*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MAPCAN(ctx,2,local+5); /*mapcan*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)NCONC(ctx,2,local+4); /*nconc*/
	local[1] = w;
	goto irtgeoWHL331;
irtgeoWHX332:
	local[4]= NIL;
irtgeoBLK333:
	w = NIL;
	local[2]= loadglobal(fqv[135]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= local[2];
	local[4]= fqv[96];
	local[5]= fqv[101];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	w = local[2];
	local[0]= w;
irtgeoBLK328:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgeoCLO334(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	if (env->c.clo.env2[0]==NIL) goto irtgeoIF335;
	local[0]= argv[0];
	local[1]= env->c.clo.env2[0];
	ctx->vsp=local+2;
	w=(pointer)irtgeoF11triangle_to_triangle(ctx,2,local+0); /*triangle-to-triangle*/
	local[0]= w;
	goto irtgeoIF336;
irtgeoIF335:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
irtgeoIF336:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*triangle-to-triangle*/
static pointer irtgeoF11triangle_to_triangle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto irtgeoENT339;}
	local[0]= makeint((eusinteger_t)50L);
irtgeoENT339:
irtgeoENT338:
	if (n>2) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= NIL;
	local[10]= argv[0];
	local[11]= fqv[106];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
irtgeoWHL340:
	if (local[10]==NIL) goto irtgeoWHX341;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10] = (w)->c.cons.cdr;
	w = local[11];
	local[9] = w;
	local[11]= local[9];
	w = loadglobal(fqv[134]);
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	storeglobal(fqv[134],local[11]);
	goto irtgeoWHL340;
irtgeoWHX341:
	local[11]= NIL;
irtgeoBLK342:
	w = NIL;
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,irtgeoFLET343,env,argv,local);
	local[10]= argv[0];
	local[11]= fqv[106];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	local[11]= makeclosure(codevec,quotevec,irtgeoCLO344,env,argv,local);
	local[12]= (pointer)get_sym_func(fqv[136]);
	ctx->vsp=local+13;
	w=(*ftab[21])(ctx,3,local+10,&ftab[21],fqv[137]); /*find-extream*/
	local[1] = w;
	if (local[0]==NIL) goto irtgeoOR347;
	local[10]= local[1];
	local[11]= fqv[138];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(pointer)LESSP(ctx,2,local+10); /*<*/
	if (w!=NIL) goto irtgeoOR347;
	goto irtgeoIF345;
irtgeoOR347:
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[0]=w;
	goto irtgeoBLK337;
	goto irtgeoIF346;
irtgeoIF345:
	local[10]= local[1];
	local[11]= fqv[109];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	local[11]= argv[0];
	local[12]= fqv[109];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.cdr;
	local[12]= fqv[139];
	local[13]= (pointer)get_sym_func(fqv[140]);
	ctx->vsp=local+14;
	w=(*ftab[22])(ctx,4,local+10,&ftab[22],fqv[141]); /*set-exclusive-or*/
	local[2] = w;
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)LENGTH(ctx,1,local+10); /*length*/
	local[10]= w;
	if (makeint((eusinteger_t)1L)==local[10]) goto irtgeoIF348;
	local[10]= fqv[142];
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(*ftab[20])(ctx,2,local+10,&ftab[20],fqv[130]); /*warn*/
	local[10]= w;
	goto irtgeoIF349;
irtgeoIF348:
	local[10]= NIL;
irtgeoIF349:
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w = local[9];
	ctx->vsp=local+11;
	w=irtgeoFLET343(ctx,1,local+10,w);
	local[3] = w;
	local[10]= local[1];
	local[11]= fqv[115];
	local[12]= argv[0];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[10]= w;
	w = local[9];
	ctx->vsp=local+11;
	w=irtgeoFLET343(ctx,1,local+10,w);
	local[5] = w;
	local[10]= local[1];
	local[11]= fqv[116];
	local[12]= argv[0];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[10]= w;
	w = local[9];
	ctx->vsp=local+11;
	w=irtgeoFLET343(ctx,1,local+10,w);
	local[6] = w;
	local[10]= local[1];
	local[11]= fqv[143];
	local[12]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[7] = w;
	local[10]= local[7];
	local[11]= loadglobal(fqv[133]);
	local[12]= fqv[139];
	local[13]= (pointer)get_sym_func(fqv[144]);
	ctx->vsp=local+14;
	w=(*ftab[23])(ctx,4,local+10,&ftab[23],fqv[145]); /*member*/
	if (w==NIL) goto irtgeoIF350;
	local[10]= local[7];
	local[11]= loadglobal(fqv[133]);
	local[12]= fqv[139];
	local[13]= (pointer)get_sym_func(fqv[144]);
	ctx->vsp=local+14;
	w=(*ftab[23])(ctx,4,local+10,&ftab[23],fqv[145]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.car;
	local[10]= local[7];
	goto irtgeoIF351;
irtgeoIF350:
	local[10]= NIL;
irtgeoIF351:
	local[10]= local[7];
	w = loadglobal(fqv[133]);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	storeglobal(fqv[133],local[10]);
	local[10]= local[7];
	w = local[9];
	ctx->vsp=local+11;
	w=irtgeoFLET343(ctx,1,local+10,w);
	local[4] = w;
	local[10]= local[5];
	local[11]= local[4];
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,3,local+10); /*list*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[13])(ctx,1,local+10,&ftab[13],fqv[111]); /*make-face-from-vertices*/
	local[10]= w;
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(pointer)irtgeoF11triangle_to_triangle(ctx,2,local+10); /*triangle-to-triangle*/
	local[10]= w;
	local[11]= local[6];
	local[12]= local[3];
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,3,local+11); /*list*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[13])(ctx,1,local+11,&ftab[13],fqv[111]); /*make-face-from-vertices*/
	local[11]= w;
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)irtgeoF11triangle_to_triangle(ctx,2,local+11); /*triangle-to-triangle*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)NCONC(ctx,2,local+10); /*nconc*/
	local[10]= w;
irtgeoIF346:
	w = local[10];
	local[0]= w;
irtgeoBLK337:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgeoFLET343(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtgeoCLO352,env,argv,local);
	local[2]= loadglobal(fqv[134]);
	ctx->vsp=local+3;
	w=(pointer)MAPCAN(ctx,2,local+1); /*mapcan*/
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgeoCLO352(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= argv[0];
	local[2]= fqv[109];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (memq(local[0],w)==NIL) goto irtgeoIF353;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto irtgeoIF354;
irtgeoIF353:
	local[0]= NIL;
irtgeoIF354:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgeoCLO344(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[138];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*make-sphere*/
static pointer irtgeoF12make_sphere(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtgeoRST356:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[24])(ctx,1,local+1,&ftab[24],fqv[146]); /*make-icosahedron*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[25])(ctx,1,local+1,&ftab[25],fqv[147]); /*make-gdome*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[41];
	local[4]= (pointer)get_sym_func(fqv[6]);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,2,local+4); /*apply*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= local[1];
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= local[1];
	local[3]= fqv[148];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= fqv[149];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)NCONC(ctx,2,local+2); /*nconc*/
	w = local[1];
	local[0]= w;
irtgeoBLK355:
	ctx->vsp=local; return(local[0]);}

/*make-ring*/
static pointer irtgeoF13make_ring(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtgeoRST358:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[150], &argv[2], n-2, local+1, 0);
	if (n & (1<<0)) goto irtgeoKEY359;
	local[1] = makeint((eusinteger_t)16L);
irtgeoKEY359:
	local[2]= NIL;
	local[3]= makeflt(6.2831853071795862319959e+00);
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[1];
irtgeoWHL360:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto irtgeoWHX361;
	local[6]= argv[1];
	local[7]= local[4];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)COS(ctx,1,local+7); /*cos*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,2,local+6); /*+*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= argv[1];
	local[9]= local[4];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SIN(ctx,1,local+9); /*sin*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,3,local+6); /*float-vector*/
	local[6]= w;
	w = local[2];
	ctx->vsp=local+7;
	local[2] = cons(ctx,local[6],w);
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto irtgeoWHL360;
irtgeoWHX361:
	local[6]= NIL;
irtgeoBLK362:
	w = NIL;
	local[4]= (pointer)get_sym_func(fqv[151]);
	local[5]= local[2];
	local[6]= fqv[152];
	local[7]= local[1];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)APPLY(ctx,5,local+4); /*apply*/
	local[0]= w;
irtgeoBLK357:
	ctx->vsp=local; return(local[0]);}

/*make-fan-cylinder*/
static pointer irtgeoF14make_fan_cylinder(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtgeoRST364:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[153], &argv[2], n-2, local+1, 0);
	if (n & (1<<0)) goto irtgeoKEY365;
	local[1] = makeint((eusinteger_t)12L);
irtgeoKEY365:
	if (n & (1<<1)) goto irtgeoKEY366;
	local[2] = makeflt(6.2831853071795862319959e+00);
irtgeoKEY366:
	if (n & (1<<2)) goto irtgeoKEY367;
	local[4]= local[2];
	local[5]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[3] = w;
irtgeoKEY367:
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtgeoCLO368,env,argv,local);
	local[5]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtgeoCLO369,env,argv,local);
	local[7]= local[1];
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,2,local+7); /*+*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[26])(ctx,1,local+7,&ftab[26],fqv[154]); /*make-list*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MAPCAR(ctx,2,local+6); /*mapcar*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MAPCAR(ctx,2,local+4); /*mapcar*/
	local[4]= w;
	local[5]= local[2];
	local[6]= makeflt(6.2831853071795862319959e+00);
	ctx->vsp=local+7;
	w=(*ftab[9])(ctx,2,local+5,&ftab[9],fqv[87]); /*eps=*/
	if (w==NIL) goto irtgeoIF370;
	local[5]= local[4];
	ctx->vsp=local+6;
	w=(pointer)REVERSE(ctx,1,local+5); /*reverse*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.cdr;
	goto irtgeoIF371;
irtgeoIF370:
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[5]= w;
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)REVERSE(ctx,1,local+6); /*reverse*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
irtgeoIF371:
	local[6]= argv[1];
	local[7]= fqv[155];
	local[8]= fqv[156];
	local[9]= argv[0];
	local[10]= argv[1];
	local[11]= local[1];
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,5,local+8); /*list*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[27])(ctx,4,local+5,&ftab[27],fqv[157]); /*make-prism*/
	local[0]= w;
irtgeoBLK363:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgeoCLO368(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env2[2];
	local[2]= env->c.clo.env2[1];
	ctx->vsp=local+3;
	w=(pointer)QUOTIENT(ctx,2,local+1); /*/*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= env->c.clo.env2[3];
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	local[0]= w;
	local[1]= env->c.clo.env1[0];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)COS(ctx,1,local+2); /*cos*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	local[2]= env->c.clo.env1[0];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SIN(ctx,1,local+3); /*sin*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,3,local+1); /*float-vector*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgeoCLO369(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env2[5];
	ctx->vsp=local+1;
	w=(pointer)ADD1(ctx,1,local+0); /*1+*/
	env->c.clo.env2[5] = w;
	w = env->c.clo.env2[5];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*x-of-cube*/
static pointer irtgeoF15x_of_cube(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[148];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[158];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[28])(ctx,2,local+1,&ftab[28],fqv[159]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
irtgeoBLK372:
	ctx->vsp=local; return(local[0]);}

/*y-of-cube*/
static pointer irtgeoF16y_of_cube(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[148];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[158];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[28])(ctx,2,local+1,&ftab[28],fqv[159]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
irtgeoBLK373:
	ctx->vsp=local; return(local[0]);}

/*z-of-cube*/
static pointer irtgeoF17z_of_cube(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[148];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[158];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[28])(ctx,2,local+1,&ftab[28],fqv[159]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
irtgeoBLK374:
	ctx->vsp=local; return(local[0]);}

/*height-of-cylinder*/
static pointer irtgeoF18height_of_cylinder(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[148];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[156];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[28])(ctx,2,local+1,&ftab[28],fqv[159]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
irtgeoBLK375:
	ctx->vsp=local; return(local[0]);}

/*radius-of-cylinder*/
static pointer irtgeoF19radius_of_cylinder(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[148];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[156];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[28])(ctx,2,local+1,&ftab[28],fqv[159]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
irtgeoBLK376:
	ctx->vsp=local; return(local[0]);}

/*radius-of-sphere*/
static pointer irtgeoF20radius_of_sphere(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[148];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[149];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[28])(ctx,2,local+1,&ftab[28],fqv[159]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
irtgeoBLK377:
	ctx->vsp=local; return(local[0]);}

/*make-faceset-from-vertices*/
static pointer irtgeoF21make_faceset_from_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
irtgeoWHL379:
	if (argv[0]==NIL) goto irtgeoWHX380;
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,3,local+1); /*list*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)PRINT(ctx,1,local+1); /*print*/
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[1];
	local[1]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[2];
	local[2]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[3];
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,3,local+1); /*list*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[13])(ctx,1,local+1,&ftab[13],fqv[111]); /*make-face-from-vertices*/
	local[1]= w;
	w = local[0];
	ctx->vsp=local+2;
	local[0] = cons(ctx,local[1],w);
	goto irtgeoWHL379;
irtgeoWHX380:
	local[1]= NIL;
irtgeoBLK381:
	local[1]= loadglobal(fqv[135]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[96];
	local[4]= fqv[101];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	w = local[1];
	local[0]= w;
irtgeoBLK378:
	ctx->vsp=local; return(local[0]);}

/*matrix-to-euler-angle*/
static pointer irtgeoF22matrix_to_euler_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= makeflt(9.9999999999999974298988e-07);
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[29])(ctx,1,local+4,&ftab[29],fqv[160]); /*matrixp*/
	if (w==NIL) goto irtgeoAND385;
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[30])(ctx,1,local+4,&ftab[30],fqv[161]); /*array-dimensions*/
	local[4]= w;
	local[5]= fqv[162];
	ctx->vsp=local+6;
	w=(pointer)EQUAL(ctx,2,local+4); /*equal*/
	if (w==NIL) goto irtgeoAND385;
	goto irtgeoIF383;
irtgeoAND385:
	local[4]= fqv[163];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)SIGERROR(ctx,2,local+4); /*error*/
	local[4]= w;
	goto irtgeoIF384;
irtgeoIF383:
	local[4]= NIL;
irtgeoIF384:
	local[4]= argv[1];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= local[4];
	if (fqv[8]!=local[5]) goto irtgeoIF386;
	local[5]= argv[1];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= local[5];
	if (fqv[8]!=local[6]) goto irtgeoIF388;
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[3])(ctx,1,local+6,&ftab[3],fqv[25]); /*acos*/
	local[1] = w;
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= makeflt(1.0000000000000000000000e+00);
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(*ftab[9])(ctx,3,local+6,&ftab[9],fqv[87]); /*eps=*/
	if (w==NIL) goto irtgeoCON391;
	local[0] = makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)1L);
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[6]= local[2];
	goto irtgeoCON390;
irtgeoCON391:
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= makeflt(-1.0000000000000000000000e+00);
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(*ftab[9])(ctx,3,local+6,&ftab[9],fqv[87]); /*eps=*/
	if (w==NIL) goto irtgeoCON392;
	local[0] = makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)1L);
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,1,local+7); /*-*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[6]= local[2];
	goto irtgeoCON390;
irtgeoCON392:
	local[6]= argv[1];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= local[6];
	if (fqv[12]!=local[7]) goto irtgeoIF394;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)2L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= makeint((eusinteger_t)1L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[31])(ctx,2,local+7,&ftab[31],fqv[164]); /*user::atan2*/
	local[0] = w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,1,local+7); /*-*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[31])(ctx,2,local+7,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[7]= local[2];
	goto irtgeoIF395;
irtgeoIF394:
	local[7]= local[6];
	if (fqv[10]!=local[7]) goto irtgeoIF396;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)1L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,1,local+7); /*-*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= makeint((eusinteger_t)2L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[31])(ctx,2,local+7,&ftab[31],fqv[164]); /*user::atan2*/
	local[0] = w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[31])(ctx,2,local+7,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[7]= local[2];
	goto irtgeoIF397;
irtgeoIF396:
	if (T==NIL) goto irtgeoIF398;
	local[7]= fqv[165];
	ctx->vsp=local+8;
	w=(pointer)SIGERROR(ctx,1,local+7); /*error*/
	local[7]= w;
	goto irtgeoIF399;
irtgeoIF398:
	local[7]= NIL;
irtgeoIF399:
irtgeoIF397:
irtgeoIF395:
	w = local[7];
	local[6]= w;
	goto irtgeoCON390;
irtgeoCON393:
	local[6]= NIL;
irtgeoCON390:
	goto irtgeoIF389;
irtgeoIF388:
	local[6]= local[5];
	if (fqv[10]!=local[6]) goto irtgeoIF400;
	local[6]= argv[1];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	if (fqv[12]==local[6]) goto irtgeoIF402;
	local[6]= fqv[166];
	ctx->vsp=local+7;
	w=(pointer)SIGERROR(ctx,1,local+6); /*error*/
	local[6]= w;
	goto irtgeoIF403;
irtgeoIF402:
	local[6]= NIL;
irtgeoIF403:
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[32])(ctx,1,local+6,&ftab[32],fqv[167]); /*asin*/
	local[1] = makeflt(-(fltval(w)));
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= makeflt(1.0000000000000000000000e+00);
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(*ftab[9])(ctx,3,local+6,&ftab[9],fqv[87]); /*eps=*/
	if (w==NIL) goto irtgeoCON405;
	local[0] = makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)1L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[6]= local[2];
	goto irtgeoCON404;
irtgeoCON405:
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= makeflt(-1.0000000000000000000000e+00);
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(*ftab[9])(ctx,3,local+6,&ftab[9],fqv[87]); /*eps=*/
	if (w==NIL) goto irtgeoCON406;
	local[0] = makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)2L);
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[6]= local[2];
	goto irtgeoCON404;
irtgeoCON406:
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)1L);
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[0] = w;
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[6]= local[2];
	goto irtgeoCON404;
irtgeoCON407:
	local[6]= NIL;
irtgeoCON404:
	goto irtgeoIF401;
irtgeoIF400:
	local[6]= local[5];
	if (fqv[12]!=local[6]) goto irtgeoIF408;
	local[6]= argv[1];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	if (fqv[10]==local[6]) goto irtgeoIF410;
	local[6]= fqv[168];
	ctx->vsp=local+7;
	w=(pointer)SIGERROR(ctx,1,local+6); /*error*/
	local[6]= w;
	goto irtgeoIF411;
irtgeoIF410:
	local[6]= NIL;
irtgeoIF411:
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[32])(ctx,1,local+6,&ftab[32],fqv[167]); /*asin*/
	local[1] = w;
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= makeflt(1.0000000000000000000000e+00);
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(*ftab[9])(ctx,3,local+6,&ftab[9],fqv[87]); /*eps=*/
	if (w==NIL) goto irtgeoCON413;
	local[0] = makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)1L);
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[6]= local[2];
	goto irtgeoCON412;
irtgeoCON413:
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= makeflt(-1.0000000000000000000000e+00);
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(*ftab[9])(ctx,3,local+6,&ftab[9],fqv[87]); /*eps=*/
	if (w==NIL) goto irtgeoCON414;
	local[0] = makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)2L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[6]= local[2];
	goto irtgeoCON412;
irtgeoCON414:
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,1,local+6); /*-*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)2L);
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[0] = w;
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,1,local+6); /*-*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[6]= local[2];
	goto irtgeoCON412;
irtgeoCON415:
	local[6]= NIL;
irtgeoCON412:
	goto irtgeoIF409;
irtgeoIF408:
	local[6]= NIL;
irtgeoIF409:
irtgeoIF401:
irtgeoIF389:
	w = local[6];
	local[5]= w;
	goto irtgeoIF387;
irtgeoIF386:
	local[5]= local[4];
	if (fqv[10]!=local[5]) goto irtgeoIF416;
	local[5]= argv[1];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= local[5];
	if (fqv[10]!=local[6]) goto irtgeoIF418;
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[3])(ctx,1,local+6,&ftab[3],fqv[25]); /*acos*/
	local[1] = w;
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= makeflt(1.0000000000000000000000e+00);
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(*ftab[9])(ctx,3,local+6,&ftab[9],fqv[87]); /*eps=*/
	if (w==NIL) goto irtgeoCON421;
	local[0] = makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[6]= local[2];
	goto irtgeoCON420;
irtgeoCON421:
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= makeflt(-1.0000000000000000000000e+00);
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(*ftab[9])(ctx,3,local+6,&ftab[9],fqv[87]); /*eps=*/
	if (w==NIL) goto irtgeoCON422;
	local[0] = makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[6]= local[2];
	goto irtgeoCON420;
irtgeoCON422:
	local[6]= argv[1];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= local[6];
	if (fqv[8]!=local[7]) goto irtgeoIF424;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= makeint((eusinteger_t)2L);
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[31])(ctx,2,local+7,&ftab[31],fqv[164]); /*user::atan2*/
	local[0] = w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)1L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,1,local+7); /*-*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= makeint((eusinteger_t)1L);
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[31])(ctx,2,local+7,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[7]= local[2];
	goto irtgeoIF425;
irtgeoIF424:
	local[7]= local[6];
	if (fqv[12]!=local[7]) goto irtgeoIF426;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)2L);
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,1,local+7); /*-*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[31])(ctx,2,local+7,&ftab[31],fqv[164]); /*user::atan2*/
	local[0] = w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)1L);
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= makeint((eusinteger_t)1L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[31])(ctx,2,local+7,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[7]= local[2];
	goto irtgeoIF427;
irtgeoIF426:
	if (T==NIL) goto irtgeoIF428;
	local[7]= fqv[169];
	ctx->vsp=local+8;
	w=(pointer)SIGERROR(ctx,1,local+7); /*error*/
	local[7]= w;
	goto irtgeoIF429;
irtgeoIF428:
	local[7]= NIL;
irtgeoIF429:
irtgeoIF427:
irtgeoIF425:
	w = local[7];
	local[6]= w;
	goto irtgeoCON420;
irtgeoCON423:
	local[6]= NIL;
irtgeoCON420:
	goto irtgeoIF419;
irtgeoIF418:
	local[6]= local[5];
	if (fqv[12]!=local[6]) goto irtgeoIF430;
	local[6]= argv[1];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	if (fqv[8]==local[6]) goto irtgeoIF432;
	local[6]= fqv[170];
	ctx->vsp=local+7;
	w=(pointer)SIGERROR(ctx,1,local+6); /*error*/
	local[6]= w;
	goto irtgeoIF433;
irtgeoIF432:
	local[6]= NIL;
irtgeoIF433:
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[32])(ctx,1,local+6,&ftab[32],fqv[167]); /*asin*/
	local[1] = makeflt(-(fltval(w)));
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= makeflt(1.0000000000000000000000e+00);
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(*ftab[9])(ctx,3,local+6,&ftab[9],fqv[87]); /*eps=*/
	if (w==NIL) goto irtgeoCON435;
	local[0] = makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)2L);
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[6]= local[2];
	goto irtgeoCON434;
irtgeoCON435:
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= makeflt(-1.0000000000000000000000e+00);
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(*ftab[9])(ctx,3,local+6,&ftab[9],fqv[87]); /*eps=*/
	if (w==NIL) goto irtgeoCON436;
	local[0] = makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[6]= local[2];
	goto irtgeoCON434;
irtgeoCON436:
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)2L);
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[0] = w;
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)1L);
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[6]= local[2];
	goto irtgeoCON434;
irtgeoCON437:
	local[6]= NIL;
irtgeoCON434:
	goto irtgeoIF431;
irtgeoIF430:
	local[6]= local[5];
	if (fqv[8]!=local[6]) goto irtgeoIF438;
	local[6]= argv[1];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	if (fqv[12]==local[6]) goto irtgeoIF440;
	local[6]= fqv[171];
	ctx->vsp=local+7;
	w=(pointer)SIGERROR(ctx,1,local+6); /*error*/
	local[6]= w;
	goto irtgeoIF441;
irtgeoIF440:
	local[6]= NIL;
irtgeoIF441:
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[32])(ctx,1,local+6,&ftab[32],fqv[167]); /*asin*/
	local[1] = w;
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= makeflt(1.0000000000000000000000e+00);
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(*ftab[9])(ctx,3,local+6,&ftab[9],fqv[87]); /*eps=*/
	if (w==NIL) goto irtgeoCON443;
	local[0] = makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)2L);
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[6]= local[2];
	goto irtgeoCON442;
irtgeoCON443:
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= makeflt(-1.0000000000000000000000e+00);
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(*ftab[9])(ctx,3,local+6,&ftab[9],fqv[87]); /*eps=*/
	if (w==NIL) goto irtgeoCON444;
	local[0] = makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)2L);
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[6]= local[2];
	goto irtgeoCON442;
irtgeoCON444:
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,1,local+6); /*-*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[0] = w;
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,1,local+6); /*-*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)1L);
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[6]= local[2];
	goto irtgeoCON442;
irtgeoCON445:
	local[6]= NIL;
irtgeoCON442:
	goto irtgeoIF439;
irtgeoIF438:
	local[6]= NIL;
irtgeoIF439:
irtgeoIF431:
irtgeoIF419:
	w = local[6];
	local[5]= w;
	goto irtgeoIF417;
irtgeoIF416:
	local[5]= local[4];
	if (fqv[12]!=local[5]) goto irtgeoIF446;
	local[5]= argv[1];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= local[5];
	if (fqv[12]!=local[6]) goto irtgeoIF448;
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[3])(ctx,1,local+6,&ftab[3],fqv[25]); /*acos*/
	local[1] = w;
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= makeflt(1.0000000000000000000000e+00);
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(*ftab[9])(ctx,3,local+6,&ftab[9],fqv[87]); /*eps=*/
	if (w==NIL) goto irtgeoCON451;
	local[0] = makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[6]= local[2];
	goto irtgeoCON450;
irtgeoCON451:
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= makeflt(-1.0000000000000000000000e+00);
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(*ftab[9])(ctx,3,local+6,&ftab[9],fqv[87]); /*eps=*/
	if (w==NIL) goto irtgeoCON452;
	local[0] = makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)1L);
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[6]= local[2];
	goto irtgeoCON450;
irtgeoCON452:
	local[6]= argv[1];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= local[6];
	if (fqv[10]!=local[7]) goto irtgeoIF454;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)1L);
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[31])(ctx,2,local+7,&ftab[31],fqv[164]); /*user::atan2*/
	local[0] = w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)2L);
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,1,local+7); /*-*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= makeint((eusinteger_t)2L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[31])(ctx,2,local+7,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[7]= local[2];
	goto irtgeoIF455;
irtgeoIF454:
	local[7]= local[6];
	if (fqv[8]!=local[7]) goto irtgeoIF456;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,1,local+7); /*-*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= makeint((eusinteger_t)1L);
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[31])(ctx,2,local+7,&ftab[31],fqv[164]); /*user::atan2*/
	local[0] = w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)2L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= makeint((eusinteger_t)2L);
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[31])(ctx,2,local+7,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[7]= local[2];
	goto irtgeoIF457;
irtgeoIF456:
	if (T==NIL) goto irtgeoIF458;
	local[7]= fqv[172];
	ctx->vsp=local+8;
	w=(pointer)SIGERROR(ctx,1,local+7); /*error*/
	local[7]= w;
	goto irtgeoIF459;
irtgeoIF458:
	local[7]= NIL;
irtgeoIF459:
irtgeoIF457:
irtgeoIF455:
	w = local[7];
	local[6]= w;
	goto irtgeoCON450;
irtgeoCON453:
	local[6]= NIL;
irtgeoCON450:
	goto irtgeoIF449;
irtgeoIF448:
	local[6]= local[5];
	if (fqv[8]!=local[6]) goto irtgeoIF460;
	local[6]= argv[1];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	if (fqv[10]==local[6]) goto irtgeoIF462;
	local[6]= fqv[173];
	ctx->vsp=local+7;
	w=(pointer)SIGERROR(ctx,1,local+6); /*error*/
	local[6]= w;
	goto irtgeoIF463;
irtgeoIF462:
	local[6]= NIL;
irtgeoIF463:
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[32])(ctx,1,local+6,&ftab[32],fqv[167]); /*asin*/
	local[1] = makeflt(-(fltval(w)));
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= makeflt(1.0000000000000000000000e+00);
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(*ftab[9])(ctx,3,local+6,&ftab[9],fqv[87]); /*eps=*/
	if (w==NIL) goto irtgeoCON465;
	local[0] = makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[6]= local[2];
	goto irtgeoCON464;
irtgeoCON465:
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= makeflt(-1.0000000000000000000000e+00);
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(*ftab[9])(ctx,3,local+6,&ftab[9],fqv[87]); /*eps=*/
	if (w==NIL) goto irtgeoCON466;
	local[0] = makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[6]= local[2];
	goto irtgeoCON464;
irtgeoCON466:
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[0] = w;
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)2L);
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[6]= local[2];
	goto irtgeoCON464;
irtgeoCON467:
	local[6]= NIL;
irtgeoCON464:
	goto irtgeoIF461;
irtgeoIF460:
	local[6]= local[5];
	if (fqv[10]!=local[6]) goto irtgeoIF468;
	local[6]= argv[1];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	if (fqv[8]==local[6]) goto irtgeoIF470;
	local[6]= fqv[174];
	ctx->vsp=local+7;
	w=(pointer)SIGERROR(ctx,1,local+6); /*error*/
	local[6]= w;
	goto irtgeoIF471;
irtgeoIF470:
	local[6]= NIL;
irtgeoIF471:
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[32])(ctx,1,local+6,&ftab[32],fqv[167]); /*asin*/
	local[1] = w;
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= makeflt(1.0000000000000000000000e+00);
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(*ftab[9])(ctx,3,local+6,&ftab[9],fqv[87]); /*eps=*/
	if (w==NIL) goto irtgeoCON473;
	local[0] = makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[6]= local[2];
	goto irtgeoCON472;
irtgeoCON473:
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= makeflt(-1.0000000000000000000000e+00);
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(*ftab[9])(ctx,3,local+6,&ftab[9],fqv[87]); /*eps=*/
	if (w==NIL) goto irtgeoCON474;
	local[0] = makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[6]= local[2];
	goto irtgeoCON472;
irtgeoCON474:
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,1,local+6); /*-*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)1L);
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[0] = w;
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,1,local+6); /*-*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)2L);
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,2,local+6,&ftab[31],fqv[164]); /*user::atan2*/
	local[2] = w;
	local[6]= local[2];
	goto irtgeoCON472;
irtgeoCON475:
	local[6]= NIL;
irtgeoCON472:
	goto irtgeoIF469;
irtgeoIF468:
	local[6]= NIL;
irtgeoIF469:
irtgeoIF461:
irtgeoIF449:
	w = local[6];
	local[5]= w;
	goto irtgeoIF447;
irtgeoIF446:
	local[5]= NIL;
irtgeoIF447:
irtgeoIF417:
irtgeoIF387:
	w = local[5];
	local[4]= local[0];
	local[5]= local[1];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,3,local+4); /*list*/
	local[0]= w;
irtgeoBLK382:
	ctx->vsp=local; return(local[0]);}

/*quaternion-from-two-vectors*/
static pointer irtgeoF23quaternion_from_two_vectors(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[4])(ctx,1,local+0,&ftab[4],fqv[26]); /*normalize-vector*/
	local[0]= w;
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(*ftab[4])(ctx,1,local+1,&ftab[4],fqv[26]); /*normalize-vector*/
	local[1]= w;
	local[2]= local[1];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)VINNERPRODUCT(ctx,2,local+2); /*v.*/
	local[2]= w;
	local[3]= local[0];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+3); /*v**/
	local[3]= w;
	local[4]= makeint((eusinteger_t)2L);
	local[5]= makeint((eusinteger_t)1L);
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SQRT(ctx,1,local+4); /*sqrt*/
	local[4]= w;
	local[5]= makeflt(1.0000000000000000000000e+00);
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	local[6]= local[5];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)SCALEVEC(ctx,2,local+6); /*scale*/
	local[6]= w;
	local[7]= makeflt(5.0000000000000000000000e-01);
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	local[8]= local[7];
	local[9]= local[6];
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	local[10]= local[6];
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	local[11]= local[6];
	local[12]= makeint((eusinteger_t)2L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)MKFLTVEC(ctx,4,local+8); /*float-vector*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[4])(ctx,1,local+8,&ftab[4],fqv[26]); /*normalize-vector*/
	local[0]= w;
irtgeoBLK476:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___irtgeo(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[175];
	ctx->vsp=local+1;
	w=(*ftab[33])(ctx,1,local+0,&ftab[33],fqv[176]); /*require*/
	local[0]= fqv[177];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtgeoIF477;
	local[0]= fqv[178];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[179],w);
	goto irtgeoIF478;
irtgeoIF477:
	local[0]= fqv[180];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtgeoIF478:
	local[0]= fqv[181];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[182];
	local[1]= fqv[183];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto irtgeoIF479;
	local[0]= fqv[182];
	local[1]= fqv[183];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[182];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto irtgeoIF481;
	local[0]= fqv[182];
	local[1]= fqv[184];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeflt(9.8066499999999941792339e+03);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto irtgeoIF482;
irtgeoIF481:
	local[0]= NIL;
irtgeoIF482:
	local[0]= fqv[182];
	goto irtgeoIF480;
irtgeoIF479:
	local[0]= NIL;
irtgeoIF480:
	ctx->vsp=local+0;
	compfun(ctx,fqv[185],module,irtgeoF1midcoords,fqv[186]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgeoM25line_worldcoords,fqv[44],fqv[187],fqv[188]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgeoM27coordinates_axis,fqv[24],fqv[72],fqv[189]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgeoM35coordinates_difference_position,fqv[190],fqv[72],fqv[191]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgeoM50coordinates_difference_rotation,fqv[192],fqv[72],fqv[193]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgeoM86coordinates_move_to,fqv[194],fqv[72],fqv[195]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgeoM98coordinates_transformation,fqv[55],fqv[72],fqv[196]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgeoM109coordinates_transform,fqv[54],fqv[72],fqv[197]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgeoM120coordinates_move_coords,fqv[198],fqv[72],fqv[199]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgeoM122cascaded_coords_worldcoords,fqv[44],fqv[200],fqv[201]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgeoM128cascaded_coords_transformation,fqv[55],fqv[200],fqv[202]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgeoM141cascaded_coords_transform,fqv[54],fqv[200],fqv[203]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgeoM154cascaded_coords_move_to,fqv[194],fqv[200],fqv[204]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[205],module,irtgeoF2transform_coords,fqv[206]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgeoM173coordinates_rotate_vector,fqv[7],fqv[72],fqv[207]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgeoM179coordinates_inverse_rotate_vector,fqv[76],fqv[72],fqv[208]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgeoM185cascaded_coords_rotate_vector,fqv[7],fqv[200],fqv[209]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgeoM189cascaded_coords_inverse_rotate_vector,fqv[76],fqv[200],fqv[210]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgeoM193coordinates_inverse_transform_vector,fqv[15],fqv[72],fqv[211]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgeoM203cascaded_coords_inverse_transform_vector,fqv[15],fqv[200],fqv[212]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[213],module,irtgeoF3orient_coords_to_axis,fqv[214]);
	local[0]= fqv[215];
	local[1]= fqv[184];
	local[2]= fqv[215];
	local[3]= fqv[216];
	local[4]= loadglobal(fqv[200]);
	local[5]= fqv[217];
	local[6]= fqv[218];
	local[7]= fqv[219];
	local[8]= NIL;
	local[9]= fqv[220];
	local[10]= NIL;
	local[11]= fqv[221];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[222];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[34])(ctx,13,local+2,&ftab[34],fqv[223]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgeoM237bodyset_init,fqv[96],fqv[215],fqv[224]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgeoM244bodyset_bodies,fqv[225],fqv[215],fqv[226]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgeoM247bodyset_faces,fqv[101],fqv[215],fqv[227]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgeoM249bodyset_worldcoords,fqv[44],fqv[215],fqv[228]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgeoM256bodyset_draw_on,fqv[105],fqv[215],fqv[229]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[230],module,irtgeoF4face_to_triangle_aux,fqv[231]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[232],module,irtgeoF5face_to_triangle,fqv[233]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[234],module,irtgeoF6face_to_tessel_triangle,fqv[235]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[236],module,irtgeoF7face_to_triangle_rest_polygon,fqv[237]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[238],module,irtgeoF8face_to_triangle_make_simple,fqv[239]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[240],module,irtgeoF9body_to_faces,fqv[241]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[242],module,irtgeoF10body_to_triangles,fqv[243]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[244],module,irtgeoF11triangle_to_triangle,fqv[245]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[246],module,irtgeoF12make_sphere,fqv[247]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[248],module,irtgeoF13make_ring,fqv[249]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[250],module,irtgeoF14make_fan_cylinder,fqv[251]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[252],module,irtgeoF15x_of_cube,fqv[253]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[254],module,irtgeoF16y_of_cube,fqv[255]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[256],module,irtgeoF17z_of_cube,fqv[257]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[258],module,irtgeoF18height_of_cylinder,fqv[259]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[260],module,irtgeoF19radius_of_cylinder,fqv[261]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[262],module,irtgeoF20radius_of_sphere,fqv[263]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[264],module,irtgeoF21make_faceset_from_vertices,fqv[265]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[266],module,irtgeoF22matrix_to_euler_angle,fqv[267]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[268],module,irtgeoF23quaternion_from_two_vectors,fqv[269]);
	local[0]= fqv[270];
	local[1]= fqv[271];
	ctx->vsp=local+2;
	w=(*ftab[35])(ctx,2,local+0,&ftab[35],fqv[272]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<36; i++) ftab[i]=fcallx;
}
