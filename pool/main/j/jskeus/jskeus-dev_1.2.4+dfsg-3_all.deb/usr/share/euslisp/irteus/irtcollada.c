/* ./irtcollada.c :  entry=irtcollada */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "irtcollada.h"
#pragma init (register_irtcollada)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___irtcollada();
extern pointer build_quote_vector();
static int register_irtcollada()
  { add_module_initializer("___irtcollada", ___irtcollada);}

static pointer irtcollaF4934symbol__string();
static pointer irtcollaF4935__string();
static pointer irtcollaF4936string_append();
static pointer irtcollaF4937make_attr();
static pointer irtcollaF4938make_xml();
static pointer irtcollaF4939sxml__xml();
static pointer irtcollaF4940xml_output_to_string_stream();
static pointer irtcollaF4941cat_normal();
static pointer irtcollaF4942cat_clark();
static pointer irtcollaF4943eusmodel_description();
static pointer irtcollaF4944verificate_unique_strings();
static pointer irtcollaF4945eusmodel_link_specs();
static pointer irtcollaF4946eusmodel_joint_specs();
static pointer irtcollaF4947eusmodel_link_spec();
static pointer irtcollaF4948eusmodel_mesh_spec();
static pointer irtcollaF4949eusmodel_joint_spec();
static pointer irtcollaF4950eusmodel_limit_spec();
static pointer irtcollaF4951eusmodel_endcoords_specs();
static pointer irtcollaF4952eusmodel_link_description();
static pointer irtcollaF4953eusmodel_joint_description();
static pointer irtcollaF4954eusmodel_endcoords_description();
static pointer irtcollaF4955eusmodel_description__collada();
static pointer irtcollaF4956setup_collada_filesystem();
static pointer irtcollaF4957range2();
static pointer irtcollaF4958eus2collada();
static pointer irtcollaF4959collada_node_id();
static pointer irtcollaF4960collada_node_name();
static pointer irtcollaF4961links_description__collada_library_materials();
static pointer irtcollaF4962link_description__collada_materials();
static pointer irtcollaF4963mesh_description__collada_material();
static pointer irtcollaF4964links_description__collada_library_effects();
static pointer irtcollaF4965link_description__collada_effects();
static pointer irtcollaF4966mesh_description__collada_effect();
static pointer irtcollaF4967matrix__collada_string();
static pointer irtcollaF4968find_parent_liks_from_link_description();
static pointer irtcollaF4969eusmodel_description__collada_node_transformations();
static pointer irtcollaF4970eusmodel_description__collada_node();
static pointer irtcollaF4971eusmodel_description__collada_library_visual_scenes();
static pointer irtcollaF4972mesh_description__instance_material();
static pointer irtcollaF4973link_description__collada_bind_material();
static pointer irtcollaF4974eusmodel_description__collada_library_kinematics_scenes();
static pointer irtcollaF4975eusmodel_description__collada_library_kinematics_models();
static pointer irtcollaF4976eusmodel_description__collada_kinematics_model();
static pointer irtcollaF4977eusmodel_description__collada_library_physics_scenes();
static pointer irtcollaF4978eusmodel_description__collada_library_physics_models();
static pointer irtcollaF4979find_root_link_from_joints_description();
static pointer irtcollaF4980find_link_from_links_description();
static pointer irtcollaF4981eusmodel_description__collada_links();
static pointer irtcollaF4982find_joint_from_link_description();
static pointer irtcollaF4983find_child_link_descriptions();
static pointer irtcollaF4984matrix__collada_rotate_vector();
static pointer irtcollaF4985eusmodel_description__collada_library_articulated_systems();
static pointer irtcollaF4986eusmodel_endcoords_description__openrave_manipulator();
static pointer irtcollaF4987eusmodel_description__collada_links_tree();
static pointer irtcollaF4988joints_description__collada_instance_joints();
static pointer irtcollaF4989joint_description__collada_instance_joint();
static pointer irtcollaF4990eusmodel_description__collada_library_joints();
static pointer irtcollaF4991joints_description__collada_joints();
static pointer irtcollaF4992collada_joint_id();
static pointer irtcollaF4993joint_description__collada_joint();
static pointer irtcollaF4994linear_joint_description__collada_joint();
static pointer irtcollaF4995rotational_joint_description__collada_joint();
static pointer irtcollaF4996eusmodel_description__collada_scene();
static pointer irtcollaF4997eusmodel_description__collada_library_geometries();
static pointer irtcollaF4998collada_geometry_id_base();
static pointer irtcollaF4999collada_geometry_name_base();
static pointer irtcollaF5000links_description__collada_geometries();
static pointer irtcollaF5001mesh_object__collada_mesh();
static pointer irtcollaF5002link_description__collada_geometry();
static pointer irtcollaF5003mesh__collada_indices();
static pointer irtcollaF5004mesh_vertices__collada_string();
static pointer irtcollaF5005mesh_normals__collada_string();
static pointer irtcollaF5006float_vector__collada_string();
static pointer irtcollaF5007enum_integer_list();
static pointer irtcollaF5008search_minimum_rotation_matrix();
static pointer irtcollaF5009estimate_class_name();
static pointer irtcollaF5010remove_directory_name();
static pointer irtcollaF5011convert_irtmodel_to_collada();

/*symbol->string*/
static pointer irtcollaF4934symbol__string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[0]);
	ctx->vsp=local+2;
	w=(*ftab[0])(ctx,2,local+0,&ftab[0],fqv[1]); /*find*/
	if (w==NIL) goto irtcollaIF5013;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[1])(ctx,1,local+0,&ftab[1],fqv[2]); /*string*/
	local[0]= w;
	goto irtcollaIF5014;
irtcollaIF5013:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[1])(ctx,1,local+0,&ftab[1],fqv[2]); /*string*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[2])(ctx,1,local+0,&ftab[2],fqv[3]); /*string-downcase*/
	local[0]= w;
irtcollaIF5014:
	w = local[0];
	local[0]= w;
irtcollaBLK5012:
	ctx->vsp=local; return(local[0]);}

/*->string*/
static pointer irtcollaF4935__string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= fqv[4];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
irtcollaBLK5015:
	ctx->vsp=local; return(local[0]);}

/*string-append*/
static pointer irtcollaF4936string_append(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
irtcollaRST5017:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= (pointer)get_sym_func(fqv[5]);
	local[2]= loadglobal(fqv[2]);
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)APPLY(ctx,3,local+1); /*apply*/
	local[0]= w;
irtcollaBLK5016:
	ctx->vsp=local; return(local[0]);}

/*make-attr*/
static pointer irtcollaF4937make_attr(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]!=NIL) goto irtcollaIF5019;
	local[0]= argv[1];
	goto irtcollaIF5020;
irtcollaIF5019:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= argv[1];
	local[2]= fqv[6];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(pointer)irtcollaF4934symbol__string(ctx,1,local+3); /*symbol->string*/
	local[3]= w;
	local[4]= fqv[7];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(*ftab[3])(ctx,1,local+5,&ftab[3],fqv[8]); /*cadar*/
	if (!isstring(w)) goto irtcollaIF5021;
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(*ftab[3])(ctx,1,local+5,&ftab[3],fqv[8]); /*cadar*/
	local[5]= w;
	goto irtcollaIF5022;
irtcollaIF5021:
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(*ftab[3])(ctx,1,local+5,&ftab[3],fqv[8]); /*cadar*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)irtcollaF4935__string(ctx,1,local+5); /*->string*/
	local[5]= w;
irtcollaIF5022:
	local[6]= fqv[9];
	ctx->vsp=local+7;
	w=(pointer)irtcollaF4936string_append(ctx,6,local+1); /*string-append*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)irtcollaF4937make_attr(ctx,2,local+0); /*make-attr*/
	local[0]= w;
irtcollaIF5020:
	w = local[0];
	local[0]= w;
irtcollaBLK5018:
	ctx->vsp=local; return(local[0]);}

/*make-xml*/
static pointer irtcollaF4938make_xml(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[0];
	if (!isstring(w)) goto irtcollaCON5025;
	local[0]= argv[1];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[1]= w;
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)APPEND(ctx,3,local+0); /*append*/
	local[0]= w;
	goto irtcollaCON5024;
irtcollaCON5025:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LISTP(ctx,1,local+0); /*listp*/
	if (w==NIL) goto irtcollaCON5026;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!issymbol(w)) goto irtcollaCON5026;
	if (argv[0]==NIL) goto irtcollaCON5026;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	ctx->vsp=local+1;
	w=(pointer)irtcollaF4934symbol__string(ctx,1,local+0); /*symbol->string*/
	local[0]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto irtcollaIF5027;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)LISTP(ctx,1,local+1); /*listp*/
	if (w==NIL) goto irtcollaIF5027;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[4])(ctx,1,local+1,&ftab[4],fqv[10]); /*caadr*/
	local[1]= w;
	if (fqv[11]!=local[1]) goto irtcollaIF5027;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	local[2]= argv[1];
	local[3]= fqv[12];
	local[4]= local[0];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(*ftab[5])(ctx,1,local+5,&ftab[5],fqv[13]); /*cdadr*/
	local[5]= w;
	local[6]= fqv[14];
	ctx->vsp=local+7;
	w=(pointer)irtcollaF4937make_attr(ctx,2,local+5); /*make-attr*/
	local[5]= w;
	local[6]= fqv[15];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,4,local+3); /*list*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)APPEND(ctx,2,local+2); /*append*/
	local[2]= w;
	local[3]= fqv[16];
	local[4]= local[0];
	local[5]= fqv[17];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,3,local+3); /*list*/
	local[3]= w;
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)APPEND(ctx,2,local+3); /*append*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)irtcollaF4938make_xml(ctx,3,local+1); /*make-xml*/
	local[1]= w;
	goto irtcollaIF5028;
irtcollaIF5027:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	local[2]= argv[1];
	local[3]= fqv[12];
	local[4]= local[0];
	local[5]= fqv[15];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,3,local+3); /*list*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)APPEND(ctx,2,local+2); /*append*/
	local[2]= w;
	local[3]= fqv[16];
	local[4]= local[0];
	local[5]= fqv[17];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,3,local+3); /*list*/
	local[3]= w;
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)APPEND(ctx,2,local+3); /*append*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)irtcollaF4938make_xml(ctx,3,local+1); /*make-xml*/
	local[1]= w;
irtcollaIF5028:
	w = local[1];
	local[0]= w;
	goto irtcollaCON5024;
irtcollaCON5026:
	if (argv[0]==NIL) goto irtcollaCON5029;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LISTP(ctx,1,local+0); /*listp*/
	if (w==NIL) goto irtcollaCON5029;
	local[0]= NIL;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= argv[1];
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)irtcollaF4938make_xml(ctx,3,local+1); /*make-xml*/
	local[1]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.cdr;
	local[3]= NIL;
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)irtcollaF4938make_xml(ctx,3,local+2); /*make-xml*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)irtcollaF4938make_xml(ctx,3,local+0); /*make-xml*/
	local[0]= w;
	goto irtcollaCON5024;
irtcollaCON5029:
	local[0]= argv[1];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)APPEND(ctx,2,local+0); /*append*/
	local[0]= w;
	goto irtcollaCON5024;
irtcollaCON5030:
	local[0]= NIL;
irtcollaCON5024:
	w = local[0];
	local[0]= w;
irtcollaBLK5023:
	ctx->vsp=local; return(local[0]);}

/*sxml->xml*/
static pointer irtcollaF4939sxml__xml(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= NIL;
	local[2]= NIL;
	ctx->vsp=local+3;
	w=(pointer)irtcollaF4938make_xml(ctx,3,local+0); /*make-xml*/
	local[0]= w;
irtcollaBLK5031:
	ctx->vsp=local; return(local[0]);}

/*xml-output-to-string-stream*/
static pointer irtcollaF4940xml_output_to_string_stream(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= argv[1];
irtcollaWHL5033:
	if (local[1]==NIL) goto irtcollaWHX5034;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	w = local[0];
	if (!isstring(w)) goto irtcollaIF5036;
	local[2]= argv[0];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,2,local+2); /*format*/
	local[2]= w;
	goto irtcollaIF5037;
irtcollaIF5036:
	local[2]= argv[0];
	local[3]= local[0];
	local[4]= local[3];
	if (fqv[12]!=local[4]) goto irtcollaIF5038;
	local[4]= fqv[18];
	goto irtcollaIF5039;
irtcollaIF5038:
	local[4]= local[3];
	if (fqv[16]!=local[4]) goto irtcollaIF5040;
	local[4]= fqv[19];
	goto irtcollaIF5041;
irtcollaIF5040:
	local[4]= local[3];
	w = fqv[20];
	if (memq(local[4],w)==NIL) goto irtcollaIF5042;
	local[4]= fqv[21];
	goto irtcollaIF5043;
irtcollaIF5042:
	local[4]= NIL;
irtcollaIF5043:
irtcollaIF5041:
irtcollaIF5039:
	w = local[4];
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,2,local+2); /*format*/
	local[2]= w;
irtcollaIF5037:
	goto irtcollaWHL5033;
irtcollaWHX5034:
	local[2]= NIL;
irtcollaBLK5035:
	w = NIL;
	local[0]= w;
irtcollaBLK5032:
	ctx->vsp=local; return(local[0]);}

/*cat-normal*/
static pointer irtcollaF4941cat_normal(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]!=NIL) goto irtcollaCON5046;
	local[0]= argv[1];
	goto irtcollaCON5045;
irtcollaCON5046:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!isstring(w)) goto irtcollaCON5047;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= argv[1];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)irtcollaF4936string_append(ctx,2,local+1); /*string-append*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)irtcollaF4941cat_normal(ctx,2,local+0); /*cat-normal*/
	local[0]= w;
	goto irtcollaCON5045;
irtcollaCON5047:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= argv[1];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= local[2];
	if (fqv[12]!=local[3]) goto irtcollaIF5049;
	local[3]= fqv[22];
	goto irtcollaIF5050;
irtcollaIF5049:
	local[3]= local[2];
	if (fqv[16]!=local[3]) goto irtcollaIF5051;
	local[3]= fqv[23];
	goto irtcollaIF5052;
irtcollaIF5051:
	local[3]= local[2];
	w = fqv[24];
	if (memq(local[3],w)==NIL) goto irtcollaIF5053;
	local[3]= fqv[25];
	goto irtcollaIF5054;
irtcollaIF5053:
	local[3]= NIL;
irtcollaIF5054:
irtcollaIF5052:
irtcollaIF5050:
	w = local[3];
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)irtcollaF4936string_append(ctx,2,local+1); /*string-append*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)irtcollaF4941cat_normal(ctx,2,local+0); /*cat-normal*/
	local[0]= w;
	goto irtcollaCON5045;
irtcollaCON5048:
	local[0]= NIL;
irtcollaCON5045:
	w = local[0];
	local[0]= w;
irtcollaBLK5044:
	ctx->vsp=local; return(local[0]);}

/*cat-clark*/
static pointer irtcollaF4942cat_clark(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	if (argv[0]!=NIL) goto irtcollaCON5057;
	local[0]= argv[1];
	goto irtcollaCON5056;
irtcollaCON5057:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!isstring(w)) goto irtcollaCON5058;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= argv[1];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)irtcollaF4936string_append(ctx,2,local+1); /*string-append*/
	local[1]= w;
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)irtcollaF4942cat_clark(ctx,3,local+0); /*cat-clark*/
	local[0]= w;
	goto irtcollaCON5056;
irtcollaCON5058:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= local[0];
	if (fqv[12]!=local[1]) goto irtcollaIF5060;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	local[2]= argv[1];
	local[3]= fqv[26];
	ctx->vsp=local+4;
	w=(pointer)irtcollaF4936string_append(ctx,2,local+2); /*string-append*/
	local[2]= w;
	local[3]= argv[2];
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)irtcollaF4942cat_clark(ctx,3,local+1); /*cat-clark*/
	local[1]= w;
	goto irtcollaIF5061;
irtcollaIF5060:
	local[1]= local[0];
	if (fqv[16]!=local[1]) goto irtcollaIF5062;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	local[2]= argv[1];
	local[3]= fqv[27];
	ctx->vsp=local+4;
	w=(pointer)irtcollaF4936string_append(ctx,2,local+2); /*string-append*/
	local[2]= w;
	local[3]= argv[2];
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)irtcollaF4942cat_clark(ctx,3,local+1); /*cat-clark*/
	local[1]= w;
	goto irtcollaIF5063;
irtcollaIF5062:
	local[1]= local[0];
	w = fqv[28];
	if (memq(local[1],w)==NIL) goto irtcollaIF5064;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	local[2]= argv[1];
	local[3]= fqv[29];
	local[4]= argv[2];
	local[5]= makeint((eusinteger_t)32L);
	ctx->vsp=local+6;
	w=(*ftab[6])(ctx,2,local+4,&ftab[6],fqv[30]); /*make-string*/
	local[4]= w;
	local[5]= fqv[31];
	ctx->vsp=local+6;
	w=(pointer)irtcollaF4936string_append(ctx,4,local+2); /*string-append*/
	local[2]= w;
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)irtcollaF4942cat_clark(ctx,3,local+1); /*cat-clark*/
	local[1]= w;
	goto irtcollaIF5065;
irtcollaIF5064:
	local[1]= NIL;
irtcollaIF5065:
irtcollaIF5063:
irtcollaIF5061:
	w = local[1];
	local[0]= w;
	goto irtcollaCON5056;
irtcollaCON5059:
	local[0]= NIL;
irtcollaCON5056:
	w = local[0];
	local[0]= w;
irtcollaBLK5055:
	ctx->vsp=local; return(local[0]);}

/*eusmodel-description*/
static pointer irtcollaF4943eusmodel_description(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[32];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[33];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= (pointer)get_sym_func(fqv[2]);
	local[3]= local[0];
	local[4]= fqv[34];
	ctx->vsp=local+5;
	w=(*ftab[7])(ctx,2,local+3,&ftab[7],fqv[35]); /*send-all*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)irtcollaF4944verificate_unique_strings(ctx,1,local+2); /*verificate-unique-strings*/
	local[2]= (pointer)get_sym_func(fqv[2]);
	local[3]= local[1];
	local[4]= fqv[34];
	ctx->vsp=local+5;
	w=(*ftab[7])(ctx,2,local+3,&ftab[7],fqv[35]); /*send-all*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)irtcollaF4944verificate_unique_strings(ctx,1,local+2); /*verificate-unique-strings*/
	local[2]= makeint((eusinteger_t)0L);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
irtcollaWHL5067:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto irtcollaWHX5068;
	local[4]= local[1];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= local[2];
	local[6]= fqv[36];
	ctx->vsp=local+7;
	w=(pointer)PUTPROP(ctx,3,local+4); /*putprop*/
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto irtcollaWHL5067;
irtcollaWHX5068:
	local[4]= NIL;
irtcollaBLK5069:
	w = NIL;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)irtcollaF4945eusmodel_link_specs(ctx,1,local+2); /*eusmodel-link-specs*/
	local[2]= w;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)irtcollaF4946eusmodel_joint_specs(ctx,1,local+3); /*eusmodel-joint-specs*/
	local[3]= w;
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)irtcollaF4951eusmodel_endcoords_specs(ctx,1,local+4); /*eusmodel-endcoords-specs*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,3,local+2); /*list*/
	local[0]= w;
irtcollaBLK5066:
	ctx->vsp=local; return(local[0]);}

/*verificate-unique-strings*/
static pointer irtcollaF4944verificate_unique_strings(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[37];
	local[3]= (pointer)get_sym_func(fqv[38]);
	ctx->vsp=local+4;
	w=(*ftab[8])(ctx,3,local+1,&ftab[8],fqv[39]); /*remove-duplicates*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	if (w==local[0]) goto irtcollaIF5071;
	local[0]= fqv[40];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,2,local+0); /*error*/
	local[0]= w;
	goto irtcollaIF5072;
irtcollaIF5071:
	local[0]= T;
irtcollaIF5072:
	w = local[0];
	local[0]= w;
irtcollaBLK5070:
	ctx->vsp=local; return(local[0]);}

/*eusmodel-link-specs*/
static pointer irtcollaF4945eusmodel_link_specs(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= (pointer)get_sym_func(fqv[41]);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
irtcollaBLK5073:
	ctx->vsp=local; return(local[0]);}

/*eusmodel-joint-specs*/
static pointer irtcollaF4946eusmodel_joint_specs(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= (pointer)get_sym_func(fqv[42]);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
irtcollaBLK5074:
	ctx->vsp=local; return(local[0]);}

/*eusmodel-link-spec*/
static pointer irtcollaF4947eusmodel_link_spec(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= *(ovafptr(argv[0],fqv[43]));
	local[1]= argv[0];
	local[2]= fqv[44];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
irtcollaWHL5076:
	local[3]= local[2];
	local[4]= fqv[45];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	if (w==NIL) goto irtcollaWHX5077;
	local[3]= local[2];
	local[4]= fqv[45];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[2] = w;
	goto irtcollaWHL5076;
irtcollaWHX5077:
	local[3]= NIL;
irtcollaBLK5078:
	local[3]= local[2];
	local[4]= fqv[32];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= fqv[46];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[47];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= local[3];
	local[7]= fqv[48];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= local[2];
	local[7]= fqv[49];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[3] = w;
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(*ftab[9])(ctx,1,local+6,&ftab[9],fqv[50]); /*user::sv-decompose*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(pointer)irtcollaF5008search_minimum_rotation_matrix(ctx,1,local+6); /*search-minimum-rotation-matrix*/
	local[4] = w;
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)TRANSPOSE(ctx,1,local+6); /*transpose*/
	local[6]= w;
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)MATTIMES(ctx,2,local+6); /*m**/
	local[6]= w;
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)MATTIMES(ctx,2,local+6); /*m**/
	local[5] = w;
	local[6]= makeflt(9.9999999999999985548644e-10);
	local[7]= local[5];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	local[8]= local[5];
	local[9]= makeint((eusinteger_t)1L);
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	local[9]= local[5];
	local[10]= makeint((eusinteger_t)2L);
	local[11]= makeint((eusinteger_t)2L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SCALEVEC(ctx,2,local+6); /*scale*/
	local[5] = w;
	local[6]= local[3];
	local[7]= fqv[51];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= fqv[34];
	local[7]= argv[0];
	local[8]= fqv[34];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[1])(ctx,1,local+7,&ftab[1],fqv[2]); /*string*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[52];
	local[8]= argv[0];
	local[9]= fqv[45];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[8];
	local[10]= fqv[49];
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[53];
	local[9]= argv[0];
	ctx->vsp=local+10;
	w=(pointer)irtcollaF4948eusmodel_mesh_spec(ctx,1,local+9); /*eusmodel-mesh-spec*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= fqv[54];
	w = local[3];
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[55];
	local[11]= argv[0];
	local[12]= fqv[56];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	local[12]= makeflt(1.0000000000000000000000e+03);
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= fqv[57];
	w = local[5];
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,6,local+6); /*list*/
	local[0]= w;
irtcollaBLK5075:
	ctx->vsp=local; return(local[0]);}

/*eusmodel-mesh-spec*/
static pointer irtcollaF4948eusmodel_mesh_spec(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[58];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtcollaCLO5080,env,argv,local);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	local[0]= w;
irtcollaBLK5079:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5080(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= loadglobal(fqv[59]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[60];
	local[3]= fqv[61];
	local[4]= argv[0];
	local[5]= NIL;
	ctx->vsp=local+6;
	w=(*ftab[10])(ctx,2,local+4,&ftab[10],fqv[62]); /*geometry:body-to-triangles*/
	local[4]= w;
	local[5]= fqv[61];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	w = local[0];
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[63];
	local[3]= argv[0];
	local[4]= fqv[64];
	ctx->vsp=local+5;
	w=(pointer)GETPROP(ctx,2,local+3); /*get*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= local[0];
	local[2]= fqv[65];
	local[3]= argv[0];
	local[4]= fqv[47];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= fqv[66];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*eusmodel-joint-spec*/
static pointer irtcollaF4949eusmodel_joint_spec(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[34];
	local[1]= argv[0];
	local[2]= fqv[34];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,1,local+1,&ftab[1],fqv[2]); /*string*/
	ctx->vsp=local+1;
	local[0]= cons(ctx,local[0],w);
	local[1]= fqv[67];
	local[2]= argv[0];
	local[3]= loadglobal(fqv[68]);
	ctx->vsp=local+4;
	w=(pointer)DERIVEDP(ctx,2,local+2); /*derivedp*/
	if (w==NIL) goto irtcollaCON5083;
	local[2]= fqv[69];
	goto irtcollaCON5082;
irtcollaCON5083:
	local[2]= argv[0];
	local[3]= loadglobal(fqv[70]);
	ctx->vsp=local+4;
	w=(pointer)DERIVEDP(ctx,2,local+2); /*derivedp*/
	if (w==NIL) goto irtcollaCON5084;
	local[2]= fqv[71];
	goto irtcollaCON5082;
irtcollaCON5084:
	local[2]= NIL;
irtcollaCON5082:
	w = local[2];
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	local[2]= fqv[72];
	local[3]= argv[0];
	local[4]= fqv[36];
	ctx->vsp=local+5;
	w=(pointer)GETPROP(ctx,2,local+3); /*get*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[73];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)irtcollaF4950eusmodel_limit_spec(ctx,1,local+4); /*eusmodel-limit-spec*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[74];
	local[5]= *(ovafptr(argv[0],fqv[75]));
	local[6]= local[5];
	if (fqv[76]!=local[6]) goto irtcollaIF5085;
	local[6]= fqv[77];
	goto irtcollaIF5086;
irtcollaIF5085:
	local[6]= local[5];
	if (fqv[78]!=local[6]) goto irtcollaIF5087;
	local[6]= fqv[79];
	goto irtcollaIF5088;
irtcollaIF5087:
	local[6]= local[5];
	if (fqv[80]!=local[6]) goto irtcollaIF5089;
	local[6]= fqv[81];
	goto irtcollaIF5090;
irtcollaIF5089:
	local[6]= local[5];
	if (fqv[82]!=local[6]) goto irtcollaIF5091;
	local[6]= fqv[83];
	goto irtcollaIF5092;
irtcollaIF5091:
	local[6]= local[5];
	if (fqv[84]!=local[6]) goto irtcollaIF5093;
	local[6]= fqv[85];
	goto irtcollaIF5094;
irtcollaIF5093:
	local[6]= local[5];
	if (fqv[86]!=local[6]) goto irtcollaIF5095;
	local[6]= fqv[87];
	goto irtcollaIF5096;
irtcollaIF5095:
	local[6]= local[5];
	if (fqv[88]!=local[6]) goto irtcollaIF5097;
	local[6]= fqv[89];
	goto irtcollaIF5098;
irtcollaIF5097:
	local[6]= local[5];
	if (fqv[90]!=local[6]) goto irtcollaIF5099;
	local[6]= fqv[91];
	goto irtcollaIF5100;
irtcollaIF5099:
	local[6]= local[5];
	if (fqv[92]!=local[6]) goto irtcollaIF5101;
	local[6]= fqv[93];
	goto irtcollaIF5102;
irtcollaIF5101:
	if (T==NIL) goto irtcollaIF5103;
	local[6]= *(ovafptr(argv[0],fqv[75]));
	ctx->vsp=local+7;
	w=(pointer)LISTP(ctx,1,local+6); /*listp*/
	if (w==NIL) goto irtcollaIF5105;
	local[6]= fqv[94];
	goto irtcollaIF5106;
irtcollaIF5105:
	local[6]= *(ovafptr(argv[0],fqv[75]));
irtcollaIF5106:
	goto irtcollaIF5104;
irtcollaIF5103:
	local[6]= NIL;
irtcollaIF5104:
irtcollaIF5102:
irtcollaIF5100:
irtcollaIF5098:
irtcollaIF5096:
irtcollaIF5094:
irtcollaIF5092:
irtcollaIF5090:
irtcollaIF5088:
irtcollaIF5086:
	w = local[6];
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[45];
	local[6]= argv[0];
	local[7]= fqv[95];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= fqv[34];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[1])(ctx,1,local+6,&ftab[1],fqv[2]); /*string*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[96];
	local[7]= argv[0];
	local[8]= fqv[97];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= fqv[34];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[1])(ctx,1,local+7,&ftab[1],fqv[2]); /*string*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,7,local+0); /*list*/
	local[0]= w;
irtcollaBLK5081:
	ctx->vsp=local; return(local[0]);}

/*eusmodel-limit-spec*/
static pointer irtcollaF4950eusmodel_limit_spec(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[98];
	local[1]= argv[0];
	local[2]= fqv[99];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[11])(ctx,1,local+1,&ftab[11],fqv[100]); /*deg2rad*/
	ctx->vsp=local+1;
	local[0]= cons(ctx,local[0],w);
	local[1]= fqv[101];
	local[2]= argv[0];
	local[3]= fqv[102];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[11])(ctx,1,local+2,&ftab[11],fqv[100]); /*deg2rad*/
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,2,local+0); /*list*/
	local[0]= w;
irtcollaBLK5107:
	ctx->vsp=local; return(local[0]);}

/*eusmodel-endcoords-specs*/
static pointer irtcollaF4951eusmodel_endcoords_specs(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtcollaFLET5109,env,argv,local);
	local[1]= fqv[103];
	w = local[0];
	ctx->vsp=local+2;
	w=irtcollaFLET5109(ctx,1,local+1,w);
	local[1]= w;
	local[2]= fqv[104];
	w = local[0];
	ctx->vsp=local+3;
	w=irtcollaFLET5109(ctx,1,local+2,w);
	local[2]= w;
	local[3]= fqv[105];
	w = local[0];
	ctx->vsp=local+4;
	w=irtcollaFLET5109(ctx,1,local+3,w);
	local[3]= w;
	local[4]= fqv[106];
	w = local[0];
	ctx->vsp=local+5;
	w=irtcollaFLET5109(ctx,1,local+4,w);
	local[4]= w;
	local[5]= fqv[107];
	w = local[0];
	ctx->vsp=local+6;
	w=irtcollaFLET5109(ctx,1,local+5,w);
	local[5]= w;
	local[6]= fqv[108];
	local[7]= (pointer)get_sym_func(fqv[2]);
	local[8]= local[1];
	local[9]= fqv[34];
	ctx->vsp=local+10;
	w=(*ftab[7])(ctx,2,local+8,&ftab[7],fqv[35]); /*send-all*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MAPCAR(ctx,2,local+7); /*mapcar*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[109];
	local[8]= (pointer)get_sym_func(fqv[2]);
	local[9]= local[2];
	local[10]= fqv[34];
	ctx->vsp=local+11;
	w=(*ftab[7])(ctx,2,local+9,&ftab[7],fqv[35]); /*send-all*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MAPCAR(ctx,2,local+8); /*mapcar*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[110];
	local[9]= (pointer)get_sym_func(fqv[2]);
	local[10]= local[3];
	local[11]= fqv[34];
	ctx->vsp=local+12;
	w=(*ftab[7])(ctx,2,local+10,&ftab[7],fqv[35]); /*send-all*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)MAPCAR(ctx,2,local+9); /*mapcar*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= fqv[111];
	local[10]= (pointer)get_sym_func(fqv[2]);
	local[11]= local[4];
	local[12]= fqv[34];
	ctx->vsp=local+13;
	w=(*ftab[7])(ctx,2,local+11,&ftab[7],fqv[35]); /*send-all*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)MAPCAR(ctx,2,local+10); /*mapcar*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[112];
	local[11]= (pointer)get_sym_func(fqv[2]);
	local[12]= local[5];
	local[13]= fqv[34];
	ctx->vsp=local+14;
	w=(*ftab[7])(ctx,2,local+12,&ftab[7],fqv[35]); /*send-all*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)MAPCAR(ctx,2,local+11); /*mapcar*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,5,local+6); /*list*/
	local[0]= w;
irtcollaBLK5108:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaFLET5109(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[12])(ctx,2,local+0,&ftab[12],fqv[113]); /*find-method*/
	if (w==NIL) goto irtcollaIF5110;
	local[0]= env->c.clo.env1[0];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	if (local[0]==NIL) goto irtcollaIF5112;
	local[1]= env->c.clo.env1[0];
	local[2]= argv[0];
	local[3]= fqv[114];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	if (w==NIL) goto irtcollaIF5112;
	local[1]= env->c.clo.env1[0];
	local[2]= argv[0];
	local[3]= fqv[114];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[45];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (w==NIL) goto irtcollaIF5112;
	local[1]= env->c.clo.env1[0];
	local[2]= fqv[115];
	local[3]= env->c.clo.env1[0];
	local[4]= argv[0];
	local[5]= fqv[114];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	local[4]= fqv[45];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= fqv[95];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	w = local[1];
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	local[1]= w;
	goto irtcollaIF5113;
irtcollaIF5112:
	local[1]= NIL;
irtcollaIF5113:
	w = local[1];
	local[0]= w;
	goto irtcollaIF5111;
irtcollaIF5110:
	local[0]= NIL;
irtcollaIF5111:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*eusmodel-link-description*/
static pointer irtcollaF4952eusmodel_link_description(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
irtcollaBLK5114:
	ctx->vsp=local; return(local[0]);}

/*eusmodel-joint-description*/
static pointer irtcollaF4953eusmodel_joint_description(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
irtcollaBLK5115:
	ctx->vsp=local; return(local[0]);}

/*eusmodel-endcoords-description*/
static pointer irtcollaF4954eusmodel_endcoords_description(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
irtcollaBLK5116:
	ctx->vsp=local; return(local[0]);}

/*eusmodel-description->collada*/
static pointer irtcollaF4955eusmodel_description__collada(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[116], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtcollaKEY5118;
	local[0] = makeflt(1.0000000000000000208167e-03);
irtcollaKEY5118:
	local[1]= fqv[117];
	ctx->vsp=local+2;
	w=(*ftab[13])(ctx,1,local+1,&ftab[13],fqv[118]); /*warn*/
	local[1]= fqv[119];
	local[2]= fqv[11];
	local[3]= fqv[120];
	local[4]= fqv[121];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[122];
	local[5]= fqv[123];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[124];
	local[4]= fqv[125];
	local[5]= fqv[126];
	local[6]= fqv[127];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[128];
	local[6]= fqv[11];
	local[7]= fqv[129];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[130];
	local[9]= fqv[131];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[132];
	local[7]= fqv[133];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= argv[0];
	local[5]= argv[1];
	ctx->vsp=local+6;
	w=(pointer)irtcollaF4971eusmodel_description__collada_library_visual_scenes(ctx,2,local+4); /*eusmodel-description->collada-library-visual-scenes*/
	local[4]= w;
	local[5]= argv[1];
	ctx->vsp=local+6;
	w=(pointer)irtcollaF4990eusmodel_description__collada_library_joints(ctx,1,local+5); /*eusmodel-description->collada-library-joints*/
	local[5]= w;
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(pointer)irtcollaF4952eusmodel_link_description(ctx,1,local+6); /*eusmodel-link-description*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)irtcollaF4964links_description__collada_library_effects(ctx,1,local+6); /*links-description->collada-library-effects*/
	local[6]= w;
	local[7]= argv[1];
	ctx->vsp=local+8;
	w=(pointer)irtcollaF4952eusmodel_link_description(ctx,1,local+7); /*eusmodel-link-description*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)irtcollaF4961links_description__collada_library_materials(ctx,1,local+7); /*links-description->collada-library-materials*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= argv[1];
	ctx->vsp=local+10;
	w=(pointer)irtcollaF4975eusmodel_description__collada_library_kinematics_models(ctx,2,local+8); /*eusmodel-description->collada-library-kinematics-models*/
	local[8]= w;
	local[9]= argv[0];
	local[10]= argv[1];
	ctx->vsp=local+11;
	w=(pointer)irtcollaF4974eusmodel_description__collada_library_kinematics_scenes(ctx,2,local+9); /*eusmodel-description->collada-library-kinematics-scenes*/
	local[9]= w;
	local[10]= argv[0];
	local[11]= argv[1];
	ctx->vsp=local+12;
	w=(pointer)irtcollaF4977eusmodel_description__collada_library_physics_scenes(ctx,2,local+10); /*eusmodel-description->collada-library-physics-scenes*/
	local[10]= w;
	local[11]= argv[0];
	local[12]= argv[1];
	ctx->vsp=local+13;
	w=(pointer)irtcollaF4978eusmodel_description__collada_library_physics_models(ctx,2,local+11); /*eusmodel-description->collada-library-physics-models*/
	local[11]= w;
	local[12]= argv[1];
	ctx->vsp=local+13;
	w=(pointer)irtcollaF4997eusmodel_description__collada_library_geometries(ctx,1,local+12); /*eusmodel-description->collada-library-geometries*/
	local[12]= w;
	local[13]= argv[1];
	local[14]= argv[0];
	ctx->vsp=local+15;
	w=(pointer)irtcollaF4985eusmodel_description__collada_library_articulated_systems(ctx,2,local+13); /*eusmodel-description->collada-library-articulated-systems*/
	local[13]= w;
	local[14]= argv[1];
	ctx->vsp=local+15;
	w=(pointer)irtcollaF4996eusmodel_description__collada_scene(ctx,1,local+14); /*eusmodel-description->collada-scene*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
irtcollaBLK5117:
	ctx->vsp=local; return(local[0]);}

/*setup-collada-filesystem*/
static pointer irtcollaF4956setup_collada_filesystem(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	ctx->vsp=local+1;
	w=(*ftab[14])(ctx,1,local+0,&ftab[14],fqv[134]); /*probe-file*/
	local[0]= w;
	if (fqv[135]==local[0]) goto irtcollaIF5120;
	local[0]= fqv[136];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,2,local+0); /*error*/
	local[0]= w;
	goto irtcollaIF5121;
irtcollaIF5120:
	local[0]= NIL;
irtcollaIF5121:
	w = local[0];
	local[0]= w;
irtcollaBLK5119:
	ctx->vsp=local; return(local[0]);}

/*range2*/
static pointer irtcollaF4957range2(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)NUMEQUAL(ctx,2,local+0); /*=*/
	if (w==NIL) goto irtcollaIF5123;
	local[0]= fqv[137];
	goto irtcollaIF5124;
irtcollaIF5123:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)SUB1(ctx,1,local+0); /*1-*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)irtcollaF4957range2(ctx,1,local+0); /*range2*/
	local[0]= w;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPEND(ctx,2,local+0); /*append*/
	local[0]= w;
irtcollaIF5124:
	w = local[0];
	local[0]= w;
irtcollaBLK5122:
	ctx->vsp=local; return(local[0]);}

/*eus2collada*/
static pointer irtcollaF4958eus2collada(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[138], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtcollaKEY5126;
	local[0] = makeflt(1.0000000000000000208167e-03);
irtcollaKEY5126:
	if (n & (1<<1)) goto irtcollaKEY5127;
	local[1] = fqv[139];
irtcollaKEY5127:
	local[2]= argv[0];
	local[3]= fqv[34];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	if (local[2]!=NIL) goto irtcollaIF5128;
	local[3]= fqv[140];
	ctx->vsp=local+4;
	w=(pointer)SIGERROR(ctx,1,local+3); /*error*/
	local[3]= w;
	goto irtcollaIF5129;
irtcollaIF5128:
	local[3]= NIL;
irtcollaIF5129:
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)GETCLASS(ctx,1,local+3); /*class*/
	local[3]= w;
	local[4]= fqv[34];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	if (fqv[141]==local[3]) goto irtcollaOR5132;
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)GETCLASS(ctx,1,local+3); /*class*/
	local[3]= w;
	local[4]= fqv[34];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	if (fqv[142]==local[3]) goto irtcollaOR5132;
	goto irtcollaIF5130;
irtcollaOR5132:
	local[3]= loadglobal(fqv[143]);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= local[3];
	local[5]= fqv[60];
	local[6]= fqv[34];
	local[7]= argv[0];
	local[8]= fqv[34];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	w = local[3];
	local[3]= w;
	local[4]= loadglobal(fqv[144]);
	ctx->vsp=local+5;
	w=(pointer)INSTANTIATE(ctx,1,local+4); /*instantiate*/
	local[4]= w;
	local[5]= local[4];
	local[6]= fqv[60];
	ctx->vsp=local+7;
	w=(*ftab[15])(ctx,0,local+7,&ftab[15],fqv[145]); /*geometry:make-cascoords*/
	local[7]= w;
	local[8]= fqv[58];
	local[9]= argv[0];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,5,local+5); /*send*/
	w = local[4];
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	local[4]= w;
	local[5]= w;
	*(ovafptr(local[3],fqv[146])) = local[5];
	local[4]= local[3];
	local[5]= fqv[147];
	local[6]= local[3];
	local[7]= fqv[32];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= local[3];
	local[5]= fqv[148];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	w = local[3];
	argv[0] = w;
	local[3]= argv[0];
	goto irtcollaIF5131;
irtcollaIF5130:
	local[3]= NIL;
irtcollaIF5131:
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)irtcollaF4943eusmodel_description(ctx,1,local+3); /*eusmodel-description*/
	local[3]= w;
	local[4]= local[2];
	local[5]= local[3];
	local[6]= fqv[149];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)irtcollaF4955eusmodel_description__collada(ctx,4,local+4); /*eusmodel-description->collada*/
	local[4]= w;
	local[5]= local[2];
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(pointer)irtcollaF4956setup_collada_filesystem(ctx,2,local+5); /*setup-collada-filesystem*/
	local[5]= NIL;
	local[6]= fqv[150];
	local[7]= argv[1];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,4,local+5); /*format*/
	local[5]= w;
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)irtcollaF4939sxml__xml(ctx,1,local+6); /*sxml->xml*/
	local[6]= w;
	local[7]= local[5];
	local[8]= fqv[151];
	local[9]= fqv[152];
	ctx->vsp=local+10;
	w=(*ftab[16])(ctx,3,local+7,&ftab[16],fqv[153]); /*open*/
	local[7]= w;
	ctx->vsp=local+8;
	w = makeclosure(codevec,quotevec,irtcollaUWP5133,env,argv,local);
	local[8]=(pointer)(ctx->protfp); local[9]=w;
	ctx->protfp=(struct protectframe *)(local+8);
	local[10]= local[7];
	local[11]= fqv[154];
	ctx->vsp=local+12;
	w=(pointer)XFORMAT(ctx,2,local+10); /*format*/
	local[10]= local[7];
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)irtcollaF4940xml_output_to_string_stream(ctx,2,local+10); /*xml-output-to-string-stream*/
	w = NIL;
	ctx->vsp=local+10;
	irtcollaUWP5133(ctx,0,local+10,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[0]= w;
irtcollaBLK5125:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaUWP5133(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[7];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*collada-node-id*/
static pointer irtcollaF4959collada_node_id(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= fqv[155];
	local[2]= fqv[34];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[17])(ctx,2,local+2,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.cdr;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
irtcollaBLK5134:
	ctx->vsp=local; return(local[0]);}

/*collada-node-name*/
static pointer irtcollaF4960collada_node_name(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= fqv[157];
	local[2]= fqv[34];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[17])(ctx,2,local+2,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.cdr;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
irtcollaBLK5135:
	ctx->vsp=local; return(local[0]);}

/*links-description->collada-library-materials*/
static pointer irtcollaF4961links_description__collada_library_materials(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[158];
	local[1]= fqv[11];
	local[2]= fqv[159];
	local[3]= fqv[160];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	local[2]= (pointer)get_sym_func(fqv[161]);
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)APPEND(ctx,2,local+2); /*append*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
irtcollaBLK5136:
	ctx->vsp=local; return(local[0]);}

/*link-description->collada-materials*/
static pointer irtcollaF4962link_description__collada_materials(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[53];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= NIL;
	local[2]= fqv[162];
	local[3]= fqv[34];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[17])(ctx,2,local+3,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,3,local+1); /*format*/
	local[1]= w;
	local[2]= NIL;
	local[3]= fqv[163];
	local[4]= fqv[34];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(*ftab[17])(ctx,2,local+4,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)irtcollaF4957range2(ctx,1,local+3); /*range2*/
	local[3]= w;
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtcollaCLO5138,env,argv,local);
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)MAPCAR(ctx,2,local+4); /*mapcar*/
	local[0]= w;
irtcollaBLK5137:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5138(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= fqv[164];
	local[2]= env->c.clo.env2[1];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= w;
	local[1]= NIL;
	local[2]= fqv[165];
	local[3]= env->c.clo.env2[2];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,4,local+1); /*format*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)irtcollaF4963mesh_description__collada_material(ctx,2,local+0); /*mesh-description->collada-material*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*mesh-description->collada-material*/
static pointer irtcollaF4963mesh_description__collada_material(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[166];
	local[1]= fqv[11];
	local[2]= fqv[159];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	local[2]= fqv[167];
	local[3]= fqv[11];
	local[4]= fqv[168];
	local[5]= NIL;
	local[6]= fqv[169];
	local[7]= argv[1];
	ctx->vsp=local+8;
	w=(pointer)XFORMAT(ctx,3,local+5); /*format*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
irtcollaBLK5139:
	ctx->vsp=local; return(local[0]);}

/*links-description->collada-library-effects*/
static pointer irtcollaF4964links_description__collada_library_effects(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[170];
	local[1]= fqv[11];
	local[2]= fqv[159];
	local[3]= fqv[171];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	local[2]= (pointer)get_sym_func(fqv[172]);
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)APPEND(ctx,2,local+2); /*append*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
irtcollaBLK5140:
	ctx->vsp=local; return(local[0]);}

/*link-description->collada-effects*/
static pointer irtcollaF4965link_description__collada_effects(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[53];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= NIL;
	local[2]= fqv[173];
	local[3]= fqv[34];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[17])(ctx,2,local+3,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,3,local+1); /*format*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)irtcollaF4957range2(ctx,1,local+2); /*range2*/
	local[2]= w;
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,irtcollaCLO5142,env,argv,local);
	local[4]= local[0];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)MAPCAR(ctx,3,local+3); /*mapcar*/
	local[0]= w;
irtcollaBLK5141:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5142(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= NIL;
	local[2]= fqv[174];
	local[3]= env->c.clo.env2[1];
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,4,local+1); /*format*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)irtcollaF4966mesh_description__collada_effect(ctx,2,local+0); /*mesh-description->collada-effect*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*mesh-description->collada-effect*/
static pointer irtcollaF4966mesh_description__collada_effect(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[64];
	ctx->vsp=local+2;
	w=(pointer)GETPROP(ctx,2,local+0); /*get*/
	if (w!=NIL) goto irtcollaIF5144;
	local[0]= fqv[175];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,2,local+0); /*error*/
	local[0]= w;
	goto irtcollaIF5145;
irtcollaIF5144:
	local[0]= NIL;
irtcollaIF5145:
	local[0]= fqv[176];
	local[1]= fqv[11];
	local[2]= fqv[159];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	local[2]= fqv[177];
	local[3]= fqv[178];
	local[4]= fqv[11];
	local[5]= fqv[179];
	local[6]= fqv[180];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[181];
	local[6]= fqv[182];
	local[7]= fqv[183];
	local[8]= NIL;
	local[9]= fqv[184];
	local[10]= argv[0];
	local[11]= fqv[64];
	ctx->vsp=local+12;
	w=(pointer)GETPROP(ctx,2,local+10); /*get*/
	local[10]= w;
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	local[11]= argv[0];
	local[12]= fqv[64];
	ctx->vsp=local+13;
	w=(pointer)GETPROP(ctx,2,local+11); /*get*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= argv[0];
	local[13]= fqv[64];
	ctx->vsp=local+14;
	w=(pointer)GETPROP(ctx,2,local+12); /*get*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)2L);
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,5,local+8); /*format*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[185];
	local[8]= fqv[183];
	local[9]= NIL;
	local[10]= fqv[186];
	local[11]= argv[0];
	local[12]= fqv[64];
	ctx->vsp=local+13;
	w=(pointer)GETPROP(ctx,2,local+11); /*get*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= argv[0];
	local[13]= fqv[64];
	ctx->vsp=local+14;
	w=(pointer)GETPROP(ctx,2,local+12); /*get*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)1L);
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= argv[0];
	local[14]= fqv[64];
	ctx->vsp=local+15;
	w=(pointer)GETPROP(ctx,2,local+13); /*get*/
	local[13]= w;
	local[14]= makeint((eusinteger_t)2L);
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)XFORMAT(ctx,5,local+9); /*format*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
irtcollaBLK5143:
	ctx->vsp=local; return(local[0]);}

/*matrix->collada-string*/
static pointer irtcollaF4967matrix__collada_string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[18])(ctx,1,local+0,&ftab[18],fqv[187]); /*array-dimensions*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[19])(ctx,0,local+1,&ftab[19],fqv[188]); /*make-string-output-stream*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
irtcollaWHL5147:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto irtcollaWHX5148;
	local[4]= makeint((eusinteger_t)0L);
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
irtcollaWHL5150:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto irtcollaWHX5151;
	local[6]= local[1];
	local[7]= fqv[189];
	local[8]= argv[0];
	local[9]= local[2];
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto irtcollaWHL5150;
irtcollaWHX5151:
	local[6]= NIL;
irtcollaBLK5152:
	w = NIL;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto irtcollaWHL5147;
irtcollaWHX5148:
	local[4]= NIL;
irtcollaBLK5149:
	w = NIL;
	local[2]= local[1];
	local[3]= fqv[190];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,2,local+2); /*format*/
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(*ftab[20])(ctx,1,local+2,&ftab[20],fqv[191]); /*get-output-stream-string*/
	local[0]= w;
irtcollaBLK5146:
	ctx->vsp=local; return(local[0]);}

/*find-parent-liks-from-link-description*/
static pointer irtcollaF4968find_parent_liks_from_link_description(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)irtcollaF4952eusmodel_link_description(ctx,1,local+1); /*eusmodel-link-description*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)irtcollaF4982find_joint_from_link_description(ctx,2,local+0); /*find-joint-from-link-description*/
	local[0]= w;
	if (local[0]!=NIL) goto irtcollaIF5154;
	local[1]= NIL;
	goto irtcollaIF5155;
irtcollaIF5154:
	local[1]= fqv[45];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[17])(ctx,2,local+1,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	local[2]= local[1];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)irtcollaF4952eusmodel_link_description(ctx,1,local+3); /*eusmodel-link-description*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)irtcollaF4980find_link_from_links_description(ctx,2,local+2); /*find-link-from-links-description*/
	local[2]= w;
	local[3]= local[2];
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)irtcollaF4968find_parent_liks_from_link_description(ctx,2,local+3); /*find-parent-liks-from-link-description*/
	local[3]= w;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)APPEND(ctx,2,local+3); /*append*/
	local[1]= w;
irtcollaIF5155:
	w = local[1];
	local[0]= w;
irtcollaBLK5153:
	ctx->vsp=local; return(local[0]);}

/*eusmodel-description->collada-node-transformations*/
static pointer irtcollaF4969eusmodel_description__collada_node_transformations(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)irtcollaF4968find_parent_liks_from_link_description(ctx,2,local+0); /*find-parent-liks-from-link-description*/
	local[0]= w;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPEND(ctx,2,local+0); /*append*/
	local[0]= w;
	local[1]= (pointer)get_sym_func(fqv[192]);
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtcollaCLO5157,env,argv,local);
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[21])(ctx,2,local+1,&ftab[21],fqv[193]); /*remove-if*/
	local[0]= w;
irtcollaBLK5156:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5157(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env1[1];
	ctx->vsp=local+2;
	w=(pointer)irtcollaF4953eusmodel_joint_description(ctx,1,local+1); /*eusmodel-joint-description*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)irtcollaF4982find_joint_from_link_description(ctx,2,local+0); /*find-joint-from-link-description*/
	local[0]= w;
	if (local[0]==NIL) goto irtcollaIF5158;
	local[1]= fqv[194];
	local[2]= fqv[11];
	local[3]= fqv[179];
	local[4]= NIL;
	local[5]= fqv[195];
	local[6]= fqv[34];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(*ftab[17])(ctx,2,local+6,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.cdr;
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,3,local+4); /*format*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[196];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[1]= w;
	goto irtcollaIF5159;
irtcollaIF5158:
	local[1]= NIL;
irtcollaIF5159:
	w = local[1];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*eusmodel-description->collada-node*/
static pointer irtcollaF4970eusmodel_description__collada_node(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	ctx->vsp=local+1;
	w=(pointer)irtcollaF4953eusmodel_joint_description(ctx,1,local+0); /*eusmodel-joint-description*/
	local[0]= w;
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)irtcollaF4952eusmodel_link_description(ctx,1,local+1); /*eusmodel-link-description*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)irtcollaF4953eusmodel_joint_description(ctx,1,local+3); /*eusmodel-joint-description*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)irtcollaF4982find_joint_from_link_description(ctx,2,local+2); /*find-joint-from-link-description*/
	local[2]= w;
	local[3]= fqv[53];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[17])(ctx,2,local+3,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	local[4]= fqv[52];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(*ftab[17])(ctx,2,local+4,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtcollaCLO5161,env,argv,local);
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(pointer)irtcollaF4952eusmodel_link_description(ctx,1,local+6); /*eusmodel-link-description*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[22])(ctx,2,local+5,&ftab[22],fqv[197]); /*position-if*/
	local[5]= w;
	local[6]= fqv[198];
	local[7]= fqv[11];
	local[8]= fqv[159];
	local[9]= argv[0];
	ctx->vsp=local+10;
	w=(pointer)irtcollaF4959collada_node_id(ctx,1,local+9); /*collada-node-id*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= fqv[130];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(pointer)irtcollaF4960collada_node_name(ctx,1,local+10); /*collada-node-name*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[179];
	local[11]= NIL;
	local[12]= fqv[199];
	local[13]= local[5];
	ctx->vsp=local+14;
	w=(pointer)XFORMAT(ctx,3,local+11); /*format*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= argv[0];
	local[9]= argv[1];
	ctx->vsp=local+10;
	w=(pointer)irtcollaF4969eusmodel_description__collada_node_transformations(ctx,2,local+8); /*eusmodel-description->collada-node-transformations*/
	local[8]= w;
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,irtcollaCLO5162,env,argv,local);
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)LENGTH(ctx,1,local+10); /*length*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)irtcollaF5007enum_integer_list(ctx,1,local+10); /*enum-integer-list*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)MAPCAR(ctx,2,local+9); /*mapcar*/
	local[9]= w;
	local[10]= NIL;
	ctx->vsp=local+11;
	w=(pointer)APPEND(ctx,2,local+9); /*append*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)APPEND(ctx,2,local+8); /*append*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	local[0]= w;
irtcollaBLK5160:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5161(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[34];
	local[1]= env->c.clo.env1[0];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= fqv[34];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[17])(ctx,2,local+1,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	ctx->vsp=local+2;
	w=(*ftab[23])(ctx,2,local+0,&ftab[23],fqv[38]); /*string=*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5162(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[200];
	local[1]= fqv[11];
	local[2]= fqv[168];
	local[3]= NIL;
	local[4]= fqv[201];
	local[5]= env->c.clo.env1[0];
	ctx->vsp=local+6;
	w=(pointer)irtcollaF4998collada_geometry_id_base(ctx,1,local+5); /*collada-geometry-id-base*/
	local[5]= w;
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,4,local+3); /*format*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	local[2]= fqv[202];
	local[3]= fqv[203];
	local[4]= fqv[204];
	local[5]= fqv[11];
	local[6]= fqv[205];
	local[7]= NIL;
	local[8]= fqv[206];
	local[9]= env->c.clo.env1[0];
	ctx->vsp=local+10;
	w=(pointer)irtcollaF4998collada_geometry_id_base(ctx,1,local+9); /*collada-geometry-id-base*/
	local[9]= w;
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,4,local+7); /*format*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[207];
	local[8]= NIL;
	local[9]= fqv[208];
	local[10]= env->c.clo.env1[0];
	ctx->vsp=local+11;
	w=(pointer)irtcollaF4998collada_geometry_id_base(ctx,1,local+10); /*collada-geometry-id-base*/
	local[10]= w;
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(pointer)XFORMAT(ctx,4,local+8); /*format*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*eusmodel-description->collada-library-visual-scenes*/
static pointer irtcollaF4971eusmodel_description__collada_library_visual_scenes(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[209];
	local[1]= fqv[11];
	local[2]= fqv[159];
	local[3]= fqv[210];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	local[2]= fqv[211];
	local[3]= fqv[11];
	local[4]= fqv[159];
	local[5]= fqv[212];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[130];
	local[6]= fqv[213];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[198];
	local[5]= fqv[11];
	local[6]= fqv[159];
	local[7]= fqv[214];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[179];
	local[8]= fqv[215];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[130];
	local[9]= argv[0];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtcollaCLO5164,env,argv,local);
	local[7]= argv[1];
	ctx->vsp=local+8;
	w=(pointer)irtcollaF4952eusmodel_link_description(ctx,1,local+7); /*eusmodel-link-description*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MAPCAR(ctx,2,local+6); /*mapcar*/
	local[6]= w;
	local[7]= NIL;
	ctx->vsp=local+8;
	w=(pointer)APPEND(ctx,2,local+6); /*append*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
irtcollaBLK5163:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5164(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env1[1];
	ctx->vsp=local+2;
	w=(pointer)irtcollaF4970eusmodel_description__collada_node(ctx,2,local+0); /*eusmodel-description->collada-node*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*mesh-description->instance-material*/
static pointer irtcollaF4972mesh_description__instance_material(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[204];
	local[1]= fqv[11];
	local[2]= fqv[205];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[207];
	local[4]= NIL;
	local[5]= fqv[216];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,3,local+4); /*format*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
irtcollaBLK5165:
	ctx->vsp=local; return(local[0]);}

/*link-description->collada-bind-material*/
static pointer irtcollaF4973link_description__collada_bind_material(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[53];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= fqv[34];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[17])(ctx,2,local+1,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)irtcollaF5007enum_integer_list(ctx,1,local+2); /*enum-integer-list*/
	local[2]= w;
	local[3]= fqv[202];
	local[4]= fqv[203];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtcollaCLO5167,env,argv,local);
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)MAPCAR(ctx,2,local+5); /*mapcar*/
	local[5]= w;
	local[6]= NIL;
	ctx->vsp=local+7;
	w=(pointer)APPEND(ctx,2,local+5); /*append*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	local[0]= w;
irtcollaBLK5166:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5167(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= fqv[217];
	local[2]= env->c.clo.env2[1];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)irtcollaF4972mesh_description__instance_material(ctx,1,local+0); /*mesh-description->instance-material*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*eusmodel-description->collada-library-kinematics-scenes*/
static pointer irtcollaF4974eusmodel_description__collada_library_kinematics_scenes(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[218];
	local[1]= fqv[11];
	local[2]= fqv[159];
	local[3]= fqv[219];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	local[2]= fqv[220];
	local[3]= fqv[11];
	local[4]= fqv[159];
	local[5]= fqv[221];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[130];
	local[6]= fqv[222];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[223];
	local[5]= fqv[11];
	local[6]= fqv[179];
	local[7]= fqv[224];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[168];
	local[8]= fqv[225];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[130];
	local[9]= argv[0];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[226];
	local[7]= fqv[11];
	local[8]= fqv[179];
	local[9]= fqv[227];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[228];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtcollaCLO5169,env,argv,local);
	local[8]= argv[1];
	ctx->vsp=local+9;
	w=(pointer)irtcollaF4953eusmodel_joint_description(ctx,1,local+8); /*eusmodel-joint-description*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MAPCAR(ctx,2,local+7); /*mapcar*/
	local[7]= w;
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtcollaCLO5170,env,argv,local);
	local[9]= argv[1];
	ctx->vsp=local+10;
	w=(pointer)irtcollaF4953eusmodel_joint_description(ctx,1,local+9); /*eusmodel-joint-description*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MAPCAR(ctx,2,local+8); /*mapcar*/
	local[8]= w;
	local[9]= NIL;
	ctx->vsp=local+10;
	w=(pointer)APPEND(ctx,2,local+8); /*append*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)APPEND(ctx,2,local+7); /*append*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
irtcollaBLK5168:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5169(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[34];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= fqv[226];
	local[2]= fqv[11];
	local[3]= fqv[179];
	local[4]= NIL;
	local[5]= fqv[229];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,3,local+4); /*format*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= NIL;
	local[4]= fqv[230];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,3,local+3); /*format*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5170(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[34];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= fqv[226];
	local[2]= fqv[11];
	local[3]= fqv[179];
	local[4]= NIL;
	local[5]= fqv[231];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,3,local+4); /*format*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= NIL;
	local[4]= fqv[232];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,3,local+3); /*format*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*eusmodel-description->collada-library-kinematics-models*/
static pointer irtcollaF4975eusmodel_description__collada_library_kinematics_models(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[233];
	local[1]= fqv[11];
	local[2]= fqv[159];
	local[3]= fqv[234];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	local[2]= argv[0];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)irtcollaF4976eusmodel_description__collada_kinematics_model(ctx,2,local+2); /*eusmodel-description->collada-kinematics-model*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
irtcollaBLK5171:
	ctx->vsp=local; return(local[0]);}

/*eusmodel-description->collada-kinematics-model*/
static pointer irtcollaF4976eusmodel_description__collada_kinematics_model(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	ctx->vsp=local+1;
	w=(pointer)irtcollaF4953eusmodel_joint_description(ctx,1,local+0); /*eusmodel-joint-description*/
	local[0]= w;
	local[1]= fqv[235];
	local[2]= fqv[11];
	local[3]= fqv[159];
	local[4]= fqv[236];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[130];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[203];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)irtcollaF4988joints_description__collada_instance_joints(ctx,1,local+4); /*joints-description->collada-instance-joints*/
	local[4]= w;
	local[5]= argv[1];
	ctx->vsp=local+6;
	w=(pointer)irtcollaF4981eusmodel_description__collada_links(ctx,1,local+5); /*eusmodel-description->collada-links*/
	local[5]= w;
	local[6]= NIL;
	ctx->vsp=local+7;
	w=(pointer)APPEND(ctx,2,local+5); /*append*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)APPEND(ctx,2,local+4); /*append*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
irtcollaBLK5172:
	ctx->vsp=local; return(local[0]);}

/*eusmodel-description->collada-library-physics-scenes*/
static pointer irtcollaF4977eusmodel_description__collada_library_physics_scenes(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[237];
	local[1]= fqv[11];
	local[2]= fqv[159];
	local[3]= fqv[238];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	local[2]= fqv[239];
	local[3]= fqv[11];
	local[4]= fqv[159];
	local[5]= fqv[240];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[130];
	local[6]= fqv[241];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[242];
	local[5]= fqv[11];
	local[6]= fqv[168];
	local[7]= fqv[243];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[179];
	local[8]= fqv[244];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[245];
	local[9]= fqv[246];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(pointer)irtcollaF4952eusmodel_link_description(ctx,1,local+6); /*eusmodel-link-description*/
	local[6]= w;
	local[7]= local[6];
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)irtcollaF5007enum_integer_list(ctx,1,local+7); /*enum-integer-list*/
	local[7]= w;
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtcollaCLO5174,env,argv,local);
	local[9]= local[7];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)MAPCAR(ctx,3,local+8); /*mapcar*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
irtcollaBLK5173:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5174(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[247];
	local[1]= fqv[11];
	local[2]= fqv[248];
	local[3]= NIL;
	local[4]= fqv[249];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,3,local+3); /*format*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[207];
	local[4]= NIL;
	local[5]= fqv[250];
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(pointer)irtcollaF4959collada_node_id(ctx,1,local+6); /*collada-node-id*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,3,local+4); /*format*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*eusmodel-description->collada-library-physics-models*/
static pointer irtcollaF4978eusmodel_description__collada_library_physics_models(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[251];
	local[1]= fqv[11];
	local[2]= fqv[159];
	local[3]= fqv[252];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	local[2]= fqv[253];
	local[3]= fqv[11];
	local[4]= fqv[159];
	local[5]= fqv[254];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[130];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtcollaCLO5176,env,argv,local);
	local[5]= argv[1];
	ctx->vsp=local+6;
	w=(pointer)irtcollaF4952eusmodel_link_description(ctx,1,local+5); /*eusmodel-link-description*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)irtcollaF5007enum_integer_list(ctx,1,local+5); /*enum-integer-list*/
	local[5]= w;
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(pointer)irtcollaF4952eusmodel_link_description(ctx,1,local+6); /*eusmodel-link-description*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MAPCAR(ctx,3,local+4); /*mapcar*/
	local[4]= w;
	local[5]= NIL;
	ctx->vsp=local+6;
	w=(pointer)APPEND(ctx,2,local+4); /*append*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
irtcollaBLK5175:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5176(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[34];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= NIL;
	local[2]= fqv[255];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,3,local+1); /*format*/
	local[1]= w;
	local[2]= NIL;
	local[3]= fqv[256];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	local[3]= fqv[53];
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(*ftab[17])(ctx,2,local+3,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	local[4]= fqv[257];
	local[5]= fqv[11];
	local[6]= fqv[159];
	local[7]= NIL;
	local[8]= fqv[258];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)XFORMAT(ctx,3,local+7); /*format*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[179];
	local[8]= NIL;
	local[9]= fqv[259];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,3,local+8); /*format*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[130];
	local[9]= NIL;
	local[10]= fqv[260];
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(pointer)XFORMAT(ctx,3,local+9); /*format*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[203];
	local[7]= fqv[261];
	local[8]= NIL;
	local[9]= fqv[262];
	local[10]= fqv[55];
	local[11]= argv[1];
	ctx->vsp=local+12;
	w=(*ftab[17])(ctx,2,local+10,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.cdr;
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,3,local+8); /*format*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[263];
	local[9]= fqv[264];
	local[10]= fqv[54];
	local[11]= argv[1];
	ctx->vsp=local+12;
	w=(*ftab[17])(ctx,2,local+10,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.cdr;
	local[11]= fqv[265];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)irtcollaF5006float_vector__collada_string(ctx,1,local+10); /*float-vector->collada-string*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[194];
	local[11]= fqv[54];
	local[12]= argv[1];
	ctx->vsp=local+13;
	w=(*ftab[17])(ctx,2,local+11,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.cdr;
	local[12]= fqv[266];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)irtcollaF4984matrix__collada_rotate_vector(ctx,1,local+11); /*matrix->collada-rotate-vector*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)irtcollaF5006float_vector__collada_string(ctx,1,local+11); /*float-vector->collada-string*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= fqv[267];
	local[10]= fqv[57];
	local[11]= argv[1];
	ctx->vsp=local+12;
	w=(*ftab[17])(ctx,2,local+10,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.cdr;
	ctx->vsp=local+11;
	w=(pointer)irtcollaF5006float_vector__collada_string(ctx,1,local+10); /*float-vector->collada-string*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	local[10]= makeclosure(codevec,quotevec,irtcollaCLO5177,env,argv,local);
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)irtcollaF5007enum_integer_list(ctx,1,local+11); /*enum-integer-list*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)MAPCAR(ctx,2,local+10); /*mapcar*/
	local[10]= w;
	local[11]= NIL;
	ctx->vsp=local+12;
	w=(pointer)APPEND(ctx,2,local+10); /*append*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5177(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[268];
	local[1]= fqv[200];
	local[2]= fqv[11];
	local[3]= fqv[168];
	local[4]= NIL;
	local[5]= fqv[269];
	local[6]= env->c.clo.env2[0];
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)XFORMAT(ctx,4,local+4); /*format*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	local[2]= fqv[264];
	local[3]= fqv[270];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[194];
	local[4]= fqv[271];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*find-root-link-from-joints-description*/
static pointer irtcollaF4979find_root_link_from_joints_description(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[0];
irtcollaWHL5179:
	if (local[2]==NIL) goto irtcollaWHX5180;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= fqv[34];
	local[4]= fqv[34];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(*ftab[17])(ctx,2,local+4,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	ctx->vsp=local+5;
	w=(*ftab[15])(ctx,2,local+3,&ftab[15],fqv[145]); /*geometry:make-cascoords*/
	local[3]= w;
	local[4]= local[3];
	local[5]= fqv[45];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(*ftab[17])(ctx,2,local+5,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.cdr;
	local[6]= fqv[95];
	ctx->vsp=local+7;
	w=(pointer)PUTPROP(ctx,3,local+4); /*putprop*/
	local[4]= local[3];
	local[5]= fqv[96];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(*ftab[17])(ctx,2,local+5,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.cdr;
	local[6]= fqv[97];
	ctx->vsp=local+7;
	w=(pointer)PUTPROP(ctx,3,local+4); /*putprop*/
	local[4]= local[3];
	w = local[0];
	ctx->vsp=local+5;
	local[0] = cons(ctx,local[4],w);
	w = local[0];
	goto irtcollaWHL5179;
irtcollaWHX5180:
	local[3]= NIL;
irtcollaBLK5181:
	w = NIL;
	local[1]= NIL;
	local[2]= local[0];
irtcollaWHL5182:
	if (local[2]==NIL) goto irtcollaWHX5183;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= local[1];
	local[4]= fqv[95];
	ctx->vsp=local+5;
	w=(pointer)GETPROP(ctx,2,local+3); /*get*/
	local[3]= w;
	local[4]= local[3];
	local[5]= local[0];
	local[6]= fqv[37];
	local[7]= (pointer)get_sym_func(fqv[38]);
	local[8]= fqv[272];
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,irtcollaCLO5185,env,argv,local);
	ctx->vsp=local+10;
	w=(*ftab[0])(ctx,6,local+4,&ftab[0],fqv[1]); /*find*/
	local[4]= w;
	if (local[4]!=NIL) goto irtcollaIF5186;
	w = local[3];
	ctx->vsp=local+5;
	local[0]=w;
	goto irtcollaBLK5178;
	goto irtcollaIF5187;
irtcollaIF5186:
	local[5]= NIL;
irtcollaIF5187:
	w = local[5];
	goto irtcollaWHL5182;
irtcollaWHX5183:
	local[3]= NIL;
irtcollaBLK5184:
	w = NIL;
	local[0]= w;
irtcollaBLK5178:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5185(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[97];
	ctx->vsp=local+2;
	w=(pointer)GETPROP(ctx,2,local+0); /*get*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*find-link-from-links-description*/
static pointer irtcollaF4980find_link_from_links_description(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= argv[1];
	local[2]= fqv[37];
	local[3]= (pointer)get_sym_func(fqv[38]);
	local[4]= fqv[272];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtcollaCLO5189,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[0])(ctx,6,local+0,&ftab[0],fqv[1]); /*find*/
	local[0]= w;
irtcollaBLK5188:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5189(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[34];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*eusmodel-description->collada-links*/
static pointer irtcollaF4981eusmodel_description__collada_links(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)irtcollaF4953eusmodel_joint_description(ctx,1,local+0); /*eusmodel-joint-description*/
	local[0]= w;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)irtcollaF4952eusmodel_link_description(ctx,1,local+1); /*eusmodel-link-description*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)irtcollaF4979find_root_link_from_joints_description(ctx,1,local+2); /*find-root-link-from-joints-description*/
	local[2]= w;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)irtcollaF4980find_link_from_links_description(ctx,2,local+2); /*find-link-from-links-description*/
	local[2]= w;
	local[3]= local[2];
	local[4]= local[1];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)irtcollaF4987eusmodel_description__collada_links_tree(ctx,3,local+3); /*eusmodel-description->collada-links-tree*/
	local[0]= w;
irtcollaBLK5190:
	ctx->vsp=local; return(local[0]);}

/*find-joint-from-link-description*/
static pointer irtcollaF4982find_joint_from_link_description(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[34];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= argv[1];
	local[2]= fqv[37];
	local[3]= (pointer)get_sym_func(fqv[38]);
	local[4]= fqv[272];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtcollaCLO5192,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[0])(ctx,6,local+0,&ftab[0],fqv[1]); /*find*/
	local[0]= w;
irtcollaBLK5191:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5192(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[96];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*find-child-link-descriptions*/
static pointer irtcollaF4983find_child_link_descriptions(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtcollaCLO5194,env,argv,local);
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(*ftab[24])(ctx,2,local+0,&ftab[24],fqv[273]); /*remove-if-not*/
	local[0]= w;
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtcollaCLO5195,env,argv,local);
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(*ftab[24])(ctx,2,local+1,&ftab[24],fqv[273]); /*remove-if-not*/
	local[1]= w;
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtcollaCLO5196,env,argv,local);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[2]= w;
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,irtcollaCLO5197,env,argv,local);
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)MAPCAR(ctx,2,local+3); /*mapcar*/
	local[0]= w;
irtcollaBLK5193:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5194(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[45];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5195(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[45];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= fqv[34];
	local[2]= env->c.clo.env1[0];
	ctx->vsp=local+3;
	w=(*ftab[17])(ctx,2,local+1,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	ctx->vsp=local+2;
	w=(*ftab[23])(ctx,2,local+0,&ftab[23],fqv[38]); /*string=*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5196(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[96];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5197(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env1[1];
	ctx->vsp=local+2;
	w=(pointer)irtcollaF4980find_link_from_links_description(ctx,2,local+0); /*find-link-from-links-description*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*matrix->collada-rotate-vector*/
static pointer irtcollaF4984matrix__collada_rotate_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[25])(ctx,1,local+0,&ftab[25],fqv[274]); /*user::matrix2quaternion*/
	local[0]= w;
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	local[3]= local[0];
	local[4]= makeint((eusinteger_t)3L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,3,local+1); /*float-vector*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[26])(ctx,1,local+1,&ftab[26],fqv[275]); /*normalize-vector*/
	local[1]= w;
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	local[3]= local[1];
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	local[4]= local[1];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= local[1];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= makeflt(2.0000000000000000000000e+00);
	local[7]= local[0];
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(*ftab[27])(ctx,2,local+7,&ftab[27],fqv[276]); /*expt*/
	local[7]= w;
	local[8]= local[0];
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(*ftab[27])(ctx,2,local+8,&ftab[27],fqv[276]); /*expt*/
	local[8]= w;
	local[9]= local[0];
	local[10]= makeint((eusinteger_t)3L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(*ftab[27])(ctx,2,local+9,&ftab[27],fqv[276]); /*expt*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,3,local+7); /*+*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SQRT(ctx,1,local+7); /*sqrt*/
	local[7]= w;
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)ATAN(ctx,2,local+7); /*atan*/
	{ double x,y;
		y=fltval(w); x=fltval(local[6]);
		local[6]=(makeflt(x * y));}
	ctx->vsp=local+7;
	w=(*ftab[28])(ctx,1,local+6,&ftab[28],fqv[277]); /*rad2deg*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,4,local+3); /*float-vector*/
	local[0]= w;
irtcollaBLK5198:
	ctx->vsp=local; return(local[0]);}

/*eusmodel-description->collada-library-articulated-systems*/
static pointer irtcollaF4985eusmodel_description__collada_library_articulated_systems(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[278];
	local[1]= fqv[11];
	local[2]= fqv[159];
	local[3]= fqv[279];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	local[2]= fqv[280];
	local[3]= fqv[11];
	local[4]= fqv[159];
	local[5]= fqv[281];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[282];
	local[5]= fqv[223];
	local[6]= fqv[11];
	local[7]= fqv[168];
	local[8]= fqv[283];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[226];
	local[8]= fqv[11];
	local[9]= fqv[179];
	local[10]= fqv[284];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= fqv[285];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtcollaCLO5200,env,argv,local);
	local[9]= argv[0];
	ctx->vsp=local+10;
	w=(pointer)irtcollaF4953eusmodel_joint_description(ctx,1,local+9); /*eusmodel-joint-description*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MAPCAR(ctx,2,local+8); /*mapcar*/
	local[8]= w;
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,irtcollaCLO5201,env,argv,local);
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(pointer)irtcollaF4953eusmodel_joint_description(ctx,1,local+10); /*eusmodel-joint-description*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)MAPCAR(ctx,2,local+9); /*mapcar*/
	local[9]= w;
	local[10]= NIL;
	ctx->vsp=local+11;
	w=(pointer)APPEND(ctx,2,local+9); /*append*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)APPEND(ctx,2,local+8); /*append*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[203];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtcollaCLO5202,env,argv,local);
	local[8]= argv[0];
	ctx->vsp=local+9;
	w=(pointer)irtcollaF4953eusmodel_joint_description(ctx,1,local+8); /*eusmodel-joint-description*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MAPCAR(ctx,2,local+7); /*mapcar*/
	local[7]= w;
	local[8]= NIL;
	ctx->vsp=local+9;
	w=(pointer)APPEND(ctx,2,local+7); /*append*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtcollaCLO5203,env,argv,local);
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)irtcollaF4954eusmodel_endcoords_description(ctx,1,local+6); /*eusmodel-endcoords-description*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MAPCAR(ctx,2,local+5); /*mapcar*/
	local[5]= w;
	local[6]= NIL;
	ctx->vsp=local+7;
	w=(pointer)APPEND(ctx,2,local+5); /*append*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[280];
	local[4]= fqv[11];
	local[5]= fqv[159];
	local[6]= fqv[286];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[287];
	local[6]= fqv[288];
	local[7]= fqv[11];
	local[8]= fqv[168];
	local[9]= fqv[289];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= fqv[179];
	local[10]= fqv[290];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[226];
	local[9]= fqv[11];
	local[10]= fqv[179];
	local[11]= fqv[291];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[292];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,irtcollaCLO5204,env,argv,local);
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(pointer)irtcollaF4953eusmodel_joint_description(ctx,1,local+10); /*eusmodel-joint-description*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)MAPCAR(ctx,2,local+9); /*mapcar*/
	local[9]= w;
	ctx->vsp=local+10;
	local[10]= makeclosure(codevec,quotevec,irtcollaCLO5205,env,argv,local);
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(pointer)irtcollaF4953eusmodel_joint_description(ctx,1,local+11); /*eusmodel-joint-description*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)MAPCAR(ctx,2,local+10); /*mapcar*/
	local[10]= w;
	local[11]= NIL;
	ctx->vsp=local+12;
	w=(pointer)APPEND(ctx,2,local+10); /*append*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)APPEND(ctx,2,local+9); /*append*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[203];
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtcollaCLO5206,env,argv,local);
	local[9]= argv[0];
	ctx->vsp=local+10;
	w=(pointer)irtcollaF4953eusmodel_joint_description(ctx,1,local+9); /*eusmodel-joint-description*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MAPCAR(ctx,2,local+8); /*mapcar*/
	local[8]= w;
	local[9]= NIL;
	ctx->vsp=local+10;
	w=(pointer)APPEND(ctx,2,local+8); /*append*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
irtcollaBLK5199:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5200(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[34];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= fqv[226];
	local[2]= fqv[11];
	local[3]= fqv[179];
	local[4]= NIL;
	local[5]= fqv[293];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,3,local+4); /*format*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= NIL;
	local[4]= fqv[294];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,3,local+3); /*format*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5201(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[34];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= fqv[226];
	local[2]= fqv[11];
	local[3]= fqv[179];
	local[4]= NIL;
	local[5]= fqv[295];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,3,local+4); /*format*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= NIL;
	local[4]= fqv[296];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,3,local+3); /*format*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5202(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[34];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= fqv[297];
	local[2]= fqv[11];
	local[3]= fqv[298];
	local[4]= NIL;
	local[5]= fqv[299];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,3,local+4); /*format*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5203(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env1[0];
	ctx->vsp=local+2;
	w=(pointer)irtcollaF4986eusmodel_endcoords_description__openrave_manipulator(ctx,2,local+0); /*eusmodel-endcoords-description->openrave-manipulator*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5204(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[34];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= fqv[226];
	local[2]= fqv[11];
	local[3]= fqv[179];
	local[4]= NIL;
	local[5]= fqv[300];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,3,local+4); /*format*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= NIL;
	local[4]= fqv[301];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,3,local+3); /*format*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5205(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[34];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= fqv[226];
	local[2]= fqv[11];
	local[3]= fqv[179];
	local[4]= NIL;
	local[5]= fqv[302];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,3,local+4); /*format*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[303];
	local[4]= fqv[304];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5206(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[34];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= fqv[297];
	local[2]= fqv[11];
	local[3]= fqv[298];
	local[4]= NIL;
	local[5]= fqv[305];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,3,local+4); /*format*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[179];
	local[5]= NIL;
	local[6]= fqv[306];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)XFORMAT(ctx,3,local+5); /*format*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*eusmodel-endcoords-description->openrave-manipulator*/
static pointer irtcollaF4986eusmodel_endcoords_description__openrave_manipulator(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.cdr;
	ctx->vsp=local+3;
	w=(*ftab[29])(ctx,1,local+2,&ftab[29],fqv[307]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= fqv[308];
	local[4]= fqv[11];
	local[5]= fqv[130];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[309];
	local[7]= fqv[310];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[178];
	local[6]= fqv[11];
	local[7]= fqv[311];
	local[8]= fqv[312];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[313];
	local[8]= fqv[11];
	local[9]= fqv[314];
	local[10]= NIL;
	local[11]= fqv[315];
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,3,local+10); /*format*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[316];
	local[9]= fqv[11];
	local[10]= fqv[314];
	local[11]= NIL;
	local[12]= fqv[317];
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(pointer)XFORMAT(ctx,3,local+11); /*format*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	local[0]= w;
irtcollaBLK5207:
	ctx->vsp=local; return(local[0]);}

/*eusmodel-description->collada-links-tree*/
static pointer irtcollaF4987eusmodel_description__collada_links_tree(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= argv[1];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)irtcollaF4983find_child_link_descriptions(ctx,3,local+0); /*find-child-link-descriptions*/
	local[0]= w;
	local[1]= fqv[34];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[17])(ctx,2,local+1,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	local[2]= fqv[314];
	local[3]= fqv[11];
	local[4]= fqv[179];
	local[5]= NIL;
	local[6]= fqv[318];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)XFORMAT(ctx,3,local+5); /*format*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[130];
	local[6]= NIL;
	local[7]= fqv[319];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtcollaCLO5209,env,argv,local);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)MAPCAR(ctx,2,local+4); /*mapcar*/
	local[4]= w;
	local[5]= NIL;
	ctx->vsp=local+6;
	w=(pointer)APPEND(ctx,2,local+4); /*append*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	local[0]= w;
irtcollaBLK5208:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5209(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[52];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= argv[0];
	local[2]= env->c.clo.env1[2];
	ctx->vsp=local+3;
	w=(pointer)irtcollaF4982find_joint_from_link_description(ctx,2,local+1); /*find-joint-from-link-description*/
	local[1]= w;
	local[2]= fqv[320];
	local[3]= fqv[11];
	local[4]= fqv[321];
	local[5]= NIL;
	local[6]= fqv[322];
	local[7]= fqv[34];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(*ftab[17])(ctx,2,local+7,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.cdr;
	ctx->vsp=local+8;
	w=(pointer)XFORMAT(ctx,3,local+5); /*format*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[264];
	local[5]= local[0];
	local[6]= fqv[265];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)irtcollaF5006float_vector__collada_string(ctx,1,local+5); /*float-vector->collada-string*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[194];
	local[6]= local[0];
	local[7]= fqv[266];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)irtcollaF4984matrix__collada_rotate_vector(ctx,1,local+6); /*matrix->collada-rotate-vector*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)irtcollaF5006float_vector__collada_string(ctx,1,local+6); /*float-vector->collada-string*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= argv[0];
	local[7]= env->c.clo.env1[1];
	local[8]= env->c.clo.env1[2];
	ctx->vsp=local+9;
	w=(pointer)irtcollaF4987eusmodel_description__collada_links_tree(ctx,3,local+6); /*eusmodel-description->collada-links-tree*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*joints-description->collada-instance-joints*/
static pointer irtcollaF4988joints_description__collada_instance_joints(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= (pointer)get_sym_func(fqv[323]);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
irtcollaBLK5210:
	ctx->vsp=local; return(local[0]);}

/*joint-description->collada-instance-joint*/
static pointer irtcollaF4989joint_description__collada_instance_joint(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[34];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= fqv[324];
	local[2]= fqv[11];
	local[3]= fqv[168];
	local[4]= NIL;
	local[5]= fqv[325];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,3,local+4); /*format*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[179];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
irtcollaBLK5211:
	ctx->vsp=local; return(local[0]);}

/*eusmodel-description->collada-library-joints*/
static pointer irtcollaF4990eusmodel_description__collada_library_joints(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[326];
	local[1]= fqv[11];
	local[2]= fqv[159];
	local[3]= fqv[327];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)irtcollaF4953eusmodel_joint_description(ctx,1,local+2); /*eusmodel-joint-description*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)irtcollaF4991joints_description__collada_joints(ctx,1,local+2); /*joints-description->collada-joints*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)APPEND(ctx,2,local+2); /*append*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
irtcollaBLK5212:
	ctx->vsp=local; return(local[0]);}

/*joints-description->collada-joints*/
static pointer irtcollaF4991joints_description__collada_joints(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= (pointer)get_sym_func(fqv[328]);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
irtcollaBLK5213:
	ctx->vsp=local; return(local[0]);}

/*collada-joint-id*/
static pointer irtcollaF4992collada_joint_id(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= fqv[329];
	local[2]= fqv[34];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[17])(ctx,2,local+2,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.cdr;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
irtcollaBLK5214:
	ctx->vsp=local; return(local[0]);}

/*joint-description->collada-joint*/
static pointer irtcollaF4993joint_description__collada_joint(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)irtcollaF4992collada_joint_id(ctx,1,local+0); /*collada-joint-id*/
	local[0]= w;
	local[1]= fqv[34];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[17])(ctx,2,local+1,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	local[2]= fqv[321];
	local[3]= fqv[11];
	local[4]= fqv[159];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[130];
	local[6]= NIL;
	local[7]= fqv[330];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[179];
	local[7]= NIL;
	local[8]= fqv[331];
	local[9]= fqv[72];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(*ftab[17])(ctx,2,local+9,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.cdr;
	ctx->vsp=local+10;
	w=(pointer)XFORMAT(ctx,3,local+7); /*format*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[67];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(*ftab[17])(ctx,2,local+4,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	if (fqv[71]!=local[4]) goto irtcollaCON5217;
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)irtcollaF4994linear_joint_description__collada_joint(ctx,1,local+4); /*linear-joint-description->collada-joint*/
	local[4]= w;
	goto irtcollaCON5216;
irtcollaCON5217:
	local[4]= fqv[67];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(*ftab[17])(ctx,2,local+4,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	if (fqv[69]!=local[4]) goto irtcollaCON5218;
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)irtcollaF4995rotational_joint_description__collada_joint(ctx,1,local+4); /*rotational-joint-description->collada-joint*/
	local[4]= w;
	goto irtcollaCON5216;
irtcollaCON5218:
	local[4]= fqv[332];
	local[5]= fqv[67];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(*ftab[17])(ctx,2,local+5,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.cdr;
	ctx->vsp=local+6;
	w=(pointer)SIGERROR(ctx,2,local+4); /*error*/
	local[4]= w;
	goto irtcollaCON5216;
irtcollaCON5219:
	local[4]= NIL;
irtcollaCON5216:
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	local[0]= w;
irtcollaBLK5215:
	ctx->vsp=local; return(local[0]);}

/*linear-joint-description->collada-joint*/
static pointer irtcollaF4994linear_joint_description__collada_joint(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[73];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= fqv[333];
	local[2]= fqv[11];
	local[3]= fqv[179];
	local[4]= fqv[334];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[298];
	local[4]= fqv[74];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(*ftab[17])(ctx,2,local+4,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	ctx->vsp=local+5;
	w=(pointer)irtcollaF5006float_vector__collada_string(ctx,1,local+4); /*float-vector->collada-string*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[335];
	local[5]= fqv[336];
	local[6]= NIL;
	local[7]= fqv[337];
	local[8]= fqv[101];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(*ftab[17])(ctx,2,local+8,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.cdr;
	ctx->vsp=local+9;
	w=(*ftab[28])(ctx,1,local+8,&ftab[28],fqv[277]); /*rad2deg*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[338];
	local[7]= NIL;
	local[8]= fqv[339];
	local[9]= fqv[98];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(*ftab[17])(ctx,2,local+9,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.cdr;
	ctx->vsp=local+10;
	w=(*ftab[28])(ctx,1,local+9,&ftab[28],fqv[277]); /*rad2deg*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)XFORMAT(ctx,3,local+7); /*format*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
irtcollaBLK5220:
	ctx->vsp=local; return(local[0]);}

/*rotational-joint-description->collada-joint*/
static pointer irtcollaF4995rotational_joint_description__collada_joint(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[73];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= fqv[340];
	local[2]= fqv[11];
	local[3]= fqv[179];
	local[4]= fqv[341];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[298];
	local[4]= fqv[74];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(*ftab[17])(ctx,2,local+4,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	ctx->vsp=local+5;
	w=(pointer)irtcollaF5006float_vector__collada_string(ctx,1,local+4); /*float-vector->collada-string*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[335];
	local[5]= fqv[336];
	local[6]= NIL;
	local[7]= fqv[342];
	local[8]= fqv[101];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(*ftab[17])(ctx,2,local+8,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.cdr;
	ctx->vsp=local+9;
	w=(*ftab[28])(ctx,1,local+8,&ftab[28],fqv[277]); /*rad2deg*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[338];
	local[7]= NIL;
	local[8]= fqv[343];
	local[9]= fqv[98];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(*ftab[17])(ctx,2,local+9,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.cdr;
	ctx->vsp=local+10;
	w=(*ftab[28])(ctx,1,local+9,&ftab[28],fqv[277]); /*rad2deg*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)XFORMAT(ctx,3,local+7); /*format*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
irtcollaBLK5221:
	ctx->vsp=local; return(local[0]);}

/*eusmodel-description->collada-scene*/
static pointer irtcollaF4996eusmodel_description__collada_scene(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[344];
	local[1]= fqv[345];
	local[2]= fqv[11];
	local[3]= fqv[168];
	local[4]= fqv[346];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	local[2]= fqv[347];
	local[3]= fqv[11];
	local[4]= fqv[168];
	local[5]= fqv[348];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[349];
	local[4]= fqv[11];
	local[5]= fqv[168];
	local[6]= fqv[350];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[351];
	local[6]= fqv[11];
	local[7]= fqv[198];
	local[8]= fqv[352];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[353];
	local[8]= fqv[354];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtcollaCLO5223,env,argv,local);
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)irtcollaF4953eusmodel_joint_description(ctx,1,local+7); /*eusmodel-joint-description*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MAPCAR(ctx,2,local+6); /*mapcar*/
	local[6]= w;
	local[7]= NIL;
	ctx->vsp=local+8;
	w=(pointer)APPEND(ctx,2,local+6); /*append*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
irtcollaBLK5222:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5223(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[355];
	local[1]= fqv[11];
	local[2]= fqv[207];
	local[3]= NIL;
	local[4]= fqv[356];
	local[5]= fqv[96];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(*ftab[17])(ctx,2,local+5,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.cdr;
	local[6]= fqv[34];
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(*ftab[17])(ctx,2,local+6,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.cdr;
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,4,local+3); /*format*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	local[2]= fqv[298];
	local[3]= fqv[353];
	local[4]= NIL;
	local[5]= fqv[357];
	local[6]= fqv[34];
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(*ftab[17])(ctx,2,local+6,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.cdr;
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,3,local+4); /*format*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[358];
	local[4]= fqv[353];
	local[5]= NIL;
	local[6]= fqv[359];
	local[7]= fqv[34];
	local[8]= argv[0];
	ctx->vsp=local+9;
	w=(*ftab[17])(ctx,2,local+7,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.cdr;
	ctx->vsp=local+8;
	w=(pointer)XFORMAT(ctx,3,local+5); /*format*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*eusmodel-description->collada-library-geometries*/
static pointer irtcollaF4997eusmodel_description__collada_library_geometries(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[360];
	local[1]= fqv[11];
	local[2]= fqv[159];
	local[3]= fqv[361];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)irtcollaF4952eusmodel_link_description(ctx,1,local+2); /*eusmodel-link-description*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)irtcollaF5000links_description__collada_geometries(ctx,1,local+2); /*links-description->collada-geometries*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)APPEND(ctx,2,local+2); /*append*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
irtcollaBLK5224:
	ctx->vsp=local; return(local[0]);}

/*collada-geometry-id-base*/
static pointer irtcollaF4998collada_geometry_id_base(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[34];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= NIL;
	local[2]= fqv[362];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,3,local+1); /*format*/
	local[0]= w;
irtcollaBLK5225:
	ctx->vsp=local; return(local[0]);}

/*collada-geometry-name-base*/
static pointer irtcollaF4999collada_geometry_name_base(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[34];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= NIL;
	local[2]= fqv[363];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,3,local+1); /*format*/
	local[0]= w;
irtcollaBLK5226:
	ctx->vsp=local; return(local[0]);}

/*links-description->collada-geometries*/
static pointer irtcollaF5000links_description__collada_geometries(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= (pointer)get_sym_func(fqv[364]);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
irtcollaBLK5227:
	ctx->vsp=local; return(local[0]);}

/*mesh-object->collada-mesh*/
static pointer irtcollaF5001mesh_object__collada_mesh(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[365];
	local[1]= fqv[366];
	local[2]= fqv[11];
	local[3]= fqv[159];
	local[4]= NIL;
	local[5]= fqv[367];
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,3,local+4); /*format*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[368];
	local[4]= fqv[11];
	local[5]= fqv[159];
	local[6]= NIL;
	local[7]= fqv[369];
	local[8]= argv[1];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[370];
	local[7]= makeint((eusinteger_t)3L);
	local[8]= makeint((eusinteger_t)3L);
	local[9]= argv[0];
	local[10]= fqv[61];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	{ eusinteger_t i,j;
		j=intval(w); i=intval(local[8]);
		local[8]=(makeint(i * j));}
	{ eusinteger_t i,j;
		j=intval(local[8]); i=intval(local[7]);
		local[7]=(makeint(i * j));}
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)irtcollaF5004mesh_vertices__collada_string(ctx,1,local+5); /*mesh-vertices->collada-string*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[203];
	local[5]= fqv[371];
	local[6]= fqv[11];
	local[7]= fqv[366];
	local[8]= NIL;
	local[9]= fqv[372];
	local[10]= argv[1];
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,3,local+8); /*format*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[370];
	local[9]= makeint((eusinteger_t)3L);
	local[10]= argv[0];
	local[11]= fqv[61];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)LENGTH(ctx,1,local+10); /*length*/
	{ eusinteger_t i,j;
		j=intval(w); i=intval(local[9]);
		local[9]=(makeint(i * j));}
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= fqv[373];
	local[10]= fqv[374];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[353];
	local[8]= fqv[11];
	local[9]= fqv[130];
	local[10]= fqv[375];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[309];
	local[11]= fqv[376];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[353];
	local[9]= fqv[11];
	local[10]= fqv[130];
	local[11]= fqv[377];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= fqv[309];
	local[12]= fqv[378];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= fqv[353];
	local[10]= fqv[11];
	local[11]= fqv[130];
	local[12]= fqv[379];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	local[12]= fqv[309];
	local[13]= fqv[380];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	local[2]= fqv[366];
	local[3]= fqv[11];
	local[4]= fqv[159];
	local[5]= NIL;
	local[6]= fqv[381];
	local[7]= argv[1];
	ctx->vsp=local+8;
	w=(pointer)XFORMAT(ctx,3,local+5); /*format*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[368];
	local[5]= fqv[11];
	local[6]= fqv[159];
	local[7]= NIL;
	local[8]= fqv[382];
	local[9]= argv[1];
	ctx->vsp=local+10;
	w=(pointer)XFORMAT(ctx,3,local+7); /*format*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[370];
	local[8]= makeint((eusinteger_t)3L);
	local[9]= argv[0];
	local[10]= fqv[61];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	{ eusinteger_t i,j;
		j=intval(w); i=intval(local[8]);
		local[8]=(makeint(i * j));}
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)irtcollaF5005mesh_normals__collada_string(ctx,1,local+6); /*mesh-normals->collada-string*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[203];
	local[6]= fqv[371];
	local[7]= fqv[11];
	local[8]= fqv[366];
	local[9]= NIL;
	local[10]= fqv[383];
	local[11]= argv[1];
	ctx->vsp=local+12;
	w=(pointer)XFORMAT(ctx,3,local+9); /*format*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= fqv[370];
	local[10]= argv[0];
	local[11]= fqv[61];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)LENGTH(ctx,1,local+10); /*length*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[373];
	local[11]= fqv[384];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[353];
	local[9]= fqv[11];
	local[10]= fqv[130];
	local[11]= fqv[385];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= fqv[309];
	local[12]= fqv[386];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= fqv[353];
	local[10]= fqv[11];
	local[11]= fqv[130];
	local[12]= fqv[387];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	local[12]= fqv[309];
	local[13]= fqv[388];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[353];
	local[11]= fqv[11];
	local[12]= fqv[130];
	local[13]= fqv[389];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	local[13]= fqv[309];
	local[14]= fqv[390];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[391];
	local[4]= fqv[11];
	local[5]= fqv[159];
	local[6]= NIL;
	local[7]= fqv[392];
	local[8]= argv[1];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[393];
	local[6]= fqv[11];
	local[7]= fqv[394];
	local[8]= fqv[395];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[366];
	local[9]= NIL;
	local[10]= fqv[396];
	local[11]= argv[1];
	ctx->vsp=local+12;
	w=(pointer)XFORMAT(ctx,3,local+9); /*format*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[397];
	local[5]= fqv[11];
	local[6]= fqv[370];
	local[7]= argv[0];
	local[8]= fqv[61];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[166];
	local[8]= NIL;
	local[9]= fqv[398];
	local[10]= argv[1];
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,3,local+8); /*format*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[393];
	local[7]= fqv[11];
	local[8]= fqv[399];
	local[9]= fqv[400];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= fqv[394];
	local[10]= fqv[401];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[366];
	local[11]= NIL;
	local[12]= fqv[402];
	local[13]= argv[1];
	ctx->vsp=local+14;
	w=(pointer)XFORMAT(ctx,3,local+11); /*format*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[393];
	local[8]= fqv[11];
	local[9]= fqv[399];
	local[10]= fqv[403];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[394];
	local[11]= fqv[404];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= fqv[366];
	local[12]= NIL;
	local[13]= fqv[405];
	local[14]= argv[1];
	ctx->vsp=local+15;
	w=(pointer)XFORMAT(ctx,3,local+12); /*format*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= argv[0];
	ctx->vsp=local+9;
	w=(pointer)irtcollaF5003mesh__collada_indices(ctx,1,local+8); /*mesh->collada-indices*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
irtcollaBLK5228:
	ctx->vsp=local; return(local[0]);}

/*link-description->collada-geometry*/
static pointer irtcollaF5002link_description__collada_geometry(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)irtcollaF4998collada_geometry_id_base(ctx,1,local+0); /*collada-geometry-id-base*/
	local[0]= w;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)irtcollaF4999collada_geometry_name_base(ctx,1,local+1); /*collada-geometry-name-base*/
	local[1]= w;
	local[2]= fqv[53];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[17])(ctx,2,local+2,&ftab[17],fqv[156]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.cdr;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)irtcollaF5007enum_integer_list(ctx,1,local+3); /*enum-integer-list*/
	local[3]= w;
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtcollaCLO5230,env,argv,local);
	local[5]= local[3];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)MAPCAR(ctx,3,local+4); /*mapcar*/
	local[0]= w;
irtcollaBLK5229:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtcollaCLO5230(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= fqv[406];
	local[2]= env->c.clo.env2[0];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= w;
	local[1]= NIL;
	local[2]= fqv[407];
	local[3]= env->c.clo.env2[1];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,4,local+1); /*format*/
	local[1]= w;
	local[2]= fqv[408];
	local[3]= fqv[11];
	local[4]= fqv[159];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[130];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= argv[1];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)irtcollaF5001mesh_object__collada_mesh(ctx,2,local+4); /*mesh-object->collada-mesh*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*mesh->collada-indices*/
static pointer irtcollaF5003mesh__collada_indices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[61];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[19])(ctx,0,local+1,&ftab[19],fqv[188]); /*make-string-output-stream*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= local[1];
	local[5]= fqv[409];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,2,local+4); /*format*/
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
irtcollaWHL5232:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto irtcollaWHX5233;
	local[6]= local[0];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= local[6];
	local[8]= fqv[410];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.cdr;
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[7];
irtcollaWHL5235:
	local[10]= local[8];
	w = local[9];
	if ((eusinteger_t)local[10] >= (eusinteger_t)w) goto irtcollaWHX5236;
	local[10]= local[1];
	local[11]= fqv[411];
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,3,local+10); /*format*/
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[2] = w;
	local[10]= local[1];
	local[11]= fqv[412];
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,3,local+10); /*format*/
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	goto irtcollaWHL5235;
irtcollaWHX5236:
	local[10]= NIL;
irtcollaBLK5237:
	w = NIL;
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[3] = w;
	w = local[3];
	local[7]= local[1];
	local[8]= fqv[413];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,2,local+7); /*format*/
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto irtcollaWHL5232;
irtcollaWHX5233:
	local[6]= NIL;
irtcollaBLK5234:
	w = NIL;
	local[4]= local[1];
	local[5]= fqv[414];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,2,local+4); /*format*/
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(*ftab[20])(ctx,1,local+4,&ftab[20],fqv[191]); /*get-output-stream-string*/
	local[0]= w;
irtcollaBLK5231:
	ctx->vsp=local; return(local[0]);}

/*mesh-vertices->collada-string*/
static pointer irtcollaF5004mesh_vertices__collada_string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[61];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[19])(ctx,0,local+1,&ftab[19],fqv[188]); /*make-string-output-stream*/
	local[1]= w;
	local[2]= NIL;
	local[3]= local[0];
irtcollaWHL5239:
	if (local[3]==NIL) goto irtcollaWHX5240;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= local[2];
	local[5]= fqv[410];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	local[5]= NIL;
	local[6]= local[4];
irtcollaWHL5242:
	if (local[6]==NIL) goto irtcollaWHX5243;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)3L);
irtcollaWHL5245:
	local[9]= local[7];
	w = local[8];
	if ((eusinteger_t)local[9] >= (eusinteger_t)w) goto irtcollaWHX5246;
	local[9]= local[1];
	local[10]= fqv[415];
	local[11]= local[5];
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)XFORMAT(ctx,3,local+9); /*format*/
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[7] = w;
	goto irtcollaWHL5245;
irtcollaWHX5246:
	local[9]= NIL;
irtcollaBLK5247:
	w = NIL;
	local[7]= local[1];
	local[8]= fqv[416];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,2,local+7); /*format*/
	goto irtcollaWHL5242;
irtcollaWHX5243:
	local[7]= NIL;
irtcollaBLK5244:
	w = NIL;
	goto irtcollaWHL5239;
irtcollaWHX5240:
	local[4]= NIL;
irtcollaBLK5241:
	w = NIL;
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(*ftab[20])(ctx,1,local+2,&ftab[20],fqv[191]); /*get-output-stream-string*/
	local[0]= w;
irtcollaBLK5238:
	ctx->vsp=local; return(local[0]);}

/*mesh-normals->collada-string*/
static pointer irtcollaF5005mesh_normals__collada_string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[61];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[19])(ctx,0,local+1,&ftab[19],fqv[188]); /*make-string-output-stream*/
	local[1]= w;
	local[2]= NIL;
	local[3]= local[0];
irtcollaWHL5249:
	if (local[3]==NIL) goto irtcollaWHX5250;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= local[2];
	local[5]= fqv[417];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)3L);
irtcollaWHL5252:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto irtcollaWHX5253;
	local[7]= local[1];
	local[8]= fqv[418];
	local[9]= local[4];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)XFORMAT(ctx,3,local+7); /*format*/
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto irtcollaWHL5252;
irtcollaWHX5253:
	local[7]= NIL;
irtcollaBLK5254:
	w = NIL;
	local[5]= local[1];
	local[6]= fqv[419];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,2,local+5); /*format*/
	goto irtcollaWHL5249;
irtcollaWHX5250:
	local[4]= NIL;
irtcollaBLK5251:
	w = NIL;
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(*ftab[20])(ctx,1,local+2,&ftab[20],fqv[191]); /*get-output-stream-string*/
	local[0]= w;
irtcollaBLK5248:
	ctx->vsp=local; return(local[0]);}

/*float-vector->collada-string*/
static pointer irtcollaF5006float_vector__collada_string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	w=(*ftab[19])(ctx,0,local+0,&ftab[19],fqv[188]); /*make-string-output-stream*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
irtcollaWHL5256:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto irtcollaWHX5257;
	local[3]= local[0];
	local[4]= fqv[420];
	local[5]= argv[0];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,3,local+3); /*format*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto irtcollaWHL5256;
irtcollaWHX5257:
	local[3]= NIL;
irtcollaBLK5258:
	w = NIL;
	local[1]= local[0];
	local[2]= fqv[421];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,2,local+1); /*format*/
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(*ftab[20])(ctx,1,local+1,&ftab[20],fqv[191]); /*get-output-stream-string*/
	local[0]= w;
irtcollaBLK5255:
	ctx->vsp=local; return(local[0]);}

/*enum-integer-list*/
static pointer irtcollaF5007enum_integer_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0];
irtcollaWHL5260:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto irtcollaWHX5261;
	local[3]= local[1];
	w = local[0];
	ctx->vsp=local+4;
	local[0] = cons(ctx,local[3],w);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto irtcollaWHL5260;
irtcollaWHX5261:
	local[3]= NIL;
irtcollaBLK5262:
	w = NIL;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)REVERSE(ctx,1,local+1); /*reverse*/
	local[0]= w;
irtcollaBLK5259:
	ctx->vsp=local; return(local[0]);}

/*search-minimum-rotation-matrix*/
static pointer irtcollaF5008search_minimum_rotation_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(*ftab[30])(ctx,2,local+0,&ftab[30],fqv[422]); /*matrix-column*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(*ftab[30])(ctx,2,local+1,&ftab[30],fqv[422]); /*matrix-column*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(*ftab[30])(ctx,2,local+2,&ftab[30],fqv[422]); /*matrix-column*/
	local[2]= w;
	local[3]= local[0];
	local[4]= local[1];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,3,local+3); /*list*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)1L);
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,3,local+4); /*float-vector*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)1L);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,3,local+6); /*float-vector*/
	local[6]= w;
	local[7]= local[4];
	local[8]= local[5];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,3,local+7); /*list*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)-2L);
	local[9]= NIL;
	local[10]= NIL;
	local[11]= local[3];
irtcollaWHL5264:
	if (local[11]==NIL) goto irtcollaWHX5265;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11] = (w)->c.cons.cdr;
	w = local[12];
	local[10] = w;
	local[12]= NIL;
	local[13]= local[7];
irtcollaWHL5267:
	if (local[13]==NIL) goto irtcollaWHX5268;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13] = (w)->c.cons.cdr;
	w = local[14];
	local[12] = w;
	local[14]= local[10];
	local[15]= local[12];
	ctx->vsp=local+16;
	w=(pointer)VINNERPRODUCT(ctx,2,local+14); /*v.*/
	local[14]= makeflt((double)fabs(fltval(w)));
	local[15]= local[14];
	local[16]= local[8];
	ctx->vsp=local+17;
	w=(pointer)GREATERP(ctx,2,local+15); /*>*/
	if (w==NIL) goto irtcollaIF5270;
	local[8] = local[14];
	local[15]= local[10];
	w = local[12];
	ctx->vsp=local+16;
	local[9] = cons(ctx,local[15],w);
	local[15]= local[9];
	goto irtcollaIF5271;
irtcollaIF5270:
	local[15]= NIL;
irtcollaIF5271:
	w = local[15];
	goto irtcollaWHL5267;
irtcollaWHX5268:
	local[14]= NIL;
irtcollaBLK5269:
	w = NIL;
	goto irtcollaWHL5264;
irtcollaWHX5265:
	local[12]= NIL;
irtcollaBLK5266:
	w = NIL;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.cdr;
	if (local[4]!=local[10]) goto irtcollaCON5273;
	local[10]= (pointer)get_sym_func(fqv[423]);
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.cdr;
	ctx->vsp=local+13;
	w=(pointer)VINNERPRODUCT(ctx,2,local+11); /*v.*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(pointer)GREATERP(ctx,2,local+11); /*>*/
	if (w==NIL) goto irtcollaIF5274;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	goto irtcollaIF5275;
irtcollaIF5274:
	local[11]= makeflt(-1.0000000000000000000000e+00);
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	ctx->vsp=local+13;
	w=(pointer)SCALEVEC(ctx,2,local+11); /*scale*/
	local[11]= w;
irtcollaIF5275:
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= local[3];
	ctx->vsp=local+14;
	w=(*ftab[31])(ctx,2,local+12,&ftab[31],fqv[424]); /*remove*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)APPLY(ctx,3,local+10); /*apply*/
	local[10]= w;
	local[11]= local[10];
	ctx->vsp=local+12;
	w=(*ftab[32])(ctx,1,local+11,&ftab[32],fqv[425]); /*user::matrix-determinant*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(pointer)LESSP(ctx,2,local+11); /*<*/
	if (w==NIL) goto irtcollaIF5276;
	local[11]= (pointer)get_sym_func(fqv[423]);
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.cdr;
	ctx->vsp=local+14;
	w=(pointer)VINNERPRODUCT(ctx,2,local+12); /*v.*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)GREATERP(ctx,2,local+12); /*>*/
	if (w==NIL) goto irtcollaIF5278;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	goto irtcollaIF5279;
irtcollaIF5278:
	local[12]= makeflt(-1.0000000000000000000000e+00);
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	ctx->vsp=local+14;
	w=(pointer)SCALEVEC(ctx,2,local+12); /*scale*/
	local[12]= w;
irtcollaIF5279:
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(*ftab[31])(ctx,2,local+13,&ftab[31],fqv[424]); /*remove*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)REVERSE(ctx,1,local+13); /*reverse*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)APPLY(ctx,3,local+11); /*apply*/
	local[11]= w;
	goto irtcollaIF5277;
irtcollaIF5276:
	local[11]= local[10];
irtcollaIF5277:
	w = local[11];
	local[10]= w;
	goto irtcollaCON5272;
irtcollaCON5273:
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.cdr;
	if (local[5]!=local[10]) goto irtcollaCON5280;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(*ftab[31])(ctx,2,local+10,&ftab[31],fqv[424]); /*remove*/
	local[10]= w;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.cdr;
	ctx->vsp=local+14;
	w=(pointer)VINNERPRODUCT(ctx,2,local+12); /*v.*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)GREATERP(ctx,2,local+12); /*>*/
	if (w==NIL) goto irtcollaIF5281;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	goto irtcollaIF5282;
irtcollaIF5281:
	local[12]= makeflt(-1.0000000000000000000000e+00);
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	ctx->vsp=local+14;
	w=(pointer)SCALEVEC(ctx,2,local+12); /*scale*/
	local[12]= w;
irtcollaIF5282:
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	ctx->vsp=local+14;
	w=(*ftab[33])(ctx,3,local+11,&ftab[33],fqv[423]); /*matrix*/
	local[11]= w;
	local[12]= local[11];
	ctx->vsp=local+13;
	w=(*ftab[32])(ctx,1,local+12,&ftab[32],fqv[425]); /*user::matrix-determinant*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)LESSP(ctx,2,local+12); /*<*/
	if (w==NIL) goto irtcollaIF5283;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.cdr;
	ctx->vsp=local+15;
	w=(pointer)VINNERPRODUCT(ctx,2,local+13); /*v.*/
	local[13]= w;
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(pointer)GREATERP(ctx,2,local+13); /*>*/
	if (w==NIL) goto irtcollaIF5285;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	goto irtcollaIF5286;
irtcollaIF5285:
	local[13]= makeflt(-1.0000000000000000000000e+00);
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	ctx->vsp=local+15;
	w=(pointer)SCALEVEC(ctx,2,local+13); /*scale*/
	local[13]= w;
irtcollaIF5286:
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	ctx->vsp=local+15;
	w=(*ftab[33])(ctx,3,local+12,&ftab[33],fqv[423]); /*matrix*/
	local[12]= w;
	goto irtcollaIF5284;
irtcollaIF5283:
	local[12]= local[11];
irtcollaIF5284:
	w = local[12];
	local[10]= w;
	goto irtcollaCON5272;
irtcollaCON5280:
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(*ftab[31])(ctx,2,local+10,&ftab[31],fqv[424]); /*remove*/
	local[10]= w;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.cdr;
	ctx->vsp=local+15;
	w=(pointer)VINNERPRODUCT(ctx,2,local+13); /*v.*/
	local[13]= w;
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(pointer)GREATERP(ctx,2,local+13); /*>*/
	if (w==NIL) goto irtcollaIF5288;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	goto irtcollaIF5289;
irtcollaIF5288:
	local[13]= makeflt(-1.0000000000000000000000e+00);
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	ctx->vsp=local+15;
	w=(pointer)SCALEVEC(ctx,2,local+13); /*scale*/
	local[13]= w;
irtcollaIF5289:
	ctx->vsp=local+14;
	w=(*ftab[33])(ctx,3,local+11,&ftab[33],fqv[423]); /*matrix*/
	local[11]= w;
	local[12]= local[11];
	ctx->vsp=local+13;
	w=(*ftab[32])(ctx,1,local+12,&ftab[32],fqv[425]); /*user::matrix-determinant*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)LESSP(ctx,2,local+12); /*<*/
	if (w==NIL) goto irtcollaIF5290;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.cdr;
	ctx->vsp=local+16;
	w=(pointer)VINNERPRODUCT(ctx,2,local+14); /*v.*/
	local[14]= w;
	local[15]= makeint((eusinteger_t)0L);
	ctx->vsp=local+16;
	w=(pointer)GREATERP(ctx,2,local+14); /*>*/
	if (w==NIL) goto irtcollaIF5292;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	goto irtcollaIF5293;
irtcollaIF5292:
	local[14]= makeflt(-1.0000000000000000000000e+00);
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	ctx->vsp=local+16;
	w=(pointer)SCALEVEC(ctx,2,local+14); /*scale*/
	local[14]= w;
irtcollaIF5293:
	ctx->vsp=local+15;
	w=(*ftab[33])(ctx,3,local+12,&ftab[33],fqv[423]); /*matrix*/
	local[12]= w;
	goto irtcollaIF5291;
irtcollaIF5290:
	local[12]= NIL;
irtcollaIF5291:
	w = local[12];
	local[10]= w;
	goto irtcollaCON5272;
irtcollaCON5287:
	local[10]= NIL;
irtcollaCON5272:
	ctx->vsp=local+11;
	w=(pointer)TRANSPOSE(ctx,1,local+10); /*transpose*/
	local[0]= w;
irtcollaBLK5263:
	ctx->vsp=local; return(local[0]);}

/*estimate-class-name*/
static pointer irtcollaF5009estimate_class_name(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[34])(ctx,1,local+0,&ftab[34],fqv[426]); /*pathname*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[35])(ctx,1,local+0,&ftab[35],fqv[427]); /*pathname-name*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[36])(ctx,1,local+0,&ftab[36],fqv[428]); /*string-upcase*/
	local[0]= w;
irtcollaBLK5294:
	ctx->vsp=local; return(local[0]);}

/*remove-directory-name*/
static pointer irtcollaF5010remove_directory_name(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[34])(ctx,1,local+0,&ftab[34],fqv[426]); /*pathname*/
	local[0]= w;
	local[1]= NIL;
	local[2]= fqv[429];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(*ftab[35])(ctx,1,local+3,&ftab[35],fqv[427]); /*pathname-name*/
	local[3]= w;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[37])(ctx,1,local+4,&ftab[37],fqv[430]); /*pathname-type*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,4,local+1); /*format*/
	local[0]= w;
irtcollaBLK5295:
	ctx->vsp=local; return(local[0]);}

/*convert-irtmodel-to-collada*/
static pointer irtcollaF5011convert_irtmodel_to_collada(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto irtcollaENT5300;}
	local[0]= fqv[431];
	ctx->vsp=local+1;
	w=(*ftab[38])(ctx,1,local+0,&ftab[38],fqv[432]); /*truename*/
	local[0]= w;
	local[1]= fqv[433];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
irtcollaENT5300:
	if (n>=3) { local[1]=(argv[2]); goto irtcollaENT5299;}
	local[1]= NIL;
irtcollaENT5299:
	if (n>=4) { local[2]=(argv[3]); goto irtcollaENT5298;}
	local[2]= T;
irtcollaENT5298:
irtcollaENT5297:
	if (n>4) maerror();
	local[3]= T;
	local[4]= fqv[434];
	local[5]= argv[0];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,4,local+3); /*format*/
	local[3]= T;
	local[4]= fqv[435];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,3,local+3); /*format*/
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[39])(ctx,1,local+3,&ftab[39],fqv[436]); /*load*/
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)irtcollaF5010remove_directory_name(ctx,1,local+3); /*remove-directory-name*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)irtcollaF5009estimate_class_name(ctx,1,local+3); /*estimate-class-name*/
	local[3]= w;
	local[4]= local[3];
	ctx->vsp=local+5;
	w=(pointer)INTERN(ctx,1,local+4); /*intern*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)EVAL(ctx,1,local+4); /*eval*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)INSTANTIATE(ctx,1,local+4); /*instantiate*/
	local[4]= w;
	local[5]= local[4];
	local[6]= fqv[60];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	w = local[4];
	local[4]= w;
	if (local[1]==NIL) goto irtcollaIF5301;
	local[5]= local[4];
	local[6]= fqv[34];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	goto irtcollaIF5302;
irtcollaIF5301:
	local[5]= NIL;
irtcollaIF5302:
	local[5]= local[4];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)irtcollaF4958eus2collada(ctx,2,local+5); /*eus2collada*/
	if (local[2]==NIL) goto irtcollaIF5303;
	ctx->vsp=local+3;
	w=(*ftab[40])(ctx,0,local+3,&ftab[40],fqv[437]); /*exit*/
	local[3]= w;
	goto irtcollaIF5304;
irtcollaIF5303:
	local[3]= NIL;
irtcollaIF5304:
	w = local[3];
	local[0]= w;
irtcollaBLK5296:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___irtcollada(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[438];
	ctx->vsp=local+1;
	w=(*ftab[41])(ctx,1,local+0,&ftab[41],fqv[439]); /*require*/
	local[0]= fqv[440];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w!=NIL) goto irtcollaIF5305;
	local[0]= fqv[441];
	ctx->vsp=local+1;
	w=(*ftab[42])(ctx,1,local+0,&ftab[42],fqv[442]); /*make-package*/
	local[0]= w;
	goto irtcollaIF5306;
irtcollaIF5305:
	local[0]= NIL;
irtcollaIF5306:
	local[0]= fqv[443];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtcollaIF5307;
	local[0]= fqv[444];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[445],w);
	goto irtcollaIF5308;
irtcollaIF5307:
	local[0]= fqv[446];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtcollaIF5308:
	local[0]= fqv[0];
	local[1]= fqv[447];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto irtcollaIF5309;
	local[0]= fqv[0];
	local[1]= fqv[447];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[0];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto irtcollaIF5311;
	local[0]= fqv[0];
	local[1]= fqv[448];
	local[2]= fqv[449];
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto irtcollaIF5312;
irtcollaIF5311:
	local[0]= NIL;
irtcollaIF5312:
	local[0]= fqv[0];
	goto irtcollaIF5310;
irtcollaIF5309:
	local[0]= NIL;
irtcollaIF5310:
	ctx->vsp=local+0;
	compfun(ctx,fqv[450],module,irtcollaF4934symbol__string,fqv[451]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[452],module,irtcollaF4935__string,fqv[453]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[454],module,irtcollaF4936string_append,fqv[455]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[456],module,irtcollaF4937make_attr,fqv[457]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[458],module,irtcollaF4938make_xml,fqv[459]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[460],module,irtcollaF4939sxml__xml,fqv[461]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[462],module,irtcollaF4940xml_output_to_string_stream,fqv[463]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[464],module,irtcollaF4941cat_normal,fqv[465]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[466],module,irtcollaF4942cat_clark,fqv[467]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[468],module,irtcollaF4943eusmodel_description,fqv[469]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[470],module,irtcollaF4944verificate_unique_strings,fqv[471]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[472],module,irtcollaF4945eusmodel_link_specs,fqv[473]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[474],module,irtcollaF4946eusmodel_joint_specs,fqv[475]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[41],module,irtcollaF4947eusmodel_link_spec,fqv[476]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[477],module,irtcollaF4948eusmodel_mesh_spec,fqv[478]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[42],module,irtcollaF4949eusmodel_joint_spec,fqv[479]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[480],module,irtcollaF4950eusmodel_limit_spec,fqv[481]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[482],module,irtcollaF4951eusmodel_endcoords_specs,fqv[483]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[484],module,irtcollaF4952eusmodel_link_description,fqv[485]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[486],module,irtcollaF4953eusmodel_joint_description,fqv[487]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[488],module,irtcollaF4954eusmodel_endcoords_description,fqv[489]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[490],module,irtcollaF4955eusmodel_description__collada,fqv[491]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[492],module,irtcollaF4956setup_collada_filesystem,fqv[493]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[494],module,irtcollaF4957range2,fqv[495]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[496],module,irtcollaF4958eus2collada,fqv[497]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[498],module,irtcollaF4959collada_node_id,fqv[499]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[500],module,irtcollaF4960collada_node_name,fqv[501]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[502],module,irtcollaF4961links_description__collada_library_materials,fqv[503]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[161],module,irtcollaF4962link_description__collada_materials,fqv[504]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[505],module,irtcollaF4963mesh_description__collada_material,fqv[506]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[507],module,irtcollaF4964links_description__collada_library_effects,fqv[508]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[172],module,irtcollaF4965link_description__collada_effects,fqv[509]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[510],module,irtcollaF4966mesh_description__collada_effect,fqv[511]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[512],module,irtcollaF4967matrix__collada_string,fqv[513]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[514],module,irtcollaF4968find_parent_liks_from_link_description,fqv[515]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[516],module,irtcollaF4969eusmodel_description__collada_node_transformations,fqv[517]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[518],module,irtcollaF4970eusmodel_description__collada_node,fqv[519]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[520],module,irtcollaF4971eusmodel_description__collada_library_visual_scenes,fqv[521]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[522],module,irtcollaF4972mesh_description__instance_material,fqv[523]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[524],module,irtcollaF4973link_description__collada_bind_material,fqv[525]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[526],module,irtcollaF4974eusmodel_description__collada_library_kinematics_scenes,fqv[527]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[528],module,irtcollaF4975eusmodel_description__collada_library_kinematics_models,fqv[529]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[530],module,irtcollaF4976eusmodel_description__collada_kinematics_model,fqv[531]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[532],module,irtcollaF4977eusmodel_description__collada_library_physics_scenes,fqv[533]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[534],module,irtcollaF4978eusmodel_description__collada_library_physics_models,fqv[535]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[536],module,irtcollaF4979find_root_link_from_joints_description,fqv[537]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[538],module,irtcollaF4980find_link_from_links_description,fqv[539]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[540],module,irtcollaF4981eusmodel_description__collada_links,fqv[541]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[542],module,irtcollaF4982find_joint_from_link_description,fqv[543]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[544],module,irtcollaF4983find_child_link_descriptions,fqv[545]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[546],module,irtcollaF4984matrix__collada_rotate_vector,fqv[547]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[548],module,irtcollaF4985eusmodel_description__collada_library_articulated_systems,fqv[549]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[550],module,irtcollaF4986eusmodel_endcoords_description__openrave_manipulator,fqv[551]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[552],module,irtcollaF4987eusmodel_description__collada_links_tree,fqv[553]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[554],module,irtcollaF4988joints_description__collada_instance_joints,fqv[555]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[323],module,irtcollaF4989joint_description__collada_instance_joint,fqv[556]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[557],module,irtcollaF4990eusmodel_description__collada_library_joints,fqv[558]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[559],module,irtcollaF4991joints_description__collada_joints,fqv[560]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[561],module,irtcollaF4992collada_joint_id,fqv[562]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[328],module,irtcollaF4993joint_description__collada_joint,fqv[563]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[564],module,irtcollaF4994linear_joint_description__collada_joint,fqv[565]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[566],module,irtcollaF4995rotational_joint_description__collada_joint,fqv[567]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[568],module,irtcollaF4996eusmodel_description__collada_scene,fqv[569]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[570],module,irtcollaF4997eusmodel_description__collada_library_geometries,fqv[571]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[572],module,irtcollaF4998collada_geometry_id_base,fqv[573]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[574],module,irtcollaF4999collada_geometry_name_base,fqv[575]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[576],module,irtcollaF5000links_description__collada_geometries,fqv[577]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[578],module,irtcollaF5001mesh_object__collada_mesh,fqv[579]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[364],module,irtcollaF5002link_description__collada_geometry,fqv[580]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[581],module,irtcollaF5003mesh__collada_indices,fqv[582]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[583],module,irtcollaF5004mesh_vertices__collada_string,fqv[584]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[585],module,irtcollaF5005mesh_normals__collada_string,fqv[586]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[587],module,irtcollaF5006float_vector__collada_string,fqv[588]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[589],module,irtcollaF5007enum_integer_list,fqv[590]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[591],module,irtcollaF5008search_minimum_rotation_matrix,fqv[592]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[593],module,irtcollaF5009estimate_class_name,fqv[594]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[595],module,irtcollaF5010remove_directory_name,fqv[596]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[597],module,irtcollaF5011convert_irtmodel_to_collada,fqv[598]);
	local[0]= fqv[599];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtcollaIF5313;
	local[0]= fqv[600];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[445],w);
	goto irtcollaIF5314;
irtcollaIF5313:
	local[0]= fqv[601];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtcollaIF5314:
	local[0]= fqv[602];
	ctx->vsp=local+1;
	w=(*ftab[43])(ctx,1,local+0,&ftab[43],fqv[603]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<44; i++) ftab[i]=fcallx;
}
