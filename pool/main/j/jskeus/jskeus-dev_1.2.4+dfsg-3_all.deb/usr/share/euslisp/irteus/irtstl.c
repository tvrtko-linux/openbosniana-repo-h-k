/* ./irtstl.c :  entry=irtstl */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "irtstl.h"
#pragma init (register_irtstl)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___irtstl();
extern pointer build_quote_vector();
static int register_irtstl()
  { add_module_initializer("___irtstl", ___irtstl);}

static pointer irtstlF5315stl2eus();
static pointer irtstlF5316write_stl_header();
static pointer irtstlF5317write_stl_binary_float_val();
static pointer irtstlF5318write_stl_face();
static pointer irtstlF5319eus2stl();
static pointer irtstlF5320read_files_from_solidedge();
static pointer irtstlF5321read_assembly_config();
static pointer irtstlF5322stl_make_faces();
static pointer irtstlF5323safe_vmax();
static pointer irtstlF5324safe_vmin();
static pointer irtstlF5325safe_vmaxmin();
static pointer irtstlF5326devide_faces();
static pointer irtstlF5327make_boundingbox_from_faces();
static pointer irtstlF5328small_square_axis();
static pointer irtstlF5329make_devided_faces_lists();
static pointer irtstlF5330make_faceset_from_faces();
static pointer irtstlF5331stl2eus_large();

/*stl2eus*/
static pointer irtstlF5315stl2eus(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[0], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto irtstlKEY5333;
	local[0] = NIL;
irtstlKEY5333:
	if (n & (1<<1)) goto irtstlKEY5334;
	local[1] = fqv[1];
irtstlKEY5334:
	if (n & (1<<2)) goto irtstlKEY5335;
	local[2] = NIL;
irtstlKEY5335:
	if (n & (1<<3)) goto irtstlKEY5336;
	local[3] = makeint((eusinteger_t)1000L);
irtstlKEY5336:
	if (n & (1<<4)) goto irtstlKEY5337;
	local[4] = fqv[2];
irtstlKEY5337:
	if (n & (1<<5)) goto irtstlKEY5338;
	local[5] = T;
irtstlKEY5338:
	if (n & (1<<6)) goto irtstlKEY5339;
	local[6] = NIL;
irtstlKEY5339:
	if (n & (1<<7)) goto irtstlKEY5340;
	local[7] = fqv[3];
irtstlKEY5340:
	local[8]= makeint((eusinteger_t)80L);
	ctx->vsp=local+9;
	w=(*ftab[0])(ctx,1,local+8,&ftab[0],fqv[4]); /*make-string*/
	local[8]= w;
	local[9]= NIL;
	local[10]= NIL;
	local[11]= NIL;
	local[12]= NIL;
	local[13]= NIL;
	local[14]= NIL;
	local[15]= NIL;
	local[16]= NIL;
	local[17]= NIL;
	local[18]= NIL;
	local[19]= NIL;
	local[20]= NIL;
	local[21]= NIL;
	local[22]= fqv[5];
	local[23]= (pointer)get_sym_func(fqv[6]);
	ctx->vsp=local+24;
	w=(*ftab[1])(ctx,2,local+22,&ftab[1],fqv[7]); /*make-hash-table*/
	local[15] = w;
	local[22]= fqv[5];
	local[23]= (pointer)get_sym_func(fqv[6]);
	ctx->vsp=local+24;
	w=(*ftab[1])(ctx,2,local+22,&ftab[1],fqv[7]); /*make-hash-table*/
	local[16] = w;
	local[22]= fqv[5];
	local[23]= (pointer)get_sym_func(fqv[6]);
	ctx->vsp=local+24;
	w=(*ftab[1])(ctx,2,local+22,&ftab[1],fqv[7]); /*make-hash-table*/
	local[17] = w;
	local[22]= argv[0];
	ctx->vsp=local+23;
	w=(*ftab[2])(ctx,1,local+22,&ftab[2],fqv[8]); /*open*/
	local[22]= w;
	ctx->vsp=local+23;
	w = makeclosure(codevec,quotevec,irtstlUWP5341,env,argv,local);
	local[23]=(pointer)(ctx->protfp); local[24]=w;
	ctx->protfp=(struct protectframe *)(local+23);
	local[25]= local[22];
	local[26]= fqv[9];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,2,local+25); /*send*/
	local[10] = w;
	local[25]= local[10];
	local[26]= local[8];
	local[27]= makeint((eusinteger_t)80L);
	ctx->vsp=local+28;
	w=(pointer)UNIXREAD(ctx,3,local+25); /*unix:uread*/
	local[25]= local[10];
	local[26]= local[8];
	local[27]= makeint((eusinteger_t)4L);
	ctx->vsp=local+28;
	w=(pointer)UNIXREAD(ctx,3,local+25); /*unix:uread*/
	local[25]= local[8];
	local[26]= makeint((eusinteger_t)0L);
	local[27]= fqv[10];
	ctx->vsp=local+28;
	w=(pointer)PEEK(ctx,3,local+25); /*system:peek*/
	local[11] = w;
	local[25]= makeint((eusinteger_t)0L);
	local[26]= local[11];
irtstlWHL5342:
	local[27]= local[25];
	w = local[26];
	if ((eusinteger_t)local[27] >= (eusinteger_t)w) goto irtstlWHX5343;
	local[18] = NIL;
	local[27]= makeint((eusinteger_t)0L);
	local[28]= makeint((eusinteger_t)4L);
irtstlWHL5345:
	local[29]= local[27];
	w = local[28];
	if ((eusinteger_t)local[29] >= (eusinteger_t)w) goto irtstlWHX5346;
	local[29]= local[10];
	local[30]= local[8];
	local[31]= makeint((eusinteger_t)12L);
	ctx->vsp=local+32;
	w=(pointer)UNIXREAD(ctx,3,local+29); /*unix:uread*/
	local[29]= local[8];
	local[30]= makeint((eusinteger_t)0L);
	local[31]= fqv[11];
	ctx->vsp=local+32;
	w=(pointer)PEEK(ctx,3,local+29); /*system:peek*/
	local[29]= w;
	local[30]= local[8];
	local[31]= makeint((eusinteger_t)4L);
	local[32]= fqv[11];
	ctx->vsp=local+33;
	w=(pointer)PEEK(ctx,3,local+30); /*system:peek*/
	local[30]= w;
	local[31]= local[8];
	local[32]= makeint((eusinteger_t)8L);
	local[33]= fqv[11];
	ctx->vsp=local+34;
	w=(pointer)PEEK(ctx,3,local+31); /*system:peek*/
	local[31]= w;
	ctx->vsp=local+32;
	w=(pointer)MKFLTVEC(ctx,3,local+29); /*float-vector*/
	local[29]= w;
	w = local[18];
	ctx->vsp=local+30;
	local[18] = cons(ctx,local[29],w);
	local[29]= local[27];
	ctx->vsp=local+30;
	w=(pointer)ADD1(ctx,1,local+29); /*1+*/
	local[27] = w;
	goto irtstlWHL5345;
irtstlWHX5346:
	local[29]= NIL;
irtstlBLK5347:
	w = NIL;
	local[27]= local[10];
	local[28]= local[8];
	local[29]= makeint((eusinteger_t)2L);
	ctx->vsp=local+30;
	w=(pointer)UNIXREAD(ctx,3,local+27); /*unix:uread*/
	local[27]= local[18];
	ctx->vsp=local+28;
	w=(pointer)NREVERSE(ctx,1,local+27); /*nreverse*/
	ctx->vsp=local+27;
	local[27]= makeclosure(codevec,quotevec,irtstlCLO5348,env,argv,local);
	w=local[18];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[28]= (w)->c.cons.cdr;
	ctx->vsp=local+29;
	w=(pointer)MAPCAR(ctx,2,local+27); /*mapcar*/
	local[19] = w;
	if (local[6]!=NIL) goto irtstlOR5351;
	if (local[5]!=NIL) goto irtstlOR5351;
	local[27]= local[7];
	w = fqv[12];
	if (memq(local[27],w)!=NIL) goto irtstlOR5351;
	goto irtstlIF5349;
irtstlOR5351:
	local[27]= makeint((eusinteger_t)0L);
	local[28]= local[19];
	ctx->vsp=local+29;
	w=(pointer)LENGTH(ctx,1,local+28); /*length*/
	local[28]= w;
irtstlWHL5352:
	local[29]= local[27];
	w = local[28];
	if ((eusinteger_t)local[29] >= (eusinteger_t)w) goto irtstlWHX5353;
	local[29]= local[19];
	local[30]= local[27];
	ctx->vsp=local+31;
	w=(pointer)ELT(ctx,2,local+29); /*elt*/
	local[29]= w;
	local[30]= local[17];
	ctx->vsp=local+31;
	w=(*ftab[3])(ctx,2,local+29,&ftab[3],fqv[13]); /*gethash*/
	if (w==NIL) goto irtstlIF5355;
	local[29]= local[19];
	local[30]= local[27];
	local[31]= local[19];
	local[32]= local[27];
	ctx->vsp=local+33;
	w=(pointer)ELT(ctx,2,local+31); /*elt*/
	local[31]= w;
	local[32]= local[17];
	ctx->vsp=local+33;
	w=(*ftab[3])(ctx,2,local+31,&ftab[3],fqv[13]); /*gethash*/
	local[31]= w;
	ctx->vsp=local+32;
	w=(pointer)SETELT(ctx,3,local+29); /*setelt*/
	local[29]= w;
	goto irtstlIF5356;
irtstlIF5355:
	local[29]= NIL;
irtstlIF5356:
	local[29]= local[19];
	local[30]= local[27];
	ctx->vsp=local+31;
	w=(pointer)ELT(ctx,2,local+29); /*elt*/
	local[29]= w;
	local[30]= local[17];
	local[31]= local[19];
	local[32]= local[27];
	ctx->vsp=local+33;
	w=(pointer)ELT(ctx,2,local+31); /*elt*/
	local[31]= w;
	ctx->vsp=local+32;
	w=(*ftab[4])(ctx,3,local+29,&ftab[4],fqv[14]); /*sethash*/
	local[29]= local[27];
	ctx->vsp=local+30;
	w=(pointer)ADD1(ctx,1,local+29); /*1+*/
	local[27] = w;
	goto irtstlWHL5352;
irtstlWHX5353:
	local[29]= NIL;
irtstlBLK5354:
	w = NIL;
	local[27]= w;
	goto irtstlIF5350;
irtstlIF5349:
	local[27]= NIL;
irtstlIF5350:
	w=local[18];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[27]= (w)->c.cons.car;
	w = local[14];
	ctx->vsp=local+28;
	local[14] = cons(ctx,local[27],w);
	if (local[6]==NIL) goto irtstlIF5357;
	ctx->vsp=local+27;
	local[27]= makeclosure(codevec,quotevec,irtstlCLO5359,env,argv,local);
	local[28]= local[19];
	ctx->vsp=local+29;
	w=(pointer)MAPCAR(ctx,2,local+27); /*mapcar*/
	local[27]= w;
	goto irtstlIF5358;
irtstlIF5357:
	local[27]= NIL;
irtstlIF5358:
	local[27]= loadglobal(fqv[15]);
	ctx->vsp=local+28;
	w=(pointer)INSTANTIATE(ctx,1,local+27); /*instantiate*/
	local[27]= w;
	local[28]= local[27];
	local[29]= fqv[16];
	local[30]= fqv[17];
	local[31]= local[19];
	ctx->vsp=local+32;
	w=(pointer)SEND(ctx,4,local+28); /*send*/
	w = local[27];
	local[20] = w;
	local[27]= local[20];
	w = local[12];
	ctx->vsp=local+28;
	local[12] = cons(ctx,local[27],w);
	if (local[5]==NIL) goto irtstlIF5360;
	local[27]= NIL;
	local[28]= NIL;
	local[29]= NIL;
	local[30]= local[20];
	local[31]= fqv[18];
	ctx->vsp=local+32;
	w=(pointer)SEND(ctx,2,local+30); /*send*/
	local[30]= w;
irtstlWHL5362:
	if (local[30]==NIL) goto irtstlWHX5363;
	w=local[30];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[31]= (w)->c.cons.car;
	w=local[30];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[30] = (w)->c.cons.cdr;
	w = local[31];
	local[29] = w;
	local[31]= *(ovafptr(local[29],fqv[19]));
	w = *(ovafptr(local[29],fqv[20]));
	ctx->vsp=local+32;
	local[31]= cons(ctx,local[31],w);
	local[32]= local[16];
	ctx->vsp=local+33;
	w=(*ftab[3])(ctx,2,local+31,&ftab[3],fqv[13]); /*gethash*/
	local[27] = w;
	if (local[27]==NIL) goto irtstlIF5365;
	local[31]= local[29];
	local[32]= local[27];
	local[33]= fqv[18];
	ctx->vsp=local+34;
	w=(pointer)SEND(ctx,2,local+32); /*send*/
	local[32]= w;
	local[33]= fqv[5];
	ctx->vsp=local+34;
	local[34]= makeclosure(codevec,quotevec,irtstlCLO5367,env,argv,local);
	ctx->vsp=local+35;
	w=(*ftab[5])(ctx,4,local+31,&ftab[5],fqv[21]); /*find*/
	local[28] = w;
	local[31]= local[20];
	local[32]= fqv[18];
	ctx->vsp=local+33;
	w=(pointer)SEND(ctx,2,local+31); /*send*/
	local[31]= w;
	local[32]= local[29];
	local[33]= local[20];
	local[34]= fqv[18];
	ctx->vsp=local+35;
	w=(pointer)SEND(ctx,2,local+33); /*send*/
	local[33]= w;
	ctx->vsp=local+34;
	w=(*ftab[6])(ctx,2,local+32,&ftab[6],fqv[22]); /*position*/
	local[32]= w;
	local[33]= local[28];
	ctx->vsp=local+34;
	w=(pointer)SETELT(ctx,3,local+31); /*setelt*/
	if (local[17]==NIL) goto irtstlIF5368;
	local[31]= *(ovafptr(local[28],fqv[20]));
	local[32]= local[17];
	ctx->vsp=local+33;
	w=(*ftab[3])(ctx,2,local+31,&ftab[3],fqv[13]); /*gethash*/
	local[31]= w;
	local[32]= w;
	*(ovafptr(local[28],fqv[20])) = local[32];
	local[31]= *(ovafptr(local[28],fqv[19]));
	local[32]= local[17];
	ctx->vsp=local+33;
	w=(*ftab[3])(ctx,2,local+31,&ftab[3],fqv[13]); /*gethash*/
	local[31]= w;
	local[32]= w;
	*(ovafptr(local[28],fqv[19])) = local[32];
	goto irtstlIF5369;
irtstlIF5368:
	local[31]= NIL;
irtstlIF5369:
	local[31]= local[20];
	local[32]= local[31];
	*(ovafptr(local[28],fqv[23])) = local[32];
	goto irtstlIF5366;
irtstlIF5365:
	local[31]= *(ovafptr(local[29],fqv[20]));
	w = *(ovafptr(local[29],fqv[19]));
	ctx->vsp=local+32;
	local[31]= cons(ctx,local[31],w);
	local[32]= local[16];
	local[33]= local[20];
	ctx->vsp=local+34;
	w=(*ftab[4])(ctx,3,local+31,&ftab[4],fqv[14]); /*sethash*/
	local[31]= local[29];
	w = local[13];
	ctx->vsp=local+32;
	local[13] = cons(ctx,local[31],w);
	local[31]= local[13];
irtstlIF5366:
	goto irtstlWHL5362;
irtstlWHX5363:
	local[31]= NIL;
irtstlBLK5364:
	w = NIL;
	local[27]= w;
	goto irtstlIF5361;
irtstlIF5360:
	local[27]= NIL;
irtstlIF5361:
	local[27]= local[25];
	ctx->vsp=local+28;
	w=(pointer)ADD1(ctx,1,local+27); /*1+*/
	local[25] = w;
	goto irtstlWHL5342;
irtstlWHX5343:
	local[27]= NIL;
irtstlBLK5344:
	w = NIL;
	ctx->vsp=local+25;
	irtstlUWP5341(ctx,0,local+25,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	if (local[5]==NIL) goto irtstlIF5370;
	local[22]= local[13];
	ctx->vsp=local+23;
	w=(pointer)NREVERSE(ctx,1,local+22); /*nreverse*/
	local[22]= w;
	goto irtstlIF5371;
irtstlIF5370:
	local[22]= T;
	ctx->vsp=local+23;
	w=(pointer)LIST(ctx,1,local+22); /*list*/
	local[13] = w;
	local[22]= local[13];
irtstlIF5371:
	local[22]= local[7];
	local[23]= local[22];
	w = fqv[24];
	if (memq(local[23],w)==NIL) goto irtstlIF5372;
	local[23]= local[7];
	local[24]= local[23];
	if (fqv[25]!=local[24]) goto irtstlIF5374;
	local[24]= loadglobal(fqv[26]);
	goto irtstlIF5375;
irtstlIF5374:
	if (T==NIL) goto irtstlIF5376;
	local[24]= loadglobal(fqv[27]);
	goto irtstlIF5377;
irtstlIF5376:
	local[24]= NIL;
irtstlIF5377:
irtstlIF5375:
	w = local[24];
	local[23]= w;
	ctx->vsp=local+24;
	w=(pointer)INSTANTIATE(ctx,1,local+23); /*instantiate*/
	local[23]= w;
	local[24]= local[23];
	local[25]= fqv[16];
	local[26]= fqv[28];
	local[27]= local[12];
	local[28]= fqv[18];
	local[29]= local[13];
	local[30]= fqv[17];
	local[31]= local[17];
	local[32]= fqv[29];
	ctx->vsp=local+33;
	w=(pointer)SEND(ctx,2,local+31); /*send*/
	local[31]= w;
	local[32]= fqv[30];
	local[33]= fqv[31];
	local[34]= makeint((eusinteger_t)100L);
	local[35]= makeint((eusinteger_t)100L);
	local[36]= makeint((eusinteger_t)100L);
	ctx->vsp=local+37;
	w=(pointer)LIST(ctx,4,local+33); /*list*/
	local[33]= w;
	ctx->vsp=local+34;
	w=(pointer)SEND(ctx,10,local+24); /*send*/
	w = local[23];
	local[9] = w;
	local[23]= local[9];
	local[24]= fqv[32];
	local[25]= NIL;
	local[26]= fqv[33];
	local[27]= local[4];
	ctx->vsp=local+28;
	w=(pointer)XFORMAT(ctx,3,local+25); /*format*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(pointer)SEND(ctx,3,local+23); /*send*/
	local[23]= local[9];
	local[24]= local[1];
	local[25]= fqv[34];
	ctx->vsp=local+26;
	w=(pointer)PUTPROP(ctx,3,local+23); /*putprop*/
	local[23]= local[9];
	local[24]= local[15];
	local[25]= fqv[35];
	ctx->vsp=local+26;
	w=(pointer)PUTPROP(ctx,3,local+23); /*putprop*/
	if (local[6]!=NIL) goto irtstlIF5378;
	if (local[0]==NIL) goto irtstlIF5380;
	local[23]= loadglobal(fqv[36]);
	local[24]= fqv[37];
	ctx->vsp=local+25;
	w=(pointer)XFORMAT(ctx,2,local+23); /*format*/
	local[23]= loadglobal(fqv[36]);
	ctx->vsp=local+24;
	w=(pointer)FINOUT(ctx,1,local+23); /*finish-output*/
	local[23]= w;
	goto irtstlIF5381;
irtstlIF5380:
	local[23]= NIL;
irtstlIF5381:
	local[23]= NIL;
	local[24]= local[9];
	local[25]= fqv[28];
	ctx->vsp=local+26;
	w=(pointer)SEND(ctx,2,local+24); /*send*/
	local[24]= w;
irtstlWHL5382:
	if (local[24]==NIL) goto irtstlWHX5383;
	w=local[24];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[25]= (w)->c.cons.car;
	w=local[24];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[24] = (w)->c.cons.cdr;
	w = local[25];
	local[23] = w;
	local[25]= local[23];
	local[26]= fqv[17];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,2,local+25); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21] = (w)->c.cons.cdr;
	local[25]= NIL;
	local[26]= local[21];
irtstlWHL5385:
	if (local[26]==NIL) goto irtstlWHX5386;
	w=local[26];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[27]= (w)->c.cons.car;
	w=local[26];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[26] = (w)->c.cons.cdr;
	w = local[27];
	local[25] = w;
	local[27]= local[25];
	local[28]= local[21];
	ctx->vsp=local+29;
	w=(pointer)LIST(ctx,2,local+27); /*list*/
	local[27]= w;
	local[28]= local[15];
	local[29]= *(ovafptr(local[23],fqv[38]));
	ctx->vsp=local+30;
	w=(*ftab[4])(ctx,3,local+27,&ftab[4],fqv[14]); /*sethash*/
	goto irtstlWHL5385;
irtstlWHX5386:
	local[27]= NIL;
irtstlBLK5387:
	w = NIL;
	goto irtstlWHL5382;
irtstlWHX5383:
	local[25]= NIL;
irtstlBLK5384:
	w = NIL;
	if (local[0]==NIL) goto irtstlIF5388;
	local[23]= loadglobal(fqv[36]);
	local[24]= fqv[39];
	ctx->vsp=local+25;
	w=(pointer)XFORMAT(ctx,2,local+23); /*format*/
	local[23]= w;
	goto irtstlIF5389;
irtstlIF5388:
	local[23]= NIL;
irtstlIF5389:
	goto irtstlIF5379;
irtstlIF5378:
	local[23]= NIL;
irtstlIF5379:
	goto irtstlIF5373;
irtstlIF5372:
	local[23]= local[22];
	if (fqv[40]!=local[23]) goto irtstlIF5390;
	local[23]= loadglobal(fqv[41]);
	ctx->vsp=local+24;
	w=(pointer)INSTANTIATE(ctx,1,local+23); /*instantiate*/
	local[23]= w;
	local[24]= local[23];
	local[25]= fqv[16];
	local[26]= fqv[42];
	local[27]= local[12];
	local[28]= fqv[17];
	ctx->vsp=local+29;
	w=(*ftab[7])(ctx,2,local+27,&ftab[7],fqv[43]); /*send-all*/
	local[27]= w;
	ctx->vsp=local+28;
	w=(*ftab[8])(ctx,1,local+27,&ftab[8],fqv[44]); /*flatten*/
	local[27]= w;
	ctx->vsp=local+28;
	w=(*ftab[9])(ctx,1,local+27,&ftab[9],fqv[45]); /*remove-duplicates*/
	local[27]= w;
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,4,local+24); /*send*/
	w = local[23];
	local[9] = w;
	local[23]= local[9];
	goto irtstlIF5391;
irtstlIF5390:
	local[23]= local[22];
	if (fqv[46]!=local[23]) goto irtstlIF5392;
	local[23]= makeint((eusinteger_t)3L);
	local[24]= local[12];
	ctx->vsp=local+25;
	w=(pointer)LENGTH(ctx,1,local+24); /*length*/
	{ eusinteger_t i,j;
		j=intval(w); i=intval(local[23]);
		local[23]=(makeint(i * j));}
	local[24]= local[23];
	local[25]= makeint((eusinteger_t)3L);
	ctx->vsp=local+26;
	w=(*ftab[10])(ctx,2,local+24,&ftab[10],fqv[47]); /*make-matrix*/
	local[24]= w;
	local[25]= local[23];
	local[26]= makeint((eusinteger_t)3L);
	ctx->vsp=local+27;
	w=(*ftab[10])(ctx,2,local+25,&ftab[10],fqv[47]); /*make-matrix*/
	local[25]= w;
	local[26]= makeint((eusinteger_t)0L);
	local[27]= NIL;
	local[28]= NIL;
	local[29]= local[12];
irtstlWHL5394:
	if (local[29]==NIL) goto irtstlWHX5395;
	w=local[29];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[30]= (w)->c.cons.car;
	w=local[29];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[29] = (w)->c.cons.cdr;
	w = local[30];
	local[28] = w;
	local[30]= local[28];
	local[31]= fqv[17];
	ctx->vsp=local+32;
	w=(pointer)SEND(ctx,2,local+30); /*send*/
	local[30]= w;
	local[31]= *(ovafptr(local[28],fqv[38]));
	local[32]= local[24];
	local[33]= local[26];
	local[34]= local[30];
	local[35]= makeint((eusinteger_t)0L);
	ctx->vsp=local+36;
	w=(pointer)ELT(ctx,2,local+34); /*elt*/
	local[34]= w;
	local[35]= T;
	ctx->vsp=local+36;
	w=(*ftab[11])(ctx,4,local+32,&ftab[11],fqv[48]); /*c-matrix-row*/
	local[32]= local[25];
	local[33]= local[26];
	local[34]= local[31];
	local[35]= T;
	ctx->vsp=local+36;
	w=(*ftab[11])(ctx,4,local+32,&ftab[11],fqv[48]); /*c-matrix-row*/
	local[32]= local[26];
	ctx->vsp=local+33;
	w=(pointer)ADD1(ctx,1,local+32); /*1+*/
	local[26] = w;
	local[32]= local[24];
	local[33]= local[26];
	local[34]= local[30];
	local[35]= makeint((eusinteger_t)1L);
	ctx->vsp=local+36;
	w=(pointer)ELT(ctx,2,local+34); /*elt*/
	local[34]= w;
	local[35]= T;
	ctx->vsp=local+36;
	w=(*ftab[11])(ctx,4,local+32,&ftab[11],fqv[48]); /*c-matrix-row*/
	local[32]= local[25];
	local[33]= local[26];
	local[34]= local[31];
	local[35]= T;
	ctx->vsp=local+36;
	w=(*ftab[11])(ctx,4,local+32,&ftab[11],fqv[48]); /*c-matrix-row*/
	local[32]= local[26];
	ctx->vsp=local+33;
	w=(pointer)ADD1(ctx,1,local+32); /*1+*/
	local[26] = w;
	local[32]= local[24];
	local[33]= local[26];
	local[34]= local[30];
	local[35]= makeint((eusinteger_t)2L);
	ctx->vsp=local+36;
	w=(pointer)ELT(ctx,2,local+34); /*elt*/
	local[34]= w;
	local[35]= T;
	ctx->vsp=local+36;
	w=(*ftab[11])(ctx,4,local+32,&ftab[11],fqv[48]); /*c-matrix-row*/
	local[32]= local[25];
	local[33]= local[26];
	local[34]= local[31];
	local[35]= T;
	ctx->vsp=local+36;
	w=(*ftab[11])(ctx,4,local+32,&ftab[11],fqv[48]); /*c-matrix-row*/
	local[32]= local[26];
	ctx->vsp=local+33;
	w=(pointer)ADD1(ctx,1,local+32); /*1+*/
	local[26] = w;
	w = local[26];
	goto irtstlWHL5394;
irtstlWHX5395:
	local[30]= NIL;
irtstlBLK5396:
	w = NIL;
	local[28]= loadglobal(fqv[49]);
	ctx->vsp=local+29;
	w=(pointer)INSTANTIATE(ctx,1,local+28); /*instantiate*/
	local[28]= w;
	local[29]= local[28];
	local[30]= fqv[16];
	local[31]= fqv[17];
	local[32]= local[24];
	ctx->vsp=local+33;
	w=(pointer)LIST(ctx,2,local+31); /*list*/
	local[31]= w;
	local[32]= fqv[50];
	local[33]= local[25];
	ctx->vsp=local+34;
	w=(pointer)LIST(ctx,2,local+32); /*list*/
	local[32]= w;
	local[33]= fqv[51];
	local[34]= fqv[52];
	local[35]= local[1];
	ctx->vsp=local+36;
	w=(pointer)LIST(ctx,2,local+34); /*list*/
	local[34]= w;
	ctx->vsp=local+35;
	w=(pointer)LIST(ctx,1,local+34); /*list*/
	local[34]= w;
	ctx->vsp=local+35;
	w=(pointer)LIST(ctx,2,local+33); /*list*/
	local[33]= w;
	local[34]= fqv[53];
	local[35]= fqv[54];
	ctx->vsp=local+36;
	w=(pointer)LIST(ctx,2,local+34); /*list*/
	local[34]= w;
	ctx->vsp=local+35;
	w=(pointer)LIST(ctx,4,local+31); /*list*/
	local[31]= w;
	ctx->vsp=local+32;
	w=(pointer)LIST(ctx,1,local+31); /*list*/
	local[31]= w;
	local[32]= fqv[55];
	local[33]= argv[0];
	ctx->vsp=local+34;
	w=(pointer)SEND(ctx,5,local+29); /*send*/
	w = local[28];
	local[9] = w;
	w = local[9];
	local[23]= w;
	goto irtstlIF5393;
irtstlIF5392:
	local[23]= local[22];
	if (fqv[28]!=local[23]) goto irtstlIF5397;
	local[9] = local[12];
	local[23]= local[9];
	goto irtstlIF5398;
irtstlIF5397:
	if (T==NIL) goto irtstlIF5399;
	local[23]= fqv[56];
	local[24]= local[7];
	ctx->vsp=local+25;
	w=(*ftab[12])(ctx,2,local+23,&ftab[12],fqv[57]); /*warn*/
	local[23]= w;
	goto irtstlIF5400;
irtstlIF5399:
	local[23]= NIL;
irtstlIF5400:
irtstlIF5398:
irtstlIF5393:
irtstlIF5391:
irtstlIF5373:
	w = local[23];
	w = local[9];
	local[0]= w;
irtstlBLK5332:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtstlUWP5341(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[22];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtstlCLO5348(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	if (env->c.clo.env2[3]==NIL) goto irtstlIF5401;
	local[0]= env->c.clo.env2[3];
	local[1]= argv[0];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SCALEVEC(ctx,3,local+0); /*scale*/
	local[0]= w;
	goto irtstlIF5402;
irtstlIF5401:
	local[0]= NIL;
irtstlIF5402:
	if (env->c.clo.env2[2]==NIL) goto irtstlIF5403;
	local[0]= env->c.clo.env2[2];
	local[1]= fqv[58];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto irtstlIF5404;
irtstlIF5403:
	local[0]= argv[0];
irtstlIF5404:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtstlCLO5359(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env2[19];
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,2,local+0); /*list*/
	local[0]= w;
	local[1]= env->c.clo.env2[15];
	w=env->c.clo.env2[18];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(*ftab[4])(ctx,3,local+0,&ftab[4],fqv[14]); /*sethash*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtstlCLO5367(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= *(ovafptr(argv[0],fqv[20]));
	local[1]= *(ovafptr(argv[1],fqv[19]));
	ctx->vsp=local+2;
	w=(*ftab[13])(ctx,2,local+0,&ftab[13],fqv[59]); /*v=*/
	local[0]= w;
	if (w==NIL) goto irtstlAND5405;
	local[0]= *(ovafptr(argv[1],fqv[20]));
	local[1]= *(ovafptr(argv[0],fqv[19]));
	ctx->vsp=local+2;
	w=(*ftab[13])(ctx,2,local+0,&ftab[13],fqv[59]); /*v=*/
	local[0]= w;
irtstlAND5405:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*write-stl-header*/
static pointer irtstlF5316write_stl_header(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeint((eusinteger_t)80L);
	ctx->vsp=local+1;
	w=(*ftab[0])(ctx,1,local+0,&ftab[0],fqv[4]); /*make-string*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[60];
	ctx->vsp=local+3;
	w=(*ftab[14])(ctx,2,local+1,&ftab[14],fqv[61]); /*replace*/
	local[1]= argv[0];
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)80L);
	ctx->vsp=local+4;
	w=(pointer)UNIXWRITE(ctx,3,local+1); /*unix:write*/
	local[0]= makeint((eusinteger_t)4L);
	ctx->vsp=local+1;
	w=(*ftab[0])(ctx,1,local+0,&ftab[0],fqv[4]); /*make-string*/
	local[0]= w;
	local[1]= argv[1];
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= fqv[10];
	ctx->vsp=local+5;
	w=(pointer)POKE(ctx,4,local+1); /*system:poke*/
	local[1]= argv[0];
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)4L);
	ctx->vsp=local+4;
	w=(pointer)UNIXWRITE(ctx,3,local+1); /*unix:write*/
	local[0]= w;
irtstlBLK5406:
	ctx->vsp=local; return(local[0]);}

/*write-stl-binary-float-val*/
static pointer irtstlF5317write_stl_binary_float_val(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeint((eusinteger_t)4L);
	ctx->vsp=local+1;
	w=(*ftab[0])(ctx,1,local+0,&ftab[0],fqv[4]); /*make-string*/
	local[0]= w;
	local[1]= argv[1];
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= fqv[11];
	ctx->vsp=local+5;
	w=(pointer)POKE(ctx,4,local+1); /*system:poke*/
	local[1]= argv[0];
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)4L);
	ctx->vsp=local+4;
	w=(pointer)UNIXWRITE(ctx,3,local+1); /*unix:write*/
	local[0]= w;
irtstlBLK5407:
	ctx->vsp=local; return(local[0]);}

/*write-stl-face*/
static pointer irtstlF5318write_stl_face(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[62], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtstlKEY5409;
	local[0] = makeflt(1.0000000000000000208167e-03);
irtstlKEY5409:
	local[1]= argv[1];
	local[2]= fqv[63];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[1];
	local[3]= fqv[17];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.cdr;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	if (makeint((eusinteger_t)3L)==local[3]) goto irtstlIF5410;
	local[3]= fqv[64];
	ctx->vsp=local+4;
	w=(pointer)SIGERROR(ctx,1,local+3); /*error*/
	local[3]= w;
	goto irtstlIF5411;
irtstlIF5410:
	local[3]= NIL;
irtstlIF5411:
	local[3]= argv[0];
	local[4]= local[1];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)irtstlF5317write_stl_binary_float_val(ctx,2,local+3); /*write-stl-binary-float-val*/
	local[3]= argv[0];
	local[4]= local[1];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)irtstlF5317write_stl_binary_float_val(ctx,2,local+3); /*write-stl-binary-float-val*/
	local[3]= argv[0];
	local[4]= local[1];
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)irtstlF5317write_stl_binary_float_val(ctx,2,local+3); /*write-stl-binary-float-val*/
	local[3]= NIL;
	local[4]= local[2];
irtstlWHL5412:
	if (local[4]==NIL) goto irtstlWHX5413;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= argv[0];
	local[6]= local[0];
	local[7]= local[3];
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)irtstlF5317write_stl_binary_float_val(ctx,2,local+5); /*write-stl-binary-float-val*/
	local[5]= argv[0];
	local[6]= local[0];
	local[7]= local[3];
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)irtstlF5317write_stl_binary_float_val(ctx,2,local+5); /*write-stl-binary-float-val*/
	local[5]= argv[0];
	local[6]= local[0];
	local[7]= local[3];
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)irtstlF5317write_stl_binary_float_val(ctx,2,local+5); /*write-stl-binary-float-val*/
	goto irtstlWHL5412;
irtstlWHX5413:
	local[5]= NIL;
irtstlBLK5414:
	w = NIL;
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(*ftab[0])(ctx,1,local+3,&ftab[0],fqv[4]); /*make-string*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= local[3];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)UNIXWRITE(ctx,3,local+4); /*unix:write*/
	local[0]= w;
irtstlBLK5408:
	ctx->vsp=local; return(local[0]);}

/*eus2stl*/
static pointer irtstlF5319eus2stl(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[65], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtstlKEY5416;
	local[0] = makeflt(1.0000000000000000208167e-03);
irtstlKEY5416:
	local[1]= argv[1];
	local[2]= fqv[66];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[67];
	local[3]= fqv[68];
	ctx->vsp=local+4;
	w=(*ftab[2])(ctx,3,local+1,&ftab[2],fqv[8]); /*open*/
	local[1]= w;
	ctx->vsp=local+2;
	w = makeclosure(codevec,quotevec,irtstlUWP5417,env,argv,local);
	local[2]=(pointer)(ctx->protfp); local[3]=w;
	ctx->protfp=(struct protectframe *)(local+2);
	local[4]= NIL;
	local[5]= argv[1];
	local[6]= fqv[69];
	ctx->vsp=local+7;
	w=(*ftab[15])(ctx,2,local+5,&ftab[15],fqv[70]); /*find-method*/
	if (w==NIL) goto irtstlCON5419;
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtstlCLO5420,env,argv,local);
	local[6]= argv[1];
	local[7]= fqv[69];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MAPCAN(ctx,2,local+5); /*mapcan*/
	local[4] = w;
	local[5]= local[4];
	goto irtstlCON5418;
irtstlCON5419:
	local[5]= argv[1];
	ctx->vsp=local+6;
	w=(*ftab[16])(ctx,1,local+5,&ftab[16],fqv[71]); /*body-to-faces*/
	local[5]= w;
	local[6]= fqv[28];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[4] = w;
	local[5]= local[4];
	goto irtstlCON5418;
irtstlCON5421:
	local[5]= NIL;
irtstlCON5418:
	local[5]= local[1];
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)irtstlF5316write_stl_header(ctx,2,local+5); /*write-stl-header*/
	local[5]= NIL;
	local[6]= local[4];
irtstlWHL5422:
	if (local[6]==NIL) goto irtstlWHX5423;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= local[1];
	local[8]= local[5];
	local[9]= fqv[72];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)irtstlF5318write_stl_face(ctx,4,local+7); /*write-stl-face*/
	goto irtstlWHL5422;
irtstlWHX5423:
	local[7]= NIL;
irtstlBLK5424:
	w = NIL;
	ctx->vsp=local+4;
	irtstlUWP5417(ctx,0,local+4,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	w = argv[0];
	local[0]= w;
irtstlBLK5415:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtstlUWP5417(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[1];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtstlCLO5420(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[46];
	ctx->vsp=local+2;
	w=(*ftab[15])(ctx,2,local+0,&ftab[15],fqv[70]); /*find-method*/
	if (w==NIL) goto irtstlCON5426;
	local[0]= argv[0];
	local[1]= fqv[46];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[16])(ctx,1,local+0,&ftab[16],fqv[71]); /*body-to-faces*/
	local[0]= w;
	local[1]= fqv[28];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto irtstlCON5425;
irtstlCON5426:
	local[0]= fqv[73];
	local[1]= argv[0];
	local[2]= fqv[74];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[75]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto irtstlCON5427;
	local[0]= fqv[73];
	local[1]= argv[0];
	local[2]= fqv[74];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[75]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= fqv[28];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto irtstlCON5425;
irtstlCON5427:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[16])(ctx,1,local+0,&ftab[16],fqv[71]); /*body-to-faces*/
	local[0]= w;
	local[1]= fqv[28];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto irtstlCON5425;
irtstlCON5428:
	local[0]= NIL;
irtstlCON5425:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*read-files-from-solidedge*/
static pointer irtstlF5320read_files_from_solidedge(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[76], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto irtstlKEY5430;
	local[0] = NIL;
irtstlKEY5430:
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,1,local+1,&ftab[2],fqv[8]); /*open*/
	local[1]= w;
	ctx->vsp=local+2;
	w = makeclosure(codevec,quotevec,irtstlUWP5431,env,argv,local);
	local[2]=(pointer)(ctx->protfp); local[3]=w;
	ctx->protfp=(struct protectframe *)(local+2);
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)READ(ctx,1,local+4); /*read*/
	ctx->vsp=local+4;
	irtstlUWP5431(ctx,0,local+4,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[72];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)irtstlF5321read_assembly_config(ctx,3,local+2); /*read-assembly-config*/
	local[0]= w;
irtstlBLK5429:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtstlUWP5431(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[1];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*read-assembly-config*/
static pointer irtstlF5321read_assembly_config(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[77], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto irtstlKEY5433;
	local[0] = NIL;
irtstlKEY5433:
	if (n & (1<<1)) goto irtstlKEY5434;
	local[1] = NIL;
irtstlKEY5434:
	local[2]= NIL;
	local[3]= NIL;
	local[4]= argv[0];
irtstlWHL5435:
	if (local[4]==NIL) goto irtstlWHX5436;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= local[5];
	if (fqv[78]!=local[6]) goto irtstlIF5438;
	local[6]= fqv[79];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(*ftab[17])(ctx,2,local+6,&ftab[17],fqv[75]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.cdr;
	local[7]= fqv[80];
	local[8]= fqv[81];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(*ftab[17])(ctx,2,local+8,&ftab[17],fqv[75]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.cdr;
	local[9]= fqv[82];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(*ftab[18])(ctx,1,local+10,&ftab[18],fqv[83]); /*elt_z*/
	local[10]= w;
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(*ftab[19])(ctx,1,local+11,&ftab[19],fqv[84]); /*elt_y*/
	local[11]= w;
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(*ftab[20])(ctx,1,local+12,&ftab[20],fqv[85]); /*elt_x*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(*ftab[21])(ctx,3,local+10,&ftab[21],fqv[86]); /*rpy-matrix*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[22])(ctx,4,local+7,&ftab[22],fqv[87]); /*make-coords*/
	local[7]= w;
	local[8]= fqv[88];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(*ftab[17])(ctx,2,local+8,&ftab[17],fqv[75]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.cdr;
	local[9]= fqv[72];
	local[10]= local[0];
	local[11]= fqv[32];
	local[12]= fqv[32];
	local[13]= local[3];
	ctx->vsp=local+14;
	w=(*ftab[17])(ctx,2,local+12,&ftab[17],fqv[75]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.cdr;
	ctx->vsp=local+13;
	w=(pointer)irtstlF5315stl2eus(ctx,5,local+8); /*stl2eus*/
	local[8]= w;
	if (local[1]==NIL) goto irtstlIF5440;
	local[9]= local[7];
	local[10]= fqv[89];
	local[11]= local[1];
	local[12]= fqv[90];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,4,local+9); /*send*/
	local[9]= w;
	goto irtstlIF5441;
irtstlIF5440:
	local[9]= NIL;
irtstlIF5441:
	local[9]= local[8];
	local[10]= fqv[91];
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= local[8];
	w = local[2];
	ctx->vsp=local+10;
	local[2] = cons(ctx,local[9],w);
	w = local[2];
	local[6]= w;
	goto irtstlIF5439;
irtstlIF5438:
	local[6]= local[5];
	if (fqv[92]!=local[6]) goto irtstlIF5442;
	local[6]= fqv[79];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(*ftab[17])(ctx,2,local+6,&ftab[17],fqv[75]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.cdr;
	local[7]= fqv[80];
	local[8]= fqv[81];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(*ftab[17])(ctx,2,local+8,&ftab[17],fqv[75]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.cdr;
	local[9]= fqv[82];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(*ftab[18])(ctx,1,local+10,&ftab[18],fqv[83]); /*elt_z*/
	local[10]= w;
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(*ftab[19])(ctx,1,local+11,&ftab[19],fqv[84]); /*elt_y*/
	local[11]= w;
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(*ftab[20])(ctx,1,local+12,&ftab[20],fqv[85]); /*elt_x*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(*ftab[21])(ctx,3,local+10,&ftab[21],fqv[86]); /*rpy-matrix*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[22])(ctx,4,local+7,&ftab[22],fqv[87]); /*make-coords*/
	local[7]= w;
	local[8]= fqv[93];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(*ftab[17])(ctx,2,local+8,&ftab[17],fqv[75]); /*assoc*/
	local[8]= w;
	if (local[8]==NIL) goto irtstlIF5444;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.cdr;
	local[10]= fqv[94];
	if (local[1]==NIL) goto irtstlIF5446;
	local[11]= local[7];
	local[12]= fqv[89];
	local[13]= local[1];
	local[14]= fqv[90];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,4,local+11); /*send*/
	local[11]= w;
	goto irtstlIF5447;
irtstlIF5446:
	local[11]= local[7];
irtstlIF5447:
	ctx->vsp=local+12;
	w=(pointer)irtstlF5321read_assembly_config(ctx,3,local+9); /*read-assembly-config*/
	local[9]= w;
	w = local[2];
	ctx->vsp=local+10;
	local[2] = cons(ctx,local[9],w);
	local[9]= local[2];
	goto irtstlIF5445;
irtstlIF5444:
	local[9]= NIL;
irtstlIF5445:
	w = local[9];
	local[6]= w;
	goto irtstlIF5443;
irtstlIF5442:
	if (T==NIL) goto irtstlIF5448;
	local[6]= fqv[95];
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(*ftab[12])(ctx,2,local+6,&ftab[12],fqv[57]); /*warn*/
	local[6]= w;
	goto irtstlIF5449;
irtstlIF5448:
	local[6]= NIL;
irtstlIF5449:
irtstlIF5443:
irtstlIF5439:
	w = local[6];
	goto irtstlWHL5435;
irtstlWHX5436:
	local[5]= NIL;
irtstlBLK5437:
	w = NIL;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)NREVERSE(ctx,1,local+3); /*nreverse*/
	local[0]= w;
irtstlBLK5432:
	ctx->vsp=local; return(local[0]);}

/*stl-make-faces*/
static pointer irtstlF5322stl_make_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[96], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto irtstlKEY5451;
	local[0] = NIL;
irtstlKEY5451:
	if (n & (1<<1)) goto irtstlKEY5452;
	local[1] = NIL;
irtstlKEY5452:
	local[2]= makeint((eusinteger_t)80L);
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,1,local+2,&ftab[0],fqv[4]); /*make-string*/
	local[2]= w;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= argv[0];
	ctx->vsp=local+10;
	w=(*ftab[2])(ctx,1,local+9,&ftab[2],fqv[8]); /*open*/
	local[9]= w;
	ctx->vsp=local+10;
	w = makeclosure(codevec,quotevec,irtstlUWP5453,env,argv,local);
	local[10]=(pointer)(ctx->protfp); local[11]=w;
	ctx->protfp=(struct protectframe *)(local+10);
	local[12]= local[9];
	local[13]= fqv[9];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[7] = w;
	local[12]= local[7];
	local[13]= local[2];
	local[14]= makeint((eusinteger_t)80L);
	ctx->vsp=local+15;
	w=(pointer)UNIXREAD(ctx,3,local+12); /*unix:uread*/
	local[12]= T;
	local[13]= fqv[97];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)XFORMAT(ctx,3,local+12); /*format*/
	local[12]= local[7];
	local[13]= local[2];
	local[14]= makeint((eusinteger_t)4L);
	ctx->vsp=local+15;
	w=(pointer)UNIXREAD(ctx,3,local+12); /*unix:uread*/
	local[12]= local[2];
	local[13]= makeint((eusinteger_t)0L);
	local[14]= fqv[10];
	ctx->vsp=local+15;
	w=(pointer)PEEK(ctx,3,local+12); /*system:peek*/
	local[8] = w;
	local[12]= T;
	local[13]= fqv[98];
	local[14]= local[8];
	ctx->vsp=local+15;
	w=(pointer)XFORMAT(ctx,3,local+12); /*format*/
	local[12]= makeint((eusinteger_t)0L);
	local[13]= local[8];
irtstlWHL5454:
	local[14]= local[12];
	w = local[13];
	if ((eusinteger_t)local[14] >= (eusinteger_t)w) goto irtstlWHX5455;
	local[3] = NIL;
	local[14]= makeint((eusinteger_t)0L);
	local[15]= makeint((eusinteger_t)4L);
irtstlWHL5457:
	local[16]= local[14];
	w = local[15];
	if ((eusinteger_t)local[16] >= (eusinteger_t)w) goto irtstlWHX5458;
	local[16]= local[7];
	local[17]= local[2];
	local[18]= makeint((eusinteger_t)12L);
	ctx->vsp=local+19;
	w=(pointer)UNIXREAD(ctx,3,local+16); /*unix:uread*/
	local[16]= local[2];
	local[17]= makeint((eusinteger_t)0L);
	local[18]= fqv[11];
	ctx->vsp=local+19;
	w=(pointer)PEEK(ctx,3,local+16); /*system:peek*/
	local[16]= w;
	local[17]= local[2];
	local[18]= makeint((eusinteger_t)4L);
	local[19]= fqv[11];
	ctx->vsp=local+20;
	w=(pointer)PEEK(ctx,3,local+17); /*system:peek*/
	local[17]= w;
	local[18]= local[2];
	local[19]= makeint((eusinteger_t)8L);
	local[20]= fqv[11];
	ctx->vsp=local+21;
	w=(pointer)PEEK(ctx,3,local+18); /*system:peek*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)MKFLTVEC(ctx,3,local+16); /*float-vector*/
	local[16]= w;
	w = local[3];
	ctx->vsp=local+17;
	local[3] = cons(ctx,local[16],w);
	local[16]= local[14];
	ctx->vsp=local+17;
	w=(pointer)ADD1(ctx,1,local+16); /*1+*/
	local[14] = w;
	goto irtstlWHL5457;
irtstlWHX5458:
	local[16]= NIL;
irtstlBLK5459:
	w = NIL;
	local[14]= local[7];
	local[15]= local[2];
	local[16]= makeint((eusinteger_t)2L);
	ctx->vsp=local+17;
	w=(pointer)UNIXREAD(ctx,3,local+14); /*unix:uread*/
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)NREVERSE(ctx,1,local+14); /*nreverse*/
	ctx->vsp=local+14;
	local[14]= makeclosure(codevec,quotevec,irtstlCLO5460,env,argv,local);
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.cdr;
	ctx->vsp=local+16;
	w=(pointer)MAPCAR(ctx,2,local+14); /*mapcar*/
	local[4] = w;
	local[14]= loadglobal(fqv[15]);
	ctx->vsp=local+15;
	w=(pointer)INSTANTIATE(ctx,1,local+14); /*instantiate*/
	local[14]= w;
	local[15]= local[14];
	local[16]= fqv[16];
	local[17]= fqv[17];
	local[18]= local[4];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,4,local+15); /*send*/
	w = local[14];
	local[5] = w;
	local[14]= local[5];
	w = local[6];
	ctx->vsp=local+15;
	local[6] = cons(ctx,local[14],w);
	local[14]= local[12];
	ctx->vsp=local+15;
	w=(pointer)ADD1(ctx,1,local+14); /*1+*/
	local[12] = w;
	goto irtstlWHL5454;
irtstlWHX5455:
	local[14]= NIL;
irtstlBLK5456:
	w = NIL;
	ctx->vsp=local+12;
	irtstlUWP5453(ctx,0,local+12,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	w = local[6];
	local[0]= w;
irtstlBLK5450:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtstlUWP5453(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[9];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtstlCLO5460(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	if (env->c.clo.env2[0]==NIL) goto irtstlIF5461;
	local[0]= env->c.clo.env2[0];
	local[1]= argv[0];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SCALEVEC(ctx,3,local+0); /*scale*/
	local[0]= w;
	goto irtstlIF5462;
irtstlIF5461:
	local[0]= NIL;
irtstlIF5462:
	if (env->c.clo.env2[1]==NIL) goto irtstlIF5463;
	local[0]= env->c.clo.env2[1];
	local[1]= fqv[58];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto irtstlIF5464;
irtstlIF5463:
	local[0]= argv[0];
irtstlIF5464:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*safe-vmax*/
static pointer irtstlF5323safe_vmax(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[99];
	local[2]= (pointer)get_sym_func(fqv[100]);
	ctx->vsp=local+3;
	w=(pointer)irtstlF5325safe_vmaxmin(ctx,3,local+0); /*safe-vmaxmin*/
	local[0]= w;
irtstlBLK5465:
	ctx->vsp=local; return(local[0]);}

/*safe-vmin*/
static pointer irtstlF5324safe_vmin(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[99];
	local[2]= (pointer)get_sym_func(fqv[101]);
	ctx->vsp=local+3;
	w=(pointer)irtstlF5325safe_vmaxmin(ctx,3,local+0); /*safe-vmaxmin*/
	local[0]= w;
irtstlBLK5466:
	ctx->vsp=local; return(local[0]);}

/*safe-vmaxmin*/
static pointer irtstlF5325safe_vmaxmin(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[102], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto irtstlKEY5468;
	local[0] = (pointer)get_sym_func(fqv[100]);
irtstlKEY5468:
	if (n & (1<<1)) goto irtstlKEY5469;
	local[1] = makeint((eusinteger_t)32000L);
irtstlKEY5469:
	local[2]= NIL;
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	local[4]= local[3];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)LESSP(ctx,2,local+4); /*<*/
	if (w==NIL) goto irtstlIF5470;
	local[4]= local[0];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,2,local+4); /*apply*/
	ctx->vsp=local+4;
	local[0]=w;
	goto irtstlBLK5467;
	goto irtstlIF5471;
irtstlIF5470:
	local[4]= NIL;
irtstlIF5471:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.car;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[3];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
irtstlWHL5472:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto irtstlWHX5473;
	local[6]= local[0];
	local[7]= local[2];
	local[8]= argv[0];
	local[9]= local[4];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[10]= w;
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SUBSEQ(ctx,3,local+8); /*subseq*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)APPLY(ctx,3,local+6); /*apply*/
	local[2] = w;
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto irtstlWHL5472;
irtstlWHX5473:
	local[6]= NIL;
irtstlBLK5474:
	w = NIL;
	local[4]= local[3];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)MOD(ctx,2,local+4); /*mod*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)NUMEQUAL(ctx,2,local+4); /*=*/
	if (w==NIL) goto irtstlIF5475;
	local[4]= local[2];
	goto irtstlIF5476;
irtstlIF5475:
	local[4]= local[0];
	local[5]= local[2];
	local[6]= argv[0];
	local[7]= local[1];
	local[8]= local[3];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)SUBSEQ(ctx,3,local+6); /*subseq*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)APPLY(ctx,3,local+4); /*apply*/
	local[4]= w;
irtstlIF5476:
	w = local[4];
	local[0]= w;
irtstlBLK5467:
	ctx->vsp=local; return(local[0]);}

/*devide-faces*/
static pointer irtstlF5326devide_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[103], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto irtstlKEY5478;
	local[0] = makeflt(0.0000000000000000000000e+00);
irtstlKEY5478:
	if (n & (1<<1)) goto irtstlKEY5479;
	local[1] = fqv[104];
irtstlKEY5479:
	local[2]= local[1];
	local[3]= local[2];
	if (fqv[104]!=local[3]) goto irtstlIF5480;
	local[3]= makeint((eusinteger_t)0L);
	goto irtstlIF5481;
irtstlIF5480:
	local[3]= local[2];
	if (fqv[105]!=local[3]) goto irtstlIF5482;
	local[3]= makeint((eusinteger_t)1L);
	goto irtstlIF5483;
irtstlIF5482:
	local[3]= local[2];
	if (fqv[106]!=local[3]) goto irtstlIF5484;
	local[3]= makeint((eusinteger_t)2L);
	goto irtstlIF5485;
irtstlIF5484:
	if (T==NIL) goto irtstlIF5486;
	local[3]= local[1];
	goto irtstlIF5487;
irtstlIF5486:
	local[3]= NIL;
irtstlIF5487:
irtstlIF5485:
irtstlIF5483:
irtstlIF5481:
	w = local[3];
	local[2]= w;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= argv[0];
irtstlWHL5488:
	if (local[6]==NIL) goto irtstlWHX5489;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= (pointer)get_sym_func(fqv[100]);
	local[8]= local[5];
	local[9]= fqv[17];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)APPLY(ctx,2,local+7); /*apply*/
	local[7]= w;
	local[8]= local[7];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)GREATERP(ctx,2,local+8); /*>*/
	if (w==NIL) goto irtstlIF5491;
	local[8]= local[5];
	w = local[3];
	ctx->vsp=local+9;
	local[3] = cons(ctx,local[8],w);
	local[8]= local[3];
	goto irtstlIF5492;
irtstlIF5491:
	local[8]= local[5];
	w = local[4];
	ctx->vsp=local+9;
	local[4] = cons(ctx,local[8],w);
	local[8]= local[4];
irtstlIF5492:
	w = local[8];
	goto irtstlWHL5488;
irtstlWHX5489:
	local[7]= NIL;
irtstlBLK5490:
	w = NIL;
	local[5]= local[3];
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,2,local+5); /*list*/
	local[0]= w;
irtstlBLK5477:
	ctx->vsp=local; return(local[0]);}

/*make-boundingbox-from-faces*/
static pointer irtstlF5327make_boundingbox_from_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[0];
irtstlWHL5494:
	if (local[3]==NIL) goto irtstlWHX5495;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= (pointer)get_sym_func(fqv[100]);
	local[5]= local[2];
	local[6]= fqv[17];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,2,local+4); /*apply*/
	local[4]= w;
	w = local[1];
	ctx->vsp=local+5;
	local[1] = cons(ctx,local[4],w);
	local[4]= (pointer)get_sym_func(fqv[101]);
	local[5]= local[2];
	local[6]= fqv[17];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,2,local+4); /*apply*/
	local[4]= w;
	w = local[0];
	ctx->vsp=local+5;
	local[0] = cons(ctx,local[4],w);
	goto irtstlWHL5494;
irtstlWHX5495:
	local[4]= NIL;
irtstlBLK5496:
	w = NIL;
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(pointer)irtstlF5323safe_vmax(ctx,1,local+2); /*safe-vmax*/
	local[2]= w;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)irtstlF5324safe_vmin(ctx,1,local+3); /*safe-vmin*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,2,local+2); /*list*/
	local[0]= w;
irtstlBLK5493:
	ctx->vsp=local; return(local[0]);}

/*small-square-axis*/
static pointer irtstlF5328small_square_axis(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= (pointer)get_sym_func(fqv[107]);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)APPLY(ctx,2,local+0); /*apply*/
	local[0]= w;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(*ftab[20])(ctx,1,local+1,&ftab[20],fqv[85]); /*elt_x*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[19])(ctx,1,local+2,&ftab[19],fqv[84]); /*elt_y*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[20])(ctx,1,local+2,&ftab[20],fqv[85]); /*elt_x*/
	local[2]= w;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(*ftab[18])(ctx,1,local+3,&ftab[18],fqv[83]); /*elt_z*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(*ftab[19])(ctx,1,local+3,&ftab[19],fqv[84]); /*elt_y*/
	local[3]= w;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[18])(ctx,1,local+4,&ftab[18],fqv[83]); /*elt_z*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	local[4]= local[3];
	local[5]= local[2];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,3,local+4); /*list*/
	local[4]= w;
	local[5]= (pointer)get_sym_func(fqv[108]);
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)APPLY(ctx,2,local+5); /*apply*/
	local[5]= w;
	local[6]= local[4];
	local[7]= fqv[5];
	local[8]= (pointer)get_sym_func(fqv[109]);
	ctx->vsp=local+9;
	w=(*ftab[6])(ctx,4,local+5,&ftab[6],fqv[22]); /*position*/
	local[0]= w;
irtstlBLK5497:
	ctx->vsp=local; return(local[0]);}

/*make-devided-faces-lists*/
static pointer irtstlF5329make_devided_faces_lists(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[110], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto irtstlKEY5499;
	local[0] = makeint((eusinteger_t)32000L);
irtstlKEY5499:
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[1]= w;
irtstlWHL5500:
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)GREATERP(ctx,2,local+2); /*>*/
	if (w==NIL) goto irtstlWHX5501;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)irtstlF5327make_boundingbox_from_faces(ctx,1,local+2); /*make-boundingbox-from-faces*/
	local[2]= w;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)irtstlF5328small_square_axis(ctx,1,local+3); /*small-square-axis*/
	local[3]= w;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= fqv[111];
	local[6]= (pointer)get_sym_func(fqv[112]);
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,2,local+6); /*apply*/
	local[6]= w;
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[6]= w;
	local[7]= fqv[113];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)irtstlF5326devide_faces(ctx,5,local+4); /*devide-faces*/
	local[4]= w;
	local[5]= local[4];
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.cdr;
	ctx->vsp=local+7;
	w=(pointer)NCONC(ctx,2,local+5); /*nconc*/
	local[1] = w;
	local[5]= local[1];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtstlCLO5503,env,argv,local);
	ctx->vsp=local+7;
	w=(pointer)SORT(ctx,2,local+5); /*sort*/
	goto irtstlWHL5500;
irtstlWHX5501:
	local[2]= NIL;
irtstlBLK5502:
	w = local[1];
	local[0]= w;
irtstlBLK5498:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtstlCLO5503(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)GREQP(ctx,2,local+0); /*>=*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*make-faceset-from-faces*/
static pointer irtstlF5330make_faceset_from_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[5];
	local[1]= (pointer)get_sym_func(fqv[6]);
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,2,local+0,&ftab[1],fqv[7]); /*make-hash-table*/
	local[0]= w;
	local[1]= fqv[5];
	local[2]= (pointer)get_sym_func(fqv[6]);
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,2,local+1,&ftab[1],fqv[7]); /*make-hash-table*/
	local[1]= w;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= argv[0];
irtstlWHL5505:
	if (local[5]==NIL) goto irtstlWHX5506;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= local[4];
	local[7]= fqv[17];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)LENGTH(ctx,1,local+8); /*length*/
	local[8]= w;
irtstlWHL5508:
	local[9]= local[7];
	w = local[8];
	if ((eusinteger_t)local[9] >= (eusinteger_t)w) goto irtstlWHX5509;
	local[9]= local[6];
	local[10]= local[7];
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	local[10]= *(ovafptr(local[4],fqv[114]));
	local[11]= local[7];
	local[12]= local[9];
	local[13]= local[0];
	local[14]= local[9];
	ctx->vsp=local+15;
	w=(*ftab[4])(ctx,3,local+12,&ftab[4],fqv[14]); /*sethash*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)SETELT(ctx,3,local+10); /*setelt*/
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[7] = w;
	goto irtstlWHL5508;
irtstlWHX5509:
	local[9]= NIL;
irtstlBLK5510:
	w = NIL;
	goto irtstlWHL5505;
irtstlWHX5506:
	local[6]= NIL;
irtstlBLK5507:
	w = NIL;
	local[4]= NIL;
	local[5]= argv[0];
irtstlWHL5511:
	if (local[5]==NIL) goto irtstlWHX5512;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= local[4];
	local[10]= fqv[18];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
irtstlWHL5514:
	if (local[9]==NIL) goto irtstlWHX5515;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= *(ovafptr(local[8],fqv[19]));
	w = *(ovafptr(local[8],fqv[20]));
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(*ftab[3])(ctx,2,local+10,&ftab[3],fqv[13]); /*gethash*/
	local[6] = w;
	if (local[6]==NIL) goto irtstlIF5517;
	local[10]= local[8];
	local[11]= local[6];
	local[12]= fqv[18];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	local[12]= fqv[5];
	ctx->vsp=local+13;
	local[13]= makeclosure(codevec,quotevec,irtstlCLO5519,env,argv,local);
	ctx->vsp=local+14;
	w=(*ftab[5])(ctx,4,local+10,&ftab[5],fqv[21]); /*find*/
	local[7] = w;
	local[10]= local[4];
	local[11]= fqv[18];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	local[11]= local[8];
	local[12]= local[4];
	local[13]= fqv[18];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(*ftab[6])(ctx,2,local+11,&ftab[6],fqv[22]); /*position*/
	local[11]= w;
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(pointer)SETELT(ctx,3,local+10); /*setelt*/
	if (local[0]==NIL) goto irtstlIF5520;
	local[10]= *(ovafptr(local[7],fqv[20]));
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(*ftab[3])(ctx,2,local+10,&ftab[3],fqv[13]); /*gethash*/
	local[10]= w;
	local[11]= w;
	*(ovafptr(local[7],fqv[20])) = local[11];
	local[10]= *(ovafptr(local[7],fqv[19]));
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(*ftab[3])(ctx,2,local+10,&ftab[3],fqv[13]); /*gethash*/
	local[10]= w;
	local[11]= w;
	*(ovafptr(local[7],fqv[19])) = local[11];
	goto irtstlIF5521;
irtstlIF5520:
	local[10]= NIL;
irtstlIF5521:
	local[10]= local[4];
	local[11]= local[10];
	*(ovafptr(local[7],fqv[23])) = local[11];
	goto irtstlIF5518;
irtstlIF5517:
	local[10]= *(ovafptr(local[8],fqv[20]));
	w = *(ovafptr(local[8],fqv[19]));
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= local[1];
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(*ftab[4])(ctx,3,local+10,&ftab[4],fqv[14]); /*sethash*/
	local[10]= local[8];
	w = local[2];
	ctx->vsp=local+11;
	local[2] = cons(ctx,local[10],w);
	local[10]= local[2];
irtstlIF5518:
	goto irtstlWHL5514;
irtstlWHX5515:
	local[10]= NIL;
irtstlBLK5516:
	w = NIL;
	goto irtstlWHL5511;
irtstlWHX5512:
	local[6]= NIL;
irtstlBLK5513:
	w = NIL;
	local[4]= loadglobal(fqv[27]);
	ctx->vsp=local+5;
	w=(pointer)INSTANTIATE(ctx,1,local+4); /*instantiate*/
	local[4]= w;
	local[5]= local[4];
	local[6]= fqv[16];
	local[7]= fqv[28];
	local[8]= argv[0];
	local[9]= fqv[18];
	local[10]= local[2];
	local[11]= fqv[17];
	local[12]= local[0];
	local[13]= fqv[29];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	local[13]= fqv[30];
	local[14]= fqv[31];
	local[15]= makeint((eusinteger_t)100L);
	local[16]= makeint((eusinteger_t)100L);
	local[17]= makeint((eusinteger_t)100L);
	ctx->vsp=local+18;
	w=(pointer)LIST(ctx,4,local+14); /*list*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,10,local+5); /*send*/
	w = local[4];
	local[0]= w;
irtstlBLK5504:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtstlCLO5519(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= *(ovafptr(argv[0],fqv[20]));
	local[1]= *(ovafptr(argv[1],fqv[19]));
	ctx->vsp=local+2;
	w=(*ftab[13])(ctx,2,local+0,&ftab[13],fqv[59]); /*v=*/
	local[0]= w;
	if (w==NIL) goto irtstlAND5522;
	local[0]= *(ovafptr(argv[1],fqv[20]));
	local[1]= *(ovafptr(argv[0],fqv[19]));
	ctx->vsp=local+2;
	w=(*ftab[13])(ctx,2,local+0,&ftab[13],fqv[59]); /*v=*/
	local[0]= w;
irtstlAND5522:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*stl2eus-large*/
static pointer irtstlF5331stl2eus_large(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)irtstlF5322stl_make_faces(ctx,1,local+0); /*stl-make-faces*/
	local[0]= w;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)irtstlF5329make_devided_faces_lists(ctx,1,local+1); /*make-devided-faces-lists*/
	local[1]= w;
	local[2]= (pointer)get_sym_func(fqv[115]);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[0]= w;
irtstlBLK5523:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___irtstl(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[116];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtstlIF5524;
	local[0]= fqv[117];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[118],w);
	goto irtstlIF5525;
irtstlIF5524:
	local[0]= fqv[119];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtstlIF5525:
	local[0]= fqv[120];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[121],module,irtstlF5315stl2eus,fqv[122]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[123],module,irtstlF5316write_stl_header,fqv[124]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[125],module,irtstlF5317write_stl_binary_float_val,fqv[126]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[127],module,irtstlF5318write_stl_face,fqv[128]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[129],module,irtstlF5319eus2stl,fqv[130]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[131],module,irtstlF5320read_files_from_solidedge,fqv[132]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[133],module,irtstlF5321read_assembly_config,fqv[134]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[135],module,irtstlF5322stl_make_faces,fqv[136]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[137],module,irtstlF5323safe_vmax,fqv[138]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[139],module,irtstlF5324safe_vmin,fqv[140]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[141],module,irtstlF5325safe_vmaxmin,fqv[142]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[143],module,irtstlF5326devide_faces,fqv[144]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[145],module,irtstlF5327make_boundingbox_from_faces,fqv[146]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[147],module,irtstlF5328small_square_axis,fqv[148]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[149],module,irtstlF5329make_devided_faces_lists,fqv[150]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[115],module,irtstlF5330make_faceset_from_faces,fqv[151]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[152],module,irtstlF5331stl2eus_large,fqv[153]);
	local[0]= fqv[154];
	local[1]= fqv[155];
	ctx->vsp=local+2;
	w=(*ftab[23])(ctx,2,local+0,&ftab[23],fqv[156]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<24; i++) ftab[i]=fcallx;
}
