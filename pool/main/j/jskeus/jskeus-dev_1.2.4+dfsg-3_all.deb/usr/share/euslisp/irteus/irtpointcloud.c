/* ./irtpointcloud.c :  entry=irtpointcloud */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "irtpointcloud.h"
#pragma init (register_irtpointcloud)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___irtpointcloud();
extern pointer build_quote_vector();
static int register_irtpointcloud()
  { add_module_initializer("___irtpointcloud", ___irtpointcloud);}

static pointer irtpointF5572make_random_pointcloud();

/*:init*/
static pointer irtpointM5573pointcloud_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtpointRST5575:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[0], &argv[2], n-2, local+1, 0);
	if (n & (1<<0)) goto irtpointKEY5576;
	local[1] = NIL;
irtpointKEY5576:
	if (n & (1<<1)) goto irtpointKEY5577;
	local[2] = NIL;
irtpointKEY5577:
	if (n & (1<<2)) goto irtpointKEY5578;
	local[3] = NIL;
irtpointKEY5578:
	if (n & (1<<3)) goto irtpointKEY5579;
	local[4] = NIL;
irtpointKEY5579:
	if (n & (1<<4)) goto irtpointKEY5580;
	local[5] = NIL;
irtpointKEY5580:
	if (n & (1<<5)) goto irtpointKEY5581;
	local[6] = NIL;
irtpointKEY5581:
	if (n & (1<<6)) goto irtpointKEY5582;
	local[12]= makeint((eusinteger_t)0L);
	local[13]= makeint((eusinteger_t)1L);
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(pointer)MKFLTVEC(ctx,3,local+12); /*float-vector*/
	local[7] = w;
irtpointKEY5582:
	if (n & (1<<7)) goto irtpointKEY5583;
	local[8] = makeflt(2.0000000000000000000000e+00);
irtpointKEY5583:
	if (n & (1<<8)) goto irtpointKEY5584;
	local[9] = NIL;
irtpointKEY5584:
	if (n & (1<<9)) goto irtpointKEY5585;
	local[10] = makeflt(2.0000000000000000000000e+00);
irtpointKEY5585:
	if (n & (1<<10)) goto irtpointKEY5586;
	local[11] = makeflt(0.0000000000000000000000e+00);
irtpointKEY5586:
	if (local[1]==NIL) goto irtpointCON5588;
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(pointer)LISTP(ctx,1,local+12); /*listp*/
	if (w==NIL) goto irtpointCON5588;
	local[12]= argv[0];
	local[13]= fqv[1];
	local[14]= local[1];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= w;
	goto irtpointCON5587;
irtpointCON5588:
	if (local[1]==NIL) goto irtpointCON5589;
	argv[0]->c.obj.iv[8] = local[1];
	local[12]= argv[0]->c.obj.iv[8];
	goto irtpointCON5587;
irtpointCON5589:
	local[12]= NIL;
irtpointCON5587:
	if (local[2]==NIL) goto irtpointCON5591;
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)LISTP(ctx,1,local+12); /*listp*/
	if (w==NIL) goto irtpointCON5591;
	local[12]= argv[0];
	local[13]= fqv[2];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= w;
	goto irtpointCON5590;
irtpointCON5591:
	if (local[2]==NIL) goto irtpointCON5592;
	argv[0]->c.obj.iv[9] = local[2];
	local[12]= argv[0]->c.obj.iv[9];
	goto irtpointCON5590;
irtpointCON5592:
	argv[0]->c.obj.iv[12] = local[7];
	local[12]= argv[0]->c.obj.iv[12];
	goto irtpointCON5590;
irtpointCON5593:
	local[12]= NIL;
irtpointCON5590:
	if (local[3]==NIL) goto irtpointCON5595;
	local[12]= argv[0]->c.obj.iv[10];
	ctx->vsp=local+13;
	w=(pointer)LISTP(ctx,1,local+12); /*listp*/
	if (w==NIL) goto irtpointCON5595;
	local[12]= argv[0];
	local[13]= fqv[3];
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= w;
	goto irtpointCON5594;
irtpointCON5595:
	if (local[3]==NIL) goto irtpointCON5596;
	argv[0]->c.obj.iv[10] = local[3];
	local[12]= argv[0]->c.obj.iv[10];
	goto irtpointCON5594;
irtpointCON5596:
	local[12]= NIL;
irtpointCON5594:
	if (local[3]==NIL) goto irtpointCON5598;
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(pointer)LISTP(ctx,1,local+12); /*listp*/
	if (w==NIL) goto irtpointCON5598;
	local[12]= argv[0];
	local[13]= fqv[4];
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= w;
	goto irtpointCON5597;
irtpointCON5598:
	if (local[3]==NIL) goto irtpointCON5599;
	argv[0]->c.obj.iv[11] = local[4];
	local[12]= argv[0]->c.obj.iv[11];
	goto irtpointCON5597;
irtpointCON5599:
	local[12]= NIL;
irtpointCON5597:
	argv[0]->c.obj.iv[13] = local[8];
	argv[0]->c.obj.iv[14] = local[10];
	argv[0]->c.obj.iv[15] = local[11];
	ctx->vsp=local+12;
	w=(*ftab[0])(ctx,0,local+12,&ftab[0],fqv[5]); /*make-coords*/
	argv[0]->c.obj.iv[19] = w;
	argv[0]->c.obj.iv[20] = fqv[6];
	if (local[5]==NIL) goto irtpointCON5601;
	if (local[6]==NIL) goto irtpointCON5601;
	local[12]= argv[0];
	local[13]= fqv[7];
	local[14]= local[6];
	local[15]= local[5];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,4,local+12); /*send*/
	local[12]= w;
	goto irtpointCON5600;
irtpointCON5601:
	local[12]= argv[0];
	local[13]= fqv[7];
	if (argv[0]->c.obj.iv[8]==NIL) goto irtpointIF5603;
	local[14]= argv[0]->c.obj.iv[8];
	local[15]= makeint((eusinteger_t)0L);
	ctx->vsp=local+16;
	w=(*ftab[1])(ctx,2,local+14,&ftab[1],fqv[8]); /*array-dimension*/
	local[14]= w;
	goto irtpointIF5604;
irtpointIF5603:
	local[14]= NIL;
irtpointIF5604:
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= w;
	goto irtpointCON5600;
irtpointCON5602:
	local[12]= NIL;
irtpointCON5600:
	if (local[9]==NIL) goto irtpointIF5605;
	local[12]= argv[0];
	local[13]= fqv[9];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	local[13]= argv[0];
	local[14]= fqv[10];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	if (local[12]==NIL) goto irtpointIF5607;
	if (local[13]==NIL) goto irtpointIF5607;
	argv[0]->c.obj.iv[12] = NIL;
	local[14]= local[12];
	local[15]= local[13];
	ctx->vsp=local+16;
	w=(pointer)TIMES(ctx,2,local+14); /***/
	local[14]= w;
	local[15]= makeint((eusinteger_t)3L);
	ctx->vsp=local+16;
	w=(*ftab[2])(ctx,2,local+14,&ftab[2],fqv[11]); /*make-matrix*/
	argv[0]->c.obj.iv[8] = w;
	local[14]= local[12];
	local[15]= local[13];
	ctx->vsp=local+16;
	w=(pointer)TIMES(ctx,2,local+14); /***/
	local[14]= w;
	local[15]= makeint((eusinteger_t)3L);
	ctx->vsp=local+16;
	w=(*ftab[2])(ctx,2,local+14,&ftab[2],fqv[11]); /*make-matrix*/
	argv[0]->c.obj.iv[9] = w;
	local[14]= argv[0]->c.obj.iv[9];
	goto irtpointIF5608;
irtpointIF5607:
	local[14]= NIL;
irtpointIF5608:
	w = local[14];
	local[12]= w;
	goto irtpointIF5606;
irtpointIF5605:
	local[12]= NIL;
irtpointIF5606:
	local[12]= (pointer)get_sym_func(fqv[12]);
	local[13]= argv[0];
	local[14]= *(ovafptr(argv[1],fqv[13]));
	local[15]= fqv[14];
	local[16]= local[0];
	ctx->vsp=local+17;
	w=(pointer)APPLY(ctx,5,local+12); /*apply*/
	w = argv[0];
	local[0]= w;
irtpointBLK5574:
	ctx->vsp=local; return(local[0]);}

/*:reset-box*/
static pointer irtpointM5609pointcloud_reset_box(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[15];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)NUMEQUAL(ctx,2,local+0); /*=*/
	if (w==NIL) goto irtpointIF5611;
	local[0]= fqv[16];
	local[1]= fqv[17];
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,2,local+0); /*list*/
	local[0]= w;
	local[1]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,2,local+0,&ftab[3],fqv[18]); /*make-bounding-box*/
	local[0]= w;
	goto irtpointIF5612;
irtpointIF5611:
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= T;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,2,local+0,&ftab[3],fqv[18]); /*make-bounding-box*/
	local[0]= w;
irtpointIF5612:
	w = local[0];
	local[0]= w;
irtpointBLK5610:
	ctx->vsp=local; return(local[0]);}

/*:box*/
static pointer irtpointM5613pointcloud_box(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[16]!=NIL) goto irtpointIF5615;
	local[0]= argv[0];
	local[1]= fqv[20];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	argv[0]->c.obj.iv[16] = w;
	local[0]= argv[0]->c.obj.iv[16];
	goto irtpointIF5616;
irtpointIF5615:
	local[0]= NIL;
irtpointIF5616:
	w = argv[0]->c.obj.iv[16];
	local[0]= w;
irtpointBLK5614:
	ctx->vsp=local; return(local[0]);}

/*:vertices*/
static pointer irtpointM5617pointcloud_vertices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[21];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[22];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[21];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[23];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,2,local+0); /*list*/
	local[0]= w;
irtpointBLK5618:
	ctx->vsp=local; return(local[0]);}

/*:size*/
static pointer irtpointM5619pointcloud_size(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[8]==NIL) goto irtpointIF5621;
	local[0]= argv[0]->c.obj.iv[8];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,2,local+0,&ftab[1],fqv[8]); /*array-dimension*/
	local[0]= w;
	goto irtpointIF5622;
irtpointIF5621:
	local[0]= makeint((eusinteger_t)0L);
irtpointIF5622:
	w = local[0];
	local[0]= w;
irtpointBLK5620:
	ctx->vsp=local; return(local[0]);}

/*:width*/
static pointer irtpointM5623pointcloud_width(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[18];
	local[0]= w;
irtpointBLK5624:
	ctx->vsp=local; return(local[0]);}

/*:height*/
static pointer irtpointM5625pointcloud_height(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[17];
	local[0]= w;
irtpointBLK5626:
	ctx->vsp=local; return(local[0]);}

/*:size-change*/
static pointer irtpointM5627pointcloud_size_change(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtpointENT5631;}
	local[0]= NIL;
irtpointENT5631:
	if (n>=4) { local[1]=(argv[3]); goto irtpointENT5630;}
	local[1]= NIL;
irtpointENT5630:
irtpointENT5629:
	if (n>4) maerror();
	if (local[0]==NIL) goto irtpointCON5633;
	if (local[1]==NIL) goto irtpointCON5633;
	argv[0]->c.obj.iv[18] = local[0];
	argv[0]->c.obj.iv[17] = local[1];
	local[2]= argv[0]->c.obj.iv[17];
	goto irtpointCON5632;
irtpointCON5633:
	if (local[0]==NIL) goto irtpointCON5634;
	argv[0]->c.obj.iv[18] = local[0];
	argv[0]->c.obj.iv[17] = makeint((eusinteger_t)1L);
	local[2]= argv[0]->c.obj.iv[17];
	goto irtpointCON5632;
irtpointCON5634:
	if (local[1]==NIL) goto irtpointCON5635;
	argv[0]->c.obj.iv[17] = local[1];
	argv[0]->c.obj.iv[18] = makeint((eusinteger_t)1L);
	local[2]= argv[0]->c.obj.iv[18];
	goto irtpointCON5632;
irtpointCON5635:
	if (argv[0]->c.obj.iv[8]==NIL) goto irtpointIF5637;
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(*ftab[1])(ctx,2,local+2,&ftab[1],fqv[8]); /*array-dimension*/
	argv[0]->c.obj.iv[18] = w;
	argv[0]->c.obj.iv[17] = makeint((eusinteger_t)1L);
	local[2]= argv[0]->c.obj.iv[17];
	goto irtpointIF5638;
irtpointIF5637:
	argv[0]->c.obj.iv[18] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[17] = makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[17];
irtpointIF5638:
	goto irtpointCON5632;
irtpointCON5636:
	local[2]= NIL;
irtpointCON5632:
	w = local[2];
	local[0]= w;
irtpointBLK5628:
	ctx->vsp=local; return(local[0]);}

/*:view-coords*/
static pointer irtpointM5639pointcloud_view_coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtpointENT5642;}
	local[0]= NIL;
irtpointENT5642:
irtpointENT5641:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtpointIF5643;
	argv[0]->c.obj.iv[19] = local[0];
	local[1]= argv[0]->c.obj.iv[19];
	goto irtpointIF5644;
irtpointIF5643:
	local[1]= NIL;
irtpointIF5644:
	w = argv[0]->c.obj.iv[19];
	local[0]= w;
irtpointBLK5640:
	ctx->vsp=local; return(local[0]);}

/*:points*/
static pointer irtpointM5645pointcloud_points(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtpointENT5650;}
	local[0]= NIL;
irtpointENT5650:
	if (n>=4) { local[1]=(argv[3]); goto irtpointENT5649;}
	local[1]= NIL;
irtpointENT5649:
	if (n>=5) { local[2]=(argv[4]); goto irtpointENT5648;}
	local[2]= NIL;
irtpointENT5648:
irtpointENT5647:
	if (n>5) maerror();
	if (local[0]==NIL) goto irtpointIF5651;
	local[3]= argv[0];
	local[4]= fqv[7];
	local[5]= local[1];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)LISTP(ctx,1,local+3); /*listp*/
	if (w==NIL) goto irtpointCON5654;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)3L);
	ctx->vsp=local+5;
	w=(*ftab[2])(ctx,2,local+3,&ftab[2],fqv[11]); /*make-matrix*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= NIL;
	local[6]= local[0];
irtpointWHL5655:
	if (local[6]==NIL) goto irtpointWHX5656;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= local[3];
	local[8]= local[4];
	local[9]= local[5];
	local[10]= T;
	ctx->vsp=local+11;
	w=(*ftab[4])(ctx,4,local+7,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[4] = w;
	goto irtpointWHL5655;
irtpointWHX5656:
	local[7]= NIL;
irtpointBLK5657:
	w = NIL;
	argv[0]->c.obj.iv[8] = local[3];
	w = argv[0]->c.obj.iv[8];
	local[3]= w;
	goto irtpointCON5653;
irtpointCON5654:
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(*ftab[5])(ctx,1,local+3,&ftab[5],fqv[25]); /*matrixp*/
	if (w==NIL) goto irtpointCON5658;
	local[3]= local[0];
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,2,local+3,&ftab[1],fqv[8]); /*array-dimension*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)3L);
	ctx->vsp=local+5;
	w=(*ftab[2])(ctx,2,local+3,&ftab[2],fqv[11]); /*make-matrix*/
	local[3]= w;
	local[4]= local[3]->c.obj.iv[1];
	local[5]= local[0]->c.obj.iv[1];
	ctx->vsp=local+6;
	w=(pointer)VECREPLACE(ctx,2,local+4); /*system::vector-replace*/
	argv[0]->c.obj.iv[8] = local[3];
	w = argv[0]->c.obj.iv[8];
	local[3]= w;
	goto irtpointCON5653;
irtpointCON5658:
	local[3]= NIL;
irtpointCON5653:
	goto irtpointIF5652;
irtpointIF5651:
	local[3]= NIL;
irtpointIF5652:
	w = argv[0]->c.obj.iv[8];
	local[0]= w;
irtpointBLK5646:
	ctx->vsp=local; return(local[0]);}

/*:colors*/
static pointer irtpointM5659pointcloud_colors(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtpointENT5662;}
	local[0]= NIL;
irtpointENT5662:
irtpointENT5661:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtpointIF5663;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)LISTP(ctx,1,local+1); /*listp*/
	if (w==NIL) goto irtpointCON5666;
	argv[0]->c.obj.iv[12] = NIL;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)3L);
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[11]); /*make-matrix*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	local[4]= local[0];
irtpointWHL5667:
	if (local[4]==NIL) goto irtpointWHX5668;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[1];
	local[6]= local[2];
	local[7]= local[3];
	local[8]= T;
	ctx->vsp=local+9;
	w=(*ftab[4])(ctx,4,local+5,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[2] = w;
	goto irtpointWHL5667;
irtpointWHX5668:
	local[5]= NIL;
irtpointBLK5669:
	w = NIL;
	argv[0]->c.obj.iv[9] = local[1];
	w = argv[0]->c.obj.iv[9];
	local[1]= w;
	goto irtpointCON5665;
irtpointCON5666:
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(*ftab[5])(ctx,1,local+1,&ftab[5],fqv[25]); /*matrixp*/
	if (w==NIL) goto irtpointCON5670;
	argv[0]->c.obj.iv[12] = NIL;
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,2,local+1,&ftab[1],fqv[8]); /*array-dimension*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)3L);
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[11]); /*make-matrix*/
	local[1]= w;
	local[2]= local[1]->c.obj.iv[1];
	local[3]= local[0]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(pointer)VECREPLACE(ctx,2,local+2); /*system::vector-replace*/
	argv[0]->c.obj.iv[9] = local[1];
	w = argv[0]->c.obj.iv[9];
	local[1]= w;
	goto irtpointCON5665;
irtpointCON5670:
	local[1]= NIL;
irtpointCON5665:
	goto irtpointIF5664;
irtpointIF5663:
	local[1]= NIL;
irtpointIF5664:
	w = argv[0]->c.obj.iv[9];
	local[0]= w;
irtpointBLK5660:
	ctx->vsp=local; return(local[0]);}

/*:normals*/
static pointer irtpointM5671pointcloud_normals(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtpointENT5674;}
	local[0]= NIL;
irtpointENT5674:
irtpointENT5673:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtpointIF5675;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)LISTP(ctx,1,local+1); /*listp*/
	if (w==NIL) goto irtpointCON5678;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)3L);
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[11]); /*make-matrix*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	local[4]= local[0];
irtpointWHL5679:
	if (local[4]==NIL) goto irtpointWHX5680;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[1];
	local[6]= local[2];
	local[7]= local[3];
	local[8]= T;
	ctx->vsp=local+9;
	w=(*ftab[4])(ctx,4,local+5,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[2] = w;
	goto irtpointWHL5679;
irtpointWHX5680:
	local[5]= NIL;
irtpointBLK5681:
	w = NIL;
	argv[0]->c.obj.iv[10] = local[1];
	w = argv[0]->c.obj.iv[10];
	local[1]= w;
	goto irtpointCON5677;
irtpointCON5678:
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(*ftab[5])(ctx,1,local+1,&ftab[5],fqv[25]); /*matrixp*/
	if (w==NIL) goto irtpointCON5682;
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,2,local+1,&ftab[1],fqv[8]); /*array-dimension*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)3L);
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[11]); /*make-matrix*/
	local[1]= w;
	local[2]= local[1]->c.obj.iv[1];
	local[3]= local[0]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(pointer)VECREPLACE(ctx,2,local+2); /*system::vector-replace*/
	argv[0]->c.obj.iv[10] = local[1];
	w = argv[0]->c.obj.iv[10];
	local[1]= w;
	goto irtpointCON5677;
irtpointCON5682:
	local[1]= NIL;
irtpointCON5677:
	goto irtpointIF5676;
irtpointIF5675:
	local[1]= NIL;
irtpointIF5676:
	w = argv[0]->c.obj.iv[10];
	local[0]= w;
irtpointBLK5672:
	ctx->vsp=local; return(local[0]);}

/*:curvatures*/
static pointer irtpointM5683pointcloud_curvatures(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtpointENT5686;}
	local[0]= NIL;
irtpointENT5686:
irtpointENT5685:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtpointIF5687;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)LISTP(ctx,1,local+1); /*listp*/
	if (w==NIL) goto irtpointCON5690;
	local[1]= loadglobal(fqv[26]);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,2,local+1); /*instantiate*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	local[4]= local[0];
irtpointWHL5691:
	if (local[4]==NIL) goto irtpointWHX5692;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[0];
	local[6]= local[2];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)SETELT(ctx,3,local+5); /*setelt*/
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[2] = w;
	goto irtpointWHL5691;
irtpointWHX5692:
	local[5]= NIL;
irtpointBLK5693:
	w = NIL;
	argv[0]->c.obj.iv[11] = local[1];
	w = argv[0]->c.obj.iv[11];
	local[1]= w;
	goto irtpointCON5689;
irtpointCON5690:
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)VECTORP(ctx,1,local+1); /*vectorp*/
	if (w==NIL) goto irtpointCON5694;
	local[1]= loadglobal(fqv[26]);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,2,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)VECREPLACE(ctx,2,local+2); /*system::vector-replace*/
	argv[0]->c.obj.iv[11] = local[1];
	w = argv[0]->c.obj.iv[11];
	local[1]= w;
	goto irtpointCON5689;
irtpointCON5694:
	local[1]= NIL;
irtpointCON5689:
	goto irtpointIF5688;
irtpointIF5687:
	local[1]= NIL;
irtpointIF5688:
	w = argv[0]->c.obj.iv[11];
	local[0]= w;
irtpointBLK5684:
	ctx->vsp=local; return(local[0]);}

/*:point-list*/
static pointer irtpointM5695pointcloud_point_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtpointENT5698;}
	local[0]= NIL;
irtpointENT5698:
irtpointENT5697:
	if (n>3) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[0];
	local[5]= fqv[15];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
irtpointWHL5699:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto irtpointWHX5700;
	local[5]= argv[0]->c.obj.iv[8];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(*ftab[4])(ctx,2,local+5,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[2] = w;
	if (local[0]==NIL) goto irtpointAND5704;
	local[5]= local[2];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[6])(ctx,1,local+5,&ftab[6],fqv[27]); /*c-isnan*/
	if (w==NIL) goto irtpointAND5704;
	goto irtpointIF5702;
irtpointAND5704:
	local[5]= local[2];
	w = local[1];
	ctx->vsp=local+6;
	local[1] = cons(ctx,local[5],w);
	local[5]= local[1];
	goto irtpointIF5703;
irtpointIF5702:
	local[5]= NIL;
irtpointIF5703:
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto irtpointWHL5699;
irtpointWHX5700:
	local[5]= NIL;
irtpointBLK5701:
	w = NIL;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)REVERSE(ctx,1,local+3); /*reverse*/
	local[0]= w;
irtpointBLK5696:
	ctx->vsp=local; return(local[0]);}

/*:color-list*/
static pointer irtpointM5705pointcloud_color_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[9]==NIL) goto irtpointIF5707;
	local[0]= NIL;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[9];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(*ftab[1])(ctx,2,local+2,&ftab[1],fqv[8]); /*array-dimension*/
	local[2]= w;
irtpointWHL5709:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto irtpointWHX5710;
	local[3]= argv[0]->c.obj.iv[9];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(*ftab[4])(ctx,2,local+3,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[3]= w;
	w = local[0];
	ctx->vsp=local+4;
	local[0] = cons(ctx,local[3],w);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto irtpointWHL5709;
irtpointWHX5710:
	local[3]= NIL;
irtpointBLK5711:
	w = NIL;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)REVERSE(ctx,1,local+1); /*reverse*/
	local[0]= w;
	goto irtpointIF5708;
irtpointIF5707:
	local[0]= NIL;
irtpointIF5708:
	w = local[0];
	local[0]= w;
irtpointBLK5706:
	ctx->vsp=local; return(local[0]);}

/*:normal-list*/
static pointer irtpointM5712pointcloud_normal_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[10]==NIL) goto irtpointIF5714;
	local[0]= NIL;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[10];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(*ftab[1])(ctx,2,local+2,&ftab[1],fqv[8]); /*array-dimension*/
	local[2]= w;
irtpointWHL5716:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto irtpointWHX5717;
	local[3]= argv[0]->c.obj.iv[10];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(*ftab[4])(ctx,2,local+3,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[3]= w;
	w = local[0];
	ctx->vsp=local+4;
	local[0] = cons(ctx,local[3],w);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto irtpointWHL5716;
irtpointWHX5717:
	local[3]= NIL;
irtpointBLK5718:
	w = NIL;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)REVERSE(ctx,1,local+1); /*reverse*/
	local[0]= w;
	goto irtpointIF5715;
irtpointIF5714:
	local[0]= NIL;
irtpointIF5715:
	w = local[0];
	local[0]= w;
irtpointBLK5713:
	ctx->vsp=local; return(local[0]);}

/*:curvature-list*/
static pointer irtpointM5719pointcloud_curvature_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[11]==NIL) goto irtpointIF5721;
	local[0]= NIL;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[11];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
irtpointWHL5723:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto irtpointWHX5724;
	local[3]= argv[0]->c.obj.iv[11];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	w = local[0];
	ctx->vsp=local+4;
	local[0] = cons(ctx,local[3],w);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto irtpointWHL5723;
irtpointWHX5724:
	local[3]= NIL;
irtpointBLK5725:
	w = NIL;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)REVERSE(ctx,1,local+1); /*reverse*/
	local[0]= w;
	goto irtpointIF5722;
irtpointIF5721:
	local[0]= NIL;
irtpointIF5722:
	w = local[0];
	local[0]= w;
irtpointBLK5720:
	ctx->vsp=local; return(local[0]);}

/*:centroid*/
static pointer irtpointM5726pointcloud_centroid(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[8];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[7])(ctx,2,local+1,&ftab[7],fqv[28]); /*vector-array-mean*/
	w = local[0];
	local[0]= w;
irtpointBLK5727:
	ctx->vsp=local; return(local[0]);}

/*:set-color*/
static pointer irtpointM5728pointcloud_set_color(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtpointENT5731;}
	local[0]= NIL;
irtpointENT5731:
irtpointENT5730:
	if (n>4) maerror();
	if (argv[2]==NIL) goto irtpointIF5732;
	local[1]= argv[0];
	local[2]= fqv[29];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto irtpointIF5733;
irtpointIF5732:
	local[1]= NIL;
irtpointIF5733:
	if (local[0]==NIL) goto irtpointIF5734;
	local[1]= argv[0];
	local[2]= fqv[30];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto irtpointIF5735;
irtpointIF5734:
	local[1]= NIL;
irtpointIF5735:
	w = local[1];
	local[0]= w;
irtpointBLK5729:
	ctx->vsp=local; return(local[0]);}

/*:point-color*/
static pointer irtpointM5736pointcloud_point_color(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtpointENT5739;}
	local[0]= NIL;
irtpointENT5739:
irtpointENT5738:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtpointIF5740;
	argv[0]->c.obj.iv[12] = local[0];
	local[1]= argv[0]->c.obj.iv[12];
	goto irtpointIF5741;
irtpointIF5740:
	local[1]= NIL;
irtpointIF5741:
	w = argv[0]->c.obj.iv[12];
	local[0]= w;
irtpointBLK5737:
	ctx->vsp=local; return(local[0]);}

/*:point-size*/
static pointer irtpointM5742pointcloud_point_size(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtpointENT5745;}
	local[0]= NIL;
irtpointENT5745:
irtpointENT5744:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtpointIF5746;
	argv[0]->c.obj.iv[13] = local[0];
	local[1]= argv[0]->c.obj.iv[13];
	goto irtpointIF5747;
irtpointIF5746:
	local[1]= NIL;
irtpointIF5747:
	w = argv[0]->c.obj.iv[13];
	local[0]= w;
irtpointBLK5743:
	ctx->vsp=local; return(local[0]);}

/*:axis-length*/
static pointer irtpointM5748pointcloud_axis_length(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtpointENT5751;}
	local[0]= NIL;
irtpointENT5751:
irtpointENT5750:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtpointIF5752;
	argv[0]->c.obj.iv[15] = local[0];
	local[1]= argv[0]->c.obj.iv[15];
	goto irtpointIF5753;
irtpointIF5752:
	local[1]= NIL;
irtpointIF5753:
	w = argv[0]->c.obj.iv[15];
	local[0]= w;
irtpointBLK5749:
	ctx->vsp=local; return(local[0]);}

/*:axis-width*/
static pointer irtpointM5754pointcloud_axis_width(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtpointENT5757;}
	local[0]= NIL;
irtpointENT5757:
irtpointENT5756:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtpointIF5758;
	argv[0]->c.obj.iv[14] = local[0];
	local[1]= argv[0]->c.obj.iv[14];
	goto irtpointIF5759;
irtpointIF5758:
	local[1]= NIL;
irtpointIF5759:
	w = argv[0]->c.obj.iv[14];
	local[0]= w;
irtpointBLK5755:
	ctx->vsp=local; return(local[0]);}

/*:append*/
static pointer irtpointM5760pointcloud_append(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[31], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtpointKEY5762;
	local[0] = T;
irtpointKEY5762:
	w = argv[2];
	if (!!iscons(w)) goto irtpointIF5763;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	argv[2] = w;
	local[1]= argv[2];
	goto irtpointIF5764;
irtpointIF5763:
	local[1]= NIL;
irtpointIF5764:
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= NIL;
	local[6]= NIL;
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	local[7]= w;
	local[8]= argv[2];
	ctx->vsp=local+9;
	w=(pointer)APPEND(ctx,2,local+7); /*append*/
	local[7]= w;
irtpointWHL5765:
	if (local[7]==NIL) goto irtpointWHX5766;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= local[4];
	local[9]= local[6];
	local[10]= fqv[1];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(*ftab[1])(ctx,2,local+9,&ftab[1],fqv[8]); /*array-dimension*/
	local[9]= w;
	if (w!=NIL) goto irtpointOR5768;
	local[9]= makeint((eusinteger_t)0L);
irtpointOR5768:
	local[10]= local[6];
	local[11]= fqv[2];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(*ftab[1])(ctx,2,local+10,&ftab[1],fqv[8]); /*array-dimension*/
	local[10]= w;
	if (w!=NIL) goto irtpointOR5769;
	local[10]= makeint((eusinteger_t)0L);
irtpointOR5769:
	local[11]= local[6];
	local[12]= fqv[3];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(*ftab[1])(ctx,2,local+11,&ftab[1],fqv[8]); /*array-dimension*/
	local[11]= w;
	if (w!=NIL) goto irtpointOR5770;
	local[11]= makeint((eusinteger_t)0L);
irtpointOR5770:
	ctx->vsp=local+12;
	w=(pointer)MAX(ctx,3,local+9); /*max*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[4] = w;
	local[8]= local[1];
	local[9]= local[6];
	local[10]= fqv[1];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(*ftab[1])(ctx,2,local+9,&ftab[1],fqv[8]); /*array-dimension*/
	local[9]= w;
	if (w!=NIL) goto irtpointOR5771;
	local[9]= makeint((eusinteger_t)0L);
irtpointOR5771:
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[1] = w;
	local[8]= local[2];
	local[9]= local[6];
	local[10]= fqv[2];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(*ftab[1])(ctx,2,local+9,&ftab[1],fqv[8]); /*array-dimension*/
	local[9]= w;
	if (w!=NIL) goto irtpointOR5772;
	local[9]= makeint((eusinteger_t)0L);
irtpointOR5772:
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[2] = w;
	local[8]= local[3];
	local[9]= local[6];
	local[10]= fqv[3];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(*ftab[1])(ctx,2,local+9,&ftab[1],fqv[8]); /*array-dimension*/
	local[9]= w;
	if (w!=NIL) goto irtpointOR5773;
	local[9]= makeint((eusinteger_t)0L);
irtpointOR5773:
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[3] = w;
	goto irtpointWHL5765;
irtpointWHX5766:
	local[8]= NIL;
irtpointBLK5767:
	w = NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= NIL;
	local[10]= NIL;
	local[11]= NIL;
	local[12]= makeint((eusinteger_t)0L);
	local[13]= NIL;
	local[14]= local[1];
	local[15]= makeint((eusinteger_t)0L);
	ctx->vsp=local+16;
	w=(pointer)GREATERP(ctx,2,local+14); /*>*/
	if (w==NIL) goto irtpointIF5774;
	local[14]= local[4];
	local[15]= makeint((eusinteger_t)3L);
	ctx->vsp=local+16;
	w=(*ftab[2])(ctx,2,local+14,&ftab[2],fqv[11]); /*make-matrix*/
	local[14]= w;
	goto irtpointIF5775;
irtpointIF5774:
	local[14]= NIL;
irtpointIF5775:
	local[6] = local[14];
	local[14]= local[2];
	local[15]= makeint((eusinteger_t)0L);
	ctx->vsp=local+16;
	w=(pointer)GREATERP(ctx,2,local+14); /*>*/
	if (w==NIL) goto irtpointIF5776;
	local[14]= local[4];
	local[15]= makeint((eusinteger_t)3L);
	ctx->vsp=local+16;
	w=(*ftab[2])(ctx,2,local+14,&ftab[2],fqv[11]); /*make-matrix*/
	local[14]= w;
	goto irtpointIF5777;
irtpointIF5776:
	local[14]= NIL;
irtpointIF5777:
	local[7] = local[14];
	local[14]= local[3];
	local[15]= makeint((eusinteger_t)0L);
	ctx->vsp=local+16;
	w=(pointer)GREATERP(ctx,2,local+14); /*>*/
	if (w==NIL) goto irtpointIF5778;
	local[14]= local[4];
	local[15]= makeint((eusinteger_t)3L);
	ctx->vsp=local+16;
	w=(*ftab[2])(ctx,2,local+14,&ftab[2],fqv[11]); /*make-matrix*/
	local[14]= w;
	goto irtpointIF5779;
irtpointIF5778:
	local[14]= NIL;
irtpointIF5779:
	local[8] = local[14];
	local[14]= NIL;
	local[15]= argv[0];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	local[15]= w;
	local[16]= argv[2];
	ctx->vsp=local+17;
	w=(pointer)APPEND(ctx,2,local+15); /*append*/
	local[15]= w;
irtpointWHL5780:
	if (local[15]==NIL) goto irtpointWHX5781;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15] = (w)->c.cons.cdr;
	w = local[16];
	local[14] = w;
	local[16]= local[14];
	local[17]= fqv[1];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[9] = w;
	local[16]= local[14];
	local[17]= fqv[2];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[10] = w;
	local[16]= local[14];
	local[17]= fqv[3];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[11] = w;
	local[16]= local[9];
	local[17]= makeint((eusinteger_t)0L);
	ctx->vsp=local+18;
	w=(*ftab[1])(ctx,2,local+16,&ftab[1],fqv[8]); /*array-dimension*/
	local[16]= w;
	if (w!=NIL) goto irtpointOR5783;
	local[16]= makeint((eusinteger_t)0L);
irtpointOR5783:
	local[17]= local[10];
	local[18]= makeint((eusinteger_t)0L);
	ctx->vsp=local+19;
	w=(*ftab[1])(ctx,2,local+17,&ftab[1],fqv[8]); /*array-dimension*/
	local[17]= w;
	if (w!=NIL) goto irtpointOR5784;
	local[17]= makeint((eusinteger_t)0L);
irtpointOR5784:
	local[18]= local[11];
	local[19]= makeint((eusinteger_t)0L);
	ctx->vsp=local+20;
	w=(*ftab[1])(ctx,2,local+18,&ftab[1],fqv[8]); /*array-dimension*/
	local[18]= w;
	if (w!=NIL) goto irtpointOR5785;
	local[18]= makeint((eusinteger_t)0L);
irtpointOR5785:
	ctx->vsp=local+19;
	w=(pointer)MAX(ctx,3,local+16); /*max*/
	local[13] = w;
	if (local[9]==NIL) goto irtpointIF5786;
	local[16]= local[6]->c.obj.iv[1];
	local[17]= local[9]->c.obj.iv[1];
	local[18]= makeint((eusinteger_t)3L);
	local[19]= local[12];
	ctx->vsp=local+20;
	w=(pointer)TIMES(ctx,2,local+18); /***/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)VECREPLACE(ctx,3,local+16); /*system::vector-replace*/
	local[16]= w;
	goto irtpointIF5787;
irtpointIF5786:
	local[16]= NIL;
irtpointIF5787:
	if (local[10]==NIL) goto irtpointIF5788;
	local[16]= local[7]->c.obj.iv[1];
	local[17]= local[10]->c.obj.iv[1];
	local[18]= makeint((eusinteger_t)3L);
	local[19]= local[12];
	ctx->vsp=local+20;
	w=(pointer)TIMES(ctx,2,local+18); /***/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)VECREPLACE(ctx,3,local+16); /*system::vector-replace*/
	local[16]= w;
	goto irtpointIF5789;
irtpointIF5788:
	local[16]= NIL;
irtpointIF5789:
	if (local[11]==NIL) goto irtpointIF5790;
	local[16]= local[8]->c.obj.iv[1];
	local[17]= local[11]->c.obj.iv[1];
	local[18]= makeint((eusinteger_t)3L);
	local[19]= local[12];
	ctx->vsp=local+20;
	w=(pointer)TIMES(ctx,2,local+18); /***/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)VECREPLACE(ctx,3,local+16); /*system::vector-replace*/
	local[16]= w;
	goto irtpointIF5791;
irtpointIF5790:
	local[16]= NIL;
irtpointIF5791:
	local[16]= local[12];
	local[17]= local[13];
	ctx->vsp=local+18;
	w=(pointer)PLUS(ctx,2,local+16); /*+*/
	local[12] = w;
	goto irtpointWHL5780;
irtpointWHX5781:
	local[16]= NIL;
irtpointBLK5782:
	w = NIL;
	if (local[0]==NIL) goto irtpointIF5792;
	local[14]= loadglobal(fqv[32]);
	ctx->vsp=local+15;
	w=(pointer)INSTANTIATE(ctx,1,local+14); /*instantiate*/
	local[14]= w;
	local[15]= local[14];
	local[16]= fqv[14];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	w = local[14];
	local[5] = w;
	local[14]= local[5];
	goto irtpointIF5793;
irtpointIF5792:
	local[5] = argv[0];
	local[14]= local[5];
irtpointIF5793:
	local[14]= local[5];
	local[15]= fqv[1];
	local[16]= local[6];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[14]= local[5];
	local[15]= fqv[2];
	local[16]= local[7];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[14]= local[5];
	local[15]= fqv[3];
	local[16]= local[8];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[14]= local[5];
	local[15]= fqv[7];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= local[5];
	local[15]= fqv[33];
	local[16]= argv[0];
	local[17]= fqv[33];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[16]= w;
	local[17]= fqv[34];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[14]= local[5];
	local[15]= fqv[29];
	local[16]= argv[0];
	local[17]= fqv[29];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[14]= local[5];
	local[15]= fqv[35];
	local[16]= argv[0];
	local[17]= fqv[35];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[14]= local[5];
	local[15]= fqv[36];
	local[16]= argv[0];
	local[17]= fqv[36];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[14]= local[5];
	local[15]= fqv[37];
	local[16]= argv[0];
	local[17]= fqv[37];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	w = local[5];
	local[0]= w;
irtpointBLK5761:
	ctx->vsp=local; return(local[0]);}

/*:clear-color*/
static pointer irtpointM5794pointcloud_clear_color(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[38];
	ctx->vsp=local+1;
	w=(*ftab[8])(ctx,1,local+0,&ftab[8],fqv[39]); /*warn*/
	local[0]= w;
irtpointBLK5795:
	ctx->vsp=local; return(local[0]);}

/*:clear-normal*/
static pointer irtpointM5796pointcloud_clear_normal(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[40];
	ctx->vsp=local+1;
	w=(*ftab[8])(ctx,1,local+0,&ftab[8],fqv[39]); /*warn*/
	local[0]= w;
irtpointBLK5797:
	ctx->vsp=local; return(local[0]);}

/*:nfilter*/
static pointer irtpointM5798pointcloud_nfilter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtpointRST5800:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[41]);
	local[2]= argv[0];
	local[3]= fqv[42];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[0]= w;
irtpointBLK5799:
	ctx->vsp=local; return(local[0]);}

/*:filter*/
static pointer irtpointM5801pointcloud_filter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtpointRST5803:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[43], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtpointKEY5804;
	local[1] = NIL;
irtpointKEY5804:
	local[2]= (pointer)get_sym_func(fqv[41]);
	local[3]= argv[0];
	local[4]= fqv[44];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,4,local+2); /*apply*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[45];
	local[5]= local[2];
	local[6]= fqv[46];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,5,local+3); /*send*/
	local[0]= w;
irtpointBLK5802:
	ctx->vsp=local; return(local[0]);}

/*:filter-with-indices*/
static pointer irtpointM5805pointcloud_filter_with_indices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[47], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtpointKEY5807;
	local[0] = NIL;
irtpointKEY5807:
	if (n & (1<<1)) goto irtpointKEY5808;
	local[1] = NIL;
irtpointKEY5808:
	local[2]= argv[0];
	local[3]= fqv[15];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	if (argv[0]->c.obj.iv[9]==NIL) goto irtpointIF5809;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[8]= w;
	goto irtpointIF5810;
irtpointIF5809:
	local[8]= NIL;
irtpointIF5810:
	if (argv[0]->c.obj.iv[10]==NIL) goto irtpointIF5811;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)MKFLTVEC(ctx,3,local+9); /*float-vector*/
	local[9]= w;
	goto irtpointIF5812;
irtpointIF5811:
	local[9]= NIL;
irtpointIF5812:
	local[10]= NIL;
	local[11]= makeint((eusinteger_t)0L);
	if (local[1]==NIL) goto irtpointIF5813;
	local[12]= NIL;
	local[13]= makeint((eusinteger_t)0L);
	local[14]= local[2];
irtpointWHL5815:
	local[15]= local[13];
	w = local[14];
	if ((eusinteger_t)local[15] >= (eusinteger_t)w) goto irtpointWHX5816;
	local[15]= local[2];
	local[16]= local[13];
	local[17]= makeint((eusinteger_t)1L);
	ctx->vsp=local+18;
	w=(pointer)MINUS(ctx,3,local+15); /*-*/
	local[15]= w;
	w = local[12];
	ctx->vsp=local+16;
	local[12] = cons(ctx,local[15],w);
	local[15]= local[13];
	ctx->vsp=local+16;
	w=(pointer)ADD1(ctx,1,local+15); /*1+*/
	local[13] = w;
	goto irtpointWHL5815;
irtpointWHX5816:
	local[15]= NIL;
irtpointBLK5817:
	w = NIL;
	local[13]= local[12];
	local[14]= argv[2];
	ctx->vsp=local+15;
	w=(*ftab[9])(ctx,2,local+13,&ftab[9],fqv[48]); /*set-difference*/
	argv[2] = w;
	w = argv[2];
	local[12]= w;
	goto irtpointIF5814;
irtpointIF5813:
	local[12]= NIL;
irtpointIF5814:
	local[12]= argv[2];
	ctx->vsp=local+13;
	w=(pointer)LENGTH(ctx,1,local+12); /*length*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)3L);
	ctx->vsp=local+14;
	w=(*ftab[2])(ctx,2,local+12,&ftab[2],fqv[11]); /*make-matrix*/
	local[3] = w;
	if (argv[0]->c.obj.iv[9]==NIL) goto irtpointIF5818;
	local[12]= argv[2];
	ctx->vsp=local+13;
	w=(pointer)LENGTH(ctx,1,local+12); /*length*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)3L);
	ctx->vsp=local+14;
	w=(*ftab[2])(ctx,2,local+12,&ftab[2],fqv[11]); /*make-matrix*/
	local[12]= w;
	goto irtpointIF5819;
irtpointIF5818:
	local[12]= NIL;
irtpointIF5819:
	local[4] = local[12];
	if (argv[0]->c.obj.iv[10]==NIL) goto irtpointIF5820;
	local[12]= argv[2];
	ctx->vsp=local+13;
	w=(pointer)LENGTH(ctx,1,local+12); /*length*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)3L);
	ctx->vsp=local+14;
	w=(*ftab[2])(ctx,2,local+12,&ftab[2],fqv[11]); /*make-matrix*/
	local[12]= w;
	goto irtpointIF5821;
irtpointIF5820:
	local[12]= NIL;
irtpointIF5821:
	local[5] = local[12];
	if (argv[0]->c.obj.iv[11]==NIL) goto irtpointIF5822;
	local[12]= loadglobal(fqv[26]);
	local[13]= argv[2];
	ctx->vsp=local+14;
	w=(pointer)LENGTH(ctx,1,local+13); /*length*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)INSTANTIATE(ctx,2,local+12); /*instantiate*/
	local[12]= w;
	goto irtpointIF5823;
irtpointIF5822:
	local[12]= NIL;
irtpointIF5823:
	local[6] = local[12];
	local[12]= argv[2];
	ctx->vsp=local+13;
	w=(pointer)LISTP(ctx,1,local+12); /*listp*/
	if (w==NIL) goto irtpointCON5825;
	local[12]= NIL;
	local[13]= argv[2];
irtpointWHL5826:
	if (local[13]==NIL) goto irtpointWHX5827;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13] = (w)->c.cons.cdr;
	w = local[14];
	local[12] = w;
	local[14]= argv[0]->c.obj.iv[8];
	local[15]= local[12];
	local[16]= local[7];
	ctx->vsp=local+17;
	w=(*ftab[4])(ctx,3,local+14,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[14]= local[3];
	local[15]= local[11];
	local[16]= local[7];
	local[17]= T;
	ctx->vsp=local+18;
	w=(*ftab[4])(ctx,4,local+14,&ftab[4],fqv[24]); /*c-matrix-row*/
	if (argv[0]->c.obj.iv[9]==NIL) goto irtpointIF5829;
	local[14]= argv[0]->c.obj.iv[9];
	local[15]= local[12];
	local[16]= local[8];
	ctx->vsp=local+17;
	w=(*ftab[4])(ctx,3,local+14,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[14]= local[4];
	local[15]= local[11];
	local[16]= local[8];
	local[17]= T;
	ctx->vsp=local+18;
	w=(*ftab[4])(ctx,4,local+14,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[14]= w;
	goto irtpointIF5830;
irtpointIF5829:
	local[14]= NIL;
irtpointIF5830:
	if (argv[0]->c.obj.iv[10]==NIL) goto irtpointIF5831;
	local[14]= argv[0]->c.obj.iv[10];
	local[15]= local[12];
	local[16]= local[9];
	ctx->vsp=local+17;
	w=(*ftab[4])(ctx,3,local+14,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[14]= local[5];
	local[15]= local[11];
	local[16]= local[9];
	local[17]= T;
	ctx->vsp=local+18;
	w=(*ftab[4])(ctx,4,local+14,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[14]= w;
	goto irtpointIF5832;
irtpointIF5831:
	local[14]= NIL;
irtpointIF5832:
	if (argv[0]->c.obj.iv[11]==NIL) goto irtpointIF5833;
	local[14]= local[6];
	local[15]= local[11];
	local[16]= argv[0]->c.obj.iv[11];
	local[17]= local[12];
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)SETELT(ctx,3,local+14); /*setelt*/
	local[14]= w;
	goto irtpointIF5834;
irtpointIF5833:
	local[14]= NIL;
irtpointIF5834:
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(pointer)ADD1(ctx,1,local+14); /*1+*/
	local[11] = w;
	goto irtpointWHL5826;
irtpointWHX5827:
	local[14]= NIL;
irtpointBLK5828:
	w = NIL;
	local[12]= w;
	goto irtpointCON5824;
irtpointCON5825:
	local[12]= NIL;
	local[13]= makeint((eusinteger_t)0L);
	local[14]= argv[2];
	ctx->vsp=local+15;
	w=(pointer)LENGTH(ctx,1,local+14); /*length*/
	local[14]= w;
irtpointWHL5836:
	local[15]= local[13];
	w = local[14];
	if ((eusinteger_t)local[15] >= (eusinteger_t)w) goto irtpointWHX5837;
	local[15]= argv[2];
	local[16]= local[13];
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[12] = w;
	local[15]= argv[0]->c.obj.iv[8];
	local[16]= local[12];
	local[17]= local[7];
	ctx->vsp=local+18;
	w=(*ftab[4])(ctx,3,local+15,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[15]= local[3];
	local[16]= local[11];
	local[17]= local[7];
	local[18]= T;
	ctx->vsp=local+19;
	w=(*ftab[4])(ctx,4,local+15,&ftab[4],fqv[24]); /*c-matrix-row*/
	if (argv[0]->c.obj.iv[9]==NIL) goto irtpointIF5839;
	local[15]= argv[0]->c.obj.iv[9];
	local[16]= local[12];
	local[17]= local[8];
	ctx->vsp=local+18;
	w=(*ftab[4])(ctx,3,local+15,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[15]= local[4];
	local[16]= local[11];
	local[17]= local[8];
	local[18]= T;
	ctx->vsp=local+19;
	w=(*ftab[4])(ctx,4,local+15,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[15]= w;
	goto irtpointIF5840;
irtpointIF5839:
	local[15]= NIL;
irtpointIF5840:
	if (argv[0]->c.obj.iv[10]==NIL) goto irtpointIF5841;
	local[15]= argv[0]->c.obj.iv[10];
	local[16]= local[12];
	local[17]= local[9];
	ctx->vsp=local+18;
	w=(*ftab[4])(ctx,3,local+15,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[15]= local[5];
	local[16]= local[11];
	local[17]= local[9];
	local[18]= T;
	ctx->vsp=local+19;
	w=(*ftab[4])(ctx,4,local+15,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[15]= w;
	goto irtpointIF5842;
irtpointIF5841:
	local[15]= NIL;
irtpointIF5842:
	if (argv[0]->c.obj.iv[11]==NIL) goto irtpointIF5843;
	local[15]= local[6];
	local[16]= local[11];
	local[17]= argv[0]->c.obj.iv[11];
	local[18]= local[12];
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)SETELT(ctx,3,local+15); /*setelt*/
	local[15]= w;
	goto irtpointIF5844;
irtpointIF5843:
	local[15]= NIL;
irtpointIF5844:
	local[15]= local[11];
	ctx->vsp=local+16;
	w=(pointer)ADD1(ctx,1,local+15); /*1+*/
	local[11] = w;
	local[15]= local[13];
	ctx->vsp=local+16;
	w=(pointer)ADD1(ctx,1,local+15); /*1+*/
	local[13] = w;
	goto irtpointWHL5836;
irtpointWHX5837:
	local[15]= NIL;
irtpointBLK5838:
	w = NIL;
	local[12]= w;
	goto irtpointCON5824;
irtpointCON5835:
	local[12]= NIL;
irtpointCON5824:
	if (local[0]==NIL) goto irtpointIF5845;
	local[12]= loadglobal(fqv[32]);
	ctx->vsp=local+13;
	w=(pointer)INSTANTIATE(ctx,1,local+12); /*instantiate*/
	local[12]= w;
	local[13]= local[12];
	local[14]= fqv[14];
	local[15]= fqv[1];
	local[16]= local[3];
	local[17]= fqv[2];
	local[18]= local[4];
	local[19]= fqv[3];
	local[20]= local[5];
	local[21]= fqv[4];
	local[22]= local[6];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,10,local+13); /*send*/
	w = local[12];
	local[12]= w;
	local[13]= argv[0]->c.obj.iv[19];
	local[14]= fqv[34];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	local[14]= w;
	*(ovafptr(local[12],fqv[49])) = local[14];
	local[13]= local[12];
	local[14]= fqv[50];
	local[15]= argv[0];
	local[16]= fqv[51];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	w = local[12];
	local[12]= w;
	goto irtpointIF5846;
irtpointIF5845:
	argv[0]->c.obj.iv[8] = local[3];
	if (local[4]==NIL) goto irtpointIF5847;
	argv[0]->c.obj.iv[9] = local[4];
	local[12]= argv[0]->c.obj.iv[9];
	goto irtpointIF5848;
irtpointIF5847:
	local[12]= NIL;
irtpointIF5848:
	if (local[5]==NIL) goto irtpointIF5849;
	argv[0]->c.obj.iv[10] = local[5];
	local[12]= argv[0]->c.obj.iv[10];
	goto irtpointIF5850;
irtpointIF5849:
	local[12]= NIL;
irtpointIF5850:
	if (local[6]==NIL) goto irtpointIF5851;
	argv[0]->c.obj.iv[11] = local[6];
	local[12]= argv[0]->c.obj.iv[11];
	goto irtpointIF5852;
irtpointIF5851:
	local[12]= NIL;
irtpointIF5852:
	local[12]= argv[0];
	local[13]= fqv[7];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= argv[0];
irtpointIF5846:
	w = local[12];
	local[0]= w;
irtpointBLK5806:
	ctx->vsp=local; return(local[0]);}

/*:filtered-indices*/
static pointer irtpointM5853pointcloud_filtered_indices(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[52], &argv[2], n-2, local+0, 1);
	if (n & (1<<0)) goto irtpointKEY5855;
	local[0] = NIL;
irtpointKEY5855:
	if (n & (1<<1)) goto irtpointKEY5856;
	local[1] = NIL;
irtpointKEY5856:
	if (n & (1<<2)) goto irtpointKEY5857;
	local[2] = NIL;
irtpointKEY5857:
	if (n & (1<<3)) goto irtpointKEY5858;
	local[3] = NIL;
irtpointKEY5858:
	if (n & (1<<4)) goto irtpointKEY5859;
	local[4] = NIL;
irtpointKEY5859:
	if (n & (1<<5)) goto irtpointKEY5860;
	local[5] = NIL;
irtpointKEY5860:
	if (n & (1<<6)) goto irtpointKEY5861;
	local[6] = NIL;
irtpointKEY5861:
	local[7]= NIL;
	local[8]= argv[0];
	local[9]= fqv[15];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= loadglobal(fqv[26]);
	local[10]= makeint((eusinteger_t)3L);
	ctx->vsp=local+11;
	w=(pointer)INSTANTIATE(ctx,2,local+9); /*instantiate*/
	local[9]= w;
	if (argv[0]->c.obj.iv[9]==NIL) goto irtpointIF5862;
	local[10]= loadglobal(fqv[26]);
	local[11]= makeint((eusinteger_t)3L);
	ctx->vsp=local+12;
	w=(pointer)INSTANTIATE(ctx,2,local+10); /*instantiate*/
	local[10]= w;
	goto irtpointIF5863;
irtpointIF5862:
	local[10]= NIL;
irtpointIF5863:
	if (argv[0]->c.obj.iv[10]==NIL) goto irtpointIF5864;
	local[11]= loadglobal(fqv[26]);
	local[12]= makeint((eusinteger_t)3L);
	ctx->vsp=local+13;
	w=(pointer)INSTANTIATE(ctx,2,local+11); /*instantiate*/
	local[11]= w;
	goto irtpointIF5865;
irtpointIF5864:
	local[11]= NIL;
irtpointIF5865:
	local[12]= makeint((eusinteger_t)0L);
	local[13]= local[8];
irtpointWHL5866:
	local[14]= local[12];
	w = local[13];
	if ((eusinteger_t)local[14] >= (eusinteger_t)w) goto irtpointWHX5867;
	local[14]= argv[0]->c.obj.iv[8];
	local[15]= local[12];
	local[16]= local[9];
	ctx->vsp=local+17;
	w=(*ftab[4])(ctx,3,local+14,&ftab[4],fqv[24]); /*c-matrix-row*/
	if (local[10]==NIL) goto irtpointIF5869;
	local[14]= argv[0]->c.obj.iv[9];
	local[15]= local[12];
	local[16]= local[10];
	ctx->vsp=local+17;
	w=(*ftab[4])(ctx,3,local+14,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[14]= w;
	goto irtpointIF5870;
irtpointIF5869:
	local[14]= NIL;
irtpointIF5870:
	if (local[11]==NIL) goto irtpointIF5871;
	local[14]= argv[0]->c.obj.iv[10];
	local[15]= local[12];
	local[16]= local[11];
	ctx->vsp=local+17;
	w=(*ftab[4])(ctx,3,local+14,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[14]= w;
	goto irtpointIF5872;
irtpointIF5871:
	local[14]= NIL;
irtpointIF5872:
	if (local[0]==NIL) goto irtpointOR5875;
	local[14]= local[0];
	local[15]= local[9];
	ctx->vsp=local+16;
	w=(pointer)FUNCALL(ctx,2,local+14); /*funcall*/
	if (w!=NIL) goto irtpointOR5875;
	goto irtpointIF5873;
irtpointOR5875:
	if (local[1]==NIL) goto irtpointOR5876;
	if (local[10]==NIL) goto irtpointOR5876;
	local[14]= local[1];
	local[15]= local[10];
	ctx->vsp=local+16;
	w=(pointer)FUNCALL(ctx,2,local+14); /*funcall*/
	if (w!=NIL) goto irtpointOR5876;
	goto irtpointIF5873;
irtpointOR5876:
	if (local[2]==NIL) goto irtpointOR5877;
	if (local[11]==NIL) goto irtpointOR5877;
	local[14]= local[2];
	local[15]= local[11];
	ctx->vsp=local+16;
	w=(pointer)FUNCALL(ctx,2,local+14); /*funcall*/
	if (w!=NIL) goto irtpointOR5877;
	goto irtpointIF5873;
irtpointOR5877:
	if (local[3]==NIL) goto irtpointOR5878;
	if (local[10]==NIL) goto irtpointOR5878;
	local[14]= local[3];
	local[15]= local[9];
	local[16]= local[10];
	ctx->vsp=local+17;
	w=(pointer)FUNCALL(ctx,3,local+14); /*funcall*/
	if (w!=NIL) goto irtpointOR5878;
	goto irtpointIF5873;
irtpointOR5878:
	if (local[4]==NIL) goto irtpointOR5879;
	if (local[11]==NIL) goto irtpointOR5879;
	local[14]= local[4];
	local[15]= local[9];
	local[16]= local[11];
	ctx->vsp=local+17;
	w=(pointer)FUNCALL(ctx,3,local+14); /*funcall*/
	if (w!=NIL) goto irtpointOR5879;
	goto irtpointIF5873;
irtpointOR5879:
	if (local[5]==NIL) goto irtpointOR5880;
	if (local[10]==NIL) goto irtpointOR5880;
	if (local[11]==NIL) goto irtpointOR5880;
	local[14]= local[5];
	local[15]= local[9];
	local[16]= local[10];
	local[17]= local[11];
	ctx->vsp=local+18;
	w=(pointer)FUNCALL(ctx,4,local+14); /*funcall*/
	if (w!=NIL) goto irtpointOR5880;
	goto irtpointIF5873;
irtpointOR5880:
	if (local[6]!=NIL) goto irtpointIF5881;
	local[14]= local[12];
	w = local[7];
	ctx->vsp=local+15;
	local[7] = cons(ctx,local[14],w);
	local[14]= local[7];
	goto irtpointIF5882;
irtpointIF5881:
	local[14]= NIL;
irtpointIF5882:
	goto irtpointIF5874;
irtpointIF5873:
	if (local[6]==NIL) goto irtpointIF5883;
	local[14]= local[12];
	w = local[7];
	ctx->vsp=local+15;
	local[7] = cons(ctx,local[14],w);
	local[14]= local[7];
	goto irtpointIF5884;
irtpointIF5883:
	local[14]= NIL;
irtpointIF5884:
irtpointIF5874:
	local[14]= local[12];
	ctx->vsp=local+15;
	w=(pointer)ADD1(ctx,1,local+14); /*1+*/
	local[12] = w;
	goto irtpointWHL5866;
irtpointWHX5867:
	local[14]= NIL;
irtpointBLK5868:
	w = NIL;
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(pointer)NREVERSE(ctx,1,local+12); /*nreverse*/
	local[0]= w;
irtpointBLK5854:
	ctx->vsp=local; return(local[0]);}

/*:viewangle-inlier*/
static pointer irtpointM5885pointcloud_viewangle_inlier(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[53], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtpointKEY5887;
	local[0] = makeflt(0.0000000000000000000000e+00);
irtpointKEY5887:
	if (n & (1<<1)) goto irtpointKEY5888;
	local[1] = makeflt(4.4000000000000000000000e+01);
irtpointKEY5888:
	if (n & (1<<2)) goto irtpointKEY5889;
	local[2] = makeflt(3.5000000000000000000000e+01);
irtpointKEY5889:
	local[3]= local[1];
	local[4]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[10])(ctx,1,local+3,&ftab[10],fqv[54]); /*deg2rad*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)TAN(ctx,1,local+3); /*tan*/
	local[3]= w;
	local[4]= local[2];
	local[5]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[10])(ctx,1,local+4,&ftab[10],fqv[54]); /*deg2rad*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)TAN(ctx,1,local+4); /*tan*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[5]= w;
	local[6]= argv[0];
	local[7]= fqv[15];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[8];
	local[8]= NIL;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= local[6];
irtpointWHL5890:
	local[11]= local[9];
	w = local[10];
	if ((eusinteger_t)local[11] >= (eusinteger_t)w) goto irtpointWHX5891;
	local[11]= local[7];
	local[12]= local[9];
	local[13]= local[5];
	ctx->vsp=local+14;
	w=(*ftab[4])(ctx,3,local+11,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[11]= local[5];
	local[12]= makeint((eusinteger_t)2L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)GREATERP(ctx,2,local+11); /*>*/
	if (w==NIL) goto irtpointIF5893;
	local[11]= local[5];
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= local[5];
	local[13]= makeint((eusinteger_t)2L);
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)ABS(ctx,1,local+11); /*abs*/
	local[11]= w;
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)LESSP(ctx,2,local+11); /*<*/
	if (w==NIL) goto irtpointIF5893;
	local[11]= local[5];
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= local[5];
	local[13]= makeint((eusinteger_t)2L);
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)ABS(ctx,1,local+11); /*abs*/
	local[11]= w;
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(pointer)LESSP(ctx,2,local+11); /*<*/
	if (w==NIL) goto irtpointIF5893;
	local[11]= local[9];
	w = local[8];
	ctx->vsp=local+12;
	local[8] = cons(ctx,local[11],w);
	local[11]= local[8];
	goto irtpointIF5894;
irtpointIF5893:
	local[11]= NIL;
irtpointIF5894:
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[9] = w;
	goto irtpointWHL5890;
irtpointWHX5891:
	local[11]= NIL;
irtpointBLK5892:
	w = NIL;
	local[9]= local[8];
	ctx->vsp=local+10;
	w=(pointer)NREVERSE(ctx,1,local+9); /*nreverse*/
	local[0]= w;
irtpointBLK5886:
	ctx->vsp=local; return(local[0]);}

/*:image-position-inlier*/
static pointer irtpointM5895pointcloud_image_position_inlier(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[55], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtpointKEY5897;
	local[0] = NIL;
irtpointKEY5897:
	if (n & (1<<1)) goto irtpointKEY5898;
	local[1] = makeint((eusinteger_t)144L);
irtpointKEY5898:
	if (n & (1<<2)) goto irtpointKEY5899;
	local[2] = makeint((eusinteger_t)176L);
irtpointKEY5899:
	if (n & (1<<3)) goto irtpointKEY5900;
	local[6]= local[1];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)EUSFLOAT(ctx,1,local+6); /*float*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[3] = w;
irtpointKEY5900:
	if (n & (1<<4)) goto irtpointKEY5901;
	local[6]= local[2];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)EUSFLOAT(ctx,1,local+6); /*float*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[4] = w;
irtpointKEY5901:
	if (n & (1<<5)) goto irtpointKEY5902;
	local[5] = NIL;
irtpointKEY5902:
	local[6]= NIL;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[1];
irtpointWHL5903:
	local[9]= local[7];
	w = local[8];
	if ((eusinteger_t)local[9] >= (eusinteger_t)w) goto irtpointWHX5904;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= local[2];
irtpointWHL5906:
	local[11]= local[9];
	w = local[10];
	if ((eusinteger_t)local[11] >= (eusinteger_t)w) goto irtpointWHX5907;
	if (local[0]==NIL) goto irtpointIF5909;
	local[11]= local[0];
	local[12]= local[9];
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(pointer)FUNCALL(ctx,3,local+11); /*funcall*/
	if (w==NIL) goto irtpointIF5909;
	if (local[5]!=NIL) goto irtpointIF5911;
	local[11]= local[7];
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	local[11]= w;
	w = local[6];
	ctx->vsp=local+12;
	local[6] = cons(ctx,local[11],w);
	local[11]= local[6];
	goto irtpointIF5912;
irtpointIF5911:
	local[11]= NIL;
irtpointIF5912:
	goto irtpointIF5910;
irtpointIF5909:
	if (local[5]==NIL) goto irtpointIF5913;
	local[11]= local[7];
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	local[11]= w;
	w = local[6];
	ctx->vsp=local+12;
	local[6] = cons(ctx,local[11],w);
	local[11]= local[6];
	goto irtpointIF5914;
irtpointIF5913:
	local[11]= NIL;
irtpointIF5914:
irtpointIF5910:
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[9] = w;
	goto irtpointWHL5906;
irtpointWHX5907:
	local[11]= NIL;
irtpointBLK5908:
	w = NIL;
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[7] = w;
	goto irtpointWHL5903;
irtpointWHX5904:
	local[9]= NIL;
irtpointBLK5905:
	w = NIL;
	local[7]= local[6];
	ctx->vsp=local+8;
	w=(pointer)NREVERSE(ctx,1,local+7); /*nreverse*/
	local[0]= w;
irtpointBLK5896:
	ctx->vsp=local; return(local[0]);}

/*:image-circle-filter*/
static pointer irtpointM5915pointcloud_image_circle_filter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[56], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtpointKEY5917;
	local[0] = makeint((eusinteger_t)144L);
irtpointKEY5917:
	if (n & (1<<1)) goto irtpointKEY5918;
	local[1] = makeint((eusinteger_t)176L);
irtpointKEY5918:
	if (n & (1<<2)) goto irtpointKEY5919;
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)EUSFLOAT(ctx,1,local+6); /*float*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[2] = w;
irtpointKEY5919:
	if (n & (1<<3)) goto irtpointKEY5920;
	local[6]= local[1];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)EUSFLOAT(ctx,1,local+6); /*float*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[3] = w;
irtpointKEY5920:
	if (n & (1<<4)) goto irtpointKEY5921;
	local[4] = NIL;
irtpointKEY5921:
	if (n & (1<<5)) goto irtpointKEY5922;
	local[5] = NIL;
irtpointKEY5922:
	local[6]= argv[0];
	local[7]= fqv[45];
	local[8]= argv[0];
	local[9]= fqv[57];
	local[10]= fqv[58];
	ctx->vsp=local+11;
	local[11]= makeclosure(codevec,quotevec,irtpointCLO5923,env,argv,local);
	local[12]= fqv[10];
	local[13]= local[0];
	local[14]= fqv[9];
	local[15]= local[1];
	local[16]= fqv[59];
	local[17]= local[5];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,10,local+8); /*send*/
	local[8]= w;
	local[9]= fqv[46];
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,5,local+6); /*send*/
	local[0]= w;
irtpointBLK5916:
	ctx->vsp=local; return(local[0]);}

/*:step-inlier*/
static pointer irtpointM5924pointcloud_step_inlier(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[4];
irtpointTAG5927:
	local[3]= local[2];
	local[4]= argv[0]->c.obj.iv[17];
	ctx->vsp=local+5;
	w=(pointer)GREQP(ctx,2,local+3); /*>=*/
	if (w==NIL) goto irtpointIF5928;
	w = NIL;
	ctx->vsp=local+3;
	local[2]=w;
	goto irtpointBLK5926;
	goto irtpointIF5929;
irtpointIF5928:
	local[3]= NIL;
irtpointIF5929:
	local[3]= argv[0]->c.obj.iv[18];
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[1] = w;
	local[3]= argv[3];
irtpointTAG5931:
	local[4]= local[3];
	local[5]= argv[0]->c.obj.iv[18];
	ctx->vsp=local+6;
	w=(pointer)GREQP(ctx,2,local+4); /*>=*/
	if (w==NIL) goto irtpointIF5932;
	w = NIL;
	ctx->vsp=local+4;
	local[3]=w;
	goto irtpointBLK5930;
	goto irtpointIF5933;
irtpointIF5932:
	local[4]= NIL;
irtpointIF5933:
	local[4]= local[3];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[4]= w;
	w = local[0];
	ctx->vsp=local+5;
	local[0] = cons(ctx,local[4],w);
	local[4]= local[3];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[4]= w;
	local[3] = local[4];
	w = NIL;
	ctx->vsp=local+4;
	goto irtpointTAG5931;
	w = NIL;
	local[3]= w;
irtpointBLK5930:
	local[3]= local[2];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	local[3]= w;
	local[2] = local[3];
	w = NIL;
	ctx->vsp=local+3;
	goto irtpointTAG5927;
	w = NIL;
	local[2]= w;
irtpointBLK5926:
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)NREVERSE(ctx,1,local+2); /*nreverse*/
	local[0]= w;
irtpointBLK5925:
	ctx->vsp=local; return(local[0]);}

/*:step*/
static pointer irtpointM5934pointcloud_step(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[60], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtpointKEY5936;
	local[0] = NIL;
irtpointKEY5936:
	if (n & (1<<1)) goto irtpointKEY5937;
	local[1] = NIL;
irtpointKEY5937:
	local[2]= argv[0]->c.obj.iv[18];
	ctx->vsp=local+3;
	w=(pointer)SUB1(ctx,1,local+2); /*1-*/
	local[2]= w;
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)MOD(ctx,2,local+2); /*mod*/
	local[2]= w;
	local[3]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)FLOOR(ctx,1,local+2); /*floor*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[17];
	ctx->vsp=local+4;
	w=(pointer)SUB1(ctx,1,local+3); /*1-*/
	local[3]= w;
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)MOD(ctx,2,local+3); /*mod*/
	local[3]= w;
	local[4]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)FLOOR(ctx,1,local+3); /*floor*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[18];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[4]= w;
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[17];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[5]= w;
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	local[6]= argv[0];
	local[7]= fqv[61];
	local[8]= argv[2];
	local[9]= local[2];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,5,local+6); /*send*/
	local[6]= w;
	local[7]= local[0];
	if (local[7]!=NIL) goto irtpointCON5938;
irtpointCON5939:
	local[7]= argv[0];
	local[8]= fqv[45];
	local[9]= local[6];
	local[10]= fqv[46];
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,5,local+7); /*send*/
	local[7]= w;
	local[8]= local[7];
	local[9]= fqv[15];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= local[7];
	local[9]= fqv[7];
	local[10]= local[4];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	w = local[7];
	local[7]= w;
	goto irtpointCON5938;
irtpointCON5940:
	local[7]= NIL;
irtpointCON5938:
	w = local[7];
	local[0]= w;
irtpointBLK5935:
	ctx->vsp=local; return(local[0]);}

/*:generate-color-histogram-hs*/
static pointer irtpointM5941pointcloud_generate_color_histogram_hs(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[62], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtpointKEY5943;
	local[0] = makeint((eusinteger_t)9L);
irtpointKEY5943:
	if (n & (1<<1)) goto irtpointKEY5944;
	local[1] = makeint((eusinteger_t)7L);
irtpointKEY5944:
	if (n & (1<<2)) goto irtpointKEY5945;
	local[8]= makeflt(3.6000000000000000000000e+02);
	w = makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+9;
	local[2] = cons(ctx,local[8],w);
irtpointKEY5945:
	if (n & (1<<3)) goto irtpointKEY5946;
	local[8]= makeflt(1.0000000000000000000000e+00);
	w = makeflt(1.4999999999999991118216e-01);
	ctx->vsp=local+9;
	local[3] = cons(ctx,local[8],w);
irtpointKEY5946:
	if (n & (1<<4)) goto irtpointKEY5947;
	local[8]= makeflt(1.0000000000000000000000e+00);
	w = makeflt(2.5000000000000000000000e-01);
	ctx->vsp=local+9;
	local[4] = cons(ctx,local[8],w);
irtpointKEY5947:
	if (n & (1<<5)) goto irtpointKEY5948;
	local[5] = NIL;
irtpointKEY5948:
	if (n & (1<<6)) goto irtpointKEY5949;
	local[6] = makeflt(2.5500000000000000000000e+02);
irtpointKEY5949:
	if (n & (1<<7)) goto irtpointKEY5950;
	local[7] = makeint((eusinteger_t)1L);
irtpointKEY5950:
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtpointFLET5951,env,argv,local);
	local[9]= argv[0];
	local[10]= fqv[2];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	local[10]= local[0];
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,2,local+10); /*list*/
	local[10]= w;
	local[11]= fqv[63];
	local[12]= loadglobal(fqv[26]);
	ctx->vsp=local+13;
	w=(*ftab[11])(ctx,3,local+10,&ftab[11],fqv[64]); /*make-array*/
	local[10]= w;
	local[11]= local[10]->c.obj.iv[1];
	local[12]= loadglobal(fqv[26]);
	local[13]= makeint((eusinteger_t)3L);
	ctx->vsp=local+14;
	w=(pointer)INSTANTIATE(ctx,2,local+12); /*instantiate*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)0L);
	local[14]= makeint((eusinteger_t)0L);
	local[15]= argv[0];
	local[16]= fqv[15];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
irtpointWHL5952:
	local[16]= local[14];
	w = local[15];
	if ((eusinteger_t)local[16] >= (eusinteger_t)w) goto irtpointWHX5953;
	local[16]= local[9];
	local[17]= local[14];
	local[18]= local[12];
	ctx->vsp=local+19;
	w=(*ftab[4])(ctx,3,local+16,&ftab[4],fqv[24]); /*c-matrix-row*/
	if (local[6]==NIL) goto irtpointIF5955;
	local[16]= local[6];
	local[17]= local[12];
	local[18]= local[12];
	ctx->vsp=local+19;
	w=(pointer)SCALEVEC(ctx,3,local+16); /*scale*/
	local[16]= w;
	goto irtpointIF5956;
irtpointIF5955:
	local[16]= NIL;
irtpointIF5956:
	local[16]= local[12];
	ctx->vsp=local+17;
	w=(*ftab[12])(ctx,1,local+16,&ftab[12],fqv[65]); /*rgb2his*/
	local[16]= w;
	if (local[5]==NIL) goto irtpointIF5957;
	local[17]= local[16];
	local[18]= makeint((eusinteger_t)0L);
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	local[18]= local[17];
	local[19]= local[5];
	ctx->vsp=local+20;
	w=(pointer)PLUS(ctx,2,local+18); /*+*/
	local[18]= w;
	local[19]= makeflt(3.6000000000000000000000e+02);
	ctx->vsp=local+20;
	w=(pointer)GREQP(ctx,2,local+18); /*>=*/
	if (w==NIL) goto irtpointIF5959;
	local[18]= local[16];
	local[19]= makeint((eusinteger_t)0L);
	local[20]= local[17];
	local[21]= local[5];
	local[22]= makeflt(-3.6000000000000000000000e+02);
	ctx->vsp=local+23;
	w=(pointer)PLUS(ctx,3,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)SETELT(ctx,3,local+18); /*setelt*/
	local[18]= w;
	goto irtpointIF5960;
irtpointIF5959:
	local[18]= local[17];
	local[19]= local[5];
	ctx->vsp=local+20;
	w=(pointer)PLUS(ctx,2,local+18); /*+*/
	local[18]= w;
	local[19]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+20;
	w=(pointer)LSEQP(ctx,2,local+18); /*<=*/
	if (w==NIL) goto irtpointIF5961;
	local[18]= local[16];
	local[19]= makeint((eusinteger_t)0L);
	local[20]= local[17];
	local[21]= local[5];
	local[22]= makeflt(3.6000000000000000000000e+02);
	ctx->vsp=local+23;
	w=(pointer)PLUS(ctx,3,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)SETELT(ctx,3,local+18); /*setelt*/
	local[18]= w;
	goto irtpointIF5962;
irtpointIF5961:
	local[18]= local[16];
	local[19]= makeint((eusinteger_t)0L);
	local[20]= local[17];
	local[21]= local[5];
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)SETELT(ctx,3,local+18); /*setelt*/
	local[18]= w;
irtpointIF5962:
irtpointIF5960:
	w = local[18];
	local[17]= w;
	goto irtpointIF5958;
irtpointIF5957:
	local[17]= NIL;
irtpointIF5958:
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	local[18]= local[16];
	local[19]= makeint((eusinteger_t)0L);
	ctx->vsp=local+20;
	w=(pointer)ELT(ctx,2,local+18); /*elt*/
	local[18]= w;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19]= (w)->c.cons.cdr;
	ctx->vsp=local+20;
	w=(pointer)GREQP(ctx,3,local+17); /*>=*/
	if (w==NIL) goto irtpointIF5963;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	local[18]= local[16];
	local[19]= makeint((eusinteger_t)1L);
	ctx->vsp=local+20;
	w=(pointer)ELT(ctx,2,local+18); /*elt*/
	local[18]= w;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19]= (w)->c.cons.cdr;
	ctx->vsp=local+20;
	w=(pointer)GREQP(ctx,3,local+17); /*>=*/
	if (w==NIL) goto irtpointIF5963;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	local[18]= local[16];
	local[19]= makeint((eusinteger_t)2L);
	ctx->vsp=local+20;
	w=(pointer)ELT(ctx,2,local+18); /*elt*/
	local[18]= w;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19]= (w)->c.cons.cdr;
	ctx->vsp=local+20;
	w=(pointer)GREQP(ctx,3,local+17); /*>=*/
	if (w==NIL) goto irtpointIF5963;
	local[17]= local[13];
	ctx->vsp=local+18;
	w=(pointer)ADD1(ctx,1,local+17); /*1+*/
	local[13] = w;
	local[17]= local[16];
	local[18]= makeint((eusinteger_t)0L);
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	local[18]= local[0];
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.cdr;
	w = local[8];
	ctx->vsp=local+21;
	w=irtpointFLET5951(ctx,4,local+17,w);
	local[17]= w;
	local[18]= local[16];
	local[19]= makeint((eusinteger_t)2L);
	ctx->vsp=local+20;
	w=(pointer)ELT(ctx,2,local+18); /*elt*/
	local[18]= w;
	local[19]= local[1];
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21]= (w)->c.cons.cdr;
	w = local[8];
	ctx->vsp=local+22;
	w=irtpointFLET5951(ctx,4,local+18,w);
	local[18]= w;
	local[19]= local[11];
	local[20]= local[17];
	local[21]= local[1];
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	local[21]= local[18];
	ctx->vsp=local+22;
	w=(pointer)PLUS(ctx,2,local+20); /*+*/
	local[20]= w;
	local[21]= makeint((eusinteger_t)1L);
	local[22]= local[11];
	local[23]= local[17];
	local[24]= local[1];
	ctx->vsp=local+25;
	w=(pointer)TIMES(ctx,2,local+23); /***/
	local[23]= w;
	local[24]= local[18];
	ctx->vsp=local+25;
	w=(pointer)PLUS(ctx,2,local+23); /*+*/
	local[23]= w;
	ctx->vsp=local+24;
	w=(pointer)ELT(ctx,2,local+22); /*elt*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)PLUS(ctx,2,local+21); /*+*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)SETELT(ctx,3,local+19); /*setelt*/
	local[17]= w;
	goto irtpointIF5964;
irtpointIF5963:
	local[17]= NIL;
irtpointIF5964:
	w = local[17];
	local[16]= local[14];
	ctx->vsp=local+17;
	w=(pointer)ADD1(ctx,1,local+16); /*1+*/
	local[14] = w;
	goto irtpointWHL5952;
irtpointWHX5953:
	local[16]= NIL;
irtpointBLK5954:
	w = NIL;
	if (local[7]==NIL) goto irtpointOR5967;
	local[14]= local[13];
	local[15]= local[7];
	ctx->vsp=local+16;
	w=(pointer)GREQP(ctx,2,local+14); /*>=*/
	if (w!=NIL) goto irtpointOR5967;
	goto irtpointIF5965;
irtpointOR5967:
	local[14]= makeflt(1.0000000000000000000000e+00);
	local[15]= local[13];
	ctx->vsp=local+16;
	w=(pointer)QUOTIENT(ctx,2,local+14); /*/*/
	local[14]= w;
	local[15]= local[10];
	local[16]= local[10];
	ctx->vsp=local+17;
	w=(*ftab[13])(ctx,3,local+14,&ftab[13],fqv[66]); /*scale-matrix*/
	local[14]= w;
	goto irtpointIF5966;
irtpointIF5965:
	local[10] = NIL;
	local[14]= local[10];
irtpointIF5966:
	w = local[10];
	local[0]= w;
irtpointBLK5942:
	ctx->vsp=local; return(local[0]);}

/*:copy-from*/
static pointer irtpointM5968pointcloud_copy_from(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[1];
	local[2]= argv[2];
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[2];
	local[2]= argv[2];
	local[3]= fqv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[3];
	local[2]= argv[2];
	local[3]= fqv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[2];
	local[1]= fqv[10];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	argv[0]->c.obj.iv[17] = w;
	local[0]= argv[2];
	local[1]= fqv[9];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	argv[0]->c.obj.iv[18] = w;
	local[0]= argv[0];
	local[1]= fqv[67];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[50];
	local[2]= argv[2];
	local[3]= fqv[51];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= *(ovafptr(argv[2],fqv[49]));
	local[1]= fqv[34];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	argv[0]->c.obj.iv[19] = w;
	local[0]= argv[0];
	local[1]= fqv[51];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	w = argv[0];
	local[0]= w;
irtpointBLK5969:
	ctx->vsp=local; return(local[0]);}

/*:transform-points*/
static pointer irtpointM5970pointcloud_transform_points(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[68], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtpointKEY5972;
	local[0] = NIL;
irtpointKEY5972:
	if (local[0]==NIL) goto irtpointIF5973;
	local[1]= loadglobal(fqv[32]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[14];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	w = local[1];
	local[1]= w;
	goto irtpointIF5974;
irtpointIF5973:
	local[1]= argv[0];
irtpointIF5974:
	if (local[0]==NIL) goto irtpointIF5975;
	local[2]= local[1];
	local[3]= fqv[69];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto irtpointIF5976;
irtpointIF5975:
	local[2]= NIL;
irtpointIF5976:
	local[2]= *(ovafptr(local[1],fqv[49]));
	local[3]= fqv[50];
	local[4]= argv[2];
	local[5]= fqv[51];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= fqv[70];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= local[1];
	local[3]= fqv[1];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[2];
	local[4]= fqv[71];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[2];
	local[5]= fqv[72];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[2];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(*ftab[14])(ctx,4,local+3,&ftab[14],fqv[73]); /*c-coords-transform-vector*/
	local[2]= local[1];
	local[3]= fqv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	if (w==NIL) goto irtpointIF5977;
	local[2]= local[1];
	local[3]= fqv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[3]= w;
	local[4]= argv[2];
	local[5]= fqv[72];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[2];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(*ftab[14])(ctx,4,local+3,&ftab[14],fqv[73]); /*c-coords-transform-vector*/
	local[2]= w;
	goto irtpointIF5978;
irtpointIF5977:
	local[2]= NIL;
irtpointIF5978:
	w = local[1];
	local[0]= w;
irtpointBLK5971:
	ctx->vsp=local; return(local[0]);}

/*:set-offset*/
static pointer irtpointM5979pointcloud_set_offset(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[74], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtpointKEY5981;
	local[0] = NIL;
irtpointKEY5981:
	local[1]= argv[0];
	local[2]= fqv[75];
	local[3]= argv[2];
	local[4]= fqv[46];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[0]= w;
irtpointBLK5980:
	ctx->vsp=local; return(local[0]);}

/*:convert-to-world*/
static pointer irtpointM5982pointcloud_convert_to_world(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[76], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtpointKEY5984;
	local[0] = NIL;
irtpointKEY5984:
	local[1]= argv[0];
	local[2]= fqv[77];
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,0,local+3,&ftab[0],fqv[5]); /*make-coords*/
	local[3]= w;
	local[4]= fqv[46];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[0]= w;
irtpointBLK5983:
	ctx->vsp=local; return(local[0]);}

/*:move-origin-to*/
static pointer irtpointM5985pointcloud_move_origin_to(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[78], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtpointKEY5987;
	local[0] = NIL;
irtpointKEY5987:
	local[1]= argv[0];
	local[2]= fqv[75];
	local[3]= argv[0];
	local[4]= fqv[34];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= fqv[50];
	local[5]= argv[2];
	local[6]= fqv[79];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= fqv[70];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	local[4]= fqv[46];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[67];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	if (argv[0]->c.obj.iv[3]==NIL) goto irtpointCON5989;
	if (local[0]!=NIL) goto irtpointCON5989;
	local[2]= argv[0];
	local[3]= fqv[50];
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= fqv[51];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= fqv[79];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= fqv[50];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto irtpointCON5988;
irtpointCON5989:
	local[2]= local[1];
	local[3]= fqv[50];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto irtpointCON5988;
irtpointCON5990:
	local[2]= NIL;
irtpointCON5988:
	local[2]= argv[0];
	local[3]= fqv[51];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	w = local[1];
	local[0]= w;
irtpointBLK5986:
	ctx->vsp=local; return(local[0]);}

/*:drawnormalmode*/
static pointer irtpointM5991pointcloud_drawnormalmode(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtpointENT5994;}
	local[0]= NIL;
irtpointENT5994:
irtpointENT5993:
	if (n>3) maerror();
	local[1]= local[0];
	local[2]= local[1];
	if (fqv[80]!=local[2]) goto irtpointIF5995;
	argv[0]->c.obj.iv[20] = NIL;
	local[2]= argv[0]->c.obj.iv[20];
	goto irtpointIF5996;
irtpointIF5995:
	if (T==NIL) goto irtpointIF5997;
	argv[0]->c.obj.iv[20] = local[0];
	local[2]= argv[0]->c.obj.iv[20];
	goto irtpointIF5998;
irtpointIF5997:
	local[2]= NIL;
irtpointIF5998:
irtpointIF5996:
	w = local[2];
	w = argv[0]->c.obj.iv[20];
	local[0]= w;
irtpointBLK5992:
	ctx->vsp=local; return(local[0]);}

/*:transparent*/
static pointer irtpointM5999pointcloud_transparent(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtpointENT6002;}
	local[0]= NIL;
irtpointENT6002:
irtpointENT6001:
	if (n>3) maerror();
	argv[0]->c.obj.iv[21] = local[0];
	if (local[0]==NIL) goto irtpointIF6003;
	if (argv[0]->c.obj.iv[9]==NIL) goto irtpointIF6003;
	local[1]= argv[0];
	local[2]= fqv[15];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= local[1];
	local[3]= makeint((eusinteger_t)4L);
	ctx->vsp=local+4;
	w=(*ftab[2])(ctx,2,local+2,&ftab[2],fqv[11]); /*make-matrix*/
	argv[0]->c.obj.iv[22] = w;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= local[1];
irtpointWHL6005:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto irtpointWHX6006;
	local[4]= argv[0]->c.obj.iv[22];
	local[5]= local[2];
	local[6]= loadglobal(fqv[26]);
	local[7]= argv[0]->c.obj.iv[9];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(*ftab[15])(ctx,2,local+7,&ftab[15],fqv[81]); /*matrix-row*/
	local[7]= w;
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)CONCATENATE(ctx,3,local+6); /*concatenate*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[16])(ctx,3,local+4,&ftab[16],fqv[82]); /*set-matrix-row*/
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto irtpointWHL6005;
irtpointWHX6006:
	local[4]= NIL;
irtpointBLK6007:
	w = NIL;
	local[1]= w;
	goto irtpointIF6004;
irtpointIF6003:
	local[1]= NIL;
irtpointIF6004:
	w = local[0];
	local[0]= w;
irtpointBLK6000:
	ctx->vsp=local; return(local[0]);}

/*:draw*/
static pointer irtpointM6008pointcloud_draw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	if (argv[0]->c.obj.iv[21]==NIL) goto irtpointIF6010;
	local[0]= makeint((eusinteger_t)0L);
	ctx->vsp=local+1;
	w=(*ftab[17])(ctx,1,local+0,&ftab[17],fqv[83]); /*gl:gldepthmask*/
	local[0]= makeint((eusinteger_t)3042L);
	ctx->vsp=local+1;
	w=(*ftab[18])(ctx,1,local+0,&ftab[18],fqv[84]); /*gl:glenable*/
	local[0]= makeint((eusinteger_t)770L);
	local[1]= makeint((eusinteger_t)771L);
	ctx->vsp=local+2;
	w=(*ftab[19])(ctx,2,local+0,&ftab[19],fqv[85]); /*gl:glblendfunc*/
	local[0]= w;
	goto irtpointIF6011;
irtpointIF6010:
	local[0]= NIL;
irtpointIF6011:
	local[0]= makeint((eusinteger_t)4294967295L);
	ctx->vsp=local+1;
	w=(*ftab[20])(ctx,1,local+0,&ftab[20],fqv[86]); /*gl:glpushattrib*/
	if (argv[2]==NIL) goto irtpointIF6012;
	local[0]= argv[2];
	local[1]= fqv[87];
	local[2]= fqv[88];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto irtpointIF6013;
irtpointIF6012:
	local[0]= NIL;
irtpointIF6013:
	local[0]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+1;
	w=(*ftab[21])(ctx,1,local+0,&ftab[21],fqv[89]); /*gl:gldisable*/
	ctx->vsp=local+0;
	w=(*ftab[22])(ctx,0,local+0,&ftab[22],fqv[90]); /*gl:glpushmatrix*/
	local[0]= argv[0];
	local[1]= fqv[51];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[91];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= loadglobal(fqv[92]);
	ctx->vsp=local+2;
	w=(pointer)TRANSPOSE(ctx,2,local+0); /*transpose*/
	local[0]= w->c.obj.iv[1];
	ctx->vsp=local+1;
	w=(*ftab[23])(ctx,1,local+0,&ftab[23],fqv[93]); /*gl:glmultmatrixf*/
	local[0]= argv[0]->c.obj.iv[15];
	local[1]= makeflt(9.9999999999999977795540e-02);
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w==NIL) goto irtpointIF6014;
	local[0]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+1;
	w=(pointer)EUSFLOAT(ctx,1,local+0); /*float*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[24])(ctx,1,local+0,&ftab[24],fqv[94]); /*gl:gllinewidth*/
	local[0]= makeint((eusinteger_t)1L);
	ctx->vsp=local+1;
	w=(*ftab[25])(ctx,1,local+0,&ftab[25],fqv[95]); /*gl:glbegin*/
	local[0]= makeint((eusinteger_t)1L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[26])(ctx,1,local+0,&ftab[26],fqv[96]); /*gl:glcolor3fv*/
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[27])(ctx,1,local+0,&ftab[27],fqv[97]); /*gl:glvertex3fv*/
	local[0]= argv[0]->c.obj.iv[15];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[27])(ctx,1,local+0,&ftab[27],fqv[97]); /*gl:glvertex3fv*/
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)1L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[26])(ctx,1,local+0,&ftab[26],fqv[96]); /*gl:glcolor3fv*/
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[27])(ctx,1,local+0,&ftab[27],fqv[97]); /*gl:glvertex3fv*/
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[0]->c.obj.iv[15];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[27])(ctx,1,local+0,&ftab[27],fqv[97]); /*gl:glvertex3fv*/
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[26])(ctx,1,local+0,&ftab[26],fqv[96]); /*gl:glcolor3fv*/
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[27])(ctx,1,local+0,&ftab[27],fqv[97]); /*gl:glvertex3fv*/
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[15];
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[27])(ctx,1,local+0,&ftab[27],fqv[97]); /*gl:glvertex3fv*/
	ctx->vsp=local+0;
	w=(*ftab[28])(ctx,0,local+0,&ftab[28],fqv[98]); /*gl:glend*/
	local[0]= w;
	goto irtpointIF6015;
irtpointIF6014:
	local[0]= NIL;
irtpointIF6015:
	local[0]= argv[0]->c.obj.iv[13];
	ctx->vsp=local+1;
	w=(pointer)EUSFLOAT(ctx,1,local+0); /*float*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[29])(ctx,1,local+0,&ftab[29],fqv[99]); /*gl:glpointsize*/
	local[0]= argv[0];
	local[1]= fqv[15];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(*ftab[30])(ctx,2,local+0,&ftab[30],fqv[100]); /*/=*/
	if (w==NIL) goto irtpointIF6016;
	local[0]= argv[0]->c.obj.iv[9];
	local[1]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+2;
	w=(pointer)VECTORP(ctx,1,local+1); /*vectorp*/
	if (w==NIL) goto irtpointCON6019;
	local[0] = NIL;
	local[1]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+2;
	w=(*ftab[26])(ctx,1,local+1,&ftab[26],fqv[96]); /*gl:glcolor3fv*/
	local[1]= w;
	goto irtpointCON6018;
irtpointCON6019:
	local[1]= argv[0]->c.obj.iv[12];
	local[2]= fqv[101];
	local[3]= fqv[102];
	local[4]= fqv[103];
	local[5]= fqv[104];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,4,local+2); /*list*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[31])(ctx,2,local+1,&ftab[31],fqv[105]); /*member*/
	if (w==NIL) goto irtpointCON6020;
	local[1]= NIL;
	local[2]= argv[0]->c.obj.iv[12];
	local[3]= local[2];
	w = fqv[106];
	if (memq(local[3],w)==NIL) goto irtpointIF6021;
	local[1] = makeint((eusinteger_t)2L);
	local[3]= local[1];
	goto irtpointIF6022;
irtpointIF6021:
	local[3]= local[2];
	if (fqv[102]!=local[3]) goto irtpointIF6023;
	local[1] = makeint((eusinteger_t)0L);
	local[3]= local[1];
	goto irtpointIF6024;
irtpointIF6023:
	local[3]= local[2];
	if (fqv[103]!=local[3]) goto irtpointIF6025;
	local[1] = makeint((eusinteger_t)1L);
	local[3]= local[1];
	goto irtpointIF6026;
irtpointIF6025:
	local[3]= NIL;
irtpointIF6026:
irtpointIF6024:
irtpointIF6022:
	w = local[3];
	local[2]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+3;
	w=(*ftab[32])(ctx,1,local+2,&ftab[32],fqv[107]); /*copy-matrix*/
	local[0] = w;
	local[2]= local[0]->c.obj.iv[1];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[3]= w;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= argv[0];
	local[7]= fqv[21];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= fqv[23];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[4] = w;
	local[6]= argv[0];
	local[7]= fqv[21];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= fqv[22];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[5] = w;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= local[0];
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(*ftab[1])(ctx,2,local+7,&ftab[1],fqv[8]); /*array-dimension*/
	local[7]= w;
irtpointWHL6027:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto irtpointWHX6028;
	local[8]= local[2];
	local[9]= makeint((eusinteger_t)-280L);
	local[10]= argv[0]->c.obj.iv[8];
	local[11]= local[6];
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(pointer)AREF(ctx,3,local+10); /*aref*/
	local[10]= w;
	local[11]= local[4];
	ctx->vsp=local+12;
	w=(pointer)MINUS(ctx,2,local+10); /*-*/
	local[10]= w;
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)QUOTIENT(ctx,2,local+10); /*/*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	local[10]= makeflt(1.0000000000000000000000e+00);
	local[11]= makeflt(1.0000000000000000000000e+00);
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(*ftab[33])(ctx,4,local+9,&ftab[33],fqv[108]); /*his2rgb*/
	local[9]= w;
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(*ftab[34])(ctx,2,local+9,&ftab[34],fqv[109]); /*normalize-vector*/
	local[9]= w;
	local[10]= fqv[110];
	local[11]= local[6];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)3L)); i=intval(local[11]);
		local[11]=(makeint(i * j));}
	ctx->vsp=local+12;
	w=(*ftab[35])(ctx,4,local+8,&ftab[35],fqv[111]); /*replace*/
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto irtpointWHL6027;
irtpointWHX6028:
	local[8]= NIL;
irtpointBLK6029:
	w = NIL;
	local[1]= w;
	goto irtpointCON6018;
irtpointCON6020:
	local[1]= NIL;
irtpointCON6018:
	local[1]= makeint((eusinteger_t)32884L);
	ctx->vsp=local+2;
	w=(*ftab[36])(ctx,1,local+1,&ftab[36],fqv[112]); /*gl::glenableclientstate*/
	if (local[0]==NIL) goto irtpointIF6030;
	local[1]= makeint((eusinteger_t)32886L);
	ctx->vsp=local+2;
	w=(*ftab[36])(ctx,1,local+1,&ftab[36],fqv[112]); /*gl::glenableclientstate*/
	local[1]= w;
	goto irtpointIF6031;
irtpointIF6030:
	local[1]= NIL;
irtpointIF6031:
	if (local[0]==NIL) goto irtpointIF6032;
	if (argv[0]->c.obj.iv[21]==NIL) goto irtpointIF6034;
	local[1]= makeint((eusinteger_t)4L);
	goto irtpointIF6035;
irtpointIF6034:
	local[1]= makeint((eusinteger_t)3L);
irtpointIF6035:
	local[2]= makeint((eusinteger_t)5130L);
	local[3]= makeint((eusinteger_t)0L);
	if (argv[0]->c.obj.iv[21]==NIL) goto irtpointIF6036;
	local[4]= argv[0]->c.obj.iv[22];
	goto irtpointIF6037;
irtpointIF6036:
	local[4]= local[0];
irtpointIF6037:
	local[4]= local[4]->c.obj.iv[1];
	ctx->vsp=local+5;
	w=(*ftab[37])(ctx,4,local+1,&ftab[37],fqv[113]); /*gl::glcolorpointer*/
	local[1]= w;
	goto irtpointIF6033;
irtpointIF6032:
	local[1]= NIL;
irtpointIF6033:
	local[1]= makeint((eusinteger_t)3L);
	local[2]= makeint((eusinteger_t)5130L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[0]->c.obj.iv[8]->c.obj.iv[1];
	ctx->vsp=local+5;
	w=(*ftab[38])(ctx,4,local+1,&ftab[38],fqv[114]); /*gl::glvertexpointer*/
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,2,local+3,&ftab[1],fqv[8]); /*array-dimension*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[39])(ctx,3,local+1,&ftab[39],fqv[115]); /*gl::gldrawarrays*/
	local[1]= makeint((eusinteger_t)32884L);
	ctx->vsp=local+2;
	w=(*ftab[40])(ctx,1,local+1,&ftab[40],fqv[116]); /*gl::gldisableclientstate*/
	if (local[0]==NIL) goto irtpointIF6038;
	local[1]= makeint((eusinteger_t)32886L);
	ctx->vsp=local+2;
	w=(*ftab[40])(ctx,1,local+1,&ftab[40],fqv[116]); /*gl::gldisableclientstate*/
	local[1]= w;
	goto irtpointIF6039;
irtpointIF6038:
	local[1]= NIL;
irtpointIF6039:
	if (argv[0]->c.obj.iv[10]==NIL) goto irtpointIF6040;
	if (argv[0]->c.obj.iv[20]==NIL) goto irtpointIF6040;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,3,local+1); /*float-vector*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,3,local+4); /*float-vector*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(*ftab[25])(ctx,1,local+5,&ftab[25],fqv[95]); /*gl:glbegin*/
	if (local[0]!=NIL) goto irtpointIF6042;
	local[4] = argv[0]->c.obj.iv[12];
	local[5]= local[4];
	goto irtpointIF6043;
irtpointIF6042:
	local[5]= NIL;
irtpointIF6043:
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0]->c.obj.iv[10];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(*ftab[1])(ctx,2,local+6,&ftab[1],fqv[8]); /*array-dimension*/
	local[6]= w;
irtpointWHL6044:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto irtpointWHX6045;
	local[7]= argv[0]->c.obj.iv[10];
	local[8]= local[5];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(*ftab[4])(ctx,3,local+7,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)VNORM(ctx,1,local+7); /*norm*/
	local[7]= w;
	{ double left,right;
		right=fltval(makeflt(9.9999999999999977795540e-02)); left=fltval(local[7]);
	if (left >= right) goto irtpointCON6048;}
	local[7]= fqv[117];
	ctx->vsp=local+8;
	w=(*ftab[26])(ctx,1,local+7,&ftab[26],fqv[96]); /*gl:glcolor3fv*/
	local[7]= NIL;
	local[8]= fqv[118];
	local[9]= fqv[119];
	local[10]= fqv[120];
	local[11]= fqv[121];
	local[12]= fqv[122];
	local[13]= fqv[123];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,6,local+8); /*list*/
	local[8]= w;
irtpointWHL6049:
	if (local[8]==NIL) goto irtpointWHX6050;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[9];
	local[7] = w;
	local[9]= argv[0]->c.obj.iv[8];
	local[10]= local[5];
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(*ftab[4])(ctx,3,local+9,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(*ftab[27])(ctx,1,local+9,&ftab[27],fqv[97]); /*gl:glvertex3fv*/
	local[9]= local[2];
	local[10]= local[7];
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)VPLUS(ctx,3,local+9); /*v+*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[27])(ctx,1,local+9,&ftab[27],fqv[97]); /*gl:glvertex3fv*/
	goto irtpointWHL6049;
irtpointWHX6050:
	local[9]= NIL;
irtpointBLK6051:
	w = NIL;
	local[7]= w;
	goto irtpointCON6047;
irtpointCON6048:
	if (local[0]==NIL) goto irtpointIF6053;
	local[7]= local[0];
	local[8]= local[5];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(*ftab[4])(ctx,3,local+7,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[7]= w;
	goto irtpointIF6054;
irtpointIF6053:
	local[7]= NIL;
irtpointIF6054:
	local[7]= argv[0]->c.obj.iv[20];
	local[8]= local[7];
	if (fqv[6]!=local[8]) goto irtpointIF6055;
	local[8]= local[4];
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	local[9]= local[4];
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	local[10]= local[4];
	local[11]= makeint((eusinteger_t)2L);
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)NUMEQUAL(ctx,3,local+8); /*=*/
	if (w==NIL) goto irtpointIF6057;
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(*ftab[26])(ctx,1,local+8,&ftab[26],fqv[96]); /*gl:glcolor3fv*/
	local[8]= w;
	goto irtpointIF6058;
irtpointIF6057:
	local[8]= fqv[124];
	ctx->vsp=local+9;
	w=(*ftab[26])(ctx,1,local+8,&ftab[26],fqv[96]); /*gl:glcolor3fv*/
	local[8]= w;
irtpointIF6058:
	goto irtpointIF6056;
irtpointIF6055:
	local[8]= local[7];
	if (fqv[125]!=local[8]) goto irtpointIF6059;
	local[8]= fqv[126];
	ctx->vsp=local+9;
	w=(*ftab[41])(ctx,1,local+8,&ftab[41],fqv[127]); /*gl:glcolor3f*/
	local[8]= w;
	goto irtpointIF6060;
irtpointIF6059:
	if (T==NIL) goto irtpointIF6061;
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(*ftab[26])(ctx,1,local+8,&ftab[26],fqv[96]); /*gl:glcolor3fv*/
	local[8]= w;
	goto irtpointIF6062;
irtpointIF6061:
	local[8]= NIL;
irtpointIF6062:
irtpointIF6060:
irtpointIF6056:
	w = local[8];
	local[7]= argv[0]->c.obj.iv[8];
	local[8]= local[5];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(*ftab[4])(ctx,3,local+7,&ftab[4],fqv[24]); /*c-matrix-row*/
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(*ftab[27])(ctx,1,local+7,&ftab[27],fqv[97]); /*gl:glvertex3fv*/
	local[7]= local[2];
	local[8]= makeflt(1.0000000000000000000000e+01);
	local[9]= local[3];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)SCALEVEC(ctx,3,local+8); /*scale*/
	local[8]= w;
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)VPLUS(ctx,3,local+7); /*v+*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[27])(ctx,1,local+7,&ftab[27],fqv[97]); /*gl:glvertex3fv*/
	local[7]= w;
	goto irtpointCON6047;
irtpointCON6052:
	local[7]= NIL;
irtpointCON6047:
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto irtpointWHL6044;
irtpointWHX6045:
	local[7]= NIL;
irtpointBLK6046:
	w = NIL;
	ctx->vsp=local+5;
	w=(*ftab[28])(ctx,0,local+5,&ftab[28],fqv[98]); /*gl:glend*/
	local[1]= w;
	goto irtpointIF6041;
irtpointIF6040:
	local[1]= NIL;
irtpointIF6041:
	w = local[1];
	local[0]= w;
	goto irtpointIF6017;
irtpointIF6016:
	local[0]= NIL;
irtpointIF6017:
	ctx->vsp=local+0;
	w=(*ftab[42])(ctx,0,local+0,&ftab[42],fqv[128]); /*gl:glpopmatrix*/
	local[0]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+1;
	w=(*ftab[18])(ctx,1,local+0,&ftab[18],fqv[84]); /*gl:glenable*/
	ctx->vsp=local+0;
	w=(*ftab[43])(ctx,0,local+0,&ftab[43],fqv[129]); /*gl:glpopattrib*/
	if (argv[0]->c.obj.iv[21]==NIL) goto irtpointIF6063;
	local[0]= makeint((eusinteger_t)1L);
	ctx->vsp=local+1;
	w=(*ftab[17])(ctx,1,local+0,&ftab[17],fqv[83]); /*gl:gldepthmask*/
	local[0]= makeint((eusinteger_t)3042L);
	ctx->vsp=local+1;
	w=(*ftab[21])(ctx,1,local+0,&ftab[21],fqv[89]); /*gl:gldisable*/
	local[0]= w;
	goto irtpointIF6064;
irtpointIF6063:
	local[0]= NIL;
irtpointIF6064:
	w = local[0];
	local[0]= w;
irtpointBLK6009:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtpointCLO5923(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env2[3];
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	local[0]= w;
	local[1]= argv[1];
	local[2]= env->c.clo.env2[2];
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MKFLTVEC(ctx,2,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)VNORM(ctx,1,local+0); /*norm*/
	local[0]= w;
	local[1]= env->c.clo.env1[2];
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtpointFLET5951(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)GREQP(ctx,2,local+0); /*>=*/
	if (w==NIL) goto irtpointIF6065;
	local[0]= argv[1];
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	local[0]= w;
	goto irtpointIF6066;
irtpointIF6065:
	local[0]= argv[0];
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)QUOTIENT(ctx,2,local+1); /*/*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)FLOOR(ctx,1,local+0); /*floor*/
	local[0]= w;
	local[1]= local[0];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)GREQP(ctx,2,local+1); /*>=*/
	if (w==NIL) goto irtpointIF6067;
	local[1]= argv[1];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
	goto irtpointIF6068;
irtpointIF6067:
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)LSEQP(ctx,2,local+1); /*<=*/
	if (w==NIL) goto irtpointIF6069;
	local[1]= makeint((eusinteger_t)0L);
	goto irtpointIF6070;
irtpointIF6069:
	local[1]= local[0];
irtpointIF6070:
irtpointIF6068:
	w = local[1];
	local[0]= w;
irtpointIF6066:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*make-random-pointcloud*/
static pointer irtpointF5572make_random_pointcloud(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[130], &argv[0], n-0, local+0, 0);
	if (n & (1<<0)) goto irtpointKEY6072;
	local[0] = makeint((eusinteger_t)1000L);
irtpointKEY6072:
	if (n & (1<<1)) goto irtpointKEY6073;
	local[1] = NIL;
irtpointKEY6073:
	if (n & (1<<2)) goto irtpointKEY6074;
	local[2] = NIL;
irtpointKEY6074:
	if (n & (1<<3)) goto irtpointKEY6075;
	local[3] = makeflt(1.0000000000000000000000e+02);
irtpointKEY6075:
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[0];
irtpointWHL6076:
	local[10]= local[8];
	w = local[9];
	if ((eusinteger_t)local[10] >= (eusinteger_t)w) goto irtpointWHX6077;
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(*ftab[44])(ctx,1,local+10,&ftab[44],fqv[131]); /*random-vector*/
	local[10]= w;
	w = local[4];
	ctx->vsp=local+11;
	local[4] = cons(ctx,local[10],w);
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	goto irtpointWHL6076;
irtpointWHX6077:
	local[10]= NIL;
irtpointBLK6078:
	w = NIL;
	if (local[1]==NIL) goto irtpointIF6079;
	local[8]= makeflt(5.0000000000000000000000e-01);
	local[9]= makeflt(5.0000000000000000000000e-01);
	local[10]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= local[0];
irtpointWHL6081:
	local[11]= local[9];
	w = local[10];
	if ((eusinteger_t)local[11] >= (eusinteger_t)w) goto irtpointWHX6082;
	local[11]= local[8];
	local[12]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+13;
	w=(*ftab[44])(ctx,1,local+12,&ftab[44],fqv[131]); /*random-vector*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)VPLUS(ctx,2,local+11); /*v+*/
	local[11]= w;
	w = local[5];
	ctx->vsp=local+12;
	local[5] = cons(ctx,local[11],w);
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[9] = w;
	goto irtpointWHL6081;
irtpointWHX6082:
	local[11]= NIL;
irtpointBLK6083:
	w = NIL;
	local[8]= w;
	goto irtpointIF6080;
irtpointIF6079:
	local[8]= NIL;
irtpointIF6080:
	if (local[2]==NIL) goto irtpointIF6084;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[0];
irtpointWHL6086:
	local[10]= local[8];
	w = local[9];
	if ((eusinteger_t)local[10] >= (eusinteger_t)w) goto irtpointWHX6087;
	local[10]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+11;
	w=(*ftab[44])(ctx,1,local+10,&ftab[44],fqv[131]); /*random-vector*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[34])(ctx,1,local+10,&ftab[34],fqv[109]); /*normalize-vector*/
	local[10]= w;
	w = local[6];
	ctx->vsp=local+11;
	local[6] = cons(ctx,local[10],w);
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	goto irtpointWHL6086;
irtpointWHX6087:
	local[10]= NIL;
irtpointBLK6088:
	w = NIL;
	local[8]= w;
	goto irtpointIF6085;
irtpointIF6084:
	local[8]= NIL;
irtpointIF6085:
	local[8]= loadglobal(fqv[32]);
	ctx->vsp=local+9;
	w=(pointer)INSTANTIATE(ctx,1,local+8); /*instantiate*/
	local[8]= w;
	local[9]= local[8];
	local[10]= fqv[14];
	local[11]= fqv[1];
	local[12]= local[4];
	local[13]= fqv[2];
	local[14]= local[5];
	local[15]= fqv[3];
	local[16]= local[6];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,8,local+9); /*send*/
	w = local[8];
	local[7] = w;
	w = local[7];
	local[0]= w;
irtpointBLK6071:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___irtpointcloud(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[132];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtpointIF6089;
	local[0]= fqv[133];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[134],w);
	goto irtpointIF6090;
irtpointIF6089:
	local[0]= fqv[135];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtpointIF6090:
	local[0]= fqv[32];
	local[1]= fqv[136];
	local[2]= fqv[32];
	local[3]= fqv[137];
	local[4]= loadglobal(fqv[138]);
	local[5]= fqv[139];
	local[6]= fqv[140];
	local[7]= fqv[141];
	local[8]= NIL;
	local[9]= fqv[63];
	local[10]= NIL;
	local[11]= fqv[15];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[142];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[45])(ctx,13,local+2,&ftab[45],fqv[143]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5573pointcloud_init,fqv[14],fqv[32],fqv[144]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5609pointcloud_reset_box,fqv[20],fqv[32],fqv[145]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5613pointcloud_box,fqv[21],fqv[32],fqv[146]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5617pointcloud_vertices,fqv[147],fqv[32],fqv[148]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5619pointcloud_size,fqv[15],fqv[32],fqv[149]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5623pointcloud_width,fqv[9],fqv[32],fqv[150]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5625pointcloud_height,fqv[10],fqv[32],fqv[151]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5627pointcloud_size_change,fqv[7],fqv[32],fqv[152]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5639pointcloud_view_coords,fqv[33],fqv[32],fqv[153]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5645pointcloud_points,fqv[1],fqv[32],fqv[154]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5659pointcloud_colors,fqv[2],fqv[32],fqv[155]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5671pointcloud_normals,fqv[3],fqv[32],fqv[156]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5683pointcloud_curvatures,fqv[4],fqv[32],fqv[157]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5695pointcloud_point_list,fqv[19],fqv[32],fqv[158]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5705pointcloud_color_list,fqv[159],fqv[32],fqv[160]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5712pointcloud_normal_list,fqv[161],fqv[32],fqv[162]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5719pointcloud_curvature_list,fqv[163],fqv[32],fqv[164]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5726pointcloud_centroid,fqv[165],fqv[32],fqv[166]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5728pointcloud_set_color,fqv[167],fqv[32],fqv[168]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5736pointcloud_point_color,fqv[29],fqv[32],fqv[169]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5742pointcloud_point_size,fqv[35],fqv[32],fqv[170]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5748pointcloud_axis_length,fqv[36],fqv[32],fqv[171]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5754pointcloud_axis_width,fqv[37],fqv[32],fqv[172]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5760pointcloud_append,fqv[173],fqv[32],fqv[174]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5794pointcloud_clear_color,fqv[175],fqv[32],fqv[176]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5796pointcloud_clear_normal,fqv[177],fqv[32],fqv[178]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5798pointcloud_nfilter,fqv[179],fqv[32],fqv[180]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5801pointcloud_filter,fqv[42],fqv[32],fqv[181]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5805pointcloud_filter_with_indices,fqv[45],fqv[32],fqv[182]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5853pointcloud_filtered_indices,fqv[44],fqv[32],fqv[183]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5885pointcloud_viewangle_inlier,fqv[184],fqv[32],fqv[185]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5895pointcloud_image_position_inlier,fqv[57],fqv[32],fqv[186]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5915pointcloud_image_circle_filter,fqv[187],fqv[32],fqv[188]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5924pointcloud_step_inlier,fqv[61],fqv[32],fqv[189]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5934pointcloud_step,fqv[190],fqv[32],fqv[191]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5941pointcloud_generate_color_histogram_hs,fqv[192],fqv[32],fqv[193]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5968pointcloud_copy_from,fqv[69],fqv[32],fqv[194]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5970pointcloud_transform_points,fqv[75],fqv[32],fqv[195]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5979pointcloud_set_offset,fqv[196],fqv[32],fqv[197]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5982pointcloud_convert_to_world,fqv[198],fqv[32],fqv[199]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5985pointcloud_move_origin_to,fqv[77],fqv[32],fqv[200]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5991pointcloud_drawnormalmode,fqv[201],fqv[32],fqv[202]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM5999pointcloud_transparent,fqv[30],fqv[32],fqv[203]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtpointM6008pointcloud_draw,fqv[204],fqv[32],fqv[205]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[206],module,irtpointF5572make_random_pointcloud,fqv[207]);
	local[0]= fqv[208];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtpointIF6091;
	local[0]= fqv[209];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[134],w);
	goto irtpointIF6092;
irtpointIF6091:
	local[0]= fqv[210];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtpointIF6092:
	local[0]= fqv[211];
	local[1]= fqv[212];
	ctx->vsp=local+2;
	w=(*ftab[46])(ctx,2,local+0,&ftab[46],fqv[213]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<47; i++) ftab[i]=fcallx;
}
