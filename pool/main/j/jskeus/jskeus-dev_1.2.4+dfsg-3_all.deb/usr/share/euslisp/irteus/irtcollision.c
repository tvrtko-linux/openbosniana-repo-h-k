/* ./irtcollision.c :  entry=irtcollision */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "irtcollision.h"
#pragma init (register_irtcollision)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___irtcollision();
extern pointer build_quote_vector();
static int register_irtcollision()
  { add_module_initializer("___irtcollision", ___irtcollision);}

static pointer irtcolliF572collision_distance();
static pointer irtcolliF573collision_check();
static pointer irtcolliF574collision_check_objects();
static pointer irtcolliF575select_collision_algorithm();

/*:make-collisionmodel*/
static pointer irtcolliM576cascaded_coords_make_collisionmodel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtcolliRST578:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= loadglobal(fqv[0]);
	if (loadglobal(fqv[1])!=local[1]) goto irtcolliCON580;
	local[1]= (pointer)get_sym_func(fqv[2]);
	local[2]= argv[0];
	local[3]= fqv[3];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[1]= w;
	goto irtcolliCON579;
irtcolliCON580:
	local[1]= loadglobal(fqv[0]);
	if (loadglobal(fqv[4])!=local[1]) goto irtcolliCON581;
	local[1]= (pointer)get_sym_func(fqv[2]);
	local[2]= argv[0];
	local[3]= fqv[5];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[1]= w;
	goto irtcolliCON579;
irtcolliCON581:
	local[1]= fqv[6];
	local[2]= loadglobal(fqv[0]);
	ctx->vsp=local+3;
	w=(pointer)SIGERROR(ctx,2,local+1); /*error*/
	local[1]= w;
	goto irtcolliCON579;
irtcolliCON582:
	local[1]= NIL;
irtcolliCON579:
	w = local[1];
	local[0]= w;
irtcolliBLK577:
	ctx->vsp=local; return(local[0]);}

/*collision-distance*/
static pointer irtcolliF572collision_distance(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtcolliRST584:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= loadglobal(fqv[0]);
	if (loadglobal(fqv[1])!=local[1]) goto irtcolliCON586;
	local[1]= (pointer)get_sym_func(fqv[7]);
	local[2]= argv[0];
	local[3]= argv[1];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[1]= w;
	goto irtcolliCON585;
irtcolliCON586:
	local[1]= loadglobal(fqv[0]);
	if (loadglobal(fqv[4])!=local[1]) goto irtcolliCON587;
	local[1]= (pointer)get_sym_func(fqv[8]);
	local[2]= argv[0];
	local[3]= argv[1];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[1]= w;
	goto irtcolliCON585;
irtcolliCON587:
	local[1]= fqv[9];
	local[2]= loadglobal(fqv[0]);
	ctx->vsp=local+3;
	w=(pointer)SIGERROR(ctx,2,local+1); /*error*/
	local[1]= w;
	goto irtcolliCON585;
irtcolliCON588:
	local[1]= NIL;
irtcolliCON585:
	w = local[1];
	local[0]= w;
irtcolliBLK583:
	ctx->vsp=local; return(local[0]);}

/*collision-check*/
static pointer irtcolliF573collision_check(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtcolliRST590:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= loadglobal(fqv[0]);
	if (loadglobal(fqv[1])!=local[1]) goto irtcolliCON592;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!issymbol(w)) goto irtcolliIF593;
	local[1]= makeint((eusinteger_t)2L);
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)APPEND(ctx,2,local+1); /*append*/
	local[0] = w;
	local[1]= local[0];
	goto irtcolliIF594;
irtcolliIF593:
	local[1]= NIL;
irtcolliIF594:
	local[1]= (pointer)get_sym_func(fqv[10]);
	local[2]= argv[0];
	local[3]= argv[1];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[1]= w;
	goto irtcolliCON591;
irtcolliCON592:
	local[1]= loadglobal(fqv[0]);
	if (loadglobal(fqv[4])!=local[1]) goto irtcolliCON595;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!isnum(w)) goto irtcolliIF596;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	local[1]= local[0];
	goto irtcolliIF597;
irtcolliIF596:
	local[1]= NIL;
irtcolliIF597:
	local[1]= (pointer)get_sym_func(fqv[11]);
	local[2]= argv[0];
	local[3]= argv[1];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[1]= w;
	goto irtcolliCON591;
irtcolliCON595:
	local[1]= fqv[12];
	local[2]= loadglobal(fqv[0]);
	ctx->vsp=local+3;
	w=(pointer)SIGERROR(ctx,2,local+1); /*error*/
	local[1]= w;
	goto irtcolliCON591;
irtcolliCON598:
	local[1]= NIL;
irtcolliCON591:
	w = local[1];
	local[0]= w;
irtcolliBLK589:
	ctx->vsp=local; return(local[0]);}

/*collision-check-objects*/
static pointer irtcolliF574collision_check_objects(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtcolliRST600:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= NIL;
	local[2]= argv[0];
irtcolliWHL601:
	if (local[2]==NIL) goto irtcolliWHX602;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= NIL;
	local[4]= argv[1];
irtcolliWHL604:
	if (local[4]==NIL) goto irtcolliWHX605;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[1];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)irtcolliF573collision_check(ctx,2,local+5); /*collision-check*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)GREATERP(ctx,2,local+5); /*>*/
	if (w==NIL) goto irtcolliIF607;
	w = T;
	ctx->vsp=local+5;
	local[0]=w;
	goto irtcolliBLK599;
	goto irtcolliIF608;
irtcolliIF607:
	local[5]= NIL;
irtcolliIF608:
	goto irtcolliWHL604;
irtcolliWHX605:
	local[5]= NIL;
irtcolliBLK606:
	w = NIL;
	goto irtcolliWHL601;
irtcolliWHX602:
	local[3]= NIL;
irtcolliBLK603:
	w = NIL;
	w = NIL;
	local[0]= w;
irtcolliBLK599:
	ctx->vsp=local; return(local[0]);}

/*select-collision-algorithm*/
static pointer irtcolliF575select_collision_algorithm(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	storeglobal(fqv[0],local[0]);
	w = local[0];
	local[0]= w;
irtcolliBLK609:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___irtcollision(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[13];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtcolliIF610;
	local[0]= fqv[14];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[15],w);
	goto irtcolliIF611;
irtcolliIF610:
	local[0]= fqv[16];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtcolliIF611:
	local[0]= fqv[17];
	ctx->vsp=local+1;
	w=(*ftab[0])(ctx,1,local+0,&ftab[0],fqv[18]); /*require*/
	local[0]= fqv[19];
	ctx->vsp=local+1;
	w=(*ftab[0])(ctx,1,local+0,&ftab[0],fqv[18]); /*require*/
	local[0]= fqv[1];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w==NIL) goto irtcolliIF612;
	local[0]= fqv[4];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w==NIL) goto irtcolliIF612;
	local[0]= fqv[0];
	local[1]= fqv[20];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto irtcolliIF614;
	local[0]= fqv[0];
	local[1]= fqv[20];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[0];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto irtcolliIF616;
	local[0]= fqv[0];
	local[1]= fqv[21];
	local[2]= loadglobal(fqv[1]);
	if (local[2]!=NIL) goto irtcolliOR618;
	local[2]= loadglobal(fqv[4]);
irtcolliOR618:
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto irtcolliIF617;
irtcolliIF616:
	local[0]= NIL;
irtcolliIF617:
	local[0]= fqv[0];
	goto irtcolliIF615;
irtcolliIF614:
	local[0]= NIL;
irtcolliIF615:
	goto irtcolliIF613;
irtcolliIF612:
	local[0]= NIL;
irtcolliIF613:
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtcolliM576cascaded_coords_make_collisionmodel,fqv[22],fqv[23],fqv[24]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[25],module,irtcolliF572collision_distance,fqv[26]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[27],module,irtcolliF573collision_check,fqv[28]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[29],module,irtcolliF574collision_check_objects,fqv[30]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[31],module,irtcolliF575select_collision_algorithm,fqv[32]);
	local[0]= fqv[33];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtcolliIF619;
	local[0]= fqv[34];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[15],w);
	goto irtcolliIF620;
irtcolliIF619:
	local[0]= fqv[35];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtcolliIF620:
	local[0]= fqv[36];
	local[1]= fqv[37];
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,2,local+0,&ftab[1],fqv[38]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<2; i++) ftab[i]=fcallx;
}
