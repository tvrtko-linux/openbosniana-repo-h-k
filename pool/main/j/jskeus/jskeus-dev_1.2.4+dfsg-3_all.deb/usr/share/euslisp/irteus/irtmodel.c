/* ./irtmodel.c :  entry=irtmodel */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "irtmodel.h"
#pragma init (register_irtmodel)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___irtmodel();
extern pointer build_quote_vector();
static int register_irtmodel()
  { add_module_initializer("___irtmodel", ___irtmodel);}

static pointer irtmodelF729calc_jacobian_default_rotate_vector();
static pointer irtmodelF730calc_jacobian_rotational();
static pointer irtmodelF731calc_jacobian_linear();
static pointer irtmodelF732calc_angle_speed_gain_scalar();
static pointer irtmodelF733calc_angle_speed_gain_vector();
static pointer irtmodelF734all_child_links();
static pointer irtmodelF735calc_dif_with_axis();
static pointer irtmodelF736calc_target_joint_dimension();
static pointer irtmodelF737calc_joint_angle_min_max_for_limit_calculation();
static pointer irtmodelF738joint_angle_limit_weight();
static pointer irtmodelF739joint_angle_limit_nspace();
static pointer irtmodelF740calc_jacobian_from_link_list_including_robot_and_obj_virtual_joint();
static pointer irtmodelF741append_obj_virtual_joint();
static pointer irtmodelF742append_multiple_obj_virtual_joint();
static pointer irtmodelF743eusmodel_validity_check_one();
static pointer irtmodelF744eusmodel_validity_check();

/*:init*/
static pointer irtmodelM745joint_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[0], &argv[2], n-2, local+0, 1);
	if (n & (1<<0)) goto irtmodelKEY747;
	local[9]= NIL;
	local[10]= fqv[1];
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(pointer)ADDRESS(ctx,1,local+11); /*system:address*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)XFORMAT(ctx,3,local+9); /*format*/
	local[9]= w;
	local[10]= fqv[2];
	ctx->vsp=local+11;
	w=(pointer)INTERN(ctx,2,local+9); /*intern*/
	local[0] = w;
irtmodelKEY747:
	if (n & (1<<1)) goto irtmodelKEY748;
	local[1] = NIL;
irtmodelKEY748:
	if (n & (1<<2)) goto irtmodelKEY749;
	local[2] = NIL;
irtmodelKEY749:
	if (n & (1<<3)) goto irtmodelKEY750;
	local[3] = makeint((eusinteger_t)-90L);
irtmodelKEY750:
	if (n & (1<<4)) goto irtmodelKEY751;
	local[4] = makeint((eusinteger_t)90L);
irtmodelKEY751:
	if (n & (1<<5)) goto irtmodelKEY752;
	local[5] = NIL;
irtmodelKEY752:
	if (n & (1<<6)) goto irtmodelKEY753;
	local[6] = NIL;
irtmodelKEY753:
	if (n & (1<<7)) goto irtmodelKEY754;
	local[7] = NIL;
irtmodelKEY754:
	if (n & (1<<8)) goto irtmodelKEY755;
	local[8] = NIL;
irtmodelKEY755:
	local[9]= argv[0];
	local[10]= fqv[3];
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	argv[0]->c.obj.iv[1] = local[2];
	argv[0]->c.obj.iv[2] = local[1];
	argv[0]->c.obj.iv[4] = local[3];
	argv[0]->c.obj.iv[5] = local[4];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(*ftab[0])(ctx,1,local+9,&ftab[0],fqv[4]); /*float-vector-p*/
	if (w==NIL) goto irtmodelAND759;
	local[9]= local[5];
	local[10]= loadglobal(fqv[5]);
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)INSTANTIATE(ctx,2,local+10); /*instantiate*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)VGREATERP(ctx,2,local+9); /*v>*/
	if (w!=NIL) goto irtmodelAND759;
	goto irtmodelOR758;
irtmodelAND759:
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(*ftab[0])(ctx,1,local+9,&ftab[0],fqv[4]); /*float-vector-p*/
	if (w!=NIL) goto irtmodelAND760;
	local[9]= local[5];
	local[10]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+11;
	w=(pointer)LESSP(ctx,2,local+9); /*<*/
	if (w==NIL) goto irtmodelAND760;
	goto irtmodelOR758;
irtmodelAND760:
	goto irtmodelIF756;
irtmodelOR758:
	local[9]= fqv[6];
	local[10]= local[0];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)SIGERROR(ctx,3,local+9); /*error*/
	local[9]= w;
	goto irtmodelIF757;
irtmodelIF756:
	local[9]= NIL;
irtmodelIF757:
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(*ftab[0])(ctx,1,local+9,&ftab[0],fqv[4]); /*float-vector-p*/
	if (w==NIL) goto irtmodelAND764;
	local[9]= local[6];
	local[10]= loadglobal(fqv[5]);
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)INSTANTIATE(ctx,2,local+10); /*instantiate*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)VGREATERP(ctx,2,local+9); /*v>*/
	if (w!=NIL) goto irtmodelAND764;
	goto irtmodelOR763;
irtmodelAND764:
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(*ftab[0])(ctx,1,local+9,&ftab[0],fqv[4]); /*float-vector-p*/
	if (w!=NIL) goto irtmodelAND765;
	local[9]= local[6];
	local[10]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+11;
	w=(pointer)LESSP(ctx,2,local+9); /*<*/
	if (w==NIL) goto irtmodelAND765;
	goto irtmodelOR763;
irtmodelAND765:
	goto irtmodelIF761;
irtmodelOR763:
	local[9]= fqv[7];
	local[10]= local[0];
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)SIGERROR(ctx,3,local+9); /*error*/
	local[9]= w;
	goto irtmodelIF762;
irtmodelIF761:
	local[9]= NIL;
irtmodelIF762:
	local[9]= argv[0];
	local[10]= fqv[8];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= argv[0];
	local[10]= fqv[9];
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= argv[0];
	local[10]= fqv[10];
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= argv[0];
	local[10]= fqv[11];
	local[11]= local[8];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= argv[0]->c.obj.iv[2];
	local[10]= fqv[12];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	argv[0]->c.obj.iv[6] = w;
	w = argv[0];
	local[0]= w;
irtmodelBLK746:
	ctx->vsp=local; return(local[0]);}

/*:min-angle*/
static pointer irtmodelM766joint_min_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT769;}
	local[0]= NIL;
irtmodelENT769:
irtmodelENT768:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF770;
	argv[0]->c.obj.iv[4] = local[0];
	local[1]= argv[0]->c.obj.iv[4];
	goto irtmodelIF771;
irtmodelIF770:
	local[1]= NIL;
irtmodelIF771:
	w = argv[0]->c.obj.iv[4];
	local[0]= w;
irtmodelBLK767:
	ctx->vsp=local; return(local[0]);}

/*:max-angle*/
static pointer irtmodelM772joint_max_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT775;}
	local[0]= NIL;
irtmodelENT775:
irtmodelENT774:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF776;
	argv[0]->c.obj.iv[5] = local[0];
	local[1]= argv[0]->c.obj.iv[5];
	goto irtmodelIF777;
irtmodelIF776:
	local[1]= NIL;
irtmodelIF777:
	w = argv[0]->c.obj.iv[5];
	local[0]= w;
irtmodelBLK773:
	ctx->vsp=local; return(local[0]);}

/*:parent-link*/
static pointer irtmodelM778joint_parent_link(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST780:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,2,local+1,&ftab[1],fqv[13]); /*forward-message-to*/
	local[0]= w;
irtmodelBLK779:
	ctx->vsp=local; return(local[0]);}

/*:child-link*/
static pointer irtmodelM781joint_child_link(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST783:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,2,local+1,&ftab[1],fqv[13]); /*forward-message-to*/
	local[0]= w;
irtmodelBLK782:
	ctx->vsp=local; return(local[0]);}

/*:calc-dav-gain*/
static pointer irtmodelM784joint_calc_dav_gain(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= fqv[14];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[15]); /*warn*/
	local[0]= w;
irtmodelBLK785:
	ctx->vsp=local; return(local[0]);}

/*:joint-dof*/
static pointer irtmodelM786joint_joint_dof(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[16];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[15]); /*warn*/
	local[0]= w;
irtmodelBLK787:
	ctx->vsp=local; return(local[0]);}

/*:speed-to-angle*/
static pointer irtmodelM788joint_speed_to_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST790:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= fqv[17];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[15]); /*warn*/
	local[0]= w;
irtmodelBLK789:
	ctx->vsp=local; return(local[0]);}

/*:angle-to-speed*/
static pointer irtmodelM791joint_angle_to_speed(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST793:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= fqv[18];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[15]); /*warn*/
	local[0]= w;
irtmodelBLK792:
	ctx->vsp=local; return(local[0]);}

/*:calc-jacobian*/
static pointer irtmodelM794joint_calc_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST796:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= fqv[19];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[15]); /*warn*/
	local[0]= w;
irtmodelBLK795:
	ctx->vsp=local; return(local[0]);}

/*:joint-velocity*/
static pointer irtmodelM797joint_joint_velocity(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT800;}
	local[0]= NIL;
irtmodelENT800:
irtmodelENT799:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF801;
	argv[0]->c.obj.iv[7] = local[0];
	local[1]= argv[0]->c.obj.iv[7];
	goto irtmodelIF802;
irtmodelIF801:
	local[1]= argv[0]->c.obj.iv[7];
irtmodelIF802:
	w = local[1];
	local[0]= w;
irtmodelBLK798:
	ctx->vsp=local; return(local[0]);}

/*:joint-acceleration*/
static pointer irtmodelM803joint_joint_acceleration(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT806;}
	local[0]= NIL;
irtmodelENT806:
irtmodelENT805:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF807;
	argv[0]->c.obj.iv[8] = local[0];
	local[1]= argv[0]->c.obj.iv[8];
	goto irtmodelIF808;
irtmodelIF807:
	local[1]= argv[0]->c.obj.iv[8];
irtmodelIF808:
	w = local[1];
	local[0]= w;
irtmodelBLK804:
	ctx->vsp=local; return(local[0]);}

/*:joint-torque*/
static pointer irtmodelM809joint_joint_torque(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT812;}
	local[0]= NIL;
irtmodelENT812:
irtmodelENT811:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF813;
	argv[0]->c.obj.iv[9] = local[0];
	local[1]= argv[0]->c.obj.iv[9];
	goto irtmodelIF814;
irtmodelIF813:
	local[1]= argv[0]->c.obj.iv[9];
irtmodelIF814:
	w = local[1];
	local[0]= w;
irtmodelBLK810:
	ctx->vsp=local; return(local[0]);}

/*:max-joint-velocity*/
static pointer irtmodelM815joint_max_joint_velocity(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT818;}
	local[0]= NIL;
irtmodelENT818:
irtmodelENT817:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF819;
	argv[0]->c.obj.iv[10] = local[0];
	local[1]= argv[0]->c.obj.iv[10];
	goto irtmodelIF820;
irtmodelIF819:
	local[1]= argv[0]->c.obj.iv[10];
irtmodelIF820:
	w = local[1];
	local[0]= w;
irtmodelBLK816:
	ctx->vsp=local; return(local[0]);}

/*:max-joint-torque*/
static pointer irtmodelM821joint_max_joint_torque(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT824;}
	local[0]= NIL;
irtmodelENT824:
irtmodelENT823:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF825;
	argv[0]->c.obj.iv[11] = local[0];
	local[1]= argv[0]->c.obj.iv[11];
	goto irtmodelIF826;
irtmodelIF825:
	local[1]= argv[0]->c.obj.iv[11];
irtmodelIF826:
	w = local[1];
	local[0]= w;
irtmodelBLK822:
	ctx->vsp=local; return(local[0]);}

/*:joint-min-max-table*/
static pointer irtmodelM827joint_joint_min_max_table(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT830;}
	local[0]= NIL;
irtmodelENT830:
irtmodelENT829:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF831;
	argv[0]->c.obj.iv[12] = local[0];
	local[1]= argv[0]->c.obj.iv[12];
	goto irtmodelIF832;
irtmodelIF831:
	local[1]= argv[0]->c.obj.iv[12];
irtmodelIF832:
	w = local[1];
	local[0]= w;
irtmodelBLK828:
	ctx->vsp=local; return(local[0]);}

/*:joint-min-max-target*/
static pointer irtmodelM833joint_joint_min_max_target(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT836;}
	local[0]= NIL;
irtmodelENT836:
irtmodelENT835:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF837;
	argv[0]->c.obj.iv[13] = local[0];
	local[1]= argv[0]->c.obj.iv[13];
	goto irtmodelIF838;
irtmodelIF837:
	local[1]= argv[0]->c.obj.iv[13];
irtmodelIF838:
	w = local[1];
	local[0]= w;
irtmodelBLK834:
	ctx->vsp=local; return(local[0]);}

/*:joint-min-max-table-angle-interpolate*/
static pointer irtmodelM839joint_joint_min_max_table_angle_interpolate(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)FLOOR(ctx,1,local+0); /*floor*/
	local[0]= w;
	local[1]= local[0];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	local[1]= w;
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtmodelCLO841,env,argv,local);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[2]= w;
	local[3]= argv[2];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)EUSFLOAT(ctx,1,local+4); /*float*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= makeint((eusinteger_t)1L);
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[0]= w;
irtmodelBLK840:
	ctx->vsp=local; return(local[0]);}

/*:joint-min-max-table-min-angle*/
static pointer irtmodelM842joint_joint_min_max_table_min_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT845;}
	local[0]= argv[0]->c.obj.iv[13];
	local[1]= fqv[20];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
irtmodelENT845:
irtmodelENT844:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[21];
	local[3]= local[0];
	local[4]= fqv[22];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
irtmodelBLK843:
	ctx->vsp=local; return(local[0]);}

/*:joint-min-max-table-max-angle*/
static pointer irtmodelM846joint_joint_min_max_table_max_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT849;}
	local[0]= argv[0]->c.obj.iv[13];
	local[1]= fqv[20];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
irtmodelENT849:
irtmodelENT848:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[21];
	local[3]= local[0];
	local[4]= fqv[23];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
irtmodelBLK847:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO841(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0]->c.obj.iv[12];
	local[1]= env->c.clo.env1[3];
	local[2]= local[1];
	if (fqv[22]!=local[2]) goto irtmodelIF850;
	local[2]= makeint((eusinteger_t)1L);
	goto irtmodelIF851;
irtmodelIF850:
	local[2]= local[1];
	if (fqv[23]!=local[2]) goto irtmodelIF852;
	local[2]= makeint((eusinteger_t)2L);
	goto irtmodelIF853;
irtmodelIF852:
	if (T==NIL) goto irtmodelIF854;
	local[2]= NIL;
	goto irtmodelIF855;
irtmodelIF854:
	local[2]= NIL;
irtmodelIF855:
irtmodelIF853:
irtmodelIF851:
	w = local[2];
	local[1]= w;
	local[2]= env->c.clo.env1[0]->c.obj.iv[12];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)AREF(ctx,3,local+2); /*aref*/
	local[2]= w;
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)MAX(ctx,2,local+2); /*max*/
	local[2]= w;
	local[3]= env->c.clo.env1[0]->c.obj.iv[12];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= env->c.clo.env1[0]->c.obj.iv[12];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(*ftab[3])(ctx,2,local+5,&ftab[3],fqv[24]); /*array-dimension*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,3,local+3); /*aref*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MIN(ctx,2,local+2); /*min*/
	local[2]= w;
	local[3]= env->c.clo.env1[0]->c.obj.iv[12];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,3,local+3); /*aref*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,2,local+2); /*-*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)ROUND(ctx,1,local+2); /*round*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)AREF(ctx,3,local+0); /*aref*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*calc-jacobian-default-rotate-vector*/
static pointer irtmodelF729calc_jacobian_default_rotate_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=6) maerror();
	if (argv[2]==NIL) goto irtmodelIF857;
	local[0]= makeflt(-1.0000000000000000000000e+00);
	goto irtmodelIF858;
irtmodelIF857:
	local[0]= makeflt(1.0000000000000000000000e+00);
irtmodelIF858:
	local[1]= argv[1];
	local[2]= fqv[25];
	local[3]= argv[0];
	local[4]= argv[4];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	local[2]= argv[4];
	ctx->vsp=local+3;
	w=(*ftab[4])(ctx,2,local+1,&ftab[4],fqv[26]); /*normalize-vector*/
	local[1]= w;
	local[2]= argv[4];
	ctx->vsp=local+3;
	w=(pointer)SCALEVEC(ctx,3,local+0); /*scale*/
	argv[4] = w;
	local[0]= argv[3];
	local[1]= fqv[27];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[5];
	ctx->vsp=local+2;
	w=(pointer)TRANSPOSE(ctx,2,local+0); /*transpose*/
	local[0]= w;
	local[1]= argv[4];
	local[2]= argv[4];
	ctx->vsp=local+3;
	w=(pointer)TRANSFORM(ctx,3,local+0); /*transform*/
	local[0]= w;
irtmodelBLK856:
	ctx->vsp=local; return(local[0]);}

/*calc-jacobian-rotational*/
static pointer irtmodelF730calc_jacobian_rotational(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=19) maerror();
	w = argv[3];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[28],w);
	local[3]= argv[4];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[9];
	local[7]= argv[15];
	local[8]= argv[18];
	ctx->vsp=local+9;
	w=(pointer)irtmodelF729calc_jacobian_default_rotate_vector(ctx,6,local+3); /*calc-jacobian-default-rotate-vector*/
	local[3]= w;
	local[4]= makeflt(1.0000000000000000208167e-03);
	local[5]= argv[9];
	local[6]= fqv[27];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= argv[18];
	ctx->vsp=local+7;
	w=(pointer)TRANSPOSE(ctx,2,local+5); /*transpose*/
	local[5]= w;
	local[6]= argv[8];
	local[7]= fqv[29];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= argv[5];
	local[8]= fqv[29];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= argv[16];
	ctx->vsp=local+9;
	w=(pointer)VMINUS(ctx,3,local+6); /*v-*/
	local[6]= w;
	local[7]= argv[16];
	ctx->vsp=local+8;
	w=(pointer)TRANSFORM(ctx,3,local+5); /*transform*/
	local[5]= w;
	local[6]= argv[16];
	ctx->vsp=local+7;
	w=(pointer)SCALEVEC(ctx,3,local+4); /*scale*/
	local[4]= w;
	local[5]= local[3];
	local[6]= local[4];
	local[7]= argv[17];
	ctx->vsp=local+8;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+5); /*v**/
	local[5]= w;
	local[6]= local[5];
	local[7]= argv[11];
	local[8]= argv[12];
	local[9]= argv[13];
	local[10]= argv[14];
	ctx->vsp=local+11;
	w=(pointer)irtmodelF735calc_dif_with_axis(ctx,5,local+6); /*calc-dif-with-axis*/
	local[5] = w;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
irtmodelWHL860:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto irtmodelWHX861;
	local[8]= argv[0];
	local[9]= local[6];
	local[10]= argv[1];
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[9]= w;
	local[10]= argv[2];
	local[11]= local[5];
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)ASET(ctx,4,local+8); /*aset*/
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto irtmodelWHL860;
irtmodelWHX861:
	local[8]= NIL;
irtmodelBLK862:
	w = NIL;
	local[6]= local[3];
	local[7]= argv[10];
	local[8]= argv[12];
	local[9]= argv[13];
	local[10]= argv[14];
	ctx->vsp=local+11;
	w=(pointer)irtmodelF735calc_dif_with_axis(ctx,5,local+6); /*calc-dif-with-axis*/
	local[3] = w;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
irtmodelWHL863:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto irtmodelWHX864;
	local[8]= argv[0];
	local[9]= local[6];
	local[10]= argv[1];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,3,local+9); /*+*/
	local[9]= w;
	local[10]= argv[2];
	local[11]= local[3];
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)ASET(ctx,4,local+8); /*aset*/
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto irtmodelWHL863;
irtmodelWHX864:
	local[8]= NIL;
irtmodelBLK865:
	w = NIL;
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtmodelBLK859:
	ctx->vsp=local; return(local[0]);}

/*calc-jacobian-linear*/
static pointer irtmodelF731calc_jacobian_linear(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=19) maerror();
	w = argv[3];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[28],w);
	local[3]= argv[4];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[9];
	local[7]= argv[15];
	local[8]= argv[18];
	ctx->vsp=local+9;
	w=(pointer)irtmodelF729calc_jacobian_default_rotate_vector(ctx,6,local+3); /*calc-jacobian-default-rotate-vector*/
	local[3]= w;
	local[4]= fqv[30];
	local[5]= local[3];
	local[6]= argv[11];
	local[7]= argv[12];
	local[8]= argv[13];
	local[9]= argv[14];
	ctx->vsp=local+10;
	w=(pointer)irtmodelF735calc_dif_with_axis(ctx,5,local+5); /*calc-dif-with-axis*/
	local[3] = w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
irtmodelWHL867:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto irtmodelWHX868;
	local[7]= argv[0];
	local[8]= local[5];
	local[9]= argv[1];
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[8]= w;
	local[9]= argv[2];
	local[10]= local[3];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)ASET(ctx,4,local+7); /*aset*/
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto irtmodelWHL867;
irtmodelWHX868:
	local[7]= NIL;
irtmodelBLK869:
	w = NIL;
	local[5]= local[4];
	local[6]= argv[10];
	local[7]= argv[12];
	local[8]= argv[13];
	local[9]= argv[14];
	ctx->vsp=local+10;
	w=(pointer)irtmodelF735calc_dif_with_axis(ctx,5,local+5); /*calc-dif-with-axis*/
	local[4] = w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
irtmodelWHL870:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto irtmodelWHX871;
	local[7]= argv[0];
	local[8]= local[5];
	local[9]= argv[1];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)LENGTH(ctx,1,local+10); /*length*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,3,local+8); /*+*/
	local[8]= w;
	local[9]= argv[2];
	local[10]= local[4];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)ASET(ctx,4,local+7); /*aset*/
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto irtmodelWHL870;
irtmodelWHX871:
	local[7]= NIL;
irtmodelBLK872:
	w = NIL;
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtmodelBLK866:
	ctx->vsp=local; return(local[0]);}

/*calc-angle-speed-gain-scalar*/
static pointer irtmodelF732calc_angle_speed_gain_scalar(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[8];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[1];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)QUOTIENT(ctx,2,local+1); /*/*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)ABS(ctx,1,local+0); /*abs*/
	local[0]= w;
	local[1]= local[0];
	local[2]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+3;
	w=(pointer)LESSP(ctx,2,local+1); /*<*/
	if (w==NIL) goto irtmodelIF874;
	local[1]= local[0];
	goto irtmodelIF875;
irtmodelIF874:
	local[1]= makeflt(1.0000000000000000000000e+00);
irtmodelIF875:
	w = local[1];
	local[0]= w;
irtmodelBLK873:
	ctx->vsp=local; return(local[0]);}

/*calc-angle-speed-gain-vector*/
static pointer irtmodelF733calc_angle_speed_gain_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= makeflt(1.0000000000000000000000e+00);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0];
	local[3]= fqv[31];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
irtmodelWHL877:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto irtmodelWHX878;
	local[3]= argv[0];
	local[4]= fqv[8];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	local[4]= argv[1];
	local[5]= local[1];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)ABS(ctx,1,local+3); /*abs*/
	local[3]= w;
	local[4]= local[3];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)LESSP(ctx,2,local+4); /*<*/
	if (w==NIL) goto irtmodelIF880;
	local[0] = local[3];
	local[4]= local[0];
	goto irtmodelIF881;
irtmodelIF880:
	local[4]= NIL;
irtmodelIF881:
	w = local[4];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto irtmodelWHL877;
irtmodelWHX878:
	local[3]= NIL;
irtmodelBLK879:
	w = NIL;
	w = local[0];
	local[0]= w;
irtmodelBLK876:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtmodelM882rotational_joint_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST884:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[32], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY885;
	local[1] = fqv[33];
irtmodelKEY885:
	if (n & (1<<1)) goto irtmodelKEY886;
	local[2] = makeint((eusinteger_t)5L);
irtmodelKEY886:
	if (n & (1<<2)) goto irtmodelKEY887;
	local[3] = makeint((eusinteger_t)100L);
irtmodelKEY887:
	argv[0]->c.obj.iv[14] = local[1];
	argv[0]->c.obj.iv[3] = makeflt(0.0000000000000000000000e+00);
	local[4]= (pointer)get_sym_func(fqv[34]);
	local[5]= argv[0];
	local[6]= *(ovafptr(argv[1],fqv[35]));
	local[7]= fqv[36];
	local[8]= fqv[8];
	local[9]= local[2];
	local[10]= fqv[9];
	local[11]= local[3];
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)APPLY(ctx,9,local+4); /*apply*/
	if (argv[0]->c.obj.iv[4]!=NIL) goto irtmodelIF888;
	argv[0]->c.obj.iv[4] = makeflt(-9.0000000000000000000000e+01);
	local[4]= argv[0]->c.obj.iv[4];
	goto irtmodelIF889;
irtmodelIF888:
	local[4]= NIL;
irtmodelIF889:
	if (argv[0]->c.obj.iv[5]!=NIL) goto irtmodelIF890;
	local[4]= makeflt(1.8000000000000000000000e+02);
	local[5]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	argv[0]->c.obj.iv[5] = w;
	local[4]= argv[0]->c.obj.iv[5];
	goto irtmodelIF891;
irtmodelIF890:
	local[4]= NIL;
irtmodelIF891:
	local[4]= argv[0];
	local[5]= fqv[37];
	local[6]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= argv[0];
	local[5]= fqv[38];
	local[6]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= argv[0];
	local[5]= fqv[39];
	local[6]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	w = argv[0];
	local[0]= w;
irtmodelBLK883:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle*/
static pointer irtmodelM892rotational_joint_joint_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT895;}
	local[0]= NIL;
irtmodelENT895:
irtmodelENT894:
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[40], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY896;
	local[1] = NIL;
irtmodelKEY896:
	if (local[0]==NIL) goto irtmodelIF897;
	if (argv[0]->c.obj.iv[12]==NIL) goto irtmodelIF899;
	if (argv[0]->c.obj.iv[13]==NIL) goto irtmodelIF899;
	local[2]= argv[0];
	local[3]= fqv[41];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	argv[0]->c.obj.iv[4] = w;
	local[2]= argv[0];
	local[3]= fqv[42];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	argv[0]->c.obj.iv[5] = w;
	local[2]= argv[0]->c.obj.iv[5];
	goto irtmodelIF900;
irtmodelIF899:
	local[2]= NIL;
irtmodelIF900:
	if (local[1]==NIL) goto irtmodelIF901;
	local[2]= local[0];
	local[3]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[0] = w;
	local[2]= local[0];
	goto irtmodelIF902;
irtmodelIF901:
	local[2]= NIL;
irtmodelIF902:
	local[2]= local[0];
	local[3]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+4;
	w=(pointer)GREATERP(ctx,2,local+2); /*>*/
	if (w==NIL) goto irtmodelCON904;
	if (local[1]!=NIL) goto irtmodelIF905;
	local[2]= makeint((eusinteger_t)3L);
	local[3]= fqv[43];
	local[4]= argv[0];
	local[5]= local[0];
	local[6]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+7;
	w=(*ftab[5])(ctx,5,local+2,&ftab[5],fqv[44]); /*warning-message*/
	local[2]= w;
	goto irtmodelIF906;
irtmodelIF905:
	local[2]= NIL;
irtmodelIF906:
	local[0] = argv[0]->c.obj.iv[5];
	local[2]= local[0];
	goto irtmodelCON903;
irtmodelCON904:
	local[2]= NIL;
irtmodelCON903:
	local[2]= local[0];
	local[3]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,2,local+2); /*<*/
	if (w==NIL) goto irtmodelCON908;
	if (local[1]!=NIL) goto irtmodelIF909;
	local[2]= makeint((eusinteger_t)3L);
	local[3]= fqv[45];
	local[4]= argv[0];
	local[5]= local[0];
	local[6]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+7;
	w=(*ftab[5])(ctx,5,local+2,&ftab[5],fqv[44]); /*warning-message*/
	local[2]= w;
	goto irtmodelIF910;
irtmodelIF909:
	local[2]= NIL;
irtmodelIF910:
	local[0] = argv[0]->c.obj.iv[4];
	local[2]= local[0];
	goto irtmodelCON907;
irtmodelCON908:
	local[2]= NIL;
irtmodelCON907:
	argv[0]->c.obj.iv[3] = local[0];
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= fqv[46];
	local[4]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= fqv[47];
	local[4]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+5;
	w=(*ftab[6])(ctx,1,local+4,&ftab[6],fqv[48]); /*deg2rad*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	goto irtmodelIF898;
irtmodelIF897:
	local[2]= NIL;
irtmodelIF898:
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
irtmodelBLK893:
	ctx->vsp=local; return(local[0]);}

/*:joint-dof*/
static pointer irtmodelM911rotational_joint_joint_dof(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = makeint((eusinteger_t)1L);
	local[0]= w;
irtmodelBLK912:
	ctx->vsp=local; return(local[0]);}

/*:calc-angle-speed-gain*/
static pointer irtmodelM913rotational_joint_calc_angle_speed_gain(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0];
	local[1]= argv[2];
	local[2]= argv[3];
	local[3]= argv[4];
	ctx->vsp=local+4;
	w=(pointer)irtmodelF732calc_angle_speed_gain_scalar(ctx,4,local+0); /*calc-angle-speed-gain-scalar*/
	local[0]= w;
irtmodelBLK914:
	ctx->vsp=local; return(local[0]);}

/*:speed-to-angle*/
static pointer irtmodelM915rotational_joint_speed_to_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(*ftab[7])(ctx,1,local+0,&ftab[7],fqv[49]); /*rad2deg*/
	local[0]= w;
irtmodelBLK916:
	ctx->vsp=local; return(local[0]);}

/*:angle-to-speed*/
static pointer irtmodelM917rotational_joint_angle_to_speed(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(*ftab[6])(ctx,1,local+0,&ftab[6],fqv[48]); /*deg2rad*/
	local[0]= w;
irtmodelBLK918:
	ctx->vsp=local; return(local[0]);}

/*:calc-jacobian*/
static pointer irtmodelM919rotational_joint_calc_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST921:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[50]);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)APPLY(ctx,2,local+1); /*apply*/
	local[0]= w;
irtmodelBLK920:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtmodelM922linear_joint_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST924:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[51], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY925;
	local[1] = fqv[33];
irtmodelKEY925:
	if (n & (1<<1)) goto irtmodelKEY926;
	local[4]= makeflt(3.1415926535897931159980e+00);
	local[5]= makeint((eusinteger_t)4L);
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[2] = w;
irtmodelKEY926:
	if (n & (1<<2)) goto irtmodelKEY927;
	local[3] = makeint((eusinteger_t)100L);
irtmodelKEY927:
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(*ftab[0])(ctx,1,local+4,&ftab[0],fqv[4]); /*float-vector-p*/
	if (w==NIL) goto irtmodelIF928;
	local[4]= local[1];
	goto irtmodelIF929;
irtmodelIF928:
	local[4]= local[1];
	local[5]= local[4];
	if (fqv[52]!=local[5]) goto irtmodelIF930;
	local[5]= makeint((eusinteger_t)1L);
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[5]= w;
	goto irtmodelIF931;
irtmodelIF930:
	local[5]= local[4];
	if (fqv[53]!=local[5]) goto irtmodelIF932;
	local[5]= makeint((eusinteger_t)-1L);
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[5]= w;
	goto irtmodelIF933;
irtmodelIF932:
	local[5]= local[4];
	if (fqv[54]!=local[5]) goto irtmodelIF934;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)1L);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[5]= w;
	goto irtmodelIF935;
irtmodelIF934:
	local[5]= local[4];
	if (fqv[55]!=local[5]) goto irtmodelIF936;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)-1L);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[5]= w;
	goto irtmodelIF937;
irtmodelIF936:
	local[5]= local[4];
	if (fqv[33]!=local[5]) goto irtmodelIF938;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[5]= w;
	goto irtmodelIF939;
irtmodelIF938:
	local[5]= local[4];
	if (fqv[56]!=local[5]) goto irtmodelIF940;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[5]= w;
	goto irtmodelIF941;
irtmodelIF940:
	local[5]= NIL;
irtmodelIF941:
irtmodelIF939:
irtmodelIF937:
irtmodelIF935:
irtmodelIF933:
irtmodelIF931:
	w = local[5];
	local[4]= w;
irtmodelIF929:
	argv[0]->c.obj.iv[14] = local[4];
	argv[0]->c.obj.iv[3] = makeflt(0.0000000000000000000000e+00);
	local[4]= (pointer)get_sym_func(fqv[34]);
	local[5]= argv[0];
	local[6]= *(ovafptr(argv[1],fqv[35]));
	local[7]= fqv[36];
	local[8]= fqv[8];
	local[9]= local[2];
	local[10]= fqv[9];
	local[11]= local[3];
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)APPLY(ctx,9,local+4); /*apply*/
	if (argv[0]->c.obj.iv[4]!=NIL) goto irtmodelIF942;
	argv[0]->c.obj.iv[4] = makeflt(-9.0000000000000000000000e+01);
	local[4]= argv[0]->c.obj.iv[4];
	goto irtmodelIF943;
irtmodelIF942:
	local[4]= NIL;
irtmodelIF943:
	if (argv[0]->c.obj.iv[5]!=NIL) goto irtmodelIF944;
	argv[0]->c.obj.iv[5] = makeflt(9.0000000000000000000000e+01);
	local[4]= argv[0]->c.obj.iv[5];
	goto irtmodelIF945;
irtmodelIF944:
	local[4]= NIL;
irtmodelIF945:
	local[4]= argv[0];
	local[5]= fqv[37];
	local[6]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= argv[0];
	local[5]= fqv[38];
	local[6]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= argv[0];
	local[5]= fqv[39];
	local[6]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	w = argv[0];
	local[0]= w;
irtmodelBLK923:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle*/
static pointer irtmodelM946linear_joint_joint_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT949;}
	local[0]= NIL;
irtmodelENT949:
irtmodelENT948:
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[57], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY950;
	local[1] = NIL;
irtmodelKEY950:
	if (local[0]==NIL) goto irtmodelIF951;
	if (local[1]==NIL) goto irtmodelIF953;
	local[2]= local[0];
	local[3]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[0] = w;
	local[2]= local[0];
	goto irtmodelIF954;
irtmodelIF953:
	local[2]= NIL;
irtmodelIF954:
	local[2]= local[0];
	local[3]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+4;
	w=(pointer)GREATERP(ctx,2,local+2); /*>*/
	if (w==NIL) goto irtmodelIF955;
	if (local[1]!=NIL) goto irtmodelIF957;
	local[2]= makeint((eusinteger_t)3L);
	local[3]= fqv[58];
	local[4]= argv[0];
	local[5]= local[0];
	local[6]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+7;
	w=(*ftab[5])(ctx,5,local+2,&ftab[5],fqv[44]); /*warning-message*/
	local[2]= w;
	goto irtmodelIF958;
irtmodelIF957:
	local[2]= NIL;
irtmodelIF958:
	local[0] = argv[0]->c.obj.iv[5];
	local[2]= local[0];
	goto irtmodelIF956;
irtmodelIF955:
	local[2]= NIL;
irtmodelIF956:
	local[2]= local[0];
	local[3]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,2,local+2); /*<*/
	if (w==NIL) goto irtmodelIF959;
	if (local[1]!=NIL) goto irtmodelIF961;
	local[2]= makeint((eusinteger_t)3L);
	local[3]= fqv[59];
	local[4]= argv[0];
	local[5]= local[0];
	local[6]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+7;
	w=(*ftab[5])(ctx,5,local+2,&ftab[5],fqv[44]); /*warning-message*/
	local[2]= w;
	goto irtmodelIF962;
irtmodelIF961:
	local[2]= NIL;
irtmodelIF962:
	local[0] = argv[0]->c.obj.iv[4];
	local[2]= local[0];
	goto irtmodelIF960;
irtmodelIF959:
	local[2]= NIL;
irtmodelIF960:
	argv[0]->c.obj.iv[3] = local[0];
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= fqv[46];
	local[4]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= fqv[60];
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+6;
	w=(pointer)SCALEVEC(ctx,2,local+4); /*scale*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto irtmodelIF952;
irtmodelIF951:
	local[2]= NIL;
irtmodelIF952:
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
irtmodelBLK947:
	ctx->vsp=local; return(local[0]);}

/*:joint-dof*/
static pointer irtmodelM963linear_joint_joint_dof(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = makeint((eusinteger_t)1L);
	local[0]= w;
irtmodelBLK964:
	ctx->vsp=local; return(local[0]);}

/*:calc-angle-speed-gain*/
static pointer irtmodelM965linear_joint_calc_angle_speed_gain(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0];
	local[1]= argv[2];
	local[2]= argv[3];
	local[3]= argv[4];
	ctx->vsp=local+4;
	w=(pointer)irtmodelF732calc_angle_speed_gain_scalar(ctx,4,local+0); /*calc-angle-speed-gain-scalar*/
	local[0]= w;
irtmodelBLK966:
	ctx->vsp=local; return(local[0]);}

/*:speed-to-angle*/
static pointer irtmodelM967linear_joint_speed_to_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeint((eusinteger_t)1000L);
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
irtmodelBLK968:
	ctx->vsp=local; return(local[0]);}

/*:angle-to-speed*/
static pointer irtmodelM969linear_joint_angle_to_speed(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeflt(1.0000000000000000208167e-03);
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
irtmodelBLK970:
	ctx->vsp=local; return(local[0]);}

/*:calc-jacobian*/
static pointer irtmodelM971linear_joint_calc_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST973:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[61]);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)APPLY(ctx,2,local+1); /*apply*/
	local[0]= w;
irtmodelBLK972:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtmodelM974wheel_joint_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST976:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[62], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY977;
	local[5]= loadglobal(fqv[63]);
	local[6]= loadglobal(fqv[63]);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,2,local+5); /*float-vector*/
	local[1] = w;
irtmodelKEY977:
	if (n & (1<<1)) goto irtmodelKEY978;
	local[5]= loadglobal(fqv[64]);
	local[6]= loadglobal(fqv[64]);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,2,local+5); /*float-vector*/
	local[2] = w;
irtmodelKEY978:
	if (n & (1<<2)) goto irtmodelKEY979;
	local[5]= makeflt(7.9999999999999960031971e-02);
	local[6]= makeflt(4.9999999999999988897770e-02);
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	local[6]= makeflt(3.1415926535897931159980e+00);
	local[7]= makeint((eusinteger_t)4L);
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,2,local+5); /*float-vector*/
	local[3] = w;
irtmodelKEY979:
	if (n & (1<<3)) goto irtmodelKEY980;
	local[5]= makeint((eusinteger_t)100L);
	local[6]= makeint((eusinteger_t)100L);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,2,local+5); /*float-vector*/
	local[4] = w;
irtmodelKEY980:
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,2,local+5); /*float-vector*/
	argv[0]->c.obj.iv[3] = w;
	local[5]= fqv[65];
	local[6]= fqv[33];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,2,local+5); /*list*/
	argv[0]->c.obj.iv[14] = w;
	local[5]= (pointer)get_sym_func(fqv[34]);
	local[6]= argv[0];
	local[7]= *(ovafptr(argv[1],fqv[35]));
	local[8]= fqv[36];
	local[9]= fqv[66];
	local[10]= local[1];
	local[11]= fqv[67];
	local[12]= local[2];
	local[13]= fqv[8];
	local[14]= local[3];
	local[15]= fqv[9];
	local[16]= local[4];
	local[17]= local[0];
	ctx->vsp=local+18;
	w=(pointer)APPLY(ctx,13,local+5); /*apply*/
	w = argv[0];
	local[0]= w;
irtmodelBLK975:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle*/
static pointer irtmodelM981wheel_joint_joint_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT984;}
	local[0]= NIL;
irtmodelENT984:
irtmodelENT983:
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[68], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY985;
	local[1] = NIL;
irtmodelKEY985:
	local[2]= NIL;
	local[3]= NIL;
	if (local[1]!=NIL) goto irtmodelIF986;
	if (local[0]==NIL) goto irtmodelIF988;
	local[4]= fqv[69];
	ctx->vsp=local+5;
	w=(*ftab[2])(ctx,1,local+4,&ftab[2],fqv[15]); /*warn*/
	local[4]= w;
	goto irtmodelIF989;
irtmodelIF988:
	local[4]= NIL;
irtmodelIF989:
	w = argv[0]->c.obj.iv[3];
	ctx->vsp=local+4;
	local[0]=w;
	goto irtmodelBLK982;
	goto irtmodelIF987;
irtmodelIF986:
	local[4]= NIL;
irtmodelIF987:
	if (local[0]==NIL) goto irtmodelIF990;
	local[4]= local[0];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[2] = w;
	local[4]= local[0];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[3] = w;
	local[4]= argv[0]->c.obj.iv[2];
	local[5]= fqv[60];
	local[6]= local[2];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,3,local+6); /*float-vector*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= argv[0]->c.obj.iv[2];
	local[5]= fqv[47];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(*ftab[6])(ctx,1,local+6,&ftab[6],fqv[48]); /*deg2rad*/
	local[6]= w;
	local[7]= fqv[33];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	goto irtmodelIF991;
irtmodelIF990:
	local[4]= NIL;
irtmodelIF991:
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
irtmodelBLK982:
	ctx->vsp=local; return(local[0]);}

/*:joint-dof*/
static pointer irtmodelM992wheel_joint_joint_dof(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = makeint((eusinteger_t)2L);
	local[0]= w;
irtmodelBLK993:
	ctx->vsp=local; return(local[0]);}

/*:calc-angle-speed-gain*/
static pointer irtmodelM994wheel_joint_calc_angle_speed_gain(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0];
	local[1]= argv[2];
	local[2]= argv[3];
	local[3]= argv[4];
	ctx->vsp=local+4;
	w=(pointer)irtmodelF733calc_angle_speed_gain_vector(ctx,4,local+0); /*calc-angle-speed-gain-vector*/
	local[0]= w;
irtmodelBLK995:
	ctx->vsp=local; return(local[0]);}

/*:speed-to-angle*/
static pointer irtmodelM996wheel_joint_speed_to_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeint((eusinteger_t)1000L);
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[7])(ctx,1,local+1,&ftab[7],fqv[49]); /*rad2deg*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MKFLTVEC(ctx,2,local+0); /*float-vector*/
	local[0]= w;
irtmodelBLK997:
	ctx->vsp=local; return(local[0]);}

/*:angle-to-speed*/
static pointer irtmodelM998wheel_joint_angle_to_speed(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeflt(1.0000000000000000208167e-03);
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,1,local+1,&ftab[6],fqv[48]); /*deg2rad*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MKFLTVEC(ctx,2,local+0); /*float-vector*/
	local[0]= w;
irtmodelBLK999:
	ctx->vsp=local; return(local[0]);}

/*:calc-jacobian*/
static pointer irtmodelM1000wheel_joint_calc_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=21) maerror();
	w = argv[5];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[28],w);
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= loadglobal(fqv[28]);
	local[7]= fqv[70];
	local[8]= argv[7];
	local[9]= argv[8];
	local[10]= argv[9];
	local[11]= argv[10];
	local[12]= argv[11];
	local[13]= argv[12];
	local[14]= argv[13];
	local[15]= argv[14];
	local[16]= argv[15];
	local[17]= argv[16];
	local[18]= argv[17];
	local[19]= argv[18];
	local[20]= argv[19];
	local[21]= argv[20];
	ctx->vsp=local+22;
	w=(pointer)irtmodelF731calc_jacobian_linear(ctx,19,local+3); /*calc-jacobian-linear*/
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	local[6]= loadglobal(fqv[28]);
	local[7]= fqv[71];
	local[8]= argv[7];
	local[9]= argv[8];
	local[10]= argv[9];
	local[11]= argv[10];
	local[12]= argv[11];
	local[13]= argv[12];
	local[14]= argv[13];
	local[15]= argv[14];
	local[16]= argv[15];
	local[17]= argv[16];
	local[18]= argv[17];
	local[19]= argv[18];
	local[20]= argv[19];
	local[21]= argv[20];
	ctx->vsp=local+22;
	w=(pointer)irtmodelF730calc_jacobian_rotational(ctx,19,local+3); /*calc-jacobian-rotational*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtmodelBLK1001:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtmodelM1002omniwheel_joint_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST1004:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[72], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1005;
	local[5]= loadglobal(fqv[63]);
	local[6]= loadglobal(fqv[63]);
	local[7]= loadglobal(fqv[63]);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[1] = w;
irtmodelKEY1005:
	if (n & (1<<1)) goto irtmodelKEY1006;
	local[5]= loadglobal(fqv[64]);
	local[6]= loadglobal(fqv[64]);
	local[7]= loadglobal(fqv[64]);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[2] = w;
irtmodelKEY1006:
	if (n & (1<<2)) goto irtmodelKEY1007;
	local[5]= makeflt(7.9999999999999960031971e-02);
	local[6]= makeflt(4.9999999999999988897770e-02);
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	local[6]= makeflt(7.9999999999999960031971e-02);
	local[7]= makeflt(4.9999999999999988897770e-02);
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[6]= w;
	local[7]= makeflt(3.1415926535897931159980e+00);
	local[8]= makeint((eusinteger_t)4L);
	ctx->vsp=local+9;
	w=(pointer)QUOTIENT(ctx,2,local+7); /*/*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[3] = w;
irtmodelKEY1007:
	if (n & (1<<3)) goto irtmodelKEY1008;
	local[5]= makeint((eusinteger_t)100L);
	local[6]= makeint((eusinteger_t)100L);
	local[7]= makeint((eusinteger_t)100L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[4] = w;
irtmodelKEY1008:
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	argv[0]->c.obj.iv[3] = w;
	local[5]= fqv[73];
	local[6]= fqv[74];
	local[7]= fqv[33];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,3,local+5); /*list*/
	argv[0]->c.obj.iv[14] = w;
	local[5]= (pointer)get_sym_func(fqv[34]);
	local[6]= argv[0];
	local[7]= *(ovafptr(argv[1],fqv[35]));
	local[8]= fqv[36];
	local[9]= fqv[66];
	local[10]= local[1];
	local[11]= fqv[67];
	local[12]= local[2];
	local[13]= fqv[8];
	local[14]= local[3];
	local[15]= fqv[9];
	local[16]= local[4];
	local[17]= local[0];
	ctx->vsp=local+18;
	w=(pointer)APPLY(ctx,13,local+5); /*apply*/
	w = argv[0];
	local[0]= w;
irtmodelBLK1003:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle*/
static pointer irtmodelM1009omniwheel_joint_joint_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT1012;}
	local[0]= NIL;
irtmodelENT1012:
irtmodelENT1011:
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[75], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1013;
	local[1] = NIL;
irtmodelKEY1013:
	if (local[0]==NIL) goto irtmodelIF1014;
	if (local[1]==NIL) goto irtmodelIF1016;
	local[2]= local[0];
	local[3]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+4;
	w=(pointer)VPLUS(ctx,2,local+2); /*v+*/
	local[0] = w;
	local[2]= local[0];
	goto irtmodelIF1017;
irtmodelIF1016:
	local[2]= NIL;
irtmodelIF1017:
	local[2]= local[0];
	local[3]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+4;
	w=(pointer)VMAX(ctx,2,local+2); /*vmax*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+4;
	w=(pointer)VMIN(ctx,2,local+2); /*vmin*/
	argv[0]->c.obj.iv[3] = w;
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= fqv[46];
	local[4]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= fqv[60];
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[3];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,3,local+4); /*float-vector*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= fqv[47];
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[6])(ctx,1,local+4,&ftab[6],fqv[48]); /*deg2rad*/
	local[4]= w;
	local[5]= fqv[33];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	goto irtmodelIF1015;
irtmodelIF1014:
	local[2]= NIL;
irtmodelIF1015:
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
irtmodelBLK1010:
	ctx->vsp=local; return(local[0]);}

/*:joint-dof*/
static pointer irtmodelM1018omniwheel_joint_joint_dof(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = makeint((eusinteger_t)3L);
	local[0]= w;
irtmodelBLK1019:
	ctx->vsp=local; return(local[0]);}

/*:calc-angle-speed-gain*/
static pointer irtmodelM1020omniwheel_joint_calc_angle_speed_gain(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0];
	local[1]= argv[2];
	local[2]= argv[3];
	local[3]= argv[4];
	ctx->vsp=local+4;
	w=(pointer)irtmodelF733calc_angle_speed_gain_vector(ctx,4,local+0); /*calc-angle-speed-gain-vector*/
	local[0]= w;
irtmodelBLK1021:
	ctx->vsp=local; return(local[0]);}

/*:speed-to-angle*/
static pointer irtmodelM1022omniwheel_joint_speed_to_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeint((eusinteger_t)1000L);
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1000L);
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[7])(ctx,1,local+2,&ftab[7],fqv[49]); /*rad2deg*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
irtmodelBLK1023:
	ctx->vsp=local; return(local[0]);}

/*:angle-to-speed*/
static pointer irtmodelM1024omniwheel_joint_angle_to_speed(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeflt(1.0000000000000000208167e-03);
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= makeflt(1.0000000000000000208167e-03);
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[6])(ctx,1,local+2,&ftab[6],fqv[48]); /*deg2rad*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
irtmodelBLK1025:
	ctx->vsp=local; return(local[0]);}

/*:calc-jacobian*/
static pointer irtmodelM1026omniwheel_joint_calc_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=21) maerror();
	w = argv[5];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[28],w);
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= loadglobal(fqv[28]);
	local[7]= fqv[76];
	local[8]= argv[7];
	local[9]= argv[8];
	local[10]= argv[9];
	local[11]= argv[10];
	local[12]= argv[11];
	local[13]= argv[12];
	local[14]= argv[13];
	local[15]= argv[14];
	local[16]= argv[15];
	local[17]= argv[16];
	local[18]= argv[17];
	local[19]= argv[18];
	local[20]= argv[19];
	local[21]= argv[20];
	ctx->vsp=local+22;
	w=(pointer)irtmodelF731calc_jacobian_linear(ctx,19,local+3); /*calc-jacobian-linear*/
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	local[6]= loadglobal(fqv[28]);
	local[7]= fqv[77];
	local[8]= argv[7];
	local[9]= argv[8];
	local[10]= argv[9];
	local[11]= argv[10];
	local[12]= argv[11];
	local[13]= argv[12];
	local[14]= argv[13];
	local[15]= argv[14];
	local[16]= argv[15];
	local[17]= argv[16];
	local[18]= argv[17];
	local[19]= argv[18];
	local[20]= argv[19];
	local[21]= argv[20];
	ctx->vsp=local+22;
	w=(pointer)irtmodelF731calc_jacobian_linear(ctx,19,local+3); /*calc-jacobian-linear*/
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	local[6]= loadglobal(fqv[28]);
	local[7]= fqv[78];
	local[8]= argv[7];
	local[9]= argv[8];
	local[10]= argv[9];
	local[11]= argv[10];
	local[12]= argv[11];
	local[13]= argv[12];
	local[14]= argv[13];
	local[15]= argv[14];
	local[16]= argv[15];
	local[17]= argv[16];
	local[18]= argv[17];
	local[19]= argv[18];
	local[20]= argv[19];
	local[21]= argv[20];
	ctx->vsp=local+22;
	w=(pointer)irtmodelF730calc_jacobian_rotational(ctx,19,local+3); /*calc-jacobian-rotational*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtmodelBLK1027:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtmodelM1028sphere_joint_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST1030:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[79], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1031;
	local[5]= loadglobal(fqv[63]);
	local[6]= loadglobal(fqv[63]);
	local[7]= loadglobal(fqv[63]);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[1] = w;
irtmodelKEY1031:
	if (n & (1<<1)) goto irtmodelKEY1032;
	local[5]= loadglobal(fqv[64]);
	local[6]= loadglobal(fqv[64]);
	local[7]= loadglobal(fqv[64]);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[2] = w;
irtmodelKEY1032:
	if (n & (1<<2)) goto irtmodelKEY1033;
	local[5]= makeflt(3.1415926535897931159980e+00);
	local[6]= makeint((eusinteger_t)4L);
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	local[6]= makeflt(3.1415926535897931159980e+00);
	local[7]= makeint((eusinteger_t)4L);
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[6]= w;
	local[7]= makeflt(3.1415926535897931159980e+00);
	local[8]= makeint((eusinteger_t)4L);
	ctx->vsp=local+9;
	w=(pointer)QUOTIENT(ctx,2,local+7); /*/*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[3] = w;
irtmodelKEY1033:
	if (n & (1<<3)) goto irtmodelKEY1034;
	local[5]= makeint((eusinteger_t)100L);
	local[6]= makeint((eusinteger_t)100L);
	local[7]= makeint((eusinteger_t)100L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[4] = w;
irtmodelKEY1034:
	local[5]= fqv[52];
	local[6]= fqv[54];
	local[7]= fqv[33];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,3,local+5); /*list*/
	argv[0]->c.obj.iv[14] = w;
	local[5]= (pointer)get_sym_func(fqv[34]);
	local[6]= argv[0];
	local[7]= *(ovafptr(argv[1],fqv[35]));
	local[8]= fqv[36];
	local[9]= fqv[66];
	local[10]= local[1];
	local[11]= fqv[67];
	local[12]= local[2];
	local[13]= fqv[8];
	local[14]= local[3];
	local[15]= fqv[9];
	local[16]= local[4];
	local[17]= local[0];
	ctx->vsp=local+18;
	w=(pointer)APPLY(ctx,13,local+5); /*apply*/
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	argv[0]->c.obj.iv[3] = w;
	w = argv[0];
	local[0]= w;
irtmodelBLK1029:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle*/
static pointer irtmodelM1035sphere_joint_joint_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT1038;}
	local[0]= NIL;
irtmodelENT1038:
irtmodelENT1037:
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[80], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1039;
	local[1] = NIL;
irtmodelKEY1039:
	if (local[0]==NIL) goto irtmodelIF1040;
	if (local[1]==NIL) goto irtmodelCON1043;
	local[2]= loadglobal(fqv[5]);
	local[3]= (pointer)get_sym_func(fqv[48]);
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)MAP(ctx,3,local+2); /*map*/
	local[2]= w;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)VNORM(ctx,1,local+3); /*norm*/
	local[3]= w;
	local[4]= makeflt(0.0000000000000000000000e+00);
	local[5]= makeflt(9.9999999999999949376344e-21);
	ctx->vsp=local+6;
	w=(*ftab[8])(ctx,3,local+3,&ftab[8],fqv[81]); /*eps=*/
	if (w!=NIL) goto irtmodelIF1044;
	local[3]= loadglobal(fqv[5]);
	local[4]= (pointer)get_sym_func(fqv[48]);
	local[5]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+6;
	w=(pointer)MAP(ctx,3,local+3); /*map*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[9])(ctx,1,local+3,&ftab[9],fqv[82]); /*matrix-exponent*/
	local[3]= w;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)VNORM(ctx,1,local+4); /*norm*/
	local[4]= w;
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(*ftab[4])(ctx,1,local+5,&ftab[4],fqv[26]); /*normalize-vector*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)ROTATION_MATRIX(ctx,2,local+4); /*rotation-matrix*/
	local[4]= w;
	local[5]= local[3];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)MATTIMES(ctx,3,local+4); /*m**/
	local[4]= loadglobal(fqv[5]);
	local[5]= (pointer)get_sym_func(fqv[49]);
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(*ftab[10])(ctx,1,local+6,&ftab[10],fqv[83]); /*matrix-log*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MAP(ctx,3,local+4); /*map*/
	argv[0]->c.obj.iv[3] = w;
	w = argv[0]->c.obj.iv[3];
	local[3]= w;
	goto irtmodelIF1045;
irtmodelIF1044:
	local[3]= NIL;
irtmodelIF1045:
	w = local[3];
	local[2]= w;
	goto irtmodelCON1042;
irtmodelCON1043:
	argv[0]->c.obj.iv[3] = local[0];
	local[2]= argv[0]->c.obj.iv[3];
	goto irtmodelCON1042;
irtmodelCON1046:
	local[2]= NIL;
irtmodelCON1042:
	local[2]= argv[0]->c.obj.iv[3];
	local[3]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+4;
	w=(pointer)VMAX(ctx,2,local+2); /*vmax*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+4;
	w=(pointer)VMIN(ctx,2,local+2); /*vmin*/
	argv[0]->c.obj.iv[3] = w;
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= fqv[46];
	local[4]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= fqv[84];
	local[4]= fqv[85];
	local[5]= loadglobal(fqv[5]);
	local[6]= (pointer)get_sym_func(fqv[48]);
	local[7]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+8;
	w=(pointer)MAP(ctx,3,local+5); /*map*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[9])(ctx,1,local+5,&ftab[9],fqv[82]); /*matrix-exponent*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[11])(ctx,2,local+4,&ftab[11],fqv[86]); /*make-coords*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto irtmodelIF1041;
irtmodelIF1040:
	local[2]= NIL;
irtmodelIF1041:
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
irtmodelBLK1036:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle-rpy*/
static pointer irtmodelM1047sphere_joint_joint_angle_rpy(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT1050;}
	local[0]= NIL;
irtmodelENT1050:
irtmodelENT1049:
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[87], &argv[3], n-3, local+1, 0);
	if (n & (1<<0)) goto irtmodelKEY1051;
	local[1] = NIL;
irtmodelKEY1051:
	if (local[0]==NIL) goto irtmodelIF1052;
	if (local[1]==NIL) goto irtmodelIF1054;
	local[2]= loadglobal(fqv[5]);
	local[3]= (pointer)get_sym_func(fqv[48]);
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)MAP(ctx,3,local+2); /*map*/
	local[2]= w;
	local[3]= loadglobal(fqv[5]);
	local[4]= (pointer)get_sym_func(fqv[48]);
	local[5]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+6;
	w=(pointer)MAP(ctx,3,local+3); /*map*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[9])(ctx,1,local+3,&ftab[9],fqv[82]); /*matrix-exponent*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)INV_RPY(ctx,1,local+3); /*rpy-angle*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= loadglobal(fqv[5]);
	ctx->vsp=local+5;
	w=(pointer)COERCE(ctx,2,local+3); /*coerce*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)VPLUS(ctx,2,local+2); /*v+*/
	local[2]= w;
	goto irtmodelIF1055;
irtmodelIF1054:
	local[2]= loadglobal(fqv[5]);
	local[3]= (pointer)get_sym_func(fqv[48]);
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)MAP(ctx,3,local+2); /*map*/
	local[2]= w;
irtmodelIF1055:
	local[3]= argv[0];
	local[4]= fqv[20];
	local[5]= loadglobal(fqv[88]);
	local[6]= (pointer)get_sym_func(fqv[49]);
	local[7]= local[2];
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	local[8]= local[2];
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	local[9]= local[2];
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[12])(ctx,3,local+7,&ftab[12],fqv[89]); /*rpy-matrix*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[10])(ctx,1,local+7,&ftab[10],fqv[83]); /*matrix-log*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MAP(ctx,3,local+5); /*map*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[2]= w;
	goto irtmodelIF1053;
irtmodelIF1052:
	local[2]= NIL;
irtmodelIF1053:
	local[2]= loadglobal(fqv[5]);
	local[3]= (pointer)get_sym_func(fqv[49]);
	local[4]= loadglobal(fqv[5]);
	local[5]= (pointer)get_sym_func(fqv[48]);
	local[6]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+7;
	w=(pointer)MAP(ctx,3,local+4); /*map*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[9])(ctx,1,local+4,&ftab[9],fqv[82]); /*matrix-exponent*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)INV_RPY(ctx,1,local+4); /*rpy-angle*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)MAP(ctx,3,local+2); /*map*/
	local[0]= w;
irtmodelBLK1048:
	ctx->vsp=local; return(local[0]);}

/*:joint-dof*/
static pointer irtmodelM1056sphere_joint_joint_dof(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = makeint((eusinteger_t)3L);
	local[0]= w;
irtmodelBLK1057:
	ctx->vsp=local; return(local[0]);}

/*:calc-angle-speed-gain*/
static pointer irtmodelM1058sphere_joint_calc_angle_speed_gain(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0];
	local[1]= argv[2];
	local[2]= argv[3];
	local[3]= argv[4];
	ctx->vsp=local+4;
	w=(pointer)irtmodelF733calc_angle_speed_gain_vector(ctx,4,local+0); /*calc-angle-speed-gain-vector*/
	local[0]= w;
irtmodelBLK1059:
	ctx->vsp=local; return(local[0]);}

/*:speed-to-angle*/
static pointer irtmodelM1060sphere_joint_speed_to_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[7])(ctx,1,local+0,&ftab[7],fqv[49]); /*rad2deg*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[7])(ctx,1,local+1,&ftab[7],fqv[49]); /*rad2deg*/
	local[1]= w;
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[7])(ctx,1,local+2,&ftab[7],fqv[49]); /*rad2deg*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
irtmodelBLK1061:
	ctx->vsp=local; return(local[0]);}

/*:angle-to-speed*/
static pointer irtmodelM1062sphere_joint_angle_to_speed(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[6])(ctx,1,local+0,&ftab[6],fqv[48]); /*deg2rad*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,1,local+1,&ftab[6],fqv[48]); /*deg2rad*/
	local[1]= w;
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[6])(ctx,1,local+2,&ftab[6],fqv[48]); /*deg2rad*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
irtmodelBLK1063:
	ctx->vsp=local; return(local[0]);}

/*:calc-jacobian*/
static pointer irtmodelM1064sphere_joint_calc_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=21) maerror();
	w = argv[5];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[28],w);
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= loadglobal(fqv[28]);
	local[7]= fqv[90];
	local[8]= argv[7];
	local[9]= argv[8];
	local[10]= argv[9];
	local[11]= argv[10];
	local[12]= argv[11];
	local[13]= argv[12];
	local[14]= argv[13];
	local[15]= argv[14];
	local[16]= argv[15];
	local[17]= argv[16];
	local[18]= argv[17];
	local[19]= argv[18];
	local[20]= argv[19];
	local[21]= argv[20];
	ctx->vsp=local+22;
	w=(pointer)irtmodelF730calc_jacobian_rotational(ctx,19,local+3); /*calc-jacobian-rotational*/
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	local[6]= loadglobal(fqv[28]);
	local[7]= fqv[91];
	local[8]= argv[7];
	local[9]= argv[8];
	local[10]= argv[9];
	local[11]= argv[10];
	local[12]= argv[11];
	local[13]= argv[12];
	local[14]= argv[13];
	local[15]= argv[14];
	local[16]= argv[15];
	local[17]= argv[16];
	local[18]= argv[17];
	local[19]= argv[18];
	local[20]= argv[19];
	local[21]= argv[20];
	ctx->vsp=local+22;
	w=(pointer)irtmodelF730calc_jacobian_rotational(ctx,19,local+3); /*calc-jacobian-rotational*/
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	local[6]= loadglobal(fqv[28]);
	local[7]= fqv[92];
	local[8]= argv[7];
	local[9]= argv[8];
	local[10]= argv[9];
	local[11]= argv[10];
	local[12]= argv[11];
	local[13]= argv[12];
	local[14]= argv[13];
	local[15]= argv[14];
	local[16]= argv[15];
	local[17]= argv[16];
	local[18]= argv[17];
	local[19]= argv[18];
	local[20]= argv[19];
	local[21]= argv[20];
	ctx->vsp=local+22;
	w=(pointer)irtmodelF730calc_jacobian_rotational(ctx,19,local+3); /*calc-jacobian-rotational*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtmodelBLK1065:
	ctx->vsp=local; return(local[0]);}

/*:joint-euler-angle*/
static pointer irtmodelM1066sphere_joint_joint_euler_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[93], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY1068;
	local[0] = fqv[94];
irtmodelKEY1068:
	if (n & (1<<1)) goto irtmodelKEY1069;
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= fqv[85];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[1] = w;
irtmodelKEY1069:
	local[2]= loadglobal(fqv[88]);
	local[3]= (pointer)get_sym_func(fqv[49]);
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
	local[5]= local[4];
	if (fqv[95]!=local[5]) goto irtmodelIF1070;
	local[5]= local[0];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= local[5];
	if (fqv[54]!=local[6]) goto irtmodelIF1072;
	local[6]= local[1];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,1,local+6); /*-*/
	local[6]= w;
	local[7]= local[1];
	local[8]= makeint((eusinteger_t)2L);
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[13])(ctx,2,local+6,&ftab[13],fqv[96]); /*atan2*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	local[6]= w;
	goto irtmodelIF1073;
irtmodelIF1072:
	local[6]= local[5];
	if (fqv[52]!=local[6]) goto irtmodelIF1074;
	local[6]= local[1];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= local[1];
	local[8]= makeint((eusinteger_t)2L);
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[13])(ctx,2,local+6,&ftab[13],fqv[96]); /*atan2*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	local[6]= w;
	goto irtmodelIF1075;
irtmodelIF1074:
	local[6]= local[5];
	if (fqv[33]!=local[6]) goto irtmodelIF1076;
	local[6]= local[1];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= local[1];
	local[8]= makeint((eusinteger_t)1L);
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[13])(ctx,2,local+6,&ftab[13],fqv[96]); /*atan2*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	local[6]= w;
	goto irtmodelIF1077;
irtmodelIF1076:
	local[6]= NIL;
irtmodelIF1077:
irtmodelIF1075:
irtmodelIF1073:
	w = local[6];
	local[5]= w;
	goto irtmodelIF1071;
irtmodelIF1070:
	local[5]= local[4];
	if (fqv[97]!=local[5]) goto irtmodelIF1078;
	local[5]= local[0];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= local[5];
	if (fqv[54]!=local[6]) goto irtmodelIF1080;
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= local[6];
	if (fqv[52]!=local[7]) goto irtmodelIF1082;
	local[7]= local[1];
	local[8]= makeint((eusinteger_t)2L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,1,local+7); /*-*/
	local[7]= w;
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[13])(ctx,2,local+7,&ftab[13],fqv[96]); /*atan2*/
	local[7]= w;
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)1L);
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,1,local+8); /*-*/
	local[8]= w;
	local[9]= local[1];
	local[10]= makeint((eusinteger_t)1L);
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[96]); /*atan2*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	goto irtmodelIF1083;
irtmodelIF1082:
	local[7]= local[6];
	if (fqv[33]!=local[7]) goto irtmodelIF1084;
	local[7]= local[1];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)2L);
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[13])(ctx,2,local+7,&ftab[13],fqv[96]); /*atan2*/
	local[7]= w;
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)1L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	local[9]= local[1];
	local[10]= makeint((eusinteger_t)1L);
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[96]); /*atan2*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	goto irtmodelIF1085;
irtmodelIF1084:
	local[7]= local[6];
	if (fqv[54]!=local[7]) goto irtmodelIF1086;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	local[9]= local[1];
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[96]); /*atan2*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	goto irtmodelIF1087;
irtmodelIF1086:
	local[7]= NIL;
irtmodelIF1087:
irtmodelIF1085:
irtmodelIF1083:
	w = local[7];
	local[6]= w;
	goto irtmodelIF1081;
irtmodelIF1080:
	local[6]= local[5];
	if (fqv[52]!=local[6]) goto irtmodelIF1088;
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= local[6];
	if (fqv[54]!=local[7]) goto irtmodelIF1090;
	local[7]= local[1];
	local[8]= makeint((eusinteger_t)2L);
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)1L);
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[13])(ctx,2,local+7,&ftab[13],fqv[96]); /*atan2*/
	local[7]= w;
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	local[9]= local[1];
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[96]); /*atan2*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	goto irtmodelIF1091;
irtmodelIF1090:
	local[7]= local[6];
	if (fqv[33]!=local[7]) goto irtmodelIF1092;
	local[7]= local[1];
	local[8]= makeint((eusinteger_t)1L);
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,1,local+7); /*-*/
	local[7]= w;
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)2L);
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[13])(ctx,2,local+7,&ftab[13],fqv[96]); /*atan2*/
	local[7]= w;
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,1,local+8); /*-*/
	local[8]= w;
	local[9]= local[1];
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[96]); /*atan2*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	goto irtmodelIF1093;
irtmodelIF1092:
	local[7]= local[6];
	if (fqv[52]!=local[7]) goto irtmodelIF1094;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)2L);
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	local[9]= local[1];
	local[10]= makeint((eusinteger_t)2L);
	local[11]= makeint((eusinteger_t)2L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[96]); /*atan2*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	goto irtmodelIF1095;
irtmodelIF1094:
	local[7]= NIL;
irtmodelIF1095:
irtmodelIF1093:
irtmodelIF1091:
	w = local[7];
	local[6]= w;
	goto irtmodelIF1089;
irtmodelIF1088:
	local[6]= local[5];
	if (fqv[33]!=local[6]) goto irtmodelIF1096;
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= local[6];
	if (fqv[54]!=local[7]) goto irtmodelIF1098;
	local[7]= local[1];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,1,local+7); /*-*/
	local[7]= w;
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)1L);
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[13])(ctx,2,local+7,&ftab[13],fqv[96]); /*atan2*/
	local[7]= w;
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)2L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,1,local+8); /*-*/
	local[8]= w;
	local[9]= local[1];
	local[10]= makeint((eusinteger_t)2L);
	local[11]= makeint((eusinteger_t)2L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[96]); /*atan2*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	goto irtmodelIF1099;
irtmodelIF1098:
	local[7]= local[6];
	if (fqv[52]!=local[7]) goto irtmodelIF1100;
	local[7]= local[1];
	local[8]= makeint((eusinteger_t)1L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[13])(ctx,2,local+7,&ftab[13],fqv[96]); /*atan2*/
	local[7]= w;
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)2L);
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	local[9]= local[1];
	local[10]= makeint((eusinteger_t)2L);
	local[11]= makeint((eusinteger_t)2L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[96]); /*atan2*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	goto irtmodelIF1101;
irtmodelIF1100:
	local[7]= local[6];
	if (fqv[33]!=local[7]) goto irtmodelIF1102;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)1L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	local[9]= local[1];
	local[10]= makeint((eusinteger_t)1L);
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,3,local+9); /*aref*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[96]); /*atan2*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	goto irtmodelIF1103;
irtmodelIF1102:
	local[7]= NIL;
irtmodelIF1103:
irtmodelIF1101:
irtmodelIF1099:
	w = local[7];
	local[6]= w;
	goto irtmodelIF1097;
irtmodelIF1096:
	local[6]= NIL;
irtmodelIF1097:
irtmodelIF1089:
irtmodelIF1081:
	w = local[6];
	local[5]= w;
	goto irtmodelIF1079;
irtmodelIF1078:
	local[5]= local[4];
	if (fqv[98]!=local[5]) goto irtmodelIF1104;
	local[5]= local[1];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(*ftab[14])(ctx,2,local+5,&ftab[14],fqv[99]); /*matrix-to-euler-angle*/
	local[5]= w;
	goto irtmodelIF1105;
irtmodelIF1104:
	local[5]= NIL;
irtmodelIF1105:
irtmodelIF1079:
irtmodelIF1071:
	w = local[5];
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MAP(ctx,3,local+2); /*map*/
	local[0]= w;
irtmodelBLK1067:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtmodelM11066dof_joint_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST1108:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[100], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1109;
	local[6]= loadglobal(fqv[63]);
	local[7]= loadglobal(fqv[63]);
	local[8]= loadglobal(fqv[63]);
	local[9]= loadglobal(fqv[63]);
	local[10]= loadglobal(fqv[63]);
	local[11]= loadglobal(fqv[63]);
	ctx->vsp=local+12;
	w=(pointer)MKFLTVEC(ctx,6,local+6); /*float-vector*/
	local[1] = w;
irtmodelKEY1109:
	if (n & (1<<1)) goto irtmodelKEY1110;
	local[6]= loadglobal(fqv[64]);
	local[7]= loadglobal(fqv[64]);
	local[8]= loadglobal(fqv[64]);
	local[9]= loadglobal(fqv[64]);
	local[10]= loadglobal(fqv[64]);
	local[11]= loadglobal(fqv[64]);
	ctx->vsp=local+12;
	w=(pointer)MKFLTVEC(ctx,6,local+6); /*float-vector*/
	local[2] = w;
irtmodelKEY1110:
	if (n & (1<<2)) goto irtmodelKEY1111;
	local[6]= makeflt(7.9999999999999960031971e-02);
	local[7]= makeflt(4.9999999999999988897770e-02);
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[6]= w;
	local[7]= makeflt(7.9999999999999960031971e-02);
	local[8]= makeflt(4.9999999999999988897770e-02);
	ctx->vsp=local+9;
	w=(pointer)QUOTIENT(ctx,2,local+7); /*/*/
	local[7]= w;
	local[8]= makeflt(7.9999999999999960031971e-02);
	local[9]= makeflt(4.9999999999999988897770e-02);
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	local[8]= w;
	local[9]= makeflt(3.1415926535897931159980e+00);
	local[10]= makeint((eusinteger_t)4L);
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[9]= w;
	local[10]= makeflt(3.1415926535897931159980e+00);
	local[11]= makeint((eusinteger_t)4L);
	ctx->vsp=local+12;
	w=(pointer)QUOTIENT(ctx,2,local+10); /*/*/
	local[10]= w;
	local[11]= makeflt(3.1415926535897931159980e+00);
	local[12]= makeint((eusinteger_t)4L);
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)MKFLTVEC(ctx,6,local+6); /*float-vector*/
	local[3] = w;
irtmodelKEY1111:
	if (n & (1<<3)) goto irtmodelKEY1112;
	local[6]= makeint((eusinteger_t)100L);
	local[7]= makeint((eusinteger_t)100L);
	local[8]= makeint((eusinteger_t)100L);
	local[9]= makeint((eusinteger_t)100L);
	local[10]= makeint((eusinteger_t)100L);
	local[11]= makeint((eusinteger_t)100L);
	ctx->vsp=local+12;
	w=(pointer)MKFLTVEC(ctx,6,local+6); /*float-vector*/
	local[4] = w;
irtmodelKEY1112:
	if (n & (1<<4)) goto irtmodelKEY1113;
	local[5] = NIL;
irtmodelKEY1113:
	local[6]= fqv[101];
	local[7]= fqv[102];
	local[8]= fqv[103];
	local[9]= fqv[52];
	local[10]= fqv[54];
	local[11]= fqv[33];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,6,local+6); /*list*/
	argv[0]->c.obj.iv[14] = w;
	local[6]= (pointer)get_sym_func(fqv[34]);
	local[7]= argv[0];
	local[8]= *(ovafptr(argv[1],fqv[35]));
	local[9]= fqv[36];
	local[10]= fqv[66];
	local[11]= local[1];
	local[12]= fqv[67];
	local[13]= local[2];
	local[14]= fqv[8];
	local[15]= local[3];
	local[16]= fqv[9];
	local[17]= local[4];
	local[18]= local[0];
	ctx->vsp=local+19;
	w=(pointer)APPLY(ctx,13,local+6); /*apply*/
	if (local[5]==NIL) goto irtmodelIF1114;
	local[6]= argv[0]->c.obj.iv[1];
	local[7]= fqv[104];
	local[8]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	local[7]= fqv[105];
	local[8]= argv[0]->c.obj.iv[6];
	local[9]= fqv[29];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[11])(ctx,2,local+7,&ftab[11],fqv[86]); /*make-coords*/
	local[7]= w;
	local[8]= local[7];
	local[9]= fqv[106];
	local[10]= local[6];
	local[11]= fqv[29];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	local[9]= local[7];
	local[10]= fqv[27];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)TRANSPOSE(ctx,1,local+9); /*transpose*/
	local[9]= w;
	local[10]= local[6];
	local[11]= fqv[27];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)MATTIMES(ctx,2,local+9); /*m**/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[10])(ctx,1,local+9,&ftab[10],fqv[83]); /*matrix-log*/
	local[9]= w;
	local[10]= local[8];
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	local[11]= local[8];
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= local[8];
	local[13]= makeint((eusinteger_t)2L);
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= local[9];
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(*ftab[7])(ctx,1,local+13,&ftab[7],fqv[49]); /*rad2deg*/
	local[13]= w;
	local[14]= local[9];
	local[15]= makeint((eusinteger_t)1L);
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(*ftab[7])(ctx,1,local+14,&ftab[7],fqv[49]); /*rad2deg*/
	local[14]= w;
	local[15]= local[9];
	local[16]= makeint((eusinteger_t)2L);
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(*ftab[7])(ctx,1,local+15,&ftab[7],fqv[49]); /*rad2deg*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)MKFLTVEC(ctx,6,local+10); /*float-vector*/
	argv[0]->c.obj.iv[3] = w;
	argv[0]->c.obj.iv[6] = local[7];
	w = argv[0]->c.obj.iv[6];
	local[6]= w;
	goto irtmodelIF1115;
irtmodelIF1114:
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)MKFLTVEC(ctx,6,local+6); /*float-vector*/
	argv[0]->c.obj.iv[3] = w;
	local[6]= argv[0]->c.obj.iv[3];
irtmodelIF1115:
	w = argv[0];
	local[0]= w;
irtmodelBLK1107:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle*/
static pointer irtmodelM11166dof_joint_joint_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT1119;}
	local[0]= NIL;
irtmodelENT1119:
irtmodelENT1118:
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[107], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1120;
	local[1] = NIL;
irtmodelKEY1120:
	if (local[0]==NIL) goto irtmodelIF1121;
	local[2]= NIL;
	local[3]= NIL;
	if (local[1]==NIL) goto irtmodelIF1123;
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)3L);
	ctx->vsp=local+7;
	w=(pointer)SUBSEQ(ctx,3,local+4); /*subseq*/
	local[4]= w;
	local[5]= local[0];
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(pointer)SUBSEQ(ctx,3,local+5); /*subseq*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)VPLUS(ctx,2,local+4); /*v+*/
	local[4]= w;
	goto irtmodelIF1124;
irtmodelIF1123:
	local[4]= local[0];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)3L);
	ctx->vsp=local+7;
	w=(pointer)SUBSEQ(ctx,3,local+4); /*subseq*/
	local[4]= w;
irtmodelIF1124:
	local[2] = local[4];
	if (local[1]==NIL) goto irtmodelCON1126;
	local[4]= loadglobal(fqv[5]);
	local[5]= (pointer)get_sym_func(fqv[48]);
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)3L);
	local[8]= makeint((eusinteger_t)6L);
	ctx->vsp=local+9;
	w=(pointer)SUBSEQ(ctx,3,local+6); /*subseq*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MAP(ctx,3,local+4); /*map*/
	local[4]= w;
	local[5]= local[4];
	ctx->vsp=local+6;
	w=(pointer)VNORM(ctx,1,local+5); /*norm*/
	local[5]= w;
	local[6]= makeflt(0.0000000000000000000000e+00);
	local[7]= makeflt(9.9999999999999949376344e-21);
	ctx->vsp=local+8;
	w=(*ftab[8])(ctx,3,local+5,&ftab[8],fqv[81]); /*eps=*/
	if (w==NIL) goto irtmodelIF1127;
	local[5]= argv[0]->c.obj.iv[3];
	local[6]= makeint((eusinteger_t)3L);
	local[7]= makeint((eusinteger_t)6L);
	ctx->vsp=local+8;
	w=(pointer)SUBSEQ(ctx,3,local+5); /*subseq*/
	local[3] = w;
	local[5]= local[3];
	goto irtmodelIF1128;
irtmodelIF1127:
	local[5]= loadglobal(fqv[5]);
	local[6]= (pointer)get_sym_func(fqv[48]);
	local[7]= argv[0]->c.obj.iv[3];
	local[8]= makeint((eusinteger_t)3L);
	local[9]= makeint((eusinteger_t)6L);
	ctx->vsp=local+10;
	w=(pointer)SUBSEQ(ctx,3,local+7); /*subseq*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MAP(ctx,3,local+5); /*map*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[9])(ctx,1,local+5,&ftab[9],fqv[82]); /*matrix-exponent*/
	local[5]= w;
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)VNORM(ctx,1,local+6); /*norm*/
	local[6]= w;
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(*ftab[4])(ctx,1,local+7,&ftab[4],fqv[26]); /*normalize-vector*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)ROTATION_MATRIX(ctx,2,local+6); /*rotation-matrix*/
	local[6]= w;
	local[7]= local[5];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)MATTIMES(ctx,3,local+6); /*m**/
	local[6]= loadglobal(fqv[5]);
	local[7]= (pointer)get_sym_func(fqv[49]);
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(*ftab[10])(ctx,1,local+8,&ftab[10],fqv[83]); /*matrix-log*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MAP(ctx,3,local+6); /*map*/
	local[3] = w;
	w = local[3];
	local[5]= w;
irtmodelIF1128:
	w = local[5];
	local[4]= w;
	goto irtmodelCON1125;
irtmodelCON1126:
	local[4]= local[0];
	local[5]= makeint((eusinteger_t)3L);
	local[6]= makeint((eusinteger_t)6L);
	ctx->vsp=local+7;
	w=(pointer)SUBSEQ(ctx,3,local+4); /*subseq*/
	local[3] = w;
	local[4]= local[3];
	goto irtmodelCON1125;
irtmodelCON1129:
	local[4]= NIL;
irtmodelCON1125:
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)3L);
irtmodelWHL1130:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto irtmodelWHX1131;
	local[6]= argv[0]->c.obj.iv[3];
	local[7]= local[4];
	local[8]= local[2];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SETELT(ctx,3,local+6); /*setelt*/
	local[6]= argv[0]->c.obj.iv[3];
	local[7]= local[4];
	w = makeint((eusinteger_t)3L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[7]= (pointer)((eusinteger_t)local[7] + (eusinteger_t)w);
	local[8]= local[3];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SETELT(ctx,3,local+6); /*setelt*/
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto irtmodelWHL1130;
irtmodelWHX1131:
	local[6]= NIL;
irtmodelBLK1132:
	w = NIL;
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+6;
	w=(pointer)VMAX(ctx,2,local+4); /*vmax*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+6;
	w=(pointer)VMIN(ctx,2,local+4); /*vmin*/
	argv[0]->c.obj.iv[3] = w;
	local[4]= argv[0]->c.obj.iv[2];
	local[5]= fqv[46];
	local[6]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= argv[0]->c.obj.iv[2];
	local[5]= fqv[84];
	local[6]= fqv[85];
	local[7]= loadglobal(fqv[5]);
	local[8]= (pointer)get_sym_func(fqv[48]);
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)MAP(ctx,3,local+7); /*map*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[9])(ctx,1,local+7,&ftab[9],fqv[82]); /*matrix-exponent*/
	local[7]= w;
	local[8]= fqv[105];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(*ftab[11])(ctx,4,local+6,&ftab[11],fqv[86]); /*make-coords*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[2]= w;
	goto irtmodelIF1122;
irtmodelIF1121:
	local[2]= NIL;
irtmodelIF1122:
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
irtmodelBLK1117:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle-rpy*/
static pointer irtmodelM11336dof_joint_joint_angle_rpy(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT1136;}
	local[0]= NIL;
irtmodelENT1136:
irtmodelENT1135:
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[108], &argv[3], n-3, local+1, 0);
	if (n & (1<<0)) goto irtmodelKEY1137;
	local[1] = NIL;
irtmodelKEY1137:
	if (local[0]==NIL) goto irtmodelIF1138;
	if (local[1]==NIL) goto irtmodelIF1140;
	local[2]= loadglobal(fqv[5]);
	local[3]= (pointer)get_sym_func(fqv[48]);
	local[4]= local[0];
	local[5]= makeint((eusinteger_t)3L);
	local[6]= makeint((eusinteger_t)6L);
	ctx->vsp=local+7;
	w=(pointer)SUBSEQ(ctx,3,local+4); /*subseq*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MAP(ctx,3,local+2); /*map*/
	local[2]= w;
	local[3]= loadglobal(fqv[5]);
	local[4]= (pointer)get_sym_func(fqv[48]);
	local[5]= argv[0]->c.obj.iv[3];
	local[6]= makeint((eusinteger_t)3L);
	local[7]= makeint((eusinteger_t)6L);
	ctx->vsp=local+8;
	w=(pointer)SUBSEQ(ctx,3,local+5); /*subseq*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MAP(ctx,3,local+3); /*map*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[9])(ctx,1,local+3,&ftab[9],fqv[82]); /*matrix-exponent*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)INV_RPY(ctx,1,local+3); /*rpy-angle*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= loadglobal(fqv[5]);
	ctx->vsp=local+5;
	w=(pointer)COERCE(ctx,2,local+3); /*coerce*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)VPLUS(ctx,2,local+2); /*v+*/
	local[2]= w;
	goto irtmodelIF1141;
irtmodelIF1140:
	local[2]= loadglobal(fqv[5]);
	local[3]= (pointer)get_sym_func(fqv[48]);
	local[4]= local[0];
	local[5]= makeint((eusinteger_t)3L);
	local[6]= makeint((eusinteger_t)6L);
	ctx->vsp=local+7;
	w=(pointer)SUBSEQ(ctx,3,local+4); /*subseq*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MAP(ctx,3,local+2); /*map*/
	local[2]= w;
irtmodelIF1141:
	local[3]= argv[0];
	local[4]= fqv[20];
	local[5]= loadglobal(fqv[5]);
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)3L);
	ctx->vsp=local+9;
	w=(pointer)SUBSEQ(ctx,3,local+6); /*subseq*/
	local[6]= w;
	local[7]= loadglobal(fqv[88]);
	local[8]= (pointer)get_sym_func(fqv[49]);
	local[9]= local[2];
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	local[10]= local[2];
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	local[11]= local[2];
	local[12]= makeint((eusinteger_t)2L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[12])(ctx,3,local+9,&ftab[12],fqv[89]); /*rpy-matrix*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[10])(ctx,1,local+9,&ftab[10],fqv[83]); /*matrix-log*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MAP(ctx,3,local+7); /*map*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)CONCATENATE(ctx,3,local+5); /*concatenate*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[2]= w;
	goto irtmodelIF1139;
irtmodelIF1138:
	local[2]= NIL;
irtmodelIF1139:
	local[2]= loadglobal(fqv[5]);
	local[3]= argv[0]->c.obj.iv[3];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)3L);
	ctx->vsp=local+6;
	w=(pointer)SUBSEQ(ctx,3,local+3); /*subseq*/
	local[3]= w;
	local[4]= loadglobal(fqv[5]);
	local[5]= (pointer)get_sym_func(fqv[49]);
	local[6]= loadglobal(fqv[5]);
	local[7]= (pointer)get_sym_func(fqv[48]);
	local[8]= argv[0]->c.obj.iv[3];
	local[9]= makeint((eusinteger_t)3L);
	local[10]= makeint((eusinteger_t)6L);
	ctx->vsp=local+11;
	w=(pointer)SUBSEQ(ctx,3,local+8); /*subseq*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MAP(ctx,3,local+6); /*map*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[9])(ctx,1,local+6,&ftab[9],fqv[82]); /*matrix-exponent*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)INV_RPY(ctx,1,local+6); /*rpy-angle*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(pointer)MAP(ctx,3,local+4); /*map*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)CONCATENATE(ctx,3,local+2); /*concatenate*/
	local[0]= w;
irtmodelBLK1134:
	ctx->vsp=local; return(local[0]);}

/*:joint-dof*/
static pointer irtmodelM11426dof_joint_joint_dof(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = makeint((eusinteger_t)6L);
	local[0]= w;
irtmodelBLK1143:
	ctx->vsp=local; return(local[0]);}

/*:calc-angle-speed-gain*/
static pointer irtmodelM11446dof_joint_calc_angle_speed_gain(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0];
	local[1]= argv[2];
	local[2]= argv[3];
	local[3]= argv[4];
	ctx->vsp=local+4;
	w=(pointer)irtmodelF733calc_angle_speed_gain_vector(ctx,4,local+0); /*calc-angle-speed-gain-vector*/
	local[0]= w;
irtmodelBLK1145:
	ctx->vsp=local; return(local[0]);}

/*:speed-to-angle*/
static pointer irtmodelM11466dof_joint_speed_to_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeint((eusinteger_t)1000L);
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1000L);
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	local[2]= makeint((eusinteger_t)1000L);
	local[3]= argv[2];
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	local[3]= argv[2];
	local[4]= makeint((eusinteger_t)3L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[7])(ctx,1,local+3,&ftab[7],fqv[49]); /*rad2deg*/
	local[3]= w;
	local[4]= argv[2];
	local[5]= makeint((eusinteger_t)4L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[7])(ctx,1,local+4,&ftab[7],fqv[49]); /*rad2deg*/
	local[4]= w;
	local[5]= argv[2];
	local[6]= makeint((eusinteger_t)5L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[7])(ctx,1,local+5,&ftab[7],fqv[49]); /*rad2deg*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,6,local+0); /*float-vector*/
	local[0]= w;
irtmodelBLK1147:
	ctx->vsp=local; return(local[0]);}

/*:angle-to-speed*/
static pointer irtmodelM11486dof_joint_angle_to_speed(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeflt(1.0000000000000000208167e-03);
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= makeflt(1.0000000000000000208167e-03);
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	local[2]= makeflt(1.0000000000000000208167e-03);
	local[3]= argv[2];
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	local[3]= argv[2];
	local[4]= makeint((eusinteger_t)3L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[6])(ctx,1,local+3,&ftab[6],fqv[48]); /*deg2rad*/
	local[3]= w;
	local[4]= argv[2];
	local[5]= makeint((eusinteger_t)4L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[6])(ctx,1,local+4,&ftab[6],fqv[48]); /*deg2rad*/
	local[4]= w;
	local[5]= argv[2];
	local[6]= makeint((eusinteger_t)5L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[6])(ctx,1,local+5,&ftab[6],fqv[48]); /*deg2rad*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,6,local+0); /*float-vector*/
	local[0]= w;
irtmodelBLK1149:
	ctx->vsp=local; return(local[0]);}

/*:calc-jacobian*/
static pointer irtmodelM11506dof_joint_calc_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=21) maerror();
	w = argv[5];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[28],w);
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= loadglobal(fqv[28]);
	local[7]= fqv[109];
	local[8]= argv[7];
	local[9]= argv[8];
	local[10]= argv[9];
	local[11]= argv[10];
	local[12]= argv[11];
	local[13]= argv[12];
	local[14]= argv[13];
	local[15]= argv[14];
	local[16]= argv[15];
	local[17]= argv[16];
	local[18]= argv[17];
	local[19]= argv[18];
	local[20]= argv[19];
	local[21]= argv[20];
	ctx->vsp=local+22;
	w=(pointer)irtmodelF731calc_jacobian_linear(ctx,19,local+3); /*calc-jacobian-linear*/
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	local[6]= loadglobal(fqv[28]);
	local[7]= fqv[110];
	local[8]= argv[7];
	local[9]= argv[8];
	local[10]= argv[9];
	local[11]= argv[10];
	local[12]= argv[11];
	local[13]= argv[12];
	local[14]= argv[13];
	local[15]= argv[14];
	local[16]= argv[15];
	local[17]= argv[16];
	local[18]= argv[17];
	local[19]= argv[18];
	local[20]= argv[19];
	local[21]= argv[20];
	ctx->vsp=local+22;
	w=(pointer)irtmodelF731calc_jacobian_linear(ctx,19,local+3); /*calc-jacobian-linear*/
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	local[6]= loadglobal(fqv[28]);
	local[7]= fqv[111];
	local[8]= argv[7];
	local[9]= argv[8];
	local[10]= argv[9];
	local[11]= argv[10];
	local[12]= argv[11];
	local[13]= argv[12];
	local[14]= argv[13];
	local[15]= argv[14];
	local[16]= argv[15];
	local[17]= argv[16];
	local[18]= argv[17];
	local[19]= argv[18];
	local[20]= argv[19];
	local[21]= argv[20];
	ctx->vsp=local+22;
	w=(pointer)irtmodelF731calc_jacobian_linear(ctx,19,local+3); /*calc-jacobian-linear*/
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= makeint((eusinteger_t)3L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	local[6]= loadglobal(fqv[28]);
	local[7]= fqv[112];
	local[8]= argv[7];
	local[9]= argv[8];
	local[10]= argv[9];
	local[11]= argv[10];
	local[12]= argv[11];
	local[13]= argv[12];
	local[14]= argv[13];
	local[15]= argv[14];
	local[16]= argv[15];
	local[17]= argv[16];
	local[18]= argv[17];
	local[19]= argv[18];
	local[20]= argv[19];
	local[21]= argv[20];
	ctx->vsp=local+22;
	w=(pointer)irtmodelF730calc_jacobian_rotational(ctx,19,local+3); /*calc-jacobian-rotational*/
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= makeint((eusinteger_t)4L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	local[6]= loadglobal(fqv[28]);
	local[7]= fqv[113];
	local[8]= argv[7];
	local[9]= argv[8];
	local[10]= argv[9];
	local[11]= argv[10];
	local[12]= argv[11];
	local[13]= argv[12];
	local[14]= argv[13];
	local[15]= argv[14];
	local[16]= argv[15];
	local[17]= argv[16];
	local[18]= argv[17];
	local[19]= argv[18];
	local[20]= argv[19];
	local[21]= argv[20];
	ctx->vsp=local+22;
	w=(pointer)irtmodelF730calc_jacobian_rotational(ctx,19,local+3); /*calc-jacobian-rotational*/
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= makeint((eusinteger_t)5L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	local[6]= loadglobal(fqv[28]);
	local[7]= fqv[114];
	local[8]= argv[7];
	local[9]= argv[8];
	local[10]= argv[9];
	local[11]= argv[10];
	local[12]= argv[11];
	local[13]= argv[12];
	local[14]= argv[13];
	local[15]= argv[14];
	local[16]= argv[15];
	local[17]= argv[16];
	local[18]= argv[17];
	local[19]= argv[18];
	local[20]= argv[19];
	local[21]= argv[20];
	ctx->vsp=local+22;
	w=(pointer)irtmodelF730calc_jacobian_rotational(ctx,19,local+3); /*calc-jacobian-rotational*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtmodelBLK1151:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtmodelM1152bodyset_link_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtmodelRST1154:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[115], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1155;
	local[1] = fqv[116];
irtmodelKEY1155:
	if (n & (1<<1)) goto irtmodelKEY1156;
	local[2] = makeint((eusinteger_t)1L);
irtmodelKEY1156:
	if (n & (1<<2)) goto irtmodelKEY1157;
	local[3] = fqv[117];
irtmodelKEY1157:
	if (n & (1<<3)) goto irtmodelKEY1158;
	local[5]= makeint((eusinteger_t)3L);
	ctx->vsp=local+6;
	w=(*ftab[15])(ctx,1,local+5,&ftab[15],fqv[118]); /*unit-matrix*/
	local[4] = w;
irtmodelKEY1158:
	argv[0]->c.obj.iv[12] = local[1];
	argv[0]->c.obj.iv[14] = local[2];
	argv[0]->c.obj.iv[16] = local[4];
	argv[0]->c.obj.iv[15] = local[3];
	local[5]= argv[0];
	local[6]= fqv[119];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= (pointer)get_sym_func(fqv[34]);
	local[6]= argv[0];
	local[7]= *(ovafptr(argv[1],fqv[35]));
	local[8]= fqv[36];
	local[9]= argv[2];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)APPLY(ctx,6,local+5); /*apply*/
	local[0]= w;
irtmodelBLK1153:
	ctx->vsp=local; return(local[0]);}

/*:worldcoords*/
static pointer irtmodelM1159bodyset_link_worldcoords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT1162;}
	local[0]= argv[0]->c.obj.iv[12];
irtmodelENT1162:
irtmodelENT1161:
	if (n>3) maerror();
	local[1]= local[0];
	local[2]= local[1];
	if (fqv[120]!=local[2]) goto irtmodelIF1163;
	local[2]= argv[0];
	local[3]= loadglobal(fqv[121]);
	local[4]= fqv[122];
	ctx->vsp=local+5;
	w=(pointer)SENDMESSAGE(ctx,3,local+2); /*send-message*/
	local[2]= w;
	goto irtmodelIF1164;
irtmodelIF1163:
	if (T==NIL) goto irtmodelIF1165;
	local[2]= argv[0];
	local[3]= *(ovafptr(argv[1],fqv[35]));
	local[4]= fqv[122];
	ctx->vsp=local+5;
	w=(pointer)SENDMESSAGE(ctx,3,local+2); /*send-message*/
	local[2]= w;
	goto irtmodelIF1166;
irtmodelIF1165:
	local[2]= NIL;
irtmodelIF1166:
irtmodelIF1164:
	w = local[2];
	local[0]= w;
irtmodelBLK1160:
	ctx->vsp=local; return(local[0]);}

/*:analysis-level*/
static pointer irtmodelM1167bodyset_link_analysis_level(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT1170;}
	local[0]= NIL;
irtmodelENT1170:
irtmodelENT1169:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF1171;
	argv[0]->c.obj.iv[12] = local[0];
	local[1]= argv[0]->c.obj.iv[12];
	goto irtmodelIF1172;
irtmodelIF1171:
	local[1]= NIL;
irtmodelIF1172:
	w = argv[0]->c.obj.iv[12];
	local[0]= w;
irtmodelBLK1168:
	ctx->vsp=local; return(local[0]);}

/*:weight*/
static pointer irtmodelM1173bodyset_link_weight(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT1176;}
	local[0]= NIL;
irtmodelENT1176:
irtmodelENT1175:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF1177;
	argv[0]->c.obj.iv[14] = local[0];
	local[1]= argv[0]->c.obj.iv[14];
	goto irtmodelIF1178;
irtmodelIF1177:
	local[1]= NIL;
irtmodelIF1178:
	w = argv[0]->c.obj.iv[14];
	local[0]= w;
irtmodelBLK1174:
	ctx->vsp=local; return(local[0]);}

/*:centroid*/
static pointer irtmodelM1179bodyset_link_centroid(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT1182;}
	local[0]= NIL;
irtmodelENT1182:
irtmodelENT1181:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF1183;
	argv[0]->c.obj.iv[15] = local[0];
	local[1]= argv[0]->c.obj.iv[15];
	goto irtmodelIF1184;
irtmodelIF1183:
	local[1]= NIL;
irtmodelIF1184:
	local[1]= argv[0];
	local[2]= fqv[122];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[123];
	local[3]= argv[0]->c.obj.iv[15];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
irtmodelBLK1180:
	ctx->vsp=local; return(local[0]);}

/*:inertia-tensor*/
static pointer irtmodelM1185bodyset_link_inertia_tensor(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT1188;}
	local[0]= NIL;
irtmodelENT1188:
irtmodelENT1187:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF1189;
	argv[0]->c.obj.iv[16] = local[0];
	local[1]= argv[0]->c.obj.iv[16];
	goto irtmodelIF1190;
irtmodelIF1189:
	local[1]= NIL;
irtmodelIF1190:
	w = argv[0]->c.obj.iv[16];
	local[0]= w;
irtmodelBLK1186:
	ctx->vsp=local; return(local[0]);}

/*:joint*/
static pointer irtmodelM1191bodyset_link_joint(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST1193:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[9];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,2,local+1,&ftab[1],fqv[13]); /*forward-message-to*/
	local[0]= w;
irtmodelBLK1192:
	ctx->vsp=local; return(local[0]);}

/*:add-joint*/
static pointer irtmodelM1194bodyset_link_add_joint(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	argv[0]->c.obj.iv[9] = argv[2];
	w = argv[0]->c.obj.iv[9];
	local[0]= w;
irtmodelBLK1195:
	ctx->vsp=local; return(local[0]);}

/*:del-joint*/
static pointer irtmodelM1196bodyset_link_del_joint(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	argv[0]->c.obj.iv[9] = NIL;
	w = argv[0]->c.obj.iv[9];
	local[0]= w;
irtmodelBLK1197:
	ctx->vsp=local; return(local[0]);}

/*:parent-link*/
static pointer irtmodelM1198bodyset_link_parent_link(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[10];
	local[0]= w;
irtmodelBLK1199:
	ctx->vsp=local; return(local[0]);}

/*:child-links*/
static pointer irtmodelM1200bodyset_link_child_links(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[11];
	local[0]= w;
irtmodelBLK1201:
	ctx->vsp=local; return(local[0]);}

/*:add-child-links*/
static pointer irtmodelM1202bodyset_link_add_child_links(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[11];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[124]); /*member*/
	if (w!=NIL) goto irtmodelIF1204;
	if (argv[2]==NIL) goto irtmodelIF1204;
	local[0]= argv[2];
	w = argv[0]->c.obj.iv[11];
	ctx->vsp=local+1;
	argv[0]->c.obj.iv[11] = cons(ctx,local[0],w);
	local[0]= argv[0]->c.obj.iv[11];
	goto irtmodelIF1205;
irtmodelIF1204:
	local[0]= NIL;
irtmodelIF1205:
	w = local[0];
	local[0]= w;
irtmodelBLK1203:
	ctx->vsp=local; return(local[0]);}

/*:add-parent-link*/
static pointer irtmodelM1206bodyset_link_add_parent_link(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	argv[0]->c.obj.iv[10] = argv[2];
	w = argv[0]->c.obj.iv[10];
	local[0]= w;
irtmodelBLK1207:
	ctx->vsp=local; return(local[0]);}

/*:del-child-link*/
static pointer irtmodelM1208bodyset_link_del_child_link(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[11];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[125]); /*delete*/
	argv[0]->c.obj.iv[11] = w;
	w = argv[0]->c.obj.iv[11];
	local[0]= w;
irtmodelBLK1209:
	ctx->vsp=local; return(local[0]);}

/*:del-parent-link*/
static pointer irtmodelM1210bodyset_link_del_parent_link(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	argv[0]->c.obj.iv[10] = NIL;
	w = argv[0]->c.obj.iv[10];
	local[0]= w;
irtmodelBLK1211:
	ctx->vsp=local; return(local[0]);}

/*:default-coords*/
static pointer irtmodelM1212bodyset_link_default_coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT1215;}
	local[0]= NIL;
irtmodelENT1215:
irtmodelENT1214:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF1216;
	argv[0]->c.obj.iv[13] = local[0];
	local[1]= argv[0]->c.obj.iv[13];
	goto irtmodelIF1217;
irtmodelIF1216:
	local[1]= NIL;
irtmodelIF1217:
	w = argv[0]->c.obj.iv[13];
	local[0]= w;
irtmodelBLK1213:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtmodelM1218cascaded_link_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST1220:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[126], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1221;
	local[1] = NIL;
irtmodelKEY1221:
	local[2]= (pointer)get_sym_func(fqv[34]);
	local[3]= argv[0];
	local[4]= *(ovafptr(argv[1],fqv[35]));
	local[5]= fqv[36];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)APPLY(ctx,5,local+2); /*apply*/
	w = argv[0];
	local[0]= w;
irtmodelBLK1219:
	ctx->vsp=local; return(local[0]);}

/*:init-ending*/
static pointer irtmodelM1222cascaded_link_init_ending(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[8];
	local[1]= fqv[127];
	ctx->vsp=local+2;
	w=(*ftab[18])(ctx,2,local+0,&ftab[18],fqv[128]); /*send-all*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[19])(ctx,1,local+0,&ftab[19],fqv[129]); /*flatten*/
	argv[0]->c.obj.iv[10] = w;
	local[0]= NIL;
	local[1]= argv[0]->c.obj.iv[9];
irtmodelWHL1224:
	if (local[1]==NIL) goto irtmodelWHX1225;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= local[0];
	local[3]= fqv[130];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= fqv[131];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= local[0];
	local[3]= fqv[130];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= fqv[132];
	local[4]= local[0];
	local[5]= fqv[133];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= local[0];
	local[3]= fqv[133];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= fqv[134];
	local[4]= local[0];
	local[5]= fqv[130];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	goto irtmodelWHL1224;
irtmodelWHX1225:
	local[2]= NIL;
irtmodelBLK1226:
	w = NIL;
	local[0]= argv[0];
	local[1]= fqv[135];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= NIL;
	local[1]= argv[0];
	local[2]= fqv[136];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
irtmodelWHL1227:
	if (local[1]==NIL) goto irtmodelWHX1228;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= local[0];
	local[3]= fqv[137];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	goto irtmodelWHL1227;
irtmodelWHX1228:
	local[2]= NIL;
irtmodelBLK1229:
	w = NIL;
	local[0]= w;
irtmodelBLK1223:
	ctx->vsp=local; return(local[0]);}

/*:links*/
static pointer irtmodelM1230cascaded_link_links(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST1232:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[8];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[20])(ctx,2,local+1,&ftab[20],fqv[138]); /*forward-message-to-all*/
	local[0]= w;
irtmodelBLK1231:
	ctx->vsp=local; return(local[0]);}

/*:joint-list*/
static pointer irtmodelM1233cascaded_link_joint_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST1235:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[9];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[20])(ctx,2,local+1,&ftab[20],fqv[138]); /*forward-message-to-all*/
	local[0]= w;
irtmodelBLK1234:
	ctx->vsp=local; return(local[0]);}

/*:link*/
static pointer irtmodelM1236cascaded_link_link(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[8];
	local[2]= fqv[139];
	local[3]= (pointer)get_sym_func(fqv[140]);
	local[4]= fqv[141];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtmodelCLO1238,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[21])(ctx,6,local+0,&ftab[21],fqv[142]); /*find*/
	local[0]= w;
irtmodelBLK1237:
	ctx->vsp=local; return(local[0]);}

/*:joint*/
static pointer irtmodelM1239cascaded_link_joint(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[9];
	local[2]= fqv[139];
	local[3]= (pointer)get_sym_func(fqv[140]);
	local[4]= fqv[141];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtmodelCLO1241,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[21])(ctx,6,local+0,&ftab[21],fqv[142]); /*find*/
	local[0]= w;
irtmodelBLK1240:
	ctx->vsp=local; return(local[0]);}

/*:end-coords*/
static pointer irtmodelM1242cascaded_link_end_coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[12];
	local[2]= fqv[139];
	local[3]= (pointer)get_sym_func(fqv[140]);
	local[4]= fqv[141];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtmodelCLO1244,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[21])(ctx,6,local+0,&ftab[21],fqv[142]); /*find*/
	local[0]= w;
irtmodelBLK1243:
	ctx->vsp=local; return(local[0]);}

/*:bodies*/
static pointer irtmodelM1245cascaded_link_bodies(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST1247:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[10];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[20])(ctx,2,local+1,&ftab[20],fqv[138]); /*forward-message-to-all*/
	local[0]= w;
irtmodelBLK1246:
	ctx->vsp=local; return(local[0]);}

/*:faces*/
static pointer irtmodelM1248cascaded_link_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[10];
	local[1]= fqv[143];
	ctx->vsp=local+2;
	w=(*ftab[18])(ctx,2,local+0,&ftab[18],fqv[128]); /*send-all*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[19])(ctx,1,local+0,&ftab[19],fqv[129]); /*flatten*/
	local[0]= w;
irtmodelBLK1249:
	ctx->vsp=local; return(local[0]);}

/*:update-descendants*/
static pointer irtmodelM1250cascaded_link_update_descendants(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST1252:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[8];
	local[2]= fqv[122];
	ctx->vsp=local+3;
	w=(*ftab[18])(ctx,2,local+1,&ftab[18],fqv[128]); /*send-all*/
	local[0]= w;
irtmodelBLK1251:
	ctx->vsp=local; return(local[0]);}

/*:angle-vector*/
static pointer irtmodelM1253cascaded_link_angle_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT1257;}
	local[0]= NIL;
irtmodelENT1257:
	if (n>=4) { local[1]=(argv[3]); goto irtmodelENT1256;}
	local[1]= loadglobal(fqv[5]);
	local[2]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+3;
	w=(pointer)irtmodelF736calc_target_joint_dimension(ctx,1,local+2); /*calc-target-joint-dimension*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,2,local+1); /*instantiate*/
	local[1]= w;
irtmodelENT1256:
irtmodelENT1255:
	if (n>4) maerror();
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	local[4]= argv[0]->c.obj.iv[9];
irtmodelWHL1258:
	if (local[4]==NIL) goto irtmodelWHX1259;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	if (local[0]==NIL) goto irtmodelIF1261;
	local[5]= local[3];
	local[6]= fqv[10];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	if (w==NIL) goto irtmodelIF1263;
	local[5]= local[3];
	local[6]= fqv[11];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	if (w==NIL) goto irtmodelIF1263;
	local[5]= local[3];
	local[6]= fqv[31];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)NUMEQUAL(ctx,2,local+5); /*=*/
	if (w==NIL) goto irtmodelIF1265;
	local[5]= local[3];
	local[6]= fqv[11];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= fqv[31];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)NUMEQUAL(ctx,2,local+5); /*=*/
	if (w==NIL) goto irtmodelIF1265;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0]->c.obj.iv[9];
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= NIL;
	local[9]= NIL;
	local[10]= NIL;
	local[11]= NIL;
	local[12]= NIL;
	local[13]= NIL;
irtmodelWHL1267:
	local[14]= local[6];
	local[15]= local[3];
	local[16]= fqv[11];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	if (w==local[14]) goto irtmodelWHX1268;
	local[14]= local[5];
	ctx->vsp=local+15;
	w=(pointer)ADD1(ctx,1,local+14); /*1+*/
	local[5] = w;
	local[14]= local[7];
	local[15]= local[6];
	local[16]= fqv[31];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)PLUS(ctx,2,local+14); /*+*/
	local[7] = w;
	local[14]= argv[0]->c.obj.iv[9];
	local[15]= local[5];
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[6] = w;
	goto irtmodelWHL1267;
irtmodelWHX1268:
	local[14]= NIL;
irtmodelBLK1269:
	local[14]= local[0];
	local[15]= local[2];
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[8] = w;
	local[14]= local[0];
	local[15]= local[7];
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[11] = w;
	local[14]= local[3];
	local[15]= fqv[41];
	local[16]= local[11];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[9] = w;
	local[14]= local[3];
	local[15]= fqv[42];
	local[16]= local[11];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[10] = w;
	local[14]= local[6];
	local[15]= fqv[41];
	local[16]= local[8];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[12] = w;
	local[14]= local[6];
	local[15]= fqv[42];
	local[16]= local[8];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[13] = w;
	local[14]= local[9];
	local[15]= local[8];
	local[16]= local[10];
	ctx->vsp=local+17;
	w=(pointer)LSEQP(ctx,3,local+14); /*<=*/
	if (w==NIL) goto irtmodelCON1271;
	local[14]= local[8];
	*(ovafptr(local[3],fqv[144])) = local[14];
	local[14]= local[11];
	local[15]= local[14];
	*(ovafptr(local[6],fqv[144])) = local[15];
	goto irtmodelCON1270;
irtmodelCON1271:
	local[14]= makeint((eusinteger_t)0L);
irtmodelTAG1274:
	local[15]= local[14];
	local[16]= makeint((eusinteger_t)1L);
	ctx->vsp=local+17;
	w=(pointer)GREATERP(ctx,2,local+15); /*>*/
	if (w==NIL) goto irtmodelIF1275;
	w = NIL;
	ctx->vsp=local+15;
	local[14]=w;
	goto irtmodelBLK1273;
	goto irtmodelIF1276;
irtmodelIF1275:
	local[15]= NIL;
irtmodelIF1276:
	local[15]= local[3];
	local[16]= fqv[41];
	local[17]= local[11];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[9] = w;
	local[15]= local[3];
	local[16]= fqv[42];
	local[17]= local[11];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[10] = w;
	local[15]= local[6];
	local[16]= fqv[41];
	local[17]= local[8];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[12] = w;
	local[15]= local[6];
	local[16]= fqv[42];
	local[17]= local[8];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[13] = w;
	local[15]= local[8];
	local[16]= local[9];
	ctx->vsp=local+17;
	w=(pointer)LESSP(ctx,2,local+15); /*<*/
	if (w==NIL) goto irtmodelIF1277;
	local[15]= local[8];
	local[16]= local[9];
	local[17]= local[8];
	ctx->vsp=local+18;
	w=(pointer)MINUS(ctx,2,local+16); /*-*/
	local[16]= w;
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)TIMES(ctx,2,local+16); /***/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)PLUS(ctx,2,local+15); /*+*/
	local[8] = w;
	local[15]= local[8];
	goto irtmodelIF1278;
irtmodelIF1277:
	local[15]= NIL;
irtmodelIF1278:
	local[15]= local[8];
	local[16]= local[10];
	ctx->vsp=local+17;
	w=(pointer)GREATERP(ctx,2,local+15); /*>*/
	if (w==NIL) goto irtmodelIF1279;
	local[15]= local[8];
	local[16]= local[10];
	local[17]= local[8];
	ctx->vsp=local+18;
	w=(pointer)MINUS(ctx,2,local+16); /*-*/
	local[16]= w;
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)TIMES(ctx,2,local+16); /***/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)PLUS(ctx,2,local+15); /*+*/
	local[8] = w;
	local[15]= local[8];
	goto irtmodelIF1280;
irtmodelIF1279:
	local[15]= NIL;
irtmodelIF1280:
	local[15]= local[11];
	local[16]= local[12];
	ctx->vsp=local+17;
	w=(pointer)LESSP(ctx,2,local+15); /*<*/
	if (w==NIL) goto irtmodelIF1281;
	local[15]= local[11];
	local[16]= local[12];
	local[17]= local[11];
	ctx->vsp=local+18;
	w=(pointer)MINUS(ctx,2,local+16); /*-*/
	local[16]= w;
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)TIMES(ctx,2,local+16); /***/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)PLUS(ctx,2,local+15); /*+*/
	local[11] = w;
	local[15]= local[11];
	goto irtmodelIF1282;
irtmodelIF1281:
	local[15]= NIL;
irtmodelIF1282:
	local[15]= local[11];
	local[16]= local[13];
	ctx->vsp=local+17;
	w=(pointer)GREATERP(ctx,2,local+15); /*>*/
	if (w==NIL) goto irtmodelIF1283;
	local[15]= local[11];
	local[16]= local[13];
	local[17]= local[11];
	ctx->vsp=local+18;
	w=(pointer)MINUS(ctx,2,local+16); /*-*/
	local[16]= w;
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)TIMES(ctx,2,local+16); /***/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)PLUS(ctx,2,local+15); /*+*/
	local[11] = w;
	local[15]= local[11];
	goto irtmodelIF1284;
irtmodelIF1283:
	local[15]= NIL;
irtmodelIF1284:
	local[15]= local[14];
	local[16]= makeflt(9.9999999999999977795540e-02);
	ctx->vsp=local+17;
	w=(pointer)PLUS(ctx,2,local+15); /*+*/
	local[14] = w;
	local[15]= local[14];
	local[14] = local[15];
	w = NIL;
	ctx->vsp=local+15;
	goto irtmodelTAG1274;
	w = NIL;
	local[14]= w;
irtmodelBLK1273:
	local[14]= local[8];
	*(ovafptr(local[3],fqv[144])) = local[14];
	local[14]= local[11];
	local[15]= local[14];
	*(ovafptr(local[6],fqv[144])) = local[15];
	local[14]= local[0];
	local[15]= local[2];
	local[16]= local[8];
	ctx->vsp=local+17;
	w=(pointer)SETELT(ctx,3,local+14); /*setelt*/
	local[14]= local[0];
	local[15]= local[7];
	local[16]= local[11];
	ctx->vsp=local+17;
	w=(pointer)SETELT(ctx,3,local+14); /*setelt*/
	local[14]= w;
	goto irtmodelCON1270;
irtmodelCON1272:
	local[14]= NIL;
irtmodelCON1270:
	w = local[14];
	local[5]= w;
	goto irtmodelIF1266;
irtmodelIF1265:
	local[5]= NIL;
irtmodelIF1266:
	goto irtmodelIF1264;
irtmodelIF1263:
	local[5]= NIL;
irtmodelIF1264:
	local[5]= local[3];
	local[6]= fqv[31];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= local[5];
	if (fqv[145]!=local[6]) goto irtmodelIF1285;
	local[6]= local[3];
	local[7]= fqv[20];
	local[8]= local[0];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	goto irtmodelIF1286;
irtmodelIF1285:
	if (T==NIL) goto irtmodelIF1287;
	local[6]= local[3];
	local[7]= fqv[20];
	local[8]= local[0];
	local[9]= local[2];
	local[10]= local[2];
	local[11]= local[3];
	local[12]= fqv[31];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SUBSEQ(ctx,3,local+8); /*subseq*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	goto irtmodelIF1288;
irtmodelIF1287:
	local[6]= NIL;
irtmodelIF1288:
irtmodelIF1286:
	w = local[6];
	local[5]= w;
	goto irtmodelIF1262;
irtmodelIF1261:
	local[5]= NIL;
irtmodelIF1262:
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[3];
	local[7]= fqv[31];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
irtmodelWHL1289:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto irtmodelWHX1290;
	local[7]= local[1];
	local[8]= local[2];
	local[9]= local[3];
	local[10]= fqv[31];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	local[10]= local[9];
	if (fqv[146]!=local[10]) goto irtmodelIF1292;
	local[10]= local[3];
	local[11]= fqv[20];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	goto irtmodelIF1293;
irtmodelIF1292:
	if (T==NIL) goto irtmodelIF1294;
	local[10]= local[3];
	local[11]= fqv[20];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	goto irtmodelIF1295;
irtmodelIF1294:
	local[10]= NIL;
irtmodelIF1295:
irtmodelIF1293:
	w = local[10];
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SETELT(ctx,3,local+7); /*setelt*/
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[2] = w;
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto irtmodelWHL1289;
irtmodelWHX1290:
	local[7]= NIL;
irtmodelBLK1291:
	w = NIL;
	goto irtmodelWHL1258;
irtmodelWHX1259:
	local[5]= NIL;
irtmodelBLK1260:
	w = NIL;
	w = local[1];
	local[0]= w;
irtmodelBLK1254:
	ctx->vsp=local; return(local[0]);}

/*:find-link-route*/
static pointer irtmodelM1296cascaded_link_find_link_route(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtmodelENT1299;}
	local[0]= NIL;
irtmodelENT1299:
irtmodelENT1298:
	if (n>4) maerror();
	local[1]= argv[2];
	local[2]= fqv[133];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	if (local[1]==NIL) goto irtmodelCON1301;
	local[2]= argv[2];
	local[3]= argv[0];
	local[4]= fqv[136];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[21])(ctx,2,local+2,&ftab[21],fqv[142]); /*find*/
	if (w!=NIL) goto irtmodelCON1301;
	local[2]= argv[0];
	local[3]= fqv[147];
	local[4]= local[1];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	goto irtmodelCON1300;
irtmodelCON1301:
	if (local[1]==NIL) goto irtmodelCON1302;
	local[2]= argv[2];
	if (local[0]==local[2]) goto irtmodelCON1302;
	local[2]= argv[0];
	local[3]= fqv[147];
	local[4]= local[1];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)APPEND(ctx,2,local+2); /*append*/
	local[2]= w;
	goto irtmodelCON1300;
irtmodelCON1302:
	if (local[1]==NIL) goto irtmodelCON1303;
	local[2]= argv[2];
	if (local[0]!=local[2]) goto irtmodelCON1303;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	local[2]= w;
	goto irtmodelCON1300;
irtmodelCON1303:
	local[2]= NIL;
irtmodelCON1300:
	w = local[2];
	local[0]= w;
irtmodelBLK1297:
	ctx->vsp=local; return(local[0]);}

/*:link-list*/
static pointer irtmodelM1304cascaded_link_link_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtmodelENT1307;}
	local[0]= NIL;
irtmodelENT1307:
irtmodelENT1306:
	if (n>4) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[0];
	local[4]= fqv[147];
	local[5]= argv[2];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[1] = w;
	if (local[0]==NIL) goto irtmodelIF1308;
	local[3]= local[0];
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car==local[3]) goto irtmodelIF1308;
	local[3]= argv[0];
	local[4]= fqv[147];
	local[5]= local[0];
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[2] = w;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)NREVERSE(ctx,1,local+3); /*nreverse*/
	local[3]= w;
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)NCONC(ctx,2,local+3); /*nconc*/
	local[1] = w;
	local[3]= local[1];
	goto irtmodelIF1309;
irtmodelIF1308:
	local[3]= NIL;
irtmodelIF1309:
	w = local[1];
	local[0]= w;
irtmodelBLK1305:
	ctx->vsp=local; return(local[0]);}

/*:make-joint-min-max-table*/
static pointer irtmodelM1310cascaded_link_make_joint_min_max_table(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<6) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[148], &argv[6], n-6, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY1312;
	local[0] = makeint((eusinteger_t)0L);
irtmodelKEY1312:
	if (n & (1<<1)) goto irtmodelKEY1313;
	local[1] = NIL;
irtmodelKEY1313:
	if (n & (1<<2)) goto irtmodelKEY1314;
	local[2] = NIL;
irtmodelKEY1314:
	if (n & (1<<3)) goto irtmodelKEY1315;
	local[3] = makeflt(0.0000000000000000000000e+00);
irtmodelKEY1315:
	if (n & (1<<4)) goto irtmodelKEY1316;
	local[4] = NIL;
irtmodelKEY1316:
	if (local[2]!=NIL) goto irtmodelIF1317;
	local[5]= argv[0];
	local[6]= fqv[136];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= fqv[149];
	local[7]= fqv[120];
	ctx->vsp=local+8;
	w=(*ftab[18])(ctx,3,local+5,&ftab[18],fqv[128]); /*send-all*/
	local[5]= w;
	goto irtmodelIF1318;
irtmodelIF1317:
	local[5]= NIL;
irtmodelIF1318:
	local[5]= NIL;
	local[6]= argv[4];
	local[7]= argv[5];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,2,local+6); /*list*/
	local[6]= w;
irtmodelWHL1319:
	if (local[6]==NIL) goto irtmodelWHX1320;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= local[5];
	local[8]= fqv[150];
	local[9]= fqv[151];
	local[10]= local[5];
	local[11]= fqv[22];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[7]= local[5];
	local[8]= fqv[150];
	local[9]= fqv[152];
	local[10]= local[5];
	local[11]= fqv[23];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	goto irtmodelWHL1319;
irtmodelWHX1320:
	local[7]= NIL;
irtmodelBLK1321:
	w = NIL;
	local[5]= argv[0];
	local[6]= fqv[153];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= argv[0];
	local[7]= fqv[154];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= argv[4];
	local[8]= fqv[22];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= makeflt(9.9999999999999991239646e-05);
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,2,local+7); /*-*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)TRUNCATE(ctx,1,local+7); /*truncate*/
	local[7]= w;
	local[8]= argv[4];
	local[9]= fqv[23];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= makeflt(9.9999999999999991239646e-05);
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)TRUNCATE(ctx,1,local+8); /*truncate*/
	local[8]= w;
	local[9]= argv[5];
	local[10]= fqv[22];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	local[10]= makeflt(9.9999999999999991239646e-05);
	ctx->vsp=local+11;
	w=(pointer)MINUS(ctx,2,local+9); /*-*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)TRUNCATE(ctx,1,local+9); /*truncate*/
	local[9]= w;
	local[10]= argv[5];
	local[11]= fqv[23];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	local[11]= makeflt(9.9999999999999991239646e-05);
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)TRUNCATE(ctx,1,local+10); /*truncate*/
	local[10]= w;
	local[11]= local[8];
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(pointer)MINUS(ctx,2,local+11); /*-*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)ROUND(ctx,1,local+11); /*round*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[11]= w;
	local[12]= local[10];
	local[13]= local[9];
	ctx->vsp=local+14;
	w=(pointer)MINUS(ctx,2,local+12); /*-*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)ROUND(ctx,1,local+12); /*round*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)ADD1(ctx,1,local+12); /*1+*/
	local[12]= w;
	if (local[2]==NIL) goto irtmodelIF1322;
	local[13]= T;
	local[14]= fqv[155];
	local[15]= argv[4];
	local[16]= fqv[3];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	local[16]= argv[4];
	local[17]= fqv[22];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[16]= w;
	local[17]= argv[4];
	local[18]= fqv[23];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,2,local+17); /*send*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)XFORMAT(ctx,5,local+13); /*format*/
	local[13]= T;
	local[14]= fqv[156];
	local[15]= argv[5];
	local[16]= fqv[3];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	local[16]= argv[5];
	local[17]= fqv[22];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[16]= w;
	local[17]= argv[5];
	local[18]= fqv[23];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,2,local+17); /*send*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)XFORMAT(ctx,5,local+13); /*format*/
	local[13]= T;
	local[14]= fqv[157];
	local[15]= argv[4];
	local[16]= fqv[3];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	local[16]= local[7];
	local[17]= local[8];
	ctx->vsp=local+18;
	w=(pointer)XFORMAT(ctx,5,local+13); /*format*/
	local[13]= T;
	local[14]= fqv[158];
	local[15]= argv[5];
	local[16]= fqv[3];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	local[16]= local[9];
	local[17]= local[10];
	ctx->vsp=local+18;
	w=(pointer)XFORMAT(ctx,5,local+13); /*format*/
	local[13]= w;
	goto irtmodelIF1323;
irtmodelIF1322:
	local[13]= NIL;
irtmodelIF1323:
	local[13]= argv[0];
	local[14]= fqv[159];
	ctx->vsp=local+15;
	w=(*ftab[11])(ctx,0,local+15,&ftab[11],fqv[86]); /*make-coords*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= argv[0];
	local[14]= fqv[160];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	if (local[4]==NIL) goto irtmodelIF1324;
	local[13]= argv[2];
	local[14]= NIL;
	local[15]= fqv[161];
	ctx->vsp=local+16;
	w=(pointer)PUTPROP(ctx,3,local+13); /*putprop*/
	local[13]= argv[3];
	local[14]= NIL;
	local[15]= fqv[161];
	ctx->vsp=local+16;
	w=(pointer)PUTPROP(ctx,3,local+13); /*putprop*/
	local[13]= argv[2];
	local[14]= argv[3];
	local[15]= makeint((eusinteger_t)2L);
	local[16]= fqv[162];
	local[17]= local[0];
	local[18]= fqv[163];
	local[19]= local[1];
	ctx->vsp=local+20;
	w=(*ftab[22])(ctx,7,local+13,&ftab[22],fqv[164]); /*collision-check*/
	local[13]= w;
	goto irtmodelIF1325;
irtmodelIF1324:
	local[13]= NIL;
irtmodelIF1325:
	local[13]= argv[0];
	local[14]= fqv[165];
	local[15]= argv[2];
	local[16]= argv[3];
	local[17]= argv[4];
	local[18]= argv[5];
	local[19]= local[11];
	local[20]= local[12];
	local[21]= local[7];
	local[22]= local[9];
	local[23]= local[0];
	local[24]= local[1];
	local[25]= local[2];
	local[26]= local[3];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,14,local+13); /*send*/
	local[13]= argv[0];
	local[14]= fqv[154];
	local[15]= local[6];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= argv[0];
	local[14]= fqv[159];
	local[15]= local[5];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	if (local[2]!=NIL) goto irtmodelIF1326;
	local[13]= argv[0];
	local[14]= fqv[136];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	local[14]= fqv[149];
	local[15]= fqv[116];
	ctx->vsp=local+16;
	w=(*ftab[18])(ctx,3,local+13,&ftab[18],fqv[128]); /*send-all*/
	local[13]= w;
	goto irtmodelIF1327;
irtmodelIF1326:
	local[13]= NIL;
irtmodelIF1327:
	w = NIL;
	local[0]= w;
irtmodelBLK1311:
	ctx->vsp=local; return(local[0]);}

/*:make-min-max-table-using-collision-check*/
static pointer irtmodelM1328cascaded_link_make_min_max_table_using_collision_check(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=14) maerror();
	local[0]= argv[7];
	local[1]= argv[6];
	ctx->vsp=local+2;
	w=(*ftab[23])(ctx,2,local+0,&ftab[23],fqv[166]); /*make-matrix*/
	local[0]= w;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= makeint((eusinteger_t)10L);
	local[4]= makeint((eusinteger_t)0L);
irtmodelTAG1331:
	local[5]= local[4];
	local[6]= argv[7];
	ctx->vsp=local+7;
	w=(pointer)GREQP(ctx,2,local+5); /*>=*/
	if (w==NIL) goto irtmodelIF1332;
	w = NIL;
	ctx->vsp=local+5;
	local[4]=w;
	goto irtmodelBLK1330;
	goto irtmodelIF1333;
irtmodelIF1332:
	local[5]= NIL;
irtmodelIF1333:
	local[5]= argv[5];
	local[6]= fqv[20];
	local[7]= local[4];
	local[8]= argv[9];
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,2,local+7); /*+*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)ROUND(ctx,1,local+7); /*round*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[1] = fqv[167];
	local[5]= local[4];
	local[6]= makeint((eusinteger_t)10L);
	ctx->vsp=local+7;
	w=(pointer)MOD(ctx,2,local+5); /*mod*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)NUMEQUAL(ctx,2,local+5); /*=*/
	if (w==NIL) goto irtmodelIF1334;
	local[5]= T;
	local[6]= fqv[168];
	local[7]= makeint((eusinteger_t)13L);
	local[8]= local[4];
	local[9]= argv[6];
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	local[9]= argv[6];
	local[10]= argv[7];
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)XFORMAT(ctx,5,local+5); /*format*/
	ctx->vsp=local+5;
	w=(pointer)FINOUT(ctx,0,local+5); /*finish-output*/
	local[5]= w;
	goto irtmodelIF1335;
irtmodelIF1334:
	local[5]= NIL;
irtmodelIF1335:
	local[5]= makeint((eusinteger_t)0L);
irtmodelTAG1337:
	local[6]= local[5];
	local[7]= argv[6];
	ctx->vsp=local+8;
	w=(pointer)GREQP(ctx,2,local+6); /*>=*/
	if (w==NIL) goto irtmodelIF1338;
	w = NIL;
	ctx->vsp=local+6;
	local[5]=w;
	goto irtmodelBLK1336;
	goto irtmodelIF1339;
irtmodelIF1338:
	local[6]= NIL;
irtmodelIF1339:
	{jmp_buf jb;
	w = fqv[169];
	ctx->vsp=local+6;
	mkcatchframe(ctx,w,(jmp_buf *)jb);
	if ((w=(pointer)eussetjmp(jb))!=0) { /*fsp=vsp;*/ goto irtmodelCAT1340;}
	local[12]= argv[4];
	local[13]= fqv[20];
	local[14]= local[5];
	local[15]= argv[8];
	ctx->vsp=local+16;
	w=(pointer)PLUS(ctx,2,local+14); /*+*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)ROUND(ctx,1,local+14); /*round*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= local[1];
	if (fqv[170]!=local[12]) goto irtmodelCON1342;
	local[12]= local[5];
	local[13]= local[3];
	ctx->vsp=local+14;
	w=(pointer)MOD(ctx,2,local+12); /*mod*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(*ftab[24])(ctx,2,local+12,&ftab[24],fqv[171]); /*/=*/
	if (w==NIL) goto irtmodelCON1342;
	local[12]= local[5];
	local[13]= argv[6];
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)MINUS(ctx,2,local+13); /*-*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)LSEQP(ctx,2,local+12); /*<=*/
	if (w==NIL) goto irtmodelCON1342;
	local[2] = T;
	local[12]= local[2];
	goto irtmodelCON1341;
irtmodelCON1342:
	local[12]= argv[2];
	local[13]= argv[3];
	local[14]= makeint((eusinteger_t)2L);
	local[15]= fqv[162];
	local[16]= argv[10];
	local[17]= fqv[163];
	local[18]= argv[11];
	ctx->vsp=local+19;
	w=(*ftab[22])(ctx,7,local+12,&ftab[22],fqv[164]); /*collision-check*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)NUMEQUAL(ctx,2,local+12); /*=*/
	local[2] = w;
	local[12]= local[1];
	if (fqv[167]!=local[12]) goto irtmodelCON1345;
	if (local[2]==NIL) goto irtmodelCON1345;
	local[1] = fqv[170];
	local[12]= local[1];
	goto irtmodelCON1344;
irtmodelCON1345:
	local[12]= local[1];
	if (fqv[170]!=local[12]) goto irtmodelCON1346;
	if (local[2]!=NIL) goto irtmodelCON1346;
	local[1] = fqv[172];
	local[12]= local[5];
	local[13]= local[3];
	ctx->vsp=local+14;
	w=(pointer)MINUS(ctx,2,local+12); /*-*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)MAX(ctx,2,local+12); /*max*/
	local[5] = w;
	local[12]= fqv[169];
	w = NIL;
	ctx->vsp=local+13;
	throw(ctx,vpop(),w);
	error(E_NOCATCHER,NULL);
	goto irtmodelCON1344;
irtmodelCON1346:
	local[12]= NIL;
irtmodelCON1344:
	goto irtmodelCON1341;
irtmodelCON1343:
	local[12]= NIL;
irtmodelCON1341:
	local[12]= local[0];
	local[13]= local[4];
	local[14]= local[5];
	if (local[2]==NIL) goto irtmodelIF1347;
	local[15]= makeint((eusinteger_t)1L);
	goto irtmodelIF1348;
irtmodelIF1347:
	local[15]= makeint((eusinteger_t)0L);
irtmodelIF1348:
	ctx->vsp=local+16;
	w=(pointer)ASET(ctx,4,local+12); /*aset*/
	if (argv[12]==NIL) goto irtmodelIF1349;
	local[12]= T;
	local[13]= fqv[173];
	local[14]= argv[5];
	local[15]= fqv[3];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= w;
	local[15]= local[4];
	local[16]= argv[9];
	ctx->vsp=local+17;
	w=(pointer)PLUS(ctx,2,local+15); /*+*/
	local[15]= w;
	local[16]= argv[4];
	local[17]= fqv[3];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[16]= w;
	local[17]= local[5];
	local[18]= argv[8];
	ctx->vsp=local+19;
	w=(pointer)PLUS(ctx,2,local+17); /*+*/
	local[17]= w;
	local[18]= local[2];
	local[19]= local[1];
	ctx->vsp=local+20;
	w=(pointer)XFORMAT(ctx,8,local+12); /*format*/
	local[12]= w;
	goto irtmodelIF1350;
irtmodelIF1349:
	local[12]= NIL;
irtmodelIF1350:
	w = local[12];
irtmodelCAT1340:
	if (w==(pointer)(1)) w=makeint(0);
	restorecatch(ctx);};
	local[6]= local[5];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,2,local+6); /*+*/
	local[6]= w;
	local[5] = local[6];
	w = NIL;
	ctx->vsp=local+6;
	goto irtmodelTAG1337;
	w = NIL;
	local[5]= w;
irtmodelBLK1336:
	local[5]= local[4];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	local[4] = local[5];
	w = NIL;
	ctx->vsp=local+5;
	goto irtmodelTAG1331;
	w = NIL;
	local[4]= w;
irtmodelBLK1330:
	w = local[4];
	local[1]= T;
	local[2]= fqv[174];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,2,local+1); /*format*/
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtmodelFLET1351,env,argv,local);
	local[2]= argv[6];
	local[3]= argv[7];
	local[4]= argv[8];
	local[5]= argv[9];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtmodelCLO1352,env,argv,local);
	w = local[1];
	ctx->vsp=local+7;
	w=irtmodelFLET1351(ctx,5,local+2,w);
	local[2]= w;
	local[3]= argv[5];
	local[4]= fqv[11];
	local[5]= argv[4];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= argv[5];
	local[4]= fqv[10];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[2]= argv[7];
	local[3]= argv[6];
	local[4]= argv[9];
	local[5]= argv[8];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtmodelCLO1353,env,argv,local);
	w = local[1];
	ctx->vsp=local+7;
	w=irtmodelFLET1351(ctx,5,local+2,w);
	local[2]= w;
	local[3]= argv[4];
	local[4]= fqv[11];
	local[5]= argv[5];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= argv[4];
	local[4]= fqv[10];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[0]= w;
irtmodelBLK1329:
	ctx->vsp=local; return(local[0]);}

/*:plot-joint-min-max-table-common*/
static pointer irtmodelM1354cascaded_link_plot_joint_min_max_table_common(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= NIL;
	local[1]= loadglobal(fqv[175]);
	local[2]= loadglobal(fqv[176]);
	local[3]= NIL;
	ctx->vsp=local+4;
	w = makeclosure(codevec,quotevec,irtmodelUWP1356,env,argv,local);
	local[4]=(pointer)(ctx->protfp); local[5]=w;
	ctx->protfp=(struct protectframe *)(local+4);
	local[6]= fqv[177];
	local[7]= fqv[178];
	local[8]= fqv[179];
	ctx->vsp=local+9;
	w=(*ftab[25])(ctx,3,local+6,&ftab[25],fqv[180]); /*open*/
	local[6]= w;
	ctx->vsp=local+7;
	w = makeclosure(codevec,quotevec,irtmodelUWP1357,env,argv,local);
	local[7]=(pointer)(ctx->protfp); local[8]=w;
	ctx->protfp=(struct protectframe *)(local+7);
	local[9]= local[6];
	storeglobal(fqv[175],local[9]);
	local[9]= local[6];
	storeglobal(fqv[176],local[9]);
	local[9]= argv[2];
	local[10]= fqv[151];
	ctx->vsp=local+11;
	w=(pointer)GETPROP(ctx,2,local+9); /*get*/
	local[9]= w;
irtmodelTAG1359:
	local[10]= local[9];
	local[11]= argv[2];
	local[12]= fqv[152];
	ctx->vsp=local+13;
	w=(pointer)GETPROP(ctx,2,local+11); /*get*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)GREATERP(ctx,2,local+10); /*>*/
	if (w==NIL) goto irtmodelIF1360;
	w = NIL;
	ctx->vsp=local+10;
	local[9]=w;
	goto irtmodelBLK1358;
	goto irtmodelIF1361;
irtmodelIF1360:
	local[10]= NIL;
irtmodelIF1361:
	local[10]= argv[0];
	local[11]= fqv[160];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= argv[2];
	local[11]= fqv[20];
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[10]= argv[2];
	local[11]= fqv[20];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)EUSFLOAT(ctx,1,local+10); /*float*/
	local[10]= w;
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)EUSFLOAT(ctx,1,local+11); /*float*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[8])(ctx,2,local+10,&ftab[8],fqv[81]); /*eps=*/
	local[10]= w;
	local[11]= argv[3];
	local[12]= fqv[151];
	ctx->vsp=local+13;
	w=(pointer)GETPROP(ctx,2,local+11); /*get*/
	local[11]= w;
irtmodelTAG1363:
	local[12]= local[11];
	local[13]= argv[3];
	local[14]= fqv[152];
	ctx->vsp=local+15;
	w=(pointer)GETPROP(ctx,2,local+13); /*get*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)GREATERP(ctx,2,local+12); /*>*/
	if (w==NIL) goto irtmodelIF1364;
	w = NIL;
	ctx->vsp=local+12;
	local[11]=w;
	goto irtmodelBLK1362;
	goto irtmodelIF1365;
irtmodelIF1364:
	local[12]= NIL;
irtmodelIF1365:
	local[12]= argv[3];
	local[13]= fqv[20];
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= argv[3];
	local[13]= fqv[20];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)EUSFLOAT(ctx,1,local+12); /*float*/
	local[12]= w;
	local[13]= local[11];
	ctx->vsp=local+14;
	w=(pointer)EUSFLOAT(ctx,1,local+13); /*float*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(*ftab[8])(ctx,2,local+12,&ftab[8],fqv[81]); /*eps=*/
	local[12]= w;
	if (local[10]==NIL) goto irtmodelIF1366;
	if (local[12]==NIL) goto irtmodelIF1366;
	local[13]= local[9];
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,2,local+13); /*list*/
	local[13]= w;
	w = local[0];
	ctx->vsp=local+14;
	local[0] = cons(ctx,local[13],w);
	local[13]= local[0];
	goto irtmodelIF1367;
irtmodelIF1366:
	local[13]= NIL;
irtmodelIF1367:
	w = local[13];
	local[12]= makeint((eusinteger_t)1L);
	local[13]= local[11];
	ctx->vsp=local+14;
	w=(pointer)PLUS(ctx,2,local+12); /*+*/
	local[12]= w;
	local[11] = local[12];
	w = NIL;
	ctx->vsp=local+12;
	goto irtmodelTAG1363;
	w = NIL;
	local[11]= w;
irtmodelBLK1362:
	w = local[11];
	local[10]= makeint((eusinteger_t)1L);
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[10]= w;
	local[9] = local[10];
	w = NIL;
	ctx->vsp=local+10;
	goto irtmodelTAG1359;
	w = NIL;
	local[9]= w;
irtmodelBLK1358:
	local[3] = local[9];
	w = local[3];
	ctx->vsp=local+9;
	irtmodelUWP1357(ctx,0,local+9,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	ctx->vsp=local+6;
	irtmodelUWP1356(ctx,0,local+6,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)REVERSE(ctx,1,local+1); /*reverse*/
	local[0]= w;
irtmodelBLK1355:
	ctx->vsp=local; return(local[0]);}

/*:plot-joint-min-max-table*/
static pointer irtmodelM1368cascaded_link_plot_joint_min_max_table(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= loadglobal(fqv[181]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[182];
	local[3]= fqv[183];
	local[4]= argv[2];
	local[5]= fqv[184];
	local[6]= fqv[152];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= argv[2];
	local[6]= fqv[184];
	local[7]= fqv[151];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ROUND(ctx,1,local+4); /*round*/
	local[4]= w;
	local[5]= fqv[185];
	local[6]= argv[3];
	local[7]= fqv[184];
	local[8]= fqv[152];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	local[7]= argv[3];
	local[8]= fqv[184];
	local[9]= fqv[151];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ROUND(ctx,1,local+6); /*round*/
	local[6]= w;
	local[7]= fqv[186];
	local[8]= fqv[187];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,8,local+1); /*send*/
	w = local[0];
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[188];
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	local[2]= local[0];
	local[3]= fqv[189];
	local[4]= makeint((eusinteger_t)16777215L);
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= local[0];
	local[3]= fqv[190];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= local[0];
	local[3]= fqv[189];
	local[4]= makeint((eusinteger_t)16711680L);
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= NIL;
	local[3]= local[1];
irtmodelWHL1370:
	if (local[3]==NIL) goto irtmodelWHX1371;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= local[0];
	local[5]= fqv[191];
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(pointer)ROUND(ctx,1,local+6); /*round*/
	local[6]= w;
	local[7]= argv[2];
	local[8]= fqv[151];
	ctx->vsp=local+9;
	w=(pointer)GETPROP(ctx,2,local+7); /*get*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)ROUND(ctx,1,local+7); /*round*/
	local[7]= w;
	local[8]= argv[3];
	local[9]= fqv[151];
	ctx->vsp=local+10;
	w=(pointer)GETPROP(ctx,2,local+8); /*get*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,2,local+7); /*-*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,2,local+6); /*float-vector*/
	local[6]= w;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)ROUND(ctx,1,local+7); /*round*/
	local[7]= w;
	local[8]= argv[2];
	local[9]= fqv[151];
	ctx->vsp=local+10;
	w=(pointer)GETPROP(ctx,2,local+8); /*get*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,2,local+7); /*-*/
	local[7]= w;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(pointer)ROUND(ctx,1,local+8); /*round*/
	local[8]= w;
	local[9]= argv[3];
	local[10]= fqv[151];
	ctx->vsp=local+11;
	w=(pointer)GETPROP(ctx,2,local+9); /*get*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,2,local+8); /*-*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,2,local+7); /*float-vector*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	goto irtmodelWHL1370;
irtmodelWHX1371:
	local[4]= NIL;
irtmodelBLK1372:
	w = NIL;
	local[2]= local[0];
	local[3]= fqv[190];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[0]= w;
irtmodelBLK1369:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO1238(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[3];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO1241(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[3];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO1244(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[3];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelFLET1351(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= makeint((eusinteger_t)3L);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[23])(ctx,2,local+0,&ftab[23],fqv[166]); /*make-matrix*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0];
irtmodelWHL1373:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto irtmodelWHX1374;
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= NIL;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= argv[1];
irtmodelWHL1376:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto irtmodelWHX1377;
	local[8]= argv[4];
	local[9]= env->c.clo.env2[0];
	local[10]= local[1];
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)FUNCALL(ctx,4,local+8); /*funcall*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)NUMEQUAL(ctx,2,local+8); /*=*/
	if (w==NIL) goto irtmodelIF1379;
	local[5] = T;
	local[8]= local[6];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)LESSP(ctx,2,local+8); /*<*/
	if (w==NIL) goto irtmodelIF1381;
	local[3] = local[6];
	local[8]= local[3];
	goto irtmodelIF1382;
irtmodelIF1381:
	local[8]= NIL;
irtmodelIF1382:
	local[8]= local[6];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)GREATERP(ctx,2,local+8); /*>*/
	if (w==NIL) goto irtmodelIF1383;
	local[4] = local[6];
	local[8]= local[4];
	goto irtmodelIF1384;
irtmodelIF1383:
	local[8]= NIL;
irtmodelIF1384:
	goto irtmodelIF1380;
irtmodelIF1379:
	local[8]= NIL;
irtmodelIF1380:
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto irtmodelWHL1376;
irtmodelWHX1377:
	local[8]= NIL;
irtmodelBLK1378:
	w = NIL;
	if (local[5]!=NIL) goto irtmodelIF1385;
	local[6]= argv[3];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,1,local+6); /*-*/
	local[3] = w;
	local[6]= argv[3];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,1,local+6); /*-*/
	local[4] = w;
	local[6]= local[4];
	goto irtmodelIF1386;
irtmodelIF1385:
	local[6]= NIL;
irtmodelIF1386:
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[1];
	local[9]= argv[2];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)ROUND(ctx,1,local+9); /*round*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)ASET(ctx,4,local+6); /*aset*/
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= local[1];
	local[9]= env->c.clo.env1[13];
	local[10]= argv[3];
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,3,local+9); /*+*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)ROUND(ctx,1,local+9); /*round*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)ASET(ctx,4,local+6); /*aset*/
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= local[1];
	local[9]= env->c.clo.env1[13];
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,1,local+9); /*-*/
	local[9]= w;
	local[10]= argv[3];
	local[11]= local[4];
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,3,local+9); /*+*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)ROUND(ctx,1,local+9); /*round*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)ASET(ctx,4,local+6); /*aset*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto irtmodelWHL1373;
irtmodelWHX1374:
	local[3]= NIL;
irtmodelBLK1375:
	w = NIL;
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO1352(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= argv[2];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)AREF(ctx,3,local+0); /*aref*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO1353(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= argv[1];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)AREF(ctx,3,local+0); /*aref*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelUWP1356(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[1];
	storeglobal(fqv[175],local[0]);
	local[0]= env->c.clo.env2[1];
	storeglobal(fqv[176],local[0]);
	w = env->c.clo.env2[3];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelUWP1357(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[6];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:calc-target-axis-dimension*/
static pointer irtmodelM1387cascaded_link_calc_target_axis_dimension(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= makeint((eusinteger_t)6L);
	w = argv[2];
	if (!!iscons(w)) goto irtmodelIF1389;
	local[1]= makeint((eusinteger_t)1L);
	goto irtmodelIF1390;
irtmodelIF1389:
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
irtmodelIF1390:
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= NIL;
	w = argv[3];
	if (!!iscons(w)) goto irtmodelIF1391;
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	local[2]= w;
	goto irtmodelIF1392;
irtmodelIF1391:
	local[2]= argv[3];
irtmodelIF1392:
	w = argv[2];
	if (!!iscons(w)) goto irtmodelIF1393;
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	local[3]= w;
	goto irtmodelIF1394;
irtmodelIF1393:
	local[3]= argv[2];
irtmodelIF1394:
	ctx->vsp=local+4;
	w=(pointer)APPEND(ctx,2,local+2); /*append*/
	local[2]= w;
irtmodelWHL1395:
	if (local[2]==NIL) goto irtmodelWHX1396;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= local[1];
	local[4]= local[3];
	w = fqv[192];
	if (memq(local[4],w)==NIL) goto irtmodelIF1398;
	local[4]= local[0];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[0] = w;
	local[4]= local[0];
	goto irtmodelIF1399;
irtmodelIF1398:
	local[4]= local[3];
	w = fqv[193];
	if (memq(local[4],w)==NIL) goto irtmodelIF1400;
	local[4]= local[0];
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[0] = w;
	local[4]= local[0];
	goto irtmodelIF1401;
irtmodelIF1400:
	local[4]= local[3];
	if (fqv[194]!=local[4]) goto irtmodelIF1402;
	local[4]= local[0];
	local[5]= makeint((eusinteger_t)3L);
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[0] = w;
	local[4]= local[0];
	goto irtmodelIF1403;
irtmodelIF1402:
	local[4]= NIL;
irtmodelIF1403:
irtmodelIF1401:
irtmodelIF1399:
	w = local[4];
	goto irtmodelWHL1395;
irtmodelWHX1396:
	local[3]= NIL;
irtmodelBLK1397:
	w = NIL;
	w = local[0];
	local[0]= w;
irtmodelBLK1388:
	ctx->vsp=local; return(local[0]);}

/*:calc-union-link-list*/
static pointer irtmodelM1404cascaded_link_calc_union_link_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!!iscons(w)) goto irtmodelCON1407;
	local[0]= argv[2];
	goto irtmodelCON1406;
irtmodelCON1407:
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	if (makeint((eusinteger_t)1L)!=local[0]) goto irtmodelCON1408;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	goto irtmodelCON1406;
irtmodelCON1408:
	local[0]= (pointer)get_sym_func(fqv[195]);
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(*ftab[26])(ctx,2,local+0,&ftab[26],fqv[196]); /*reduce*/
	local[0]= w;
	goto irtmodelCON1406;
irtmodelCON1409:
	local[0]= NIL;
irtmodelCON1406:
	w = local[0];
	local[0]= w;
irtmodelBLK1405:
	ctx->vsp=local; return(local[0]);}

/*:calc-target-joint-dimension*/
static pointer irtmodelM1410cascaded_link_calc_target_joint_dimension(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[197];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[198];
	ctx->vsp=local+2;
	w=(*ftab[18])(ctx,2,local+0,&ftab[18],fqv[128]); /*send-all*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)irtmodelF736calc_target_joint_dimension(ctx,1,local+0); /*calc-target-joint-dimension*/
	local[0]= w;
irtmodelBLK1411:
	ctx->vsp=local; return(local[0]);}

/*:calc-inverse-jacobian*/
static pointer irtmodelM1412cascaded_link_calc_inverse_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtmodelRST1414:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[199], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1415;
	local[1] = makeflt(9.9999999999999977795540e-02);
irtmodelKEY1415:
	if (n & (1<<1)) goto irtmodelKEY1416;
	local[2] = makeflt(1.0000000000000000208167e-03);
irtmodelKEY1416:
	if (n & (1<<2)) goto irtmodelKEY1417;
	local[3] = NIL;
irtmodelKEY1417:
	if (n & (1<<3)) goto irtmodelKEY1418;
	local[4] = NIL;
irtmodelKEY1418:
	if (n & (1<<4)) goto irtmodelKEY1419;
	local[5] = NIL;
irtmodelKEY1419:
	if (n & (1<<5)) goto irtmodelKEY1420;
	local[6] = NIL;
irtmodelKEY1420:
	if (n & (1<<6)) goto irtmodelKEY1421;
	local[7] = NIL;
irtmodelKEY1421:
	if (n & (1<<7)) goto irtmodelKEY1422;
	local[8] = NIL;
irtmodelKEY1422:
	if (n & (1<<8)) goto irtmodelKEY1423;
	local[9] = NIL;
irtmodelKEY1423:
	if (n & (1<<9)) goto irtmodelKEY1424;
	local[10] = NIL;
irtmodelKEY1424:
	if (n & (1<<10)) goto irtmodelKEY1425;
	local[11] = NIL;
irtmodelKEY1425:
	if (n & (1<<11)) goto irtmodelKEY1426;
	local[12] = NIL;
irtmodelKEY1426:
	if (n & (1<<12)) goto irtmodelKEY1427;
	local[13] = NIL;
irtmodelKEY1427:
	local[14]= NIL;
	local[15]= NIL;
	local[16]= NIL;
	local[17]= makeint((eusinteger_t)0L);
	local[18]= argv[2];
	local[19]= local[12];
	local[20]= local[7];
	ctx->vsp=local+21;
	w=(*ftab[27])(ctx,3,local+18,&ftab[27],fqv[200]); /*manipulability*/
	local[15] = w;
	local[18]= local[15];
	local[19]= local[1];
	ctx->vsp=local+20;
	w=(pointer)LESSP(ctx,2,local+18); /*<*/
	if (w==NIL) goto irtmodelIF1428;
	local[18]= local[2];
	local[19]= makeflt(1.0000000000000000000000e+00);
	local[20]= local[15];
	local[21]= local[1];
	ctx->vsp=local+22;
	w=(pointer)QUOTIENT(ctx,2,local+20); /*/*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)MINUS(ctx,2,local+19); /*-*/
	local[19]= w;
	local[20]= makeint((eusinteger_t)2L);
	ctx->vsp=local+21;
	w=(*ftab[28])(ctx,2,local+19,&ftab[28],fqv[201]); /*expt*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)TIMES(ctx,2,local+18); /***/
	local[17] = w;
	local[18]= local[17];
	goto irtmodelIF1429;
irtmodelIF1428:
	local[18]= NIL;
irtmodelIF1429:
	if (local[4]==NIL) goto irtmodelIF1430;
	local[18]= fqv[202];
	w = local[4];
	if (memq(local[18],w)!=NIL) goto irtmodelIF1430;
	local[18]= fqv[203];
	local[19]= local[17];
	local[20]= local[15];
	local[21]= local[2];
	local[22]= local[1];
	local[23]= argv[2];
	ctx->vsp=local+24;
	w=(*ftab[29])(ctx,1,local+23,&ftab[29],fqv[204]); /*array-dimensions*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[23]= (w)->c.cons.car;
	ctx->vsp=local+24;
	w=(*ftab[2])(ctx,6,local+18,&ftab[2],fqv[15]); /*warn*/
	local[18]= w;
	goto irtmodelIF1431;
irtmodelIF1430:
	local[18]= NIL;
irtmodelIF1431:
	local[18]= argv[2];
	local[19]= local[17];
	local[20]= local[3];
	local[21]= local[5];
	local[22]= local[6];
	local[23]= local[7];
	local[24]= local[8];
	local[25]= local[9];
	local[26]= local[10];
	local[27]= local[11];
	local[28]= local[12];
	local[29]= local[13];
	ctx->vsp=local+30;
	w=(*ftab[30])(ctx,12,local+18,&ftab[30],fqv[205]); /*sr-inverse*/
	local[14] = w;
	w = local[14];
	local[0]= w;
irtmodelBLK1413:
	ctx->vsp=local; return(local[0]);}

/*:calc-gradh-from-link-list*/
static pointer irtmodelM1432cascaded_link_calc_gradh_from_link_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtmodelENT1435;}
	local[0]= loadglobal(fqv[5]);
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,2,local+0); /*instantiate*/
	local[0]= w;
irtmodelENT1435:
irtmodelENT1434:
	if (n>4) maerror();
	local[1]= argv[2];
	local[2]= fqv[198];
	ctx->vsp=local+3;
	w=(*ftab[18])(ctx,2,local+1,&ftab[18],fqv[128]); /*send-all*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[20];
	ctx->vsp=local+4;
	w=(*ftab[18])(ctx,2,local+2,&ftab[18],fqv[128]); /*send-all*/
	local[2]= w;
	local[3]= local[1];
	local[4]= fqv[22];
	ctx->vsp=local+5;
	w=(*ftab[18])(ctx,2,local+3,&ftab[18],fqv[128]); /*send-all*/
	local[3]= w;
	local[4]= local[1];
	local[5]= fqv[23];
	ctx->vsp=local+6;
	w=(*ftab[18])(ctx,2,local+4,&ftab[18],fqv[128]); /*send-all*/
	local[4]= w;
	local[5]= loadglobal(fqv[88]);
	local[6]= (pointer)get_sym_func(fqv[206]);
	local[7]= local[4];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)MAP(ctx,4,local+5); /*map*/
	local[5]= w;
	local[6]= loadglobal(fqv[88]);
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtmodelCLO1436,env,argv,local);
	local[8]= local[4];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)MAP(ctx,4,local+6); /*map*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= argv[2];
	ctx->vsp=local+9;
	w=(pointer)LENGTH(ctx,1,local+8); /*length*/
	local[8]= w;
irtmodelWHL1437:
	local[9]= local[7];
	w = local[8];
	if ((eusinteger_t)local[9] >= (eusinteger_t)w) goto irtmodelWHX1438;
	local[9]= local[0];
	local[10]= local[7];
	local[11]= local[6];
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= local[2];
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)MINUS(ctx,2,local+11); /*-*/
	local[11]= w;
	local[12]= local[5];
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SETELT(ctx,3,local+9); /*setelt*/
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[7] = w;
	goto irtmodelWHL1437;
irtmodelWHX1438:
	local[9]= NIL;
irtmodelBLK1439:
	w = local[0];
	w = local[0];
	local[0]= w;
irtmodelBLK1433:
	ctx->vsp=local; return(local[0]);}

/*:calc-jacobian-from-link-list*/
static pointer irtmodelM1440cascaded_link_calc_jacobian_from_link_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtmodelRST1442:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[207], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1443;
	local[1] = NIL;
irtmodelKEY1443:
	if (n & (1<<1)) goto irtmodelKEY1444;
	local[2] = local[1];
irtmodelKEY1444:
	if (n & (1<<2)) goto irtmodelKEY1445;
	w = local[1];
	if (!!iscons(w)) goto irtmodelCON1447;
	local[16]= NIL;
	goto irtmodelCON1446;
irtmodelCON1447:
	local[16]= local[1];
	ctx->vsp=local+17;
	w=(pointer)LENGTH(ctx,1,local+16); /*length*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(*ftab[31])(ctx,1,local+16,&ftab[31],fqv[208]); /*make-list*/
	local[16]= w;
	goto irtmodelCON1446;
irtmodelCON1448:
	local[16]= NIL;
irtmodelCON1446:
	local[3] = local[16];
irtmodelKEY1445:
	if (n & (1<<3)) goto irtmodelKEY1449;
	w = local[1];
	if (!!iscons(w)) goto irtmodelCON1451;
	local[16]= T;
	goto irtmodelCON1450;
irtmodelCON1451:
	local[16]= local[1];
	ctx->vsp=local+17;
	w=(pointer)LENGTH(ctx,1,local+16); /*length*/
	local[16]= w;
	local[17]= fqv[209];
	local[18]= T;
	ctx->vsp=local+19;
	w=(*ftab[31])(ctx,3,local+16,&ftab[31],fqv[208]); /*make-list*/
	local[16]= w;
	goto irtmodelCON1450;
irtmodelCON1452:
	local[16]= NIL;
irtmodelCON1450:
	local[4] = local[16];
irtmodelKEY1449:
	if (n & (1<<4)) goto irtmodelKEY1453;
	local[5] = makeint((eusinteger_t)0L);
irtmodelKEY1453:
	if (n & (1<<5)) goto irtmodelKEY1454;
	local[16]= argv[0];
	local[17]= fqv[210];
	local[18]= local[3];
	local[19]= local[4];
	ctx->vsp=local+20;
	w=(pointer)SEND(ctx,4,local+16); /*send*/
	local[6] = w;
irtmodelKEY1454:
	if (n & (1<<6)) goto irtmodelKEY1455;
	local[16]= argv[0];
	local[17]= fqv[211];
	local[18]= argv[2];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,3,local+16); /*send*/
	local[7] = w;
irtmodelKEY1455:
	if (n & (1<<7)) goto irtmodelKEY1456;
	local[8] = NIL;
irtmodelKEY1456:
	if (n & (1<<8)) goto irtmodelKEY1457;
	local[16]= loadglobal(fqv[5]);
	local[17]= makeint((eusinteger_t)0L);
	ctx->vsp=local+18;
	w=(pointer)INSTANTIATE(ctx,2,local+16); /*instantiate*/
	local[9] = w;
irtmodelKEY1457:
	if (n & (1<<9)) goto irtmodelKEY1458;
	local[16]= loadglobal(fqv[5]);
	local[17]= makeint((eusinteger_t)1L);
	ctx->vsp=local+18;
	w=(pointer)INSTANTIATE(ctx,2,local+16); /*instantiate*/
	local[10] = w;
irtmodelKEY1458:
	if (n & (1<<10)) goto irtmodelKEY1459;
	local[16]= loadglobal(fqv[5]);
	local[17]= makeint((eusinteger_t)2L);
	ctx->vsp=local+18;
	w=(pointer)INSTANTIATE(ctx,2,local+16); /*instantiate*/
	local[11] = w;
irtmodelKEY1459:
	if (n & (1<<11)) goto irtmodelKEY1460;
	local[16]= loadglobal(fqv[5]);
	local[17]= makeint((eusinteger_t)3L);
	ctx->vsp=local+18;
	w=(pointer)INSTANTIATE(ctx,2,local+16); /*instantiate*/
	local[12] = w;
irtmodelKEY1460:
	if (n & (1<<12)) goto irtmodelKEY1461;
	local[16]= loadglobal(fqv[5]);
	local[17]= makeint((eusinteger_t)3L);
	ctx->vsp=local+18;
	w=(pointer)INSTANTIATE(ctx,2,local+16); /*instantiate*/
	local[13] = w;
irtmodelKEY1461:
	if (n & (1<<13)) goto irtmodelKEY1462;
	local[16]= loadglobal(fqv[5]);
	local[17]= makeint((eusinteger_t)3L);
	ctx->vsp=local+18;
	w=(pointer)INSTANTIATE(ctx,2,local+16); /*instantiate*/
	local[14] = w;
irtmodelKEY1462:
	if (n & (1<<14)) goto irtmodelKEY1463;
	local[16]= makeint((eusinteger_t)3L);
	local[17]= makeint((eusinteger_t)3L);
	ctx->vsp=local+18;
	w=(*ftab[23])(ctx,2,local+16,&ftab[23],fqv[166]); /*make-matrix*/
	local[15] = w;
irtmodelKEY1463:
	local[16]= NIL;
	local[17]= NIL;
	local[18]= NIL;
	local[19]= NIL;
	local[20]= NIL;
	local[21]= NIL;
	local[22]= NIL;
	if (local[8]!=NIL) goto irtmodelIF1464;
	local[23]= local[6];
	local[24]= local[7];
	ctx->vsp=local+25;
	w=(*ftab[23])(ctx,2,local+23,&ftab[23],fqv[166]); /*make-matrix*/
	local[8] = w;
	local[23]= local[8];
	goto irtmodelIF1465;
irtmodelIF1464:
	local[23]= NIL;
irtmodelIF1465:
	local[23]= argv[0];
	local[24]= fqv[197];
	local[25]= argv[2];
	ctx->vsp=local+26;
	w=(pointer)SEND(ctx,3,local+23); /*send*/
	local[20] = w;
	local[23]= argv[0];
	local[24]= fqv[211];
	local[25]= local[20];
	ctx->vsp=local+26;
	w=(pointer)SEND(ctx,3,local+23); /*send*/
	local[22] = w;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!!iscons(w)) goto irtmodelIF1466;
	local[23]= argv[2];
	ctx->vsp=local+24;
	w=(pointer)LIST(ctx,1,local+23); /*list*/
	argv[2] = w;
	local[23]= argv[2];
	goto irtmodelIF1467;
irtmodelIF1466:
	local[23]= NIL;
irtmodelIF1467:
	w = local[1];
	if (!!iscons(w)) goto irtmodelIF1468;
	local[23]= local[1];
	ctx->vsp=local+24;
	w=(pointer)LIST(ctx,1,local+23); /*list*/
	local[1] = w;
	local[23]= local[1];
	goto irtmodelIF1469;
irtmodelIF1468:
	local[23]= NIL;
irtmodelIF1469:
	w = local[2];
	if (!!iscons(w)) goto irtmodelIF1470;
	local[23]= local[2];
	ctx->vsp=local+24;
	w=(pointer)LIST(ctx,1,local+23); /*list*/
	local[2] = w;
	local[23]= local[2];
	goto irtmodelIF1471;
irtmodelIF1470:
	local[23]= NIL;
irtmodelIF1471:
	w = local[3];
	if (!!iscons(w)) goto irtmodelIF1472;
	local[23]= local[3];
	ctx->vsp=local+24;
	w=(pointer)LIST(ctx,1,local+23); /*list*/
	local[3] = w;
	local[23]= local[3];
	goto irtmodelIF1473;
irtmodelIF1472:
	local[23]= NIL;
irtmodelIF1473:
	w = local[4];
	if (!!iscons(w)) goto irtmodelIF1474;
	local[23]= local[4];
	ctx->vsp=local+24;
	w=(pointer)LIST(ctx,1,local+23); /*list*/
	local[4] = w;
	local[23]= local[4];
	goto irtmodelIF1475;
irtmodelIF1474:
	local[23]= NIL;
irtmodelIF1475:
	local[23]= local[5];
	local[24]= makeint((eusinteger_t)0L);
irtmodelTAG1477:
	local[25]= local[23];
	local[26]= local[5];
	local[27]= local[22];
	ctx->vsp=local+28;
	w=(pointer)PLUS(ctx,2,local+26); /*+*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)GREQP(ctx,2,local+25); /*>=*/
	if (w==NIL) goto irtmodelIF1478;
	w = NIL;
	ctx->vsp=local+25;
	local[23]=w;
	goto irtmodelBLK1476;
	goto irtmodelIF1479;
irtmodelIF1478:
	local[25]= NIL;
irtmodelIF1479:
	local[25]= local[20];
	local[26]= local[24];
	ctx->vsp=local+27;
	w=(pointer)ELT(ctx,2,local+25); /*elt*/
	local[17] = w;
	local[18] = makeint((eusinteger_t)0L);
	local[25]= makeint((eusinteger_t)0L);
	local[26]= argv[2];
	ctx->vsp=local+27;
	w=(pointer)LENGTH(ctx,1,local+26); /*length*/
	local[26]= w;
irtmodelWHL1480:
	local[27]= local[25];
	w = local[26];
	if ((eusinteger_t)local[27] >= (eusinteger_t)w) goto irtmodelWHX1481;
	local[27]= argv[2];
	local[28]= local[25];
	ctx->vsp=local+29;
	w=(pointer)ELT(ctx,2,local+27); /*elt*/
	local[27]= w;
	local[28]= local[1];
	local[29]= local[25];
	ctx->vsp=local+30;
	w=(pointer)ELT(ctx,2,local+28); /*elt*/
	local[28]= w;
	local[29]= local[2];
	local[30]= local[25];
	ctx->vsp=local+31;
	w=(pointer)ELT(ctx,2,local+29); /*elt*/
	local[29]= w;
	local[30]= local[3];
	local[31]= local[25];
	ctx->vsp=local+32;
	w=(pointer)ELT(ctx,2,local+30); /*elt*/
	local[30]= w;
	local[31]= local[4];
	local[32]= local[25];
	ctx->vsp=local+33;
	w=(pointer)ELT(ctx,2,local+31); /*elt*/
	local[31]= w;
	local[32]= NIL;
	local[33]= local[17];
	local[34]= local[27];
	local[35]= fqv[139];
	local[36]= (pointer)get_sym_func(fqv[140]);
	ctx->vsp=local+37;
	w=(*ftab[16])(ctx,4,local+33,&ftab[16],fqv[124]); /*member*/
	if (w==NIL) goto irtmodelIF1483;
	local[33]= local[27];
	ctx->vsp=local+34;
	w=(pointer)LENGTH(ctx,1,local+33); /*length*/
	local[16] = w;
	local[33]= local[17];
	local[34]= local[27];
	local[35]= fqv[139];
	local[36]= (pointer)get_sym_func(fqv[140]);
	ctx->vsp=local+37;
	w=(*ftab[32])(ctx,4,local+33,&ftab[32],fqv[212]); /*position*/
	local[32] = w;
	local[33]= local[17];
	local[34]= fqv[198];
	ctx->vsp=local+35;
	w=(pointer)SEND(ctx,2,local+33); /*send*/
	local[21] = w;
	ctx->vsp=local+33;
	local[33]= makeclosure(codevec,quotevec,irtmodelFLET1485,env,argv,local);
	local[34]= local[21];
	local[35]= fqv[130];
	ctx->vsp=local+36;
	w=(pointer)SEND(ctx,2,local+34); /*send*/
	local[34]= w;
	local[35]= loadglobal(fqv[213]);
	ctx->vsp=local+36;
	w=(pointer)DERIVEDP(ctx,2,local+34); /*derivedp*/
	if (w!=NIL) goto irtmodelCON1487;
	local[19] = NIL;
	local[34]= local[19];
	goto irtmodelCON1486;
irtmodelCON1487:
	local[34]= local[32];
	local[35]= makeint((eusinteger_t)1L);
	ctx->vsp=local+36;
	w=(pointer)PLUS(ctx,2,local+34); /*+*/
	local[34]= w;
	local[35]= local[16];
	ctx->vsp=local+36;
	w=(pointer)LESSP(ctx,2,local+34); /*<*/
	if (w==NIL) goto irtmodelAND1490;
	local[34]= local[21];
	local[35]= fqv[130];
	ctx->vsp=local+36;
	w=(pointer)SEND(ctx,2,local+34); /*send*/
	local[34]= w;
	local[35]= local[27];
	local[36]= local[32];
	local[37]= makeint((eusinteger_t)1L);
	ctx->vsp=local+38;
	w=(pointer)PLUS(ctx,2,local+36); /*+*/
	local[36]= w;
	ctx->vsp=local+37;
	w=(pointer)ELT(ctx,2,local+35); /*elt*/
	local[35]= w;
	local[36]= fqv[133];
	ctx->vsp=local+37;
	w=(pointer)SEND(ctx,2,local+35); /*send*/
	local[35]= w;
	local[36]= local[27];
	w = local[33];
	ctx->vsp=local+37;
	w=irtmodelFLET1485(ctx,2,local+35,w);
	if (w==local[34]) goto irtmodelAND1490;
	goto irtmodelOR1489;
irtmodelAND1490:
	local[34]= local[16];
	local[35]= local[32];
	local[36]= makeint((eusinteger_t)1L);
	ctx->vsp=local+37;
	w=(pointer)PLUS(ctx,2,local+35); /*+*/
	local[35]= w;
	ctx->vsp=local+36;
	w=(pointer)NUMEQUAL(ctx,2,local+34); /*=*/
	if (w==NIL) goto irtmodelAND1491;
	local[34]= local[21];
	local[35]= fqv[130];
	ctx->vsp=local+36;
	w=(pointer)SEND(ctx,2,local+34); /*send*/
	local[34]= w;
	local[35]= local[28];
	local[36]= fqv[214];
	ctx->vsp=local+37;
	w=(pointer)SEND(ctx,2,local+35); /*send*/
	local[35]= w;
	local[36]= local[27];
	w = local[33];
	ctx->vsp=local+37;
	w=irtmodelFLET1485(ctx,2,local+35,w);
	if (w==local[34]) goto irtmodelAND1491;
	goto irtmodelOR1489;
irtmodelAND1491:
	goto irtmodelCON1488;
irtmodelOR1489:
	local[19] = T;
	local[34]= local[19];
	goto irtmodelCON1486;
irtmodelCON1488:
	local[19] = NIL;
	local[34]= local[19];
	goto irtmodelCON1486;
irtmodelCON1492:
	local[34]= NIL;
irtmodelCON1486:
	w = local[34];
	local[33]= *(ovafptr(local[21],fqv[215]));
	local[34]= local[33];
	if (fqv[52]!=local[34]) goto irtmodelIF1493;
	local[34]= fqv[216];
	goto irtmodelIF1494;
irtmodelIF1493:
	local[34]= local[33];
	if (fqv[54]!=local[34]) goto irtmodelIF1495;
	local[34]= fqv[217];
	goto irtmodelIF1496;
irtmodelIF1495:
	local[34]= local[33];
	if (fqv[33]!=local[34]) goto irtmodelIF1497;
	local[34]= fqv[218];
	goto irtmodelIF1498;
irtmodelIF1497:
	local[34]= local[33];
	if (fqv[219]!=local[34]) goto irtmodelIF1499;
	local[34]= fqv[220];
	goto irtmodelIF1500;
irtmodelIF1499:
	local[34]= local[33];
	if (fqv[221]!=local[34]) goto irtmodelIF1501;
	local[34]= fqv[222];
	goto irtmodelIF1502;
irtmodelIF1501:
	local[34]= local[33];
	if (fqv[223]!=local[34]) goto irtmodelIF1503;
	local[34]= fqv[224];
	goto irtmodelIF1504;
irtmodelIF1503:
	local[34]= local[33];
	if (fqv[53]!=local[34]) goto irtmodelIF1505;
	local[34]= fqv[225];
	goto irtmodelIF1506;
irtmodelIF1505:
	local[34]= local[33];
	if (fqv[55]!=local[34]) goto irtmodelIF1507;
	local[34]= fqv[226];
	goto irtmodelIF1508;
irtmodelIF1507:
	local[34]= local[33];
	if (fqv[56]!=local[34]) goto irtmodelIF1509;
	local[34]= fqv[227];
	goto irtmodelIF1510;
irtmodelIF1509:
	if (T==NIL) goto irtmodelIF1511;
	local[34]= *(ovafptr(local[21],fqv[215]));
	goto irtmodelIF1512;
irtmodelIF1511:
	local[34]= NIL;
irtmodelIF1512:
irtmodelIF1510:
irtmodelIF1508:
irtmodelIF1506:
irtmodelIF1504:
irtmodelIF1502:
irtmodelIF1500:
irtmodelIF1498:
irtmodelIF1496:
irtmodelIF1494:
	w = local[34];
	local[33]= w;
	local[34]= local[21];
	local[35]= fqv[130];
	ctx->vsp=local+36;
	w=(pointer)SEND(ctx,2,local+34); /*send*/
	local[34]= w;
	local[35]= local[21];
	local[36]= fqv[133];
	ctx->vsp=local+37;
	w=(pointer)SEND(ctx,2,local+35); /*send*/
	local[35]= w;
	local[36]= *(ovafptr(local[21],fqv[228]));
	local[37]= local[35];
	local[38]= fqv[153];
	ctx->vsp=local+39;
	w=(pointer)SEND(ctx,2,local+37); /*send*/
	local[37]= w;
	local[38]= fqv[84];
	local[39]= local[36];
	ctx->vsp=local+40;
	w=(pointer)SEND(ctx,3,local+37); /*send*/
	local[37]= w;
	local[38]= local[21];
	local[39]= fqv[229];
	local[40]= local[8];
	local[41]= local[18];
	local[42]= local[23];
	local[43]= local[21];
	local[44]= local[33];
	local[45]= local[34];
	local[46]= local[37];
	local[47]= local[19];
	local[48]= local[28];
	local[49]= local[29];
	local[50]= local[30];
	local[51]= local[31];
	local[52]= local[9];
	local[53]= local[10];
	local[54]= local[11];
	local[55]= local[12];
	local[56]= local[13];
	local[57]= local[14];
	local[58]= local[15];
	ctx->vsp=local+59;
	w=(pointer)SEND(ctx,21,local+38); /*send*/
	local[33]= w;
	goto irtmodelIF1484;
irtmodelIF1483:
	local[33]= NIL;
irtmodelIF1484:
	local[33]= local[18];
	local[34]= argv[0];
	local[35]= fqv[210];
	local[36]= local[30];
	local[37]= local[31];
	ctx->vsp=local+38;
	w=(pointer)SEND(ctx,4,local+34); /*send*/
	local[34]= w;
	ctx->vsp=local+35;
	w=(pointer)PLUS(ctx,2,local+33); /*+*/
	local[18] = w;
	w = local[18];
	local[27]= local[25];
	ctx->vsp=local+28;
	w=(pointer)ADD1(ctx,1,local+27); /*1+*/
	local[25] = w;
	goto irtmodelWHL1480;
irtmodelWHX1481:
	local[27]= NIL;
irtmodelBLK1482:
	w = NIL;
	local[25]= local[23];
	local[26]= local[21];
	local[27]= fqv[31];
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,2,local+26); /*send*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)PLUS(ctx,2,local+25); /*+*/
	local[25]= w;
	local[26]= local[24];
	ctx->vsp=local+27;
	w=(pointer)ADD1(ctx,1,local+26); /*1+*/
	local[26]= w;
	local[23] = local[25];
	local[24] = local[26];
	w = NIL;
	ctx->vsp=local+25;
	goto irtmodelTAG1477;
	w = NIL;
	local[23]= w;
irtmodelBLK1476:
	w = local[8];
	local[0]= w;
irtmodelBLK1441:
	ctx->vsp=local; return(local[0]);}

/*:calc-joint-angle-speed*/
static pointer irtmodelM1513cascaded_link_calc_joint_angle_speed(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtmodelRST1515:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[230], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1516;
	local[1] = NIL;
irtmodelKEY1516:
	if (n & (1<<1)) goto irtmodelKEY1517;
	local[2] = makeflt(5.0000000000000000000000e-01);
irtmodelKEY1517:
	if (n & (1<<2)) goto irtmodelKEY1518;
	local[3] = NIL;
irtmodelKEY1518:
	if (n & (1<<3)) goto irtmodelKEY1519;
	local[4] = NIL;
irtmodelKEY1519:
	if (n & (1<<4)) goto irtmodelKEY1520;
	local[5] = NIL;
irtmodelKEY1520:
	if (n & (1<<5)) goto irtmodelKEY1521;
	local[6] = NIL;
irtmodelKEY1521:
	if (n & (1<<6)) goto irtmodelKEY1522;
	local[7] = NIL;
irtmodelKEY1522:
	if (n & (1<<7)) goto irtmodelKEY1523;
	local[8] = NIL;
irtmodelKEY1523:
	if (n & (1<<8)) goto irtmodelKEY1524;
	local[9] = NIL;
irtmodelKEY1524:
	if (n & (1<<9)) goto irtmodelKEY1525;
	local[10] = NIL;
irtmodelKEY1525:
	if (n & (1<<10)) goto irtmodelKEY1526;
	local[11] = NIL;
irtmodelKEY1526:
	if (n & (1<<11)) goto irtmodelKEY1527;
	local[12] = NIL;
irtmodelKEY1527:
	if (local[3]==NIL) goto irtmodelOR1530;
	if (local[4]==NIL) goto irtmodelOR1530;
	goto irtmodelIF1528;
irtmodelOR1530:
	local[13]= fqv[231];
	ctx->vsp=local+14;
	w=(*ftab[2])(ctx,1,local+13,&ftab[2],fqv[15]); /*warn*/
	w = local[5];
	ctx->vsp=local+13;
	local[0]=w;
	goto irtmodelBLK1514;
	goto irtmodelIF1529;
irtmodelIF1528:
	local[13]= NIL;
irtmodelIF1529:
	if (local[12]!=NIL) goto irtmodelIF1531;
	local[13]= local[3];
	ctx->vsp=local+14;
	w=(*ftab[29])(ctx,1,local+13,&ftab[29],fqv[204]); /*array-dimensions*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12] = (w)->c.cons.car;
	local[13]= local[12];
	goto irtmodelIF1532;
irtmodelIF1531:
	local[13]= NIL;
irtmodelIF1532:
	if (local[10]!=NIL) goto irtmodelIF1533;
	local[13]= loadglobal(fqv[5]);
	local[14]= local[12];
	ctx->vsp=local+15;
	w=(pointer)INSTANTIATE(ctx,2,local+13); /*instantiate*/
	local[10] = w;
	local[13]= local[10];
	goto irtmodelIF1534;
irtmodelIF1533:
	local[13]= NIL;
irtmodelIF1534:
	if (local[11]!=NIL) goto irtmodelIF1535;
	local[13]= loadglobal(fqv[5]);
	local[14]= local[12];
	ctx->vsp=local+15;
	w=(pointer)INSTANTIATE(ctx,2,local+13); /*instantiate*/
	local[11] = w;
	local[13]= local[11];
	goto irtmodelIF1536;
irtmodelIF1535:
	local[13]= NIL;
irtmodelIF1536:
	local[13]= local[4];
	local[14]= argv[2];
	local[15]= local[10];
	ctx->vsp=local+16;
	w=(pointer)TRANSFORM(ctx,3,local+13); /*transform*/
	local[13]= w;
	if (local[7]==NIL) goto irtmodelIF1537;
	local[14]= fqv[202];
	w = local[7];
	if (memq(local[14],w)!=NIL) goto irtmodelIF1537;
	local[14]= local[3];
	local[15]= fqv[232];
	ctx->vsp=local+16;
	w=(*ftab[33])(ctx,2,local+14,&ftab[33],fqv[233]); /*format-array*/
	local[14]= fqv[234];
	local[15]= local[3];
	local[16]= local[3];
	ctx->vsp=local+17;
	w=(pointer)TRANSPOSE(ctx,1,local+16); /*transpose*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)MATTIMES(ctx,2,local+15); /*m**/
	local[15]= w;
	ctx->vsp=local+16;
	w=(*ftab[34])(ctx,1,local+15,&ftab[34],fqv[235]); /*matrix-determinant*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(*ftab[2])(ctx,2,local+14,&ftab[2],fqv[15]); /*warn*/
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(pointer)TRANSPOSE(ctx,1,local+14); /*transpose*/
	local[14]= w;
	local[15]= fqv[236];
	ctx->vsp=local+16;
	w=(*ftab[33])(ctx,2,local+14,&ftab[33],fqv[233]); /*format-array*/
	local[14]= argv[2];
	local[15]= fqv[237];
	ctx->vsp=local+16;
	w=(*ftab[33])(ctx,2,local+14,&ftab[33],fqv[233]); /*format-array*/
	local[14]= loadglobal(fqv[5]);
	local[15]= (pointer)get_sym_func(fqv[49]);
	local[16]= local[13];
	ctx->vsp=local+17;
	w=(pointer)MAP(ctx,3,local+14); /*map*/
	local[14]= w;
	local[15]= fqv[238];
	ctx->vsp=local+16;
	w=(*ftab[33])(ctx,2,local+14,&ftab[33],fqv[233]); /*format-array*/
	local[14]= w;
	goto irtmodelIF1538;
irtmodelIF1537:
	local[14]= NIL;
irtmodelIF1538:
	if (local[1]==NIL) goto irtmodelIF1539;
	local[14]= local[2];
	local[15]= local[13];
	local[16]= local[1];
	local[17]= local[13];
	ctx->vsp=local+18;
	w=(*ftab[35])(ctx,4,local+14,&ftab[35],fqv[239]); /*midpoint*/
	local[13] = w;
	if (local[7]==NIL) goto irtmodelIF1541;
	local[14]= fqv[202];
	w = local[7];
	if (memq(local[14],w)!=NIL) goto irtmodelIF1541;
	local[14]= loadglobal(fqv[5]);
	local[15]= (pointer)get_sym_func(fqv[49]);
	local[16]= local[1];
	ctx->vsp=local+17;
	w=(pointer)MAP(ctx,3,local+14); /*map*/
	local[14]= w;
	local[15]= fqv[240];
	ctx->vsp=local+16;
	w=(*ftab[33])(ctx,2,local+14,&ftab[33],fqv[233]); /*format-array*/
	local[14]= loadglobal(fqv[5]);
	local[15]= (pointer)get_sym_func(fqv[49]);
	local[16]= local[13];
	ctx->vsp=local+17;
	w=(pointer)MAP(ctx,3,local+14); /*map*/
	local[14]= w;
	local[15]= fqv[241];
	ctx->vsp=local+16;
	w=(*ftab[33])(ctx,2,local+14,&ftab[33],fqv[233]); /*format-array*/
	local[14]= w;
	goto irtmodelIF1542;
irtmodelIF1541:
	local[14]= NIL;
irtmodelIF1542:
	goto irtmodelIF1540;
irtmodelIF1539:
	local[14]= NIL;
irtmodelIF1540:
	local[14]= local[5];
	ctx->vsp=local+15;
	w=(pointer)VECTORP(ctx,1,local+14); /*vectorp*/
	if (w==NIL) goto irtmodelIF1543;
	local[14]= local[12];
	local[15]= local[5];
	ctx->vsp=local+16;
	w=(pointer)LENGTH(ctx,1,local+15); /*length*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)NUMEQUAL(ctx,2,local+14); /*=*/
	if (w==NIL) goto irtmodelIF1543;
	if (local[6]==NIL) goto irtmodelIF1543;
	if (local[8]!=NIL) goto irtmodelIF1545;
	local[14]= loadglobal(fqv[5]);
	local[15]= local[12];
	ctx->vsp=local+16;
	w=(pointer)INSTANTIATE(ctx,2,local+14); /*instantiate*/
	local[14]= w;
	local[15]= makeint((eusinteger_t)1L);
	ctx->vsp=local+16;
	w=(*ftab[36])(ctx,2,local+14,&ftab[36],fqv[242]); /*fill*/
	local[8] = w;
	local[14]= local[8];
	goto irtmodelIF1546;
irtmodelIF1545:
	local[14]= NIL;
irtmodelIF1546:
	if (local[9]!=NIL) goto irtmodelIF1547;
	local[14]= local[12];
	local[15]= local[12];
	ctx->vsp=local+16;
	w=(*ftab[23])(ctx,2,local+14,&ftab[23],fqv[166]); /*make-matrix*/
	local[9] = w;
	local[14]= local[9];
	goto irtmodelIF1548;
irtmodelIF1547:
	local[14]= NIL;
irtmodelIF1548:
	local[14]= makeint((eusinteger_t)0L);
	local[15]= local[12];
irtmodelWHL1549:
	local[16]= local[14];
	w = local[15];
	if ((eusinteger_t)local[16] >= (eusinteger_t)w) goto irtmodelWHX1550;
	local[16]= local[9];
	local[17]= local[14];
	local[18]= local[14];
	local[19]= local[8];
	local[20]= local[14];
	ctx->vsp=local+21;
	w=(pointer)AREF(ctx,2,local+19); /*aref*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)ASET(ctx,4,local+16); /*aset*/
	local[16]= local[14];
	ctx->vsp=local+17;
	w=(pointer)ADD1(ctx,1,local+16); /*1+*/
	local[14] = w;
	goto irtmodelWHL1549;
irtmodelWHX1550:
	local[16]= NIL;
irtmodelBLK1551:
	w = NIL;
	local[14]= local[13];
	local[15]= local[6];
	local[16]= local[5];
	local[17]= local[11];
	ctx->vsp=local+18;
	w=(pointer)TRANSFORM(ctx,3,local+15); /*transform*/
	local[15]= w;
	local[16]= local[13];
	ctx->vsp=local+17;
	w=(pointer)VPLUS(ctx,3,local+14); /*v+*/
	if (local[7]==NIL) goto irtmodelIF1552;
	local[14]= fqv[202];
	w = local[7];
	if (memq(local[14],w)!=NIL) goto irtmodelIF1552;
	local[14]= loadglobal(fqv[5]);
	local[15]= (pointer)get_sym_func(fqv[49]);
	local[16]= local[11];
	ctx->vsp=local+17;
	w=(pointer)MAP(ctx,3,local+14); /*map*/
	local[14]= w;
	local[15]= fqv[243];
	ctx->vsp=local+16;
	w=(*ftab[33])(ctx,2,local+14,&ftab[33],fqv[233]); /*format-array*/
	local[14]= loadglobal(fqv[5]);
	local[15]= (pointer)get_sym_func(fqv[49]);
	local[16]= local[13];
	ctx->vsp=local+17;
	w=(pointer)MAP(ctx,3,local+14); /*map*/
	local[14]= w;
	local[15]= fqv[244];
	ctx->vsp=local+16;
	w=(*ftab[33])(ctx,2,local+14,&ftab[33],fqv[233]); /*format-array*/
	local[14]= w;
	goto irtmodelIF1553;
irtmodelIF1552:
	local[14]= NIL;
irtmodelIF1553:
	goto irtmodelIF1544;
irtmodelIF1543:
	local[14]= NIL;
irtmodelIF1544:
	w = local[13];
	local[0]= w;
irtmodelBLK1514:
	ctx->vsp=local; return(local[0]);}

/*:calc-joint-angle-speed-gain*/
static pointer irtmodelM1554cascaded_link_calc_joint_angle_speed_gain(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0];
	local[1]= fqv[211];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= loadglobal(fqv[5]);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,2,local+1); /*instantiate*/
	local[1]= w;
	local[2]= NIL;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
irtmodelTAG1557:
	local[5]= local[4];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)GREQP(ctx,2,local+5); /*>=*/
	if (w==NIL) goto irtmodelIF1558;
	w = NIL;
	ctx->vsp=local+5;
	local[3]=w;
	goto irtmodelBLK1556;
	goto irtmodelIF1559;
irtmodelIF1558:
	local[5]= NIL;
irtmodelIF1559:
	local[5]= argv[2];
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= fqv[198];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[2] = w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[2];
	local[7]= fqv[31];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
irtmodelWHL1560:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto irtmodelWHX1561;
	local[7]= local[1];
	local[8]= local[3];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[8]= w;
	local[9]= local[2];
	local[10]= fqv[245];
	local[11]= argv[3];
	local[12]= local[3];
	local[13]= argv[4];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,5,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SETELT(ctx,3,local+7); /*setelt*/
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto irtmodelWHL1560;
irtmodelWHX1561:
	local[7]= NIL;
irtmodelBLK1562:
	w = NIL;
	local[5]= local[3];
	local[6]= local[2];
	local[7]= fqv[31];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[3] = w;
	local[5]= local[4];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[4] = w;
	ctx->vsp=local+5;
	goto irtmodelTAG1557;
	w = NIL;
	local[3]= w;
irtmodelBLK1556:
	w = local[1];
	local[0]= w;
irtmodelBLK1555:
	ctx->vsp=local; return(local[0]);}

/*:collision-avoidance-links*/
static pointer irtmodelM1563cascaded_link_collision_avoidance_links(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT1566;}
	local[0]= NIL;
irtmodelENT1566:
irtmodelENT1565:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtmodelIF1567;
	argv[0]->c.obj.iv[11] = local[0];
	local[1]= argv[0]->c.obj.iv[11];
	goto irtmodelIF1568;
irtmodelIF1567:
	local[1]= NIL;
irtmodelIF1568:
	w = argv[0]->c.obj.iv[11];
	local[0]= w;
irtmodelBLK1564:
	ctx->vsp=local; return(local[0]);}

/*:collision-avoidance-link-pair-from-link-list*/
static pointer irtmodelM1569cascaded_link_collision_avoidance_link_pair_from_link_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[246], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY1571;
	local[0] = NIL;
irtmodelKEY1571:
	if (n & (1<<1)) goto irtmodelKEY1572;
	local[1] = argv[0]->c.obj.iv[11];
irtmodelKEY1572:
	if (n & (1<<2)) goto irtmodelKEY1573;
	local[2] = NIL;
irtmodelKEY1573:
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,irtmodelCLO1574,env,argv,local);
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)MAPCAR(ctx,2,local+3); /*mapcar*/
	local[3]= w;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
	local[8]= NIL;
	local[9]= NIL;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!!iscons(w)) goto irtmodelIF1575;
	local[10]= argv[2];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	argv[2] = w;
	local[10]= argv[2];
	goto irtmodelIF1576;
irtmodelIF1575:
	local[10]= NIL;
irtmodelIF1576:
	if (local[2]==NIL) goto irtmodelIF1577;
	local[10]= fqv[202];
	w = local[2];
	if (memq(local[10],w)!=NIL) goto irtmodelIF1577;
	local[10]= fqv[247];
	local[11]= local[1];
	local[12]= fqv[3];
	ctx->vsp=local+13;
	w=(*ftab[18])(ctx,2,local+11,&ftab[18],fqv[128]); /*send-all*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[2])(ctx,2,local+10,&ftab[2],fqv[15]); /*warn*/
	local[10]= fqv[248];
	local[11]= local[3];
	local[12]= fqv[3];
	ctx->vsp=local+13;
	w=(*ftab[18])(ctx,2,local+11,&ftab[18],fqv[128]); /*send-all*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[2])(ctx,2,local+10,&ftab[2],fqv[15]); /*warn*/
	local[10]= w;
	goto irtmodelIF1578;
irtmodelIF1577:
	local[10]= NIL;
irtmodelIF1578:
	local[10]= NIL;
	local[11]= argv[2];
irtmodelWHL1579:
	if (local[11]==NIL) goto irtmodelWHX1580;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11] = (w)->c.cons.cdr;
	w = local[12];
	local[10] = w;
	local[12]= local[10];
	local[13]= makeint((eusinteger_t)1L);
irtmodelTAG1583:
	local[14]= local[13];
	local[15]= local[10];
	ctx->vsp=local+16;
	w=(pointer)LENGTH(ctx,1,local+15); /*length*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)SUB1(ctx,1,local+15); /*1-*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)LESSP(ctx,2,local+14); /*<*/
	if (w==NIL) goto irtmodelAND1586;
	local[14]= local[10];
	local[15]= makeint((eusinteger_t)0L);
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[14]= w;
	local[15]= fqv[29];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= w;
	local[15]= local[10];
	local[16]= local[13];
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	local[16]= fqv[29];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)VDISTANCE(ctx,2,local+14); /*distance*/
	local[14]= w;
	local[15]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+16;
	w=(*ftab[8])(ctx,2,local+14,&ftab[8],fqv[81]); /*eps=*/
	if (w==NIL) goto irtmodelAND1586;
	goto irtmodelIF1584;
irtmodelAND1586:
	local[14]= local[13];
	ctx->vsp=local+15;
	w=(pointer)SUB1(ctx,1,local+14); /*1-*/
	ctx->vsp=local+14;
	local[13]=w;
	goto irtmodelBLK1582;
	goto irtmodelIF1585;
irtmodelIF1584:
	local[14]= NIL;
irtmodelIF1585:
	local[14]= local[13];
	ctx->vsp=local+15;
	w=(pointer)ADD1(ctx,1,local+14); /*1+*/
	local[14]= w;
	local[13] = local[14];
	w = NIL;
	ctx->vsp=local+14;
	goto irtmodelTAG1583;
	w = NIL;
	local[13]= w;
irtmodelBLK1582:
	ctx->vsp=local+14;
	w=(pointer)SUBSEQ(ctx,2,local+12); /*subseq*/
	local[5] = w;
	ctx->vsp=local+12;
	local[12]= makeclosure(codevec,quotevec,irtmodelCLO1587,env,argv,local);
	local[13]= local[1];
	ctx->vsp=local+14;
	w=(pointer)MAPCAR(ctx,2,local+12); /*mapcar*/
	local[6] = w;
	if (local[2]==NIL) goto irtmodelIF1588;
	local[12]= fqv[202];
	w = local[2];
	if (memq(local[12],w)!=NIL) goto irtmodelIF1588;
	local[12]= fqv[249];
	local[13]= local[5];
	local[14]= fqv[3];
	ctx->vsp=local+15;
	w=(*ftab[18])(ctx,2,local+13,&ftab[18],fqv[128]); /*send-all*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(*ftab[2])(ctx,2,local+12,&ftab[2],fqv[15]); /*warn*/
	local[12]= fqv[250];
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(*ftab[2])(ctx,2,local+12,&ftab[2],fqv[15]); /*warn*/
	local[12]= w;
	goto irtmodelIF1589;
irtmodelIF1588:
	local[12]= NIL;
irtmodelIF1589:
	local[12]= makeint((eusinteger_t)0L);
	local[13]= local[7];
irtmodelWHL1590:
	local[14]= local[12];
	w = local[13];
	if ((eusinteger_t)local[14] >= (eusinteger_t)w) goto irtmodelWHX1591;
	local[14]= local[12];
	ctx->vsp=local+15;
	w=(pointer)ADD1(ctx,1,local+14); /*1+*/
	local[14]= w;
irtmodelTAG1594:
	local[15]= local[14];
	local[16]= local[7];
	ctx->vsp=local+17;
	w=(pointer)GREQP(ctx,2,local+15); /*>=*/
	if (w==NIL) goto irtmodelIF1595;
	w = NIL;
	ctx->vsp=local+15;
	local[14]=w;
	goto irtmodelBLK1593;
	goto irtmodelIF1596;
irtmodelIF1595:
	local[15]= NIL;
irtmodelIF1596:
	local[15]= local[6];
	local[16]= local[12];
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[8] = w;
	if (local[8]!=NIL) goto irtmodelOR1599;
	local[15]= local[6];
	local[16]= local[14];
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	if (w!=NIL) goto irtmodelOR1599;
	goto irtmodelIF1597;
irtmodelOR1599:
	local[15]= local[3];
	local[16]= local[12];
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	local[16]= local[1];
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	if (w==local[15]) goto irtmodelIF1597;
	local[15]= local[3];
	local[16]= local[14];
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	local[16]= local[1];
	local[17]= local[12];
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	if (w==local[15]) goto irtmodelIF1597;
	local[15]= local[3];
	local[16]= local[14];
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	local[16]= local[3];
	local[17]= local[12];
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	if (w==local[15]) goto irtmodelIF1597;
	local[15]= local[1];
	if (local[8]==NIL) goto irtmodelIF1600;
	local[16]= local[12];
	goto irtmodelIF1601;
irtmodelIF1600:
	local[16]= local[14];
irtmodelIF1601:
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	local[16]= local[1];
	if (local[8]==NIL) goto irtmodelIF1602;
	local[17]= local[14];
	goto irtmodelIF1603;
irtmodelIF1602:
	local[17]= local[12];
irtmodelIF1603:
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,2,local+15); /*list*/
	local[15]= w;
	w = local[9];
	ctx->vsp=local+16;
	local[9] = cons(ctx,local[15],w);
	local[15]= local[9];
	goto irtmodelIF1598;
irtmodelIF1597:
	local[15]= NIL;
irtmodelIF1598:
	local[15]= local[14];
	ctx->vsp=local+16;
	w=(pointer)ADD1(ctx,1,local+15); /*1+*/
	local[15]= w;
	local[14] = local[15];
	w = NIL;
	ctx->vsp=local+15;
	goto irtmodelTAG1594;
	w = NIL;
	local[14]= w;
irtmodelBLK1593:
	local[14]= local[12];
	ctx->vsp=local+15;
	w=(pointer)ADD1(ctx,1,local+14); /*1+*/
	local[12] = w;
	goto irtmodelWHL1590;
irtmodelWHX1591:
	local[14]= NIL;
irtmodelBLK1592:
	w = NIL;
	if (local[0]==NIL) goto irtmodelIF1604;
	w = local[0];
	if (!!iscons(w)) goto irtmodelIF1606;
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	local[0] = w;
	local[12]= local[0];
	goto irtmodelIF1607;
irtmodelIF1606:
	local[12]= NIL;
irtmodelIF1607:
	local[12]= makeint((eusinteger_t)0L);
	local[13]= local[7];
irtmodelWHL1608:
	local[14]= local[12];
	w = local[13];
	if ((eusinteger_t)local[14] >= (eusinteger_t)w) goto irtmodelWHX1609;
	local[14]= local[6];
	local[15]= local[12];
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	if (w==NIL) goto irtmodelIF1611;
	local[14]= NIL;
	local[15]= local[0];
irtmodelWHL1613:
	if (local[15]==NIL) goto irtmodelWHX1614;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15] = (w)->c.cons.cdr;
	w = local[16];
	local[14] = w;
	local[16]= local[1];
	local[17]= local[12];
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)LIST(ctx,2,local+16); /*list*/
	local[16]= w;
	w = local[9];
	ctx->vsp=local+17;
	local[9] = cons(ctx,local[16],w);
	goto irtmodelWHL1613;
irtmodelWHX1614:
	local[16]= NIL;
irtmodelBLK1615:
	w = NIL;
	local[14]= w;
	goto irtmodelIF1612;
irtmodelIF1611:
	local[14]= NIL;
irtmodelIF1612:
	local[14]= local[12];
	ctx->vsp=local+15;
	w=(pointer)ADD1(ctx,1,local+14); /*1+*/
	local[12] = w;
	goto irtmodelWHL1608;
irtmodelWHX1609:
	local[14]= NIL;
irtmodelBLK1610:
	w = NIL;
	local[12]= w;
	goto irtmodelIF1605;
irtmodelIF1604:
	local[12]= NIL;
irtmodelIF1605:
	goto irtmodelWHL1579;
irtmodelWHX1580:
	local[12]= NIL;
irtmodelBLK1581:
	w = NIL;
	w = local[9];
	local[0]= w;
irtmodelBLK1570:
	ctx->vsp=local; return(local[0]);}

/*:collision-avoidance-calc-distance*/
static pointer irtmodelM1616cascaded_link_collision_avoidance_calc_distance(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST1618:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[251], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1619;
	local[1] = NIL;
irtmodelKEY1619:
	if (n & (1<<1)) goto irtmodelKEY1620;
	local[2] = T;
irtmodelKEY1620:
	if (n & (1<<2)) goto irtmodelKEY1621;
	local[3] = NIL;
irtmodelKEY1621:
	if (n & (1<<3)) goto irtmodelKEY1622;
	local[4] = makeint((eusinteger_t)10L);
irtmodelKEY1622:
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	local[6]= argv[0];
	local[7]= fqv[184];
	local[8]= fqv[252];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	local[7]= NIL;
	local[8]= NIL;
	if (local[1]==NIL) goto irtmodelOR1625;
	local[9]= local[5];
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)NUMEQUAL(ctx,2,local+9); /*=*/
	if (w!=NIL) goto irtmodelOR1625;
	goto irtmodelIF1623;
irtmodelOR1625:
	w = NIL;
	ctx->vsp=local+9;
	local[0]=w;
	goto irtmodelBLK1617;
	goto irtmodelIF1624;
irtmodelIF1623:
	local[9]= NIL;
irtmodelIF1624:
	if (local[6]==NIL) goto irtmodelOR1628;
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(*ftab[24])(ctx,2,local+9,&ftab[24],fqv[171]); /*/=*/
	if (w!=NIL) goto irtmodelOR1628;
	goto irtmodelIF1626;
irtmodelOR1628:
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(*ftab[31])(ctx,1,local+9,&ftab[31],fqv[208]); /*make-list*/
	local[6] = w;
	local[9]= local[6];
	goto irtmodelIF1627;
irtmodelIF1626:
	local[9]= NIL;
irtmodelIF1627:
	local[9]= makeint((eusinteger_t)0L);
	local[10]= local[5];
irtmodelWHL1629:
	local[11]= local[9];
	w = local[10];
	if ((eusinteger_t)local[11] >= (eusinteger_t)w) goto irtmodelWHX1630;
	local[11]= local[3];
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[8] = w;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w = local[1];
	if (memq(local[11],w)!=NIL) goto irtmodelIF1632;
	local[11]= fqv[253];
	local[12]= local[8];
	local[13]= fqv[3];
	ctx->vsp=local+14;
	w=(*ftab[18])(ctx,2,local+12,&ftab[18],fqv[128]); /*send-all*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(*ftab[2])(ctx,2,local+11,&ftab[2],fqv[15]); /*warn*/
	local[11]= local[6];
	local[12]= local[9];
	local[13]= NIL;
	ctx->vsp=local+14;
	w=(pointer)SETELT(ctx,3,local+11); /*setelt*/
	local[11]= w;
	goto irtmodelIF1633;
irtmodelIF1632:
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= fqv[254];
	local[14]= makeint((eusinteger_t)2L);
	ctx->vsp=local+15;
	w=(*ftab[37])(ctx,4,local+11,&ftab[37],fqv[255]); /*collision-distance*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)0L);
	local[13]= makeint((eusinteger_t)0L);
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(pointer)MKFLTVEC(ctx,3,local+12); /*float-vector*/
	local[12]= w;
	local[13]= local[9];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,2,local+12); /*list*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)NCONC(ctx,2,local+11); /*nconc*/
	local[7] = w;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(pointer)LSEQP(ctx,2,local+11); /*<=*/
	if (w==NIL) goto irtmodelIF1634;
	if (local[2]==NIL) goto irtmodelIF1636;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+13;
	w=(pointer)LESSP(ctx,2,local+11); /*<*/
	if (w==NIL) goto irtmodelIF1636;
	local[11]= fqv[256];
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= fqv[3];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	local[14]= fqv[3];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	local[14]= local[7];
	ctx->vsp=local+15;
	w=(*ftab[2])(ctx,4,local+11,&ftab[2],fqv[15]); /*warn*/
	local[11]= w;
	goto irtmodelIF1637;
irtmodelIF1636:
	local[11]= NIL;
irtmodelIF1637:
	local[11]= local[7];
	local[12]= makeint((eusinteger_t)1L);
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	local[14]= fqv[257];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SETELT(ctx,3,local+11); /*setelt*/
	local[11]= local[6];
	local[12]= local[9];
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(pointer)SETELT(ctx,3,local+11); /*setelt*/
	local[11]= local[6];
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)0L);
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(pointer)SETELT(ctx,3,local+11); /*setelt*/
	local[11]= w;
	goto irtmodelIF1635;
irtmodelIF1634:
	local[11]= local[6];
	local[12]= local[9];
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(pointer)SETELT(ctx,3,local+11); /*setelt*/
	local[11]= w;
irtmodelIF1635:
	local[11]= makeflt(1.0000000000000000208167e-03);
	local[12]= local[7];
	local[13]= makeint((eusinteger_t)1L);
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= local[7];
	local[14]= makeint((eusinteger_t)2L);
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	local[14]= local[7];
	local[15]= makeint((eusinteger_t)3L);
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)VMINUS(ctx,3,local+12); /*v-*/
	local[12]= w;
	local[13]= local[7];
	local[14]= makeint((eusinteger_t)3L);
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(*ftab[4])(ctx,2,local+12,&ftab[4],fqv[26]); /*normalize-vector*/
	local[12]= w;
	local[13]= local[7];
	local[14]= makeint((eusinteger_t)3L);
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SCALEVEC(ctx,3,local+11); /*scale*/
	local[11]= w;
irtmodelIF1633:
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[9] = w;
	goto irtmodelWHL1629;
irtmodelWHX1630:
	local[11]= NIL;
irtmodelBLK1631:
	w = NIL;
	local[9]= local[6];
	local[10]= (pointer)get_sym_func(fqv[258]);
	ctx->vsp=local+11;
	local[11]= makeclosure(codevec,quotevec,irtmodelCLO1638,env,argv,local);
	ctx->vsp=local+12;
	w=(pointer)SORT(ctx,3,local+9); /*sort*/
	local[9]= argv[0];
	local[10]= fqv[150];
	local[11]= fqv[252];
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,4,local+9); /*send*/
	w = T;
	local[0]= w;
irtmodelBLK1617:
	ctx->vsp=local; return(local[0]);}

/*:collision-avoidance-args*/
static pointer irtmodelM1639cascaded_link_collision_avoidance_args(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[184];
	local[2]= fqv[259];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[260];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[211];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= NIL;
	local[4]= local[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)GREATERP(ctx,2,local+4); /*>*/
	if (w==NIL) goto irtmodelIF1641;
	local[4]= local[0];
	local[5]= local[2];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,1,local+5,&ftab[31],fqv[208]); /*make-list*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)NCONC(ctx,2,local+4); /*nconc*/
	local[0] = w;
	local[4]= local[0];
	goto irtmodelIF1642;
irtmodelIF1641:
	local[4]= NIL;
irtmodelIF1642:
	local[4]= local[0];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)SUB1(ctx,1,local+5); /*1-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[3] = w;
	if (local[3]!=NIL) goto irtmodelIF1643;
	local[4]= local[2];
	local[5]= makeint((eusinteger_t)3L);
	local[6]= local[4];
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(*ftab[23])(ctx,2,local+6,&ftab[23],fqv[166]); /*make-matrix*/
	local[6]= w;
	local[7]= local[4];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(*ftab[23])(ctx,2,local+7,&ftab[23],fqv[166]); /*make-matrix*/
	local[7]= w;
	local[8]= local[4];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(*ftab[23])(ctx,2,local+8,&ftab[23],fqv[166]); /*make-matrix*/
	local[8]= w;
	local[9]= local[5];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(*ftab[23])(ctx,2,local+9,&ftab[23],fqv[166]); /*make-matrix*/
	local[9]= w;
	local[10]= local[5];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(*ftab[23])(ctx,2,local+10,&ftab[23],fqv[166]); /*make-matrix*/
	local[10]= w;
	local[11]= local[4];
	local[12]= local[5];
	ctx->vsp=local+13;
	w=(*ftab[23])(ctx,2,local+11,&ftab[23],fqv[166]); /*make-matrix*/
	local[11]= w;
	local[12]= local[4];
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(*ftab[23])(ctx,2,local+12,&ftab[23],fqv[166]); /*make-matrix*/
	local[12]= w;
	local[13]= local[4];
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(*ftab[23])(ctx,2,local+13,&ftab[23],fqv[166]); /*make-matrix*/
	local[13]= w;
	local[14]= local[5];
	local[15]= local[4];
	ctx->vsp=local+16;
	w=(*ftab[23])(ctx,2,local+14,&ftab[23],fqv[166]); /*make-matrix*/
	local[14]= w;
	local[15]= local[5];
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(*ftab[23])(ctx,2,local+15,&ftab[23],fqv[166]); /*make-matrix*/
	local[15]= w;
	local[16]= local[5];
	local[17]= local[5];
	ctx->vsp=local+18;
	w=(*ftab[23])(ctx,2,local+16,&ftab[23],fqv[166]); /*make-matrix*/
	local[16]= w;
	local[17]= local[5];
	local[18]= local[4];
	ctx->vsp=local+19;
	w=(*ftab[23])(ctx,2,local+17,&ftab[23],fqv[166]); /*make-matrix*/
	local[17]= w;
	local[18]= loadglobal(fqv[5]);
	local[19]= makeint((eusinteger_t)0L);
	ctx->vsp=local+20;
	w=(pointer)INSTANTIATE(ctx,2,local+18); /*instantiate*/
	local[18]= w;
	local[19]= loadglobal(fqv[5]);
	local[20]= makeint((eusinteger_t)1L);
	ctx->vsp=local+21;
	w=(pointer)INSTANTIATE(ctx,2,local+19); /*instantiate*/
	local[19]= w;
	local[20]= loadglobal(fqv[5]);
	local[21]= makeint((eusinteger_t)2L);
	ctx->vsp=local+22;
	w=(pointer)INSTANTIATE(ctx,2,local+20); /*instantiate*/
	local[20]= w;
	local[21]= loadglobal(fqv[5]);
	local[22]= makeint((eusinteger_t)3L);
	ctx->vsp=local+23;
	w=(pointer)INSTANTIATE(ctx,2,local+21); /*instantiate*/
	local[21]= w;
	local[22]= loadglobal(fqv[5]);
	local[23]= makeint((eusinteger_t)3L);
	ctx->vsp=local+24;
	w=(pointer)INSTANTIATE(ctx,2,local+22); /*instantiate*/
	local[22]= w;
	local[23]= loadglobal(fqv[5]);
	local[24]= makeint((eusinteger_t)3L);
	ctx->vsp=local+25;
	w=(pointer)INSTANTIATE(ctx,2,local+23); /*instantiate*/
	local[23]= w;
	local[24]= loadglobal(fqv[5]);
	local[25]= makeint((eusinteger_t)3L);
	ctx->vsp=local+26;
	w=(pointer)INSTANTIATE(ctx,2,local+24); /*instantiate*/
	local[24]= w;
	local[25]= makeint((eusinteger_t)3L);
	local[26]= makeint((eusinteger_t)3L);
	ctx->vsp=local+27;
	w=(*ftab[23])(ctx,2,local+25,&ftab[23],fqv[166]); /*make-matrix*/
	local[25]= w;
	local[26]= loadglobal(fqv[5]);
	local[27]= local[5];
	ctx->vsp=local+28;
	w=(pointer)INSTANTIATE(ctx,2,local+26); /*instantiate*/
	local[26]= w;
	local[27]= loadglobal(fqv[5]);
	local[28]= local[4];
	ctx->vsp=local+29;
	w=(pointer)INSTANTIATE(ctx,2,local+27); /*instantiate*/
	local[27]= w;
	local[28]= loadglobal(fqv[5]);
	local[29]= local[4];
	ctx->vsp=local+30;
	w=(pointer)INSTANTIATE(ctx,2,local+28); /*instantiate*/
	local[28]= w;
	local[29]= loadglobal(fqv[5]);
	local[30]= makeint((eusinteger_t)3L);
	ctx->vsp=local+31;
	w=(pointer)INSTANTIATE(ctx,2,local+29); /*instantiate*/
	local[29]= w;
	local[30]= loadglobal(fqv[5]);
	local[31]= makeint((eusinteger_t)3L);
	ctx->vsp=local+32;
	w=(pointer)INSTANTIATE(ctx,2,local+30); /*instantiate*/
	local[30]= w;
	local[31]= fqv[261];
	local[32]= local[6];
	local[33]= fqv[262];
	local[34]= local[7];
	local[35]= fqv[263];
	local[36]= local[8];
	local[37]= fqv[264];
	local[38]= local[9];
	local[39]= fqv[265];
	local[40]= local[10];
	local[41]= fqv[266];
	local[42]= local[11];
	local[43]= fqv[267];
	local[44]= local[12];
	local[45]= fqv[268];
	local[46]= local[13];
	local[47]= fqv[269];
	local[48]= local[14];
	local[49]= fqv[270];
	local[50]= local[15];
	local[51]= fqv[271];
	local[52]= local[16];
	local[53]= fqv[272];
	local[54]= local[17];
	local[55]= fqv[273];
	local[56]= NIL;
	local[57]= fqv[274];
	local[58]= local[18];
	local[59]= fqv[275];
	local[60]= local[19];
	local[61]= fqv[276];
	local[62]= local[20];
	local[63]= fqv[277];
	local[64]= local[21];
	local[65]= fqv[278];
	local[66]= local[22];
	local[67]= fqv[279];
	local[68]= local[23];
	local[69]= fqv[280];
	local[70]= local[24];
	local[71]= fqv[281];
	local[72]= local[25];
	local[73]= fqv[282];
	local[74]= local[26];
	local[75]= fqv[283];
	local[76]= local[27];
	local[77]= fqv[284];
	local[78]= local[28];
	local[79]= fqv[285];
	local[80]= local[29];
	local[81]= fqv[286];
	local[82]= local[30];
	ctx->vsp=local+83;
	w=(pointer)LIST(ctx,52,local+31); /*list*/
	local[3] = w;
	local[31]= local[0];
	local[32]= local[2];
	ctx->vsp=local+33;
	w=(pointer)SUB1(ctx,1,local+32); /*1-*/
	local[32]= w;
	local[33]= local[3];
	ctx->vsp=local+34;
	w=(pointer)SETELT(ctx,3,local+31); /*setelt*/
	local[31]= argv[0];
	local[32]= fqv[150];
	local[33]= fqv[259];
	local[34]= local[0];
	ctx->vsp=local+35;
	w=(pointer)SEND(ctx,4,local+31); /*send*/
	local[4]= w;
	goto irtmodelIF1644;
irtmodelIF1643:
	local[4]= NIL;
irtmodelIF1644:
	w = local[3];
	local[0]= w;
irtmodelBLK1640:
	ctx->vsp=local; return(local[0]);}

/*:collision-avoidance*/
static pointer irtmodelM1645cascaded_link_collision_avoidance(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST1647:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[287], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1648;
	local[1] = NIL;
irtmodelKEY1648:
	if (n & (1<<1)) goto irtmodelKEY1649;
	local[2] = NIL;
irtmodelKEY1649:
	if (n & (1<<2)) goto irtmodelKEY1650;
	local[3] = NIL;
irtmodelKEY1650:
	if (n & (1<<3)) goto irtmodelKEY1651;
	local[4] = NIL;
irtmodelKEY1651:
	if (n & (1<<4)) goto irtmodelKEY1652;
	local[5] = NIL;
irtmodelKEY1652:
	if (n & (1<<5)) goto irtmodelKEY1653;
	local[6] = NIL;
irtmodelKEY1653:
	if (n & (1<<6)) goto irtmodelKEY1654;
	local[7] = NIL;
irtmodelKEY1654:
	if (n & (1<<7)) goto irtmodelKEY1655;
	local[10]= argv[0];
	local[11]= fqv[211];
	local[12]= local[5];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[8] = w;
irtmodelKEY1655:
	if (n & (1<<8)) goto irtmodelKEY1656;
	local[9] = NIL;
irtmodelKEY1656:
	local[10]= (pointer)get_sym_func(fqv[288]);
	local[11]= argv[0];
	local[12]= fqv[289];
	local[13]= local[0];
	ctx->vsp=local+14;
	w=(pointer)APPLY(ctx,4,local+10); /*apply*/
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)LENGTH(ctx,1,local+10); /*length*/
	local[10]= w;
	local[11]= makeint((eusinteger_t)0L);
	local[12]= loadglobal(fqv[5]);
	local[13]= local[8];
	ctx->vsp=local+14;
	w=(pointer)INSTANTIATE(ctx,2,local+12); /*instantiate*/
	local[12]= w;
	local[13]= argv[0];
	local[14]= fqv[150];
	local[15]= fqv[290];
	local[16]= local[4];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,4,local+13); /*send*/
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!!iscons(w)) goto irtmodelIF1657;
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	local[6] = w;
	local[13]= local[6];
	goto irtmodelIF1658;
irtmodelIF1657:
	local[13]= NIL;
irtmodelIF1658:
irtmodelWHL1659:
	local[13]= local[11];
	local[14]= local[10];
	ctx->vsp=local+15;
	w=(pointer)LESSP(ctx,2,local+13); /*<*/
	if (w==NIL) goto irtmodelWHX1660;
	local[13]= argv[0];
	local[14]= fqv[184];
	local[15]= fqv[252];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= w;
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	local[14]= local[4];
	local[15]= local[13];
	ctx->vsp=local+16;
	w=(*ftab[38])(ctx,1,local+15,&ftab[38],fqv[291]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[14]= w;
	local[15]= local[11];
	ctx->vsp=local+16;
	w=(pointer)ADD1(ctx,1,local+15); /*1+*/
	local[11] = w;
	if (local[9]==NIL) goto irtmodelIF1662;
	local[15]= fqv[202];
	w = local[9];
	if (memq(local[15],w)!=NIL) goto irtmodelIF1662;
	local[15]= local[13];
	local[16]= makeint((eusinteger_t)1L);
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	local[16]= local[13];
	local[17]= makeint((eusinteger_t)2L);
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)VMINUS(ctx,2,local+15); /*v-*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(*ftab[4])(ctx,1,local+15,&ftab[4],fqv[26]); /*normalize-vector*/
	local[15]= w;
	local[16]= fqv[292];
	local[17]= local[13];
	local[18]= makeint((eusinteger_t)0L);
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	local[18]= local[1];
	ctx->vsp=local+19;
	w=(*ftab[2])(ctx,3,local+16,&ftab[2],fqv[15]); /*warn*/
	local[16]= makeint((eusinteger_t)0L);
	local[17]= makeint((eusinteger_t)3L);
irtmodelWHL1664:
	local[18]= local[16];
	w = local[17];
	if ((eusinteger_t)local[18] >= (eusinteger_t)w) goto irtmodelWHX1665;
	local[18]= fqv[293];
	local[19]= local[15];
	local[20]= local[16];
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(*ftab[2])(ctx,2,local+18,&ftab[2],fqv[15]); /*warn*/
	local[18]= local[16];
	ctx->vsp=local+19;
	w=(pointer)ADD1(ctx,1,local+18); /*1+*/
	local[16] = w;
	goto irtmodelWHL1664;
irtmodelWHX1665:
	local[18]= NIL;
irtmodelBLK1666:
	w = NIL;
	local[16]= fqv[294];
	local[17]= local[14];
	local[18]= fqv[3];
	ctx->vsp=local+19;
	w=(*ftab[18])(ctx,2,local+17,&ftab[18],fqv[128]); /*send-all*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(*ftab[2])(ctx,2,local+16,&ftab[2],fqv[15]); /*warn*/
	local[15]= w;
	goto irtmodelIF1663;
irtmodelIF1662:
	local[15]= NIL;
irtmodelIF1663:
	local[15]= local[13];
	local[16]= makeint((eusinteger_t)0L);
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	local[16]= local[1];
	ctx->vsp=local+17;
	w=(pointer)GREQP(ctx,2,local+15); /*>=*/
	if (w!=NIL) goto irtmodelIF1667;
	ctx->vsp=local+15;
	local[15]= makeclosure(codevec,quotevec,irtmodelCLO1669,env,argv,local);
	local[16]= local[6];
	ctx->vsp=local+17;
	w=(*ftab[39])(ctx,2,local+15,&ftab[39],fqv[295]); /*find-if*/
	local[15]= w;
	local[16]= argv[0];
	local[17]= fqv[296];
	local[18]= local[14];
	local[19]= local[15];
	ctx->vsp=local+20;
	w=(pointer)SEND(ctx,4,local+16); /*send*/
	local[16]= w;
	local[17]= fqv[105];
	local[18]= local[13];
	local[19]= makeint((eusinteger_t)1L);
	ctx->vsp=local+20;
	w=(pointer)ELT(ctx,2,local+18); /*elt*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[40])(ctx,2,local+17,&ftab[40],fqv[297]); /*make-cascoords*/
	local[17]= w;
	local[18]= argv[0];
	local[19]= fqv[260];
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.car;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21]= (w)->c.cons.car;
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,4,local+18); /*send*/
	local[18]= w;
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[19]= (w)->c.cons.car;
	local[20]= fqv[298];
	local[21]= local[17];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,3,local+19); /*send*/
	local[19]= (pointer)get_sym_func(fqv[288]);
	local[20]= argv[0];
	local[21]= fqv[299];
	local[22]= local[18];
	local[23]= fqv[300];
	local[24]= local[17];
	local[25]= local[16];
	ctx->vsp=local+26;
	w=(pointer)APPLY(ctx,7,local+19); /*apply*/
	local[19]= w;
	local[20]= local[19];
	ctx->vsp=local+21;
	w=(pointer)TRANSPOSE(ctx,1,local+20); /*transpose*/
	local[20]= w;
	local[21]= local[13];
	local[22]= makeint((eusinteger_t)3L);
	ctx->vsp=local+23;
	w=(pointer)ELT(ctx,2,local+21); /*elt*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)TRANSFORM(ctx,2,local+20); /*transform*/
	local[20]= w;
	local[21]= local[1];
	local[22]= local[13];
	local[23]= makeint((eusinteger_t)0L);
	ctx->vsp=local+24;
	w=(pointer)ELT(ctx,2,local+22); /*elt*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)QUOTIENT(ctx,2,local+21); /*/*/
	local[21]= w;
	local[22]= makeint((eusinteger_t)1L);
	ctx->vsp=local+23;
	w=(pointer)MINUS(ctx,2,local+21); /*-*/
	local[21]= w;
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22]= (w)->c.cons.car;
	local[23]= fqv[301];
	local[24]= local[17];
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,3,local+22); /*send*/
	local[22]= NIL;
	local[23]= local[18];
irtmodelWHL1670:
	if (local[23]==NIL) goto irtmodelWHX1671;
	w=local[23];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[24]= (w)->c.cons.car;
	w=local[23];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[23] = (w)->c.cons.cdr;
	w = local[24];
	local[22] = w;
	ctx->vsp=local+24;
	local[24]= makeclosure(codevec,quotevec,irtmodelFLET1673,env,argv,local);
	local[25]= local[22];
	local[26]= local[5];
	w = local[24];
	ctx->vsp=local+27;
	w=irtmodelFLET1673(ctx,2,local+25,w);
	local[25]= w;
	local[26]= local[22];
	local[27]= local[18];
	w = local[24];
	ctx->vsp=local+28;
	w=irtmodelFLET1673(ctx,2,local+26,w);
	local[26]= w;
	local[27]= makeint((eusinteger_t)0L);
	local[28]= local[22];
	local[29]= fqv[198];
	ctx->vsp=local+30;
	w=(pointer)SEND(ctx,2,local+28); /*send*/
	local[28]= w;
	ctx->vsp=local+29;
	w=(pointer)LIST(ctx,1,local+28); /*list*/
	local[28]= w;
	ctx->vsp=local+29;
	w=(pointer)irtmodelF736calc_target_joint_dimension(ctx,1,local+28); /*calc-target-joint-dimension*/
	local[28]= w;
irtmodelWHL1674:
	local[29]= local[27];
	w = local[28];
	if ((eusinteger_t)local[29] >= (eusinteger_t)w) goto irtmodelWHX1675;
	local[29]= local[12];
	local[30]= local[27];
	local[31]= local[25];
	ctx->vsp=local+32;
	w=(pointer)PLUS(ctx,2,local+30); /*+*/
	local[30]= w;
	local[31]= local[12];
	local[32]= local[27];
	local[33]= local[25];
	ctx->vsp=local+34;
	w=(pointer)PLUS(ctx,2,local+32); /*+*/
	local[32]= w;
	ctx->vsp=local+33;
	w=(pointer)ELT(ctx,2,local+31); /*elt*/
	local[31]= w;
	local[32]= local[21];
	local[33]= local[20];
	local[34]= local[26];
	local[35]= local[27];
	ctx->vsp=local+36;
	w=(pointer)PLUS(ctx,2,local+34); /*+*/
	local[34]= w;
	ctx->vsp=local+35;
	w=(pointer)ELT(ctx,2,local+33); /*elt*/
	local[33]= w;
	ctx->vsp=local+34;
	w=(pointer)TIMES(ctx,2,local+32); /***/
	local[32]= w;
	ctx->vsp=local+33;
	w=(pointer)PLUS(ctx,2,local+31); /*+*/
	local[31]= w;
	ctx->vsp=local+32;
	w=(pointer)SETELT(ctx,3,local+29); /*setelt*/
	local[29]= local[27];
	ctx->vsp=local+30;
	w=(pointer)ADD1(ctx,1,local+29); /*1+*/
	local[27] = w;
	goto irtmodelWHL1674;
irtmodelWHX1675:
	local[29]= NIL;
irtmodelBLK1676:
	w = NIL;
	goto irtmodelWHL1670;
irtmodelWHX1671:
	local[24]= NIL;
irtmodelBLK1672:
	w = NIL;
	local[15]= w;
	goto irtmodelIF1668;
irtmodelIF1667:
	local[15]= NIL;
irtmodelIF1668:
	w = local[15];
	goto irtmodelWHL1659;
irtmodelWHX1660:
	local[13]= NIL;
irtmodelBLK1661:
	local[13]= makeint((eusinteger_t)0L);
	local[14]= local[8];
irtmodelWHL1677:
	local[15]= local[13];
	w = local[14];
	if ((eusinteger_t)local[15] >= (eusinteger_t)w) goto irtmodelWHX1678;
	local[15]= local[12];
	local[16]= local[13];
	local[17]= local[12];
	local[18]= local[13];
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	local[18]= local[7];
	local[19]= local[13];
	ctx->vsp=local+20;
	w=(pointer)ELT(ctx,2,local+18); /*elt*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)TIMES(ctx,2,local+17); /***/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)SETELT(ctx,3,local+15); /*setelt*/
	local[15]= local[13];
	ctx->vsp=local+16;
	w=(pointer)ADD1(ctx,1,local+15); /*1+*/
	local[13] = w;
	goto irtmodelWHL1677;
irtmodelWHX1678:
	local[15]= NIL;
irtmodelBLK1679:
	w = NIL;
	local[13]= argv[0];
	local[14]= fqv[150];
	local[15]= fqv[302];
	local[16]= local[3];
	local[17]= local[12];
	ctx->vsp=local+18;
	w=(pointer)SCALEVEC(ctx,2,local+16); /*scale*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,4,local+13); /*send*/
	local[13]= argv[0];
	local[14]= fqv[150];
	local[15]= fqv[303];
	local[16]= local[2];
	local[17]= local[12];
	ctx->vsp=local+18;
	w=(pointer)SCALEVEC(ctx,2,local+16); /*scale*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,4,local+13); /*send*/
	if (local[9]==NIL) goto irtmodelIF1680;
	local[13]= fqv[202];
	w = local[9];
	if (memq(local[13],w)!=NIL) goto irtmodelIF1680;
	local[13]= loadglobal(fqv[5]);
	local[14]= (pointer)get_sym_func(fqv[49]);
	local[15]= argv[0];
	local[16]= fqv[184];
	local[17]= fqv[303];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)MAP(ctx,3,local+13); /*map*/
	local[13]= w;
	local[14]= fqv[304];
	ctx->vsp=local+15;
	w=(*ftab[33])(ctx,2,local+13,&ftab[33],fqv[233]); /*format-array*/
	local[13]= loadglobal(fqv[5]);
	local[14]= (pointer)get_sym_func(fqv[49]);
	local[15]= argv[0];
	local[16]= fqv[184];
	local[17]= fqv[302];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)MAP(ctx,3,local+13); /*map*/
	local[13]= w;
	local[14]= fqv[305];
	ctx->vsp=local+15;
	w=(*ftab[33])(ctx,2,local+13,&ftab[33],fqv[233]); /*format-array*/
	local[13]= w;
	goto irtmodelIF1681;
irtmodelIF1680:
	local[13]= NIL;
irtmodelIF1681:
	w = local[13];
	local[10]= argv[0];
	local[11]= fqv[184];
	local[12]= fqv[303];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[0]= w;
irtmodelBLK1646:
	ctx->vsp=local; return(local[0]);}

/*:move-joints*/
static pointer irtmodelM1682cascaded_link_move_joints(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtmodelRST1684:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[306], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1685;
	local[1] = NIL;
irtmodelKEY1685:
	if (n & (1<<1)) goto irtmodelKEY1686;
	local[2] = makeflt(4.9999999999999988897770e-02);
irtmodelKEY1686:
	if (n & (1<<2)) goto irtmodelKEY1687;
	local[3] = NIL;
irtmodelKEY1687:
	if (n & (1<<3)) goto irtmodelKEY1688;
	local[4] = NIL;
irtmodelKEY1688:
	if (n & (1<<4)) goto irtmodelKEY1689;
	local[5] = NIL;
irtmodelKEY1689:
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	if (local[4]==NIL) goto irtmodelIF1690;
	w = local[4];
	if (!!iscons(w)) goto irtmodelIF1690;
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	local[4] = w;
	local[9]= local[4];
	goto irtmodelIF1691;
irtmodelIF1690:
	local[9]= NIL;
irtmodelIF1691:
	local[9]= (pointer)get_sym_func(fqv[288]);
	local[10]= argv[0];
	local[11]= fqv[307];
	local[12]= argv[2];
	local[13]= local[0];
	ctx->vsp=local+14;
	w=(pointer)APPLY(ctx,5,local+9); /*apply*/
	local[6] = w;
	local[9]= argv[0];
	local[10]= fqv[308];
	local[11]= local[1];
	local[12]= local[6];
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,5,local+9); /*send*/
	local[9]= w;
	local[10]= makeflt(1.0000000000000000000000e+00);
	local[11]= makeint((eusinteger_t)0L);
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)LENGTH(ctx,1,local+12); /*length*/
	local[12]= w;
irtmodelWHL1692:
	local[13]= local[11];
	w = local[12];
	if ((eusinteger_t)local[13] >= (eusinteger_t)w) goto irtmodelWHX1693;
	local[13]= local[9];
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	local[14]= local[10];
	ctx->vsp=local+15;
	w=(pointer)LESSP(ctx,2,local+13); /*<*/
	if (w==NIL) goto irtmodelIF1695;
	local[13]= local[9];
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[10] = w;
	local[13]= local[10];
	goto irtmodelIF1696;
irtmodelIF1695:
	local[13]= NIL;
irtmodelIF1696:
	local[13]= local[11];
	ctx->vsp=local+14;
	w=(pointer)ADD1(ctx,1,local+13); /*1+*/
	local[11] = w;
	goto irtmodelWHL1692;
irtmodelWHX1693:
	local[13]= NIL;
irtmodelBLK1694:
	w = NIL;
	local[11]= local[10];
	local[12]= local[6];
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(pointer)SCALEVEC(ctx,3,local+11); /*scale*/
	local[6] = w;
	w = local[6];
	if (local[4]==NIL) goto irtmodelIF1697;
	local[9]= fqv[202];
	w = local[4];
	if (memq(local[9],w)!=NIL) goto irtmodelIF1697;
	local[9]= loadglobal(fqv[5]);
	local[10]= (pointer)get_sym_func(fqv[49]);
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)MAP(ctx,3,local+9); /*map*/
	local[9]= w;
	local[10]= fqv[309];
	ctx->vsp=local+11;
	w=(*ftab[33])(ctx,2,local+9,&ftab[33],fqv[233]); /*format-array*/
	local[9]= w;
	goto irtmodelIF1698;
irtmodelIF1697:
	local[9]= NIL;
irtmodelIF1698:
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
irtmodelTAG1700:
	local[11]= local[10];
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(pointer)LENGTH(ctx,1,local+12); /*length*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)GREQP(ctx,2,local+11); /*>=*/
	if (w==NIL) goto irtmodelIF1701;
	w = NIL;
	ctx->vsp=local+11;
	local[9]=w;
	goto irtmodelBLK1699;
	goto irtmodelIF1702;
irtmodelIF1701:
	local[11]= NIL;
irtmodelIF1702:
	local[11]= local[1];
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= fqv[198];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[8] = w;
	local[11]= local[8];
	local[12]= fqv[31];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	local[12]= local[11];
	if (fqv[310]!=local[12]) goto irtmodelIF1703;
	local[12]= local[8];
	local[13]= fqv[311];
	local[14]= local[6];
	local[15]= local[9];
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[7] = w;
	local[12]= local[7];
	goto irtmodelIF1704;
irtmodelIF1703:
	if (T==NIL) goto irtmodelIF1705;
	local[12]= local[8];
	local[13]= fqv[311];
	local[14]= local[6];
	local[15]= local[9];
	local[16]= local[9];
	local[17]= local[8];
	local[18]= fqv[31];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,2,local+17); /*send*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)PLUS(ctx,2,local+16); /*+*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)SUBSEQ(ctx,3,local+14); /*subseq*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[7] = w;
	local[12]= local[7];
	goto irtmodelIF1706;
irtmodelIF1705:
	local[12]= NIL;
irtmodelIF1706:
irtmodelIF1704:
	w = local[12];
	local[11]= (pointer)get_sym_func(fqv[288]);
	local[12]= local[1];
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= fqv[198];
	local[14]= fqv[20];
	local[15]= local[7];
	local[16]= fqv[312];
	local[17]= T;
	local[18]= local[3];
	ctx->vsp=local+19;
	w=(pointer)APPLY(ctx,8,local+11); /*apply*/
	local[11]= local[9];
	local[12]= local[8];
	local[13]= fqv[31];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	local[11]= w;
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)ADD1(ctx,1,local+12); /*1+*/
	local[12]= w;
	local[9] = local[11];
	local[10] = local[12];
	w = NIL;
	ctx->vsp=local+11;
	goto irtmodelTAG1700;
	w = NIL;
	local[9]= w;
irtmodelBLK1699:
	if (local[5]==NIL) goto irtmodelIF1707;
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)FUNCALL(ctx,1,local+9); /*funcall*/
	local[9]= w;
	goto irtmodelIF1708;
irtmodelIF1707:
	local[9]= NIL;
irtmodelIF1708:
	w = T;
	local[0]= w;
irtmodelBLK1683:
	ctx->vsp=local; return(local[0]);}

/*:find-joint-angle-limit-weight-old-from-union-link-list*/
static pointer irtmodelM1709cascaded_link_find_joint_angle_limit_weight_old_from_union_link_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= fqv[3];
	ctx->vsp=local+2;
	w=(*ftab[18])(ctx,2,local+0,&ftab[18],fqv[128]); /*send-all*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[313];
	ctx->vsp=local+3;
	w=(pointer)GETPROP(ctx,2,local+1); /*get*/
	local[1]= w;
	local[2]= fqv[139];
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,irtmodelCLO1711,env,argv,local);
	ctx->vsp=local+4;
	w=(*ftab[41])(ctx,4,local+0,&ftab[41],fqv[314]); /*assoc*/
	local[0]= w;
irtmodelBLK1710:
	ctx->vsp=local; return(local[0]);}

/*:reset-joint-angle-limit-weight-old*/
static pointer irtmodelM1712cascaded_link_reset_joint_angle_limit_weight_old(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[315];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	if (local[0]==NIL) goto irtmodelIF1714;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	local[2]= NIL;
	ctx->vsp=local+3;
	w=(pointer)RPLACA2(ctx,2,local+1); /*rplaca2*/
	local[1]= w;
	goto irtmodelIF1715;
irtmodelIF1714:
	local[1]= NIL;
irtmodelIF1715:
	w = local[1];
	local[0]= w;
irtmodelBLK1713:
	ctx->vsp=local; return(local[0]);}

/*:calc-weight-from-joint-limit*/
static pointer irtmodelM1716cascaded_link_calc_weight_from_joint_limit(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=10) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[0];
	local[3]= fqv[315];
	local[4]= argv[5];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	if (local[2]!=NIL) goto irtmodelIF1718;
	local[3]= argv[0];
	local[4]= fqv[150];
	local[5]= fqv[313];
	local[6]= argv[5];
	local[7]= fqv[3];
	ctx->vsp=local+8;
	w=(*ftab[18])(ctx,2,local+6,&ftab[18],fqv[128]); /*send-all*/
	local[6]= w;
	local[7]= NIL;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,2,local+6); /*list*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= fqv[313];
	ctx->vsp=local+9;
	w=(pointer)GETPROP(ctx,2,local+7); /*get*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= argv[0];
	local[4]= fqv[315];
	local[5]= argv[5];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[2] = w;
	local[3]= local[2];
	goto irtmodelIF1719;
irtmodelIF1718:
	local[3]= NIL;
irtmodelIF1719:
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car!=NIL) goto irtmodelIF1720;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	local[4]= loadglobal(fqv[5]);
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)INSTANTIATE(ctx,2,local+4); /*instantiate*/
	local[4]= w;
	local[5]= makeflt(1.0000000000000000000000e+20);
	ctx->vsp=local+6;
	w=(*ftab[36])(ctx,2,local+4,&ftab[36],fqv[242]); /*fill*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)RPLACA2(ctx,2,local+3); /*rplaca2*/
	local[3]= w;
	goto irtmodelIF1721;
irtmodelIF1720:
	local[3]= NIL;
irtmodelIF1721:
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.car;
	w = local[0];
	local[2]= argv[2];
	local[3]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+4;
	w=(pointer)GREATERP(ctx,2,local+2); /*>*/
	if (w==NIL) goto irtmodelIF1722;
	local[2]= argv[2];
	local[3]= argv[5];
	local[4]= fqv[198];
	ctx->vsp=local+5;
	w=(*ftab[18])(ctx,2,local+3,&ftab[18],fqv[128]); /*send-all*/
	local[3]= w;
	local[4]= argv[9];
	ctx->vsp=local+5;
	w=(pointer)irtmodelF738joint_angle_limit_weight(ctx,2,local+3); /*joint-angle-limit-weight*/
	local[3]= w;
	local[4]= argv[9];
	ctx->vsp=local+5;
	w=(pointer)SCALEVEC(ctx,3,local+2); /*scale*/
	local[1] = w;
	if (argv[6]==NIL) goto irtmodelIF1724;
	local[2]= fqv[202];
	w = argv[6];
	if (memq(local[2],w)!=NIL) goto irtmodelIF1724;
	local[2]= local[0];
	local[3]= fqv[316];
	ctx->vsp=local+4;
	w=(*ftab[33])(ctx,2,local+2,&ftab[33],fqv[233]); /*format-array*/
	local[2]= local[1];
	local[3]= fqv[317];
	ctx->vsp=local+4;
	w=(*ftab[33])(ctx,2,local+2,&ftab[33],fqv[233]); /*format-array*/
	local[2]= w;
	goto irtmodelIF1725;
irtmodelIF1724:
	local[2]= NIL;
irtmodelIF1725:
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[3];
irtmodelWHL1726:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto irtmodelWHX1727;
	local[4]= argv[8];
	local[5]= local[2];
	local[6]= local[1];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= local[0];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	local[7]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+8;
	w=(pointer)GREQP(ctx,2,local+6); /*>=*/
	if (w==NIL) goto irtmodelIF1729;
	local[6]= makeflt(1.0000000000000000000000e+00);
	local[7]= makeflt(1.0000000000000000000000e+00);
	local[8]= local[1];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,2,local+7); /*+*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[6]= w;
	goto irtmodelIF1730;
irtmodelIF1729:
	local[6]= makeflt(1.0000000000000000000000e+00);
irtmodelIF1730:
	ctx->vsp=local+7;
	w=(pointer)SETELT(ctx,3,local+4); /*setelt*/
	local[4]= local[0];
	local[5]= local[2];
	local[6]= local[1];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SETELT(ctx,3,local+4); /*setelt*/
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto irtmodelWHL1726;
irtmodelWHX1727:
	local[4]= NIL;
irtmodelBLK1728:
	w = NIL;
	local[2]= w;
	goto irtmodelIF1723;
irtmodelIF1722:
	local[2]= NIL;
irtmodelIF1723:
	local[2]= argv[2];
	local[3]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+4;
	w=(pointer)NUMEQUAL(ctx,2,local+2); /*=*/
	if (w==NIL) goto irtmodelIF1731;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[3];
irtmodelWHL1733:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto irtmodelWHX1734;
	local[4]= argv[8];
	local[5]= local[2];
	local[6]= argv[7];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SETELT(ctx,3,local+4); /*setelt*/
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto irtmodelWHL1733;
irtmodelWHX1734:
	local[4]= NIL;
irtmodelBLK1735:
	w = NIL;
	local[2]= w;
	goto irtmodelIF1732;
irtmodelIF1731:
	local[2]= NIL;
irtmodelIF1732:
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	local[4]= argv[5];
irtmodelWHL1736:
	if (local[4]==NIL) goto irtmodelWHX1737;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtmodelCLO1739,env,argv,local);
	local[6]= argv[4];
	ctx->vsp=local+7;
	w=(*ftab[42])(ctx,2,local+5,&ftab[42],fqv[318]); /*count-if*/
	local[5]= w;
	local[6]= local[3];
	local[7]= fqv[198];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)irtmodelF736calc_target_joint_dimension(ctx,1,local+6); /*calc-target-joint-dimension*/
	local[6]= w;
	local[7]= local[5];
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)GREATERP(ctx,2,local+7); /*>*/
	if (w==NIL) goto irtmodelIF1740;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[6];
irtmodelWHL1742:
	local[9]= local[7];
	w = local[8];
	if ((eusinteger_t)local[9] >= (eusinteger_t)w) goto irtmodelWHX1743;
	local[9]= argv[8];
	local[10]= local[2];
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[10]= w;
	local[11]= argv[8];
	local[12]= local[2];
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(pointer)PLUS(ctx,2,local+12); /*+*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= local[5];
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SETELT(ctx,3,local+9); /*setelt*/
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[7] = w;
	goto irtmodelWHL1742;
irtmodelWHX1743:
	local[9]= NIL;
irtmodelBLK1744:
	w = NIL;
	local[7]= w;
	goto irtmodelIF1741;
irtmodelIF1740:
	local[7]= NIL;
irtmodelIF1741:
	local[7]= local[2];
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,2,local+7); /*+*/
	local[2] = w;
	w = local[2];
	goto irtmodelWHL1736;
irtmodelWHX1737:
	local[5]= NIL;
irtmodelBLK1738:
	w = NIL;
	w = argv[8];
	local[0]= w;
irtmodelBLK1717:
	ctx->vsp=local; return(local[0]);}

/*:calc-inverse-kinematics-weight-from-link-list*/
static pointer irtmodelM1745cascaded_link_calc_inverse_kinematics_weight_from_link_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[319], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY1747;
	local[0] = makeflt(1.0000000000000000000000e+00);
irtmodelKEY1747:
	if (n & (1<<1)) goto irtmodelKEY1748;
	local[8]= argv[0];
	local[9]= fqv[197];
	local[10]= argv[2];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[1] = w;
irtmodelKEY1748:
	if (n & (1<<2)) goto irtmodelKEY1749;
	local[8]= argv[0];
	local[9]= fqv[211];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[2] = w;
irtmodelKEY1749:
	if (n & (1<<3)) goto irtmodelKEY1750;
	local[8]= loadglobal(fqv[5]);
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,2,local+8); /*instantiate*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(*ftab[36])(ctx,2,local+8,&ftab[36],fqv[242]); /*fill*/
	local[3] = w;
irtmodelKEY1750:
	if (n & (1<<4)) goto irtmodelKEY1751;
	local[4] = NIL;
irtmodelKEY1751:
	if (n & (1<<5)) goto irtmodelKEY1752;
	local[5] = NIL;
irtmodelKEY1752:
	if (n & (1<<6)) goto irtmodelKEY1753;
	local[8]= loadglobal(fqv[5]);
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,2,local+8); /*instantiate*/
	local[6] = w;
irtmodelKEY1753:
	if (n & (1<<7)) goto irtmodelKEY1754;
	local[8]= loadglobal(fqv[5]);
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,2,local+8); /*instantiate*/
	local[7] = w;
irtmodelKEY1754:
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(*ftab[43])(ctx,1,local+8,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelCON1756;
	local[8]= local[3];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)FUNCALL(ctx,2,local+8); /*funcall*/
	local[3] = w;
	local[8]= local[3];
	goto irtmodelCON1755;
irtmodelCON1756:
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)LISTP(ctx,1,local+8); /*listp*/
	if (w==NIL) goto irtmodelCON1757;
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)EVAL(ctx,1,local+8); /*eval*/
	local[3] = w;
	local[8]= local[3];
	goto irtmodelCON1755;
irtmodelCON1757:
	local[8]= NIL;
irtmodelCON1755:
	if (local[5]==NIL) goto irtmodelIF1758;
	local[8]= fqv[202];
	w = local[5];
	if (memq(local[8],w)!=NIL) goto irtmodelIF1758;
	local[8]= local[3];
	local[9]= fqv[321];
	ctx->vsp=local+10;
	w=(*ftab[33])(ctx,2,local+8,&ftab[33],fqv[233]); /*format-array*/
	local[8]= w;
	goto irtmodelIF1759;
irtmodelIF1758:
	local[8]= NIL;
irtmodelIF1759:
	local[8]= NIL;
	local[9]= local[4];
irtmodelWHL1760:
	if (local[9]==NIL) goto irtmodelWHX1761;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= local[1];
	local[12]= fqv[139];
	local[13]= (pointer)get_sym_func(fqv[140]);
	ctx->vsp=local+14;
	w=(*ftab[32])(ctx,4,local+10,&ftab[32],fqv[212]); /*position*/
	local[10]= w;
	if (local[10]==NIL) goto irtmodelIF1763;
	local[11]= (pointer)get_sym_func(fqv[322]);
	local[12]= local[1];
	local[13]= makeint((eusinteger_t)0L);
	local[14]= local[10];
	ctx->vsp=local+15;
	w=(pointer)SUBSEQ(ctx,3,local+12); /*subseq*/
	local[12]= w;
	local[13]= fqv[198];
	ctx->vsp=local+14;
	w=(*ftab[18])(ctx,2,local+12,&ftab[18],fqv[128]); /*send-all*/
	local[12]= w;
	local[13]= fqv[31];
	ctx->vsp=local+14;
	w=(*ftab[18])(ctx,2,local+12,&ftab[18],fqv[128]); /*send-all*/
	local[12]= w;
	local[13]= fqv[323];
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(*ftab[26])(ctx,4,local+11,&ftab[26],fqv[196]); /*reduce*/
	local[11]= w;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	ctx->vsp=local+13;
	w=(*ftab[43])(ctx,1,local+12,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelIF1765;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	ctx->vsp=local+13;
	w=(pointer)FUNCALL(ctx,1,local+12); /*funcall*/
	local[12]= w;
	goto irtmodelIF1766;
irtmodelIF1765:
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
irtmodelIF1766:
	local[13]= makeint((eusinteger_t)0L);
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	local[15]= fqv[198];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= w;
	local[15]= fqv[31];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= w;
irtmodelWHL1767:
	local[15]= local[13];
	w = local[14];
	if ((eusinteger_t)local[15] >= (eusinteger_t)w) goto irtmodelWHX1768;
	local[15]= local[3];
	local[16]= local[13];
	local[17]= local[11];
	ctx->vsp=local+18;
	w=(pointer)PLUS(ctx,2,local+16); /*+*/
	local[16]= w;
	local[17]= local[3];
	local[18]= local[13];
	local[19]= local[11];
	ctx->vsp=local+20;
	w=(pointer)PLUS(ctx,2,local+18); /*+*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	local[18]= local[12];
	ctx->vsp=local+19;
	w=(*ftab[0])(ctx,1,local+18,&ftab[0],fqv[4]); /*float-vector-p*/
	if (w==NIL) goto irtmodelIF1770;
	local[18]= local[12];
	local[19]= local[13];
	ctx->vsp=local+20;
	w=(pointer)ELT(ctx,2,local+18); /*elt*/
	local[18]= w;
	goto irtmodelIF1771;
irtmodelIF1770:
	local[18]= local[12];
irtmodelIF1771:
	ctx->vsp=local+19;
	w=(pointer)TIMES(ctx,2,local+17); /***/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)SETELT(ctx,3,local+15); /*setelt*/
	local[15]= local[13];
	ctx->vsp=local+16;
	w=(pointer)ADD1(ctx,1,local+15); /*1+*/
	local[13] = w;
	goto irtmodelWHL1767;
irtmodelWHX1768:
	local[15]= NIL;
irtmodelBLK1769:
	w = NIL;
	local[11]= w;
	goto irtmodelIF1764;
irtmodelIF1763:
	local[11]= NIL;
irtmodelIF1764:
	w = local[11];
	goto irtmodelWHL1760;
irtmodelWHX1761:
	local[10]= NIL;
irtmodelBLK1762:
	w = NIL;
	if (local[5]==NIL) goto irtmodelIF1772;
	local[8]= fqv[202];
	w = local[5];
	if (memq(local[8],w)!=NIL) goto irtmodelIF1772;
	if (local[4]==NIL) goto irtmodelIF1772;
	local[8]= local[3];
	local[9]= fqv[324];
	ctx->vsp=local+10;
	w=(*ftab[33])(ctx,2,local+8,&ftab[33],fqv[233]); /*format-array*/
	local[8]= w;
	goto irtmodelIF1773;
irtmodelIF1772:
	local[8]= NIL;
irtmodelIF1773:
	local[8]= argv[0];
	local[9]= fqv[325];
	local[10]= local[0];
	local[11]= local[2];
	local[12]= argv[2];
	local[13]= local[1];
	local[14]= local[5];
	local[15]= local[3];
	local[16]= local[6];
	local[17]= local[7];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,10,local+8); /*send*/
	local[6] = w;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[2];
irtmodelWHL1774:
	local[10]= local[8];
	w = local[9];
	if ((eusinteger_t)local[10] >= (eusinteger_t)w) goto irtmodelWHX1775;
	local[10]= local[6];
	local[11]= local[8];
	local[12]= local[3];
	local[13]= local[8];
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= local[6];
	local[14]= local[8];
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)TIMES(ctx,2,local+12); /***/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)SETELT(ctx,3,local+10); /*setelt*/
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	goto irtmodelWHL1774;
irtmodelWHX1775:
	local[10]= NIL;
irtmodelBLK1776:
	w = NIL;
	if (local[5]==NIL) goto irtmodelIF1777;
	local[8]= fqv[202];
	w = local[5];
	if (memq(local[8],w)!=NIL) goto irtmodelIF1777;
	local[8]= local[6];
	local[9]= fqv[326];
	ctx->vsp=local+10;
	w=(*ftab[33])(ctx,2,local+8,&ftab[33],fqv[233]); /*format-array*/
	local[8]= w;
	goto irtmodelIF1778;
irtmodelIF1777:
	local[8]= NIL;
irtmodelIF1778:
	w = local[6];
	local[0]= w;
irtmodelBLK1746:
	ctx->vsp=local; return(local[0]);}

/*:calc-nspace-from-joint-limit*/
static pointer irtmodelM1779cascaded_link_calc_nspace_from_joint_limit(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=7) maerror();
	local[0]= argv[2];
	local[1]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w==NIL) goto irtmodelIF1781;
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= fqv[198];
	ctx->vsp=local+3;
	w=(*ftab[18])(ctx,2,local+1,&ftab[18],fqv[128]); /*send-all*/
	local[1]= w;
	local[2]= argv[6];
	ctx->vsp=local+3;
	w=(pointer)irtmodelF739joint_angle_limit_nspace(ctx,2,local+1); /*joint-angle-limit-nspace*/
	local[1]= w;
	local[2]= argv[6];
	ctx->vsp=local+3;
	w=(pointer)SCALEVEC(ctx,3,local+0); /*scale*/
	argv[6] = w;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[4];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
irtmodelWHL1783:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto irtmodelWHX1784;
	local[2]= argv[6];
	local[3]= local[0];
	local[4]= argv[6];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= argv[4];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SETELT(ctx,3,local+2); /*setelt*/
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto irtmodelWHL1783;
irtmodelWHX1784:
	local[2]= NIL;
irtmodelBLK1785:
	w = NIL;
	if (argv[5]==NIL) goto irtmodelIF1786;
	local[0]= fqv[202];
	w = argv[5];
	if (memq(local[0],w)!=NIL) goto irtmodelIF1786;
	local[0]= loadglobal(fqv[5]);
	local[1]= (pointer)get_sym_func(fqv[49]);
	local[2]= argv[6];
	ctx->vsp=local+3;
	w=(pointer)MAP(ctx,3,local+0); /*map*/
	local[0]= w;
	local[1]= fqv[327];
	ctx->vsp=local+2;
	w=(*ftab[33])(ctx,2,local+0,&ftab[33],fqv[233]); /*format-array*/
	local[0]= w;
	goto irtmodelIF1787;
irtmodelIF1786:
	local[0]= NIL;
irtmodelIF1787:
	goto irtmodelIF1782;
irtmodelIF1781:
	local[0]= NIL;
irtmodelIF1782:
	w = argv[6];
	local[0]= w;
irtmodelBLK1780:
	ctx->vsp=local; return(local[0]);}

/*:calc-inverse-kinematics-nspace-from-link-list*/
static pointer irtmodelM1788cascaded_link_calc_inverse_kinematics_nspace_from_link_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[328], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY1790;
	local[0] = makeflt(9.9999999999999950039964e-03);
irtmodelKEY1790:
	if (n & (1<<1)) goto irtmodelKEY1791;
	local[14]= argv[0];
	local[15]= fqv[197];
	local[16]= argv[2];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[1] = w;
irtmodelKEY1791:
	if (n & (1<<2)) goto irtmodelKEY1792;
	local[14]= argv[0];
	local[15]= fqv[211];
	local[16]= local[1];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[2] = w;
irtmodelKEY1792:
	if (n & (1<<3)) goto irtmodelKEY1793;
	local[3] = NIL;
irtmodelKEY1793:
	if (n & (1<<4)) goto irtmodelKEY1794;
	local[4] = NIL;
irtmodelKEY1794:
	if (n & (1<<5)) goto irtmodelKEY1795;
	local[5] = NIL;
irtmodelKEY1795:
	if (n & (1<<6)) goto irtmodelKEY1796;
	local[6] = makeflt(0.0000000000000000000000e+00);
irtmodelKEY1796:
	if (n & (1<<7)) goto irtmodelKEY1797;
	local[7] = NIL;
irtmodelKEY1797:
	if (n & (1<<8)) goto irtmodelKEY1798;
	local[8] = NIL;
irtmodelKEY1798:
	if (n & (1<<9)) goto irtmodelKEY1799;
	local[9] = fqv[33];
irtmodelKEY1799:
	if (n & (1<<10)) goto irtmodelKEY1800;
	local[10] = NIL;
irtmodelKEY1800:
	if (n & (1<<11)) goto irtmodelKEY1801;
	local[14]= loadglobal(fqv[5]);
	local[15]= local[2];
	ctx->vsp=local+16;
	w=(pointer)INSTANTIATE(ctx,2,local+14); /*instantiate*/
	local[14]= w;
	local[15]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+16;
	w=(*ftab[36])(ctx,2,local+14,&ftab[36],fqv[242]); /*fill*/
	local[11] = w;
irtmodelKEY1801:
	if (n & (1<<12)) goto irtmodelKEY1802;
	local[12] = T;
irtmodelKEY1802:
	if (n & (1<<13)) goto irtmodelKEY1803;
	local[14]= loadglobal(fqv[5]);
	local[15]= local[2];
	ctx->vsp=local+16;
	w=(pointer)INSTANTIATE(ctx,2,local+14); /*instantiate*/
	local[13] = w;
irtmodelKEY1803:
	local[14]= argv[0];
	local[15]= fqv[329];
	local[16]= local[0];
	local[17]= local[1];
	local[18]= local[11];
	local[19]= local[4];
	local[20]= local[13];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,7,local+14); /*send*/
	local[13] = w;
	if (local[10]==NIL) goto irtmodelIF1804;
	local[14]= local[6];
	local[15]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+16;
	w=(pointer)GREATERP(ctx,2,local+14); /*>*/
	if (w==NIL) goto irtmodelIF1806;
	if (local[7]==NIL) goto irtmodelIF1806;
	local[14]= argv[0];
	local[15]= fqv[330];
	local[16]= local[1];
	local[17]= fqv[273];
	local[18]= local[11];
	local[19]= fqv[331];
	local[20]= local[8];
	local[21]= fqv[332];
	local[22]= local[12];
	local[23]= fqv[333];
	local[24]= local[7];
	local[25]= fqv[334];
	local[26]= local[6];
	local[27]= fqv[335];
	local[28]= local[9];
	ctx->vsp=local+29;
	w=(pointer)SEND(ctx,15,local+14); /*send*/
	local[14]= w;
	local[15]= local[13];
	local[16]= local[13];
	ctx->vsp=local+17;
	w=(pointer)VPLUS(ctx,3,local+14); /*v+*/
	local[13] = w;
	local[14]= local[13];
	goto irtmodelIF1807;
irtmodelIF1806:
	local[14]= NIL;
irtmodelIF1807:
	goto irtmodelIF1805;
irtmodelIF1804:
	local[14]= NIL;
irtmodelIF1805:
	local[14]= NIL;
	local[15]= local[5];
irtmodelWHL1808:
	if (local[15]==NIL) goto irtmodelWHX1809;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15] = (w)->c.cons.cdr;
	w = local[16];
	local[14] = w;
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	local[17]= local[1];
	local[18]= fqv[139];
	local[19]= (pointer)get_sym_func(fqv[140]);
	ctx->vsp=local+20;
	w=(*ftab[32])(ctx,4,local+16,&ftab[32],fqv[212]); /*position*/
	local[16]= w;
	if (local[16]==NIL) goto irtmodelIF1811;
	local[17]= (pointer)get_sym_func(fqv[322]);
	local[18]= local[1];
	local[19]= makeint((eusinteger_t)0L);
	local[20]= local[16];
	ctx->vsp=local+21;
	w=(pointer)SUBSEQ(ctx,3,local+18); /*subseq*/
	local[18]= w;
	local[19]= fqv[198];
	ctx->vsp=local+20;
	w=(*ftab[18])(ctx,2,local+18,&ftab[18],fqv[128]); /*send-all*/
	local[18]= w;
	local[19]= fqv[31];
	ctx->vsp=local+20;
	w=(*ftab[18])(ctx,2,local+18,&ftab[18],fqv[128]); /*send-all*/
	local[18]= w;
	local[19]= fqv[323];
	local[20]= makeint((eusinteger_t)0L);
	ctx->vsp=local+21;
	w=(*ftab[26])(ctx,4,local+17,&ftab[26],fqv[196]); /*reduce*/
	local[17]= w;
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.car;
	ctx->vsp=local+19;
	w=(*ftab[43])(ctx,1,local+18,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelIF1813;
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.car;
	ctx->vsp=local+19;
	w=(pointer)FUNCALL(ctx,1,local+18); /*funcall*/
	local[18]= w;
	goto irtmodelIF1814;
irtmodelIF1813:
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.car;
irtmodelIF1814:
	local[19]= makeint((eusinteger_t)0L);
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.car;
	local[21]= fqv[198];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,2,local+20); /*send*/
	local[20]= w;
	local[21]= fqv[31];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,2,local+20); /*send*/
	local[20]= w;
irtmodelWHL1815:
	local[21]= local[19];
	w = local[20];
	if ((eusinteger_t)local[21] >= (eusinteger_t)w) goto irtmodelWHX1816;
	local[21]= local[13];
	local[22]= local[19];
	local[23]= local[17];
	ctx->vsp=local+24;
	w=(pointer)PLUS(ctx,2,local+22); /*+*/
	local[22]= w;
	local[23]= local[13];
	local[24]= local[19];
	local[25]= local[17];
	ctx->vsp=local+26;
	w=(pointer)PLUS(ctx,2,local+24); /*+*/
	local[24]= w;
	ctx->vsp=local+25;
	w=(pointer)ELT(ctx,2,local+23); /*elt*/
	local[23]= w;
	local[24]= local[18];
	ctx->vsp=local+25;
	w=(*ftab[0])(ctx,1,local+24,&ftab[0],fqv[4]); /*float-vector-p*/
	if (w==NIL) goto irtmodelIF1818;
	local[24]= local[18];
	local[25]= local[19];
	ctx->vsp=local+26;
	w=(pointer)ELT(ctx,2,local+24); /*elt*/
	local[24]= w;
	goto irtmodelIF1819;
irtmodelIF1818:
	local[24]= local[18];
irtmodelIF1819:
	local[25]= local[11];
	local[26]= local[19];
	local[27]= local[17];
	ctx->vsp=local+28;
	w=(pointer)PLUS(ctx,2,local+26); /*+*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)ELT(ctx,2,local+25); /*elt*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(pointer)TIMES(ctx,2,local+24); /***/
	local[24]= w;
	ctx->vsp=local+25;
	w=(pointer)PLUS(ctx,2,local+23); /*+*/
	local[23]= w;
	ctx->vsp=local+24;
	w=(pointer)SETELT(ctx,3,local+21); /*setelt*/
	local[21]= local[19];
	ctx->vsp=local+22;
	w=(pointer)ADD1(ctx,1,local+21); /*1+*/
	local[19] = w;
	goto irtmodelWHL1815;
irtmodelWHX1816:
	local[21]= NIL;
irtmodelBLK1817:
	w = NIL;
	local[17]= w;
	goto irtmodelIF1812;
irtmodelIF1811:
	local[17]= NIL;
irtmodelIF1812:
	w = local[17];
	goto irtmodelWHL1808;
irtmodelWHX1809:
	local[16]= NIL;
irtmodelBLK1810:
	w = NIL;
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(*ftab[43])(ctx,1,local+14,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelCON1821;
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)FUNCALL(ctx,1,local+14); /*funcall*/
	local[3] = w;
	local[14]= local[3];
	goto irtmodelCON1820;
irtmodelCON1821:
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)LISTP(ctx,1,local+14); /*listp*/
	if (w==NIL) goto irtmodelCON1822;
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)EVAL(ctx,1,local+14); /*eval*/
	local[3] = w;
	local[14]= local[3];
	goto irtmodelCON1820;
irtmodelCON1822:
	local[14]= NIL;
irtmodelCON1820:
	if (local[3]==NIL) goto irtmodelIF1823;
	local[14]= local[3];
	local[15]= local[13];
	local[16]= local[13];
	ctx->vsp=local+17;
	w=(pointer)VPLUS(ctx,3,local+14); /*v+*/
	local[13] = w;
	local[14]= local[13];
	goto irtmodelIF1824;
irtmodelIF1823:
	local[14]= NIL;
irtmodelIF1824:
	w = local[13];
	local[0]= w;
irtmodelBLK1789:
	ctx->vsp=local; return(local[0]);}

/*:move-joints-avoidance*/
static pointer irtmodelM1825cascaded_link_move_joints_avoidance(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtmodelRST1827:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[336], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1828;
	local[1] = NIL;
irtmodelKEY1828:
	if (n & (1<<1)) goto irtmodelKEY1829;
	local[2] = NIL;
irtmodelKEY1829:
	if (n & (1<<2)) goto irtmodelKEY1830;
	local[27]= argv[0];
	local[28]= fqv[211];
	local[29]= local[1];
	ctx->vsp=local+30;
	w=(pointer)SEND(ctx,3,local+27); /*send*/
	local[3] = w;
irtmodelKEY1830:
	if (n & (1<<3)) goto irtmodelKEY1831;
	local[27]= loadglobal(fqv[5]);
	local[28]= local[3];
	ctx->vsp=local+29;
	w=(pointer)INSTANTIATE(ctx,2,local+27); /*instantiate*/
	local[27]= w;
	local[28]= makeint((eusinteger_t)1L);
	ctx->vsp=local+29;
	w=(*ftab[36])(ctx,2,local+27,&ftab[36],fqv[242]); /*fill*/
	local[4] = w;
irtmodelKEY1831:
	if (n & (1<<4)) goto irtmodelKEY1832;
	local[5] = NIL;
irtmodelKEY1832:
	if (n & (1<<5)) goto irtmodelKEY1833;
	local[6] = makeflt(9.9999999999999950039964e-03);
irtmodelKEY1833:
	if (n & (1<<6)) goto irtmodelKEY1834;
	local[7] = makeflt(1.0000000000000000000000e+00);
irtmodelKEY1834:
	if (n & (1<<7)) goto irtmodelKEY1835;
	local[8] = makeint((eusinteger_t)200L);
irtmodelKEY1835:
	if (n & (1<<8)) goto irtmodelKEY1836;
	local[9] = makeflt(1.0000000000000000000000e+00);
irtmodelKEY1836:
	if (n & (1<<9)) goto irtmodelKEY1837;
	local[10] = makeflt(1.0000000000000000000000e+00);
irtmodelKEY1837:
	if (n & (1<<10)) goto irtmodelKEY1838;
	local[27]= argv[0];
	local[28]= fqv[337];
	local[29]= local[2];
	local[30]= fqv[338];
	local[31]= fqv[338];
	w = local[0];
	w=memq(local[31],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[31]= (w)->c.cons.car;
	local[32]= fqv[339];
	local[33]= fqv[340];
	w = local[0];
	w=memq(local[33],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[33]= (w)->c.cons.car;
	ctx->vsp=local+34;
	w=(pointer)SEND(ctx,7,local+27); /*send*/
	local[11] = w;
irtmodelKEY1838:
	if (n & (1<<11)) goto irtmodelKEY1839;
	local[12] = makeflt(0.0000000000000000000000e+00);
irtmodelKEY1839:
	if (n & (1<<12)) goto irtmodelKEY1840;
	local[13] = NIL;
irtmodelKEY1840:
	if (n & (1<<13)) goto irtmodelKEY1841;
	local[14] = NIL;
irtmodelKEY1841:
	if (n & (1<<14)) goto irtmodelKEY1842;
	local[15] = fqv[33];
irtmodelKEY1842:
	if (n & (1<<15)) goto irtmodelKEY1843;
	local[16] = NIL;
irtmodelKEY1843:
	if (n & (1<<16)) goto irtmodelKEY1844;
	local[17] = NIL;
irtmodelKEY1844:
	if (n & (1<<17)) goto irtmodelKEY1845;
	local[18] = NIL;
irtmodelKEY1845:
	if (n & (1<<18)) goto irtmodelKEY1846;
	local[27]= loadglobal(fqv[5]);
	local[28]= local[3];
	ctx->vsp=local+29;
	w=(pointer)INSTANTIATE(ctx,2,local+27); /*instantiate*/
	local[19] = w;
irtmodelKEY1846:
	if (n & (1<<19)) goto irtmodelKEY1847;
	local[27]= loadglobal(fqv[5]);
	local[28]= local[3];
	ctx->vsp=local+29;
	w=(pointer)INSTANTIATE(ctx,2,local+27); /*instantiate*/
	local[20] = w;
irtmodelKEY1847:
	if (n & (1<<20)) goto irtmodelKEY1848;
	local[27]= loadglobal(fqv[5]);
	local[28]= local[3];
	ctx->vsp=local+29;
	w=(pointer)INSTANTIATE(ctx,2,local+27); /*instantiate*/
	local[21] = w;
irtmodelKEY1848:
	if (n & (1<<21)) goto irtmodelKEY1849;
	local[27]= loadglobal(fqv[5]);
	local[28]= local[3];
	ctx->vsp=local+29;
	w=(pointer)INSTANTIATE(ctx,2,local+27); /*instantiate*/
	local[22] = w;
irtmodelKEY1849:
	if (n & (1<<22)) goto irtmodelKEY1850;
	local[27]= local[3];
	local[28]= local[3];
	ctx->vsp=local+29;
	w=(*ftab[23])(ctx,2,local+27,&ftab[23],fqv[166]); /*make-matrix*/
	local[23] = w;
irtmodelKEY1850:
	if (n & (1<<23)) goto irtmodelKEY1851;
	local[27]= local[3];
	local[28]= local[3];
	ctx->vsp=local+29;
	w=(*ftab[23])(ctx,2,local+27,&ftab[23],fqv[166]); /*make-matrix*/
	local[24] = w;
irtmodelKEY1851:
	if (n & (1<<24)) goto irtmodelKEY1852;
	local[25] = NIL;
irtmodelKEY1852:
	if (n & (1<<25)) goto irtmodelKEY1853;
	local[26] = NIL;
irtmodelKEY1853:
	local[27]= NIL;
	local[28]= NIL;
	local[29]= NIL;
	local[30]= NIL;
	local[31]= NIL;
	local[32]= makeflt(0.0000000000000000000000e+00);
	local[33]= NIL;
	local[34]= NIL;
	local[35]= NIL;
	if (local[26]!=NIL) goto irtmodelIF1854;
	local[36]= fqv[341];
	ctx->vsp=local+37;
	w=(*ftab[2])(ctx,1,local+36,&ftab[2],fqv[15]); /*warn*/
	w = T;
	ctx->vsp=local+36;
	local[0]=w;
	goto irtmodelBLK1826;
	goto irtmodelIF1855;
irtmodelIF1854:
	local[36]= NIL;
irtmodelIF1855:
	if (local[25]==NIL) goto irtmodelIF1856;
	w = local[25];
	if (!!iscons(w)) goto irtmodelIF1856;
	local[36]= local[25];
	ctx->vsp=local+37;
	w=(pointer)LIST(ctx,1,local+36); /*list*/
	local[25] = w;
	local[36]= local[25];
	goto irtmodelIF1857;
irtmodelIF1856:
	local[36]= NIL;
irtmodelIF1857:
	if (local[25]==NIL) goto irtmodelIF1858;
	local[36]= fqv[202];
	w = local[25];
	if (memq(local[36],w)!=NIL) goto irtmodelIF1858;
	local[36]= fqv[342];
	ctx->vsp=local+37;
	w=(*ftab[2])(ctx,1,local+36,&ftab[2],fqv[15]); /*warn*/
	local[36]= NIL;
	local[37]= local[1];
	local[38]= fqv[198];
	ctx->vsp=local+39;
	w=(*ftab[18])(ctx,2,local+37,&ftab[18],fqv[128]); /*send-all*/
	local[37]= w;
irtmodelWHL1860:
	if (local[37]==NIL) goto irtmodelWHX1861;
	w=local[37];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[38]= (w)->c.cons.car;
	w=local[37];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[37] = (w)->c.cons.cdr;
	w = local[38];
	local[36] = w;
	local[38]= local[36];
	local[39]= fqv[20];
	ctx->vsp=local+40;
	w=(pointer)SEND(ctx,2,local+38); /*send*/
	local[38]= w;
	local[39]= local[38];
	ctx->vsp=local+40;
	w=(pointer)VECTORP(ctx,1,local+39); /*vectorp*/
	if (w==NIL) goto irtmodelIF1863;
	local[39]= makeint((eusinteger_t)0L);
	local[40]= local[38];
	ctx->vsp=local+41;
	w=(pointer)LENGTH(ctx,1,local+40); /*length*/
	local[40]= w;
irtmodelWHL1865:
	local[41]= local[39];
	w = local[40];
	if ((eusinteger_t)local[41] >= (eusinteger_t)w) goto irtmodelWHX1866;
	local[41]= fqv[343];
	local[42]= local[38];
	local[43]= local[39];
	ctx->vsp=local+44;
	w=(pointer)ELT(ctx,2,local+42); /*elt*/
	local[42]= w;
	ctx->vsp=local+43;
	w=(*ftab[2])(ctx,2,local+41,&ftab[2],fqv[15]); /*warn*/
	local[41]= local[39];
	ctx->vsp=local+42;
	w=(pointer)ADD1(ctx,1,local+41); /*1+*/
	local[39] = w;
	goto irtmodelWHL1865;
irtmodelWHX1866:
	local[41]= NIL;
irtmodelBLK1867:
	w = NIL;
	local[39]= w;
	goto irtmodelIF1864;
irtmodelIF1863:
	local[39]= fqv[344];
	local[40]= local[38];
	ctx->vsp=local+41;
	w=(*ftab[2])(ctx,2,local+39,&ftab[2],fqv[15]); /*warn*/
	local[39]= w;
irtmodelIF1864:
	w = local[39];
	goto irtmodelWHL1860;
irtmodelWHX1861:
	local[38]= NIL;
irtmodelBLK1862:
	w = NIL;
	local[36]= fqv[345];
	ctx->vsp=local+37;
	w=(*ftab[2])(ctx,1,local+36,&ftab[2],fqv[15]); /*warn*/
	local[36]= fqv[346];
	ctx->vsp=local+37;
	w=(*ftab[2])(ctx,1,local+36,&ftab[2],fqv[15]); /*warn*/
	local[36]= NIL;
	local[37]= local[1];
	local[38]= fqv[198];
	ctx->vsp=local+39;
	w=(*ftab[18])(ctx,2,local+37,&ftab[18],fqv[128]); /*send-all*/
	local[37]= w;
irtmodelWHL1868:
	if (local[37]==NIL) goto irtmodelWHX1869;
	w=local[37];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[38]= (w)->c.cons.car;
	w=local[37];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[37] = (w)->c.cons.cdr;
	w = local[38];
	local[36] = w;
	local[38]= local[36];
	local[39]= fqv[22];
	ctx->vsp=local+40;
	w=(pointer)SEND(ctx,2,local+38); /*send*/
	local[38]= w;
	local[39]= local[38];
	ctx->vsp=local+40;
	w=(pointer)VECTORP(ctx,1,local+39); /*vectorp*/
	if (w==NIL) goto irtmodelIF1871;
	local[39]= makeint((eusinteger_t)0L);
	local[40]= local[38];
	ctx->vsp=local+41;
	w=(pointer)LENGTH(ctx,1,local+40); /*length*/
	local[40]= w;
irtmodelWHL1873:
	local[41]= local[39];
	w = local[40];
	if ((eusinteger_t)local[41] >= (eusinteger_t)w) goto irtmodelWHX1874;
	local[41]= fqv[347];
	local[42]= local[38];
	local[43]= local[39];
	ctx->vsp=local+44;
	w=(pointer)ELT(ctx,2,local+42); /*elt*/
	local[42]= w;
	ctx->vsp=local+43;
	w=(*ftab[2])(ctx,2,local+41,&ftab[2],fqv[15]); /*warn*/
	local[41]= local[39];
	ctx->vsp=local+42;
	w=(pointer)ADD1(ctx,1,local+41); /*1+*/
	local[39] = w;
	goto irtmodelWHL1873;
irtmodelWHX1874:
	local[41]= NIL;
irtmodelBLK1875:
	w = NIL;
	local[39]= w;
	goto irtmodelIF1872;
irtmodelIF1871:
	local[39]= fqv[348];
	local[40]= local[38];
	ctx->vsp=local+41;
	w=(*ftab[2])(ctx,2,local+39,&ftab[2],fqv[15]); /*warn*/
	local[39]= w;
irtmodelIF1872:
	w = local[39];
	goto irtmodelWHL1868;
irtmodelWHX1869:
	local[38]= NIL;
irtmodelBLK1870:
	w = NIL;
	local[36]= fqv[349];
	ctx->vsp=local+37;
	w=(*ftab[2])(ctx,1,local+36,&ftab[2],fqv[15]); /*warn*/
	local[36]= fqv[350];
	ctx->vsp=local+37;
	w=(*ftab[2])(ctx,1,local+36,&ftab[2],fqv[15]); /*warn*/
	local[36]= NIL;
	local[37]= local[1];
	local[38]= fqv[198];
	ctx->vsp=local+39;
	w=(*ftab[18])(ctx,2,local+37,&ftab[18],fqv[128]); /*send-all*/
	local[37]= w;
irtmodelWHL1876:
	if (local[37]==NIL) goto irtmodelWHX1877;
	w=local[37];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[38]= (w)->c.cons.car;
	w=local[37];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[37] = (w)->c.cons.cdr;
	w = local[38];
	local[36] = w;
	local[38]= local[36];
	local[39]= fqv[23];
	ctx->vsp=local+40;
	w=(pointer)SEND(ctx,2,local+38); /*send*/
	local[38]= w;
	local[39]= local[38];
	ctx->vsp=local+40;
	w=(pointer)VECTORP(ctx,1,local+39); /*vectorp*/
	if (w==NIL) goto irtmodelIF1879;
	local[39]= makeint((eusinteger_t)0L);
	local[40]= local[38];
	ctx->vsp=local+41;
	w=(pointer)LENGTH(ctx,1,local+40); /*length*/
	local[40]= w;
irtmodelWHL1881:
	local[41]= local[39];
	w = local[40];
	if ((eusinteger_t)local[41] >= (eusinteger_t)w) goto irtmodelWHX1882;
	local[41]= fqv[351];
	local[42]= local[38];
	local[43]= local[39];
	ctx->vsp=local+44;
	w=(pointer)ELT(ctx,2,local+42); /*elt*/
	local[42]= w;
	ctx->vsp=local+43;
	w=(*ftab[2])(ctx,2,local+41,&ftab[2],fqv[15]); /*warn*/
	local[41]= local[39];
	ctx->vsp=local+42;
	w=(pointer)ADD1(ctx,1,local+41); /*1+*/
	local[39] = w;
	goto irtmodelWHL1881;
irtmodelWHX1882:
	local[41]= NIL;
irtmodelBLK1883:
	w = NIL;
	local[39]= w;
	goto irtmodelIF1880;
irtmodelIF1879:
	local[39]= fqv[352];
	local[40]= local[38];
	ctx->vsp=local+41;
	w=(*ftab[2])(ctx,2,local+39,&ftab[2],fqv[15]); /*warn*/
	local[39]= w;
irtmodelIF1880:
	w = local[39];
	goto irtmodelWHL1876;
irtmodelWHX1877:
	local[38]= NIL;
irtmodelBLK1878:
	w = NIL;
	local[36]= fqv[353];
	ctx->vsp=local+37;
	w=(*ftab[2])(ctx,1,local+36,&ftab[2],fqv[15]); /*warn*/
	local[36]= w;
	goto irtmodelIF1859;
irtmodelIF1858:
	local[36]= NIL;
irtmodelIF1859:
	local[36]= argv[0];
	local[37]= fqv[354];
	local[38]= local[2];
	local[39]= fqv[273];
	local[40]= local[4];
	local[41]= fqv[355];
	local[42]= local[3];
	local[43]= fqv[356];
	local[44]= local[7];
	local[45]= fqv[357];
	local[46]= local[1];
	local[47]= fqv[340];
	local[48]= local[25];
	local[49]= fqv[283];
	local[50]= local[19];
	local[51]= fqv[358];
	local[52]= local[21];
	local[53]= fqv[359];
	local[54]= local[17];
	ctx->vsp=local+55;
	w=(pointer)SEND(ctx,19,local+36); /*send*/
	local[4] = w;
	local[36]= (pointer)get_sym_func(fqv[288]);
	local[37]= argv[0];
	local[38]= fqv[360];
	local[39]= local[26];
	local[40]= fqv[273];
	local[41]= local[4];
	local[42]= local[0];
	ctx->vsp=local+43;
	w=(pointer)APPLY(ctx,7,local+36); /*apply*/
	local[34] = w;
	local[36]= local[23]->c.obj.iv[1];
	local[37]= makeint((eusinteger_t)0L);
	ctx->vsp=local+38;
	w=(*ftab[36])(ctx,2,local+36,&ftab[36],fqv[242]); /*fill*/
	local[36]= makeint((eusinteger_t)0L);
	local[37]= local[3];
irtmodelWHL1884:
	local[38]= local[36];
	w = local[37];
	if ((eusinteger_t)local[38] >= (eusinteger_t)w) goto irtmodelWHX1885;
	local[38]= local[23];
	local[39]= local[36];
	local[40]= local[36];
	local[41]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+42;
	w=(pointer)ASET(ctx,4,local+38); /*aset*/
	local[38]= local[36];
	ctx->vsp=local+39;
	w=(pointer)ADD1(ctx,1,local+38); /*1+*/
	local[36] = w;
	goto irtmodelWHL1884;
irtmodelWHX1885:
	local[38]= NIL;
irtmodelBLK1886:
	w = NIL;
	local[36]= local[23];
	local[37]= local[34];
	local[38]= local[26];
	local[39]= local[24];
	ctx->vsp=local+40;
	w=(pointer)MATTIMES(ctx,3,local+37); /*m**/
	local[37]= w;
	local[38]= local[23];
	ctx->vsp=local+39;
	w=(*ftab[44])(ctx,3,local+36,&ftab[44],fqv[361]); /*m-*/
	local[35] = w;
	local[36]= argv[0];
	local[37]= fqv[150];
	local[38]= fqv[302];
	local[39]= NIL;
	ctx->vsp=local+40;
	w=(pointer)SEND(ctx,4,local+36); /*send*/
	local[36]= argv[0];
	local[37]= fqv[150];
	local[38]= fqv[303];
	local[39]= NIL;
	ctx->vsp=local+40;
	w=(pointer)SEND(ctx,4,local+36); /*send*/
	if (local[11]==NIL) goto irtmodelIF1887;
	local[36]= local[8];
	local[37]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+38;
	w=(pointer)GREATERP(ctx,2,local+36); /*>*/
	if (w==NIL) goto irtmodelIF1887;
	local[36]= local[10];
	local[37]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+38;
	w=(pointer)GREATERP(ctx,2,local+36); /*>*/
	if (w!=NIL) goto irtmodelOR1889;
	local[36]= local[9];
	local[37]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+38;
	w=(pointer)GREATERP(ctx,2,local+36); /*>*/
	if (w!=NIL) goto irtmodelOR1889;
	goto irtmodelIF1887;
irtmodelOR1889:
	local[36]= (pointer)get_sym_func(fqv[288]);
	local[37]= argv[0];
	local[38]= fqv[362];
	local[39]= fqv[363];
	local[40]= local[8];
	local[41]= fqv[364];
	local[42]= local[9];
	local[43]= fqv[365];
	local[44]= local[10];
	local[45]= fqv[273];
	local[46]= local[4];
	local[47]= fqv[366];
	local[48]= local[11];
	local[49]= local[0];
	ctx->vsp=local+50;
	w=(pointer)APPLY(ctx,14,local+36); /*apply*/
	local[31] = w;
	local[36]= argv[0];
	local[37]= fqv[184];
	local[38]= fqv[252];
	ctx->vsp=local+39;
	w=(pointer)SEND(ctx,3,local+36); /*send*/
	local[36]= w;
	local[37]= makeint((eusinteger_t)0L);
	ctx->vsp=local+38;
	w=(pointer)ELT(ctx,2,local+36); /*elt*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[33] = (w)->c.cons.car;
	local[36]= local[10];
	local[37]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+38;
	w=(pointer)LSEQP(ctx,2,local+36); /*<=*/
	if (w==NIL) goto irtmodelCON1891;
	local[36]= makeflt(0.0000000000000000000000e+00);
	goto irtmodelCON1890;
irtmodelCON1891:
	local[36]= local[33];
	local[37]= makeflt(9.9999999999999977795540e-02);
	local[38]= local[8];
	ctx->vsp=local+39;
	w=(pointer)TIMES(ctx,2,local+37); /***/
	local[37]= w;
	ctx->vsp=local+38;
	w=(pointer)LESSP(ctx,2,local+36); /*<*/
	if (w==NIL) goto irtmodelCON1892;
	local[36]= makeflt(1.0000000000000000000000e+00);
	goto irtmodelCON1890;
irtmodelCON1892:
	local[36]= local[33];
	local[37]= local[8];
	ctx->vsp=local+38;
	w=(pointer)LESSP(ctx,2,local+36); /*<*/
	if (w==NIL) goto irtmodelCON1893;
	local[36]= local[8];
	local[37]= local[33];
	ctx->vsp=local+38;
	w=(pointer)MINUS(ctx,2,local+36); /*-*/
	local[36]= w;
	local[37]= makeflt(8.9999999999999991118216e-01);
	local[38]= local[8];
	ctx->vsp=local+39;
	w=(pointer)TIMES(ctx,2,local+37); /***/
	local[37]= w;
	ctx->vsp=local+38;
	w=(pointer)QUOTIENT(ctx,2,local+36); /*/*/
	local[36]= w;
	goto irtmodelCON1890;
irtmodelCON1893:
	local[36]= makeflt(0.0000000000000000000000e+00);
	goto irtmodelCON1890;
irtmodelCON1894:
	local[36]= NIL;
irtmodelCON1890:
	local[32] = local[36];
	if (local[25]==NIL) goto irtmodelIF1895;
	local[36]= fqv[202];
	w = local[25];
	if (memq(local[36],w)!=NIL) goto irtmodelIF1895;
	local[36]= loadglobal(fqv[5]);
	local[37]= (pointer)get_sym_func(fqv[49]);
	local[38]= local[31];
	ctx->vsp=local+39;
	w=(pointer)MAP(ctx,3,local+36); /*map*/
	local[36]= w;
	local[37]= fqv[367];
	ctx->vsp=local+38;
	w=(*ftab[33])(ctx,2,local+36,&ftab[33],fqv[233]); /*format-array*/
	local[36]= fqv[368];
	local[37]= local[32];
	ctx->vsp=local+38;
	w=(*ftab[2])(ctx,2,local+36,&ftab[2],fqv[15]); /*warn*/
	local[36]= w;
	goto irtmodelIF1896;
irtmodelIF1895:
	local[36]= NIL;
irtmodelIF1896:
	goto irtmodelIF1888;
irtmodelIF1887:
	local[36]= NIL;
irtmodelIF1888:
	local[36]= argv[0];
	local[37]= fqv[369];
	local[38]= local[2];
	local[39]= fqv[357];
	local[40]= local[1];
	local[41]= fqv[370];
	local[42]= local[6];
	local[43]= fqv[340];
	local[44]= local[25];
	local[45]= fqv[334];
	local[46]= local[12];
	local[47]= fqv[333];
	local[48]= local[13];
	local[49]= fqv[331];
	local[50]= local[14];
	local[51]= fqv[371];
	local[52]= local[16];
	local[53]= fqv[332];
	local[54]= NIL;
	local[55]= fqv[372];
	local[56]= local[15];
	local[57]= fqv[273];
	local[58]= local[4];
	local[59]= fqv[355];
	local[60]= local[3];
	local[61]= fqv[373];
	local[62]= local[5];
	local[63]= fqv[374];
	local[64]= local[22];
	local[65]= fqv[375];
	local[66]= local[18];
	ctx->vsp=local+67;
	w=(pointer)SEND(ctx,31,local+36); /*send*/
	local[22] = w;
	local[36]= argv[0];
	local[37]= fqv[184];
	local[38]= fqv[302];
	ctx->vsp=local+39;
	w=(pointer)SEND(ctx,3,local+36); /*send*/
	if (w==NIL) goto irtmodelIF1897;
	local[36]= local[22];
	local[37]= argv[0];
	local[38]= fqv[184];
	local[39]= fqv[302];
	ctx->vsp=local+40;
	w=(pointer)SEND(ctx,3,local+37); /*send*/
	local[37]= w;
	local[38]= local[22];
	ctx->vsp=local+39;
	w=(pointer)VPLUS(ctx,3,local+36); /*v+*/
	local[36]= w;
	goto irtmodelIF1898;
irtmodelIF1897:
	local[36]= NIL;
irtmodelIF1898:
	local[36]= (pointer)get_sym_func(fqv[34]);
	local[37]= argv[0];
	local[38]= loadglobal(fqv[376]);
	local[39]= fqv[377];
	local[40]= argv[2];
	local[41]= fqv[357];
	local[42]= local[1];
	local[43]= fqv[373];
	local[44]= local[22];
	local[45]= fqv[378];
	local[46]= local[31];
	local[47]= fqv[379];
	local[48]= local[32];
	local[49]= fqv[273];
	local[50]= local[4];
	local[51]= fqv[380];
	local[52]= local[34];
	local[53]= fqv[381];
	local[54]= local[35];
	local[55]= local[0];
	ctx->vsp=local+56;
	w=(pointer)APPLY(ctx,20,local+36); /*apply*/
	w = T;
	local[0]= w;
irtmodelBLK1826:
	ctx->vsp=local; return(local[0]);}

/*:inverse-kinematics-args*/
static pointer irtmodelM1899cascaded_link_inverse_kinematics_args(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtmodelRST1901:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[382], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1902;
	local[1] = NIL;
irtmodelKEY1902:
	if (n & (1<<1)) goto irtmodelKEY1903;
	local[2] = NIL;
irtmodelKEY1903:
	if (n & (1<<2)) goto irtmodelKEY1904;
	local[3] = NIL;
irtmodelKEY1904:
	if (n & (1<<3)) goto irtmodelKEY1905;
	local[4] = NIL;
irtmodelKEY1905:
	local[5]= argv[0];
	local[6]= fqv[211];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= argv[0];
	local[7]= fqv[210];
	local[8]= local[2];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= w;
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,2,local+6); /*+*/
	local[6]= w;
	local[7]= local[6];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(*ftab[23])(ctx,2,local+7,&ftab[23],fqv[166]); /*make-matrix*/
	local[7]= w;
	local[8]= local[5];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(*ftab[23])(ctx,2,local+8,&ftab[23],fqv[166]); /*make-matrix*/
	local[8]= w;
	local[9]= local[5];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(*ftab[23])(ctx,2,local+9,&ftab[23],fqv[166]); /*make-matrix*/
	local[9]= w;
	local[10]= local[5];
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(*ftab[23])(ctx,2,local+10,&ftab[23],fqv[166]); /*make-matrix*/
	local[10]= w;
	local[11]= local[6];
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(*ftab[23])(ctx,2,local+11,&ftab[23],fqv[166]); /*make-matrix*/
	local[11]= w;
	local[12]= local[6];
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(*ftab[23])(ctx,2,local+12,&ftab[23],fqv[166]); /*make-matrix*/
	local[12]= w;
	local[13]= local[5];
	local[14]= local[6];
	ctx->vsp=local+15;
	w=(*ftab[23])(ctx,2,local+13,&ftab[23],fqv[166]); /*make-matrix*/
	local[13]= w;
	local[14]= local[5];
	local[15]= local[5];
	ctx->vsp=local+16;
	w=(*ftab[23])(ctx,2,local+14,&ftab[23],fqv[166]); /*make-matrix*/
	local[14]= w;
	local[15]= local[5];
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(*ftab[23])(ctx,2,local+15,&ftab[23],fqv[166]); /*make-matrix*/
	local[15]= w;
	local[16]= local[6];
	local[17]= local[6];
	ctx->vsp=local+18;
	w=(*ftab[23])(ctx,2,local+16,&ftab[23],fqv[166]); /*make-matrix*/
	local[16]= w;
	local[17]= local[6];
	local[18]= local[5];
	ctx->vsp=local+19;
	w=(*ftab[23])(ctx,2,local+17,&ftab[23],fqv[166]); /*make-matrix*/
	local[17]= w;
	local[18]= loadglobal(fqv[5]);
	local[19]= makeint((eusinteger_t)0L);
	ctx->vsp=local+20;
	w=(pointer)INSTANTIATE(ctx,2,local+18); /*instantiate*/
	local[18]= w;
	local[19]= loadglobal(fqv[5]);
	local[20]= makeint((eusinteger_t)1L);
	ctx->vsp=local+21;
	w=(pointer)INSTANTIATE(ctx,2,local+19); /*instantiate*/
	local[19]= w;
	local[20]= loadglobal(fqv[5]);
	local[21]= makeint((eusinteger_t)2L);
	ctx->vsp=local+22;
	w=(pointer)INSTANTIATE(ctx,2,local+20); /*instantiate*/
	local[20]= w;
	local[21]= loadglobal(fqv[5]);
	local[22]= makeint((eusinteger_t)3L);
	ctx->vsp=local+23;
	w=(pointer)INSTANTIATE(ctx,2,local+21); /*instantiate*/
	local[21]= w;
	local[22]= loadglobal(fqv[5]);
	local[23]= makeint((eusinteger_t)3L);
	ctx->vsp=local+24;
	w=(pointer)INSTANTIATE(ctx,2,local+22); /*instantiate*/
	local[22]= w;
	local[23]= loadglobal(fqv[5]);
	local[24]= makeint((eusinteger_t)3L);
	ctx->vsp=local+25;
	w=(pointer)INSTANTIATE(ctx,2,local+23); /*instantiate*/
	local[23]= w;
	local[24]= loadglobal(fqv[5]);
	local[25]= makeint((eusinteger_t)3L);
	ctx->vsp=local+26;
	w=(pointer)INSTANTIATE(ctx,2,local+24); /*instantiate*/
	local[24]= w;
	local[25]= makeint((eusinteger_t)3L);
	local[26]= makeint((eusinteger_t)3L);
	ctx->vsp=local+27;
	w=(*ftab[23])(ctx,2,local+25,&ftab[23],fqv[166]); /*make-matrix*/
	local[25]= w;
	local[26]= loadglobal(fqv[5]);
	local[27]= local[6];
	ctx->vsp=local+28;
	w=(pointer)INSTANTIATE(ctx,2,local+26); /*instantiate*/
	local[26]= w;
	local[27]= NIL;
	local[28]= loadglobal(fqv[5]);
	local[29]= local[5];
	ctx->vsp=local+30;
	w=(pointer)INSTANTIATE(ctx,2,local+28); /*instantiate*/
	local[28]= w;
	local[29]= loadglobal(fqv[5]);
	local[30]= local[5];
	ctx->vsp=local+31;
	w=(pointer)INSTANTIATE(ctx,2,local+29); /*instantiate*/
	local[29]= w;
	local[30]= loadglobal(fqv[5]);
	local[31]= makeint((eusinteger_t)3L);
	ctx->vsp=local+32;
	w=(pointer)INSTANTIATE(ctx,2,local+30); /*instantiate*/
	local[30]= w;
	local[31]= loadglobal(fqv[5]);
	local[32]= makeint((eusinteger_t)3L);
	ctx->vsp=local+33;
	w=(pointer)INSTANTIATE(ctx,2,local+31); /*instantiate*/
	local[31]= w;
	local[32]= makeint((eusinteger_t)0L);
	local[33]= local[2];
	ctx->vsp=local+34;
	w=(pointer)LENGTH(ctx,1,local+33); /*length*/
	local[33]= w;
irtmodelWHL1906:
	local[34]= local[32];
	w = local[33];
	if ((eusinteger_t)local[34] >= (eusinteger_t)w) goto irtmodelWHX1907;
	local[34]= loadglobal(fqv[5]);
	local[35]= argv[0];
	local[36]= fqv[210];
	local[37]= local[2];
	local[38]= local[32];
	ctx->vsp=local+39;
	w=(pointer)ELT(ctx,2,local+37); /*elt*/
	local[37]= w;
	local[38]= local[3];
	local[39]= local[32];
	ctx->vsp=local+40;
	w=(pointer)ELT(ctx,2,local+38); /*elt*/
	local[38]= w;
	ctx->vsp=local+39;
	w=(pointer)SEND(ctx,4,local+35); /*send*/
	local[35]= w;
	ctx->vsp=local+36;
	w=(pointer)INSTANTIATE(ctx,2,local+34); /*instantiate*/
	local[34]= w;
	w = local[27];
	ctx->vsp=local+35;
	local[27] = cons(ctx,local[34],w);
	local[34]= local[32];
	ctx->vsp=local+35;
	w=(pointer)ADD1(ctx,1,local+34); /*1+*/
	local[32] = w;
	goto irtmodelWHL1906;
irtmodelWHX1907:
	local[34]= NIL;
irtmodelBLK1908:
	w = NIL;
	local[32]= local[27];
	ctx->vsp=local+33;
	w=(pointer)NREVERSE(ctx,1,local+32); /*nreverse*/
	local[32]= fqv[383];
	local[33]= local[6];
	local[34]= fqv[355];
	local[35]= local[5];
	local[36]= fqv[272];
	local[37]= local[7];
	local[38]= fqv[261];
	local[39]= local[8];
	local[40]= fqv[262];
	local[41]= local[9];
	local[42]= fqv[263];
	local[43]= local[10];
	local[44]= fqv[264];
	local[45]= local[11];
	local[46]= fqv[265];
	local[47]= local[12];
	local[48]= fqv[266];
	local[49]= local[13];
	local[50]= fqv[267];
	local[51]= local[14];
	local[52]= fqv[268];
	local[53]= local[15];
	local[54]= fqv[270];
	local[55]= local[16];
	local[56]= fqv[269];
	local[57]= local[17];
	local[58]= fqv[274];
	local[59]= local[18];
	local[60]= fqv[275];
	local[61]= local[19];
	local[62]= fqv[276];
	local[63]= local[20];
	local[64]= fqv[277];
	local[65]= local[21];
	local[66]= fqv[278];
	local[67]= local[22];
	local[68]= fqv[279];
	local[69]= local[23];
	local[70]= fqv[280];
	local[71]= local[24];
	local[72]= fqv[281];
	local[73]= local[25];
	local[74]= fqv[282];
	local[75]= local[26];
	local[76]= fqv[384];
	local[77]= local[27];
	local[78]= fqv[283];
	local[79]= local[28];
	local[80]= fqv[284];
	local[81]= local[29];
	local[82]= fqv[285];
	local[83]= local[30];
	local[84]= fqv[286];
	local[85]= local[31];
	ctx->vsp=local+86;
	w=(pointer)LIST(ctx,54,local+32); /*list*/
	local[0]= w;
irtmodelBLK1900:
	ctx->vsp=local; return(local[0]);}

/*:draw-collision-debug-view*/
static pointer irtmodelM1909cascaded_link_draw_collision_debug_view(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[184];
	local[2]= fqv[290];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	if (w==NIL) goto irtmodelIF1911;
	local[0]= loadglobal(fqv[385]);
	local[1]= fqv[386];
	local[2]= fqv[387];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= loadglobal(fqv[385]);
	local[2]= fqv[386];
	local[3]= fqv[388];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= loadglobal(fqv[385]);
	local[3]= fqv[386];
	local[4]= fqv[189];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[184];
	local[5]= fqv[290];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[184];
	local[6]= fqv[252];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= NIL;
	local[6]= loadglobal(fqv[385]);
	local[7]= fqv[386];
	local[8]= fqv[189];
	local[9]= fqv[389];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= loadglobal(fqv[385]);
	local[7]= fqv[386];
	local[8]= fqv[387];
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= loadglobal(fqv[385]);
	local[7]= fqv[386];
	local[8]= fqv[388];
	local[9]= makeint((eusinteger_t)3L);
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= makeint((eusinteger_t)0L);
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
irtmodelWHL1913:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto irtmodelWHX1914;
	local[8]= argv[0];
	local[9]= fqv[184];
	local[10]= fqv[252];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[5] = w;
	if (local[5]!=NIL) goto irtmodelIF1916;
	local[8]= fqv[390];
	local[9]= local[3];
	local[10]= fqv[3];
	ctx->vsp=local+11;
	w=(*ftab[18])(ctx,2,local+9,&ftab[18],fqv[128]); /*send-all*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[2])(ctx,2,local+8,&ftab[2],fqv[15]); /*warn*/
	w = NIL;
	ctx->vsp=local+8;
	local[8]=w;
	goto irtmodelBLK1915;
	goto irtmodelIF1917;
irtmodelIF1916:
	local[8]= NIL;
irtmodelIF1917:
	local[8]= loadglobal(fqv[385]);
	local[9]= fqv[386];
	local[10]= fqv[189];
	local[11]= fqv[391];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= loadglobal(fqv[385]);
	local[9]= fqv[386];
	local[10]= fqv[387];
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= loadglobal(fqv[385]);
	local[9]= fqv[386];
	local[10]= fqv[388];
	local[11]= makeint((eusinteger_t)2L);
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= loadglobal(fqv[385]);
	local[9]= fqv[386];
	local[10]= fqv[392];
	local[11]= local[5];
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= fqv[393];
	local[13]= T;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,6,local+8); /*send*/
	local[8]= loadglobal(fqv[385]);
	local[9]= fqv[386];
	local[10]= fqv[392];
	local[11]= local[5];
	local[12]= makeint((eusinteger_t)2L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= fqv[393];
	local[13]= T;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,6,local+8); /*send*/
	local[8]= loadglobal(fqv[385]);
	local[9]= fqv[386];
	local[10]= fqv[394];
	local[11]= local[5];
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= local[5];
	local[13]= makeint((eusinteger_t)2L);
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= fqv[393];
	local[14]= T;
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,7,local+8); /*send*/
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= makeint((eusinteger_t)200L);
	ctx->vsp=local+10;
	w=(pointer)LESSP(ctx,2,local+8); /*<*/
	if (w==NIL) goto irtmodelIF1918;
	local[8]= loadglobal(fqv[385]);
	local[9]= fqv[386];
	local[10]= fqv[387];
	local[11]= makeint((eusinteger_t)4L);
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= loadglobal(fqv[385]);
	local[9]= fqv[386];
	local[10]= fqv[388];
	local[11]= makeint((eusinteger_t)6L);
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= w;
	goto irtmodelIF1919;
irtmodelIF1918:
	local[8]= loadglobal(fqv[385]);
	local[9]= fqv[386];
	local[10]= fqv[387];
	local[11]= makeint((eusinteger_t)2L);
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= loadglobal(fqv[385]);
	local[9]= fqv[386];
	local[10]= fqv[388];
	local[11]= makeint((eusinteger_t)3L);
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= w;
irtmodelIF1919:
	local[8]= loadglobal(fqv[385]);
	local[9]= fqv[386];
	local[10]= fqv[189];
	local[11]= local[4];
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+14;
	w=(*ftab[8])(ctx,3,local+11,&ftab[8],fqv[81]); /*eps=*/
	if (w==NIL) goto irtmodelIF1920;
	local[11]= fqv[395];
	goto irtmodelIF1921;
irtmodelIF1920:
	local[11]= fqv[396];
irtmodelIF1921:
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= loadglobal(fqv[385]);
	local[9]= fqv[386];
	local[10]= fqv[394];
	local[11]= local[5];
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= local[5];
	local[13]= makeint((eusinteger_t)2L);
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= fqv[393];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,7,local+8); /*send*/
	local[8]= loadglobal(fqv[385]);
	local[9]= fqv[386];
	local[10]= fqv[392];
	local[11]= local[5];
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= fqv[393];
	local[13]= NIL;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,6,local+8); /*send*/
	local[8]= loadglobal(fqv[385]);
	local[9]= fqv[386];
	local[10]= fqv[392];
	local[11]= local[5];
	local[12]= makeint((eusinteger_t)2L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= fqv[393];
	local[13]= NIL;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,6,local+8); /*send*/
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+10;
	w=(pointer)LSEQP(ctx,2,local+8); /*<=*/
	if (w==NIL) goto irtmodelIF1922;
	local[8]= NIL;
	local[9]= local[3];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(*ftab[38])(ctx,1,local+10,&ftab[38],fqv[291]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
irtmodelWHL1924:
	if (local[9]==NIL) goto irtmodelWHX1925;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= local[8];
	local[11]= loadglobal(fqv[213]);
	ctx->vsp=local+12;
	w=(pointer)DERIVEDP(ctx,2,local+10); /*derivedp*/
	if (w==NIL) goto irtmodelIF1927;
	local[10]= local[8];
	local[11]= fqv[149];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	if (fqv[120]!=local[10]) goto irtmodelIF1927;
	local[10]= *(ovafptr(local[8],fqv[397]));
	local[11]= fqv[122];
	ctx->vsp=local+12;
	w=(*ftab[18])(ctx,2,local+10,&ftab[18],fqv[128]); /*send-all*/
	local[10]= w;
	goto irtmodelIF1928;
irtmodelIF1927:
	local[10]= NIL;
irtmodelIF1928:
	local[10]= local[8];
	local[11]= loadglobal(fqv[213]);
	ctx->vsp=local+12;
	w=(pointer)DERIVEDP(ctx,2,local+10); /*derivedp*/
	if (w==NIL) goto irtmodelIF1929;
	local[10]= NIL;
	local[11]= local[8];
	local[12]= fqv[127];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
irtmodelWHL1931:
	if (local[11]==NIL) goto irtmodelWHX1932;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11] = (w)->c.cons.cdr;
	w = local[12];
	local[10] = w;
	local[12]= NIL;
	local[13]= local[10];
	local[14]= fqv[398];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.cdr;
irtmodelWHL1934:
	if (local[13]==NIL) goto irtmodelWHX1935;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13] = (w)->c.cons.cdr;
	w = local[14];
	local[12] = w;
	local[14]= loadglobal(fqv[385]);
	local[15]= fqv[386];
	local[16]= fqv[394];
	local[17]= *(ovafptr(local[12],fqv[399]));
	local[18]= *(ovafptr(local[12],fqv[400]));
	local[19]= fqv[393];
	local[20]= T;
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,7,local+14); /*send*/
	goto irtmodelWHL1934;
irtmodelWHX1935:
	local[14]= NIL;
irtmodelBLK1936:
	w = NIL;
	goto irtmodelWHL1931;
irtmodelWHX1932:
	local[12]= NIL;
irtmodelBLK1933:
	w = NIL;
	local[10]= w;
	goto irtmodelIF1930;
irtmodelIF1929:
	local[10]= NIL;
	local[11]= local[8];
	local[12]= fqv[398];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.cdr;
irtmodelWHL1937:
	if (local[11]==NIL) goto irtmodelWHX1938;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11] = (w)->c.cons.cdr;
	w = local[12];
	local[10] = w;
	local[12]= loadglobal(fqv[385]);
	local[13]= fqv[386];
	local[14]= fqv[394];
	local[15]= *(ovafptr(local[10],fqv[399]));
	local[16]= *(ovafptr(local[10],fqv[400]));
	local[17]= fqv[393];
	local[18]= T;
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,7,local+12); /*send*/
	goto irtmodelWHL1937;
irtmodelWHX1938:
	local[12]= NIL;
irtmodelBLK1939:
	w = NIL;
	local[10]= w;
irtmodelIF1930:
	goto irtmodelWHL1924;
irtmodelWHX1925:
	local[10]= NIL;
irtmodelBLK1926:
	w = NIL;
	local[8]= w;
	goto irtmodelIF1923;
irtmodelIF1922:
	local[8]= NIL;
irtmodelIF1923:
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto irtmodelWHL1913;
irtmodelWHX1914:
	local[8]= NIL;
irtmodelBLK1915:
	w = NIL;
	local[6]= loadglobal(fqv[385]);
	local[7]= fqv[386];
	local[8]= fqv[387];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= loadglobal(fqv[385]);
	local[7]= fqv[386];
	local[8]= fqv[388];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= loadglobal(fqv[385]);
	local[7]= fqv[386];
	local[8]= fqv[189];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[0]= w;
	goto irtmodelIF1912;
irtmodelIF1911:
	local[0]= NIL;
irtmodelIF1912:
	w = local[0];
	local[0]= w;
irtmodelBLK1910:
	ctx->vsp=local; return(local[0]);}

/*:inverse-kinematics-loop*/
static pointer irtmodelM1940cascaded_link_inverse_kinematics_loop(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
irtmodelRST1942:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-4);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[401], &argv[4], n-4, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY1943;
	local[1] = makeint((eusinteger_t)1L);
irtmodelKEY1943:
	if (n & (1<<1)) goto irtmodelKEY1944;
	local[2] = makeint((eusinteger_t)0L);
irtmodelKEY1944:
	if (n & (1<<2)) goto irtmodelKEY1945;
	local[3] = NIL;
irtmodelKEY1945:
	if (n & (1<<3)) goto irtmodelKEY1946;
	local[4] = NIL;
irtmodelKEY1946:
	if (n & (1<<4)) goto irtmodelKEY1947;
	w = local[4];
	if (!!iscons(w)) goto irtmodelCON1949;
	local[26]= T;
	goto irtmodelCON1948;
irtmodelCON1949:
	local[26]= local[4];
	ctx->vsp=local+27;
	w=(pointer)LENGTH(ctx,1,local+26); /*length*/
	local[26]= w;
	local[27]= fqv[209];
	local[28]= T;
	ctx->vsp=local+29;
	w=(*ftab[31])(ctx,3,local+26,&ftab[31],fqv[208]); /*make-list*/
	local[26]= w;
	goto irtmodelCON1948;
irtmodelCON1950:
	local[26]= NIL;
irtmodelCON1948:
	local[5] = local[26];
irtmodelKEY1947:
	if (n & (1<<5)) goto irtmodelKEY1951;
	w = local[4];
	if (!!iscons(w)) goto irtmodelCON1953;
	local[26]= T;
	goto irtmodelCON1952;
irtmodelCON1953:
	local[26]= local[4];
	ctx->vsp=local+27;
	w=(pointer)LENGTH(ctx,1,local+26); /*length*/
	local[26]= w;
	local[27]= fqv[209];
	local[28]= T;
	ctx->vsp=local+29;
	w=(*ftab[31])(ctx,3,local+26,&ftab[31],fqv[208]); /*make-list*/
	local[26]= w;
	goto irtmodelCON1952;
irtmodelCON1954:
	local[26]= NIL;
irtmodelCON1952:
	local[6] = local[26];
irtmodelKEY1951:
	if (n & (1<<6)) goto irtmodelKEY1955;
	w = local[4];
	if (!!iscons(w)) goto irtmodelCON1957;
	local[26]= makeint((eusinteger_t)1L);
	goto irtmodelCON1956;
irtmodelCON1957:
	local[26]= local[4];
	ctx->vsp=local+27;
	w=(pointer)LENGTH(ctx,1,local+26); /*length*/
	local[26]= w;
	local[27]= fqv[209];
	local[28]= makeint((eusinteger_t)1L);
	ctx->vsp=local+29;
	w=(*ftab[31])(ctx,3,local+26,&ftab[31],fqv[208]); /*make-list*/
	local[26]= w;
	goto irtmodelCON1956;
irtmodelCON1958:
	local[26]= NIL;
irtmodelCON1956:
	local[7] = local[26];
irtmodelKEY1955:
	if (n & (1<<7)) goto irtmodelKEY1959;
	w = local[4];
	if (!!iscons(w)) goto irtmodelCON1961;
	local[26]= makeint((eusinteger_t)1L);
	ctx->vsp=local+27;
	w=(*ftab[6])(ctx,1,local+26,&ftab[6],fqv[48]); /*deg2rad*/
	local[26]= w;
	goto irtmodelCON1960;
irtmodelCON1961:
	local[26]= local[4];
	ctx->vsp=local+27;
	w=(pointer)LENGTH(ctx,1,local+26); /*length*/
	local[26]= w;
	local[27]= fqv[209];
	local[28]= makeint((eusinteger_t)1L);
	ctx->vsp=local+29;
	w=(*ftab[6])(ctx,1,local+28,&ftab[6],fqv[48]); /*deg2rad*/
	local[28]= w;
	ctx->vsp=local+29;
	w=(*ftab[31])(ctx,3,local+26,&ftab[31],fqv[208]); /*make-list*/
	local[26]= w;
	goto irtmodelCON1960;
irtmodelCON1962:
	local[26]= NIL;
irtmodelCON1960:
	local[8] = local[26];
irtmodelKEY1959:
	if (n & (1<<8)) goto irtmodelKEY1963;
	local[9] = makeflt(1.0000000000000000000000e+00);
irtmodelKEY1963:
	if (n & (1<<9)) goto irtmodelKEY1964;
	local[10] = makeflt(1.0000000000000000000000e+00);
irtmodelKEY1964:
	if (n & (1<<10)) goto irtmodelKEY1965;
	local[11] = NIL;
irtmodelKEY1965:
	if (n & (1<<11)) goto irtmodelKEY1966;
	local[12] = NIL;
irtmodelKEY1966:
	if (n & (1<<12)) goto irtmodelKEY1967;
	local[13] = NIL;
irtmodelKEY1967:
	if (n & (1<<13)) goto irtmodelKEY1968;
	local[14] = NIL;
irtmodelKEY1968:
	if (n & (1<<14)) goto irtmodelKEY1969;
	local[15] = NIL;
irtmodelKEY1969:
	if (n & (1<<15)) goto irtmodelKEY1970;
	local[16] = NIL;
irtmodelKEY1970:
	if (n & (1<<16)) goto irtmodelKEY1971;
	local[17] = makeflt(1.0000000000000000000000e+00);
irtmodelKEY1971:
	if (n & (1<<17)) goto irtmodelKEY1972;
	local[18] = NIL;
irtmodelKEY1972:
	if (n & (1<<18)) goto irtmodelKEY1973;
	local[19] = NIL;
irtmodelKEY1973:
	if (n & (1<<19)) goto irtmodelKEY1974;
	local[20] = fqv[33];
irtmodelKEY1974:
	if (n & (1<<20)) goto irtmodelKEY1975;
	local[21] = NIL;
irtmodelKEY1975:
	if (n & (1<<21)) goto irtmodelKEY1976;
	local[22] = makeflt(1.0000000000000000000000e+00);
irtmodelKEY1976:
	if (n & (1<<22)) goto irtmodelKEY1977;
	local[26]= local[1];
	local[27]= makeint((eusinteger_t)10L);
	ctx->vsp=local+28;
	w=(pointer)QUOTIENT(ctx,2,local+26); /*/*/
	local[23] = w;
irtmodelKEY1977:
	if (n & (1<<23)) goto irtmodelKEY1978;
	local[24] = NIL;
irtmodelKEY1978:
	if (n & (1<<24)) goto irtmodelKEY1979;
	local[25] = NIL;
irtmodelKEY1979:
	if (local[18]==NIL) goto irtmodelIF1980;
	local[26]= argv[0];
	local[27]= fqv[332];
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,2,local+26); /*send*/
	local[26]= w;
	goto irtmodelIF1981;
irtmodelIF1980:
	local[26]= NIL;
irtmodelIF1981:
	local[26]= NIL;
	local[27]= NIL;
	local[28]= makeint((eusinteger_t)0L);
	local[29]= T;
	local[30]= local[0];
	local[31]= local[25];
	ctx->vsp=local+32;
	w=(pointer)NCONC(ctx,2,local+30); /*nconc*/
	local[30]= w;
	local[31]= fqv[402];
	w = local[0];
	w=memq(local[31],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[31]= (w)->c.cons.car;
	local[32]= fqv[403];
	w = local[0];
	w=memq(local[32],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[32]= (w)->c.cons.car;
	if (local[11]!=NIL) goto irtmodelIF1982;
	local[33]= argv[0];
	local[34]= fqv[197];
	local[35]= local[3];
	ctx->vsp=local+36;
	w=(pointer)SEND(ctx,3,local+33); /*send*/
	local[11] = w;
	local[33]= local[11];
	ctx->vsp=local+34;
	w=(pointer)LENGTH(ctx,1,local+33); /*length*/
	local[33]= w;
	local[34]= local[3];
	ctx->vsp=local+35;
	w=(pointer)LENGTH(ctx,1,local+34); /*length*/
	local[34]= w;
	ctx->vsp=local+35;
	w=(*ftab[24])(ctx,2,local+33,&ftab[24],fqv[171]); /*/=*/
	if (w==NIL) goto irtmodelIF1984;
	local[33]= argv[0];
	local[34]= fqv[404];
	local[35]= local[11];
	ctx->vsp=local+36;
	w=(pointer)SEND(ctx,3,local+33); /*send*/
	local[33]= w;
	goto irtmodelIF1985;
irtmodelIF1984:
	local[33]= NIL;
irtmodelIF1985:
	goto irtmodelIF1983;
irtmodelIF1982:
	local[33]= NIL;
irtmodelIF1983:
	if (local[24]==NIL) goto irtmodelIF1986;
	w = local[24];
	if (!!iscons(w)) goto irtmodelIF1986;
	local[33]= local[24];
	ctx->vsp=local+34;
	w=(pointer)LIST(ctx,1,local+33); /*list*/
	local[24] = w;
	local[33]= local[24];
	goto irtmodelIF1987;
irtmodelIF1986:
	local[33]= NIL;
irtmodelIF1987:
	if (local[24]==NIL) goto irtmodelIF1988;
	local[33]= local[24];
	local[34]= fqv[405];
	ctx->vsp=local+35;
	w=(pointer)EQUAL(ctx,2,local+33); /*equal*/
	if (w!=NIL) goto irtmodelIF1988;
	if (loadglobal(fqv[385])==NIL) goto irtmodelIF1988;
	local[33]= loadglobal(fqv[385]);
	local[34]= fqv[386];
	local[35]= fqv[406];
	ctx->vsp=local+36;
	w=(pointer)SEND(ctx,3,local+33); /*send*/
	local[33]= w;
	goto irtmodelIF1989;
irtmodelIF1988:
	local[33]= NIL;
irtmodelIF1989:
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!!iscons(w)) goto irtmodelIF1990;
	local[33]= local[3];
	ctx->vsp=local+34;
	w=(pointer)LIST(ctx,1,local+33); /*list*/
	local[3] = w;
	local[33]= local[3];
	goto irtmodelIF1991;
irtmodelIF1990:
	local[33]= NIL;
irtmodelIF1991:
	w = local[4];
	if (!!iscons(w)) goto irtmodelIF1992;
	local[33]= local[4];
	ctx->vsp=local+34;
	w=(pointer)LIST(ctx,1,local+33); /*list*/
	local[4] = w;
	local[33]= local[4];
	goto irtmodelIF1993;
irtmodelIF1992:
	local[33]= NIL;
irtmodelIF1993:
	w = local[12];
	if (!iscons(w)) goto irtmodelOR1996;
	local[33]= local[12];
	ctx->vsp=local+34;
	w=(*ftab[43])(ctx,1,local+33,&ftab[43],fqv[320]); /*functionp*/
	if (w!=NIL) goto irtmodelOR1996;
	goto irtmodelIF1994;
irtmodelOR1996:
	local[33]= local[12];
	ctx->vsp=local+34;
	w=(pointer)LIST(ctx,1,local+33); /*list*/
	local[12] = w;
	local[33]= local[12];
	goto irtmodelIF1995;
irtmodelIF1994:
	local[33]= NIL;
irtmodelIF1995:
	w = argv[2];
	if (!!iscons(w)) goto irtmodelIF1997;
	local[33]= argv[2];
	ctx->vsp=local+34;
	w=(pointer)LIST(ctx,1,local+33); /*list*/
	argv[2] = w;
	local[33]= argv[2];
	goto irtmodelIF1998;
irtmodelIF1997:
	local[33]= NIL;
irtmodelIF1998:
	w = argv[3];
	if (!!iscons(w)) goto irtmodelIF1999;
	local[33]= argv[3];
	ctx->vsp=local+34;
	w=(pointer)LIST(ctx,1,local+33); /*list*/
	argv[3] = w;
	local[33]= argv[3];
	goto irtmodelIF2000;
irtmodelIF1999:
	local[33]= NIL;
irtmodelIF2000:
	w = local[5];
	if (!!iscons(w)) goto irtmodelIF2001;
	local[33]= local[5];
	ctx->vsp=local+34;
	w=(pointer)LIST(ctx,1,local+33); /*list*/
	local[5] = w;
	local[33]= local[5];
	goto irtmodelIF2002;
irtmodelIF2001:
	local[33]= NIL;
irtmodelIF2002:
	w = local[6];
	if (!!iscons(w)) goto irtmodelIF2003;
	local[33]= local[6];
	ctx->vsp=local+34;
	w=(pointer)LIST(ctx,1,local+33); /*list*/
	local[6] = w;
	local[33]= local[6];
	goto irtmodelIF2004;
irtmodelIF2003:
	local[33]= NIL;
irtmodelIF2004:
	w = local[7];
	if (!!iscons(w)) goto irtmodelIF2005;
	local[33]= local[7];
	ctx->vsp=local+34;
	w=(pointer)LIST(ctx,1,local+33); /*list*/
	local[7] = w;
	local[33]= local[7];
	goto irtmodelIF2006;
irtmodelIF2005:
	local[33]= NIL;
irtmodelIF2006:
	w = local[8];
	if (!!iscons(w)) goto irtmodelIF2007;
	local[33]= local[8];
	ctx->vsp=local+34;
	w=(pointer)LIST(ctx,1,local+33); /*list*/
	local[8] = w;
	local[33]= local[8];
	goto irtmodelIF2008;
irtmodelIF2007:
	local[33]= NIL;
irtmodelIF2008:
	local[33]= local[6];
	ctx->vsp=local+34;
	w=(pointer)LENGTH(ctx,1,local+33); /*length*/
	local[33]= w;
	local[34]= local[5];
	ctx->vsp=local+35;
	w=(pointer)LENGTH(ctx,1,local+34); /*length*/
	local[34]= w;
	local[35]= local[4];
	ctx->vsp=local+36;
	w=(pointer)LENGTH(ctx,1,local+35); /*length*/
	local[35]= w;
	local[36]= local[3];
	ctx->vsp=local+37;
	w=(pointer)LENGTH(ctx,1,local+36); /*length*/
	local[36]= w;
	local[37]= argv[2];
	ctx->vsp=local+38;
	w=(pointer)LENGTH(ctx,1,local+37); /*length*/
	local[37]= w;
	local[38]= argv[3];
	ctx->vsp=local+39;
	w=(pointer)LENGTH(ctx,1,local+38); /*length*/
	local[38]= w;
	local[39]= local[7];
	ctx->vsp=local+40;
	w=(pointer)LENGTH(ctx,1,local+39); /*length*/
	local[39]= w;
	local[40]= local[8];
	ctx->vsp=local+41;
	w=(pointer)LENGTH(ctx,1,local+40); /*length*/
	local[40]= w;
	ctx->vsp=local+41;
	w=(pointer)NUMEQUAL(ctx,8,local+33); /*=*/
	if (w!=NIL) goto irtmodelIF2009;
	local[33]= fqv[407];
	local[34]= local[6];
	ctx->vsp=local+35;
	w=(pointer)LENGTH(ctx,1,local+34); /*length*/
	local[34]= w;
	local[35]= local[5];
	ctx->vsp=local+36;
	w=(pointer)LENGTH(ctx,1,local+35); /*length*/
	local[35]= w;
	local[36]= local[4];
	ctx->vsp=local+37;
	w=(pointer)LENGTH(ctx,1,local+36); /*length*/
	local[36]= w;
	local[37]= local[3];
	ctx->vsp=local+38;
	w=(pointer)LENGTH(ctx,1,local+37); /*length*/
	local[37]= w;
	local[38]= argv[2];
	ctx->vsp=local+39;
	w=(pointer)LENGTH(ctx,1,local+38); /*length*/
	local[38]= w;
	local[39]= argv[3];
	ctx->vsp=local+40;
	w=(pointer)LENGTH(ctx,1,local+39); /*length*/
	local[39]= w;
	local[40]= local[7];
	ctx->vsp=local+41;
	w=(pointer)LENGTH(ctx,1,local+40); /*length*/
	local[40]= w;
	local[41]= local[8];
	ctx->vsp=local+42;
	w=(pointer)LENGTH(ctx,1,local+41); /*length*/
	local[41]= w;
	ctx->vsp=local+42;
	w=(*ftab[2])(ctx,9,local+33,&ftab[2],fqv[15]); /*warn*/
	w = fqv[408];
	ctx->vsp=local+33;
	local[0]=w;
	goto irtmodelBLK1941;
	goto irtmodelIF2010;
irtmodelIF2009:
	local[33]= NIL;
irtmodelIF2010:
	local[33]= fqv[384];
	w = local[25];
	if (memq(local[33],w)==NIL) goto irtmodelIF2011;
	local[33]= fqv[384];
	w = local[25];
	w=memq(local[33],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[27] = (w)->c.cons.car;
	local[33]= local[27];
	goto irtmodelIF2012;
irtmodelIF2011:
	local[33]= makeint((eusinteger_t)0L);
	local[34]= local[5];
	ctx->vsp=local+35;
	w=(pointer)LENGTH(ctx,1,local+34); /*length*/
	local[34]= w;
irtmodelWHL2013:
	local[35]= local[33];
	w = local[34];
	if ((eusinteger_t)local[35] >= (eusinteger_t)w) goto irtmodelWHX2014;
	local[35]= loadglobal(fqv[5]);
	local[36]= argv[0];
	local[37]= fqv[210];
	local[38]= local[5];
	local[39]= local[33];
	ctx->vsp=local+40;
	w=(pointer)ELT(ctx,2,local+38); /*elt*/
	local[38]= w;
	local[39]= local[6];
	local[40]= local[33];
	ctx->vsp=local+41;
	w=(pointer)ELT(ctx,2,local+39); /*elt*/
	local[39]= w;
	ctx->vsp=local+40;
	w=(pointer)SEND(ctx,4,local+36); /*send*/
	local[36]= w;
	ctx->vsp=local+37;
	w=(pointer)INSTANTIATE(ctx,2,local+35); /*instantiate*/
	local[35]= w;
	w = local[27];
	ctx->vsp=local+36;
	local[27] = cons(ctx,local[35],w);
	local[35]= local[33];
	ctx->vsp=local+36;
	w=(pointer)ADD1(ctx,1,local+35); /*1+*/
	local[33] = w;
	goto irtmodelWHL2013;
irtmodelWHX2014:
	local[35]= NIL;
irtmodelBLK2015:
	w = NIL;
	local[33]= local[27];
	ctx->vsp=local+34;
	w=(pointer)NREVERSE(ctx,1,local+33); /*nreverse*/
	local[27] = w;
	local[33]= local[27];
irtmodelIF2012:
	local[33]= fqv[282];
	w = local[25];
	if (memq(local[33],w)==NIL) goto irtmodelIF2016;
	local[33]= fqv[282];
	w = local[25];
	w=memq(local[33],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[26] = (w)->c.cons.car;
	local[33]= local[26];
	goto irtmodelIF2017;
irtmodelIF2016:
	local[33]= loadglobal(fqv[5]);
	local[34]= argv[0];
	local[35]= fqv[210];
	local[36]= local[5];
	local[37]= local[6];
	ctx->vsp=local+38;
	w=(pointer)SEND(ctx,4,local+34); /*send*/
	local[34]= w;
	ctx->vsp=local+35;
	w=(pointer)INSTANTIATE(ctx,2,local+33); /*instantiate*/
	local[26] = w;
	local[33]= local[26];
irtmodelIF2017:
	local[33]= local[13];
	ctx->vsp=local+34;
	w=(*ftab[43])(ctx,1,local+33,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelIF2018;
	local[33]= local[13];
	local[34]= local[3];
	local[35]= local[4];
	local[36]= local[6];
	local[37]= local[5];
	ctx->vsp=local+38;
	w=(pointer)FUNCALL(ctx,5,local+33); /*funcall*/
	local[13] = w;
	local[33]= local[13];
	goto irtmodelIF2019;
irtmodelIF2018:
	local[33]= NIL;
irtmodelIF2019:
	if (local[13]!=NIL) goto irtmodelIF2020;
	local[33]= (pointer)get_sym_func(fqv[288]);
	local[34]= argv[0];
	local[35]= fqv[299];
	local[36]= local[3];
	local[37]= fqv[335];
	local[38]= local[6];
	local[39]= fqv[409];
	local[40]= local[5];
	local[41]= fqv[300];
	local[42]= local[4];
	local[43]= local[30];
	ctx->vsp=local+44;
	w=(pointer)APPLY(ctx,11,local+33); /*apply*/
	local[13] = w;
	local[33]= local[13];
	goto irtmodelIF2021;
irtmodelIF2020:
	local[33]= NIL;
irtmodelIF2021:
	if (local[24]==NIL) goto irtmodelIF2022;
	local[33]= fqv[202];
	w = local[24];
	if (memq(local[33],w)!=NIL) goto irtmodelIF2022;
	local[33]= fqv[410];
	local[34]= local[2];
	ctx->vsp=local+35;
	w=(*ftab[2])(ctx,2,local+33,&ftab[2],fqv[15]); /*warn*/
	local[33]= fqv[411];
	local[34]= local[11];
	local[35]= fqv[3];
	ctx->vsp=local+36;
	w=(*ftab[18])(ctx,2,local+34,&ftab[18],fqv[128]); /*send-all*/
	local[34]= w;
	ctx->vsp=local+35;
	w=(*ftab[2])(ctx,2,local+33,&ftab[2],fqv[15]); /*warn*/
	local[33]= fqv[412];
	local[34]= local[4];
	ctx->vsp=local+35;
	w=(*ftab[2])(ctx,2,local+33,&ftab[2],fqv[15]); /*warn*/
	local[33]= fqv[413];
	local[34]= local[12];
	ctx->vsp=local+35;
	w=(*ftab[2])(ctx,2,local+33,&ftab[2],fqv[15]); /*warn*/
	local[33]= w;
	goto irtmodelIF2023;
irtmodelIF2022:
	local[33]= NIL;
irtmodelIF2023:
	local[33]= argv[0];
	local[34]= fqv[414];
	if (local[23]==NIL) goto irtmodelIF2024;
	local[35]= local[2];
	local[36]= local[23];
	ctx->vsp=local+37;
	w=(pointer)GREQP(ctx,2,local+35); /*>=*/
	local[35]= w;
	goto irtmodelIF2025;
irtmodelIF2024:
	local[35]= T;
irtmodelIF2025:
	local[36]= argv[2];
	local[37]= argv[3];
	local[38]= local[5];
	local[39]= local[6];
	local[40]= local[7];
	local[41]= local[8];
	local[42]= local[17];
	local[43]= local[18];
	local[44]= local[19];
	local[45]= local[20];
	local[46]= fqv[332];
	local[47]= NIL;
	ctx->vsp=local+48;
	w=(pointer)SEND(ctx,15,local+33); /*send*/
	local[29] = w;
	if (local[14]==NIL) goto irtmodelIF2026;
	local[33]= local[29];
	if (local[33]==NIL) goto irtmodelAND2028;
	local[33]= local[14];
	ctx->vsp=local+34;
	w=(pointer)FUNCALL(ctx,1,local+33); /*funcall*/
	local[33]= w;
irtmodelAND2028:
	local[29] = local[33];
	local[33]= local[29];
	goto irtmodelIF2027;
irtmodelIF2026:
	local[33]= NIL;
irtmodelIF2027:
	local[33]= makeint((eusinteger_t)0L);
	local[34]= local[4];
	ctx->vsp=local+35;
	w=(pointer)LENGTH(ctx,1,local+34); /*length*/
	local[34]= w;
irtmodelWHL2029:
	local[35]= local[33];
	w = local[34];
	if ((eusinteger_t)local[35] >= (eusinteger_t)w) goto irtmodelWHX2030;
	local[35]= local[27];
	local[36]= local[33];
	ctx->vsp=local+37;
	w=(pointer)ELT(ctx,2,local+35); /*elt*/
	local[35]= w;
	local[36]= (pointer)get_sym_func(fqv[288]);
	local[37]= argv[0];
	local[38]= fqv[415];
	local[39]= argv[2];
	local[40]= local[33];
	ctx->vsp=local+41;
	w=(pointer)ELT(ctx,2,local+39); /*elt*/
	local[39]= w;
	local[40]= local[6];
	local[41]= local[33];
	ctx->vsp=local+42;
	w=(pointer)ELT(ctx,2,local+40); /*elt*/
	local[40]= w;
	if (local[31]==NIL) goto irtmodelIF2032;
	local[41]= fqv[402];
	local[42]= local[31];
	ctx->vsp=local+43;
	w=(pointer)LIST(ctx,2,local+41); /*list*/
	local[41]= w;
	goto irtmodelIF2033;
irtmodelIF2032:
	local[41]= NIL;
irtmodelIF2033:
	ctx->vsp=local+42;
	w=(pointer)APPLY(ctx,6,local+36); /*apply*/
	local[36]= w;
	local[37]= (pointer)get_sym_func(fqv[288]);
	local[38]= argv[0];
	local[39]= fqv[416];
	local[40]= argv[3];
	local[41]= local[33];
	ctx->vsp=local+42;
	w=(pointer)ELT(ctx,2,local+40); /*elt*/
	local[40]= w;
	local[41]= local[5];
	local[42]= local[33];
	ctx->vsp=local+43;
	w=(pointer)ELT(ctx,2,local+41); /*elt*/
	local[41]= w;
	if (local[32]==NIL) goto irtmodelIF2034;
	local[42]= fqv[403];
	local[43]= local[32];
	ctx->vsp=local+44;
	w=(pointer)LIST(ctx,2,local+42); /*list*/
	local[42]= w;
	goto irtmodelIF2035;
irtmodelIF2034:
	local[42]= NIL;
irtmodelIF2035:
	ctx->vsp=local+43;
	w=(pointer)APPLY(ctx,6,local+37); /*apply*/
	local[37]= w;
	if (local[24]==NIL) goto irtmodelIF2036;
	local[38]= fqv[202];
	w = local[24];
	if (memq(local[38],w)!=NIL) goto irtmodelIF2036;
	local[38]= makeflt(1.0000000000000000000000e+03);
	local[39]= local[36];
	ctx->vsp=local+40;
	w=(pointer)SCALEVEC(ctx,2,local+38); /*scale*/
	local[38]= w;
	local[39]= fqv[417];
	ctx->vsp=local+40;
	w=(*ftab[33])(ctx,2,local+38,&ftab[33],fqv[233]); /*format-array*/
	local[38]= local[37];
	local[39]= fqv[418];
	ctx->vsp=local+40;
	w=(*ftab[33])(ctx,2,local+38,&ftab[33],fqv[233]); /*format-array*/
	local[38]= fqv[419];
	local[39]= makeflt(1.0000000000000000000000e+03);
	local[40]= local[36];
	ctx->vsp=local+41;
	w=(pointer)VNORM(ctx,1,local+40); /*norm*/
	{ double x,y;
		y=fltval(w); x=fltval(local[39]);
		local[39]=(makeflt(x * y));}
	local[40]= local[7];
	local[41]= local[33];
	ctx->vsp=local+42;
	w=(pointer)ELT(ctx,2,local+40); /*elt*/
	local[40]= w;
	local[41]= local[37];
	ctx->vsp=local+42;
	w=(pointer)VNORM(ctx,1,local+41); /*norm*/
	local[41]= w;
	local[42]= local[8];
	local[43]= local[33];
	ctx->vsp=local+44;
	w=(pointer)ELT(ctx,2,local+42); /*elt*/
	local[42]= w;
	ctx->vsp=local+43;
	w=(*ftab[2])(ctx,5,local+38,&ftab[2],fqv[15]); /*warn*/
	local[38]= w;
	goto irtmodelIF2037;
irtmodelIF2036:
	local[38]= NIL;
irtmodelIF2037:
	local[38]= makeint((eusinteger_t)0L);
	local[39]= local[36];
	ctx->vsp=local+40;
	w=(pointer)LENGTH(ctx,1,local+39); /*length*/
	local[39]= w;
irtmodelWHL2038:
	local[40]= local[38];
	w = local[39];
	if ((eusinteger_t)local[40] >= (eusinteger_t)w) goto irtmodelWHX2039;
	local[40]= local[35];
	local[41]= local[38];
	local[42]= local[9];
	local[43]= local[36];
	local[44]= local[38];
	ctx->vsp=local+45;
	w=(pointer)ELT(ctx,2,local+43); /*elt*/
	local[43]= w;
	ctx->vsp=local+44;
	w=(pointer)TIMES(ctx,2,local+42); /***/
	local[42]= w;
	ctx->vsp=local+43;
	w=(pointer)SETELT(ctx,3,local+40); /*setelt*/
	local[40]= local[38];
	ctx->vsp=local+41;
	w=(pointer)ADD1(ctx,1,local+40); /*1+*/
	local[38] = w;
	goto irtmodelWHL2038;
irtmodelWHX2039:
	local[40]= NIL;
irtmodelBLK2040:
	w = NIL;
	local[38]= makeint((eusinteger_t)0L);
	local[39]= local[37];
	ctx->vsp=local+40;
	w=(pointer)LENGTH(ctx,1,local+39); /*length*/
	local[39]= w;
irtmodelWHL2041:
	local[40]= local[38];
	w = local[39];
	if ((eusinteger_t)local[40] >= (eusinteger_t)w) goto irtmodelWHX2042;
	local[40]= local[35];
	local[41]= local[38];
	local[42]= local[36];
	ctx->vsp=local+43;
	w=(pointer)LENGTH(ctx,1,local+42); /*length*/
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[41]= (pointer)((eusinteger_t)local[41] + (eusinteger_t)w);
	local[42]= local[10];
	local[43]= local[37];
	local[44]= local[38];
	ctx->vsp=local+45;
	w=(pointer)ELT(ctx,2,local+43); /*elt*/
	local[43]= w;
	ctx->vsp=local+44;
	w=(pointer)TIMES(ctx,2,local+42); /***/
	local[42]= w;
	ctx->vsp=local+43;
	w=(pointer)SETELT(ctx,3,local+40); /*setelt*/
	local[40]= local[38];
	ctx->vsp=local+41;
	w=(pointer)ADD1(ctx,1,local+40); /*1+*/
	local[38] = w;
	goto irtmodelWHL2041;
irtmodelWHX2042:
	local[40]= NIL;
irtmodelBLK2043:
	w = NIL;
	local[38]= argv[0];
	local[39]= fqv[184];
	local[40]= fqv[420];
	ctx->vsp=local+41;
	w=(pointer)SEND(ctx,3,local+38); /*send*/
	if (w==NIL) goto irtmodelIF2044;
	local[38]= NIL;
	local[39]= fqv[421];
	local[40]= local[33];
	ctx->vsp=local+41;
	w=(pointer)XFORMAT(ctx,3,local+38); /*format*/
	local[38]= w;
	ctx->vsp=local+39;
	w=(*ftab[45])(ctx,1,local+38,&ftab[45],fqv[422]); /*read-from-string*/
	local[38]= w;
	local[39]= argv[0];
	local[40]= fqv[184];
	local[41]= fqv[420];
	ctx->vsp=local+42;
	w=(pointer)SEND(ctx,3,local+39); /*send*/
	local[39]= w;
	ctx->vsp=local+40;
	w=(*ftab[41])(ctx,2,local+38,&ftab[41],fqv[314]); /*assoc*/
	local[38]= w;
	local[39]= local[36];
	local[40]= local[37];
	ctx->vsp=local+41;
	w=(pointer)LIST(ctx,2,local+39); /*list*/
	local[39]= w;
	local[40]= NIL;
	local[41]= fqv[423];
	local[42]= local[33];
	ctx->vsp=local+43;
	w=(pointer)XFORMAT(ctx,3,local+40); /*format*/
	local[40]= w;
	ctx->vsp=local+41;
	w=(*ftab[45])(ctx,1,local+40,&ftab[45],fqv[422]); /*read-from-string*/
	local[40]= w;
	local[41]= argv[0];
	local[42]= fqv[184];
	local[43]= fqv[420];
	ctx->vsp=local+44;
	w=(pointer)SEND(ctx,3,local+41); /*send*/
	local[41]= w;
	ctx->vsp=local+42;
	w=(*ftab[41])(ctx,2,local+40,&ftab[41],fqv[314]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	ctx->vsp=local+40;
	local[39]= cons(ctx,local[39],w);
	ctx->vsp=local+40;
	w=(pointer)RPLACD2(ctx,2,local+38); /*rplacd2*/
	local[38]= w;
	goto irtmodelIF2045;
irtmodelIF2044:
	local[38]= NIL;
irtmodelIF2045:
	w = local[38];
	local[35]= local[33];
	ctx->vsp=local+36;
	w=(pointer)ADD1(ctx,1,local+35); /*1+*/
	local[33] = w;
	goto irtmodelWHL2029;
irtmodelWHX2030:
	local[35]= NIL;
irtmodelBLK2031:
	w = NIL;
	local[33]= makeint((eusinteger_t)0L);
	local[34]= local[27];
	ctx->vsp=local+35;
	w=(pointer)LENGTH(ctx,1,local+34); /*length*/
	local[34]= w;
irtmodelWHL2046:
	local[35]= local[33];
	w = local[34];
	if ((eusinteger_t)local[35] >= (eusinteger_t)w) goto irtmodelWHX2047;
	local[35]= makeint((eusinteger_t)0L);
	local[36]= local[27];
	local[37]= local[33];
	ctx->vsp=local+38;
	w=(pointer)ELT(ctx,2,local+36); /*elt*/
	local[36]= w;
	ctx->vsp=local+37;
	w=(pointer)LENGTH(ctx,1,local+36); /*length*/
	local[36]= w;
irtmodelWHL2049:
	local[37]= local[35];
	w = local[36];
	if ((eusinteger_t)local[37] >= (eusinteger_t)w) goto irtmodelWHX2050;
	local[37]= local[26];
	local[38]= local[35];
	local[39]= local[28];
	ctx->vsp=local+40;
	w=(pointer)PLUS(ctx,2,local+38); /*+*/
	local[38]= w;
	local[39]= local[27];
	local[40]= local[33];
	ctx->vsp=local+41;
	w=(pointer)ELT(ctx,2,local+39); /*elt*/
	local[39]= w;
	local[40]= local[35];
	ctx->vsp=local+41;
	w=(pointer)ELT(ctx,2,local+39); /*elt*/
	local[39]= w;
	ctx->vsp=local+40;
	w=(pointer)SETELT(ctx,3,local+37); /*setelt*/
	local[37]= local[35];
	ctx->vsp=local+38;
	w=(pointer)ADD1(ctx,1,local+37); /*1+*/
	local[35] = w;
	goto irtmodelWHL2049;
irtmodelWHX2050:
	local[37]= NIL;
irtmodelBLK2051:
	w = NIL;
	local[35]= local[28];
	local[36]= local[27];
	local[37]= local[33];
	ctx->vsp=local+38;
	w=(pointer)ELT(ctx,2,local+36); /*elt*/
	local[36]= w;
	ctx->vsp=local+37;
	w=(pointer)LENGTH(ctx,1,local+36); /*length*/
	local[36]= w;
	ctx->vsp=local+37;
	w=(pointer)PLUS(ctx,2,local+35); /*+*/
	local[28] = w;
	local[35]= local[33];
	ctx->vsp=local+36;
	w=(pointer)ADD1(ctx,1,local+35); /*1+*/
	local[33] = w;
	goto irtmodelWHL2046;
irtmodelWHX2047:
	local[35]= NIL;
irtmodelBLK2048:
	w = NIL;
	if (local[21]!=NIL) goto irtmodelIF2052;
	if (local[18]==NIL) goto irtmodelIF2052;
	local[33]= argv[0];
	local[34]= fqv[424];
	local[35]= fqv[332];
	local[36]= NIL;
	local[37]= fqv[260];
	local[38]= local[11];
	local[39]= fqv[335];
	local[40]= local[20];
	ctx->vsp=local+41;
	w=(pointer)SEND(ctx,8,local+33); /*send*/
	local[33]= w;
	ctx->vsp=local+34;
	w=(pointer)LIST(ctx,1,local+33); /*list*/
	local[33]= w;
	local[34]= local[15];
	ctx->vsp=local+35;
	w=(pointer)APPEND(ctx,2,local+33); /*append*/
	local[15] = w;
	local[33]= local[22];
	local[34]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+35;
	w=(pointer)GREATERP(ctx,2,local+33); /*>*/
	if (w==NIL) goto irtmodelIF2054;
	local[33]= makeflt(1.0000000000000000000000e+00);
	goto irtmodelIF2055;
irtmodelIF2054:
	local[33]= local[22];
irtmodelIF2055:
	local[34]= argv[0];
	local[35]= fqv[425];
	local[36]= local[33];
	local[37]= local[20];
	local[38]= local[18];
	local[39]= fqv[331];
	local[40]= local[19];
	local[41]= fqv[332];
	local[42]= NIL;
	ctx->vsp=local+43;
	w=(pointer)SEND(ctx,9,local+34); /*send*/
	local[34]= w;
	ctx->vsp=local+35;
	w=(pointer)LIST(ctx,1,local+34); /*list*/
	local[34]= w;
	local[35]= local[16];
	ctx->vsp=local+36;
	w=(pointer)APPEND(ctx,2,local+34); /*append*/
	local[16] = w;
	local[34]= argv[0];
	local[35]= fqv[184];
	local[36]= fqv[420];
	ctx->vsp=local+37;
	w=(pointer)SEND(ctx,3,local+34); /*send*/
	if (w==NIL) goto irtmodelIF2056;
	local[34]= fqv[257];
	local[35]= argv[0];
	local[36]= fqv[184];
	local[37]= fqv[420];
	ctx->vsp=local+38;
	w=(pointer)SEND(ctx,3,local+35); /*send*/
	local[35]= w;
	ctx->vsp=local+36;
	w=(*ftab[41])(ctx,2,local+34,&ftab[41],fqv[314]); /*assoc*/
	local[34]= w;
	w=local[16];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[35]= (w)->c.cons.car;
	local[36]= fqv[257];
	local[37]= argv[0];
	local[38]= fqv[184];
	local[39]= fqv[420];
	ctx->vsp=local+40;
	w=(pointer)SEND(ctx,3,local+37); /*send*/
	local[37]= w;
	ctx->vsp=local+38;
	w=(*ftab[41])(ctx,2,local+36,&ftab[41],fqv[314]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	ctx->vsp=local+36;
	local[35]= cons(ctx,local[35],w);
	ctx->vsp=local+36;
	w=(pointer)RPLACD2(ctx,2,local+34); /*rplacd2*/
	local[34]= w;
	goto irtmodelIF2057;
irtmodelIF2056:
	local[34]= NIL;
irtmodelIF2057:
	w = local[34];
	local[33]= w;
	goto irtmodelIF2053;
irtmodelIF2052:
	local[33]= NIL;
irtmodelIF2053:
	local[33]= NIL;
	local[34]= NIL;
	local[35]= NIL;
	local[36]= NIL;
	if (local[15]==NIL) goto irtmodelIF2058;
	ctx->vsp=local+37;
	local[37]= makeclosure(codevec,quotevec,irtmodelCLO2060,env,argv,local);
	local[38]= local[16];
	ctx->vsp=local+39;
	w=(pointer)MAPCAR(ctx,2,local+37); /*mapcar*/
	local[33] = w;
	local[37]= local[26];
	ctx->vsp=local+38;
	w=(pointer)LENGTH(ctx,1,local+37); /*length*/
	local[37]= w;
	local[38]= (pointer)get_sym_func(fqv[322]);
	local[39]= (pointer)get_sym_func(fqv[426]);
	local[40]= local[33];
	ctx->vsp=local+41;
	w=(pointer)MAPCAR(ctx,2,local+39); /*mapcar*/
	local[39]= w;
	ctx->vsp=local+40;
	w=(*ftab[26])(ctx,2,local+38,&ftab[26],fqv[196]); /*reduce*/
	local[38]= w;
	ctx->vsp=local+39;
	w=(pointer)MINUS(ctx,2,local+37); /*-*/
	local[34] = w;
	local[37]= makeint((eusinteger_t)0L);
	local[38]= local[15];
	ctx->vsp=local+39;
	w=(pointer)LENGTH(ctx,1,local+38); /*length*/
	local[38]= w;
irtmodelWHL2061:
	local[39]= local[37];
	w = local[38];
	if ((eusinteger_t)local[39] >= (eusinteger_t)w) goto irtmodelWHX2062;
	local[39]= local[15];
	local[40]= local[37];
	ctx->vsp=local+41;
	w=(pointer)ELT(ctx,2,local+39); /*elt*/
	local[36] = w;
	local[39]= local[36];
	ctx->vsp=local+40;
	w=(*ftab[43])(ctx,1,local+39,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelIF2064;
	local[39]= local[36];
	local[40]= local[3];
	ctx->vsp=local+41;
	w=(pointer)FUNCALL(ctx,2,local+39); /*funcall*/
	local[39]= w;
	goto irtmodelIF2065;
irtmodelIF2064:
	local[39]= local[36];
irtmodelIF2065:
	local[36] = local[39];
	local[39]= local[33];
	local[40]= local[37];
	ctx->vsp=local+41;
	w=(pointer)ELT(ctx,2,local+39); /*elt*/
	local[35] = w;
	local[39]= makeint((eusinteger_t)0L);
	local[40]= local[36];
	local[41]= makeint((eusinteger_t)0L);
	ctx->vsp=local+42;
	w=(*ftab[3])(ctx,2,local+40,&ftab[3],fqv[24]); /*array-dimension*/
	local[40]= w;
irtmodelWHL2066:
	local[41]= local[39];
	w = local[40];
	if ((eusinteger_t)local[41] >= (eusinteger_t)w) goto irtmodelWHX2067;
	local[41]= makeint((eusinteger_t)0L);
	local[42]= local[13];
	local[43]= makeint((eusinteger_t)1L);
	ctx->vsp=local+44;
	w=(*ftab[3])(ctx,2,local+42,&ftab[3],fqv[24]); /*array-dimension*/
	local[42]= w;
irtmodelWHL2069:
	local[43]= local[41];
	w = local[42];
	if ((eusinteger_t)local[43] >= (eusinteger_t)w) goto irtmodelWHX2070;
	local[43]= local[13];
	local[44]= local[34];
	local[45]= local[39];
	ctx->vsp=local+46;
	w=(pointer)PLUS(ctx,2,local+44); /*+*/
	local[44]= w;
	local[45]= local[41];
	local[46]= local[36];
	local[47]= local[39];
	local[48]= local[41];
	ctx->vsp=local+49;
	w=(pointer)AREF(ctx,3,local+46); /*aref*/
	local[46]= w;
	ctx->vsp=local+47;
	w=(pointer)ASET(ctx,4,local+43); /*aset*/
	local[43]= local[41];
	ctx->vsp=local+44;
	w=(pointer)ADD1(ctx,1,local+43); /*1+*/
	local[41] = w;
	goto irtmodelWHL2069;
irtmodelWHX2070:
	local[43]= NIL;
irtmodelBLK2071:
	w = NIL;
	local[41]= local[26];
	local[42]= local[34];
	local[43]= local[39];
	ctx->vsp=local+44;
	w=(pointer)PLUS(ctx,2,local+42); /*+*/
	local[42]= w;
	local[43]= local[35];
	local[44]= local[39];
	ctx->vsp=local+45;
	w=(pointer)ELT(ctx,2,local+43); /*elt*/
	local[43]= w;
	ctx->vsp=local+44;
	w=(pointer)SETELT(ctx,3,local+41); /*setelt*/
	local[41]= local[39];
	ctx->vsp=local+42;
	w=(pointer)ADD1(ctx,1,local+41); /*1+*/
	local[39] = w;
	goto irtmodelWHL2066;
irtmodelWHX2067:
	local[41]= NIL;
irtmodelBLK2068:
	w = NIL;
	local[39]= local[34];
	local[40]= local[35];
	ctx->vsp=local+41;
	w=(pointer)LENGTH(ctx,1,local+40); /*length*/
	local[40]= w;
	ctx->vsp=local+41;
	w=(pointer)PLUS(ctx,2,local+39); /*+*/
	local[34] = w;
	if (local[24]==NIL) goto irtmodelIF2072;
	local[39]= fqv[202];
	w = local[24];
	if (memq(local[39],w)!=NIL) goto irtmodelIF2072;
	local[39]= local[36];
	local[40]= NIL;
	local[41]= fqv[427];
	local[42]= local[37];
	ctx->vsp=local+43;
	w=(pointer)XFORMAT(ctx,3,local+40); /*format*/
	local[40]= w;
	ctx->vsp=local+41;
	w=(*ftab[33])(ctx,2,local+39,&ftab[33],fqv[233]); /*format-array*/
	local[39]= local[35];
	local[40]= NIL;
	local[41]= fqv[428];
	local[42]= local[37];
	ctx->vsp=local+43;
	w=(pointer)XFORMAT(ctx,3,local+40); /*format*/
	local[40]= w;
	ctx->vsp=local+41;
	w=(*ftab[33])(ctx,2,local+39,&ftab[33],fqv[233]); /*format-array*/
	local[39]= w;
	goto irtmodelIF2073;
irtmodelIF2072:
	local[39]= NIL;
irtmodelIF2073:
	local[39]= argv[0];
	local[40]= fqv[184];
	local[41]= fqv[420];
	ctx->vsp=local+42;
	w=(pointer)SEND(ctx,3,local+39); /*send*/
	if (w==NIL) goto irtmodelIF2074;
	if (local[21]!=NIL) goto irtmodelIF2076;
	if (local[18]==NIL) goto irtmodelIF2076;
	local[39]= local[37];
	local[40]= makeint((eusinteger_t)0L);
	ctx->vsp=local+41;
	w=(*ftab[24])(ctx,2,local+39,&ftab[24],fqv[171]); /*/=*/
	if (w==NIL) goto irtmodelIF2076;
	local[39]= NIL;
	local[40]= fqv[429];
	local[41]= local[37];
	w = makeint((eusinteger_t)1L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[41]= (pointer)((eusinteger_t)local[41] - (eusinteger_t)w);
	ctx->vsp=local+42;
	w=(pointer)XFORMAT(ctx,3,local+39); /*format*/
	local[39]= w;
	ctx->vsp=local+40;
	w=(*ftab[45])(ctx,1,local+39,&ftab[45],fqv[422]); /*read-from-string*/
	local[39]= w;
	local[40]= argv[0];
	local[41]= fqv[184];
	local[42]= fqv[420];
	ctx->vsp=local+43;
	w=(pointer)SEND(ctx,3,local+40); /*send*/
	local[40]= w;
	ctx->vsp=local+41;
	w=(*ftab[41])(ctx,2,local+39,&ftab[41],fqv[314]); /*assoc*/
	local[39]= w;
	w=local[16];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[40]= (w)->c.cons.car;
	local[41]= NIL;
	local[42]= fqv[430];
	local[43]= local[37];
	w = makeint((eusinteger_t)1L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[43]= (pointer)((eusinteger_t)local[43] - (eusinteger_t)w);
	ctx->vsp=local+44;
	w=(pointer)XFORMAT(ctx,3,local+41); /*format*/
	local[41]= w;
	ctx->vsp=local+42;
	w=(*ftab[45])(ctx,1,local+41,&ftab[45],fqv[422]); /*read-from-string*/
	local[41]= w;
	local[42]= argv[0];
	local[43]= fqv[184];
	local[44]= fqv[420];
	ctx->vsp=local+45;
	w=(pointer)SEND(ctx,3,local+42); /*send*/
	local[42]= w;
	ctx->vsp=local+43;
	w=(*ftab[41])(ctx,2,local+41,&ftab[41],fqv[314]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	ctx->vsp=local+41;
	local[40]= cons(ctx,local[40],w);
	ctx->vsp=local+41;
	w=(pointer)RPLACD2(ctx,2,local+39); /*rplacd2*/
	local[39]= w;
	goto irtmodelIF2077;
irtmodelIF2076:
	local[39]= NIL;
irtmodelIF2077:
	goto irtmodelIF2075;
irtmodelIF2074:
	local[39]= NIL;
irtmodelIF2075:
	local[39]= local[37];
	ctx->vsp=local+40;
	w=(pointer)ADD1(ctx,1,local+39); /*1+*/
	local[37] = w;
	goto irtmodelWHL2061;
irtmodelWHX2062:
	local[39]= NIL;
irtmodelBLK2063:
	w = NIL;
	local[37]= w;
	goto irtmodelIF2059;
irtmodelIF2058:
	local[37]= NIL;
irtmodelIF2059:
	w = local[37];
	if (local[29]==NIL) goto irtmodelIF2078;
	local[33]= argv[0];
	local[34]= fqv[150];
	local[35]= fqv[431];
	local[36]= NIL;
	ctx->vsp=local+37;
	w=(pointer)SEND(ctx,4,local+33); /*send*/
	local[33]= fqv[432];
	goto irtmodelIF2079;
irtmodelIF2078:
	if (local[24]==NIL) goto irtmodelIF2080;
	local[33]= fqv[405];
	w = local[24];
	if (memq(local[33],w)!=NIL) goto irtmodelIF2080;
	if (loadglobal(fqv[385])==NIL) goto irtmodelIF2080;
	local[33]= loadglobal(fqv[385]);
	local[34]= fqv[386];
	local[35]= fqv[406];
	ctx->vsp=local+36;
	w=(pointer)SEND(ctx,3,local+33); /*send*/
	local[33]= w;
	goto irtmodelIF2081;
irtmodelIF2080:
	local[33]= NIL;
irtmodelIF2081:
	local[33]= argv[0];
	local[34]= fqv[150];
	local[35]= fqv[290];
	local[36]= NIL;
	ctx->vsp=local+37;
	w=(pointer)SEND(ctx,4,local+33); /*send*/
	local[33]= (pointer)get_sym_func(fqv[34]);
	local[34]= argv[0];
	local[35]= loadglobal(fqv[376]);
	local[36]= fqv[433];
	local[37]= local[26];
	local[38]= fqv[357];
	local[39]= local[11];
	local[40]= fqv[409];
	local[41]= local[5];
	local[42]= fqv[335];
	local[43]= local[6];
	local[44]= fqv[434];
	local[45]= local[13];
	local[46]= fqv[340];
	local[47]= local[24];
	local[48]= local[30];
	ctx->vsp=local+49;
	w=(pointer)APPLY(ctx,16,local+33); /*apply*/
	if (local[24]==NIL) goto irtmodelIF2082;
	if (loadglobal(fqv[385])==NIL) goto irtmodelIF2082;
	local[33]= loadglobal(fqv[385]);
	local[34]= fqv[435];
	local[35]= fqv[406];
	local[36]= NIL;
	local[37]= fqv[190];
	local[38]= NIL;
	ctx->vsp=local+39;
	w=(pointer)SEND(ctx,6,local+33); /*send*/
	local[33]= argv[0];
	local[34]= fqv[436];
	ctx->vsp=local+35;
	w=(pointer)SEND(ctx,2,local+33); /*send*/
	w=local[12];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car==NIL) goto irtmodelIF2084;
	local[33]= makeint((eusinteger_t)0L);
	local[34]= local[12];
	ctx->vsp=local+35;
	w=(pointer)LENGTH(ctx,1,local+34); /*length*/
	local[34]= w;
irtmodelWHL2086:
	local[35]= local[33];
	w = local[34];
	if ((eusinteger_t)local[35] >= (eusinteger_t)w) goto irtmodelWHX2087;
	local[35]= local[4];
	local[36]= local[33];
	ctx->vsp=local+37;
	w=(pointer)ELT(ctx,2,local+35); /*elt*/
	local[35]= w;
	local[36]= loadglobal(fqv[437]);
	local[37]= fqv[438];
	local[38]= fqv[190];
	local[39]= NIL;
	local[40]= fqv[439];
	local[41]= makeint((eusinteger_t)100L);
	ctx->vsp=local+42;
	w=(pointer)SENDMESSAGE(ctx,7,local+35); /*send-message*/
	local[35]= local[12];
	local[36]= local[33];
	ctx->vsp=local+37;
	w=(pointer)ELT(ctx,2,local+35); /*elt*/
	local[35]= w;
	local[36]= fqv[438];
	local[37]= fqv[190];
	local[38]= NIL;
	local[39]= fqv[189];
	local[40]= fqv[440];
	ctx->vsp=local+41;
	w=(pointer)SEND(ctx,6,local+35); /*send*/
	local[35]= local[33];
	ctx->vsp=local+36;
	w=(pointer)ADD1(ctx,1,local+35); /*1+*/
	local[33] = w;
	goto irtmodelWHL2086;
irtmodelWHX2087:
	local[35]= NIL;
irtmodelBLK2088:
	w = NIL;
	local[33]= w;
	goto irtmodelIF2085;
irtmodelIF2084:
	local[33]= NIL;
irtmodelIF2085:
	local[33]= NIL;
	local[34]= argv[0];
	local[35]= fqv[184];
	local[36]= fqv[431];
	ctx->vsp=local+37;
	w=(pointer)SEND(ctx,3,local+34); /*send*/
	local[34]= w;
irtmodelWHL2089:
	if (local[34]==NIL) goto irtmodelWHX2090;
	w=local[34];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[35]= (w)->c.cons.car;
	w=local[34];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[34] = (w)->c.cons.cdr;
	w = local[35];
	local[33] = w;
	local[35]= (pointer)get_sym_func(fqv[288]);
	w=local[33];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[36]= (w)->c.cons.car;
	local[37]= fqv[438];
	local[38]= fqv[190];
	local[39]= NIL;
	w=local[33];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[40]= (w)->c.cons.cdr;
	ctx->vsp=local+41;
	w=(pointer)APPLY(ctx,6,local+35); /*apply*/
	goto irtmodelWHL2089;
irtmodelWHX2090:
	local[35]= NIL;
irtmodelBLK2091:
	w = NIL;
	local[33]= fqv[441];
	w = local[24];
	if (memq(local[33],w)!=NIL) goto irtmodelIF2092;
	local[33]= loadglobal(fqv[385]);
	local[34]= fqv[386];
	local[35]= fqv[190];
	ctx->vsp=local+36;
	w=(pointer)SEND(ctx,3,local+33); /*send*/
	local[33]= w;
	goto irtmodelIF2093;
irtmodelIF2092:
	local[33]= NIL;
irtmodelIF2093:
	ctx->vsp=local+33;
	w=(*ftab[46])(ctx,0,local+33,&ftab[46],fqv[442]); /*x::window-main-one*/
	local[33]= w;
	goto irtmodelIF2083;
irtmodelIF2082:
	local[33]= NIL;
irtmodelIF2083:
	local[33]= argv[0];
	local[34]= fqv[150];
	local[35]= fqv[431];
	local[36]= NIL;
	ctx->vsp=local+37;
	w=(pointer)SEND(ctx,4,local+33); /*send*/
	local[33]= fqv[408];
irtmodelIF2079:
	w = local[33];
	local[0]= w;
irtmodelBLK1941:
	ctx->vsp=local; return(local[0]);}

/*:inverse-kinematics*/
static pointer irtmodelM2094cascaded_link_inverse_kinematics(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtmodelRST2096:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[443], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY2097;
	local[1] = makeint((eusinteger_t)50L);
irtmodelKEY2097:
	if (n & (1<<1)) goto irtmodelKEY2098;
	local[2] = NIL;
irtmodelKEY2098:
	if (n & (1<<2)) goto irtmodelKEY2099;
	local[3] = NIL;
irtmodelKEY2099:
	if (n & (1<<3)) goto irtmodelKEY2100;
	local[4] = NIL;
irtmodelKEY2100:
	if (n & (1<<4)) goto irtmodelKEY2101;
	local[5] = T;
irtmodelKEY2101:
	if (n & (1<<5)) goto irtmodelKEY2102;
	local[6] = T;
irtmodelKEY2102:
	if (n & (1<<6)) goto irtmodelKEY2103;
	w = local[3];
	if (!!iscons(w)) goto irtmodelCON2105;
	local[23]= T;
	goto irtmodelCON2104;
irtmodelCON2105:
	local[23]= local[3];
	ctx->vsp=local+24;
	w=(pointer)LENGTH(ctx,1,local+23); /*length*/
	local[23]= w;
	local[24]= fqv[209];
	local[25]= T;
	ctx->vsp=local+26;
	w=(*ftab[31])(ctx,3,local+23,&ftab[31],fqv[208]); /*make-list*/
	local[23]= w;
	goto irtmodelCON2104;
irtmodelCON2106:
	local[23]= NIL;
irtmodelCON2104:
	local[7] = local[23];
irtmodelKEY2103:
	if (n & (1<<7)) goto irtmodelKEY2107;
	w = local[3];
	if (!!iscons(w)) goto irtmodelCON2109;
	local[23]= T;
	goto irtmodelCON2108;
irtmodelCON2109:
	local[23]= local[3];
	ctx->vsp=local+24;
	w=(pointer)LENGTH(ctx,1,local+23); /*length*/
	local[23]= w;
	local[24]= fqv[209];
	local[25]= T;
	ctx->vsp=local+26;
	w=(*ftab[31])(ctx,3,local+23,&ftab[31],fqv[208]); /*make-list*/
	local[23]= w;
	goto irtmodelCON2108;
irtmodelCON2110:
	local[23]= NIL;
irtmodelCON2108:
	local[8] = local[23];
irtmodelKEY2107:
	if (n & (1<<8)) goto irtmodelKEY2111;
	local[9] = NIL;
irtmodelKEY2111:
	if (n & (1<<9)) goto irtmodelKEY2112;
	w = local[3];
	if (!!iscons(w)) goto irtmodelCON2114;
	local[23]= makeint((eusinteger_t)1L);
	goto irtmodelCON2113;
irtmodelCON2114:
	local[23]= local[3];
	ctx->vsp=local+24;
	w=(pointer)LENGTH(ctx,1,local+23); /*length*/
	local[23]= w;
	local[24]= fqv[209];
	local[25]= makeint((eusinteger_t)1L);
	ctx->vsp=local+26;
	w=(*ftab[31])(ctx,3,local+23,&ftab[31],fqv[208]); /*make-list*/
	local[23]= w;
	goto irtmodelCON2113;
irtmodelCON2115:
	local[23]= NIL;
irtmodelCON2113:
	local[10] = local[23];
irtmodelKEY2112:
	if (n & (1<<10)) goto irtmodelKEY2116;
	w = local[3];
	if (!!iscons(w)) goto irtmodelCON2118;
	local[23]= makeint((eusinteger_t)1L);
	ctx->vsp=local+24;
	w=(*ftab[6])(ctx,1,local+23,&ftab[6],fqv[48]); /*deg2rad*/
	local[23]= w;
	goto irtmodelCON2117;
irtmodelCON2118:
	local[23]= local[3];
	ctx->vsp=local+24;
	w=(pointer)LENGTH(ctx,1,local+23); /*length*/
	local[23]= w;
	local[24]= fqv[209];
	local[25]= makeint((eusinteger_t)1L);
	ctx->vsp=local+26;
	w=(*ftab[6])(ctx,1,local+25,&ftab[6],fqv[48]); /*deg2rad*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(*ftab[31])(ctx,3,local+23,&ftab[31],fqv[208]); /*make-list*/
	local[23]= w;
	goto irtmodelCON2117;
irtmodelCON2119:
	local[23]= NIL;
irtmodelCON2117:
	local[11] = local[23];
irtmodelKEY2116:
	if (n & (1<<11)) goto irtmodelKEY2120;
	local[12] = NIL;
irtmodelKEY2120:
	if (n & (1<<12)) goto irtmodelKEY2121;
	local[13] = makeflt(1.0000000000000000000000e+00);
irtmodelKEY2121:
	if (n & (1<<13)) goto irtmodelKEY2122;
	local[14] = NIL;
irtmodelKEY2122:
	if (n & (1<<14)) goto irtmodelKEY2123;
	local[15] = NIL;
irtmodelKEY2123:
	if (n & (1<<15)) goto irtmodelKEY2124;
	local[16] = fqv[33];
irtmodelKEY2124:
	if (n & (1<<16)) goto irtmodelKEY2125;
	local[17] = NIL;
irtmodelKEY2125:
	if (n & (1<<17)) goto irtmodelKEY2126;
	local[18] = fqv[444];
irtmodelKEY2126:
	if (n & (1<<18)) goto irtmodelKEY2127;
	local[19] = makeflt(5.0000000000000000000000e-01);
irtmodelKEY2127:
	if (n & (1<<19)) goto irtmodelKEY2128;
	local[20] = NIL;
irtmodelKEY2128:
	if (n & (1<<20)) goto irtmodelKEY2129;
	local[21] = NIL;
irtmodelKEY2129:
	if (n & (1<<21)) goto irtmodelKEY2130;
	local[22] = NIL;
irtmodelKEY2130:
	w = argv[2];
	if (!iscons(w)) goto irtmodelOR2133;
	local[23]= argv[2];
	ctx->vsp=local+24;
	w=(*ftab[43])(ctx,1,local+23,&ftab[43],fqv[320]); /*functionp*/
	if (w!=NIL) goto irtmodelOR2133;
	goto irtmodelIF2131;
irtmodelOR2133:
	local[23]= argv[2];
	ctx->vsp=local+24;
	w=(pointer)LIST(ctx,1,local+23); /*list*/
	argv[2] = w;
	local[23]= argv[2];
	goto irtmodelIF2132;
irtmodelIF2131:
	local[23]= NIL;
irtmodelIF2132:
	local[23]= makeint((eusinteger_t)0L);
	local[24]= local[12];
	ctx->vsp=local+25;
	w=(*ftab[43])(ctx,1,local+24,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelIF2134;
	local[24]= local[12];
	local[25]= local[2];
	ctx->vsp=local+26;
	w=(pointer)FUNCALL(ctx,2,local+24); /*funcall*/
	local[24]= w;
	goto irtmodelIF2135;
irtmodelIF2134:
	local[24]= argv[0];
	local[25]= fqv[197];
	local[26]= local[2];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,3,local+24); /*send*/
	local[24]= w;
irtmodelIF2135:
	local[25]= local[24];
	local[26]= fqv[198];
	ctx->vsp=local+27;
	w=(*ftab[18])(ctx,2,local+25,&ftab[18],fqv[128]); /*send-all*/
	local[25]= w;
	local[26]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+27;
	w=(pointer)APPEND(ctx,2,local+25); /*append*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(*ftab[47])(ctx,1,local+25,&ftab[47],fqv[445]); /*remove-duplicates*/
	local[25]= w;
	local[26]= fqv[20];
	ctx->vsp=local+27;
	w=(*ftab[18])(ctx,2,local+25,&ftab[18],fqv[128]); /*send-all*/
	local[25]= w;
	local[26]= argv[0];
	local[27]= fqv[214];
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,2,local+26); /*send*/
	if (w!=NIL) goto irtmodelIF2136;
	local[26]= argv[0];
	local[27]= fqv[153];
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,2,local+26); /*send*/
	local[26]= w;
	goto irtmodelIF2137;
irtmodelIF2136:
	local[26]= NIL;
irtmodelIF2137:
	local[27]= argv[2];
	local[28]= NIL;
	local[29]= NIL;
	local[30]= T;
	local[31]= local[24];
	local[32]= fqv[149];
	ctx->vsp=local+33;
	w=(*ftab[18])(ctx,2,local+31,&ftab[18],fqv[128]); /*send-all*/
	local[31]= w;
	local[32]= NIL;
	local[33]= NIL;
	local[34]= NIL;
	local[35]= NIL;
	local[36]= NIL;
	local[37]= NIL;
	local[38]= NIL;
	local[39]= NIL;
	local[40]= local[24];
	local[41]= fqv[149];
	local[42]= fqv[120];
	ctx->vsp=local+43;
	w=(*ftab[18])(ctx,3,local+40,&ftab[18],fqv[128]); /*send-all*/
	if (local[2]==NIL) goto irtmodelOR2140;
	if (local[3]==NIL) goto irtmodelOR2140;
	goto irtmodelIF2138;
irtmodelOR2140:
	local[40]= fqv[446];
	ctx->vsp=local+41;
	w=(*ftab[2])(ctx,1,local+40,&ftab[2],fqv[15]); /*warn*/
	w = T;
	ctx->vsp=local+40;
	local[0]=w;
	goto irtmodelBLK2095;
	goto irtmodelIF2139;
irtmodelIF2138:
	local[40]= NIL;
irtmodelIF2139:
	if (local[8]!=NIL) goto irtmodelIF2141;
	if (local[7]!=NIL) goto irtmodelIF2141;
	w = T;
	ctx->vsp=local+40;
	local[0]=w;
	goto irtmodelBLK2095;
	goto irtmodelIF2142;
irtmodelIF2141:
	local[40]= NIL;
irtmodelIF2142:
	if (local[18]==NIL) goto irtmodelIF2143;
	local[40]= NIL;
	local[41]= fqv[447];
	if (local[30]==NIL) goto irtmodelIF2145;
	local[42]= fqv[448];
	goto irtmodelIF2146;
irtmodelIF2145:
	local[42]= fqv[449];
irtmodelIF2146:
	local[43]= fqv[450];
	ctx->vsp=local+44;
	w=(pointer)LOCALTIME(ctx,0,local+44); /*unix:localtime*/
	local[44]= w;
	ctx->vsp=local+45;
	w=(pointer)ASCTIME(ctx,1,local+44); /*unix:asctime*/
	local[44]= w;
	ctx->vsp=local+45;
	w=(*ftab[48])(ctx,2,local+43,&ftab[48],fqv[451]); /*string-trim*/
	local[43]= w;
	local[44]= loadglobal(fqv[452]);
	ctx->vsp=local+45;
	w=(pointer)XFORMAT(ctx,5,local+40); /*format*/
	local[39] = w;
	local[40]= NIL;
	local[41]= fqv[453];
	local[42]= local[39];
	local[43]= local[2];
	ctx->vsp=local+44;
	w=(pointer)XFORMAT(ctx,4,local+40); /*format*/
	local[39] = w;
	local[40]= NIL;
	local[41]= fqv[454];
	local[42]= local[39];
	local[43]= local[3];
	ctx->vsp=local+44;
	w=(pointer)XFORMAT(ctx,4,local+40); /*format*/
	local[39] = w;
	local[40]= NIL;
	local[41]= fqv[455];
	local[42]= local[39];
	local[43]= local[7];
	local[44]= local[8];
	ctx->vsp=local+45;
	w=(pointer)XFORMAT(ctx,5,local+40); /*format*/
	local[39] = w;
	local[40]= NIL;
	local[41]= fqv[456];
	local[42]= local[39];
	local[43]= local[10];
	local[44]= local[11];
	local[45]= local[1];
	ctx->vsp=local+46;
	w=(pointer)XFORMAT(ctx,6,local+40); /*format*/
	local[39] = w;
	local[40]= fqv[457];
	local[41]= fqv[458];
	local[42]= fqv[459];
	ctx->vsp=local+43;
	local[43]= makeclosure(codevec,quotevec,irtmodelCLO2147,env,argv,local);
	local[44]= argv[2];
	ctx->vsp=local+45;
	w=(pointer)MAPCAR(ctx,2,local+43); /*mapcar*/
	local[43]= w;
	ctx->vsp=local+44;
	w=(pointer)LIST(ctx,1,local+43); /*list*/
	ctx->vsp=local+43;
	local[42]= cons(ctx,local[42],w);
	ctx->vsp=local+43;
	w=(pointer)LIST(ctx,1,local+42); /*list*/
	ctx->vsp=local+42;
	w = cons(ctx,local[41],w);
	ctx->vsp=local+41;
	local[37] = cons(ctx,local[40],w);
	local[40]= fqv[457];
	local[41]= fqv[460];
	local[42]= argv[0];
	local[43]= fqv[154];
	ctx->vsp=local+44;
	w=(pointer)SEND(ctx,2,local+42); /*send*/
	local[42]= w;
	ctx->vsp=local+43;
	w=(pointer)LIST(ctx,1,local+42); /*list*/
	ctx->vsp=local+42;
	w = cons(ctx,local[41],w);
	ctx->vsp=local+41;
	local[38] = cons(ctx,local[40],w);
	local[40]= local[38];
	goto irtmodelIF2144;
irtmodelIF2143:
	local[40]= NIL;
irtmodelIF2144:
	if (local[4]==NIL) goto irtmodelIF2148;
	w = local[4];
	if (!!iscons(w)) goto irtmodelIF2150;
	local[40]= local[4];
	ctx->vsp=local+41;
	w=(pointer)LIST(ctx,1,local+40); /*list*/
	local[4] = w;
	local[40]= local[4];
	goto irtmodelIF2151;
irtmodelIF2150:
	local[40]= NIL;
irtmodelIF2151:
	local[40]= fqv[405];
	w = local[4];
	if (memq(local[40],w)==NIL) goto irtmodelIF2152;
	local[40]= fqv[405];
	w = local[4];
	ctx->vsp=local+41;
	local[4] = cons(ctx,local[40],w);
	local[40]= local[4];
	goto irtmodelIF2153;
irtmodelIF2152:
	local[40]= NIL;
irtmodelIF2153:
	local[40]= fqv[441];
	w = local[4];
	if (memq(local[40],w)==NIL) goto irtmodelIF2154;
	local[40]= fqv[441];
	w = local[4];
	ctx->vsp=local+41;
	local[4] = cons(ctx,local[40],w);
	local[40]= local[4];
	goto irtmodelIF2155;
irtmodelIF2154:
	local[40]= NIL;
irtmodelIF2155:
	goto irtmodelIF2149;
irtmodelIF2148:
	local[40]= NIL;
irtmodelIF2149:
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!!iscons(w)) goto irtmodelIF2156;
	local[40]= local[2];
	ctx->vsp=local+41;
	w=(pointer)LIST(ctx,1,local+40); /*list*/
	local[2] = w;
	local[40]= local[2];
	goto irtmodelIF2157;
irtmodelIF2156:
	local[40]= NIL;
irtmodelIF2157:
	w = local[3];
	if (!!iscons(w)) goto irtmodelIF2158;
	local[40]= local[3];
	ctx->vsp=local+41;
	w=(pointer)LIST(ctx,1,local+40); /*list*/
	local[3] = w;
	local[40]= local[3];
	goto irtmodelIF2159;
irtmodelIF2158:
	local[40]= NIL;
irtmodelIF2159:
	w = local[7];
	if (!!iscons(w)) goto irtmodelIF2160;
	local[40]= local[7];
	ctx->vsp=local+41;
	w=(pointer)LIST(ctx,1,local+40); /*list*/
	local[7] = w;
	local[40]= local[7];
	goto irtmodelIF2161;
irtmodelIF2160:
	local[40]= NIL;
irtmodelIF2161:
	w = local[8];
	if (!!iscons(w)) goto irtmodelIF2162;
	local[40]= local[8];
	ctx->vsp=local+41;
	w=(pointer)LIST(ctx,1,local+40); /*list*/
	local[8] = w;
	local[40]= local[8];
	goto irtmodelIF2163;
irtmodelIF2162:
	local[40]= NIL;
irtmodelIF2163:
	w = local[10];
	if (!!iscons(w)) goto irtmodelIF2164;
	local[40]= local[10];
	ctx->vsp=local+41;
	w=(pointer)LIST(ctx,1,local+40); /*list*/
	local[10] = w;
	local[40]= local[10];
	goto irtmodelIF2165;
irtmodelIF2164:
	local[40]= NIL;
irtmodelIF2165:
	w = local[11];
	if (!!iscons(w)) goto irtmodelIF2166;
	local[40]= local[11];
	ctx->vsp=local+41;
	w=(pointer)LIST(ctx,1,local+40); /*list*/
	local[11] = w;
	local[40]= local[11];
	goto irtmodelIF2167;
irtmodelIF2166:
	local[40]= NIL;
irtmodelIF2167:
	if (local[21]==NIL) goto irtmodelIF2168;
	w = local[21];
	if (!iscons(w)) goto irtmodelOR2170;
	local[40]= local[21];
	ctx->vsp=local+41;
	w=(*ftab[43])(ctx,1,local+40,&ftab[43],fqv[320]); /*functionp*/
	if (w!=NIL) goto irtmodelOR2170;
	goto irtmodelIF2168;
irtmodelOR2170:
	local[40]= local[21];
	ctx->vsp=local+41;
	w=(pointer)LIST(ctx,1,local+40); /*list*/
	local[21] = w;
	local[40]= local[21];
	goto irtmodelIF2169;
irtmodelIF2168:
	local[40]= NIL;
irtmodelIF2169:
	if (local[22]==NIL) goto irtmodelIF2171;
	w = local[22];
	if (!iscons(w)) goto irtmodelOR2173;
	local[40]= local[22];
	ctx->vsp=local+41;
	w=(*ftab[43])(ctx,1,local+40,&ftab[43],fqv[320]); /*functionp*/
	if (w!=NIL) goto irtmodelOR2173;
	goto irtmodelIF2171;
irtmodelOR2173:
	local[40]= local[22];
	ctx->vsp=local+41;
	w=(pointer)LIST(ctx,1,local+40); /*list*/
	local[22] = w;
	local[40]= local[22];
	goto irtmodelIF2172;
irtmodelIF2171:
	local[40]= NIL;
irtmodelIF2172:
	local[40]= local[8];
	ctx->vsp=local+41;
	w=(pointer)LENGTH(ctx,1,local+40); /*length*/
	local[40]= w;
	local[41]= local[7];
	ctx->vsp=local+42;
	w=(pointer)LENGTH(ctx,1,local+41); /*length*/
	local[41]= w;
	local[42]= local[3];
	ctx->vsp=local+43;
	w=(pointer)LENGTH(ctx,1,local+42); /*length*/
	local[42]= w;
	local[43]= local[2];
	ctx->vsp=local+44;
	w=(pointer)LENGTH(ctx,1,local+43); /*length*/
	local[43]= w;
	local[44]= argv[2];
	ctx->vsp=local+45;
	w=(pointer)LENGTH(ctx,1,local+44); /*length*/
	local[44]= w;
	local[45]= local[10];
	ctx->vsp=local+46;
	w=(pointer)LENGTH(ctx,1,local+45); /*length*/
	local[45]= w;
	local[46]= local[11];
	ctx->vsp=local+47;
	w=(pointer)LENGTH(ctx,1,local+46); /*length*/
	local[46]= w;
	ctx->vsp=local+47;
	w=(pointer)NUMEQUAL(ctx,7,local+40); /*=*/
	if (w!=NIL) goto irtmodelIF2174;
	local[40]= fqv[461];
	local[41]= local[8];
	ctx->vsp=local+42;
	w=(pointer)LENGTH(ctx,1,local+41); /*length*/
	local[41]= w;
	local[42]= local[7];
	ctx->vsp=local+43;
	w=(pointer)LENGTH(ctx,1,local+42); /*length*/
	local[42]= w;
	local[43]= local[3];
	ctx->vsp=local+44;
	w=(pointer)LENGTH(ctx,1,local+43); /*length*/
	local[43]= w;
	local[44]= local[2];
	ctx->vsp=local+45;
	w=(pointer)LENGTH(ctx,1,local+44); /*length*/
	local[44]= w;
	local[45]= argv[2];
	ctx->vsp=local+46;
	w=(pointer)LENGTH(ctx,1,local+45); /*length*/
	local[45]= w;
	local[46]= local[10];
	ctx->vsp=local+47;
	w=(pointer)LENGTH(ctx,1,local+46); /*length*/
	local[46]= w;
	local[47]= local[11];
	ctx->vsp=local+48;
	w=(pointer)LENGTH(ctx,1,local+47); /*length*/
	local[47]= w;
	ctx->vsp=local+48;
	w=(*ftab[2])(ctx,8,local+40,&ftab[2],fqv[15]); /*warn*/
	w = T;
	ctx->vsp=local+40;
	local[0]=w;
	goto irtmodelBLK2095;
	goto irtmodelIF2175;
irtmodelIF2174:
	local[40]= NIL;
irtmodelIF2175:
	local[40]= local[21];
	ctx->vsp=local+41;
	w=(pointer)LENGTH(ctx,1,local+40); /*length*/
	local[40]= w;
	local[41]= local[22];
	ctx->vsp=local+42;
	w=(pointer)LENGTH(ctx,1,local+41); /*length*/
	if (w==local[40]) goto irtmodelIF2176;
	local[40]= fqv[462];
	local[41]= local[21];
	ctx->vsp=local+42;
	w=(pointer)LENGTH(ctx,1,local+41); /*length*/
	local[41]= w;
	local[42]= local[22];
	ctx->vsp=local+43;
	w=(pointer)LENGTH(ctx,1,local+42); /*length*/
	local[42]= w;
	ctx->vsp=local+43;
	w=(*ftab[2])(ctx,3,local+40,&ftab[2],fqv[15]); /*warn*/
	w = T;
	ctx->vsp=local+40;
	local[0]=w;
	goto irtmodelBLK2095;
	goto irtmodelIF2177;
irtmodelIF2176:
	local[40]= NIL;
irtmodelIF2177:
	ctx->vsp=local+40;
	local[40]= makeclosure(codevec,quotevec,irtmodelCLO2178,env,argv,local);
	local[41]= local[21];
	ctx->vsp=local+42;
	w=(pointer)MAPCAR(ctx,2,local+40); /*mapcar*/
	local[40]= w;
	local[41]= (pointer)get_sym_func(fqv[288]);
	local[42]= argv[0];
	local[43]= fqv[463];
	local[44]= fqv[335];
	local[45]= local[8];
	local[46]= fqv[409];
	local[47]= local[7];
	local[48]= fqv[464];
	if (local[17]!=NIL) goto irtmodelIF2179;
	if (local[14]==NIL) goto irtmodelIF2179;
	local[49]= argv[0];
	local[50]= fqv[210];
	local[51]= NIL;
	local[52]= local[16];
	ctx->vsp=local+53;
	w=(pointer)SEND(ctx,4,local+49); /*send*/
	local[49]= w;
	goto irtmodelIF2180;
irtmodelIF2179:
	local[49]= makeint((eusinteger_t)0L);
irtmodelIF2180:
	local[50]= (pointer)get_sym_func(fqv[322]);
	ctx->vsp=local+51;
	local[51]= makeclosure(codevec,quotevec,irtmodelCLO2181,env,argv,local);
	local[52]= local[40];
	ctx->vsp=local+53;
	w=(pointer)MAPCAR(ctx,2,local+51); /*mapcar*/
	local[51]= w;
	ctx->vsp=local+52;
	w=(*ftab[26])(ctx,2,local+50,&ftab[26],fqv[196]); /*reduce*/
	local[50]= w;
	ctx->vsp=local+51;
	w=(pointer)PLUS(ctx,2,local+49); /*+*/
	local[49]= w;
	local[50]= fqv[357];
	local[51]= local[24];
	local[52]= local[0];
	ctx->vsp=local+53;
	w=(pointer)APPLY(ctx,12,local+41); /*apply*/
	local[41]= w;
	local[42]= local[0];
	ctx->vsp=local+43;
	w=(pointer)NCONC(ctx,2,local+41); /*nconc*/
	local[32] = w;
	w = local[32];
	local[40]= argv[0];
	local[41]= fqv[404];
	local[42]= local[24];
	ctx->vsp=local+43;
	w=(pointer)SEND(ctx,3,local+40); /*send*/
	local[40]= local[18];
	w = fqv[465];
	if (memq(local[40],w)==NIL) goto irtmodelIF2182;
	local[40]= argv[0];
	local[41]= fqv[150];
	local[42]= fqv[420];
	local[43]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+44;
	local[44]= makeclosure(codevec,quotevec,irtmodelCLO2184,env,argv,local);
	local[45]= argv[2];
	ctx->vsp=local+46;
	w=(pointer)LENGTH(ctx,1,local+45); /*length*/
	local[45]= w;
	ctx->vsp=local+46;
	w=(*ftab[31])(ctx,1,local+45,&ftab[31],fqv[208]); /*make-list*/
	local[45]= w;
	ctx->vsp=local+46;
	w=(pointer)MAPCAR(ctx,2,local+44); /*mapcar*/
	local[43]= w;
	if (local[14]==NIL) goto irtmodelIF2185;
	local[44]= fqv[257];
	ctx->vsp=local+45;
	w=(pointer)LIST(ctx,1,local+44); /*list*/
	local[44]= w;
	ctx->vsp=local+45;
	w=(pointer)LIST(ctx,1,local+44); /*list*/
	local[44]= w;
	goto irtmodelIF2186;
irtmodelIF2185:
	local[44]= NIL;
irtmodelIF2186:
	local[45]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+46;
	local[46]= makeclosure(codevec,quotevec,irtmodelCLO2187,env,argv,local);
	local[47]= local[22];
	ctx->vsp=local+48;
	w=(pointer)LENGTH(ctx,1,local+47); /*length*/
	local[47]= w;
	ctx->vsp=local+48;
	w=(*ftab[31])(ctx,1,local+47,&ftab[31],fqv[208]); /*make-list*/
	local[47]= w;
	ctx->vsp=local+48;
	w=(pointer)MAPCAR(ctx,2,local+46); /*mapcar*/
	local[45]= w;
	ctx->vsp=local+46;
	w=(pointer)APPEND(ctx,3,local+43); /*append*/
	local[43]= w;
	ctx->vsp=local+44;
	w=(pointer)SEND(ctx,4,local+40); /*send*/
	local[40]= w;
	goto irtmodelIF2183;
irtmodelIF2182:
	local[40]= NIL;
irtmodelIF2183:
irtmodelWHL2188:
	local[40]= local[23];
	ctx->vsp=local+41;
	w=(pointer)ADD1(ctx,1,local+40); /*1+*/
	local[23] = w;
	local[40]= local[23];
	local[41]= local[1];
	ctx->vsp=local+42;
	w=(pointer)LESSP(ctx,2,local+40); /*<*/
	if (w==NIL) goto irtmodelWHX2189;
	ctx->vsp=local+40;
	local[40]= makeclosure(codevec,quotevec,irtmodelCLO2191,env,argv,local);
	local[41]= argv[2];
	ctx->vsp=local+42;
	w=(pointer)MAPCAR(ctx,2,local+40); /*mapcar*/
	local[40]= w;
	ctx->vsp=local+41;
	local[41]= makeclosure(codevec,quotevec,irtmodelCLO2192,env,argv,local);
	local[42]= local[3];
	local[43]= local[40];
	local[44]= local[8];
	ctx->vsp=local+45;
	w=(pointer)MAPCAR(ctx,4,local+41); /*mapcar*/
	local[41]= w;
	ctx->vsp=local+42;
	local[42]= makeclosure(codevec,quotevec,irtmodelCLO2193,env,argv,local);
	local[43]= local[3];
	local[44]= local[40];
	local[45]= local[7];
	ctx->vsp=local+46;
	w=(pointer)MAPCAR(ctx,4,local+42); /*mapcar*/
	local[42]= w;
	local[43]= (pointer)get_sym_func(fqv[288]);
	local[44]= argv[0];
	local[45]= fqv[466];
	local[46]= local[41];
	local[47]= local[42];
	local[48]= fqv[467];
	local[49]= local[40];
	local[50]= fqv[468];
	local[51]= local[19];
	local[52]= fqv[469];
	local[53]= local[1];
	local[54]= fqv[470];
	local[55]= local[23];
	local[56]= fqv[409];
	local[57]= local[7];
	local[58]= fqv[335];
	local[59]= local[8];
	local[60]= fqv[300];
	local[61]= local[3];
	local[62]= fqv[357];
	local[63]= local[24];
	local[64]= fqv[471];
	local[65]= local[10];
	local[66]= fqv[472];
	local[67]= local[11];
	local[68]= fqv[473];
	local[69]= local[21];
	local[70]= fqv[474];
	local[71]= local[22];
	local[72]= fqv[340];
	local[73]= local[4];
	local[74]= fqv[475];
	local[75]= local[32];
	local[76]= local[0];
	ctx->vsp=local+77;
	w=(pointer)APPLY(ctx,34,local+43); /*apply*/
	local[30] = w;
	local[43]= local[30];
	if (fqv[432]!=local[43]) goto irtmodelIF2194;
	local[30] = T;
	w = NIL;
	ctx->vsp=local+43;
	local[40]=w;
	goto irtmodelBLK2190;
	goto irtmodelIF2195;
irtmodelIF2194:
	local[43]= NIL;
irtmodelIF2195:
	w = local[43];
	goto irtmodelWHL2188;
irtmodelWHX2189:
	local[40]= NIL;
irtmodelBLK2190:
	if (local[14]==NIL) goto irtmodelIF2196;
	local[40]= argv[0];
	local[41]= fqv[332];
	ctx->vsp=local+42;
	w=(pointer)SEND(ctx,2,local+40); /*send*/
	local[40]= w;
	goto irtmodelIF2197;
irtmodelIF2196:
	local[40]= NIL;
irtmodelIF2197:
	ctx->vsp=local+40;
	local[40]= makeclosure(codevec,quotevec,irtmodelCLO2198,env,argv,local);
	local[41]= argv[2];
	ctx->vsp=local+42;
	w=(pointer)MAPCAR(ctx,2,local+40); /*mapcar*/
	local[40]= w;
	ctx->vsp=local+41;
	local[41]= makeclosure(codevec,quotevec,irtmodelCLO2199,env,argv,local);
	local[42]= local[3];
	local[43]= local[40];
	local[44]= local[8];
	ctx->vsp=local+45;
	w=(pointer)MAPCAR(ctx,4,local+41); /*mapcar*/
	local[28] = w;
	ctx->vsp=local+41;
	local[41]= makeclosure(codevec,quotevec,irtmodelCLO2200,env,argv,local);
	local[42]= local[3];
	local[43]= local[40];
	local[44]= local[7];
	ctx->vsp=local+45;
	w=(pointer)MAPCAR(ctx,4,local+41); /*mapcar*/
	local[29] = w;
	local[41]= argv[0];
	local[42]= fqv[414];
	local[43]= local[30];
	local[44]= local[28];
	local[45]= local[29];
	local[46]= local[7];
	local[47]= local[8];
	local[48]= local[10];
	local[49]= local[11];
	local[50]= local[13];
	local[51]= local[14];
	local[52]= local[15];
	local[53]= local[16];
	local[54]= fqv[332];
	local[55]= NIL;
	ctx->vsp=local+56;
	w=(pointer)SEND(ctx,15,local+41); /*send*/
	local[30] = w;
	w = local[30];
	ctx->vsp=local+40;
	local[40]= makeclosure(codevec,quotevec,irtmodelCLO2201,env,argv,local);
	local[41]= local[24];
	local[42]= local[31];
	ctx->vsp=local+43;
	w=(pointer)MAPCAR(ctx,3,local+40); /*mapcar*/
	local[40]= argv[0];
	local[41]= fqv[404];
	local[42]= local[24];
	ctx->vsp=local+43;
	w=(pointer)SEND(ctx,3,local+40); /*send*/
	if (local[20]==NIL) goto irtmodelIF2202;
	local[40]= argv[0];
	local[41]= fqv[476];
	ctx->vsp=local+42;
	w=(pointer)SEND(ctx,2,local+40); /*send*/
	local[33] = w;
	local[40]= local[33];
	goto irtmodelIF2203;
irtmodelIF2202:
	local[40]= NIL;
irtmodelIF2203:
	local[40]= local[30];
	if (local[40]!=NIL) goto irtmodelOR2205;
	local[40]= ((local[6])==NIL?T:NIL);
irtmodelOR2205:
	if (local[40]==NIL) goto irtmodelAND2204;
	local[40]= ((local[33])==NIL?T:NIL);
irtmodelAND2204:
	local[30] = local[40];
	local[40]= local[18];
	w = fqv[477];
	if (memq(local[40],w)!=NIL) goto irtmodelOR2208;
	local[40]= local[18];
	w = fqv[478];
	if (memq(local[40],w)==NIL) goto irtmodelAND2209;
	if (local[30]!=NIL) goto irtmodelAND2209;
	goto irtmodelOR2208;
irtmodelAND2209:
	goto irtmodelIF2206;
irtmodelOR2208:
	local[40]= NIL;
	local[41]= fqv[479];
	ctx->vsp=local+42;
	w=(pointer)GETPID(ctx,0,local+42); /*unix:getpid*/
	local[42]= w;
	ctx->vsp=local+43;
	w=(pointer)XFORMAT(ctx,3,local+40); /*format*/
	local[34] = w;
	ctx->vsp=local+40;
	w=(pointer)LOCALTIME(ctx,0,local+40); /*unix:localtime*/
	local[40]= w;
	ctx->vsp=local+41;
	w=(pointer)GETTIMEOFDAY(ctx,0,local+41); /*unix:gettimeofday*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[41]= (w)->c.cons.car;
	local[42]= makeint((eusinteger_t)48L);
	local[43]= makeint((eusinteger_t)32L);
	local[44]= NIL;
	local[45]= fqv[480];
	local[46]= argv[0];
	ctx->vsp=local+47;
	w=(pointer)GETCLASS(ctx,1,local+46); /*class*/
	local[46]= w;
	local[47]= fqv[3];
	ctx->vsp=local+48;
	w=(pointer)SEND(ctx,2,local+46); /*send*/
	local[46]= w;
	local[47]= makeint((eusinteger_t)1900L);
	local[48]= local[40];
	local[49]= makeint((eusinteger_t)5L);
	ctx->vsp=local+50;
	w=(pointer)ELT(ctx,2,local+48); /*elt*/
	local[48]= w;
	ctx->vsp=local+49;
	w=(pointer)PLUS(ctx,2,local+47); /*+*/
	local[47]= w;
	local[48]= makeint((eusinteger_t)1L);
	local[49]= local[40];
	local[50]= makeint((eusinteger_t)4L);
	ctx->vsp=local+51;
	w=(pointer)ELT(ctx,2,local+49); /*elt*/
	local[49]= w;
	ctx->vsp=local+50;
	w=(pointer)PLUS(ctx,2,local+48); /*+*/
	local[48]= w;
	local[49]= local[40];
	local[50]= makeint((eusinteger_t)3L);
	ctx->vsp=local+51;
	w=(pointer)ELT(ctx,2,local+49); /*elt*/
	local[49]= w;
	local[50]= local[40];
	local[51]= makeint((eusinteger_t)2L);
	ctx->vsp=local+52;
	w=(pointer)ELT(ctx,2,local+50); /*elt*/
	local[50]= w;
	local[51]= local[40];
	local[52]= makeint((eusinteger_t)1L);
	ctx->vsp=local+53;
	w=(pointer)ELT(ctx,2,local+51); /*elt*/
	local[51]= w;
	local[52]= local[40];
	local[53]= makeint((eusinteger_t)0L);
	ctx->vsp=local+54;
	w=(pointer)ELT(ctx,2,local+52); /*elt*/
	local[52]= w;
	local[53]= NIL;
	local[54]= fqv[481];
	local[55]= local[41];
	ctx->vsp=local+56;
	w=(pointer)XFORMAT(ctx,3,local+53); /*format*/
	local[53]= w;
	local[54]= makeint((eusinteger_t)0L);
	local[55]= makeint((eusinteger_t)2L);
	ctx->vsp=local+56;
	w=(pointer)SUBSEQ(ctx,3,local+53); /*subseq*/
	local[53]= w;
	local[54]= NIL;
	local[55]= fqv[482];
	local[56]= local[41];
	ctx->vsp=local+57;
	w=(pointer)XFORMAT(ctx,3,local+54); /*format*/
	local[54]= w;
	local[55]= makeint((eusinteger_t)2L);
	local[56]= makeint((eusinteger_t)4L);
	ctx->vsp=local+57;
	w=(pointer)SUBSEQ(ctx,3,local+54); /*subseq*/
	local[54]= w;
	local[55]= NIL;
	local[56]= fqv[483];
	local[57]= local[41];
	ctx->vsp=local+58;
	w=(pointer)XFORMAT(ctx,3,local+55); /*format*/
	local[55]= w;
	local[56]= makeint((eusinteger_t)4L);
	ctx->vsp=local+57;
	w=(pointer)SUBSEQ(ctx,2,local+55); /*subseq*/
	local[55]= w;
	ctx->vsp=local+56;
	w=(pointer)XFORMAT(ctx,12,local+44); /*format*/
	local[44]= w;
	ctx->vsp=local+45;
	w=(*ftab[49])(ctx,3,local+42,&ftab[49],fqv[484]); /*substitute*/
	local[36] = w;
	local[40]= NIL;
	local[41]= fqv[485];
	local[42]= local[34];
	local[43]= local[36];
	if (local[30]==NIL) goto irtmodelIF2210;
	local[44]= fqv[486];
	goto irtmodelIF2211;
irtmodelIF2210:
	local[44]= fqv[487];
irtmodelIF2211:
	ctx->vsp=local+45;
	w=(pointer)XFORMAT(ctx,5,local+40); /*format*/
	local[35] = w;
	local[40]= local[34];
	ctx->vsp=local+41;
	w=(*ftab[50])(ctx,1,local+40,&ftab[50],fqv[488]); /*unix:mkdir*/
	local[40]= local[35];
	local[41]= fqv[178];
	local[42]= fqv[179];
	ctx->vsp=local+43;
	w=(*ftab[25])(ctx,3,local+40,&ftab[25],fqv[180]); /*open*/
	local[40]= w;
	ctx->vsp=local+41;
	w = makeclosure(codevec,quotevec,irtmodelUWP2212,env,argv,local);
	local[41]=(pointer)(ctx->protfp); local[42]=w;
	ctx->protfp=(struct protectframe *)(local+41);
	local[43]= local[40];
	local[44]= fqv[489];
	local[45]= local[39];
	ctx->vsp=local+46;
	w=(pointer)XFORMAT(ctx,3,local+43); /*format*/
	local[43]= local[40];
	local[44]= local[37];
	ctx->vsp=local+45;
	w=(*ftab[51])(ctx,2,local+43,&ftab[51],fqv[490]); /*dump-structure*/
	local[43]= local[40];
	local[44]= local[38];
	ctx->vsp=local+45;
	w=(*ftab[51])(ctx,2,local+43,&ftab[51],fqv[490]); /*dump-structure*/
	ctx->vsp=local+43;
	irtmodelUWP2212(ctx,0,local+43,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[40]= local[18];
	w = fqv[491];
	if (memq(local[40],w)==NIL) goto irtmodelIF2213;
	local[40]= NIL;
	local[41]= fqv[492];
	local[42]= local[34];
	local[43]= local[36];
	if (local[30]==NIL) goto irtmodelIF2215;
	local[44]= fqv[493];
	goto irtmodelIF2216;
irtmodelIF2215:
	local[44]= fqv[494];
irtmodelIF2216:
	ctx->vsp=local+45;
	w=(pointer)XFORMAT(ctx,5,local+40); /*format*/
	local[40]= w;
	local[41]= fqv[178];
	local[42]= fqv[179];
	ctx->vsp=local+43;
	w=(*ftab[25])(ctx,3,local+40,&ftab[25],fqv[180]); /*open*/
	local[40]= w;
	ctx->vsp=local+41;
	w = makeclosure(codevec,quotevec,irtmodelUWP2217,env,argv,local);
	local[41]=(pointer)(ctx->protfp); local[42]=w;
	ctx->protfp=(struct protectframe *)(local+41);
	local[43]= local[40];
	local[44]= fqv[495];
	local[45]= local[23];
	ctx->vsp=local+46;
	w=(pointer)XFORMAT(ctx,3,local+43); /*format*/
	local[43]= local[40];
	local[44]= fqv[496];
	ctx->vsp=local+45;
	local[45]= makeclosure(codevec,quotevec,irtmodelCLO2218,env,argv,local);
	local[46]= argv[0];
	local[47]= fqv[184];
	local[48]= fqv[420];
	ctx->vsp=local+49;
	w=(pointer)SEND(ctx,3,local+46); /*send*/
	local[46]= w;
	ctx->vsp=local+47;
	w=(pointer)MAPCAR(ctx,2,local+45); /*mapcar*/
	local[45]= w;
	ctx->vsp=local+46;
	w=(pointer)XFORMAT(ctx,3,local+43); /*format*/
	local[43]= local[40];
	local[44]= fqv[497];
	local[45]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+46;
	local[46]= makeclosure(codevec,quotevec,irtmodelCLO2219,env,argv,local);
	local[47]= local[10];
	local[48]= local[11];
	ctx->vsp=local+49;
	w=(pointer)MAPCAR(ctx,3,local+46); /*mapcar*/
	local[45]= w;
	if (local[14]==NIL) goto irtmodelIF2220;
	local[46]= fqv[257];
	local[47]= makeflt(1.0000000000000000208167e-03);
	local[48]= local[13];
	ctx->vsp=local+49;
	w=(pointer)TIMES(ctx,2,local+47); /***/
	local[47]= w;
	ctx->vsp=local+48;
	w=(pointer)LIST(ctx,2,local+46); /*list*/
	local[46]= w;
	ctx->vsp=local+47;
	w=(pointer)LIST(ctx,1,local+46); /*list*/
	local[46]= w;
	goto irtmodelIF2221;
irtmodelIF2220:
	local[46]= NIL;
irtmodelIF2221:
	ctx->vsp=local+47;
	w=(pointer)APPEND(ctx,2,local+45); /*append*/
	local[45]= w;
	ctx->vsp=local+46;
	w=(pointer)XFORMAT(ctx,3,local+43); /*format*/
	local[43]= argv[0];
	local[44]= fqv[420];
	ctx->vsp=local+45;
	w=(*ftab[52])(ctx,2,local+43,&ftab[52],fqv[498]); /*remprop*/
	ctx->vsp=local+43;
	irtmodelUWP2217(ctx,0,local+43,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[40]= w;
	goto irtmodelIF2214;
irtmodelIF2213:
	local[40]= NIL;
irtmodelIF2214:
	goto irtmodelIF2207;
irtmodelIF2206:
	local[40]= NIL;
irtmodelIF2207:
	if (local[30]==NIL) goto irtmodelIF2222;
	local[40]= argv[0];
	local[41]= fqv[154];
	ctx->vsp=local+42;
	w=(pointer)SEND(ctx,2,local+40); /*send*/
	local[40]= w;
	goto irtmodelIF2223;
irtmodelIF2222:
	if (local[5]==NIL) goto irtmodelIF2224;
	local[40]= fqv[499];
	ctx->vsp=local+41;
	w=(*ftab[2])(ctx,1,local+40,&ftab[2],fqv[15]); /*warn*/
	local[40]= makeint((eusinteger_t)0L);
	local[41]= local[3];
	ctx->vsp=local+42;
	w=(pointer)LENGTH(ctx,1,local+41); /*length*/
	local[41]= w;
irtmodelWHL2226:
	local[42]= local[40];
	w = local[41];
	if ((eusinteger_t)local[42] >= (eusinteger_t)w) goto irtmodelWHX2227;
	local[42]= fqv[500];
	local[43]= local[28];
	local[44]= local[40];
	ctx->vsp=local+45;
	w=(pointer)ELT(ctx,2,local+43); /*elt*/
	local[43]= w;
	local[44]= local[28];
	local[45]= local[40];
	ctx->vsp=local+46;
	w=(pointer)ELT(ctx,2,local+44); /*elt*/
	local[44]= w;
	ctx->vsp=local+45;
	w=(pointer)VNORM(ctx,1,local+44); /*norm*/
	local[44]= w;
	local[45]= local[10];
	local[46]= local[40];
	ctx->vsp=local+47;
	w=(pointer)ELT(ctx,2,local+45); /*elt*/
	local[45]= w;
	ctx->vsp=local+46;
	w=(*ftab[2])(ctx,4,local+42,&ftab[2],fqv[15]); /*warn*/
	local[42]= fqv[501];
	local[43]= local[29];
	local[44]= local[40];
	ctx->vsp=local+45;
	w=(pointer)ELT(ctx,2,local+43); /*elt*/
	local[43]= w;
	local[44]= local[29];
	local[45]= local[40];
	ctx->vsp=local+46;
	w=(pointer)ELT(ctx,2,local+44); /*elt*/
	local[44]= w;
	ctx->vsp=local+45;
	w=(pointer)VNORM(ctx,1,local+44); /*norm*/
	local[44]= w;
	local[45]= local[11];
	local[46]= local[40];
	ctx->vsp=local+47;
	w=(pointer)ELT(ctx,2,local+45); /*elt*/
	local[45]= w;
	ctx->vsp=local+46;
	w=(*ftab[2])(ctx,4,local+42,&ftab[2],fqv[15]); /*warn*/
	local[42]= local[40];
	ctx->vsp=local+43;
	w=(pointer)ADD1(ctx,1,local+42); /*1+*/
	local[40] = w;
	goto irtmodelWHL2226;
irtmodelWHX2227:
	local[42]= NIL;
irtmodelBLK2228:
	w = NIL;
	if (local[14]==NIL) goto irtmodelIF2229;
	local[40]= argv[0];
	local[41]= fqv[502];
	local[42]= local[14];
	local[43]= fqv[331];
	local[44]= local[15];
	local[45]= fqv[335];
	local[46]= local[16];
	local[47]= fqv[332];
	local[48]= NIL;
	ctx->vsp=local+49;
	w=(pointer)SEND(ctx,9,local+40); /*send*/
	local[40]= w;
	local[41]= fqv[503];
	local[42]= local[40];
	local[43]= local[40];
	ctx->vsp=local+44;
	w=(pointer)VNORM(ctx,1,local+43); /*norm*/
	local[43]= w;
	local[44]= local[13];
	ctx->vsp=local+45;
	w=(*ftab[2])(ctx,4,local+41,&ftab[2],fqv[15]); /*warn*/
	local[40]= w;
	goto irtmodelIF2230;
irtmodelIF2229:
	local[40]= NIL;
irtmodelIF2230:
	local[40]= fqv[504];
	local[41]= argv[0];
irtmodelWHL2231:
	local[42]= local[41];
	local[43]= fqv[214];
	ctx->vsp=local+44;
	w=(pointer)SEND(ctx,2,local+42); /*send*/
	if (w==NIL) goto irtmodelWHX2232;
	local[42]= local[41];
	local[43]= fqv[214];
	ctx->vsp=local+44;
	w=(pointer)SEND(ctx,2,local+42); /*send*/
	local[41] = w;
	goto irtmodelWHL2231;
irtmodelWHX2232:
	local[42]= NIL;
irtmodelBLK2233:
	w = local[41];
	local[41]= w;
	local[42]= fqv[122];
	ctx->vsp=local+43;
	w=(pointer)SEND(ctx,2,local+41); /*send*/
	local[41]= w;
	ctx->vsp=local+42;
	w=(*ftab[2])(ctx,2,local+40,&ftab[2],fqv[15]); /*warn*/
	local[40]= fqv[505];
	local[41]= local[25];
	ctx->vsp=local+42;
	w=(*ftab[2])(ctx,2,local+40,&ftab[2],fqv[15]); /*warn*/
	if (local[20]==NIL) goto irtmodelIF2234;
	local[40]= fqv[506];
	local[41]= local[33];
	ctx->vsp=local+42;
	w=(*ftab[2])(ctx,2,local+40,&ftab[2],fqv[15]); /*warn*/
	local[40]= w;
	goto irtmodelIF2235;
irtmodelIF2234:
	local[40]= NIL;
irtmodelIF2235:
	local[40]= fqv[507];
	local[41]= argv[2];
	ctx->vsp=local+42;
	w=(pointer)LIST(ctx,1,local+41); /*list*/
	local[41]= w;
	local[42]= local[0];
	ctx->vsp=local+43;
	w=(pointer)APPEND(ctx,2,local+41); /*append*/
	local[41]= w;
	ctx->vsp=local+42;
	w=(*ftab[2])(ctx,2,local+40,&ftab[2],fqv[15]); /*warn*/
	if (local[18]==NIL) goto irtmodelIF2236;
	local[40]= NIL;
	local[41]= NIL;
	local[42]= NIL;
	local[43]= NIL;
	local[44]= NIL;
	ctx->vsp=local+45;
	local[45]= makeclosure(codevec,quotevec,irtmodelFLET2238,env,argv,local);
	ctx->vsp=local+46;
	local[46]= makeclosure(codevec,quotevec,irtmodelFLET2239,env,argv,local);
	ctx->vsp=local+47;
	local[47]= makeclosure(codevec,quotevec,irtmodelFLET2240,env,argv,local);
	ctx->vsp=local+48;
	local[48]= makeclosure(codevec,quotevec,irtmodelFLET2241,env,argv,local);
	ctx->vsp=local+49;
	local[49]= makeclosure(codevec,quotevec,irtmodelFLET2242,env,argv,local);
	ctx->vsp=local+50;
	local[50]= makeclosure(codevec,quotevec,irtmodelFLET2243,env,argv,local);
	local[51]= local[0];
	w = local[50];
	ctx->vsp=local+52;
	w=irtmodelFLET2243(ctx,1,local+51,w);
	local[41] = w;
	local[51]= makeint((eusinteger_t)0L);
	local[52]= local[41];
	ctx->vsp=local+53;
	w=(pointer)LENGTH(ctx,1,local+52); /*length*/
	local[52]= w;
	local[53]= makeint((eusinteger_t)2L);
	ctx->vsp=local+54;
	w=(pointer)QUOTIENT(ctx,2,local+52); /*/*/
	local[52]= w;
irtmodelWHL2244:
	local[53]= local[51];
	w = local[52];
	if ((eusinteger_t)local[53] >= (eusinteger_t)w) goto irtmodelWHX2245;
	local[53]= local[41];
	local[54]= makeint((eusinteger_t)2L);
	{ eusinteger_t i,j;
		j=intval(local[51]); i=intval(local[54]);
		local[54]=(makeint(i * j));}
	ctx->vsp=local+55;
	w=(pointer)ELT(ctx,2,local+53); /*elt*/
	local[53]= w;
	if (fqv[300]==local[53]) goto irtmodelIF2247;
	local[53]= local[41];
	local[54]= makeint((eusinteger_t)1L);
	local[55]= makeint((eusinteger_t)2L);
	{ eusinteger_t i,j;
		j=intval(local[51]); i=intval(local[55]);
		local[55]=(makeint(i * j));}
	w = local[55];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[54]= (pointer)((eusinteger_t)local[54] + (eusinteger_t)w);
	w = local[46];
	ctx->vsp=local+55;
	w=irtmodelFLET2239(ctx,2,local+53,w);
	local[53]= w;
	goto irtmodelIF2248;
irtmodelIF2247:
	local[53]= NIL;
irtmodelIF2248:
	local[53]= local[51];
	ctx->vsp=local+54;
	w=(pointer)ADD1(ctx,1,local+53); /*1+*/
	local[51] = w;
	goto irtmodelWHL2244;
irtmodelWHX2245:
	local[53]= NIL;
irtmodelBLK2246:
	w = NIL;
	local[51]= makeint((eusinteger_t)0L);
	local[52]= local[41];
	ctx->vsp=local+53;
	w=(pointer)LENGTH(ctx,1,local+52); /*length*/
	local[52]= w;
irtmodelWHL2249:
	local[53]= local[51];
	w = local[52];
	if ((eusinteger_t)local[53] >= (eusinteger_t)w) goto irtmodelWHX2250;
	local[53]= local[41];
	local[54]= local[51];
	w = local[47];
	ctx->vsp=local+55;
	w=irtmodelFLET2240(ctx,2,local+53,w);
	local[53]= local[51];
	ctx->vsp=local+54;
	w=(pointer)ADD1(ctx,1,local+53); /*1+*/
	local[51] = w;
	goto irtmodelWHL2249;
irtmodelWHX2250:
	local[53]= NIL;
irtmodelBLK2251:
	w = NIL;
	local[51]= makeint((eusinteger_t)0L);
	local[52]= fqv[300];
	local[53]= local[41];
	ctx->vsp=local+54;
	w=(*ftab[53])(ctx,2,local+52,&ftab[53],fqv[508]); /*count*/
	local[52]= w;
irtmodelWHL2252:
	local[53]= local[51];
	w = local[52];
	if ((eusinteger_t)local[53] >= (eusinteger_t)w) goto irtmodelWHX2253;
	local[53]= fqv[300];
	local[54]= local[41];
	local[55]= fqv[509];
	local[56]= local[51];
	ctx->vsp=local+57;
	w=(pointer)ADD1(ctx,1,local+56); /*1+*/
	local[56]= w;
	ctx->vsp=local+57;
	w=(*ftab[32])(ctx,4,local+53,&ftab[32],fqv[212]); /*position*/
	local[40] = w;
	if (local[40]==NIL) goto irtmodelIF2255;
	local[53]= local[41];
	local[54]= local[40];
	local[55]= makeint((eusinteger_t)1L);
	ctx->vsp=local+56;
	w=(pointer)PLUS(ctx,2,local+54); /*+*/
	local[54]= w;
	ctx->vsp=local+55;
	w=(pointer)ELT(ctx,2,local+53); /*elt*/
	if (!!iscons(w)) goto irtmodelCON2258;
	local[53]= local[41];
	local[54]= local[40];
	local[55]= makeint((eusinteger_t)1L);
	ctx->vsp=local+56;
	w=(pointer)PLUS(ctx,2,local+54); /*+*/
	local[54]= w;
	local[55]= local[41];
	local[56]= local[40];
	local[57]= makeint((eusinteger_t)1L);
	ctx->vsp=local+58;
	w=(pointer)PLUS(ctx,2,local+56); /*+*/
	local[56]= w;
	ctx->vsp=local+57;
	w=(pointer)ELT(ctx,2,local+55); /*elt*/
	local[55]= w;
	w = local[49];
	ctx->vsp=local+56;
	w=irtmodelFLET2242(ctx,1,local+55,w);
	local[55]= w;
	ctx->vsp=local+56;
	w=(pointer)SETELT(ctx,3,local+53); /*setelt*/
	local[53]= w;
	goto irtmodelCON2257;
irtmodelCON2258:
	local[53]= local[41];
	local[54]= local[40];
	local[55]= makeint((eusinteger_t)1L);
	ctx->vsp=local+56;
	w=(pointer)PLUS(ctx,2,local+54); /*+*/
	local[54]= w;
	local[55]= fqv[510];
	ctx->vsp=local+56;
	local[56]= makeclosure(codevec,quotevec,irtmodelCLO2260,env,argv,local);
	local[57]= local[41];
	local[58]= local[40];
	local[59]= makeint((eusinteger_t)1L);
	ctx->vsp=local+60;
	w=(pointer)PLUS(ctx,2,local+58); /*+*/
	local[58]= w;
	ctx->vsp=local+59;
	w=(pointer)ELT(ctx,2,local+57); /*elt*/
	local[57]= w;
	ctx->vsp=local+58;
	w=(pointer)MAPCAR(ctx,2,local+56); /*mapcar*/
	local[56]= w;
	ctx->vsp=local+57;
	w=(pointer)APPEND(ctx,2,local+55); /*append*/
	local[55]= w;
	ctx->vsp=local+56;
	w=(pointer)SETELT(ctx,3,local+53); /*setelt*/
	local[53]= w;
	goto irtmodelCON2257;
irtmodelCON2259:
	local[53]= NIL;
irtmodelCON2257:
	goto irtmodelIF2256;
irtmodelIF2255:
	local[53]= NIL;
irtmodelIF2256:
	local[53]= local[51];
	ctx->vsp=local+54;
	w=(pointer)ADD1(ctx,1,local+53); /*1+*/
	local[51] = w;
	goto irtmodelWHL2252;
irtmodelWHX2253:
	local[53]= NIL;
irtmodelBLK2254:
	w = NIL;
	local[51]= fqv[511];
	local[52]= argv[0];
	ctx->vsp=local+53;
	w=(pointer)GETCLASS(ctx,1,local+52); /*class*/
	local[52]= w;
	local[53]= fqv[3];
	ctx->vsp=local+54;
	w=(pointer)SEND(ctx,2,local+52); /*send*/
	local[52]= w;
	local[53]= fqv[36];
	ctx->vsp=local+54;
	w=(pointer)LIST(ctx,1,local+53); /*list*/
	ctx->vsp=local+53;
	w = cons(ctx,local[52],w);
	ctx->vsp=local+52;
	local[42] = cons(ctx,local[51],w);
	local[51]= fqv[512];
	local[52]= fqv[288];
	local[53]= fqv[513];
	local[54]= fqv[159];
	local[55]= fqv[86];
	local[56]= fqv[514];
	local[57]= argv[0];
	local[58]= fqv[514];
	ctx->vsp=local+59;
	w=(pointer)SEND(ctx,2,local+57); /*send*/
	local[57]= w;
	ctx->vsp=local+58;
	w=(pointer)LIST(ctx,1,local+57); /*list*/
	ctx->vsp=local+57;
	w = cons(ctx,local[56],w);
	ctx->vsp=local+56;
	local[55]= cons(ctx,local[55],w);
	ctx->vsp=local+56;
	w=(pointer)LIST(ctx,1,local+55); /*list*/
	ctx->vsp=local+55;
	w = cons(ctx,local[54],w);
	ctx->vsp=local+54;
	w = cons(ctx,local[53],w);
	ctx->vsp=local+53;
	local[52]= cons(ctx,local[52],w);
	local[53]= fqv[515];
	local[54]= fqv[516];
	local[55]= fqv[517];
	local[56]= fqv[518];
	local[57]= fqv[519];
	ctx->vsp=local+58;
	w=(pointer)LIST(ctx,1,local+57); /*list*/
	ctx->vsp=local+57;
	local[56]= cons(ctx,local[56],w);
	local[57]= fqv[520];
	local[58]= fqv[518];
	local[59]= fqv[20];
	local[60]= fqv[519];
	local[61]= local[9];
	ctx->vsp=local+62;
	w=(pointer)LIST(ctx,1,local+61); /*list*/
	ctx->vsp=local+61;
	w = cons(ctx,local[60],w);
	ctx->vsp=local+60;
	w = cons(ctx,local[59],w);
	ctx->vsp=local+59;
	w = cons(ctx,local[58],w);
	ctx->vsp=local+58;
	local[57]= cons(ctx,local[57],w);
	ctx->vsp=local+58;
	w=(pointer)LIST(ctx,1,local+57); /*list*/
	ctx->vsp=local+57;
	w = cons(ctx,local[56],w);
	ctx->vsp=local+56;
	local[55]= cons(ctx,local[55],w);
	ctx->vsp=local+56;
	w=(pointer)LIST(ctx,1,local+55); /*list*/
	ctx->vsp=local+55;
	local[54]= cons(ctx,local[54],w);
	local[55]= fqv[521];
	ctx->vsp=local+56;
	local[56]= makeclosure(codevec,quotevec,irtmodelCLO2261,env,argv,local);
	local[57]= local[24];
	local[58]= fqv[198];
	ctx->vsp=local+59;
	w=(*ftab[18])(ctx,2,local+57,&ftab[18],fqv[128]); /*send-all*/
	local[57]= w;
	local[58]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+59;
	w=(pointer)APPEND(ctx,2,local+57); /*append*/
	local[57]= w;
	ctx->vsp=local+58;
	w=(*ftab[47])(ctx,1,local+57,&ftab[47],fqv[445]); /*remove-duplicates*/
	local[57]= w;
	local[58]= fqv[3];
	ctx->vsp=local+59;
	w=(*ftab[18])(ctx,2,local+57,&ftab[18],fqv[128]); /*send-all*/
	local[57]= w;
	ctx->vsp=local+58;
	w=(pointer)MAPCAR(ctx,2,local+56); /*mapcar*/
	ctx->vsp=local+56;
	local[55]= cons(ctx,local[55],w);
	local[56]= fqv[459];
	local[57]= local[25];
	ctx->vsp=local+58;
	w=(pointer)LIST(ctx,2,local+56); /*list*/
	local[56]= w;
	ctx->vsp=local+57;
	w=(pointer)LIST(ctx,1,local+56); /*list*/
	ctx->vsp=local+56;
	w = cons(ctx,local[55],w);
	ctx->vsp=local+55;
	w = cons(ctx,local[54],w);
	ctx->vsp=local+54;
	local[53]= cons(ctx,local[53],w);
	local[54]= fqv[522];
	local[55]= fqv[521];
	local[56]= fqv[513];
	ctx->vsp=local+57;
	w=(pointer)LIST(ctx,1,local+56); /*list*/
	ctx->vsp=local+56;
	local[55]= cons(ctx,local[55],w);
	ctx->vsp=local+56;
	w=(pointer)LIST(ctx,1,local+55); /*list*/
	ctx->vsp=local+55;
	local[54]= cons(ctx,local[54],w);
	ctx->vsp=local+55;
	w=(pointer)LIST(ctx,1,local+54); /*list*/
	ctx->vsp=local+54;
	w = cons(ctx,local[53],w);
	ctx->vsp=local+53;
	w = cons(ctx,local[52],w);
	ctx->vsp=local+52;
	local[43] = cons(ctx,local[51],w);
	local[51]= fqv[523];
	ctx->vsp=local+52;
	local[52]= makeclosure(codevec,quotevec,irtmodelCLO2262,env,argv,local);
	local[53]= argv[2];
	ctx->vsp=local+54;
	w=(pointer)MAPCAR(ctx,2,local+52); /*mapcar*/
	local[52]= w;
	local[53]= NIL;
	ctx->vsp=local+54;
	w=(pointer)APPEND(ctx,2,local+52); /*append*/
	local[52]= w;
	ctx->vsp=local+53;
	w=(pointer)LIST(ctx,1,local+52); /*list*/
	local[52]= w;
	local[53]= fqv[524];
	local[54]= NIL;
	local[55]= fqv[340];
	local[56]= T;
	ctx->vsp=local+57;
	w=(pointer)LIST(ctx,4,local+53); /*list*/
	local[53]= w;
	local[54]= local[41];
	ctx->vsp=local+55;
	w=(pointer)APPEND(ctx,4,local+51); /*append*/
	local[44] = w;
	local[51]= local[44];
	local[52]= makeint((eusinteger_t)1L);
	local[53]= fqv[525];
	local[54]= local[44];
	local[55]= makeint((eusinteger_t)1L);
	ctx->vsp=local+56;
	w=(pointer)ELT(ctx,2,local+54); /*elt*/
	local[54]= w;
	ctx->vsp=local+55;
	w=(pointer)APPEND(ctx,2,local+53); /*append*/
	local[53]= w;
	ctx->vsp=local+54;
	w=(pointer)SETELT(ctx,3,local+51); /*setelt*/
	local[45]= fqv[526];
	local[46]= fqv[527];
	local[47]= fqv[513];
	local[48]= local[42];
	ctx->vsp=local+49;
	w=(pointer)LIST(ctx,1,local+48); /*list*/
	ctx->vsp=local+48;
	local[47]= cons(ctx,local[47],w);
	ctx->vsp=local+48;
	w=(pointer)LIST(ctx,1,local+47); /*list*/
	local[47]= w;
	local[48]= local[43];
	local[49]= fqv[520];
	local[50]= fqv[513];
	local[51]= fqv[528];
	local[52]= local[44];
	ctx->vsp=local+53;
	w=(pointer)LIST(ctx,1,local+52); /*list*/
	ctx->vsp=local+52;
	w = cons(ctx,local[51],w);
	ctx->vsp=local+51;
	w = cons(ctx,local[50],w);
	ctx->vsp=local+50;
	local[49]= cons(ctx,local[49],w);
	ctx->vsp=local+50;
	w=(pointer)LIST(ctx,1,local+49); /*list*/
	ctx->vsp=local+49;
	w = cons(ctx,local[48],w);
	ctx->vsp=local+48;
	w = cons(ctx,local[47],w);
	ctx->vsp=local+47;
	local[46]= cons(ctx,local[46],w);
	ctx->vsp=local+47;
	w=(*ftab[2])(ctx,2,local+45,&ftab[2],fqv[15]); /*warn*/
	local[45]= fqv[529];
	local[46]= local[35];
	ctx->vsp=local+47;
	w=(*ftab[2])(ctx,2,local+45,&ftab[2],fqv[15]); /*warn*/
	local[45]= fqv[530];
	local[46]= local[35];
	ctx->vsp=local+47;
	w=(*ftab[2])(ctx,2,local+45,&ftab[2],fqv[15]); /*warn*/
	local[45]= local[35];
	local[46]= fqv[178];
	local[47]= fqv[179];
	local[48]= fqv[531];
	local[49]= fqv[532];
	ctx->vsp=local+50;
	w=(*ftab[25])(ctx,5,local+45,&ftab[25],fqv[180]); /*open*/
	local[45]= w;
	ctx->vsp=local+46;
	w = makeclosure(codevec,quotevec,irtmodelUWP2263,env,argv,local);
	local[46]=(pointer)(ctx->protfp); local[47]=w;
	ctx->protfp=(struct protectframe *)(local+46);
	local[48]= local[45];
	local[49]= fqv[533];
	local[50]= local[36];
	local[51]= local[42];
	local[52]= local[43];
	ctx->vsp=local+53;
	w=(pointer)XFORMAT(ctx,5,local+48); /*format*/
	local[48]= local[45];
	local[49]= fqv[534];
	local[50]= local[36];
	local[51]= local[44];
	ctx->vsp=local+52;
	w=(pointer)XFORMAT(ctx,4,local+48); /*format*/
	local[48]= local[45];
	local[49]= fqv[535];
	local[50]= local[36];
	ctx->vsp=local+51;
	w=(pointer)XFORMAT(ctx,3,local+48); /*format*/
	local[48]= local[45];
	local[49]= fqv[536];
	local[50]= local[36];
	ctx->vsp=local+51;
	w=(pointer)XFORMAT(ctx,3,local+48); /*format*/
	local[48]= local[45];
	local[49]= fqv[537];
	ctx->vsp=local+50;
	w=(pointer)XFORMAT(ctx,2,local+48); /*format*/
	local[48]= local[45];
	local[49]= fqv[538];
	local[50]= local[28];
	local[51]= local[29];
	ctx->vsp=local+52;
	w=(pointer)XFORMAT(ctx,4,local+48); /*format*/
	if (local[14]==NIL) goto irtmodelIF2264;
	local[48]= local[45];
	local[49]= fqv[539];
	local[50]= argv[0];
	local[51]= fqv[502];
	local[52]= local[14];
	local[53]= fqv[331];
	local[54]= local[15];
	local[55]= fqv[335];
	local[56]= local[16];
	local[57]= fqv[332];
	local[58]= NIL;
	ctx->vsp=local+59;
	w=(pointer)SEND(ctx,9,local+50); /*send*/
	local[50]= w;
	ctx->vsp=local+51;
	w=(pointer)XFORMAT(ctx,3,local+48); /*format*/
	local[48]= w;
	goto irtmodelIF2265;
irtmodelIF2264:
	local[48]= NIL;
irtmodelIF2265:
	local[48]= local[45];
	local[49]= fqv[540];
	ctx->vsp=local+50;
	w=(pointer)XFORMAT(ctx,2,local+48); /*format*/
	ctx->vsp=local+48;
	irtmodelUWP2263(ctx,0,local+48,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[40]= w;
	goto irtmodelIF2237;
irtmodelIF2236:
	local[40]= NIL;
irtmodelIF2237:
	goto irtmodelIF2225;
irtmodelIF2224:
	local[40]= NIL;
irtmodelIF2225:
	ctx->vsp=local+40;
	local[40]= makeclosure(codevec,quotevec,irtmodelCLO2266,env,argv,local);
	local[41]= local[24];
	local[42]= fqv[198];
	ctx->vsp=local+43;
	w=(*ftab[18])(ctx,2,local+41,&ftab[18],fqv[128]); /*send-all*/
	local[41]= w;
	local[42]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+43;
	w=(pointer)APPEND(ctx,2,local+41); /*append*/
	local[41]= w;
	ctx->vsp=local+42;
	w=(*ftab[47])(ctx,1,local+41,&ftab[47],fqv[445]); /*remove-duplicates*/
	local[41]= w;
	local[42]= local[25];
	ctx->vsp=local+43;
	w=(pointer)MAPC(ctx,3,local+40); /*mapc*/
	if (local[26]==NIL) goto irtmodelIF2267;
	local[40]= argv[0];
	local[41]= fqv[159];
	local[42]= local[26];
	ctx->vsp=local+43;
	w=(pointer)SEND(ctx,3,local+40); /*send*/
	local[40]= w;
	goto irtmodelIF2268;
irtmodelIF2267:
	local[40]= NIL;
irtmodelIF2268:
	local[40]= NIL;
irtmodelIF2223:
	w = local[40];
	local[0]= w;
irtmodelBLK2095:
	ctx->vsp=local; return(local[0]);}

/*:ik-convergence-check*/
static pointer irtmodelM2269cascaded_link_ik_convergence_check(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<13) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[541], &argv[13], n-13, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY2271;
	local[0] = T;
irtmodelKEY2271:
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
irtmodelWHL2272:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto irtmodelWHX2273;
	local[3]= argv[2];
	if (local[3]==NIL) goto irtmodelAND2275;
	local[3]= argv[6];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	if (w==NIL) goto irtmodelIF2276;
	local[3]= argv[3];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)VNORM(ctx,1,local+3); /*norm*/
	local[3]= w;
	local[4]= argv[7];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LESSP(ctx,2,local+3); /*<*/
	local[3]= w;
	goto irtmodelIF2277;
irtmodelIF2276:
	local[3]= T;
irtmodelIF2277:
	if (local[3]==NIL) goto irtmodelAND2275;
	local[3]= argv[5];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	if (w==NIL) goto irtmodelIF2278;
	local[3]= argv[4];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)VNORM(ctx,1,local+3); /*norm*/
	local[3]= w;
	local[4]= argv[8];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LESSP(ctx,2,local+3); /*<*/
	local[3]= w;
	goto irtmodelIF2279;
irtmodelIF2278:
	local[3]= T;
irtmodelIF2279:
irtmodelAND2275:
	argv[2] = local[3];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto irtmodelWHL2272;
irtmodelWHX2273:
	local[3]= NIL;
irtmodelBLK2274:
	w = NIL;
	if (argv[10]==NIL) goto irtmodelIF2280;
	local[1]= argv[2];
	if (local[1]==NIL) goto irtmodelAND2282;
	local[1]= argv[0];
	local[2]= fqv[542];
	local[3]= argv[9];
	local[4]= argv[10];
	local[5]= fqv[331];
	local[6]= argv[11];
	local[7]= fqv[335];
	local[8]= argv[12];
	local[9]= fqv[332];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,10,local+1); /*send*/
	local[1]= w;
irtmodelAND2282:
	argv[2] = local[1];
	local[1]= argv[2];
	goto irtmodelIF2281;
irtmodelIF2280:
	local[1]= NIL;
irtmodelIF2281:
	w = argv[2];
	local[0]= w;
irtmodelBLK2270:
	ctx->vsp=local; return(local[0]);}

/*:calc-vel-from-pos*/
static pointer irtmodelM2283cascaded_link_calc_vel_from_pos(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
irtmodelRST2285:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-4);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[543], &argv[4], n-4, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY2286;
	local[1] = makeflt(1.0000000000000000000000e+02);
irtmodelKEY2286:
	if (n & (1<<1)) goto irtmodelKEY2287;
	local[6]= loadglobal(fqv[5]);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,2,local+6); /*instantiate*/
	local[2] = w;
irtmodelKEY2287:
	if (n & (1<<2)) goto irtmodelKEY2288;
	local[6]= loadglobal(fqv[5]);
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,2,local+6); /*instantiate*/
	local[3] = w;
irtmodelKEY2288:
	if (n & (1<<3)) goto irtmodelKEY2289;
	local[6]= loadglobal(fqv[5]);
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,2,local+6); /*instantiate*/
	local[4] = w;
irtmodelKEY2289:
	if (n & (1<<4)) goto irtmodelKEY2290;
	local[6]= loadglobal(fqv[5]);
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,2,local+6); /*instantiate*/
	local[5] = w;
irtmodelKEY2290:
	local[6]= NIL;
	local[7]= argv[2];
	ctx->vsp=local+8;
	w=(pointer)VNORM(ctx,1,local+7); /*norm*/
	local[7]= w;
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)GREATERP(ctx,2,local+7); /*>*/
	if (w==NIL) goto irtmodelIF2291;
	local[7]= local[1];
	local[8]= argv[2];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(*ftab[4])(ctx,2,local+8,&ftab[4],fqv[26]); /*normalize-vector*/
	local[8]= w;
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,3,local+7); /*scale*/
	argv[2] = w;
	local[7]= argv[2];
	goto irtmodelIF2292;
irtmodelIF2291:
	local[7]= NIL;
irtmodelIF2292:
	local[7]= makeflt(1.0000000000000000208167e-03);
	local[8]= argv[2];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,3,local+7); /*scale*/
	argv[2] = w;
	local[7]= argv[2];
	local[8]= argv[3];
	local[9]= local[2];
	local[10]= local[3];
	local[11]= local[4];
	ctx->vsp=local+12;
	w=(pointer)irtmodelF735calc_dif_with_axis(ctx,5,local+7); /*calc-dif-with-axis*/
	local[6] = w;
	w = local[6];
	local[0]= w;
irtmodelBLK2284:
	ctx->vsp=local; return(local[0]);}

/*:calc-vel-from-rot*/
static pointer irtmodelM2293cascaded_link_calc_vel_from_rot(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
irtmodelRST2295:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-4);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[544], &argv[4], n-4, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY2296;
	local[1] = makeflt(5.0000000000000000000000e-01);
irtmodelKEY2296:
	if (n & (1<<1)) goto irtmodelKEY2297;
	local[6]= loadglobal(fqv[5]);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,2,local+6); /*instantiate*/
	local[2] = w;
irtmodelKEY2297:
	if (n & (1<<2)) goto irtmodelKEY2298;
	local[6]= loadglobal(fqv[5]);
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,2,local+6); /*instantiate*/
	local[3] = w;
irtmodelKEY2298:
	if (n & (1<<3)) goto irtmodelKEY2299;
	local[6]= loadglobal(fqv[5]);
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,2,local+6); /*instantiate*/
	local[4] = w;
irtmodelKEY2299:
	if (n & (1<<4)) goto irtmodelKEY2300;
	local[6]= loadglobal(fqv[5]);
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,2,local+6); /*instantiate*/
	local[5] = w;
irtmodelKEY2300:
	local[6]= NIL;
	local[7]= argv[2];
	ctx->vsp=local+8;
	w=(pointer)VNORM(ctx,1,local+7); /*norm*/
	local[7]= w;
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)GREATERP(ctx,2,local+7); /*>*/
	if (w==NIL) goto irtmodelIF2301;
	local[7]= local[1];
	local[8]= argv[2];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(*ftab[4])(ctx,2,local+8,&ftab[4],fqv[26]); /*normalize-vector*/
	local[8]= w;
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,3,local+7); /*scale*/
	argv[2] = w;
	local[7]= argv[2];
	goto irtmodelIF2302;
irtmodelIF2301:
	local[7]= NIL;
irtmodelIF2302:
	local[7]= argv[2];
	local[8]= argv[3];
	local[9]= local[2];
	local[10]= local[3];
	local[11]= local[4];
	ctx->vsp=local+12;
	w=(pointer)irtmodelF735calc_dif_with_axis(ctx,5,local+7); /*calc-dif-with-axis*/
	local[6] = w;
	w = local[6];
	local[0]= w;
irtmodelBLK2294:
	ctx->vsp=local; return(local[0]);}

/*:collision-check-pairs*/
static pointer irtmodelM2303cascaded_link_collision_check_pairs(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[545], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY2305;
	w=argv[0]->c.obj.iv[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)irtmodelF734all_child_links(ctx,1,local+2); /*all-child-links*/
	ctx->vsp=local+2;
	local[0] = cons(ctx,local[1],w);
irtmodelKEY2305:
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
irtmodelWHL2306:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	if (local[2]==NIL) goto irtmodelWHX2307;
	local[4]= NIL;
	local[5]= local[2];
	local[6]= fqv[546];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= local[2];
	local[7]= fqv[547];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= local[2];
	local[8]= fqv[133];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= local[2];
	local[9]= fqv[214];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)APPEND(ctx,3,local+5); /*append*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[54])(ctx,2,local+4,&ftab[54],fqv[548]); /*remove*/
	local[3] = w;
	local[4]= NIL;
	local[5]= local[0];
irtmodelWHL2309:
	if (local[5]==NIL) goto irtmodelWHX2310;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= local[4];
	w = local[3];
	if (memq(local[6],w)!=NIL) goto irtmodelIF2312;
	local[6]= local[2];
	w = local[4];
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	w = local[1];
	ctx->vsp=local+7;
	local[1] = cons(ctx,local[6],w);
	local[6]= local[1];
	goto irtmodelIF2313;
irtmodelIF2312:
	local[6]= NIL;
irtmodelIF2313:
	goto irtmodelWHL2309;
irtmodelWHX2310:
	local[6]= NIL;
irtmodelBLK2311:
	w = NIL;
	goto irtmodelWHL2306;
irtmodelWHX2307:
	local[4]= NIL;
irtmodelBLK2308:
	w = local[1];
	local[0]= w;
irtmodelBLK2304:
	ctx->vsp=local; return(local[0]);}

/*:self-collision-check*/
static pointer irtmodelM2314cascaded_link_self_collision_check(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[549], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY2316;
	local[0] = fqv[550];
irtmodelKEY2316:
	if (n & (1<<1)) goto irtmodelKEY2317;
	local[3]= argv[0];
	local[4]= fqv[551];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[1] = w;
irtmodelKEY2317:
	if (n & (1<<2)) goto irtmodelKEY2318;
	local[2] = fqv[164];
irtmodelKEY2318:
	local[3]= NIL;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= NIL;
	local[6]= NIL;
	local[7]= local[1];
irtmodelWHL2319:
	if (local[7]==NIL) goto irtmodelWHX2320;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= fqv[143];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	if (w==NIL) goto irtmodelIF2322;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.cdr;
	local[9]= fqv[143];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	if (w==NIL) goto irtmodelIF2322;
	local[8]= local[2];
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.cdr;
	ctx->vsp=local+11;
	w=(pointer)FUNCALL(ctx,3,local+8); /*funcall*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(*ftab[24])(ctx,2,local+8,&ftab[24],fqv[171]); /*/=*/
	local[8]= w;
	if (local[8]==NIL) goto irtmodelIF2324;
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[4] = w;
	local[9]= local[0];
	if (fqv[552]!=local[9]) goto irtmodelIF2326;
	w = local[6];
	ctx->vsp=local+9;
	local[0]=w;
	goto irtmodelBLK2315;
	goto irtmodelIF2327;
irtmodelIF2326:
	local[9]= local[6];
	w = local[3];
	ctx->vsp=local+10;
	local[3] = cons(ctx,local[9],w);
	local[9]= local[3];
irtmodelIF2327:
	goto irtmodelIF2325;
irtmodelIF2324:
	local[9]= NIL;
irtmodelIF2325:
	w = local[9];
	local[8]= w;
	goto irtmodelIF2323;
irtmodelIF2322:
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= fqv[143];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	if (w!=NIL) goto irtmodelIF2328;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(*ftab[16])(ctx,2,local+8,&ftab[16],fqv[124]); /*member*/
	if (w!=NIL) goto irtmodelIF2328;
	local[8]= makeint((eusinteger_t)3L);
	local[9]= fqv[553];
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= fqv[3];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= fqv[143];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[5])(ctx,4,local+8,&ftab[5],fqv[44]); /*warning-message*/
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w = local[5];
	ctx->vsp=local+9;
	local[5] = cons(ctx,local[8],w);
	local[8]= local[5];
	goto irtmodelIF2329;
irtmodelIF2328:
	local[8]= NIL;
irtmodelIF2329:
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.cdr;
	local[9]= fqv[143];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	if (w!=NIL) goto irtmodelIF2330;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.cdr;
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(*ftab[16])(ctx,2,local+8,&ftab[16],fqv[124]); /*member*/
	if (w!=NIL) goto irtmodelIF2330;
	local[8]= makeint((eusinteger_t)3L);
	local[9]= fqv[554];
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.cdr;
	local[11]= fqv[3];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.cdr;
	local[12]= fqv[143];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[5])(ctx,4,local+8,&ftab[5],fqv[44]); /*warning-message*/
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.cdr;
	w = local[5];
	ctx->vsp=local+9;
	local[5] = cons(ctx,local[8],w);
	local[8]= local[5];
	goto irtmodelIF2331;
irtmodelIF2330:
	local[8]= NIL;
irtmodelIF2331:
irtmodelIF2323:
	goto irtmodelWHL2319;
irtmodelWHX2320:
	local[8]= NIL;
irtmodelBLK2321:
	w = NIL;
	w = local[3];
	local[0]= w;
irtmodelBLK2315:
	ctx->vsp=local; return(local[0]);}

/*:calc-grasp-matrix*/
static pointer irtmodelM2332cascaded_link_calc_grasp_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[555], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY2334;
	local[2]= makeint((eusinteger_t)6L);
	local[3]= makeint((eusinteger_t)6L);
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	{ eusinteger_t i,j;
		j=intval(w); i=intval(local[3]);
		local[3]=(makeint(i * j));}
	ctx->vsp=local+4;
	w=(*ftab[23])(ctx,2,local+2,&ftab[23],fqv[166]); /*make-matrix*/
	local[0] = w;
irtmodelKEY2334:
	if (n & (1<<1)) goto irtmodelKEY2335;
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtmodelCLO2336,env,argv,local);
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[1] = w;
irtmodelKEY2335:
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtmodelCLO2337,env,argv,local);
	local[3]= argv[2];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)MAPCAR(ctx,3,local+2); /*mapcar*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
irtmodelWHL2338:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto irtmodelWHX2339;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)3L);
irtmodelWHL2341:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto irtmodelWHX2342;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)3L);
irtmodelWHL2344:
	local[9]= local[7];
	w = local[8];
	if ((eusinteger_t)local[9] >= (eusinteger_t)w) goto irtmodelWHX2345;
	local[9]= local[0];
	local[10]= local[5];
	local[11]= local[3];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)6L)); i=intval(local[11]);
		local[11]=(makeint(i * j));}
	w = local[7];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[11]= (pointer)((eusinteger_t)local[11] + (eusinteger_t)w);
	local[12]= local[1];
	local[13]= local[3];
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= local[5];
	local[14]= local[7];
	ctx->vsp=local+15;
	w=(pointer)AREF(ctx,3,local+12); /*aref*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)ASET(ctx,4,local+9); /*aset*/
	local[9]= local[0];
	local[10]= makeint((eusinteger_t)3L);
	w = local[5];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[10]= (pointer)((eusinteger_t)local[10] + (eusinteger_t)w);
	local[11]= local[3];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)6L)); i=intval(local[11]);
		local[11]=(makeint(i * j));}
	local[12]= makeint((eusinteger_t)3L);
	w = local[7];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	w = (pointer)((eusinteger_t)local[12] + (eusinteger_t)w);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[11]= (pointer)((eusinteger_t)local[11] + (eusinteger_t)w);
	local[12]= local[1];
	local[13]= local[3];
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= local[5];
	local[14]= local[7];
	ctx->vsp=local+15;
	w=(pointer)AREF(ctx,3,local+12); /*aref*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)ASET(ctx,4,local+9); /*aset*/
	local[9]= local[0];
	local[10]= makeint((eusinteger_t)3L);
	w = local[5];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[10]= (pointer)((eusinteger_t)local[10] + (eusinteger_t)w);
	local[11]= local[3];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)6L)); i=intval(local[11]);
		local[11]=(makeint(i * j));}
	w = local[7];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[11]= (pointer)((eusinteger_t)local[11] + (eusinteger_t)w);
	local[12]= local[2];
	local[13]= local[3];
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= local[5];
	local[14]= local[7];
	ctx->vsp=local+15;
	w=(pointer)AREF(ctx,3,local+12); /*aref*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)ASET(ctx,4,local+9); /*aset*/
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[7] = w;
	goto irtmodelWHL2344;
irtmodelWHX2345:
	local[9]= NIL;
irtmodelBLK2346:
	w = NIL;
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto irtmodelWHL2341;
irtmodelWHX2342:
	local[7]= NIL;
irtmodelBLK2343:
	w = NIL;
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto irtmodelWHL2338;
irtmodelWHX2339:
	local[5]= NIL;
irtmodelBLK2340:
	w = NIL;
	w = local[0];
	local[0]= w;
irtmodelBLK2333:
	ctx->vsp=local; return(local[0]);}

/*:inverse-kinematics-for-closed-loop-forward-kinematics*/
static pointer irtmodelM2347cascaded_link_inverse_kinematics_for_closed_loop_forward_kinematics(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtmodelRST2349:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[556], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtmodelKEY2350;
	local[1] = NIL;
irtmodelKEY2350:
	if (n & (1<<1)) goto irtmodelKEY2351;
	local[2] = NIL;
irtmodelKEY2351:
	if (n & (1<<2)) goto irtmodelKEY2352;
	local[3] = NIL;
irtmodelKEY2352:
	if (n & (1<<3)) goto irtmodelKEY2353;
	local[4] = NIL;
irtmodelKEY2353:
	if (n & (1<<4)) goto irtmodelKEY2354;
	local[5] = NIL;
irtmodelKEY2354:
	if (n & (1<<5)) goto irtmodelKEY2355;
	local[6] = NIL;
irtmodelKEY2355:
	if (n & (1<<6)) goto irtmodelKEY2356;
	local[7] = makeint((eusinteger_t)2L);
irtmodelKEY2356:
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtmodelCLO2357,env,argv,local);
	local[9]= local[5];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)MAPCAR(ctx,3,local+8); /*mapcar*/
	local[8]= (pointer)get_sym_func(fqv[288]);
	local[9]= argv[0];
	local[10]= fqv[528];
	local[11]= argv[2];
	local[12]= fqv[300];
	local[13]= local[1];
	local[14]= fqv[260];
	local[15]= local[2];
	local[16]= fqv[557];
	ctx->vsp=local+17;
	local[17]= makeclosure(codevec,quotevec,irtmodelCLO2358,env,argv,local);
	local[18]= fqv[359];
	local[19]= local[4];
	ctx->vsp=local+20;
	local[20]= makeclosure(codevec,quotevec,irtmodelCLO2359,env,argv,local);
	local[21]= local[5];
	ctx->vsp=local+22;
	w=(pointer)MAPCAR(ctx,2,local+20); /*mapcar*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)APPEND(ctx,2,local+19); /*append*/
	local[19]= w;
	local[20]= fqv[558];
	local[21]= local[7];
	local[22]= local[0];
	ctx->vsp=local+23;
	w=(pointer)APPLY(ctx,15,local+8); /*apply*/
	local[0]= w;
irtmodelBLK2348:
	ctx->vsp=local; return(local[0]);}

/*:calc-jacobian-for-interlocking-joints*/
static pointer irtmodelM2360cascaded_link_calc_jacobian_for_interlocking_joints(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[559], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY2362;
	local[1]= argv[0];
	local[2]= fqv[560];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[0] = w;
irtmodelKEY2362:
	local[1]= argv[0];
	local[2]= fqv[197];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[198];
	ctx->vsp=local+4;
	w=(*ftab[18])(ctx,2,local+2,&ftab[18],fqv[128]); /*send-all*/
	local[2]= w;
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,irtmodelCLO2363,env,argv,local);
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[55])(ctx,2,local+3,&ftab[55],fqv[561]); /*remove-if-not*/
	local[3]= w;
	local[4]= local[3];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[211];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[23])(ctx,2,local+4,&ftab[23],fqv[166]); /*make-matrix*/
	local[4]= w;
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtmodelCLO2364,env,argv,local);
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)MAPCAR(ctx,2,local+5); /*mapcar*/
	w = local[4];
	local[0]= w;
irtmodelBLK2361:
	ctx->vsp=local; return(local[0]);}

/*:calc-vel-for-interlocking-joints*/
static pointer irtmodelM2365cascaded_link_calc_vel_for_interlocking_joints(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[562], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY2367;
	local[1]= argv[0];
	local[2]= fqv[560];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[0] = w;
irtmodelKEY2367:
	local[1]= argv[0];
	local[2]= fqv[197];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[198];
	ctx->vsp=local+3;
	w=(*ftab[18])(ctx,2,local+1,&ftab[18],fqv[128]); /*send-all*/
	local[1]= w;
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtmodelCLO2368,env,argv,local);
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(*ftab[55])(ctx,2,local+2,&ftab[55],fqv[561]); /*remove-if-not*/
	local[2]= w;
	local[3]= loadglobal(fqv[5]);
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)INSTANTIATE(ctx,2,local+3); /*instantiate*/
	local[3]= w;
	w = local[3];
	local[0]= w;
irtmodelBLK2366:
	ctx->vsp=local; return(local[0]);}

/*:set-midpoint-for-interlocking-joints*/
static pointer irtmodelM2369cascaded_link_set_midpoint_for_interlocking_joints(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[563], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY2371;
	local[1]= argv[0];
	local[2]= fqv[560];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[0] = w;
irtmodelKEY2371:
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtmodelCLO2372,env,argv,local);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	local[0]= w;
irtmodelBLK2370:
	ctx->vsp=local; return(local[0]);}

/*:interlocking-joint-pairs*/
static pointer irtmodelM2373cascaded_link_interlocking_joint_pairs(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = fqv[564];
	local[0]= w;
irtmodelBLK2374:
	ctx->vsp=local; return(local[0]);}

/*:check-interlocking-joint-angle-validity*/
static pointer irtmodelM2375cascaded_link_check_interlocking_joint_angle_validity(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[565], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY2377;
	local[0] = makeflt(1.0000000000000000208167e-03);
irtmodelKEY2377:
	if (n & (1<<1)) goto irtmodelKEY2378;
	local[2]= argv[0];
	local[3]= fqv[560];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[1] = w;
irtmodelKEY2378:
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtmodelCLO2379,env,argv,local);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[2]= w;
	local[3]= (pointer)get_sym_func(fqv[566]);
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(*ftab[56])(ctx,2,local+3,&ftab[56],fqv[567]); /*every*/
	local[0]= w;
irtmodelBLK2376:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO1436(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	local[0]= w;
	local[1]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelFLET1485(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(*ftab[21])(ctx,2,local+0,&ftab[21],fqv[142]); /*find*/
	if (w!=NIL) goto irtmodelOR2382;
	if (argv[0]==NIL) goto irtmodelOR2382;
	goto irtmodelIF2380;
irtmodelOR2382:
	local[0]= argv[0];
	goto irtmodelIF2381;
irtmodelIF2380:
	local[0]= argv[0];
	local[1]= fqv[214];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[1];
	w = env->c.clo.env2[33];
	ctx->vsp=local+2;
	w=irtmodelFLET1485(ctx,2,local+0,w);
	local[0]= w;
irtmodelIF2381:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO1574(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
irtmodelWHL2383:
	if (local[0]==NIL) goto irtmodelWHX2384;
	local[1]= local[0];
	local[2]= fqv[133];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (w==NIL) goto irtmodelWHX2384;
	local[1]= argv[0];
	local[2]= fqv[29];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= local[0];
	local[3]= fqv[133];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= fqv[29];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)VDISTANCE(ctx,2,local+1); /*distance*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(*ftab[8])(ctx,2,local+1,&ftab[8],fqv[81]); /*eps=*/
	if (w==NIL) goto irtmodelWHX2384;
	local[1]= local[0];
	local[2]= fqv[133];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[0] = w;
	goto irtmodelWHL2383;
irtmodelWHX2384:
	local[1]= NIL;
irtmodelBLK2385:
	local[1]= local[0];
	local[2]= fqv[133];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO1587(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env2[5];
	ctx->vsp=local+2;
	w=(*ftab[32])(ctx,2,local+0,&ftab[32],fqv[212]); /*position*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO1638(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO1669(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=env->c.clo.env2[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= argv[0];
	local[2]= fqv[139];
	local[3]= (pointer)get_sym_func(fqv[140]);
	ctx->vsp=local+4;
	w=(*ftab[16])(ctx,4,local+0,&ftab[16],fqv[124]); /*member*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelFLET1673(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0];
	local[3]= argv[1];
	local[4]= fqv[139];
	local[5]= (pointer)get_sym_func(fqv[140]);
	ctx->vsp=local+6;
	w=(*ftab[32])(ctx,4,local+2,&ftab[32],fqv[212]); /*position*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SUBSEQ(ctx,3,local+0); /*subseq*/
	local[0]= w;
	local[1]= fqv[198];
	ctx->vsp=local+2;
	w=(*ftab[18])(ctx,2,local+0,&ftab[18],fqv[128]); /*send-all*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)irtmodelF736calc_target_joint_dimension(ctx,1,local+0); /*calc-target-joint-dimension*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO1711(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)NUMEQUAL(ctx,2,local+0); /*=*/
	local[0]= w;
	if (w==NIL) goto irtmodelAND2386;
	local[0]= (pointer)get_sym_func(fqv[566]);
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtmodelCLO2387,env,argv,local);
	local[2]= argv[0];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,3,local+1); /*mapcar*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[56])(ctx,2,local+0,&ftab[56],fqv[567]); /*every*/
	local[0]= w;
irtmodelAND2386:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2387(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0];
	if (!issymbol(w)) goto irtmodelCON2389;
	w = argv[1];
	if (!issymbol(w)) goto irtmodelCON2389;
	local[0]= argv[0];
	local[0]= ((argv[1])==(local[0])?T:NIL);
	goto irtmodelCON2388;
irtmodelCON2389:
	w = argv[0];
	if (!isstring(w)) goto irtmodelCON2390;
	w = argv[1];
	if (!isstring(w)) goto irtmodelCON2390;
	local[0]= argv[0];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(*ftab[57])(ctx,2,local+0,&ftab[57],fqv[568]); /*string=*/
	local[0]= w;
	goto irtmodelCON2388;
irtmodelCON2390:
	local[0]= T;
	if (local[0]!=NIL) goto irtmodelCON2388;
irtmodelCON2391:
	local[0]= NIL;
irtmodelCON2388:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO1739(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env2[3];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[124]); /*member*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2060(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[43])(ctx,1,local+0,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelIF2392;
	local[0]= argv[0];
	local[1]= env->c.clo.env2[3];
	ctx->vsp=local+2;
	w=(pointer)FUNCALL(ctx,2,local+0); /*funcall*/
	local[0]= w;
	goto irtmodelIF2393;
irtmodelIF2392:
	local[0]= argv[0];
irtmodelIF2393:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2147(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2178(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[43])(ctx,1,local+0,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelIF2394;
	local[0]= argv[0];
	local[1]= env->c.clo.env2[2];
	ctx->vsp=local+2;
	w=(pointer)FUNCALL(ctx,2,local+0); /*funcall*/
	local[0]= w;
	goto irtmodelIF2395;
irtmodelIF2394:
	local[0]= argv[0];
irtmodelIF2395:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2181(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[43])(ctx,1,local+0,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelIF2396;
	local[0]= argv[0];
	local[1]= env->c.clo.env2[2];
	ctx->vsp=local+2;
	w=(pointer)FUNCALL(ctx,2,local+0); /*funcall*/
	local[0]= w;
	goto irtmodelIF2397;
irtmodelIF2396:
	local[0]= argv[0];
irtmodelIF2397:
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,2,local+0,&ftab[3],fqv[24]); /*array-dimension*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2184(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= fqv[569];
	local[2]= env->c.clo.env2[43];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	env->c.clo.env2[43] = w;
	local[2]= env->c.clo.env2[43];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[45])(ctx,1,local+0,&ftab[45],fqv[422]); /*read-from-string*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2187(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= fqv[570];
	local[2]= env->c.clo.env2[45];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	env->c.clo.env2[45] = w;
	local[2]= env->c.clo.env2[45];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[45])(ctx,1,local+0,&ftab[45],fqv[422]); /*read-from-string*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2191(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[43])(ctx,1,local+0,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelIF2398;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)FUNCALL(ctx,1,local+0); /*funcall*/
	local[0]= w;
	goto irtmodelIF2399;
irtmodelIF2398:
	local[0]= argv[0];
irtmodelIF2399:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2192(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[571];
	local[2]= argv[1];
	local[3]= fqv[335];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,5,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2193(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[572];
	local[2]= argv[1];
	local[3]= fqv[409];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,5,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2198(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[43])(ctx,1,local+0,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelIF2400;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)FUNCALL(ctx,1,local+0); /*funcall*/
	local[0]= w;
	goto irtmodelIF2401;
irtmodelIF2400:
	local[0]= argv[0];
irtmodelIF2401:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2199(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[571];
	local[2]= argv[1];
	local[3]= fqv[335];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,5,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2200(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[572];
	local[2]= argv[1];
	local[3]= fqv[409];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,5,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2201(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[149];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelUWP2212(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[40];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelUWP2217(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[40];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2218(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	ctx->vsp=local+2;
	w=(pointer)REVERSE(ctx,1,local+1); /*reverse*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPEND(ctx,2,local+0); /*append*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2219(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= fqv[573];
	local[2]= env->c.clo.env2[45];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	env->c.clo.env2[45] = w;
	local[2]= env->c.clo.env2[45];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[45])(ctx,1,local+0,&ftab[45],fqv[422]); /*read-from-string*/
	local[0]= w;
	local[1]= makeflt(1.0000000000000000208167e-03);
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,2,local+0); /*list*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelFLET2238(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	if (!isstring(w)) goto irtmodelIF2402;
	local[0]= NIL;
	local[1]= fqv[574];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
	goto irtmodelIF2403;
irtmodelIF2402:
	local[0]= argv[0];
irtmodelIF2403:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelFLET2239(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	if (!iscons(w)) goto irtmodelIF2404;
	local[0]= argv[0];
	local[1]= argv[1];
	local[2]= fqv[575];
	local[3]= argv[0];
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)APPEND(ctx,2,local+2); /*append*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETELT(ctx,3,local+0); /*setelt*/
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[0];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
irtmodelWHL2406:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto irtmodelWHX2407;
	local[2]= argv[0];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	local[3]= local[0];
	w = env->c.clo.env2[46];
	ctx->vsp=local+4;
	w=irtmodelFLET2239(ctx,2,local+2,w);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto irtmodelWHL2406;
irtmodelWHX2407:
	local[2]= NIL;
irtmodelBLK2408:
	w = NIL;
	local[0]= w;
	goto irtmodelIF2405;
irtmodelIF2404:
	local[0]= NIL;
irtmodelIF2405:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelFLET2240(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	local[1]= loadglobal(fqv[213]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto irtmodelIF2409;
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[576];
	local[2]= argv[0];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	local[3]= fqv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	if (w==NIL) goto irtmodelIF2409;
	local[0]= argv[0];
	local[1]= argv[1];
	local[2]= fqv[288];
	local[3]= fqv[513];
	local[4]= fqv[576];
	local[5]= argv[0];
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= fqv[3];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	w = env->c.clo.env2[45];
	ctx->vsp=local+6;
	w=irtmodelFLET2238(ctx,1,local+5,w);
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)SETELT(ctx,3,local+0); /*setelt*/
	local[0]= w;
	goto irtmodelIF2410;
irtmodelIF2409:
	local[0]= NIL;
irtmodelIF2410:
	local[0]= argv[0];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	if (!iscons(w)) goto irtmodelIF2411;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[0];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
irtmodelWHL2413:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto irtmodelWHX2414;
	local[2]= argv[0];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	local[3]= local[0];
	w = env->c.clo.env2[47];
	ctx->vsp=local+4;
	w=irtmodelFLET2240(ctx,2,local+2,w);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto irtmodelWHL2413;
irtmodelWHX2414:
	local[2]= NIL;
irtmodelBLK2415:
	w = NIL;
	local[0]= w;
	goto irtmodelIF2412;
irtmodelIF2411:
	local[0]= NIL;
irtmodelIF2412:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelFLET2241(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[214];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= env->c.clo.env1[0];
	local[2]= fqv[136];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[21])(ctx,2,local+0,&ftab[21],fqv[142]); /*find*/
	if (w==NIL) goto irtmodelIF2416;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto irtmodelIF2417;
irtmodelIF2416:
	local[0]= argv[0];
	local[1]= fqv[214];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	w = env->c.clo.env2[48];
	ctx->vsp=local+1;
	w=irtmodelFLET2241(ctx,1,local+0,w);
	local[0]= w;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPEND(ctx,2,local+0); /*append*/
	local[0]= w;
irtmodelIF2417:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelFLET2242(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w = env->c.clo.env2[48];
	ctx->vsp=local+1;
	w=irtmodelFLET2241(ctx,1,local+0,w);
	local[0]= w;
	local[1]= fqv[577];
	local[2]= fqv[578];
	local[3]= fqv[288];
	local[4]= fqv[513];
	local[5]= fqv[576];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	local[7]= fqv[214];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= fqv[3];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	w = env->c.clo.env2[45];
	ctx->vsp=local+7;
	w=irtmodelFLET2238(ctx,1,local+6,w);
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[579];
	local[4]= fqv[297];
	local[5]= fqv[120];
	local[6]= fqv[288];
	local[7]= fqv[288];
	local[8]= fqv[578];
	local[9]= fqv[153];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[84];
	local[9]= fqv[86];
	local[10]= fqv[514];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= fqv[214];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	local[12]= fqv[104];
	local[13]= local[0];
	ctx->vsp=local+14;
	w=(*ftab[38])(ctx,1,local+13,&ftab[38],fqv[291]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	local[11]= w;
	local[12]= fqv[514];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[288];
	local[4]= fqv[578];
	local[5]= fqv[298];
	local[6]= fqv[579];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[579];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelFLET2243(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtmodelCLO2418,env,argv,local);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2418(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	if (!iscons(w)) goto irtmodelIF2419;
	local[0]= argv[0];
	w = env->c.clo.env0->c.clo.env2[50];
	ctx->vsp=local+1;
	w=irtmodelFLET2243(ctx,1,local+0,w);
	local[0]= w;
	goto irtmodelIF2420;
irtmodelIF2419:
	local[0]= argv[0];
irtmodelIF2420:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2260(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w = env->c.clo.env2[49];
	ctx->vsp=local+1;
	w=irtmodelFLET2242(ctx,1,local+0,w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2261(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[288];
	local[1]= fqv[513];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[58])(ctx,1,local+2,&ftab[58],fqv[580]); /*string-upcase*/
	local[2]= w;
	local[3]= loadglobal(fqv[581]);
	ctx->vsp=local+4;
	w=(pointer)INTERN(ctx,2,local+2); /*intern*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2262(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[86];
	local[1]= fqv[105];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[43])(ctx,1,local+2,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelIF2421;
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)FUNCALL(ctx,1,local+2); /*funcall*/
	local[2]= w;
	goto irtmodelIF2422;
irtmodelIF2421:
	local[2]= argv[0];
irtmodelIF2422:
	local[3]= fqv[29];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= fqv[85];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[43])(ctx,1,local+4,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelIF2423;
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)FUNCALL(ctx,1,local+4); /*funcall*/
	local[4]= w;
	goto irtmodelIF2424;
irtmodelIF2423:
	local[4]= argv[0];
irtmodelIF2424:
	local[5]= fqv[27];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelUWP2263(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[45];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2266(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= (pointer)get_sym_func(fqv[288]);
	local[1]= argv[0];
	local[2]= fqv[20];
	local[3]= argv[1];
	local[4]= env->c.clo.env2[9];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,5,local+0); /*apply*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2336(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= makeint((eusinteger_t)3L);
	ctx->vsp=local+1;
	w=(*ftab[15])(ctx,1,local+0,&ftab[15],fqv[118]); /*unit-matrix*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2337(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeflt(1.0000000000000000208167e-03);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)SCALEVEC(ctx,2,local+0); /*scale*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[59])(ctx,1,local+0,&ftab[59],fqv[582]); /*outer-product-matrix*/
	local[0]= w;
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)MATTIMES(ctx,2,local+0); /*m**/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2357(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[20];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2358(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtmodelCLO2425,env,argv,local);
	local[1]= env->c.clo.env2[5];
	local[2]= env->c.clo.env2[6];
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,3,local+0); /*mapcar*/
	local[0]= env->c.clo.env2[3];
	ctx->vsp=local+1;
	w=(*ftab[43])(ctx,1,local+0,&ftab[43],fqv[320]); /*functionp*/
	if (w==NIL) goto irtmodelIF2426;
	local[0]= env->c.clo.env2[3];
	ctx->vsp=local+1;
	w=(pointer)FUNCALL(ctx,1,local+0); /*funcall*/
	local[0]= w;
	goto irtmodelIF2427;
irtmodelIF2426:
	local[0]= NIL;
irtmodelIF2427:
	w = NIL;
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2425(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[20];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2359(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[130];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,2,local+0); /*list*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2363(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= env->c.clo.env2[2];
	ctx->vsp=local+2;
	w=(*ftab[21])(ctx,2,local+0,&ftab[21],fqv[142]); /*find*/
	local[0]= w;
	if (w==NIL) goto irtmodelAND2428;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= env->c.clo.env2[2];
	ctx->vsp=local+2;
	w=(*ftab[21])(ctx,2,local+0,&ftab[21],fqv[142]); /*find*/
	local[0]= w;
irtmodelAND2428:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2364(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= (pointer)get_sym_func(fqv[322]);
	local[1]= env->c.clo.env2[2];
	local[2]= makeint((eusinteger_t)0L);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= env->c.clo.env2[2];
	ctx->vsp=local+5;
	w=(*ftab[32])(ctx,2,local+3,&ftab[32],fqv[212]); /*position*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SUBSEQ(ctx,3,local+1); /*subseq*/
	local[1]= w;
	local[2]= fqv[31];
	ctx->vsp=local+3;
	w=(*ftab[18])(ctx,2,local+1,&ftab[18],fqv[128]); /*send-all*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[26])(ctx,2,local+0,&ftab[26],fqv[196]); /*reduce*/
	local[0]= w;
	local[1]= env->c.clo.env2[4];
	local[2]= argv[0];
	local[3]= env->c.clo.env2[3];
	ctx->vsp=local+4;
	w=(*ftab[32])(ctx,2,local+2,&ftab[32],fqv[212]); /*position*/
	local[2]= w;
	local[3]= local[0];
	local[4]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,4,local+1); /*aset*/
	local[0]= (pointer)get_sym_func(fqv[322]);
	local[1]= env->c.clo.env2[2];
	local[2]= makeint((eusinteger_t)0L);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	local[4]= env->c.clo.env2[2];
	ctx->vsp=local+5;
	w=(*ftab[32])(ctx,2,local+3,&ftab[32],fqv[212]); /*position*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SUBSEQ(ctx,3,local+1); /*subseq*/
	local[1]= w;
	local[2]= fqv[31];
	ctx->vsp=local+3;
	w=(*ftab[18])(ctx,2,local+1,&ftab[18],fqv[128]); /*send-all*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[26])(ctx,2,local+0,&ftab[26],fqv[196]); /*reduce*/
	local[0]= w;
	local[1]= env->c.clo.env2[4];
	local[2]= argv[0];
	local[3]= env->c.clo.env2[3];
	ctx->vsp=local+4;
	w=(*ftab[32])(ctx,2,local+2,&ftab[32],fqv[212]); /*position*/
	local[2]= w;
	local[3]= local[0];
	local[4]= makeflt(-1.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,4,local+1); /*aset*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2368(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= env->c.clo.env2[1];
	ctx->vsp=local+2;
	w=(*ftab[21])(ctx,2,local+0,&ftab[21],fqv[142]); /*find*/
	local[0]= w;
	if (w==NIL) goto irtmodelAND2429;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= env->c.clo.env2[1];
	ctx->vsp=local+2;
	w=(*ftab[21])(ctx,2,local+0,&ftab[21],fqv[142]); /*find*/
	local[0]= w;
irtmodelAND2429:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2372(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= makeflt(5.0000000000000000000000e-01);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[20];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.cdr;
	local[3]= fqv[20];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,2,local+1); /*+*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[20];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	local[2]= fqv[20];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2379(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env2[0];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[20];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.cdr;
	local[3]= fqv[20];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)ABS(ctx,1,local+1); /*abs*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*all-child-links*/
static pointer irtmodelF734all_child_links(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto irtmodelENT2432;}
	local[0]= (pointer)get_sym_func(fqv[566]);
irtmodelENT2432:
irtmodelENT2431:
	if (n>2) maerror();
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtmodelCLO2433,env,argv,local);
	local[2]= argv[0];
	local[3]= fqv[547];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MAPCAN(ctx,2,local+1); /*mapcan*/
	local[1]= w;
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtmodelCLO2434,env,argv,local);
	local[3]= argv[0];
	local[4]= fqv[547];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MAPCAN(ctx,2,local+2); /*mapcan*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)APPEND(ctx,2,local+1); /*append*/
	local[0]= w;
irtmodelBLK2430:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2433(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env2[0];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)FUNCALL(ctx,2,local+0); /*funcall*/
	if (w==NIL) goto irtmodelIF2435;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto irtmodelIF2436;
irtmodelIF2435:
	local[0]= NIL;
irtmodelIF2436:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2434(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env2[0];
	ctx->vsp=local+2;
	w=(pointer)irtmodelF734all_child_links(ctx,2,local+0); /*all-child-links*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*calc-dif-with-axis*/
static pointer irtmodelF735calc_dif_with_axis(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtmodelENT2441;}
	local[0]= NIL;
irtmodelENT2441:
	if (n>=4) { local[1]=(argv[3]); goto irtmodelENT2440;}
	local[1]= NIL;
irtmodelENT2440:
	if (n>=5) { local[2]=(argv[4]); goto irtmodelENT2439;}
	local[2]= NIL;
irtmodelENT2439:
irtmodelENT2438:
	if (n>5) maerror();
	local[3]= argv[1];
	local[4]= local[3];
	w = fqv[583];
	if (memq(local[4],w)==NIL) goto irtmodelIF2442;
	if (local[2]==NIL) goto irtmodelIF2444;
	local[4]= local[2];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SETELT(ctx,3,local+4); /*setelt*/
	local[4]= local[2];
	local[5]= makeint((eusinteger_t)1L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SETELT(ctx,3,local+4); /*setelt*/
	local[4]= local[2];
	goto irtmodelIF2445;
irtmodelIF2444:
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,2,local+4); /*float-vector*/
	local[4]= w;
irtmodelIF2445:
	goto irtmodelIF2443;
irtmodelIF2442:
	local[4]= local[3];
	w = fqv[584];
	if (memq(local[4],w)==NIL) goto irtmodelIF2446;
	if (local[2]==NIL) goto irtmodelIF2448;
	local[4]= local[2];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SETELT(ctx,3,local+4); /*setelt*/
	local[4]= local[2];
	local[5]= makeint((eusinteger_t)1L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SETELT(ctx,3,local+4); /*setelt*/
	local[4]= local[2];
	goto irtmodelIF2449;
irtmodelIF2448:
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,2,local+4); /*float-vector*/
	local[4]= w;
irtmodelIF2449:
	goto irtmodelIF2447;
irtmodelIF2446:
	local[4]= local[3];
	w = fqv[585];
	if (memq(local[4],w)==NIL) goto irtmodelIF2450;
	if (local[2]==NIL) goto irtmodelIF2452;
	local[4]= local[2];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SETELT(ctx,3,local+4); /*setelt*/
	local[4]= local[2];
	local[5]= makeint((eusinteger_t)1L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SETELT(ctx,3,local+4); /*setelt*/
	local[4]= local[2];
	goto irtmodelIF2453;
irtmodelIF2452:
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,2,local+4); /*float-vector*/
	local[4]= w;
irtmodelIF2453:
	goto irtmodelIF2451;
irtmodelIF2450:
	local[4]= local[3];
	w = fqv[586];
	if (memq(local[4],w)==NIL) goto irtmodelIF2454;
	if (local[1]==NIL) goto irtmodelIF2456;
	local[4]= local[1];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SETELT(ctx,3,local+4); /*setelt*/
	local[4]= local[1];
	goto irtmodelIF2457;
irtmodelIF2456:
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,1,local+4); /*float-vector*/
	local[4]= w;
irtmodelIF2457:
	goto irtmodelIF2455;
irtmodelIF2454:
	local[4]= local[3];
	w = fqv[587];
	if (memq(local[4],w)==NIL) goto irtmodelIF2458;
	if (local[1]==NIL) goto irtmodelIF2460;
	local[4]= local[1];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SETELT(ctx,3,local+4); /*setelt*/
	local[4]= local[1];
	goto irtmodelIF2461;
irtmodelIF2460:
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,1,local+4); /*float-vector*/
	local[4]= w;
irtmodelIF2461:
	goto irtmodelIF2459;
irtmodelIF2458:
	local[4]= local[3];
	w = fqv[588];
	if (memq(local[4],w)==NIL) goto irtmodelIF2462;
	if (local[1]==NIL) goto irtmodelIF2464;
	local[4]= local[1];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SETELT(ctx,3,local+4); /*setelt*/
	local[4]= local[1];
	goto irtmodelIF2465;
irtmodelIF2464:
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,1,local+4); /*float-vector*/
	local[4]= w;
irtmodelIF2465:
	goto irtmodelIF2463;
irtmodelIF2462:
	local[4]= local[3];
	if (fqv[194]!=local[4]) goto irtmodelIF2466;
	if (local[0]==NIL) goto irtmodelIF2468;
	local[4]= local[0];
	goto irtmodelIF2469;
irtmodelIF2468:
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,0,local+4); /*float-vector*/
	local[4]= w;
irtmodelIF2469:
	goto irtmodelIF2467;
irtmodelIF2466:
	local[4]= local[3];
	w = fqv[589];
	if (memq(local[4],w)==NIL) goto irtmodelIF2470;
	local[4]= argv[0];
	goto irtmodelIF2471;
irtmodelIF2470:
	if (T==NIL) goto irtmodelIF2472;
	local[4]= argv[0];
	goto irtmodelIF2473;
irtmodelIF2472:
	local[4]= NIL;
irtmodelIF2473:
irtmodelIF2471:
irtmodelIF2467:
irtmodelIF2463:
irtmodelIF2459:
irtmodelIF2455:
irtmodelIF2451:
irtmodelIF2447:
irtmodelIF2443:
	w = local[4];
	local[0]= w;
irtmodelBLK2437:
	ctx->vsp=local; return(local[0]);}

/*calc-target-joint-dimension*/
static pointer irtmodelF736calc_target_joint_dimension(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= NIL;
	local[2]= argv[0];
irtmodelWHL2475:
	if (local[2]==NIL) goto irtmodelWHX2476;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= local[0];
	local[4]= local[1];
	local[5]= fqv[31];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	local[0] = w;
	goto irtmodelWHL2475;
irtmodelWHX2476:
	local[3]= NIL;
irtmodelBLK2477:
	w = NIL;
	w = local[0];
	local[0]= w;
irtmodelBLK2474:
	ctx->vsp=local; return(local[0]);}

/*calc-joint-angle-min-max-for-limit-calculation*/
static pointer irtmodelF737calc_joint_angle_min_max_for_limit_calculation(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[20];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)VECTORP(ctx,1,local+0); /*vectorp*/
	if (w==NIL) goto irtmodelCON2480;
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0];
	local[3]= fqv[590];
	local[4]= argv[0];
	local[5]= fqv[20];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETELT(ctx,3,local+0); /*setelt*/
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)1L);
	local[2]= argv[0];
	local[3]= fqv[590];
	local[4]= argv[0];
	local[5]= fqv[23];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETELT(ctx,3,local+0); /*setelt*/
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)2L);
	local[2]= argv[0];
	local[3]= fqv[590];
	local[4]= argv[0];
	local[5]= fqv[22];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETELT(ctx,3,local+0); /*setelt*/
	local[0]= w;
	goto irtmodelCON2479;
irtmodelCON2480:
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0];
	local[3]= fqv[590];
	local[4]= argv[0];
	local[5]= fqv[20];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETELT(ctx,3,local+0); /*setelt*/
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)1L);
	local[2]= argv[0];
	local[3]= fqv[590];
	local[4]= argv[0];
	local[5]= fqv[23];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETELT(ctx,3,local+0); /*setelt*/
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)2L);
	local[2]= argv[0];
	local[3]= fqv[590];
	local[4]= argv[0];
	local[5]= fqv[22];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETELT(ctx,3,local+0); /*setelt*/
	local[0]= w;
	goto irtmodelCON2479;
irtmodelCON2481:
	local[0]= NIL;
irtmodelCON2479:
	w = argv[2];
	local[0]= w;
irtmodelBLK2478:
	ctx->vsp=local; return(local[0]);}

/*joint-angle-limit-weight*/
static pointer irtmodelF738joint_angle_limit_weight(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto irtmodelENT2484;}
	local[0]= loadglobal(fqv[5]);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)irtmodelF736calc_target_joint_dimension(ctx,1,local+1); /*calc-target-joint-dimension*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,2,local+0); /*instantiate*/
	local[0]= w;
irtmodelENT2484:
irtmodelENT2483:
	if (n>2) maerror();
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)irtmodelF736calc_target_joint_dimension(ctx,1,local+5); /*calc-target-joint-dimension*/
	local[5]= w;
irtmodelWHL2485:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto irtmodelWHX2486;
	local[6]= argv[0];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= local[6];
	local[8]= local[2];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)irtmodelF737calc_joint_angle_min_max_for_limit_calculation(ctx,3,local+7); /*calc-joint-angle-min-max-for-limit-calculation*/
	local[7]= local[3];
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	local[8]= local[3];
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	local[9]= local[3];
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(*ftab[6])(ctx,1,local+10,&ftab[6],fqv[48]); /*deg2rad*/
	local[10]= w;
	local[11]= local[6];
	local[12]= fqv[20];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)VECTORP(ctx,1,local+11); /*vectorp*/
	if (w==NIL) goto irtmodelIF2488;
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[2] = w;
	local[11]= local[2];
	local[12]= local[6];
	local[13]= fqv[20];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)LENGTH(ctx,1,local+12); /*length*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)GREQP(ctx,2,local+11); /*>=*/
	if (w==NIL) goto irtmodelIF2490;
	local[2] = makeint((eusinteger_t)0L);
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[1] = w;
	local[11]= local[1];
	goto irtmodelIF2491;
irtmodelIF2490:
	local[11]= NIL;
irtmodelIF2491:
	goto irtmodelIF2489;
irtmodelIF2488:
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[1] = w;
	local[11]= local[1];
irtmodelIF2489:
	local[11]= local[7];
	local[12]= local[8];
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(*ftab[8])(ctx,3,local+11,&ftab[8],fqv[81]); /*eps=*/
	local[11]= w;
	if (w==NIL) goto irtmodelAND2494;
	local[11]= local[7];
	local[12]= local[9];
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(*ftab[8])(ctx,3,local+11,&ftab[8],fqv[81]); /*eps=*/
	local[11]= w;
irtmodelAND2494:
	if (local[11]!=NIL) goto irtmodelCON2492;
irtmodelCON2493:
	local[11]= local[7];
	local[12]= local[8];
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(*ftab[8])(ctx,3,local+11,&ftab[8],fqv[81]); /*eps=*/
	if (w==NIL) goto irtmodelCON2495;
	local[11]= local[8];
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)MINUS(ctx,2,local+11); /*-*/
	local[7] = w;
	local[11]= local[7];
	goto irtmodelCON2492;
irtmodelCON2495:
	local[11]= local[7];
	local[12]= local[9];
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(*ftab[8])(ctx,3,local+11,&ftab[8],fqv[81]); /*eps=*/
	if (w==NIL) goto irtmodelCON2496;
	local[11]= local[9];
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	local[7] = w;
	local[11]= local[7];
	goto irtmodelCON2492;
irtmodelCON2496:
	local[11]= NIL;
irtmodelCON2492:
	local[11]= local[6];
	local[12]= fqv[3];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	if (fqv[591]==local[11]) goto irtmodelOR2499;
	local[11]= local[6];
	local[12]= fqv[3];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	if (fqv[592]==local[11]) goto irtmodelOR2499;
	goto irtmodelCON2498;
irtmodelOR2499:
	local[11]= makeflt(0.0000000000000000000000e+00);
	local[12]= local[8];
	ctx->vsp=local+13;
	w=(pointer)NUMEQUAL(ctx,2,local+11); /*=*/
	if (w==NIL) goto irtmodelCON2501;
	local[11]= local[8];
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)MINUS(ctx,2,local+11); /*-*/
	local[11]= w;
	goto irtmodelCON2500;
irtmodelCON2501:
	local[11]= makeflt(0.0000000000000000000000e+00);
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)NUMEQUAL(ctx,2,local+11); /*=*/
	if (w==NIL) goto irtmodelCON2502;
	local[11]= local[9];
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	local[11]= w;
	goto irtmodelCON2500;
irtmodelCON2502:
	local[11]= makeflt(0.0000000000000000000000e+00);
	goto irtmodelCON2500;
irtmodelCON2503:
	local[11]= NIL;
irtmodelCON2500:
	local[12]= local[7];
	local[13]= local[11];
	ctx->vsp=local+14;
	w=(pointer)GREATERP(ctx,2,local+12); /*>*/
	if (w==NIL) goto irtmodelIF2504;
	local[12]= local[8];
	ctx->vsp=local+13;
	w=(pointer)ABS(ctx,1,local+12); /*abs*/
	local[12]= w;
	goto irtmodelIF2505;
irtmodelIF2504:
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)ABS(ctx,1,local+12); /*abs*/
	local[12]= w;
irtmodelIF2505:
	local[13]= local[0];
	local[14]= local[4];
	local[15]= makeint((eusinteger_t)2L);
	local[16]= local[12];
	ctx->vsp=local+17;
	w=(pointer)TIMES(ctx,2,local+15); /***/
	local[15]= w;
	local[16]= makeint((eusinteger_t)2L);
	ctx->vsp=local+17;
	w=(*ftab[28])(ctx,2,local+15,&ftab[28],fqv[201]); /*expt*/
	local[15]= w;
	local[16]= makeint((eusinteger_t)2L);
	local[17]= local[7];
	local[18]= local[11];
	ctx->vsp=local+19;
	w=(pointer)MINUS(ctx,2,local+17); /*-*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)TIMES(ctx,2,local+16); /***/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)TIMES(ctx,2,local+15); /***/
	local[15]= w;
	local[16]= makeint((eusinteger_t)4L);
	local[17]= local[12];
	local[18]= local[12];
	ctx->vsp=local+19;
	w=(pointer)TIMES(ctx,2,local+17); /***/
	local[17]= w;
	local[18]= local[7];
	local[19]= local[7];
	ctx->vsp=local+20;
	w=(pointer)TIMES(ctx,2,local+18); /***/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)MINUS(ctx,2,local+17); /*-*/
	local[17]= w;
	local[18]= makeint((eusinteger_t)2L);
	ctx->vsp=local+19;
	w=(*ftab[28])(ctx,2,local+17,&ftab[28],fqv[201]); /*expt*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)TIMES(ctx,2,local+16); /***/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)QUOTIENT(ctx,2,local+15); /*/*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)ABS(ctx,1,local+15); /*abs*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)SETELT(ctx,3,local+13); /*setelt*/
	local[11]= w;
	goto irtmodelCON2497;
irtmodelCON2498:
	local[11]= local[7];
	local[12]= local[8];
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(*ftab[8])(ctx,3,local+11,&ftab[8],fqv[81]); /*eps=*/
	if (w==NIL) goto irtmodelCON2506;
	local[11]= local[7];
	local[12]= local[9];
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(*ftab[8])(ctx,3,local+11,&ftab[8],fqv[81]); /*eps=*/
	if (w==NIL) goto irtmodelCON2506;
	local[11]= local[0];
	local[12]= local[4];
	local[13]= loadglobal(fqv[64]);
	ctx->vsp=local+14;
	w=(pointer)SETELT(ctx,3,local+11); /*setelt*/
	local[11]= w;
	goto irtmodelCON2497;
irtmodelCON2506:
	local[11]= local[8];
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)MINUS(ctx,2,local+11); /*-*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)2L);
	ctx->vsp=local+13;
	w=(*ftab[28])(ctx,2,local+11,&ftab[28],fqv[201]); /*expt*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)2L);
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(pointer)TIMES(ctx,2,local+12); /***/
	local[12]= w;
	local[13]= local[8];
	local[14]= local[9];
	ctx->vsp=local+15;
	w=(pointer)MINUS(ctx,3,local+12); /*-*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	local[12]= makeint((eusinteger_t)4L);
	local[13]= local[8];
	local[14]= local[7];
	ctx->vsp=local+15;
	w=(pointer)MINUS(ctx,2,local+13); /*-*/
	local[13]= w;
	local[14]= makeint((eusinteger_t)2L);
	ctx->vsp=local+15;
	w=(*ftab[28])(ctx,2,local+13,&ftab[28],fqv[201]); /*expt*/
	local[13]= w;
	local[14]= local[7];
	local[15]= local[9];
	ctx->vsp=local+16;
	w=(pointer)MINUS(ctx,2,local+14); /*-*/
	local[14]= w;
	local[15]= makeint((eusinteger_t)2L);
	ctx->vsp=local+16;
	w=(*ftab[28])(ctx,2,local+14,&ftab[28],fqv[201]); /*expt*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)TIMES(ctx,3,local+12); /***/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)ABS(ctx,1,local+11); /*abs*/
	local[11]= w;
	local[12]= local[11];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)GREATERP(ctx,2,local+12); /*>*/
	if (w==NIL) goto irtmodelIF2508;
	local[12]= local[11];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)LESSP(ctx,2,local+12); /*<*/
	if (w==NIL) goto irtmodelIF2508;
	local[11] = makeflt(0.0000000000000000000000e+00);
	local[12]= local[11];
	goto irtmodelIF2509;
irtmodelIF2508:
	local[12]= NIL;
irtmodelIF2509:
	local[12]= local[0];
	local[13]= local[4];
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(pointer)SETELT(ctx,3,local+12); /*setelt*/
	local[11]= w;
	goto irtmodelCON2497;
irtmodelCON2507:
	local[11]= NIL;
irtmodelCON2497:
	w = local[11];
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto irtmodelWHL2485;
irtmodelWHX2486:
	local[6]= NIL;
irtmodelBLK2487:
	w = NIL;
	w = local[0];
	local[0]= w;
irtmodelBLK2482:
	ctx->vsp=local; return(local[0]);}

/*joint-angle-limit-nspace*/
static pointer irtmodelF739joint_angle_limit_nspace(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto irtmodelENT2512;}
	local[0]= loadglobal(fqv[5]);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)irtmodelF736calc_target_joint_dimension(ctx,1,local+1); /*calc-target-joint-dimension*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,2,local+0); /*instantiate*/
	local[0]= w;
irtmodelENT2512:
irtmodelENT2511:
	if (n>2) maerror();
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)irtmodelF736calc_target_joint_dimension(ctx,1,local+5); /*calc-target-joint-dimension*/
	local[5]= w;
irtmodelWHL2513:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto irtmodelWHX2514;
	local[6]= argv[0];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= local[6];
	local[8]= local[2];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)irtmodelF737calc_joint_angle_min_max_for_limit_calculation(ctx,3,local+7); /*calc-joint-angle-min-max-for-limit-calculation*/
	local[7]= local[3];
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	local[8]= local[3];
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	local[9]= local[3];
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(*ftab[6])(ctx,1,local+10,&ftab[6],fqv[48]); /*deg2rad*/
	local[10]= w;
	local[11]= local[6];
	local[12]= fqv[20];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)VECTORP(ctx,1,local+11); /*vectorp*/
	if (w==NIL) goto irtmodelIF2516;
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[2] = w;
	local[11]= local[2];
	local[12]= local[6];
	local[13]= fqv[20];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)LENGTH(ctx,1,local+12); /*length*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)GREQP(ctx,2,local+11); /*>=*/
	if (w==NIL) goto irtmodelIF2518;
	local[2] = makeint((eusinteger_t)0L);
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[1] = w;
	local[11]= local[1];
	goto irtmodelIF2519;
irtmodelIF2518:
	local[11]= NIL;
irtmodelIF2519:
	goto irtmodelIF2517;
irtmodelIF2516:
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[1] = w;
	local[11]= local[1];
irtmodelIF2517:
	local[11]= local[6];
	local[12]= fqv[3];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	if (fqv[591]==local[11]) goto irtmodelOR2522;
	local[11]= local[6];
	local[12]= fqv[3];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	if (fqv[592]==local[11]) goto irtmodelOR2522;
	goto irtmodelCON2521;
irtmodelOR2522:
	local[11]= makeflt(0.0000000000000000000000e+00);
	local[12]= local[8];
	ctx->vsp=local+13;
	w=(pointer)NUMEQUAL(ctx,2,local+11); /*=*/
	if (w==NIL) goto irtmodelCON2524;
	local[11]= local[8];
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)MINUS(ctx,2,local+11); /*-*/
	local[11]= w;
	goto irtmodelCON2523;
irtmodelCON2524:
	local[11]= makeflt(0.0000000000000000000000e+00);
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)NUMEQUAL(ctx,2,local+11); /*=*/
	if (w==NIL) goto irtmodelCON2525;
	local[11]= local[9];
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	local[11]= w;
	goto irtmodelCON2523;
irtmodelCON2525:
	local[11]= makeflt(0.0000000000000000000000e+00);
	goto irtmodelCON2523;
irtmodelCON2526:
	local[11]= NIL;
irtmodelCON2523:
	local[12]= local[0];
	local[13]= local[4];
	local[14]= local[7];
	local[15]= local[11];
	ctx->vsp=local+16;
	w=(pointer)GREATERP(ctx,2,local+14); /*>*/
	if (w==NIL) goto irtmodelIF2527;
	local[14]= local[11];
	local[15]= local[7];
	ctx->vsp=local+16;
	w=(pointer)MINUS(ctx,2,local+14); /*-*/
	local[14]= w;
	local[15]= local[8];
	local[16]= local[11];
	ctx->vsp=local+17;
	w=(pointer)MINUS(ctx,2,local+15); /*-*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)QUOTIENT(ctx,2,local+14); /*/*/
	local[14]= w;
	goto irtmodelIF2528;
irtmodelIF2527:
	local[14]= local[11];
	local[15]= local[7];
	ctx->vsp=local+16;
	w=(pointer)MINUS(ctx,2,local+14); /*-*/
	local[14]= w;
	local[15]= makeflt(5.0000000000000000000000e+00);
	local[16]= local[11];
	local[17]= local[9];
	ctx->vsp=local+18;
	w=(pointer)MINUS(ctx,2,local+16); /*-*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)TIMES(ctx,2,local+15); /***/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)QUOTIENT(ctx,2,local+14); /*/*/
	local[14]= w;
irtmodelIF2528:
	ctx->vsp=local+15;
	w=(pointer)SETELT(ctx,3,local+12); /*setelt*/
	local[11]= w;
	goto irtmodelCON2520;
irtmodelCON2521:
	local[11]= local[0];
	local[12]= local[4];
	local[13]= local[8];
	local[14]= local[9];
	ctx->vsp=local+15;
	w=(pointer)PLUS(ctx,2,local+13); /*+*/
	local[13]= w;
	local[14]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+15;
	w=(pointer)QUOTIENT(ctx,2,local+13); /*/*/
	local[13]= w;
	local[14]= local[7];
	ctx->vsp=local+15;
	w=(pointer)MINUS(ctx,2,local+13); /*-*/
	local[13]= w;
	local[14]= local[8];
	local[15]= local[9];
	ctx->vsp=local+16;
	w=(pointer)MINUS(ctx,2,local+14); /*-*/
	local[14]= w;
	local[15]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+16;
	w=(pointer)QUOTIENT(ctx,2,local+14); /*/*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)QUOTIENT(ctx,2,local+13); /*/*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SETELT(ctx,3,local+11); /*setelt*/
	local[11]= w;
	goto irtmodelCON2520;
irtmodelCON2529:
	local[11]= NIL;
irtmodelCON2520:
	local[11]= local[0];
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[60])(ctx,1,local+11,&ftab[60],fqv[593]); /*plusp*/
	if (w==NIL) goto irtmodelIF2530;
	local[11]= makeint((eusinteger_t)1L);
	goto irtmodelIF2531;
irtmodelIF2530:
	local[11]= makeint((eusinteger_t)-1L);
irtmodelIF2531:
	local[12]= local[0];
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)2L);
	ctx->vsp=local+14;
	w=(*ftab[28])(ctx,2,local+12,&ftab[28],fqv[201]); /*expt*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	local[12]= local[11];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)GREATERP(ctx,2,local+12); /*>*/
	if (w==NIL) goto irtmodelAND2535;
	local[12]= local[11];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)LESSP(ctx,2,local+12); /*<*/
	if (w==NIL) goto irtmodelAND2535;
	goto irtmodelOR2534;
irtmodelAND2535:
	local[12]= local[11];
	if (loadglobal(fqv[64])==local[12]) goto irtmodelOR2534;
	local[12]= local[11];
	if (loadglobal(fqv[63])==local[12]) goto irtmodelOR2534;
	goto irtmodelIF2532;
irtmodelOR2534:
	local[11] = makeflt(0.0000000000000000000000e+00);
	local[12]= local[11];
	goto irtmodelIF2533;
irtmodelIF2532:
	local[12]= NIL;
irtmodelIF2533:
	local[12]= local[0];
	local[13]= local[4];
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(pointer)SETELT(ctx,3,local+12); /*setelt*/
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto irtmodelWHL2513;
irtmodelWHX2514:
	local[6]= NIL;
irtmodelBLK2515:
	w = NIL;
	w = local[0];
	local[0]= w;
irtmodelBLK2510:
	ctx->vsp=local; return(local[0]);}

/*calc-jacobian-from-link-list-including-robot-and-obj-virtual-joint*/
static pointer irtmodelF740calc_jacobian_from_link_list_including_robot_and_obj_virtual_joint(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[594], &argv[4], n-4, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY2537;
	local[0] = fqv[595];
irtmodelKEY2537:
	if (n & (1<<1)) goto irtmodelKEY2538;
	local[1] = fqv[596];
irtmodelKEY2538:
	if (n & (1<<2)) goto irtmodelKEY2539;
	local[3]= argv[3];
	local[4]= fqv[210];
	local[5]= local[0];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	local[4]= argv[3];
	local[5]= fqv[211];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[23])(ctx,2,local+3,&ftab[23],fqv[166]); /*make-matrix*/
	local[2] = w;
irtmodelKEY2539:
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,irtmodelCLO2540,env,argv,local);
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)MAPCAR(ctx,2,local+3); /*mapcar*/
	local[3]= w;
	local[4]= NIL;
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtmodelCLO2541,env,argv,local);
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)MAPCAR(ctx,2,local+5); /*mapcar*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[54])(ctx,2,local+4,&ftab[54],fqv[548]); /*remove*/
	local[4]= w;
	local[5]= argv[3];
	local[6]= fqv[211];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= argv[3];
	local[7]= fqv[299];
	local[8]= local[4];
	local[9]= fqv[597];
	local[10]= local[5];
	local[11]= fqv[272];
	local[12]= local[2];
	local[13]= fqv[598];
	local[14]= argv[1];
	local[15]= fqv[300];
	local[16]= argv[2];
	local[17]= fqv[409];
	local[18]= local[0];
	local[19]= fqv[335];
	local[20]= local[1];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,15,local+6); /*send*/
	local[6]= argv[3];
	local[7]= fqv[299];
	local[8]= local[3];
	local[9]= fqv[300];
	local[10]= argv[1];
	local[11]= fqv[272];
	local[12]= local[2];
	local[13]= fqv[409];
	local[14]= local[0];
	local[15]= fqv[335];
	local[16]= local[1];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,11,local+6); /*send*/
	local[6]= makeint((eusinteger_t)0L);
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(*ftab[29])(ctx,1,local+7,&ftab[29],fqv[204]); /*array-dimensions*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
irtmodelWHL2542:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto irtmodelWHX2543;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(*ftab[29])(ctx,1,local+9,&ftab[29],fqv[204]); /*array-dimensions*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)MINUS(ctx,2,local+9); /*-*/
	local[9]= w;
irtmodelWHL2545:
	local[10]= local[8];
	w = local[9];
	if ((eusinteger_t)local[10] >= (eusinteger_t)w) goto irtmodelWHX2546;
	local[10]= local[2];
	local[11]= local[6];
	local[12]= local[5];
	local[13]= local[8];
	ctx->vsp=local+14;
	w=(pointer)PLUS(ctx,2,local+12); /*+*/
	local[12]= w;
	local[13]= makeflt(-1.0000000000000000000000e+00);
	local[14]= local[2];
	local[15]= local[6];
	local[16]= local[5];
	local[17]= local[8];
	ctx->vsp=local+18;
	w=(pointer)PLUS(ctx,2,local+16); /*+*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)AREF(ctx,3,local+14); /*aref*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)TIMES(ctx,2,local+13); /***/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)ASET(ctx,4,local+10); /*aset*/
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	goto irtmodelWHL2545;
irtmodelWHX2546:
	local[10]= NIL;
irtmodelBLK2547:
	w = NIL;
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto irtmodelWHL2542;
irtmodelWHX2543:
	local[8]= NIL;
irtmodelBLK2544:
	w = NIL;
	w = local[2];
	local[0]= w;
irtmodelBLK2536:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2540(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtmodelCLO2548,env,argv,local);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[55])(ctx,2,local+0,&ftab[55],fqv[561]); /*remove-if-not*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2548(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env0->c.clo.env1[3];
	local[2]= fqv[136];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[124]); /*member*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2541(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtmodelCLO2549,env,argv,local);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[61])(ctx,2,local+0,&ftab[61],fqv[599]); /*remove-if*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2549(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env0->c.clo.env1[3];
	local[2]= fqv[136];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[124]); /*member*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*append-obj-virtual-joint*/
static pointer irtmodelF741append_obj_virtual_joint(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[600], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY2551;
	local[0] = loadglobal(fqv[601]);
irtmodelKEY2551:
	if (n & (1<<1)) goto irtmodelKEY2552;
	local[1] = NIL;
irtmodelKEY2552:
	if (n & (1<<2)) goto irtmodelKEY2553;
	local[2] = NIL;
irtmodelKEY2553:
	if (n & (1<<3)) goto irtmodelKEY2554;
	local[3] = NIL;
irtmodelKEY2554:
	if (n & (1<<4)) goto irtmodelKEY2555;
	local[4] = NIL;
irtmodelKEY2555:
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtmodelFLET2556,env,argv,local);
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtmodelCLO2557,env,argv,local);
	local[7]= argv[1];
	ctx->vsp=local+8;
	w=(pointer)MAPCAR(ctx,2,local+6); /*mapcar*/
	local[6]= w;
	if (local[2]==NIL) goto irtmodelIF2558;
	local[7]= local[2];
	goto irtmodelIF2559;
irtmodelIF2558:
	local[7]= fqv[602];
	if (local[3]==NIL) goto irtmodelIF2560;
	local[8]= local[3];
	goto irtmodelIF2561;
irtmodelIF2560:
	local[8]= makeint((eusinteger_t)1L);
	local[9]= argv[1];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	if (w!=local[8]) goto irtmodelIF2562;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= fqv[153];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	goto irtmodelIF2563;
irtmodelIF2562:
	local[8]= (pointer)get_sym_func(fqv[603]);
	local[9]= makeflt(5.0000000000000000000000e-01);
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)APPLY(ctx,3,local+8); /*apply*/
	local[8]= w;
irtmodelIF2563:
irtmodelIF2561:
	w = local[5];
	ctx->vsp=local+9;
	w=irtmodelFLET2556(ctx,2,local+7,w);
	local[7]= w;
irtmodelIF2559:
	local[8]= fqv[604];
	if (local[4]==NIL) goto irtmodelIF2564;
	local[9]= local[4];
	goto irtmodelIF2565;
irtmodelIF2564:
	local[9]= local[7];
	local[10]= fqv[153];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
irtmodelIF2565:
	w = local[5];
	ctx->vsp=local+10;
	w=irtmodelFLET2556(ctx,2,local+8,w);
	local[8]= w;
	local[9]= NIL;
	local[10]= local[6];
irtmodelWHL2566:
	if (local[10]==NIL) goto irtmodelWHX2567;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10] = (w)->c.cons.cdr;
	w = local[11];
	local[9] = w;
	local[11]= local[8];
	local[12]= fqv[298];
	local[13]= local[9];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	goto irtmodelWHL2566;
irtmodelWHX2567:
	local[11]= NIL;
irtmodelBLK2568:
	w = NIL;
	local[9]= local[7];
	local[10]= fqv[298];
	local[11]= local[8];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= local[8];
	local[10]= loadglobal(fqv[213]);
	local[11]= fqv[131];
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)INSTANTIATE(ctx,1,local+12); /*instantiate*/
	local[12]= w;
	local[13]= (pointer)get_sym_func(fqv[288]);
	local[14]= local[12];
	local[15]= fqv[36];
	local[16]= fqv[130];
	local[17]= local[8];
	local[18]= fqv[133];
	local[19]= local[7];
	local[20]= local[1];
	ctx->vsp=local+21;
	w=(pointer)APPLY(ctx,8,local+13); /*apply*/
	w = local[12];
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)SENDMESSAGE(ctx,4,local+9); /*send-message*/
	local[9]= local[8];
	local[10]= fqv[132];
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= local[7];
	local[10]= fqv[134];
	local[11]= local[8];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,irtmodelCLO2569,env,argv,local);
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(pointer)MAPCAR(ctx,2,local+9); /*mapcar*/
	local[9]= w;
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,2,local+9); /*list*/
	local[0]= w;
irtmodelBLK2550:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelFLET2556(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[213]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[36];
	local[3]= fqv[120];
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(*ftab[40])(ctx,2,local+3,&ftab[40],fqv[297]); /*make-cascoords*/
	local[3]= w;
	local[4]= fqv[127];
	local[5]= makeint((eusinteger_t)10L);
	local[6]= makeint((eusinteger_t)10L);
	local[7]= makeint((eusinteger_t)10L);
	ctx->vsp=local+8;
	w=(*ftab[62])(ctx,3,local+5,&ftab[62],fqv[605]); /*make-cube*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	local[5]= w;
	local[6]= fqv[3];
	local[7]= argv[0];
	local[8]= fqv[273];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= fqv[257];
	local[11]= fqv[606];
	local[12]= fqv[607];
	local[13]= makeint((eusinteger_t)3L);
	local[14]= makeint((eusinteger_t)3L);
	ctx->vsp=local+15;
	w=(*ftab[23])(ctx,2,local+13,&ftab[23],fqv[166]); /*make-matrix*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,13,local+1); /*send*/
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2557(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[120];
	local[1]= argv[0];
	local[2]= fqv[153];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[40])(ctx,2,local+0,&ftab[40],fqv[297]); /*make-cascoords*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2569(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env2[8];
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPEND(ctx,2,local+0); /*append*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*append-multiple-obj-virtual-joint*/
static pointer irtmodelF742append_multiple_obj_virtual_joint(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[608], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtmodelKEY2571;
	local[0] = fqv[609];
irtmodelKEY2571:
	if (n & (1<<1)) goto irtmodelKEY2572;
	local[1] = fqv[610];
irtmodelKEY2572:
	if (n & (1<<2)) goto irtmodelKEY2573;
	local[2] = NIL;
irtmodelKEY2573:
	if (n & (1<<3)) goto irtmodelKEY2574;
	local[3] = NIL;
irtmodelKEY2574:
	if (n & (1<<4)) goto irtmodelKEY2575;
	local[4] = NIL;
irtmodelKEY2575:
	local[5]= argv[0];
	local[6]= local[2];
	local[7]= local[3];
	local[8]= NIL;
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,irtmodelCLO2576,env,argv,local);
	local[10]= local[0];
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)MAPCAR(ctx,3,local+9); /*mapcar*/
	w = local[8];
	local[0]= w;
irtmodelBLK2570:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2576(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= env->c.clo.env2[5];
	local[1]= env->c.clo.env1[1];
	local[2]= fqv[611];
	local[3]= argv[0];
	local[4]= fqv[612];
	local[5]= argv[1];
	local[6]= fqv[613];
	local[7]= env->c.clo.env2[6];
	local[8]= fqv[614];
	local[9]= env->c.clo.env2[7];
	local[10]= fqv[615];
	local[11]= env->c.clo.env2[4];
	ctx->vsp=local+12;
	w=(pointer)irtmodelF741append_obj_virtual_joint(ctx,12,local+0); /*append-obj-virtual-joint*/
	env->c.clo.env2[8] = w;
	w=env->c.clo.env2[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	env->c.clo.env2[5] = (w)->c.cons.car;
	w=env->c.clo.env2[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	ctx->vsp=local+1;
	w=(*ftab[38])(ctx,1,local+0,&ftab[38],fqv[291]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	env->c.clo.env2[6] = (w)->c.cons.car;
	w = env->c.clo.env2[6];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*with-difference-position-and-rotation*/
static pointer irtmodelF2577(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtmodelRST2579:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	ctx->vsp=local+1;
	w=(pointer)GENSYM(ctx,0,local+1); /*gensym*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,0,local+2); /*gensym*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)GENSYM(ctx,0,local+3); /*gensym*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)GENSYM(ctx,0,local+4); /*gensym*/
	local[4]= w;
	local[5]= fqv[527];
	local[6]= local[1];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= local[2];
	local[8]= argv[0];
	ctx->vsp=local+9;
	w=(*ftab[63])(ctx,1,local+8,&ftab[63],fqv[616]); /*cadddr*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= local[4];
	local[9]= fqv[335];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(*ftab[16])(ctx,2,local+9,&ftab[16],fqv[124]); /*member*/
	if (w==NIL) goto irtmodelIF2580;
	local[9]= fqv[335];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(*ftab[16])(ctx,2,local+9,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	goto irtmodelIF2581;
irtmodelIF2580:
	local[9]= T;
irtmodelIF2581:
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= local[3];
	local[10]= fqv[409];
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(*ftab[16])(ctx,2,local+10,&ftab[16],fqv[124]); /*member*/
	if (w==NIL) goto irtmodelIF2582;
	local[10]= fqv[409];
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(*ftab[16])(ctx,2,local+10,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	goto irtmodelIF2583;
irtmodelIF2582:
	local[10]= T;
irtmodelIF2583:
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[527];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= fqv[288];
	local[10]= local[1];
	local[11]= fqv[571];
	local[12]= local[2];
	local[13]= fqv[335];
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= fqv[288];
	local[11]= local[1];
	local[12]= fqv[572];
	local[13]= local[2];
	local[14]= fqv[409];
	local[15]= local[3];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= local[0];
	local[10]= NIL;
	ctx->vsp=local+11;
	w=(pointer)APPEND(ctx,2,local+9); /*append*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	local[0]= w;
irtmodelBLK2578:
	ctx->vsp=local; return(local[0]);}

/*with-difference-positions-and-rotations*/
static pointer irtmodelF2584(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtmodelRST2586:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	ctx->vsp=local+1;
	w=(pointer)GENSYM(ctx,0,local+1); /*gensym*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,0,local+2); /*gensym*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)GENSYM(ctx,0,local+3); /*gensym*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)GENSYM(ctx,0,local+4); /*gensym*/
	local[4]= w;
	local[5]= fqv[577];
	local[6]= local[1];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= local[2];
	local[8]= argv[0];
	ctx->vsp=local+9;
	w=(*ftab[63])(ctx,1,local+8,&ftab[63],fqv[616]); /*cadddr*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= local[4];
	local[9]= fqv[617];
	local[10]= fqv[335];
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(*ftab[16])(ctx,2,local+10,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= fqv[335];
	local[12]= argv[0];
	ctx->vsp=local+13;
	w=(*ftab[16])(ctx,2,local+11,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= fqv[208];
	local[13]= fqv[426];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	local[14]= fqv[209];
	local[15]= fqv[618];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= local[3];
	local[10]= fqv[617];
	local[11]= fqv[409];
	local[12]= argv[0];
	ctx->vsp=local+13;
	w=(*ftab[16])(ctx,2,local+11,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= fqv[409];
	local[13]= argv[0];
	ctx->vsp=local+14;
	w=(*ftab[16])(ctx,2,local+12,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= fqv[208];
	local[14]= fqv[426];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	local[14]= cons(ctx,local[14],w);
	local[15]= fqv[209];
	local[16]= fqv[618];
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,1,local+16); /*list*/
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[527];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= fqv[619];
	local[10]= fqv[516];
	local[11]= fqv[517];
	local[12]= fqv[620];
	local[13]= fqv[621];
	local[14]= fqv[622];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	local[13]= fqv[288];
	local[14]= fqv[620];
	local[15]= fqv[571];
	local[16]= fqv[621];
	local[17]= fqv[335];
	local[18]= fqv[622];
	ctx->vsp=local+19;
	w=(pointer)LIST(ctx,1,local+18); /*list*/
	ctx->vsp=local+18;
	w = cons(ctx,local[17],w);
	ctx->vsp=local+17;
	w = cons(ctx,local[16],w);
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= local[1];
	local[12]= local[2];
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= fqv[619];
	local[11]= fqv[516];
	local[12]= fqv[517];
	local[13]= fqv[620];
	local[14]= fqv[621];
	local[15]= fqv[623];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	local[14]= fqv[288];
	local[15]= fqv[620];
	local[16]= fqv[572];
	local[17]= fqv[621];
	local[18]= fqv[409];
	local[19]= fqv[623];
	ctx->vsp=local+20;
	w=(pointer)LIST(ctx,1,local+19); /*list*/
	ctx->vsp=local+19;
	w = cons(ctx,local[18],w);
	ctx->vsp=local+18;
	w = cons(ctx,local[17],w);
	ctx->vsp=local+17;
	w = cons(ctx,local[16],w);
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	local[14]= cons(ctx,local[14],w);
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	local[12]= local[1];
	local[13]= local[2];
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= local[0];
	local[10]= NIL;
	ctx->vsp=local+11;
	w=(pointer)APPEND(ctx,2,local+9); /*append*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	local[0]= w;
irtmodelBLK2585:
	ctx->vsp=local; return(local[0]);}

/*with-move-target-link-list*/
static pointer irtmodelF2587(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtmodelRST2589:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	ctx->vsp=local+1;
	w=(pointer)GENSYM(ctx,0,local+1); /*gensym*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,0,local+2); /*gensym*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)GENSYM(ctx,0,local+3); /*gensym*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)GENSYM(ctx,0,local+4); /*gensym*/
	local[4]= w;
	local[5]= fqv[577];
	local[6]= local[3];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= local[4];
	local[8]= fqv[617];
	local[9]= fqv[624];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(*ftab[63])(ctx,1,local+10,&ftab[63],fqv[616]); /*cadddr*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[521];
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(*ftab[63])(ctx,1,local+11,&ftab[63],fqv[616]); /*cadddr*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(*ftab[63])(ctx,1,local+11,&ftab[63],fqv[616]); /*cadddr*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= local[1];
	local[9]= fqv[625];
	local[10]= fqv[300];
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(*ftab[16])(ctx,2,local+10,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= fqv[617];
	local[12]= fqv[624];
	local[13]= fqv[300];
	local[14]= argv[0];
	ctx->vsp=local+15;
	w=(*ftab[16])(ctx,2,local+13,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	local[13]= fqv[521];
	local[14]= fqv[300];
	local[15]= argv[0];
	ctx->vsp=local+16;
	w=(*ftab[16])(ctx,2,local+14,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	local[14]= fqv[300];
	local[15]= argv[0];
	ctx->vsp=local+16;
	w=(*ftab[16])(ctx,2,local+14,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= fqv[618];
	local[12]= fqv[619];
	local[13]= fqv[516];
	local[14]= fqv[517];
	local[15]= fqv[626];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	local[15]= w;
	local[16]= fqv[288];
	local[17]= local[3];
	local[18]= fqv[626];
	local[19]= fqv[627];
	ctx->vsp=local+20;
	w=(pointer)LIST(ctx,1,local+19); /*list*/
	ctx->vsp=local+19;
	w = cons(ctx,local[18],w);
	ctx->vsp=local+18;
	w = cons(ctx,local[17],w);
	ctx->vsp=local+17;
	local[16]= cons(ctx,local[16],w);
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,1,local+16); /*list*/
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	local[14]= cons(ctx,local[14],w);
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= local[2];
	local[10]= fqv[619];
	local[11]= fqv[516];
	local[12]= fqv[517];
	local[13]= fqv[628];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	local[13]= w;
	local[14]= fqv[288];
	local[15]= local[3];
	local[16]= fqv[260];
	local[17]= fqv[288];
	local[18]= fqv[628];
	local[19]= fqv[214];
	ctx->vsp=local+20;
	w=(pointer)LIST(ctx,1,local+19); /*list*/
	ctx->vsp=local+19;
	w = cons(ctx,local[18],w);
	ctx->vsp=local+18;
	local[17]= cons(ctx,local[17],w);
	ctx->vsp=local+18;
	w=(pointer)LIST(ctx,1,local+17); /*list*/
	ctx->vsp=local+17;
	w = cons(ctx,local[16],w);
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	local[14]= cons(ctx,local[14],w);
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[527];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= local[0];
	local[10]= NIL;
	ctx->vsp=local+11;
	w=(pointer)APPEND(ctx,2,local+9); /*append*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	local[0]= w;
irtmodelBLK2588:
	ctx->vsp=local; return(local[0]);}

/*with-append-root-joint*/
static pointer irtmodelF2590(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtmodelRST2592:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	ctx->vsp=local+1;
	w=(pointer)GENSYM(ctx,0,local+1); /*gensym*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,0,local+2); /*gensym*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)GENSYM(ctx,0,local+3); /*gensym*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)GENSYM(ctx,0,local+4); /*gensym*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)GENSYM(ctx,0,local+5); /*gensym*/
	local[5]= w;
	local[6]= fqv[512];
	local[7]= fqv[527];
	local[8]= local[1];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= local[2];
	local[10]= fqv[617];
	local[11]= fqv[567];
	local[12]= fqv[516];
	local[13]= fqv[629];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= fqv[521];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= local[5];
	local[11]= fqv[612];
	local[12]= argv[0];
	ctx->vsp=local+13;
	w=(*ftab[16])(ctx,2,local+11,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= fqv[527];
	local[10]= local[3];
	local[11]= fqv[511];
	local[12]= fqv[213];
	local[13]= fqv[36];
	local[14]= fqv[297];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	local[14]= w;
	local[15]= fqv[127];
	local[16]= fqv[521];
	local[17]= fqv[605];
	local[18]= fqv[630];
	local[19]= fqv[631];
	local[20]= fqv[632];
	ctx->vsp=local+21;
	w=(pointer)LIST(ctx,1,local+20); /*list*/
	ctx->vsp=local+20;
	w = cons(ctx,local[19],w);
	ctx->vsp=local+19;
	w = cons(ctx,local[18],w);
	ctx->vsp=local+18;
	local[17]= cons(ctx,local[17],w);
	ctx->vsp=local+18;
	w=(pointer)LIST(ctx,1,local+17); /*list*/
	ctx->vsp=local+17;
	local[16]= cons(ctx,local[16],w);
	local[17]= fqv[3];
	local[18]= fqv[459];
	local[19]= fqv[633];
	ctx->vsp=local+20;
	w=(pointer)LIST(ctx,1,local+19); /*list*/
	ctx->vsp=local+19;
	local[18]= cons(ctx,local[18],w);
	local[19]= fqv[273];
	local[20]= fqv[634];
	local[21]= fqv[257];
	local[22]= fqv[5];
	local[23]= fqv[635];
	local[24]= fqv[636];
	local[25]= fqv[637];
	ctx->vsp=local+26;
	w=(pointer)LIST(ctx,1,local+25); /*list*/
	ctx->vsp=local+25;
	w = cons(ctx,local[24],w);
	ctx->vsp=local+24;
	w = cons(ctx,local[23],w);
	ctx->vsp=local+23;
	local[22]= cons(ctx,local[22],w);
	local[23]= fqv[607];
	local[24]= fqv[166];
	local[25]= fqv[638];
	local[26]= fqv[639];
	ctx->vsp=local+27;
	w=(pointer)LIST(ctx,1,local+26); /*list*/
	ctx->vsp=local+26;
	w = cons(ctx,local[25],w);
	ctx->vsp=local+25;
	local[24]= cons(ctx,local[24],w);
	ctx->vsp=local+25;
	w=(pointer)LIST(ctx,1,local+24); /*list*/
	ctx->vsp=local+24;
	w = cons(ctx,local[23],w);
	ctx->vsp=local+23;
	w = cons(ctx,local[22],w);
	ctx->vsp=local+22;
	w = cons(ctx,local[21],w);
	ctx->vsp=local+21;
	w = cons(ctx,local[20],w);
	ctx->vsp=local+20;
	w = cons(ctx,local[19],w);
	ctx->vsp=local+19;
	w = cons(ctx,local[18],w);
	ctx->vsp=local+18;
	w = cons(ctx,local[17],w);
	ctx->vsp=local+17;
	w = cons(ctx,local[16],w);
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= local[4];
	local[12]= fqv[640];
	local[13]= fqv[288];
	local[14]= local[1];
	local[15]= fqv[136];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= fqv[34];
	local[12]= local[4];
	local[13]= fqv[213];
	local[14]= fqv[131];
	local[15]= fqv[641];
	local[16]= fqv[611];
	local[17]= argv[0];
	ctx->vsp=local+18;
	w=(*ftab[16])(ctx,2,local+16,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	if (local[16]!=NIL) goto irtmodelOR2593;
	local[16]= loadglobal(fqv[601]);
irtmodelOR2593:
	local[17]= fqv[36];
	local[18]= fqv[130];
	local[19]= local[1];
	local[20]= fqv[133];
	local[21]= local[3];
	local[22]= local[5];
	ctx->vsp=local+23;
	w=(pointer)LIST(ctx,1,local+22); /*list*/
	ctx->vsp=local+22;
	w = cons(ctx,local[21],w);
	ctx->vsp=local+21;
	w = cons(ctx,local[20],w);
	ctx->vsp=local+20;
	w = cons(ctx,local[19],w);
	ctx->vsp=local+19;
	w = cons(ctx,local[18],w);
	ctx->vsp=local+18;
	w = cons(ctx,local[17],w);
	ctx->vsp=local+17;
	w = cons(ctx,local[16],w);
	ctx->vsp=local+16;
	local[15]= cons(ctx,local[15],w);
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	local[12]= fqv[288];
	local[13]= local[4];
	local[14]= fqv[132];
	local[15]= local[3];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	local[13]= fqv[288];
	local[14]= local[3];
	local[15]= fqv[134];
	local[16]= local[4];
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,1,local+16); /*list*/
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	local[14]= fqv[642];
	local[15]= fqv[527];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	local[17]= fqv[619];
	local[18]= fqv[516];
	local[19]= fqv[517];
	local[20]= fqv[643];
	ctx->vsp=local+21;
	w=(pointer)LIST(ctx,1,local+20); /*list*/
	local[20]= w;
	local[21]= fqv[88];
	local[22]= local[4];
	local[23]= fqv[643];
	ctx->vsp=local+24;
	w=(pointer)LIST(ctx,1,local+23); /*list*/
	ctx->vsp=local+23;
	w = cons(ctx,local[22],w);
	ctx->vsp=local+22;
	local[21]= cons(ctx,local[21],w);
	ctx->vsp=local+22;
	w=(pointer)LIST(ctx,1,local+21); /*list*/
	ctx->vsp=local+21;
	w = cons(ctx,local[20],w);
	ctx->vsp=local+20;
	local[19]= cons(ctx,local[19],w);
	ctx->vsp=local+20;
	w=(pointer)LIST(ctx,1,local+19); /*list*/
	ctx->vsp=local+19;
	local[18]= cons(ctx,local[18],w);
	local[19]= local[2];
	ctx->vsp=local+20;
	w=(pointer)LIST(ctx,1,local+19); /*list*/
	ctx->vsp=local+19;
	w = cons(ctx,local[18],w);
	ctx->vsp=local+18;
	local[17]= cons(ctx,local[17],w);
	ctx->vsp=local+18;
	w=(pointer)LIST(ctx,1,local+17); /*list*/
	ctx->vsp=local+17;
	local[16]= cons(ctx,local[16],w);
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,1,local+16); /*list*/
	local[16]= w;
	local[17]= local[0];
	local[18]= NIL;
	ctx->vsp=local+19;
	w=(pointer)APPEND(ctx,2,local+17); /*append*/
	ctx->vsp=local+17;
	w = cons(ctx,local[16],w);
	ctx->vsp=local+16;
	local[15]= cons(ctx,local[15],w);
	local[16]= fqv[288];
	local[17]= local[4];
	local[18]= fqv[644];
	ctx->vsp=local+19;
	w=(pointer)LIST(ctx,1,local+18); /*list*/
	ctx->vsp=local+18;
	w = cons(ctx,local[17],w);
	ctx->vsp=local+17;
	local[16]= cons(ctx,local[16],w);
	local[17]= fqv[288];
	local[18]= local[4];
	local[19]= fqv[645];
	ctx->vsp=local+20;
	w=(pointer)LIST(ctx,1,local+19); /*list*/
	ctx->vsp=local+19;
	w = cons(ctx,local[18],w);
	ctx->vsp=local+18;
	local[17]= cons(ctx,local[17],w);
	local[18]= fqv[288];
	local[19]= local[3];
	local[20]= fqv[646];
	local[21]= local[4];
	ctx->vsp=local+22;
	w=(pointer)LIST(ctx,1,local+21); /*list*/
	ctx->vsp=local+21;
	w = cons(ctx,local[20],w);
	ctx->vsp=local+20;
	w = cons(ctx,local[19],w);
	ctx->vsp=local+19;
	local[18]= cons(ctx,local[18],w);
	ctx->vsp=local+19;
	w=(pointer)LIST(ctx,1,local+18); /*list*/
	ctx->vsp=local+18;
	w = cons(ctx,local[17],w);
	ctx->vsp=local+17;
	w = cons(ctx,local[16],w);
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	local[14]= cons(ctx,local[14],w);
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	local[0]= w;
irtmodelBLK2591:
	ctx->vsp=local; return(local[0]);}

/*with-assoc-move-target*/
static pointer irtmodelF2594(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtmodelRST2596:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	ctx->vsp=local+1;
	w=(pointer)GENSYM(ctx,0,local+1); /*gensym*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,0,local+2); /*gensym*/
	local[2]= w;
	local[3]= fqv[527];
	local[4]= local[1];
	local[5]= fqv[617];
	local[6]= fqv[624];
	local[7]= fqv[300];
	local[8]= argv[0];
	ctx->vsp=local+9;
	w=(*ftab[16])(ctx,2,local+7,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[521];
	local[8]= fqv[300];
	local[9]= argv[0];
	ctx->vsp=local+10;
	w=(*ftab[16])(ctx,2,local+8,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[300];
	local[9]= argv[0];
	ctx->vsp=local+10;
	w=(*ftab[16])(ctx,2,local+8,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= local[2];
	local[6]= fqv[617];
	local[7]= fqv[624];
	local[8]= fqv[133];
	local[9]= argv[0];
	ctx->vsp=local+10;
	w=(*ftab[16])(ctx,2,local+8,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[521];
	local[9]= fqv[133];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(*ftab[16])(ctx,2,local+9,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= fqv[133];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(*ftab[16])(ctx,2,local+9,&ftab[16],fqv[124]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[457];
	local[6]= local[1];
	local[7]= fqv[619];
	local[8]= fqv[516];
	local[9]= fqv[517];
	local[10]= fqv[647];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	local[10]= w;
	local[11]= fqv[297];
	local[12]= fqv[120];
	local[13]= fqv[288];
	local[14]= fqv[647];
	local[15]= fqv[153];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[619];
	local[7]= fqv[516];
	local[8]= fqv[517];
	local[9]= fqv[648];
	local[10]= fqv[647];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[288];
	local[11]= fqv[648];
	local[12]= fqv[298];
	local[13]= fqv[647];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= local[2];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[642];
	local[8]= fqv[527];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	local[9]= w;
	local[10]= local[0];
	local[11]= NIL;
	ctx->vsp=local+12;
	w=(pointer)APPEND(ctx,2,local+10); /*append*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= fqv[619];
	local[10]= fqv[516];
	local[11]= fqv[517];
	local[12]= fqv[649];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	local[12]= w;
	local[13]= fqv[288];
	local[14]= fqv[288];
	local[15]= fqv[649];
	local[16]= fqv[214];
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,1,local+16); /*list*/
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	local[14]= cons(ctx,local[14],w);
	local[15]= fqv[301];
	local[16]= fqv[649];
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,1,local+16); /*list*/
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	local[0]= w;
irtmodelBLK2595:
	ctx->vsp=local; return(local[0]);}

/*eusmodel-validity-check-one*/
static pointer irtmodelF743eusmodel_validity_check_one(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[136];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
irtmodelWHL2598:
	local[1]= local[0];
	local[2]= fqv[133];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (w==NIL) goto irtmodelWHX2599;
	local[1]= loadglobal(fqv[176]);
	local[2]= NIL;
	local[3]= fqv[650];
	local[4]= local[0];
	local[5]= local[0];
	local[6]= fqv[133];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,4,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,2,local+1); /*format*/
	local[1]= loadglobal(fqv[176]);
	ctx->vsp=local+2;
	w=(pointer)FINOUT(ctx,1,local+1); /*finish-output*/
	local[1]= fqv[651];
	ctx->vsp=local+2;
	w=(*ftab[64])(ctx,1,local+1,&ftab[64],fqv[652]); /*reploop*/
	goto irtmodelWHL2598;
irtmodelWHX2599:
	local[1]= NIL;
irtmodelBLK2600:
irtmodelWHL2601:
	local[1]= argv[0];
	local[2]= local[0];
	local[3]= fqv[214];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)EQUAL(ctx,2,local+1); /*equal*/
	if (w!=NIL) goto irtmodelWHX2602;
	local[1]= loadglobal(fqv[176]);
	local[2]= NIL;
	local[3]= fqv[653];
	local[4]= local[0];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,4,local+2); /*format*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,2,local+1); /*format*/
	local[1]= loadglobal(fqv[176]);
	ctx->vsp=local+2;
	w=(pointer)FINOUT(ctx,1,local+1); /*finish-output*/
	local[1]= fqv[654];
	ctx->vsp=local+2;
	w=(*ftab[64])(ctx,1,local+1,&ftab[64],fqv[652]); /*reploop*/
	goto irtmodelWHL2601;
irtmodelWHX2602:
	local[1]= NIL;
irtmodelBLK2603:
	w = local[1];
	local[0]= (pointer)get_sym_func(fqv[655]);
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtmodelCLO2604,env,argv,local);
	local[2]= argv[0];
	local[3]= fqv[656];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[55])(ctx,2,local+1,&ftab[55],fqv[561]); /*remove-if-not*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[657];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPEND(ctx,2,local+0); /*append*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[47])(ctx,1,local+0,&ftab[47],fqv[445]); /*remove-duplicates*/
	local[0]= w;
	local[1]= (pointer)get_sym_func(fqv[655]);
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtmodelCLO2605,env,argv,local);
	local[3]= argv[0];
	local[4]= fqv[656];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[55])(ctx,2,local+2,&ftab[55],fqv[561]); /*remove-if-not*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[136];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)APPEND(ctx,2,local+1); /*append*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[47])(ctx,1,local+1,&ftab[47],fqv[445]); /*remove-duplicates*/
	local[1]= w;
irtmodelWHL2606:
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
	w = makeint((eusinteger_t)1L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[2]= (pointer)((eusinteger_t)local[2] + (eusinteger_t)w);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	if (w==local[2]) goto irtmodelWHX2607;
	local[2]= loadglobal(fqv[176]);
	local[3]= NIL;
	local[4]= fqv[658];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,4,local+3); /*format*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,2,local+2); /*format*/
	local[2]= loadglobal(fqv[176]);
	ctx->vsp=local+3;
	w=(pointer)FINOUT(ctx,1,local+2); /*finish-output*/
	local[2]= fqv[659];
	ctx->vsp=local+3;
	w=(*ftab[64])(ctx,1,local+2,&ftab[64],fqv[652]); /*reploop*/
	goto irtmodelWHL2606;
irtmodelWHX2607:
	local[2]= NIL;
irtmodelBLK2608:
	local[2]= NIL;
	local[3]= local[0];
irtmodelWHL2609:
	if (local[3]==NIL) goto irtmodelWHX2610;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
irtmodelWHL2612:
	local[4]= local[2];
	local[5]= fqv[130];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	if (w==NIL) goto irtmodelAND2615;
	local[4]= local[2];
	local[5]= fqv[130];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= loadglobal(fqv[213]);
	ctx->vsp=local+6;
	w=(pointer)DERIVEDP(ctx,2,local+4); /*derivedp*/
	if (w==NIL) goto irtmodelAND2615;
	goto irtmodelWHX2613;
irtmodelAND2615:
	local[4]= loadglobal(fqv[176]);
	local[5]= NIL;
	local[6]= fqv[660];
	local[7]= local[2];
	local[8]= local[2];
	local[9]= fqv[130];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,4,local+5); /*format*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,2,local+4); /*format*/
	local[4]= loadglobal(fqv[176]);
	ctx->vsp=local+5;
	w=(pointer)FINOUT(ctx,1,local+4); /*finish-output*/
	local[4]= fqv[661];
	ctx->vsp=local+5;
	w=(*ftab[64])(ctx,1,local+4,&ftab[64],fqv[652]); /*reploop*/
	goto irtmodelWHL2612;
irtmodelWHX2613:
	local[4]= NIL;
irtmodelBLK2614:
irtmodelWHL2616:
	local[4]= local[2];
	local[5]= fqv[133];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	if (w==NIL) goto irtmodelAND2619;
	local[4]= local[2];
	local[5]= fqv[133];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= loadglobal(fqv[213]);
	ctx->vsp=local+6;
	w=(pointer)DERIVEDP(ctx,2,local+4); /*derivedp*/
	if (w==NIL) goto irtmodelAND2619;
	goto irtmodelWHX2617;
irtmodelAND2619:
	local[4]= loadglobal(fqv[176]);
	local[5]= NIL;
	local[6]= fqv[662];
	local[7]= local[2];
	local[8]= local[2];
	local[9]= fqv[133];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,4,local+5); /*format*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,2,local+4); /*format*/
	local[4]= loadglobal(fqv[176]);
	ctx->vsp=local+5;
	w=(pointer)FINOUT(ctx,1,local+4); /*finish-output*/
	local[4]= fqv[663];
	ctx->vsp=local+5;
	w=(*ftab[64])(ctx,1,local+4,&ftab[64],fqv[652]); /*reploop*/
	goto irtmodelWHL2616;
irtmodelWHX2617:
	local[4]= NIL;
irtmodelBLK2618:
irtmodelWHL2620:
	local[4]= local[2];
	local[5]= fqv[130];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[2];
	local[6]= fqv[133];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= fqv[546];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[16])(ctx,2,local+4,&ftab[16],fqv[124]); /*member*/
	if (w==NIL) goto irtmodelAND2623;
	local[4]= local[2];
	local[5]= fqv[133];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[2];
	local[6]= fqv[130];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= fqv[214];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)EQUAL(ctx,2,local+4); /*equal*/
	if (w==NIL) goto irtmodelAND2623;
	goto irtmodelWHX2621;
irtmodelAND2623:
	local[4]= loadglobal(fqv[176]);
	local[5]= NIL;
	local[6]= fqv[664];
	local[7]= local[2];
	local[8]= local[2];
	local[9]= fqv[133];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[2];
	local[10]= fqv[130];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)XFORMAT(ctx,5,local+5); /*format*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,2,local+4); /*format*/
	local[4]= loadglobal(fqv[176]);
	ctx->vsp=local+5;
	w=(pointer)FINOUT(ctx,1,local+4); /*finish-output*/
	local[4]= fqv[665];
	ctx->vsp=local+5;
	w=(*ftab[64])(ctx,1,local+4,&ftab[64],fqv[652]); /*reploop*/
	goto irtmodelWHL2620;
irtmodelWHX2621:
	local[4]= NIL;
irtmodelBLK2622:
irtmodelWHL2624:
	local[4]= local[2];
	local[5]= fqv[130];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= fqv[133];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[2];
	local[6]= fqv[133];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)EQUAL(ctx,2,local+4); /*equal*/
	if (w==NIL) goto irtmodelAND2627;
	local[4]= local[2];
	local[5]= fqv[130];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[2];
	local[6]= fqv[133];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= fqv[547];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[16])(ctx,2,local+4,&ftab[16],fqv[124]); /*member*/
	if (w==NIL) goto irtmodelAND2627;
	goto irtmodelWHX2625;
irtmodelAND2627:
	local[4]= loadglobal(fqv[176]);
	local[5]= NIL;
	local[6]= fqv[666];
	local[7]= local[2];
	local[8]= local[2];
	local[9]= fqv[130];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[2];
	local[10]= fqv[133];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)XFORMAT(ctx,5,local+5); /*format*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,2,local+4); /*format*/
	local[4]= loadglobal(fqv[176]);
	ctx->vsp=local+5;
	w=(pointer)FINOUT(ctx,1,local+4); /*finish-output*/
	local[4]= fqv[667];
	ctx->vsp=local+5;
	w=(*ftab[64])(ctx,1,local+4,&ftab[64],fqv[652]); /*reploop*/
	goto irtmodelWHL2624;
irtmodelWHX2625:
	local[4]= NIL;
irtmodelBLK2626:
	goto irtmodelWHL2609;
irtmodelWHX2610:
	local[4]= NIL;
irtmodelBLK2611:
	w = NIL;
	local[0]= w;
irtmodelBLK2597:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2604(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= loadglobal(fqv[28]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtmodelCLO2605(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= loadglobal(fqv[213]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*eusmodel-validity-check*/
static pointer irtmodelF744eusmodel_validity_check(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[668];
	local[1]= fqv[669];
	ctx->vsp=local+2;
	w=(*ftab[65])(ctx,2,local+0,&ftab[65],fqv[670]); /*require*/
	ctx->vsp=local+0;
	w=(*ftab[66])(ctx,0,local+0,&ftab[66],fqv[671]); /*init-unit-test*/
	local[0]= NIL;
	storeglobal(fqv[672],local[0]);
	local[0]= fqv[673];
	local[1]= fqv[674];
	local[2]= fqv[675];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	local[0]= cons(ctx,local[0],w);
	ctx->vsp=local+1;
	w=(pointer)EVAL(ctx,1,local+0); /*eval*/
	ctx->vsp=local+0;
	w=(*ftab[67])(ctx,0,local+0,&ftab[67],fqv[676]); /*run-all-tests*/
	local[0]= w;
irtmodelBLK2628:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___irtmodel(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[677];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtmodelIF2629;
	local[0]= fqv[678];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[679],w);
	goto irtmodelIF2630;
irtmodelIF2629:
	local[0]= fqv[680];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtmodelIF2630:
	local[0]= fqv[681];
	ctx->vsp=local+1;
	w=(*ftab[65])(ctx,1,local+0,&ftab[65],fqv[670]); /*require*/
	local[0]= fqv[682];
	ctx->vsp=local+1;
	w=(*ftab[65])(ctx,1,local+0,&ftab[65],fqv[670]); /*require*/
	local[0]= fqv[683];
	ctx->vsp=local+1;
	w=(*ftab[65])(ctx,1,local+0,&ftab[65],fqv[670]); /*require*/
	local[0]= fqv[28];
	local[1]= fqv[684];
	local[2]= fqv[28];
	local[3]= fqv[685];
	local[4]= loadglobal(fqv[686]);
	local[5]= fqv[656];
	local[6]= fqv[687];
	local[7]= fqv[688];
	local[8]= NIL;
	local[9]= fqv[689];
	local[10]= NIL;
	local[11]= fqv[439];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[690];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[68])(ctx,13,local+2,&ftab[68],fqv[691]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM745joint_init,fqv[36],fqv[28],fqv[692]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM766joint_min_angle,fqv[22],fqv[28],fqv[693]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM772joint_max_angle,fqv[23],fqv[28],fqv[694]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM778joint_parent_link,fqv[133],fqv[28],fqv[695]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM781joint_child_link,fqv[130],fqv[28],fqv[696]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM784joint_calc_dav_gain,fqv[697],fqv[28],fqv[698]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM786joint_joint_dof,fqv[31],fqv[28],fqv[699]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM788joint_speed_to_angle,fqv[311],fqv[28],fqv[700]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM791joint_angle_to_speed,fqv[590],fqv[28],fqv[701]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM794joint_calc_jacobian,fqv[229],fqv[28],fqv[702]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM797joint_joint_velocity,fqv[37],fqv[28],fqv[703]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM803joint_joint_acceleration,fqv[38],fqv[28],fqv[704]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM809joint_joint_torque,fqv[39],fqv[28],fqv[705]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM815joint_max_joint_velocity,fqv[8],fqv[28],fqv[706]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM821joint_max_joint_torque,fqv[9],fqv[28],fqv[707]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM827joint_joint_min_max_table,fqv[10],fqv[28],fqv[708]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM833joint_joint_min_max_target,fqv[11],fqv[28],fqv[709]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM839joint_joint_min_max_table_angle_interpolate,fqv[21],fqv[28],fqv[710]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM842joint_joint_min_max_table_min_angle,fqv[41],fqv[28],fqv[711]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM846joint_joint_min_max_table_max_angle,fqv[42],fqv[28],fqv[712]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[713],module,irtmodelF729calc_jacobian_default_rotate_vector,fqv[714]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[50],module,irtmodelF730calc_jacobian_rotational,fqv[715]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[61],module,irtmodelF731calc_jacobian_linear,fqv[716]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[717],module,irtmodelF732calc_angle_speed_gain_scalar,fqv[718]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[719],module,irtmodelF733calc_angle_speed_gain_vector,fqv[720]);
	local[0]= fqv[721];
	local[1]= fqv[684];
	local[2]= fqv[721];
	local[3]= fqv[685];
	local[4]= loadglobal(fqv[28]);
	local[5]= fqv[656];
	local[6]= fqv[722];
	local[7]= fqv[688];
	local[8]= NIL;
	local[9]= fqv[689];
	local[10]= NIL;
	local[11]= fqv[439];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[690];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[68])(ctx,13,local+2,&ftab[68],fqv[691]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM882rotational_joint_init,fqv[36],fqv[721],fqv[723]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM892rotational_joint_joint_angle,fqv[20],fqv[721],fqv[724]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM911rotational_joint_joint_dof,fqv[31],fqv[721],fqv[725]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM913rotational_joint_calc_angle_speed_gain,fqv[245],fqv[721],fqv[726]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM915rotational_joint_speed_to_angle,fqv[311],fqv[721],fqv[727]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM917rotational_joint_angle_to_speed,fqv[590],fqv[721],fqv[728]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM919rotational_joint_calc_jacobian,fqv[229],fqv[721],fqv[729]);
	local[0]= fqv[730];
	local[1]= fqv[684];
	local[2]= fqv[730];
	local[3]= fqv[685];
	local[4]= loadglobal(fqv[28]);
	local[5]= fqv[656];
	local[6]= fqv[731];
	local[7]= fqv[688];
	local[8]= NIL;
	local[9]= fqv[689];
	local[10]= NIL;
	local[11]= fqv[439];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[690];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[68])(ctx,13,local+2,&ftab[68],fqv[691]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM922linear_joint_init,fqv[36],fqv[730],fqv[732]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM946linear_joint_joint_angle,fqv[20],fqv[730],fqv[733]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM963linear_joint_joint_dof,fqv[31],fqv[730],fqv[734]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM965linear_joint_calc_angle_speed_gain,fqv[245],fqv[730],fqv[735]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM967linear_joint_speed_to_angle,fqv[311],fqv[730],fqv[736]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM969linear_joint_angle_to_speed,fqv[590],fqv[730],fqv[737]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM971linear_joint_calc_jacobian,fqv[229],fqv[730],fqv[738]);
	local[0]= fqv[739];
	local[1]= fqv[684];
	local[2]= fqv[739];
	local[3]= fqv[685];
	local[4]= loadglobal(fqv[28]);
	local[5]= fqv[656];
	local[6]= fqv[740];
	local[7]= fqv[688];
	local[8]= NIL;
	local[9]= fqv[689];
	local[10]= NIL;
	local[11]= fqv[439];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[690];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[68])(ctx,13,local+2,&ftab[68],fqv[691]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM974wheel_joint_init,fqv[36],fqv[739],fqv[741]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM981wheel_joint_joint_angle,fqv[20],fqv[739],fqv[742]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM992wheel_joint_joint_dof,fqv[31],fqv[739],fqv[743]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM994wheel_joint_calc_angle_speed_gain,fqv[245],fqv[739],fqv[744]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM996wheel_joint_speed_to_angle,fqv[311],fqv[739],fqv[745]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM998wheel_joint_angle_to_speed,fqv[590],fqv[739],fqv[746]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1000wheel_joint_calc_jacobian,fqv[229],fqv[739],fqv[747]);
	local[0]= fqv[748];
	local[1]= fqv[684];
	local[2]= fqv[748];
	local[3]= fqv[685];
	local[4]= loadglobal(fqv[28]);
	local[5]= fqv[656];
	local[6]= fqv[749];
	local[7]= fqv[688];
	local[8]= NIL;
	local[9]= fqv[689];
	local[10]= NIL;
	local[11]= fqv[439];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[690];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[68])(ctx,13,local+2,&ftab[68],fqv[691]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1002omniwheel_joint_init,fqv[36],fqv[748],fqv[750]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1009omniwheel_joint_joint_angle,fqv[20],fqv[748],fqv[751]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1018omniwheel_joint_joint_dof,fqv[31],fqv[748],fqv[752]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1020omniwheel_joint_calc_angle_speed_gain,fqv[245],fqv[748],fqv[753]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1022omniwheel_joint_speed_to_angle,fqv[311],fqv[748],fqv[754]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1024omniwheel_joint_angle_to_speed,fqv[590],fqv[748],fqv[755]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1026omniwheel_joint_calc_jacobian,fqv[229],fqv[748],fqv[756]);
	local[0]= fqv[757];
	local[1]= fqv[684];
	local[2]= fqv[757];
	local[3]= fqv[685];
	local[4]= loadglobal(fqv[28]);
	local[5]= fqv[656];
	local[6]= fqv[758];
	local[7]= fqv[688];
	local[8]= NIL;
	local[9]= fqv[689];
	local[10]= NIL;
	local[11]= fqv[439];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[690];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[68])(ctx,13,local+2,&ftab[68],fqv[691]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1028sphere_joint_init,fqv[36],fqv[757],fqv[759]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1035sphere_joint_joint_angle,fqv[20],fqv[757],fqv[760]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1047sphere_joint_joint_angle_rpy,fqv[761],fqv[757],fqv[762]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1056sphere_joint_joint_dof,fqv[31],fqv[757],fqv[763]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1058sphere_joint_calc_angle_speed_gain,fqv[245],fqv[757],fqv[764]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1060sphere_joint_speed_to_angle,fqv[311],fqv[757],fqv[765]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1062sphere_joint_angle_to_speed,fqv[590],fqv[757],fqv[766]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1064sphere_joint_calc_jacobian,fqv[229],fqv[757],fqv[767]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1066sphere_joint_joint_euler_angle,fqv[768],fqv[757],fqv[769]);
	local[0]= fqv[601];
	local[1]= fqv[684];
	local[2]= fqv[601];
	local[3]= fqv[685];
	local[4]= loadglobal(fqv[28]);
	local[5]= fqv[656];
	local[6]= fqv[770];
	local[7]= fqv[688];
	local[8]= NIL;
	local[9]= fqv[689];
	local[10]= NIL;
	local[11]= fqv[439];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[690];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[68])(ctx,13,local+2,&ftab[68],fqv[691]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM11066dof_joint_init,fqv[36],fqv[601],fqv[771]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM11166dof_joint_joint_angle,fqv[20],fqv[601],fqv[772]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM11336dof_joint_joint_angle_rpy,fqv[761],fqv[601],fqv[773]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM11426dof_joint_joint_dof,fqv[31],fqv[601],fqv[774]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM11446dof_joint_calc_angle_speed_gain,fqv[245],fqv[601],fqv[775]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM11466dof_joint_speed_to_angle,fqv[311],fqv[601],fqv[776]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM11486dof_joint_angle_to_speed,fqv[590],fqv[601],fqv[777]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM11506dof_joint_calc_jacobian,fqv[229],fqv[601],fqv[778]);
	local[0]= fqv[213];
	local[1]= fqv[684];
	local[2]= fqv[213];
	local[3]= fqv[685];
	local[4]= loadglobal(fqv[779]);
	local[5]= fqv[656];
	local[6]= fqv[780];
	local[7]= fqv[688];
	local[8]= NIL;
	local[9]= fqv[689];
	local[10]= NIL;
	local[11]= fqv[439];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[690];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[68])(ctx,13,local+2,&ftab[68],fqv[691]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1152bodyset_link_init,fqv[36],fqv[213],fqv[781]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1159bodyset_link_worldcoords,fqv[122],fqv[213],fqv[782]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1167bodyset_link_analysis_level,fqv[149],fqv[213],fqv[783]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1173bodyset_link_weight,fqv[273],fqv[213],fqv[784]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1179bodyset_link_centroid,fqv[257],fqv[213],fqv[785]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1185bodyset_link_inertia_tensor,fqv[607],fqv[213],fqv[786]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1191bodyset_link_joint,fqv[198],fqv[213],fqv[787]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1194bodyset_link_add_joint,fqv[131],fqv[213],fqv[788]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1196bodyset_link_del_joint,fqv[644],fqv[213],fqv[789]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1198bodyset_link_parent_link,fqv[133],fqv[213],fqv[790]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1200bodyset_link_child_links,fqv[547],fqv[213],fqv[791]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1202bodyset_link_add_child_links,fqv[134],fqv[213],fqv[792]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1206bodyset_link_add_parent_link,fqv[132],fqv[213],fqv[793]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1208bodyset_link_del_child_link,fqv[646],fqv[213],fqv[794]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1210bodyset_link_del_parent_link,fqv[645],fqv[213],fqv[795]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1212bodyset_link_default_coords,fqv[796],fqv[213],fqv[797]);
	local[0]= fqv[376];
	local[1]= fqv[684];
	local[2]= fqv[376];
	local[3]= fqv[685];
	local[4]= loadglobal(fqv[121]);
	local[5]= fqv[656];
	local[6]= fqv[798];
	local[7]= fqv[688];
	local[8]= NIL;
	local[9]= fqv[689];
	local[10]= NIL;
	local[11]= fqv[439];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[690];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[68])(ctx,13,local+2,&ftab[68],fqv[691]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1218cascaded_link_init,fqv[36],fqv[376],fqv[799]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1222cascaded_link_init_ending,fqv[800],fqv[376],fqv[801]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1230cascaded_link_links,fqv[136],fqv[376],fqv[802]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1233cascaded_link_joint_list,fqv[657],fqv[376],fqv[803]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1236cascaded_link_link,fqv[576],fqv[376],fqv[804]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1239cascaded_link_joint,fqv[198],fqv[376],fqv[805]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1242cascaded_link_end_coords,fqv[627],fqv[376],fqv[806]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1245cascaded_link_bodies,fqv[127],fqv[376],fqv[807]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1248cascaded_link_faces,fqv[143],fqv[376],fqv[808]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1250cascaded_link_update_descendants,fqv[135],fqv[376],fqv[809]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1253cascaded_link_angle_vector,fqv[154],fqv[376],fqv[810]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1296cascaded_link_find_link_route,fqv[147],fqv[376],fqv[811]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1304cascaded_link_link_list,fqv[260],fqv[376],fqv[812]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1310cascaded_link_make_joint_min_max_table,fqv[813],fqv[376],fqv[814]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1328cascaded_link_make_min_max_table_using_collision_check,fqv[165],fqv[376],fqv[815]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1354cascaded_link_plot_joint_min_max_table_common,fqv[188],fqv[376],fqv[816]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1368cascaded_link_plot_joint_min_max_table,fqv[817],fqv[376],fqv[818]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1387cascaded_link_calc_target_axis_dimension,fqv[210],fqv[376],fqv[819]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1404cascaded_link_calc_union_link_list,fqv[197],fqv[376],fqv[820]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1410cascaded_link_calc_target_joint_dimension,fqv[211],fqv[376],fqv[821]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1412cascaded_link_calc_inverse_jacobian,fqv[360],fqv[376],fqv[822]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1432cascaded_link_calc_gradh_from_link_list,fqv[823],fqv[376],fqv[824]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1440cascaded_link_calc_jacobian_from_link_list,fqv[299],fqv[376],fqv[825]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1513cascaded_link_calc_joint_angle_speed,fqv[307],fqv[376],fqv[826]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1554cascaded_link_calc_joint_angle_speed_gain,fqv[308],fqv[376],fqv[827]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1563cascaded_link_collision_avoidance_links,fqv[828],fqv[376],fqv[829]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1569cascaded_link_collision_avoidance_link_pair_from_link_list,fqv[337],fqv[376],fqv[830]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1616cascaded_link_collision_avoidance_calc_distance,fqv[289],fqv[376],fqv[831]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1639cascaded_link_collision_avoidance_args,fqv[296],fqv[376],fqv[832]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1645cascaded_link_collision_avoidance,fqv[362],fqv[376],fqv[833]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1682cascaded_link_move_joints,fqv[377],fqv[376],fqv[834]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1709cascaded_link_find_joint_angle_limit_weight_old_from_union_link_list,fqv[315],fqv[376],fqv[835]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1712cascaded_link_reset_joint_angle_limit_weight_old,fqv[404],fqv[376],fqv[836]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1716cascaded_link_calc_weight_from_joint_limit,fqv[325],fqv[376],fqv[837]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1745cascaded_link_calc_inverse_kinematics_weight_from_link_list,fqv[354],fqv[376],fqv[838]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1779cascaded_link_calc_nspace_from_joint_limit,fqv[329],fqv[376],fqv[839]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1788cascaded_link_calc_inverse_kinematics_nspace_from_link_list,fqv[369],fqv[376],fqv[840]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1825cascaded_link_move_joints_avoidance,fqv[433],fqv[376],fqv[841]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1899cascaded_link_inverse_kinematics_args,fqv[463],fqv[376],fqv[842]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1909cascaded_link_draw_collision_debug_view,fqv[436],fqv[376],fqv[843]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM1940cascaded_link_inverse_kinematics_loop,fqv[466],fqv[376],fqv[844]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM2094cascaded_link_inverse_kinematics,fqv[528],fqv[376],fqv[845]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM2269cascaded_link_ik_convergence_check,fqv[414],fqv[376],fqv[846]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM2283cascaded_link_calc_vel_from_pos,fqv[415],fqv[376],fqv[847]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM2293cascaded_link_calc_vel_from_rot,fqv[416],fqv[376],fqv[848]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM2303cascaded_link_collision_check_pairs,fqv[551],fqv[376],fqv[849]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM2314cascaded_link_self_collision_check,fqv[476],fqv[376],fqv[850]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM2332cascaded_link_calc_grasp_matrix,fqv[851],fqv[376],fqv[852]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM2347cascaded_link_inverse_kinematics_for_closed_loop_forward_kinematics,fqv[853],fqv[376],fqv[854]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM2360cascaded_link_calc_jacobian_for_interlocking_joints,fqv[855],fqv[376],fqv[856]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM2365cascaded_link_calc_vel_for_interlocking_joints,fqv[857],fqv[376],fqv[858]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM2369cascaded_link_set_midpoint_for_interlocking_joints,fqv[859],fqv[376],fqv[860]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM2373cascaded_link_interlocking_joint_pairs,fqv[560],fqv[376],fqv[861]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtmodelM2375cascaded_link_check_interlocking_joint_angle_validity,fqv[862],fqv[376],fqv[863]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[864],module,irtmodelF734all_child_links,fqv[865]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[866],module,irtmodelF735calc_dif_with_axis,fqv[867]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[868],module,irtmodelF736calc_target_joint_dimension,fqv[869]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[870],module,irtmodelF737calc_joint_angle_min_max_for_limit_calculation,fqv[871]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[872],module,irtmodelF738joint_angle_limit_weight,fqv[873]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[874],module,irtmodelF739joint_angle_limit_nspace,fqv[875]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[876],module,irtmodelF740calc_jacobian_from_link_list_including_robot_and_obj_virtual_joint,fqv[877]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[878],module,irtmodelF741append_obj_virtual_joint,fqv[879]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[880],module,irtmodelF742append_multiple_obj_virtual_joint,fqv[881]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[882],module,irtmodelF2577,fqv[883]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[884],module,irtmodelF2584,fqv[885]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[886],module,irtmodelF2587,fqv[887]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[888],module,irtmodelF2590,fqv[889]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[890],module,irtmodelF2594,fqv[891]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[675],module,irtmodelF743eusmodel_validity_check_one,fqv[892]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[893],module,irtmodelF744eusmodel_validity_check,fqv[894]);
	local[0]= fqv[895];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtmodelIF2631;
	local[0]= fqv[896];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[679],w);
	goto irtmodelIF2632;
irtmodelIF2631:
	local[0]= fqv[897];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtmodelIF2632:
	local[0]= fqv[898];
	local[1]= fqv[899];
	ctx->vsp=local+2;
	w=(*ftab[69])(ctx,2,local+0,&ftab[69],fqv[900]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<70; i++) ftab[i]=fcallx;
}
