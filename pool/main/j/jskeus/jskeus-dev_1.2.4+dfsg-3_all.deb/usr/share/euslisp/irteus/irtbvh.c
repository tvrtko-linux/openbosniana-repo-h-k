/* ./irtbvh.c :  entry=irtbvh */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "irtbvh.h"
#pragma init (register_irtbvh)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___irtbvh();
extern pointer build_quote_vector();
static int register_irtbvh()
  { add_module_initializer("___irtbvh", ___irtbvh);}

static pointer irtbvhF4469parse_bvh_sexp();
static pointer irtbvhF4470read_bvh();
static pointer irtbvhF4471make_bvh_robot_model();
static pointer irtbvhF4472bvh2eus();
static pointer irtbvhF4473load_mcd();
static pointer irtbvhF4474rikiya_bvh2eus();
static pointer irtbvhF4475cmu_bvh2eus();
static pointer irtbvhF4476tum_bvh2eus();
static pointer irtbvhF4477rikiya_file();
static pointer irtbvhF4478tum_kitchen_file();
static pointer irtbvhF4479cmu_mocap_file();

/*:init*/
static pointer irtbvhM4480bvh_link_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=8) maerror();
	local[0]= makeint((eusinteger_t)30L);
	local[1]= NIL;
	argv[0]->c.obj.iv[29] = argv[3];
	argv[0]->c.obj.iv[30] = argv[4];
	argv[0]->c.obj.iv[31] = argv[5];
	local[2]= local[0];
	local[3]= local[0];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[0])(ctx,3,local+2,&ftab[0],fqv[0]); /*make-cube*/
	local[2]= w;
	local[3]= makeflt(9.9999999999999977795540e-02);
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	local[4]= makeflt(5.0000000000000000000000e-01);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	local[5]= makeflt(5.0000000000000000000000e-01);
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	local[6]= fqv[1];
	local[7]= makeflt(5.9999999999999964472863e-01);
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[0])(ctx,5,local+3,&ftab[0],fqv[0]); /*make-cube*/
	local[3]= w;
	local[4]= makeflt(5.0000000000000000000000e-01);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	local[5]= makeflt(5.9999999999999964472863e-01);
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[1])(ctx,2,local+4,&ftab[1],fqv[2]); /*make-cylinder*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,3,local+2); /*list*/
	local[1] = w;
	local[2]= NIL;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
irtbvhWHL4482:
	if (local[3]==NIL) goto irtbvhWHX4483;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= fqv[3];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	goto irtbvhWHL4482;
irtbvhWHX4483:
	local[4]= NIL;
irtbvhBLK4484:
	w = NIL;
	local[2]= NIL;
	local[3]= argv[7];
irtbvhWHL4485:
	if (local[3]==NIL) goto irtbvhWHX4486;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(*ftab[2])(ctx,1,local+4,&ftab[2],fqv[4]); /*normalize-vector*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)VMINUS(ctx,1,local+4); /*v-*/
	local[4]= w;
	local[5]= local[0];
	local[6]= makeflt(3.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)VNORM(ctx,1,local+6); /*norm*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[1])(ctx,2,local+5,&ftab[1],fqv[2]); /*make-cylinder*/
	local[5]= w;
	local[6]= local[4];
	local[7]= fqv[5];
	ctx->vsp=local+8;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+6); /*v**/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[2])(ctx,1,local+6,&ftab[2],fqv[4]); /*normalize-vector*/
	local[6]= w;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)VNORM(ctx,1,local+9); /*norm*/
	local[9]= w;
	local[10]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+11;
	w=(*ftab[3])(ctx,2,local+9,&ftab[3],fqv[6]); /*eps=*/
	if (w==NIL) goto irtbvhIF4488;
	local[6] = fqv[7];
	local[9]= local[6];
	goto irtbvhIF4489;
irtbvhIF4488:
	local[9]= NIL;
irtbvhIF4489:
	ctx->vsp=local+9;
	w=(*ftab[4])(ctx,0,local+9,&ftab[4],fqv[8]); /*make-coords*/
	local[9]= w;
	local[10]= fqv[9];
	local[11]= local[4];
	local[12]= fqv[10];
	ctx->vsp=local+13;
	w=(pointer)VINNERPRODUCT(ctx,2,local+11); /*v.*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[5])(ctx,1,local+11,&ftab[5],fqv[11]); /*acos*/
	local[11]= w;
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,4,local+9); /*send*/
	local[9]= w;
	local[10]= fqv[12];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[7] = w;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)12L);
irtbvhWHL4490:
	local[11]= local[9];
	w = local[10];
	if ((eusinteger_t)local[11] >= (eusinteger_t)w) goto irtbvhWHX4491;
	local[11]= local[7];
	local[12]= local[0];
	local[13]= makeint((eusinteger_t)3L);
	ctx->vsp=local+14;
	w=(pointer)QUOTIENT(ctx,2,local+12); /*/*/
	local[12]= w;
	local[13]= makeflt(-6.2831853071795862319959e+00);
	local[14]= local[9];
	local[15]= makeflt(1.2000000000000000000000e+01);
	ctx->vsp=local+16;
	w=(pointer)QUOTIENT(ctx,2,local+14); /*/*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)TIMES(ctx,2,local+13); /***/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SIN(ctx,1,local+13); /*sin*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)TIMES(ctx,2,local+12); /***/
	local[12]= w;
	local[13]= local[0];
	local[14]= makeint((eusinteger_t)3L);
	ctx->vsp=local+15;
	w=(pointer)QUOTIENT(ctx,2,local+13); /*/*/
	local[13]= w;
	local[14]= makeflt(-6.2831853071795862319959e+00);
	local[15]= local[9];
	local[16]= makeflt(1.2000000000000000000000e+01);
	ctx->vsp=local+17;
	w=(pointer)QUOTIENT(ctx,2,local+15); /*/*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)TIMES(ctx,2,local+14); /***/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)COS(ctx,1,local+14); /*cos*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)TIMES(ctx,2,local+13); /***/
	local[13]= w;
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(pointer)MKFLTVEC(ctx,3,local+12); /*float-vector*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)TRANSFORM(ctx,2,local+11); /*transform*/
	local[11]= w;
	w = local[8];
	ctx->vsp=local+12;
	local[8] = cons(ctx,local[11],w);
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[9] = w;
	goto irtbvhWHL4490;
irtbvhWHX4491:
	local[11]= NIL;
irtbvhBLK4492:
	w = NIL;
	local[9]= local[8];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(*ftab[6])(ctx,2,local+9,&ftab[6],fqv[13]); /*make-prism*/
	local[5] = w;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= fqv[3];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= local[1];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)NCONC(ctx,2,local+9); /*nconc*/
	local[1] = w;
	w = local[1];
	goto irtbvhWHL4485;
irtbvhWHX4486:
	local[4]= NIL;
irtbvhBLK4487:
	w = NIL;
	local[2]= argv[0];
	local[3]= *(ovafptr(argv[1],fqv[14]));
	local[4]= fqv[15];
	ctx->vsp=local+5;
	w=(*ftab[7])(ctx,0,local+5,&ftab[7],fqv[16]); /*make-cascoords*/
	local[5]= w;
	local[6]= fqv[17];
	local[7]= local[1];
	local[8]= fqv[18];
	local[9]= argv[2];
	ctx->vsp=local+10;
	w=(pointer)SENDMESSAGE(ctx,8,local+2); /*send-message*/
	local[2]= argv[0]->c.obj.iv[29];
	local[3]= local[2];
	w = fqv[19];
	if (memq(local[3],w)==NIL) goto irtbvhIF4493;
	local[3]= argv[0];
	local[4]= fqv[17];
	local[5]= fqv[20];
	local[6]= fqv[21];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	goto irtbvhIF4494;
irtbvhIF4493:
	local[3]= local[2];
	w = fqv[22];
	if (memq(local[3],w)==NIL) goto irtbvhIF4495;
	local[3]= argv[0];
	local[4]= fqv[17];
	local[5]= fqv[20];
	local[6]= fqv[23];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	goto irtbvhIF4496;
irtbvhIF4495:
	if (T==NIL) goto irtbvhIF4497;
	local[3]= argv[0];
	local[4]= fqv[17];
	local[5]= fqv[20];
	local[6]= fqv[24];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	goto irtbvhIF4498;
irtbvhIF4497:
	local[3]= NIL;
irtbvhIF4498:
irtbvhIF4496:
irtbvhIF4494:
	w = local[3];
	local[2]= argv[0];
	local[3]= fqv[25];
	if (argv[6]==NIL) goto irtbvhIF4499;
	local[4]= argv[6];
	local[5]= fqv[26];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[30];
	ctx->vsp=local+6;
	w=(pointer)VPLUS(ctx,2,local+4); /*v+*/
	local[4]= w;
	goto irtbvhIF4500;
irtbvhIF4499:
	local[4]= argv[0]->c.obj.iv[30];
irtbvhIF4500:
	local[5]= fqv[27];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	if (argv[6]==NIL) goto irtbvhIF4501;
	local[2]= argv[6];
	local[3]= fqv[3];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto irtbvhIF4502;
irtbvhIF4501:
	local[2]= NIL;
irtbvhIF4502:
	local[2]= argv[0];
	local[3]= fqv[28];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	w = argv[0];
	local[0]= w;
irtbvhBLK4481:
	ctx->vsp=local; return(local[0]);}

/*:type*/
static pointer irtbvhM4503bvh_link_type(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[29];
	local[0]= w;
irtbvhBLK4504:
	ctx->vsp=local; return(local[0]);}

/*:offset*/
static pointer irtbvhM4505bvh_link_offset(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[30];
	local[0]= w;
irtbvhBLK4506:
	ctx->vsp=local; return(local[0]);}

/*:channels*/
static pointer irtbvhM4507bvh_link_channels(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[31];
	local[0]= w;
irtbvhBLK4508:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtbvhM4509bvh_sphere_joint_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4511:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[29], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtbvhKEY4512;
	local[3]= fqv[30];
	local[4]= fqv[31];
	local[5]= fqv[32];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,3,local+3); /*list*/
	local[1] = w;
irtbvhKEY4512:
	if (n & (1<<1)) goto irtbvhKEY4513;
	local[3]= makeint((eusinteger_t)3L);
	ctx->vsp=local+4;
	w=(*ftab[8])(ctx,1,local+3,&ftab[8],fqv[33]); /*unit-matrix*/
	local[2] = w;
irtbvhKEY4513:
	argv[0]->c.obj.iv[15] = local[1];
	argv[0]->c.obj.iv[16] = local[2];
	local[3]= (pointer)get_sym_func(fqv[34]);
	local[4]= argv[0];
	local[5]= *(ovafptr(argv[1],fqv[14]));
	local[6]= fqv[15];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,5,local+3); /*apply*/
	local[0]= w;
irtbvhBLK4510:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle-bvh*/
static pointer irtbvhM4514bvh_sphere_joint_joint_angle_bvh(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtbvhENT4517;}
	local[0]= NIL;
irtbvhENT4517:
irtbvhENT4516:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[35];
	local[3]= local[0];
	local[4]= makeint((eusinteger_t)3L);
	ctx->vsp=local+5;
	w=(*ftab[8])(ctx,1,local+4,&ftab[8],fqv[33]); /*unit-matrix*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
irtbvhBLK4515:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle-bvh-offset*/
static pointer irtbvhM4518bvh_sphere_joint_joint_angle_bvh_offset(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtbvhENT4521;}
	local[0]= NIL;
irtbvhENT4521:
irtbvhENT4520:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[35];
	local[3]= local[0];
	local[4]= argv[0]->c.obj.iv[16];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
irtbvhBLK4519:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle-bvh-impl*/
static pointer irtbvhM4522bvh_sphere_joint_joint_angle_bvh_impl(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= NIL;
	local[1]= NIL;
	if (argv[2]==NIL) goto irtbvhIF4524;
	local[2]= loadglobal(fqv[36]);
	local[3]= (pointer)get_sym_func(fqv[37]);
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)MAP(ctx,3,local+2); /*map*/
	local[0] = w;
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[15];
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)ROTATION_MATRIX(ctx,2,local+2); /*rotation-matrix*/
	local[1] = w;
	local[2]= local[1];
	local[3]= local[0];
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[15];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= T;
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)ROTMAT(ctx,5,local+2); /*rotate-matrix*/
	local[2]= local[1];
	local[3]= local[0];
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[15];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= T;
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)ROTMAT(ctx,5,local+2); /*rotate-matrix*/
	local[2]= argv[0];
	local[3]= fqv[38];
	local[4]= loadglobal(fqv[36]);
	local[5]= (pointer)get_sym_func(fqv[39]);
	local[6]= argv[3];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)MATTIMES(ctx,2,local+6); /*m**/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[9])(ctx,1,local+6,&ftab[9],fqv[40]); /*matrix-log*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MAP(ctx,3,local+4); /*map*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto irtbvhIF4525;
irtbvhIF4524:
	local[2]= NIL;
irtbvhIF4525:
	local[2]= loadglobal(fqv[41]);
	local[3]= (pointer)get_sym_func(fqv[39]);
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)TRANSPOSE(ctx,1,local+4); /*transpose*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[2];
	local[6]= fqv[12];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MATTIMES(ctx,2,local+4); /*m**/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[15];
	ctx->vsp=local+6;
	w=(*ftab[10])(ctx,2,local+4,&ftab[10],fqv[42]); /*matrix-to-euler-angle*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MAP(ctx,3,local+2); /*map*/
	local[0]= w;
irtbvhBLK4523:
	ctx->vsp=local; return(local[0]);}

/*:axis-order*/
static pointer irtbvhM4526bvh_sphere_joint_axis_order(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[15];
	local[0]= w;
irtbvhBLK4527:
	ctx->vsp=local; return(local[0]);}

/*:bvh-offset-rotation*/
static pointer irtbvhM4528bvh_sphere_joint_bvh_offset_rotation(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[16];
	local[0]= w;
irtbvhBLK4529:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtbvhM4530bvh_6dof_joint_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4532:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[43], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtbvhKEY4533;
	local[4]= fqv[31];
	local[5]= fqv[32];
	local[6]= fqv[30];
	local[7]= fqv[30];
	local[8]= fqv[31];
	local[9]= fqv[32];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,6,local+4); /*list*/
	local[1] = w;
irtbvhKEY4533:
	if (n & (1<<1)) goto irtbvhKEY4534;
	local[2] = NIL;
irtbvhKEY4534:
	if (n & (1<<2)) goto irtbvhKEY4535;
	local[4]= makeint((eusinteger_t)3L);
	ctx->vsp=local+5;
	w=(*ftab[8])(ctx,1,local+4,&ftab[8],fqv[33]); /*unit-matrix*/
	local[3] = w;
irtbvhKEY4535:
	argv[0]->c.obj.iv[16] = local[1];
	if (local[2]==NIL) goto irtbvhIF4536;
	local[4]= local[2];
	goto irtbvhIF4537;
irtbvhIF4536:
	local[4]= makeflt(1.0000000000000000000000e+00);
irtbvhIF4537:
	argv[0]->c.obj.iv[15] = local[4];
	argv[0]->c.obj.iv[17] = local[3];
	local[4]= (pointer)get_sym_func(fqv[34]);
	local[5]= argv[0];
	local[6]= *(ovafptr(argv[1],fqv[14]));
	local[7]= fqv[15];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)APPLY(ctx,5,local+4); /*apply*/
	local[0]= w;
irtbvhBLK4531:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle-bvh*/
static pointer irtbvhM4538bvh_6dof_joint_joint_angle_bvh(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtbvhENT4541;}
	local[0]= NIL;
irtbvhENT4541:
irtbvhENT4540:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[35];
	local[3]= local[0];
	local[4]= makeint((eusinteger_t)3L);
	ctx->vsp=local+5;
	w=(*ftab[8])(ctx,1,local+4,&ftab[8],fqv[33]); /*unit-matrix*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
irtbvhBLK4539:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle-bvh-offset*/
static pointer irtbvhM4542bvh_6dof_joint_joint_angle_bvh_offset(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtbvhENT4545;}
	local[0]= NIL;
irtbvhENT4545:
irtbvhENT4544:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[35];
	local[3]= local[0];
	local[4]= argv[0]->c.obj.iv[17];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
irtbvhBLK4543:
	ctx->vsp=local; return(local[0]);}

/*:joint-angle-bvh-impl*/
static pointer irtbvhM4546bvh_6dof_joint_joint_angle_bvh_impl(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	if (argv[2]==NIL) goto irtbvhIF4548;
	local[3]= loadglobal(fqv[36]);
	local[4]= (pointer)get_sym_func(fqv[37]);
	local[5]= argv[2];
	local[6]= makeint((eusinteger_t)3L);
	local[7]= makeint((eusinteger_t)6L);
	ctx->vsp=local+8;
	w=(pointer)SUBSEQ(ctx,3,local+5); /*subseq*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MAP(ctx,3,local+3); /*map*/
	local[1] = w;
	local[3]= argv[0]->c.obj.iv[15];
	local[4]= argv[2];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)3L);
	ctx->vsp=local+7;
	w=(pointer)SUBSEQ(ctx,3,local+4); /*subseq*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SCALEVEC(ctx,2,local+3); /*scale*/
	local[2] = w;
	local[3]= local[1];
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[16];
	local[5]= makeint((eusinteger_t)5L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ROTATION_MATRIX(ctx,2,local+3); /*rotation-matrix*/
	local[0] = w;
	local[3]= local[0];
	local[4]= local[1];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[16];
	local[6]= makeint((eusinteger_t)4L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= T;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)ROTMAT(ctx,5,local+3); /*rotate-matrix*/
	local[3]= local[0];
	local[4]= local[1];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[16];
	local[6]= makeint((eusinteger_t)3L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= T;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)ROTMAT(ctx,5,local+3); /*rotate-matrix*/
	local[3]= argv[0];
	local[4]= fqv[38];
	local[5]= loadglobal(fqv[36]);
	local[6]= argv[3];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)TRANSFORM(ctx,2,local+6); /*transform*/
	local[6]= w;
	local[7]= loadglobal(fqv[41]);
	local[8]= (pointer)get_sym_func(fqv[39]);
	local[9]= argv[0]->c.obj.iv[17];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)MATTIMES(ctx,2,local+9); /*m**/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[9])(ctx,1,local+9,&ftab[9],fqv[40]); /*matrix-log*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MAP(ctx,3,local+7); /*map*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)CONCATENATE(ctx,3,local+5); /*concatenate*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto irtbvhIF4549;
irtbvhIF4548:
	local[3]= NIL;
irtbvhIF4549:
	local[3]= loadglobal(fqv[41]);
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)TRANSPOSE(ctx,1,local+4); /*transpose*/
	local[4]= w;
	local[5]= makeflt(1.0000000000000000208167e-03);
	local[6]= argv[0]->c.obj.iv[2];
	local[7]= fqv[1];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SCALEVEC(ctx,2,local+5); /*scale*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)TRANSFORM(ctx,2,local+4); /*transform*/
	local[4]= w;
	local[5]= loadglobal(fqv[41]);
	local[6]= (pointer)get_sym_func(fqv[39]);
	local[7]= argv[3];
	ctx->vsp=local+8;
	w=(pointer)TRANSPOSE(ctx,1,local+7); /*transpose*/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= fqv[12];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MATTIMES(ctx,2,local+7); /*m**/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[16];
	local[9]= makeint((eusinteger_t)3L);
	local[10]= makeint((eusinteger_t)6L);
	ctx->vsp=local+11;
	w=(pointer)SUBSEQ(ctx,3,local+8); /*subseq*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[10])(ctx,2,local+7,&ftab[10],fqv[42]); /*matrix-to-euler-angle*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MAP(ctx,3,local+5); /*map*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)CONCATENATE(ctx,3,local+3); /*concatenate*/
	local[0]= w;
irtbvhBLK4547:
	ctx->vsp=local; return(local[0]);}

/*:axis-order*/
static pointer irtbvhM4550bvh_6dof_joint_axis_order(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[16];
	local[0]= w;
irtbvhBLK4551:
	ctx->vsp=local; return(local[0]);}

/*:bvh-offset-rotation*/
static pointer irtbvhM4552bvh_6dof_joint_bvh_offset_rotation(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[17];
	local[0]= w;
irtbvhBLK4553:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtbvhM4554bvh_robot_model_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4556:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[44], &argv[2], n-2, local+1, 0);
	if (n & (1<<0)) goto irtbvhKEY4557;
	local[1] = NIL;
irtbvhKEY4557:
	if (n & (1<<1)) goto irtbvhKEY4558;
	local[2] = NIL;
irtbvhKEY4558:
	if (n & (1<<2)) goto irtbvhKEY4559;
	local[3] = NIL;
irtbvhKEY4559:
	local[4]= (pointer)get_sym_func(fqv[34]);
	local[5]= argv[0];
	local[6]= *(ovafptr(argv[1],fqv[14]));
	local[7]= fqv[15];
	local[8]= fqv[45];
	ctx->vsp=local+9;
	w=(*ftab[7])(ctx,0,local+9,&ftab[7],fqv[16]); /*make-cascoords*/
	local[9]= w;
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)APPLY(ctx,7,local+4); /*apply*/
	local[4]= argv[0];
	local[5]= fqv[46];
	local[6]= local[1];
	local[7]= fqv[47];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	if (local[2]==NIL) goto irtbvhIF4560;
	local[4]= argv[0];
	local[5]= fqv[48];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto irtbvhIF4561;
irtbvhIF4560:
	local[4]= NIL;
irtbvhIF4561:
	local[4]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+5;
	w=(pointer)REVERSE(ctx,1,local+4); /*reverse*/
	argv[0]->c.obj.iv[8] = w;
	local[4]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+5;
	w=(pointer)REVERSE(ctx,1,local+4); /*reverse*/
	argv[0]->c.obj.iv[9] = w;
	local[4]= argv[0];
	local[5]= fqv[49];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	w = argv[0];
	local[0]= w;
irtbvhBLK4555:
	ctx->vsp=local; return(local[0]);}

/*:make-bvh-link*/
static pointer irtbvhM4562bvh_robot_model_make_bvh_link(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[50], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtbvhKEY4564;
	local[0] = NIL;
irtbvhKEY4564:
	if (n & (1<<1)) goto irtbvhKEY4565;
	local[1] = NIL;
irtbvhKEY4565:
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	if (local[1]!=NIL) goto irtbvhIF4566;
	local[1] = makeflt(1.0000000000000000000000e+00);
	local[8]= local[1];
	goto irtbvhIF4567;
irtbvhIF4566:
	local[8]= NIL;
irtbvhIF4567:
	local[8]= loadglobal(fqv[51]);
	ctx->vsp=local+9;
	w=(pointer)INSTANTIATE(ctx,1,local+8); /*instantiate*/
	local[8]= w;
	local[9]= local[8];
	local[10]= fqv[15];
	local[11]= local[3];
	local[12]= local[2];
	local[13]= local[4];
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	local[15]= local[0];
	ctx->vsp=local+16;
	local[16]= makeclosure(codevec,quotevec,irtbvhCLO4568,env,argv,local);
	local[17]= argv[2];
	ctx->vsp=local+18;
	w=(pointer)MAPCAR(ctx,2,local+16); /*mapcar*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,8,local+9); /*send*/
	w = local[8];
	local[6] = w;
	local[8]= local[6];
	w = argv[0]->c.obj.iv[8];
	ctx->vsp=local+9;
	argv[0]->c.obj.iv[8] = cons(ctx,local[8],w);
	local[8]= local[2];
	local[9]= fqv[52];
	ctx->vsp=local+10;
	w=(pointer)EQ(ctx,2,local+8); /*eql*/
	if (w!=NIL) goto irtbvhIF4569;
	local[8]= NIL;
	local[9]= local[2];
	local[10]= fqv[53];
	ctx->vsp=local+11;
	w=(pointer)EQ(ctx,2,local+9); /*eql*/
	if (w==NIL) goto irtbvhIF4571;
	local[9]= loadglobal(fqv[54]);
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,1,local+9); /*instantiate*/
	local[9]= w;
	local[10]= local[9];
	local[11]= fqv[15];
	ctx->vsp=local+12;
	w=(*ftab[7])(ctx,0,local+12,&ftab[7],fqv[16]); /*make-cascoords*/
	local[12]= w;
	local[13]= fqv[18];
	local[14]= fqv[55];
	local[15]= fqv[17];
	local[16]= makeint((eusinteger_t)10L);
	local[17]= makeint((eusinteger_t)10L);
	local[18]= makeint((eusinteger_t)10L);
	ctx->vsp=local+19;
	w=(*ftab[0])(ctx,3,local+16,&ftab[0],fqv[0]); /*make-cube*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,1,local+16); /*list*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,7,local+10); /*send*/
	w = local[9];
	local[0] = w;
	local[9]= local[0];
	local[10]= fqv[3];
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= argv[0];
	local[10]= fqv[3];
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	goto irtbvhIF4572;
irtbvhIF4571:
	local[9]= NIL;
irtbvhIF4572:
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= local[9];
	if (fqv[56]!=local[10]) goto irtbvhIF4573;
	local[8] = loadglobal(fqv[57]);
	local[10]= local[8];
	goto irtbvhIF4574;
irtbvhIF4573:
	local[10]= local[9];
	if (fqv[58]!=local[10]) goto irtbvhIF4575;
	local[8] = loadglobal(fqv[59]);
	local[10]= local[8];
	goto irtbvhIF4576;
irtbvhIF4575:
	if (T==NIL) goto irtbvhIF4577;
	local[10]= makeint((eusinteger_t)1L);
	local[11]= fqv[60];
	local[12]= local[5];
	ctx->vsp=local+13;
	w=(*ftab[11])(ctx,3,local+10,&ftab[11],fqv[61]); /*warning-message*/
	local[10]= w;
	goto irtbvhIF4578;
irtbvhIF4577:
	local[10]= NIL;
irtbvhIF4578:
irtbvhIF4576:
irtbvhIF4574:
	w = local[10];
	local[9]= local[8];
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,1,local+9); /*instantiate*/
	local[9]= w;
	local[10]= local[9];
	local[11]= fqv[15];
	local[12]= fqv[18];
	local[13]= local[3];
	local[14]= fqv[62];
	local[15]= local[6];
	local[16]= fqv[63];
	local[17]= local[0];
	local[18]= fqv[64];
	local[19]= argv[0];
	local[20]= fqv[65];
	local[21]= local[3];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,3,local+19); /*send*/
	local[19]= w;
	local[20]= fqv[66];
	ctx->vsp=local+21;
	local[21]= makeclosure(codevec,quotevec,irtbvhCLO4579,env,argv,local);
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22]= (w)->c.cons.cdr;
	local[23]= fqv[31];
	w = fqv[67];
	ctx->vsp=local+24;
	local[23]= cons(ctx,local[23],w);
	local[24]= fqv[32];
	w = fqv[68];
	ctx->vsp=local+25;
	local[24]= cons(ctx,local[24],w);
	local[25]= fqv[30];
	w = fqv[69];
	ctx->vsp=local+26;
	local[25]= cons(ctx,local[25],w);
	ctx->vsp=local+26;
	w=(pointer)LIST(ctx,4,local+22); /*list*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(*ftab[12])(ctx,2,local+21,&ftab[12],fqv[70]); /*reduce*/
	local[21]= w;
	local[22]= fqv[47];
	local[23]= local[1];
	ctx->vsp=local+24;
	w=(pointer)SEND(ctx,14,local+10); /*send*/
	w = local[9];
	local[7] = w;
	local[9]= local[7];
	w = argv[0]->c.obj.iv[9];
	ctx->vsp=local+10;
	argv[0]->c.obj.iv[9] = cons(ctx,local[9],w);
	w = argv[0]->c.obj.iv[9];
	local[8]= w;
	goto irtbvhIF4570;
irtbvhIF4569:
	local[8]= NIL;
irtbvhIF4570:
	local[8]= NIL;
	local[9]= argv[2];
irtbvhWHL4580:
	if (local[9]==NIL) goto irtbvhWHX4581;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= argv[0];
	local[11]= fqv[46];
	local[12]= local[8];
	local[13]= fqv[71];
	local[14]= local[6];
	local[15]= fqv[47];
	local[16]= local[1];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,7,local+10); /*send*/
	goto irtbvhWHL4580;
irtbvhWHX4581:
	local[10]= NIL;
irtbvhBLK4582:
	w = NIL;
	w = local[0];
	local[0]= w;
irtbvhBLK4563:
	ctx->vsp=local; return(local[0]);}

/*:angle-vector*/
static pointer irtbvhM4583bvh_robot_model_angle_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtbvhENT4587;}
	local[0]= NIL;
irtbvhENT4587:
	if (n>=4) { local[1]=(argv[3]); goto irtbvhENT4586;}
	local[1]= loadglobal(fqv[36]);
	local[2]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+3;
	w=(*ftab[13])(ctx,1,local+2,&ftab[13],fqv[72]); /*calc-target-joint-dimension*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,2,local+1); /*instantiate*/
	local[1]= w;
irtbvhENT4586:
irtbvhENT4585:
	if (n>4) maerror();
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	local[4]= NIL;
	local[5]= argv[0]->c.obj.iv[9];
irtbvhWHL4588:
	if (local[5]==NIL) goto irtbvhWHX4589;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	if (local[0]==NIL) goto irtbvhIF4591;
	local[6]= local[4];
	local[7]= fqv[73];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= local[6];
	if (fqv[74]!=local[7]) goto irtbvhIF4593;
	local[7]= local[4];
	local[8]= fqv[38];
	local[9]= local[0];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	goto irtbvhIF4594;
irtbvhIF4593:
	local[7]= local[6];
	if (fqv[75]!=local[7]) goto irtbvhIF4595;
	local[7]= local[0];
	local[8]= local[2];
	local[9]= local[2];
	local[10]= local[4];
	local[11]= fqv[73];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SUBSEQ(ctx,3,local+7); /*subseq*/
	local[7]= w;
	local[8]= local[4];
	local[9]= fqv[76];
	local[10]= local[7];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[7]= w;
	goto irtbvhIF4596;
irtbvhIF4595:
	if (T==NIL) goto irtbvhIF4597;
	local[7]= local[4];
	local[8]= fqv[76];
	local[9]= local[0];
	local[10]= local[2];
	local[11]= local[2];
	local[12]= local[4];
	local[13]= fqv[73];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SUBSEQ(ctx,3,local+9); /*subseq*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	goto irtbvhIF4598;
irtbvhIF4597:
	local[7]= NIL;
irtbvhIF4598:
irtbvhIF4596:
irtbvhIF4594:
	w = local[7];
	local[6]= w;
	goto irtbvhIF4592;
irtbvhIF4591:
	local[6]= NIL;
irtbvhIF4592:
	local[6]= makeint((eusinteger_t)0L);
	local[7]= local[4];
	local[8]= fqv[73];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
irtbvhWHL4599:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto irtbvhWHX4600;
	local[8]= local[1];
	local[9]= local[2];
	local[10]= local[4];
	local[11]= fqv[76];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SETELT(ctx,3,local+8); /*setelt*/
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[2] = w;
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto irtbvhWHL4599;
irtbvhWHX4600:
	local[8]= NIL;
irtbvhBLK4601:
	w = NIL;
	goto irtbvhWHL4588;
irtbvhWHX4589:
	local[6]= NIL;
irtbvhBLK4590:
	w = NIL;
	w = local[1];
	local[0]= w;
irtbvhBLK4584:
	ctx->vsp=local; return(local[0]);}

/*:dump-joints*/
static pointer irtbvhM4602bvh_robot_model_dump_joints(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[77], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtbvhKEY4604;
	local[0] = makeint((eusinteger_t)0L);
irtbvhKEY4604:
	if (n & (1<<1)) goto irtbvhKEY4605;
	local[1] = loadglobal(fqv[78]);
irtbvhKEY4605:
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[14])(ctx,1,local+2,&ftab[14],fqv[79]); /*make-string*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)32L);
	ctx->vsp=local+4;
	w=(*ftab[15])(ctx,2,local+2,&ftab[15],fqv[80]); /*fill*/
	local[2]= w;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= argv[2];
irtbvhWHL4606:
	if (local[7]==NIL) goto irtbvhWHX4607;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= local[6];
	local[9]= fqv[81];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[3] = w;
	local[8]= local[6];
	local[9]= fqv[82];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[4] = w;
	local[8]= local[6];
	local[9]= fqv[83];
	local[10]= fqv[84];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[5] = w;
	local[8]= local[1];
	local[9]= fqv[85];
	local[10]= local[2];
	local[11]= local[6];
	local[12]= fqv[86];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[16])(ctx,1,local+11,&ftab[16],fqv[87]); /*string-upcase*/
	local[11]= w;
	local[12]= local[6];
	local[13]= fqv[83];
	local[14]= fqv[18];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,5,local+8); /*format*/
	local[8]= local[1];
	local[9]= fqv[88];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,3,local+8); /*format*/
	local[8]= local[1];
	local[9]= fqv[89];
	local[10]= local[2];
	local[11]= local[3];
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= local[3];
	local[13]= makeint((eusinteger_t)1L);
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= local[3];
	local[14]= makeint((eusinteger_t)2L);
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)XFORMAT(ctx,6,local+8); /*format*/
	local[8]= local[1];
	local[9]= fqv[90];
	local[10]= local[2];
	local[11]= local[4];
	ctx->vsp=local+12;
	w=(pointer)XFORMAT(ctx,4,local+8); /*format*/
	local[8]= NIL;
	local[9]= local[5];
irtbvhWHL4609:
	if (local[9]==NIL) goto irtbvhWHX4610;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= local[8];
	local[11]= local[10];
	if (fqv[31]!=local[11]) goto irtbvhIF4612;
	local[11]= local[1];
	local[12]= fqv[91];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,2,local+11); /*format*/
	local[11]= w;
	goto irtbvhIF4613;
irtbvhIF4612:
	local[11]= local[10];
	if (fqv[32]!=local[11]) goto irtbvhIF4614;
	local[11]= local[1];
	local[12]= fqv[92];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,2,local+11); /*format*/
	local[11]= w;
	goto irtbvhIF4615;
irtbvhIF4614:
	local[11]= local[10];
	if (fqv[30]!=local[11]) goto irtbvhIF4616;
	local[11]= local[1];
	local[12]= fqv[93];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,2,local+11); /*format*/
	local[11]= w;
	goto irtbvhIF4617;
irtbvhIF4616:
	if (T==NIL) goto irtbvhIF4618;
	local[11]= local[1];
	local[12]= fqv[94];
	local[13]= local[8];
	ctx->vsp=local+14;
	w=(pointer)XFORMAT(ctx,3,local+11); /*format*/
	local[11]= w;
	goto irtbvhIF4619;
irtbvhIF4618:
	local[11]= NIL;
irtbvhIF4619:
irtbvhIF4617:
irtbvhIF4615:
irtbvhIF4613:
	w = local[11];
	goto irtbvhWHL4609;
irtbvhWHX4610:
	local[10]= NIL;
irtbvhBLK4611:
	w = NIL;
	local[8]= local[1];
	local[9]= fqv[95];
	ctx->vsp=local+10;
	w=(pointer)XFORMAT(ctx,2,local+8); /*format*/
	local[8]= local[6];
	local[9]= fqv[96];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	if (w==NIL) goto irtbvhIF4620;
	local[8]= argv[0];
	local[9]= fqv[97];
	local[10]= local[6];
	local[11]= fqv[96];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)REVERSE(ctx,1,local+10); /*reverse*/
	local[10]= w;
	local[11]= fqv[98];
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)ADD1(ctx,1,local+12); /*1+*/
	local[12]= w;
	local[13]= fqv[99];
	local[14]= local[1];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,7,local+8); /*send*/
	local[8]= w;
	goto irtbvhIF4621;
irtbvhIF4620:
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtbvhCLO4622,env,argv,local);
	local[9]= local[6];
	local[10]= fqv[100];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[17])(ctx,2,local+8,&ftab[17],fqv[101]); /*find-if*/
	local[8]= w;
	local[9]= local[8];
	local[10]= fqv[81];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	local[10]= local[1];
	local[11]= fqv[102];
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,3,local+10); /*format*/
	local[10]= local[1];
	local[11]= fqv[103];
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,3,local+10); /*format*/
	local[10]= local[1];
	local[11]= fqv[104];
	local[12]= local[2];
	local[13]= local[9];
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	local[14]= local[9];
	local[15]= makeint((eusinteger_t)1L);
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[14]= w;
	local[15]= local[9];
	local[16]= makeint((eusinteger_t)2L);
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,6,local+10); /*format*/
	local[10]= local[1];
	local[11]= fqv[105];
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,3,local+10); /*format*/
	local[8]= w;
irtbvhIF4621:
	local[8]= local[1];
	local[9]= fqv[106];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,3,local+8); /*format*/
	goto irtbvhWHL4606;
irtbvhWHX4607:
	local[8]= NIL;
irtbvhBLK4608:
	w = NIL;
	local[0]= w;
irtbvhBLK4603:
	ctx->vsp=local; return(local[0]);}

/*:dump-hierarchy*/
static pointer irtbvhM4623bvh_robot_model_dump_hierarchy(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtbvhENT4626;}
	local[0]= loadglobal(fqv[78]);
irtbvhENT4626:
irtbvhENT4625:
	if (n>3) maerror();
	local[1]= local[0];
	local[2]= fqv[107];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,2,local+1); /*format*/
	local[1]= argv[0];
	local[2]= fqv[97];
	w=argv[0]->c.obj.iv[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	local[3]= w;
	local[4]= fqv[99];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[1]= local[0];
	local[2]= fqv[108];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,2,local+1); /*format*/
	local[1]= local[0];
	local[2]= fqv[109];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,2,local+1); /*format*/
	local[1]= local[0];
	local[2]= fqv[110];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,2,local+1); /*format*/
	local[0]= w;
irtbvhBLK4624:
	ctx->vsp=local; return(local[0]);}

/*:dump-motion*/
static pointer irtbvhM4627bvh_robot_model_dump_motion(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtbvhENT4630;}
	local[0]= loadglobal(fqv[78]);
irtbvhENT4630:
irtbvhENT4629:
	if (n>3) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[0]->c.obj.iv[8];
irtbvhWHL4631:
	if (local[3]==NIL) goto irtbvhWHX4632;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= local[2];
	local[5]= fqv[83];
	local[6]= fqv[111];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[1] = w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
irtbvhWHL4634:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto irtbvhWHX4635;
	local[6]= local[0];
	local[7]= fqv[112];
	local[8]= local[1];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto irtbvhWHL4634;
irtbvhWHX4635:
	local[6]= NIL;
irtbvhBLK4636:
	w = NIL;
	goto irtbvhWHL4631;
irtbvhWHX4632:
	local[4]= NIL;
irtbvhBLK4633:
	w = NIL;
	local[2]= local[0];
	local[3]= fqv[113];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,2,local+2); /*format*/
	local[0]= w;
irtbvhBLK4628:
	ctx->vsp=local; return(local[0]);}

/*:copy-state-to*/
static pointer irtbvhM4637bvh_robot_model_copy_state_to(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeint((eusinteger_t)1L);
	local[1]= fqv[114];
	ctx->vsp=local+2;
	w=(*ftab[11])(ctx,2,local+0,&ftab[11],fqv[61]); /*warning-message*/
	local[0]= w;
irtbvhBLK4638:
	ctx->vsp=local; return(local[0]);}

/*:fix-joint-angle*/
static pointer irtbvhM4639bvh_robot_model_fix_joint_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=7) maerror();
	w = argv[6];
	local[0]= w;
irtbvhBLK4640:
	ctx->vsp=local; return(local[0]);}

/*:fix-joint-order*/
static pointer irtbvhM4641bvh_robot_model_fix_joint_order(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	w = argv[2];
	local[0]= w;
irtbvhBLK4642:
	ctx->vsp=local; return(local[0]);}

/*:bvh-offset-rotate*/
static pointer irtbvhM4643bvh_robot_model_bvh_offset_rotate(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeint((eusinteger_t)3L);
	ctx->vsp=local+1;
	w=(*ftab[8])(ctx,1,local+0,&ftab[8],fqv[33]); /*unit-matrix*/
	local[0]= w;
irtbvhBLK4644:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4568(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[115];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	ctx->vsp=local+2;
	w=(*ftab[18])(ctx,2,local+0,&ftab[18],fqv[116]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4579(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[19])(ctx,3,local+0,&ftab[19],fqv[117]); /*substitute*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4622(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[51]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*parse-bvh-sexp*/
static pointer irtbvhF4469parse_bvh_sexp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[118], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto irtbvhKEY4646;
	local[0] = NIL;
irtbvhKEY4646:
	if (local[0]!=NIL) goto irtbvhIF4647;
	local[0] = makeflt(1.0000000000000000000000e+00);
	local[1]= local[0];
	goto irtbvhIF4648;
irtbvhIF4647:
	local[1]= NIL;
irtbvhIF4648:
	w = argv[0];
	if (!!iscons(w)) goto irtbvhIF4649;
	local[1]= argv[0];
	goto irtbvhIF4650;
irtbvhIF4649:
	local[1]= NIL;
	local[2]= NIL;
irtbvhWHL4651:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	if (local[1]==NIL) goto irtbvhWHX4652;
	local[3]= local[1];
	local[4]= local[3];
	w = fqv[119];
	if (memq(local[4],w)==NIL) goto irtbvhIF4654;
	local[4]= local[1];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[5];
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,2,local+4); /*list*/
	local[4]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[5];
	local[5]= w;
	local[6]= fqv[47];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)irtbvhF4469parse_bvh_sexp(ctx,3,local+5); /*parse-bvh-sexp*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	w = local[2];
	ctx->vsp=local+5;
	local[2] = cons(ctx,local[4],w);
	local[4]= local[2];
	goto irtbvhIF4655;
irtbvhIF4654:
	local[4]= local[3];
	if (fqv[115]!=local[4]) goto irtbvhIF4656;
	local[4]= local[1];
	local[5]= local[0];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[6];
	local[6]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[7];
	local[7]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[8];
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,3,local+6); /*float-vector*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SCALEVEC(ctx,2,local+5); /*scale*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,2,local+4); /*list*/
	local[4]= w;
	w = local[2];
	ctx->vsp=local+5;
	local[2] = cons(ctx,local[4],w);
	local[4]= local[2];
	goto irtbvhIF4657;
irtbvhIF4656:
	local[4]= local[3];
	if (fqv[120]!=local[4]) goto irtbvhIF4658;
	local[4]= local[1];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[5];
	local[5]= w;
	local[6]= local[5];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	local[6]= w;
irtbvhTAG4661:
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)SUB1(ctx,1,local+7); /*1-*/
	local[5] = w;
	local[7]= local[5];
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)LESSP(ctx,2,local+7); /*<*/
	if (w==NIL) goto irtbvhIF4662;
	local[7]= local[6];
	ctx->vsp=local+8;
	w=(pointer)REVERSE(ctx,1,local+7); /*reverse*/
	ctx->vsp=local+7;
	local[5]=w;
	goto irtbvhBLK4660;
	goto irtbvhIF4663;
irtbvhIF4662:
	local[7]= NIL;
irtbvhIF4663:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[7];
	local[7]= w;
	w = local[6];
	ctx->vsp=local+8;
	local[6] = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	goto irtbvhTAG4661;
	w = NIL;
	local[5]= w;
irtbvhBLK4660:
	w = local[5];
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	w = local[2];
	ctx->vsp=local+5;
	local[2] = cons(ctx,local[4],w);
	local[4]= local[2];
	goto irtbvhIF4659;
irtbvhIF4658:
	if (T==NIL) goto irtbvhIF4664;
	w = local[1];
	if (!issymbol(w)) goto irtbvhIF4666;
	local[4]= local[1];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[5];
	local[5]= w;
	local[6]= fqv[47];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)irtbvhF4469parse_bvh_sexp(ctx,3,local+5); /*parse-bvh-sexp*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	w = local[2];
	ctx->vsp=local+5;
	local[2] = cons(ctx,local[4],w);
	local[4]= local[2];
	goto irtbvhIF4667;
irtbvhIF4666:
	local[4]= local[1];
	w = local[2];
	ctx->vsp=local+5;
	local[2] = cons(ctx,local[4],w);
	local[4]= local[2];
irtbvhIF4667:
	goto irtbvhIF4665;
irtbvhIF4664:
	local[4]= NIL;
irtbvhIF4665:
irtbvhIF4659:
irtbvhIF4657:
irtbvhIF4655:
	w = local[4];
	goto irtbvhWHL4651;
irtbvhWHX4652:
	local[3]= NIL;
irtbvhBLK4653:
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)REVERSE(ctx,1,local+3); /*reverse*/
	local[1]= w;
irtbvhIF4650:
	w = local[1];
	local[0]= w;
irtbvhBLK4645:
	ctx->vsp=local; return(local[0]);}

/*read-bvh*/
static pointer irtbvhF4470read_bvh(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[121], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto irtbvhKEY4669;
	local[0] = NIL;
irtbvhKEY4669:
	ctx->vsp=local+1;
	w=(*ftab[20])(ctx,0,local+1,&ftab[20],fqv[122]); /*copy-readtable*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,0,local+2); /*gensym*/
	local[2]= w;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	w = local[1];
	ctx->vsp=local+7;
	bindspecial(ctx,fqv[123],w);
	local[10]= makeint((eusinteger_t)35L);
	local[11]= makeint((eusinteger_t)59L);
	ctx->vsp=local+12;
	w=(*ftab[21])(ctx,2,local+10,&ftab[21],fqv[124]); /*set-syntax-from-char*/
	local[10]= makeint((eusinteger_t)58L);
	local[11]= makeint((eusinteger_t)32L);
	ctx->vsp=local+12;
	w=(*ftab[21])(ctx,2,local+10,&ftab[21],fqv[124]); /*set-syntax-from-char*/
	local[10]= makeint((eusinteger_t)125L);
	local[11]= makeint((eusinteger_t)41L);
	ctx->vsp=local+12;
	w=(*ftab[21])(ctx,2,local+10,&ftab[21],fqv[124]); /*set-syntax-from-char*/
	local[10]= makeint((eusinteger_t)123L);
	ctx->vsp=local+11;
	local[11]= makeclosure(codevec,quotevec,irtbvhCLO4670,env,argv,local);
	ctx->vsp=local+12;
	w=(pointer)SETMACROCH(ctx,2,local+10); /*set-macro-character*/
	local[10]= argv[0];
	local[11]= fqv[125];
	local[12]= fqv[126];
	ctx->vsp=local+13;
	w=(*ftab[22])(ctx,3,local+10,&ftab[22],fqv[127]); /*open*/
	local[10]= w;
	ctx->vsp=local+11;
	w = makeclosure(codevec,quotevec,irtbvhUWP4671,env,argv,local);
	local[11]=(pointer)(ctx->protfp); local[12]=w;
	ctx->protfp=(struct protectframe *)(local+11);
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)READ(ctx,1,local+13); /*read*/
	local[13]= NIL;
irtbvhTAG4673:
	local[14]= local[13];
	local[15]= local[2];
	ctx->vsp=local+16;
	w=(pointer)EQ(ctx,2,local+14); /*eql*/
	if (w!=NIL) goto irtbvhOR4676;
	local[14]= local[13];
	local[15]= fqv[128];
	ctx->vsp=local+16;
	w=(pointer)EQ(ctx,2,local+14); /*eql*/
	if (w!=NIL) goto irtbvhOR4676;
	goto irtbvhIF4674;
irtbvhOR4676:
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)NREVERSE(ctx,1,local+14); /*nreverse*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[3];
	ctx->vsp=local+14;
	local[13]=w;
	goto irtbvhBLK4672;
	goto irtbvhIF4675;
irtbvhIF4674:
	local[14]= NIL;
irtbvhIF4675:
	local[14]= local[13];
	w = local[3];
	ctx->vsp=local+15;
	local[3] = cons(ctx,local[14],w);
	local[14]= local[10];
	local[15]= NIL;
	local[16]= local[2];
	ctx->vsp=local+17;
	w=(pointer)READ(ctx,3,local+14); /*read*/
	local[13] = w;
	ctx->vsp=local+14;
	goto irtbvhTAG4673;
	w = NIL;
	local[13]= w;
irtbvhBLK4672:
	local[13]= local[3];
	local[14]= fqv[47];
	local[15]= local[0];
	ctx->vsp=local+16;
	w=(pointer)irtbvhF4469parse_bvh_sexp(ctx,3,local+13); /*parse-bvh-sexp*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.car;
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)READ(ctx,1,local+13); /*read*/
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)READ(ctx,1,local+13); /*read*/
	local[5] = w;
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)READ(ctx,1,local+13); /*read*/
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)READ(ctx,1,local+13); /*read*/
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)READ(ctx,1,local+13); /*read*/
	local[6] = w;
	local[13]= fqv[129];
	w = local[13];
	ctx->vsp=local+13;
	bindspecial(ctx,fqv[130],w);
irtbvhTAG4678:
	if (loadglobal(fqv[130])!=NIL) goto irtbvhIF4679;
	w = NIL;
	ctx->vsp=local+16;
	unwind(ctx,local+13);
	local[13]=w;
	goto irtbvhBLK4677;
	goto irtbvhIF4680;
irtbvhIF4679:
	local[16]= NIL;
irtbvhIF4680:
	local[16]= NIL;
	local[17]= fqv[131];
	local[18]= loadglobal(fqv[130]);
	ctx->vsp=local+19;
	w=(pointer)XFORMAT(ctx,3,local+16); /*format*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(*ftab[23])(ctx,1,local+16,&ftab[23],fqv[132]); /*read-from-string*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)EVAL(ctx,1,local+16); /*eval*/
	local[16]= w;
	local[17]= local[16];
	ctx->vsp=local+18;
	w=(pointer)LENGTH(ctx,1,local+17); /*length*/
	local[17]= w;
	w = makeint((eusinteger_t)0L);
	if ((eusinteger_t)local[17] <= (eusinteger_t)w) goto irtbvhIF4681;
	local[17]= local[16];
	w = local[4];
	ctx->vsp=local+18;
	local[4] = cons(ctx,local[17],w);
	local[17]= local[4];
	goto irtbvhIF4682;
irtbvhIF4681:
	local[17]= NIL;
irtbvhIF4682:
	w = local[17];
	local[16]= local[10];
	local[17]= NIL;
	local[18]= NIL;
	ctx->vsp=local+19;
	w=(pointer)READLINE(ctx,3,local+16); /*read-line*/
	local[16]= w;
	storeglobal(fqv[130],w);
	ctx->vsp=local+16;
	goto irtbvhTAG4678;
	local[16]= NIL;
	ctx->vsp=local+17;
	unbindx(ctx,1);
	w = local[16];
	local[13]= w;
irtbvhBLK4677:
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(pointer)NREVERSE(ctx,1,local+13); /*nreverse*/
	local[4] = w;
	local[13]= makeint((eusinteger_t)2L);
	local[14]= fqv[133];
	local[15]= argv[0];
	ctx->vsp=local+16;
	w=(*ftab[11])(ctx,3,local+13,&ftab[11],fqv[61]); /*warning-message*/
	local[13]= makeint((eusinteger_t)2L);
	local[14]= fqv[134];
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	ctx->vsp=local+16;
	w=(pointer)LENGTH(ctx,1,local+15); /*length*/
	local[15]= w;
	local[16]= local[4];
	ctx->vsp=local+17;
	w=(pointer)LENGTH(ctx,1,local+16); /*length*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(*ftab[11])(ctx,4,local+13,&ftab[11],fqv[61]); /*warning-message*/
	local[13]= fqv[135];
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	local[14]= fqv[136];
	local[15]= fqv[137];
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,1,local+16); /*list*/
	ctx->vsp=local+16;
	local[15]= cons(ctx,local[15],w);
	local[16]= fqv[138];
	local[17]= local[6];
	ctx->vsp=local+18;
	w=(pointer)LIST(ctx,1,local+17); /*list*/
	ctx->vsp=local+17;
	local[16]= cons(ctx,local[16],w);
	local[17]= local[4];
	ctx->vsp=local+18;
	w=(pointer)LIST(ctx,1,local+17); /*list*/
	ctx->vsp=local+17;
	w = cons(ctx,local[16],w);
	ctx->vsp=local+16;
	local[15]= cons(ctx,local[15],w);
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	local[14]= cons(ctx,local[14],w);
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	irtbvhUWP4671(ctx,0,local+13,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[10]= w;
	ctx->vsp=local+11;
	unbindx(ctx,1);
	w = local[10];
	local[0]= w;
irtbvhBLK4668:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4670(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeint((eusinteger_t)125L);
	local[1]= argv[0];
	local[2]= T;
	ctx->vsp=local+3;
	w=(*ftab[24])(ctx,3,local+0,&ftab[24],fqv[139]); /*read-delimited-list*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhUWP4671(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[10];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*make-bvh-robot-model*/
static pointer irtbvhF4471make_bvh_robot_model(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtbvhRST4684:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= loadglobal(fqv[140]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= (pointer)get_sym_func(fqv[141]);
	local[3]= local[1];
	local[4]= fqv[15];
	local[5]= fqv[142];
	local[6]= argv[0];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,6,local+2); /*apply*/
	w = local[1];
	local[0]= w;
irtbvhBLK4683:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtbvhM4685motion_capture_data_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[143], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtbvhKEY4687;
	ctx->vsp=local+2;
	w=(*ftab[4])(ctx,0,local+2,&ftab[4],fqv[8]); /*make-coords*/
	local[0] = w;
irtbvhKEY4687:
	if (n & (1<<1)) goto irtbvhKEY4688;
	local[1] = NIL;
irtbvhKEY4688:
	local[2]= NIL;
	local[3]= argv[2];
	local[4]= fqv[47];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)irtbvhF4470read_bvh(ctx,3,local+3); /*read-bvh*/
	local[2] = w;
	local[3]= fqv[135];
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(*ftab[18])(ctx,2,local+3,&ftab[18],fqv[116]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= fqv[45];
	local[5]= local[0];
	local[6]= fqv[47];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)irtbvhF4471make_bvh_robot_model(ctx,5,local+3); /*make-bvh-robot-model*/
	argv[0]->c.obj.iv[2] = w;
	local[3]= fqv[136];
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(*ftab[18])(ctx,2,local+3,&ftab[18],fqv[116]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(*ftab[25])(ctx,1,local+3,&ftab[25],fqv[144]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[3] = (w)->c.cons.car;
	argv[0]->c.obj.iv[1] = makeint((eusinteger_t)0L);
	w = argv[0];
	local[0]= w;
irtbvhBLK4686:
	ctx->vsp=local; return(local[0]);}

/*:model*/
static pointer irtbvhM4689motion_capture_data_model(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4691:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4690:
	ctx->vsp=local; return(local[0]);}

/*:animation*/
static pointer irtbvhM4692motion_capture_data_animation(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4694:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4693:
	ctx->vsp=local; return(local[0]);}

/*:frame*/
static pointer irtbvhM4695motion_capture_data_frame(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtbvhENT4698;}
	local[0]= NIL;
irtbvhENT4698:
irtbvhENT4697:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtbvhIF4699;
	argv[0]->c.obj.iv[1] = local[0];
	local[1]= argv[0]->c.obj.iv[1];
	goto irtbvhIF4700;
irtbvhIF4699:
	local[1]= NIL;
irtbvhIF4700:
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	local[4]= argv[0]->c.obj.iv[2];
	local[5]= fqv[146];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
irtbvhWHL4701:
	if (local[4]==NIL) goto irtbvhWHX4702;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[3];
	local[6]= fqv[111];
	local[7]= local[1];
	local[8]= local[2];
	local[9]= local[2];
	local[10]= local[3];
	local[11]= fqv[73];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[2] = w;
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)SUBSEQ(ctx,3,local+7); /*subseq*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	goto irtbvhWHL4701;
irtbvhWHX4702:
	local[5]= NIL;
irtbvhBLK4703:
	w = NIL;
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtbvhBLK4696:
	ctx->vsp=local; return(local[0]);}

/*:frame-length*/
static pointer irtbvhM4704motion_capture_data_frame_length(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
irtbvhBLK4705:
	ctx->vsp=local; return(local[0]);}

/*:animate*/
static pointer irtbvhM4706motion_capture_data_animate(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4708:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[147], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtbvhKEY4709;
	local[1] = makeint((eusinteger_t)0L);
irtbvhKEY4709:
	if (n & (1<<1)) goto irtbvhKEY4710;
	local[2] = makeint((eusinteger_t)1L);
irtbvhKEY4710:
	if (n & (1<<2)) goto irtbvhKEY4711;
	local[5]= argv[0];
	local[6]= fqv[148];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[3] = w;
irtbvhKEY4711:
	if (n & (1<<3)) goto irtbvhKEY4712;
	local[4] = makeint((eusinteger_t)20L);
irtbvhKEY4712:
	local[5]= argv[0];
	local[6]= fqv[149];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	{jmp_buf jb;
	w = fqv[150];
	ctx->vsp=local+5;
	mkcatchframe(ctx,w,(jmp_buf *)jb);
	if ((w=(pointer)eussetjmp(jb))!=0) { /*fsp=vsp;*/ goto irtbvhCAT4713;}
irtbvhWHL4714:
	if (T==NIL) goto irtbvhWHX4715;
	local[11]= argv[0];
	local[12]= fqv[149];
	local[13]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	local[11]= loadglobal(fqv[151]);
	local[12]= fqv[152];
	ctx->vsp=local+13;
	w=(pointer)GETPROP(ctx,2,local+11); /*get*/
	local[11]= w;
	local[12]= fqv[153];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= NIL;
	ctx->vsp=local+12;
	w=(*ftab[27])(ctx,0,local+12,&ftab[27],fqv[154]); /*objects*/
	local[12]= w;
irtbvhWHL4717:
	if (local[12]==NIL) goto irtbvhWHX4718;
	w=local[12];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	w=local[12];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12] = (w)->c.cons.cdr;
	w = local[13];
	local[11] = w;
	local[13]= local[11];
	local[14]= loadglobal(fqv[140]);
	ctx->vsp=local+15;
	w=(pointer)DERIVEDP(ctx,2,local+13); /*derivedp*/
	if (w!=NIL) goto irtbvhIF4720;
	local[13]= local[11];
	local[14]= loadglobal(fqv[155]);
	ctx->vsp=local+15;
	w=(pointer)DERIVEDP(ctx,2,local+13); /*derivedp*/
	if (w==NIL) goto irtbvhIF4720;
	local[13]= argv[0];
	local[14]= fqv[156];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	local[14]= fqv[157];
	local[15]= local[11];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= w;
	goto irtbvhIF4721;
irtbvhIF4720:
	local[13]= NIL;
irtbvhIF4721:
	goto irtbvhWHL4717;
irtbvhWHX4718:
	local[13]= NIL;
irtbvhBLK4719:
	w = NIL;
	local[11]= argv[0]->c.obj.iv[1];
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	argv[0]->c.obj.iv[1] = w;
	local[11]= argv[0]->c.obj.iv[1];
	local[12]= argv[0];
	local[13]= fqv[148];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)GREQP(ctx,2,local+11); /*>=*/
	if (w==NIL) goto irtbvhIF4722;
	local[11]= fqv[150];
	w = NIL;
	ctx->vsp=local+12;
	throw(ctx,vpop(),w);
	error(E_NOCATCHER,NULL);
	goto irtbvhIF4723;
irtbvhIF4722:
	local[11]= NIL;
irtbvhIF4723:
	local[11]= loadglobal(fqv[158]);
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	local[11]= w;
	local[12]= makeflt(9.9999999999999969005032e-09);
	ctx->vsp=local+13;
	w=(*ftab[28])(ctx,2,local+11,&ftab[28],fqv[159]); /*select-stream*/
	if (w==NIL) goto irtbvhIF4724;
	local[11]= fqv[150];
	w = NIL;
	ctx->vsp=local+12;
	throw(ctx,vpop(),w);
	error(E_NOCATCHER,NULL);
	goto irtbvhIF4725;
irtbvhIF4724:
	local[11]= NIL;
irtbvhIF4725:
	if (local[4]==NIL) goto irtbvhIF4726;
	local[11]= makeint((eusinteger_t)1000L);
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[29])(ctx,1,local+11,&ftab[29],fqv[160]); /*unix:usleep*/
	local[11]= w;
	goto irtbvhIF4727;
irtbvhIF4726:
	local[11]= NIL;
irtbvhIF4727:
	ctx->vsp=local+11;
	w=(*ftab[30])(ctx,0,local+11,&ftab[30],fqv[161]); /*x::window-main-one*/
	goto irtbvhWHL4714;
irtbvhWHX4715:
	local[11]= NIL;
irtbvhBLK4716:
	w = local[11];
irtbvhCAT4713:
	if (w==(pointer)(1)) w=makeint(0);
	restorecatch(ctx);};
	local[0]= w;
irtbvhBLK4707:
	ctx->vsp=local; return(local[0]);}

/*bvh2eus*/
static pointer irtbvhF4472bvh2eus(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtbvhRST4729:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[162], &argv[1], n-1, local+1, 1);
	if (n & (1<<0)) goto irtbvhKEY4730;
	local[1] = NIL;
irtbvhKEY4730:
	local[2]= NIL;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)LISTP(ctx,1,local+3); /*listp*/
	if (w!=NIL) goto irtbvhIF4731;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	local[1] = w;
	local[3]= local[1];
	goto irtbvhIF4732;
irtbvhIF4731:
	local[3]= NIL;
irtbvhIF4732:
	local[3]= (pointer)get_sym_func(fqv[163]);
	local[4]= argv[0];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,3,local+3); /*apply*/
	local[2] = w;
	local[3]= local[2];
	local[4]= fqv[156];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	local[3]= w;
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)APPEND(ctx,2,local+3); /*append*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[27])(ctx,1,local+3,&ftab[27],fqv[154]); /*objects*/
	local[3]= local[2];
	local[4]= fqv[150];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	w = local[2];
	local[0]= w;
irtbvhBLK4728:
	ctx->vsp=local; return(local[0]);}

/*:init-end-coords*/
static pointer irtbvhM4733bvh_robot_model_init_end_coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtbvhCLO4735,env,argv,local);
	local[1]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[101]); /*find-if*/
	argv[0]->c.obj.iv[13] = w;
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtbvhCLO4736,env,argv,local);
	local[1]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[101]); /*find-if*/
	argv[0]->c.obj.iv[14] = w;
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtbvhCLO4737,env,argv,local);
	local[1]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[101]); /*find-if*/
	argv[0]->c.obj.iv[15] = w;
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtbvhCLO4738,env,argv,local);
	local[1]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[101]); /*find-if*/
	argv[0]->c.obj.iv[16] = w;
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtbvhCLO4739,env,argv,local);
	local[1]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[101]); /*find-if*/
	argv[0]->c.obj.iv[18] = w;
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtbvhCLO4740,env,argv,local);
	local[1]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[101]); /*find-if*/
	argv[0]->c.obj.iv[17] = w;
	w = argv[0]->c.obj.iv[17];
	local[0]= w;
irtbvhBLK4734:
	ctx->vsp=local; return(local[0]);}

/*:init-root-link*/
static pointer irtbvhM4741bvh_robot_model_init_root_link(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[27];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[19] = (w)->c.cons.car;
	w=argv[0]->c.obj.iv[28];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[20] = (w)->c.cons.car;
	w=argv[0]->c.obj.iv[29];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[21] = (w)->c.cons.car;
	w=argv[0]->c.obj.iv[30];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[22] = (w)->c.cons.car;
	w=argv[0]->c.obj.iv[31];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[24] = (w)->c.cons.car;
	w=argv[0]->c.obj.iv[32];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[23] = (w)->c.cons.car;
	w = argv[0]->c.obj.iv[23];
	local[0]= w;
irtbvhBLK4742:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4735(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[0]= ((fqv[164])==(local[0])?T:NIL);
	if (local[0]==NIL) goto irtbvhAND4743;
	local[0]= argv[0];
	local[1]= fqv[71];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= env->c.clo.env1[0]->c.obj.iv[27];
	ctx->vsp=local+2;
	w=(*ftab[25])(ctx,1,local+1,&ftab[25],fqv[144]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (((w)->c.cons.car)==(local[0])?T:NIL);
irtbvhAND4743:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4736(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[0]= ((fqv[164])==(local[0])?T:NIL);
	if (local[0]==NIL) goto irtbvhAND4744;
	local[0]= argv[0];
	local[1]= fqv[71];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= env->c.clo.env1[0]->c.obj.iv[28];
	ctx->vsp=local+2;
	w=(*ftab[25])(ctx,1,local+1,&ftab[25],fqv[144]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (((w)->c.cons.car)==(local[0])?T:NIL);
irtbvhAND4744:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4737(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[0]= ((fqv[164])==(local[0])?T:NIL);
	if (local[0]==NIL) goto irtbvhAND4745;
	local[0]= argv[0];
	local[1]= fqv[71];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= env->c.clo.env1[0]->c.obj.iv[29];
	ctx->vsp=local+2;
	w=(*ftab[25])(ctx,1,local+1,&ftab[25],fqv[144]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (((w)->c.cons.car)==(local[0])?T:NIL);
irtbvhAND4745:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4738(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[0]= ((fqv[164])==(local[0])?T:NIL);
	if (local[0]==NIL) goto irtbvhAND4746;
	local[0]= argv[0];
	local[1]= fqv[71];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= env->c.clo.env1[0]->c.obj.iv[30];
	ctx->vsp=local+2;
	w=(*ftab[25])(ctx,1,local+1,&ftab[25],fqv[144]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (((w)->c.cons.car)==(local[0])?T:NIL);
irtbvhAND4746:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4739(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[0]= ((fqv[164])==(local[0])?T:NIL);
	if (local[0]==NIL) goto irtbvhAND4747;
	local[0]= argv[0];
	local[1]= fqv[71];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= env->c.clo.env1[0]->c.obj.iv[31];
	ctx->vsp=local+2;
	w=(*ftab[25])(ctx,1,local+1,&ftab[25],fqv[144]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (((w)->c.cons.car)==(local[0])?T:NIL);
irtbvhAND4747:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4740(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[0]= ((fqv[164])==(local[0])?T:NIL);
	if (local[0]==NIL) goto irtbvhAND4748;
	local[0]= argv[0];
	local[1]= fqv[71];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= env->c.clo.env1[0]->c.obj.iv[32];
	ctx->vsp=local+2;
	w=(*ftab[25])(ctx,1,local+1,&ftab[25],fqv[144]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (((w)->c.cons.car)==(local[0])?T:NIL);
irtbvhAND4748:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtbvhM4749rikiya_bvh_robot_model_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4751:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[34]);
	local[2]= argv[0];
	local[3]= *(ovafptr(argv[1],fqv[14]));
	local[4]= fqv[15];
	local[5]= fqv[45];
	local[6]= fqv[165];
	local[7]= makeflt(1.5707963267948965579990e+00);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeflt(1.5707963267948965579990e+00);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[4])(ctx,2,local+6,&ftab[4],fqv[8]); /*make-coords*/
	local[6]= w;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,7,local+1); /*apply*/
	local[1]= fqv[166];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4752,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[169];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4753,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[170];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4754,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	local[4]= fqv[171];
	local[5]= argv[0]->c.obj.iv[8];
	local[6]= fqv[167];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtbvhCLO4755,env,argv,local);
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,4,local+4,&ftab[31],fqv[168]); /*find*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,4,local+1); /*list*/
	argv[0]->c.obj.iv[27] = w;
	local[1]= fqv[172];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4756,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[173];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4757,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[174];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4758,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	local[4]= fqv[175];
	local[5]= argv[0]->c.obj.iv[8];
	local[6]= fqv[167];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtbvhCLO4759,env,argv,local);
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,4,local+4,&ftab[31],fqv[168]); /*find*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,4,local+1); /*list*/
	argv[0]->c.obj.iv[28] = w;
	local[1]= fqv[176];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4760,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[177];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4761,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[178];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4762,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,3,local+1); /*list*/
	argv[0]->c.obj.iv[29] = w;
	local[1]= fqv[179];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4763,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[180];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4764,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[181];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4765,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,3,local+1); /*list*/
	argv[0]->c.obj.iv[30] = w;
	local[1]= fqv[182];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4766,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	argv[0]->c.obj.iv[31] = w;
	local[1]= fqv[183];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4767,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[184];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4768,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	argv[0]->c.obj.iv[32] = w;
	local[1]= argv[0];
	local[2]= fqv[185];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[186];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	w = argv[0];
	local[0]= w;
irtbvhBLK4750:
	ctx->vsp=local; return(local[0]);}

/*:larm-collar*/
static pointer irtbvhM4769rikiya_bvh_robot_model_larm_collar(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4771:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[27];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4770:
	ctx->vsp=local; return(local[0]);}

/*:larm-shoulder*/
static pointer irtbvhM4772rikiya_bvh_robot_model_larm_shoulder(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4774:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[27];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4773:
	ctx->vsp=local; return(local[0]);}

/*:larm-elbow*/
static pointer irtbvhM4775rikiya_bvh_robot_model_larm_elbow(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4777:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[27];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4776:
	ctx->vsp=local; return(local[0]);}

/*:larm-wrist*/
static pointer irtbvhM4778rikiya_bvh_robot_model_larm_wrist(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4780:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[27];
	local[2]= makeint((eusinteger_t)3L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4779:
	ctx->vsp=local; return(local[0]);}

/*:rarm-collar*/
static pointer irtbvhM4781rikiya_bvh_robot_model_rarm_collar(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4783:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[28];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4782:
	ctx->vsp=local; return(local[0]);}

/*:rarm-shoulder*/
static pointer irtbvhM4784rikiya_bvh_robot_model_rarm_shoulder(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4786:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[28];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4785:
	ctx->vsp=local; return(local[0]);}

/*:rarm-elbow*/
static pointer irtbvhM4787rikiya_bvh_robot_model_rarm_elbow(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4789:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[28];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4788:
	ctx->vsp=local; return(local[0]);}

/*:rarm-wrist*/
static pointer irtbvhM4790rikiya_bvh_robot_model_rarm_wrist(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4792:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[28];
	local[2]= makeint((eusinteger_t)3L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4791:
	ctx->vsp=local; return(local[0]);}

/*:lleg-crotch*/
static pointer irtbvhM4793rikiya_bvh_robot_model_lleg_crotch(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4795:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[29];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4794:
	ctx->vsp=local; return(local[0]);}

/*:lleg-knee*/
static pointer irtbvhM4796rikiya_bvh_robot_model_lleg_knee(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4798:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[29];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4797:
	ctx->vsp=local; return(local[0]);}

/*:lleg-ankle*/
static pointer irtbvhM4799rikiya_bvh_robot_model_lleg_ankle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4801:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[29];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4800:
	ctx->vsp=local; return(local[0]);}

/*:rleg-crotch*/
static pointer irtbvhM4802rikiya_bvh_robot_model_rleg_crotch(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4804:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[30];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4803:
	ctx->vsp=local; return(local[0]);}

/*:rleg-knee*/
static pointer irtbvhM4805rikiya_bvh_robot_model_rleg_knee(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4807:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[30];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4806:
	ctx->vsp=local; return(local[0]);}

/*:rleg-ankle*/
static pointer irtbvhM4808rikiya_bvh_robot_model_rleg_ankle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4810:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[30];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4809:
	ctx->vsp=local; return(local[0]);}

/*:torso-chest*/
static pointer irtbvhM4811rikiya_bvh_robot_model_torso_chest(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4813:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[31];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4812:
	ctx->vsp=local; return(local[0]);}

/*:head-neck*/
static pointer irtbvhM4814rikiya_bvh_robot_model_head_neck(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4816:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[32];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[26])(ctx,2,local+1,&ftab[26],fqv[145]); /*forward-message-to*/
	local[0]= w;
irtbvhBLK4815:
	ctx->vsp=local; return(local[0]);}

/*:copy-joint-to*/
static pointer irtbvhM4817rikiya_bvh_robot_model_copy_joint_to(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	w = argv[4];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[187],w);
	if (n>=6) { local[3]=(argv[5]); goto irtbvhENT4820;}
	local[3]= makeint((eusinteger_t)1L);
irtbvhENT4820:
irtbvhENT4819:
	if (n>6) maerror();
	local[4]= argv[2];
	local[5]= NIL;
	local[6]= fqv[188];
	local[7]= argv[3];
	ctx->vsp=local+8;
	w=(*ftab[32])(ctx,1,local+7,&ftab[32],fqv[189]); /*symbol-name*/
	local[7]= w;
	local[8]= loadglobal(fqv[187]);
	ctx->vsp=local+9;
	w=(*ftab[32])(ctx,1,local+8,&ftab[32],fqv[189]); /*symbol-name*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,4,local+5); /*format*/
	local[5]= w;
	local[6]= fqv[190];
	ctx->vsp=local+7;
	w=(pointer)INTERN(ctx,2,local+5); /*intern*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[33])(ctx,2,local+4,&ftab[33],fqv[191]); /*find-method*/
	if (w==NIL) goto irtbvhIF4821;
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= NIL;
	local[7]= fqv[192];
	local[8]= loadglobal(fqv[187]);
	ctx->vsp=local+9;
	w=(*ftab[32])(ctx,1,local+8,&ftab[32],fqv[189]); /*symbol-name*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= w;
	local[7]= fqv[193];
	ctx->vsp=local+8;
	w=(pointer)INTERN(ctx,2,local+6); /*intern*/
	local[6]= w;
	local[7]= fqv[38];
	local[8]= local[3];
	local[9]= argv[0];
	local[10]= argv[3];
	local[11]= loadglobal(fqv[187]);
	local[12]= fqv[83];
	local[13]= fqv[38];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,5,local+9); /*send*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	local[4]= w;
	goto irtbvhIF4822;
irtbvhIF4821:
	local[4]= NIL;
irtbvhIF4822:
	local[4]= argv[2];
	local[5]= NIL;
	local[6]= fqv[194];
	local[7]= argv[3];
	ctx->vsp=local+8;
	w=(*ftab[32])(ctx,1,local+7,&ftab[32],fqv[189]); /*symbol-name*/
	local[7]= w;
	local[8]= loadglobal(fqv[187]);
	ctx->vsp=local+9;
	w=(*ftab[32])(ctx,1,local+8,&ftab[32],fqv[189]); /*symbol-name*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,4,local+5); /*format*/
	local[5]= w;
	local[6]= fqv[195];
	ctx->vsp=local+7;
	w=(pointer)INTERN(ctx,2,local+5); /*intern*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[33])(ctx,2,local+4,&ftab[33],fqv[191]); /*find-method*/
	if (w==NIL) goto irtbvhIF4823;
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= NIL;
	local[7]= fqv[196];
	local[8]= loadglobal(fqv[187]);
	ctx->vsp=local+9;
	w=(*ftab[32])(ctx,1,local+8,&ftab[32],fqv[189]); /*symbol-name*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= w;
	local[7]= fqv[197];
	ctx->vsp=local+8;
	w=(pointer)INTERN(ctx,2,local+6); /*intern*/
	local[6]= w;
	local[7]= fqv[38];
	local[8]= argv[0];
	local[9]= argv[3];
	local[10]= loadglobal(fqv[187]);
	local[11]= fqv[83];
	local[12]= fqv[38];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,5,local+8); /*send*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	local[4]= w;
	goto irtbvhIF4824;
irtbvhIF4823:
	local[4]= NIL;
irtbvhIF4824:
	local[4]= argv[2];
	local[5]= NIL;
	local[6]= fqv[198];
	local[7]= argv[3];
	ctx->vsp=local+8;
	w=(*ftab[32])(ctx,1,local+7,&ftab[32],fqv[189]); /*symbol-name*/
	local[7]= w;
	local[8]= loadglobal(fqv[187]);
	ctx->vsp=local+9;
	w=(*ftab[32])(ctx,1,local+8,&ftab[32],fqv[189]); /*symbol-name*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,4,local+5); /*format*/
	local[5]= w;
	local[6]= fqv[199];
	ctx->vsp=local+7;
	w=(pointer)INTERN(ctx,2,local+5); /*intern*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[33])(ctx,2,local+4,&ftab[33],fqv[191]); /*find-method*/
	if (w==NIL) goto irtbvhIF4825;
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= NIL;
	local[7]= fqv[200];
	local[8]= loadglobal(fqv[187]);
	ctx->vsp=local+9;
	w=(*ftab[32])(ctx,1,local+8,&ftab[32],fqv[189]); /*symbol-name*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= w;
	local[7]= fqv[201];
	ctx->vsp=local+8;
	w=(pointer)INTERN(ctx,2,local+6); /*intern*/
	local[6]= w;
	local[7]= fqv[38];
	local[8]= local[3];
	local[9]= argv[0];
	local[10]= argv[3];
	local[11]= loadglobal(fqv[187]);
	local[12]= fqv[83];
	local[13]= fqv[38];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,5,local+9); /*send*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	local[4]= w;
	goto irtbvhIF4826;
irtbvhIF4825:
	local[4]= NIL;
irtbvhIF4826:
	ctx->vsp=local+5;
	unbindx(ctx,1);
	w = local[4];
	local[0]= w;
irtbvhBLK4818:
	ctx->vsp=local; return(local[0]);}

/*:copy-state-to*/
static pointer irtbvhM4827rikiya_bvh_robot_model_copy_state_to(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= fqv[202];
irtbvhWHL4829:
	if (local[2]==NIL) goto irtbvhWHX4830;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= NIL;
	local[4]= fqv[203];
	w = local[3];
	ctx->vsp=local+5;
	bindspecial(ctx,fqv[187],w);
irtbvhWHL4832:
	if (local[4]==NIL) goto irtbvhWHX4833;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[8];
	local[8]= w;
	storeglobal(fqv[187],w);
	local[8]= fqv[204];
	ctx->vsp=local+9;
	w=(pointer)BOUNDP(ctx,1,local+8); /*boundp*/
	if (w==NIL) goto irtbvhIF4835;
	local[8]= argv[2];
	local[9]= loadglobal(fqv[204]);
	ctx->vsp=local+10;
	w=(pointer)DERIVEDP(ctx,2,local+8); /*derivedp*/
	if (w==NIL) goto irtbvhIF4835;
	local[8]= argv[0];
	local[9]= fqv[205];
	local[10]= argv[2];
	local[11]= local[1];
	local[12]= loadglobal(fqv[187]);
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,5,local+8); /*send*/
	local[8]= w;
	goto irtbvhIF4836;
irtbvhIF4835:
	local[8]= argv[0];
	local[9]= fqv[205];
	local[10]= argv[2];
	local[11]= local[1];
	local[12]= loadglobal(fqv[187]);
	local[13]= local[1];
	local[14]= local[13];
	if (fqv[206]!=local[14]) goto irtbvhIF4837;
	local[14]= makeint((eusinteger_t)-1L);
	goto irtbvhIF4838;
irtbvhIF4837:
	if (T==NIL) goto irtbvhIF4839;
	local[14]= makeint((eusinteger_t)1L);
	goto irtbvhIF4840;
irtbvhIF4839:
	local[14]= NIL;
irtbvhIF4840:
irtbvhIF4838:
	w = local[14];
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,6,local+8); /*send*/
	local[8]= w;
irtbvhIF4836:
	goto irtbvhWHL4832;
irtbvhWHX4833:
	local[8]= NIL;
irtbvhBLK4834:
	local[8]= NIL;
	ctx->vsp=local+9;
	unbindx(ctx,1);
	w = local[8];
	goto irtbvhWHL4829;
irtbvhWHX4830:
	local[3]= NIL;
irtbvhBLK4831:
	w = NIL;
	local[1]= NIL;
	local[2]= fqv[207];
irtbvhWHL4841:
	if (local[2]==NIL) goto irtbvhWHX4842;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= NIL;
	local[4]= fqv[208];
	w = local[3];
	ctx->vsp=local+5;
	bindspecial(ctx,fqv[187],w);
irtbvhWHL4844:
	if (local[4]==NIL) goto irtbvhWHX4845;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[8];
	local[8]= w;
	storeglobal(fqv[187],w);
	local[8]= fqv[204];
	ctx->vsp=local+9;
	w=(pointer)BOUNDP(ctx,1,local+8); /*boundp*/
	if (w==NIL) goto irtbvhIF4847;
	local[8]= argv[2];
	local[9]= loadglobal(fqv[204]);
	ctx->vsp=local+10;
	w=(pointer)DERIVEDP(ctx,2,local+8); /*derivedp*/
	if (w==NIL) goto irtbvhIF4847;
	local[8]= argv[0];
	local[9]= fqv[205];
	local[10]= argv[2];
	local[11]= local[1];
	local[12]= loadglobal(fqv[187]);
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,5,local+8); /*send*/
	local[8]= w;
	goto irtbvhIF4848;
irtbvhIF4847:
	local[8]= argv[0];
	local[9]= fqv[205];
	local[10]= argv[2];
	local[11]= local[1];
	local[12]= loadglobal(fqv[187]);
	local[13]= local[1];
	local[14]= local[13];
	if (fqv[209]!=local[14]) goto irtbvhIF4849;
	local[14]= makeint((eusinteger_t)-1L);
	goto irtbvhIF4850;
irtbvhIF4849:
	if (T==NIL) goto irtbvhIF4851;
	local[14]= makeint((eusinteger_t)1L);
	goto irtbvhIF4852;
irtbvhIF4851:
	local[14]= NIL;
irtbvhIF4852:
irtbvhIF4850:
	w = local[14];
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,6,local+8); /*send*/
	local[8]= w;
irtbvhIF4848:
	goto irtbvhWHL4844;
irtbvhWHX4845:
	local[8]= NIL;
irtbvhBLK4846:
	local[8]= NIL;
	ctx->vsp=local+9;
	unbindx(ctx,1);
	w = local[8];
	goto irtbvhWHL4841;
irtbvhWHX4842:
	local[3]= NIL;
irtbvhBLK4843:
	w = NIL;
	local[1]= argv[0];
	local[2]= fqv[205];
	local[3]= argv[2];
	local[4]= fqv[210];
	local[5]= fqv[211];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[205];
	local[3]= argv[2];
	local[4]= fqv[212];
	local[5]= fqv[213];
	local[6]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	local[1]= argv[2];
	local[2]= fqv[214];
	local[3]= argv[0];
	local[4]= fqv[215];
	w=argv[0]->c.obj.iv[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= fqv[27];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
irtbvhBLK4828:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4752(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4753(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4754(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4755(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4756(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4757(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4758(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4759(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4760(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4761(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4762(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4763(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4764(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4765(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4766(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4767(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4768(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtbvhM4853tum_bvh_robot_model_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4855:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[34]);
	local[2]= argv[0];
	local[3]= *(ovafptr(argv[1],fqv[14]));
	local[4]= fqv[15];
	local[5]= fqv[45];
	local[6]= fqv[165];
	local[7]= makeflt(1.5707963267948965579990e+00);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[4])(ctx,2,local+6,&ftab[4],fqv[8]); /*make-coords*/
	local[6]= w;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,7,local+1); /*apply*/
	local[1]= fqv[216];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4856,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[217];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4857,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[218];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4858,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	local[4]= fqv[219];
	local[5]= argv[0]->c.obj.iv[8];
	local[6]= fqv[167];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtbvhCLO4859,env,argv,local);
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,4,local+4,&ftab[31],fqv[168]); /*find*/
	local[4]= w;
	local[5]= fqv[220];
	local[6]= argv[0]->c.obj.iv[8];
	local[7]= fqv[167];
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtbvhCLO4860,env,argv,local);
	ctx->vsp=local+9;
	w=(*ftab[31])(ctx,4,local+5,&ftab[31],fqv[168]); /*find*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,5,local+1); /*list*/
	argv[0]->c.obj.iv[27] = w;
	local[1]= fqv[221];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4861,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[222];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4862,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[223];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4863,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	local[4]= fqv[224];
	local[5]= argv[0]->c.obj.iv[8];
	local[6]= fqv[167];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtbvhCLO4864,env,argv,local);
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,4,local+4,&ftab[31],fqv[168]); /*find*/
	local[4]= w;
	local[5]= fqv[225];
	local[6]= argv[0]->c.obj.iv[8];
	local[7]= fqv[167];
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtbvhCLO4865,env,argv,local);
	ctx->vsp=local+9;
	w=(*ftab[31])(ctx,4,local+5,&ftab[31],fqv[168]); /*find*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,5,local+1); /*list*/
	argv[0]->c.obj.iv[28] = w;
	local[1]= fqv[226];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4866,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[227];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4867,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[228];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4868,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	local[4]= fqv[229];
	local[5]= argv[0]->c.obj.iv[8];
	local[6]= fqv[167];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtbvhCLO4869,env,argv,local);
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,4,local+4,&ftab[31],fqv[168]); /*find*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,4,local+1); /*list*/
	argv[0]->c.obj.iv[29] = w;
	local[1]= fqv[230];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4870,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[231];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4871,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[232];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4872,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	local[4]= fqv[233];
	local[5]= argv[0]->c.obj.iv[8];
	local[6]= fqv[167];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtbvhCLO4873,env,argv,local);
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,4,local+4,&ftab[31],fqv[168]); /*find*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,4,local+1); /*list*/
	argv[0]->c.obj.iv[30] = w;
	local[1]= fqv[234];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4874,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[235];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4875,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[236];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4876,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	local[4]= fqv[237];
	local[5]= argv[0]->c.obj.iv[8];
	local[6]= fqv[167];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtbvhCLO4877,env,argv,local);
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,4,local+4,&ftab[31],fqv[168]); /*find*/
	local[4]= w;
	local[5]= fqv[238];
	local[6]= argv[0]->c.obj.iv[8];
	local[7]= fqv[167];
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtbvhCLO4878,env,argv,local);
	ctx->vsp=local+9;
	w=(*ftab[31])(ctx,4,local+5,&ftab[31],fqv[168]); /*find*/
	local[5]= w;
	local[6]= fqv[239];
	local[7]= argv[0]->c.obj.iv[8];
	local[8]= fqv[167];
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,irtbvhCLO4879,env,argv,local);
	ctx->vsp=local+10;
	w=(*ftab[31])(ctx,4,local+6,&ftab[31],fqv[168]); /*find*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,6,local+1); /*list*/
	argv[0]->c.obj.iv[31] = w;
	local[1]= fqv[240];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4880,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[241];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4881,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	argv[0]->c.obj.iv[32] = w;
	local[1]= argv[0];
	local[2]= fqv[185];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[186];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	w = argv[0];
	local[0]= w;
irtbvhBLK4854:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4856(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4857(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4858(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4859(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4860(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4861(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4862(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4863(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4864(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4865(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4866(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4867(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4868(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4869(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4870(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4871(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4872(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4873(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4874(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4875(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4876(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4877(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4878(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4879(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4880(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4881(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtbvhM4882cmu_bvh_robot_model_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtbvhRST4884:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[34]);
	local[2]= argv[0];
	local[3]= *(ovafptr(argv[1],fqv[14]));
	local[4]= fqv[15];
	local[5]= fqv[45];
	local[6]= fqv[165];
	local[7]= makeflt(1.5707963267948965579990e+00);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeflt(1.5707963267948965579990e+00);
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,3,local+7); /*float-vector*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[4])(ctx,2,local+6,&ftab[4],fqv[8]); /*make-coords*/
	local[6]= w;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,7,local+1); /*apply*/
	local[1]= fqv[169];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4885,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[242];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4886,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[243];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4887,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	local[4]= fqv[244];
	local[5]= argv[0]->c.obj.iv[8];
	local[6]= fqv[167];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtbvhCLO4888,env,argv,local);
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,4,local+4,&ftab[31],fqv[168]); /*find*/
	local[4]= w;
	local[5]= fqv[245];
	local[6]= argv[0]->c.obj.iv[8];
	local[7]= fqv[167];
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtbvhCLO4889,env,argv,local);
	ctx->vsp=local+9;
	w=(*ftab[31])(ctx,4,local+5,&ftab[31],fqv[168]); /*find*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,5,local+1); /*list*/
	argv[0]->c.obj.iv[27] = w;
	local[1]= fqv[173];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4890,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[246];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4891,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[247];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4892,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	local[4]= fqv[248];
	local[5]= argv[0]->c.obj.iv[8];
	local[6]= fqv[167];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtbvhCLO4893,env,argv,local);
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,4,local+4,&ftab[31],fqv[168]); /*find*/
	local[4]= w;
	local[5]= fqv[249];
	local[6]= argv[0]->c.obj.iv[8];
	local[7]= fqv[167];
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtbvhCLO4894,env,argv,local);
	ctx->vsp=local+9;
	w=(*ftab[31])(ctx,4,local+5,&ftab[31],fqv[168]); /*find*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,5,local+1); /*list*/
	argv[0]->c.obj.iv[28] = w;
	local[1]= fqv[250];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4895,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[251];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4896,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[252];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4897,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	local[4]= fqv[253];
	local[5]= argv[0]->c.obj.iv[8];
	local[6]= fqv[167];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtbvhCLO4898,env,argv,local);
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,4,local+4,&ftab[31],fqv[168]); /*find*/
	local[4]= w;
	local[5]= fqv[254];
	local[6]= argv[0]->c.obj.iv[8];
	local[7]= fqv[167];
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtbvhCLO4899,env,argv,local);
	ctx->vsp=local+9;
	w=(*ftab[31])(ctx,4,local+5,&ftab[31],fqv[168]); /*find*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,5,local+1); /*list*/
	argv[0]->c.obj.iv[29] = w;
	local[1]= fqv[255];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4900,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[256];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4901,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[257];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4902,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	local[4]= fqv[258];
	local[5]= argv[0]->c.obj.iv[8];
	local[6]= fqv[167];
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtbvhCLO4903,env,argv,local);
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,4,local+4,&ftab[31],fqv[168]); /*find*/
	local[4]= w;
	local[5]= fqv[259];
	local[6]= argv[0]->c.obj.iv[8];
	local[7]= fqv[167];
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtbvhCLO4904,env,argv,local);
	ctx->vsp=local+9;
	w=(*ftab[31])(ctx,4,local+5,&ftab[31],fqv[168]); /*find*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,5,local+1); /*list*/
	argv[0]->c.obj.iv[30] = w;
	local[1]= fqv[260];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4905,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[261];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4906,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[262];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4907,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,3,local+1); /*list*/
	argv[0]->c.obj.iv[31] = w;
	local[1]= fqv[183];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= fqv[167];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtbvhCLO4908,env,argv,local);
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,4,local+1,&ftab[31],fqv[168]); /*find*/
	local[1]= w;
	local[2]= fqv[263];
	local[3]= argv[0]->c.obj.iv[8];
	local[4]= fqv[167];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtbvhCLO4909,env,argv,local);
	ctx->vsp=local+6;
	w=(*ftab[31])(ctx,4,local+2,&ftab[31],fqv[168]); /*find*/
	local[2]= w;
	local[3]= fqv[184];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= fqv[167];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtbvhCLO4910,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[31])(ctx,4,local+3,&ftab[31],fqv[168]); /*find*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,3,local+1); /*list*/
	argv[0]->c.obj.iv[32] = w;
	local[1]= argv[0];
	local[2]= fqv[185];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[186];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	w = argv[0];
	local[0]= w;
irtbvhBLK4883:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4885(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4886(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4887(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4888(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4889(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4890(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4891(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4892(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4893(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4894(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4895(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4896(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4897(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4898(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4899(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4900(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4901(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4902(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4903(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4904(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4905(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4906(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4907(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4908(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4909(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtbvhCLO4910(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*load-mcd*/
static pointer irtbvhF4473load_mcd(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[264], &argv[1], n-1, local+0, 1);
	if (n & (1<<0)) goto irtbvhKEY4912;
	local[0] = NIL;
irtbvhKEY4912:
	if (n & (1<<1)) goto irtbvhKEY4913;
	local[1] = NIL;
irtbvhKEY4913:
	if (n & (1<<2)) goto irtbvhKEY4914;
	local[2] = loadglobal(fqv[140]);
irtbvhKEY4914:
	local[3]= local[2];
	w = local[3];
	ctx->vsp=local+4;
	bindspecial(ctx,fqv[140],w);
	local[7]= loadglobal(fqv[265]);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,1,local+7); /*instantiate*/
	local[7]= w;
	local[8]= local[7];
	local[9]= fqv[15];
	local[10]= argv[0];
	local[11]= fqv[45];
	local[12]= local[1];
	local[13]= fqv[47];
	local[14]= local[0];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,7,local+8); /*send*/
	w = local[7];
	local[7]= w;
	ctx->vsp=local+8;
	unbindx(ctx,1);
	w = local[7];
	local[0]= w;
irtbvhBLK4911:
	ctx->vsp=local; return(local[0]);}

/*rikiya-bvh2eus*/
static pointer irtbvhF4474rikiya_bvh2eus(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtbvhRST4916:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= (pointer)get_sym_func(fqv[266]);
	local[2]= argv[0];
	local[3]= fqv[47];
	local[4]= makeflt(1.0000000000000000000000e+01);
	local[5]= fqv[267];
	local[6]= loadglobal(fqv[268]);
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,7,local+1); /*apply*/
	local[0]= w;
irtbvhBLK4915:
	ctx->vsp=local; return(local[0]);}

/*cmu-bvh2eus*/
static pointer irtbvhF4475cmu_bvh2eus(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtbvhRST4918:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= (pointer)get_sym_func(fqv[266]);
	local[2]= argv[0];
	local[3]= fqv[47];
	local[4]= makeflt(1.0000000000000000000000e+02);
	local[5]= fqv[267];
	local[6]= loadglobal(fqv[269]);
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,7,local+1); /*apply*/
	local[0]= w;
irtbvhBLK4917:
	ctx->vsp=local; return(local[0]);}

/*tum-bvh2eus*/
static pointer irtbvhF4476tum_bvh2eus(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtbvhRST4920:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= (pointer)get_sym_func(fqv[266]);
	local[2]= argv[0];
	local[3]= fqv[47];
	local[4]= makeflt(1.0000000000000000000000e+01);
	local[5]= fqv[267];
	local[6]= loadglobal(fqv[270]);
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,7,local+1); /*apply*/
	local[0]= w;
irtbvhBLK4919:
	ctx->vsp=local; return(local[0]);}

/*rikiya-file*/
static pointer irtbvhF4477rikiya_file(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[271], &argv[0], n-0, local+0, 0);
	if (n & (1<<0)) goto irtbvhKEY4922;
	local[0] = makeint((eusinteger_t)1L);
irtbvhKEY4922:
	if (n & (1<<1)) goto irtbvhKEY4923;
	local[1] = fqv[272];
irtbvhKEY4923:
	local[2]= NIL;
	local[3]= fqv[273];
	local[4]= fqv[274];
	ctx->vsp=local+5;
	w=(pointer)GETENV(ctx,1,local+4); /*unix:getenv*/
	local[4]= w;
	local[5]= local[1];
	local[6]= NIL;
	local[7]= fqv[275];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[16])(ctx,1,local+6,&ftab[16],fqv[87]); /*string-upcase*/
	local[6]= w;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)XFORMAT(ctx,6,local+2); /*format*/
	local[0]= w;
irtbvhBLK4921:
	ctx->vsp=local; return(local[0]);}

/*tum-kitchen-file*/
static pointer irtbvhF4478tum_kitchen_file(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[276], &argv[0], n-0, local+0, 0);
	if (n & (1<<0)) goto irtbvhKEY4925;
	local[0] = makeint((eusinteger_t)1L);
irtbvhKEY4925:
	if (n & (1<<1)) goto irtbvhKEY4926;
	local[1] = makeint((eusinteger_t)0L);
irtbvhKEY4926:
	local[2]= NIL;
	local[3]= fqv[277];
	local[4]= fqv[278];
	ctx->vsp=local+5;
	w=(pointer)GETENV(ctx,1,local+4); /*unix:getenv*/
	local[4]= w;
	local[5]= local[1];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,5,local+2); /*format*/
	local[0]= w;
irtbvhBLK4924:
	ctx->vsp=local; return(local[0]);}

/*cmu-mocap-file*/
static pointer irtbvhF4479cmu_mocap_file(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[279], &argv[0], n-0, local+0, 0);
	if (n & (1<<0)) goto irtbvhKEY4928;
	local[0] = makeint((eusinteger_t)1L);
irtbvhKEY4928:
	if (n & (1<<1)) goto irtbvhKEY4929;
	local[1] = makeint((eusinteger_t)1L);
irtbvhKEY4929:
	local[2]= NIL;
	local[3]= fqv[280];
	local[4]= fqv[281];
	ctx->vsp=local+5;
	w=(pointer)GETENV(ctx,1,local+4); /*unix:getenv*/
	local[4]= w;
	local[5]= local[1];
	local[6]= local[1];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)XFORMAT(ctx,6,local+2); /*format*/
	local[0]= w;
irtbvhBLK4927:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___irtbvh(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[282];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtbvhIF4930;
	local[0]= fqv[283];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[284],w);
	goto irtbvhIF4931;
irtbvhIF4930:
	local[0]= fqv[285];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtbvhIF4931:
	local[0]= fqv[51];
	local[1]= fqv[286];
	local[2]= fqv[51];
	local[3]= fqv[287];
	local[4]= loadglobal(fqv[54]);
	local[5]= fqv[288];
	local[6]= fqv[289];
	local[7]= fqv[290];
	local[8]= NIL;
	local[9]= fqv[291];
	local[10]= NIL;
	local[11]= fqv[292];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[293];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[34])(ctx,13,local+2,&ftab[34],fqv[294]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4480bvh_link_init,fqv[15],fqv[51],fqv[295]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4503bvh_link_type,fqv[86],fqv[51],fqv[296]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4505bvh_link_offset,fqv[81],fqv[51],fqv[297]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4507bvh_link_channels,fqv[82],fqv[51],fqv[298]);
	local[0]= fqv[57];
	local[1]= fqv[286];
	local[2]= fqv[57];
	local[3]= fqv[287];
	local[4]= loadglobal(fqv[299]);
	local[5]= fqv[288];
	local[6]= fqv[300];
	local[7]= fqv[290];
	local[8]= NIL;
	local[9]= fqv[291];
	local[10]= NIL;
	local[11]= fqv[292];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[293];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[34])(ctx,13,local+2,&ftab[34],fqv[294]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4509bvh_sphere_joint_init,fqv[15],fqv[57],fqv[301]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4514bvh_sphere_joint_joint_angle_bvh,fqv[111],fqv[57],fqv[302]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4518bvh_sphere_joint_joint_angle_bvh_offset,fqv[76],fqv[57],fqv[303]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4522bvh_sphere_joint_joint_angle_bvh_impl,fqv[35],fqv[57],fqv[304]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4526bvh_sphere_joint_axis_order,fqv[84],fqv[57],fqv[305]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4528bvh_sphere_joint_bvh_offset_rotation,fqv[64],fqv[57],fqv[306]);
	local[0]= fqv[59];
	local[1]= fqv[286];
	local[2]= fqv[59];
	local[3]= fqv[287];
	local[4]= loadglobal(fqv[307]);
	local[5]= fqv[288];
	local[6]= fqv[308];
	local[7]= fqv[290];
	local[8]= NIL;
	local[9]= fqv[291];
	local[10]= NIL;
	local[11]= fqv[292];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[293];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[34])(ctx,13,local+2,&ftab[34],fqv[294]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4530bvh_6dof_joint_init,fqv[15],fqv[59],fqv[309]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4538bvh_6dof_joint_joint_angle_bvh,fqv[111],fqv[59],fqv[310]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4542bvh_6dof_joint_joint_angle_bvh_offset,fqv[76],fqv[59],fqv[311]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4546bvh_6dof_joint_joint_angle_bvh_impl,fqv[35],fqv[59],fqv[312]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4550bvh_6dof_joint_axis_order,fqv[84],fqv[59],fqv[313]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4552bvh_6dof_joint_bvh_offset_rotation,fqv[64],fqv[59],fqv[314]);
	local[0]= fqv[140];
	local[1]= fqv[286];
	local[2]= fqv[140];
	local[3]= fqv[287];
	local[4]= loadglobal(fqv[155]);
	local[5]= fqv[288];
	local[6]= fqv[315];
	local[7]= fqv[290];
	local[8]= NIL;
	local[9]= fqv[291];
	local[10]= NIL;
	local[11]= fqv[292];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[293];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[34])(ctx,13,local+2,&ftab[34],fqv[294]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4554bvh_robot_model_init,fqv[15],fqv[140],fqv[316]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4562bvh_robot_model_make_bvh_link,fqv[46],fqv[140],fqv[317]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4583bvh_robot_model_angle_vector,fqv[318],fqv[140],fqv[319]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4602bvh_robot_model_dump_joints,fqv[97],fqv[140],fqv[320]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4623bvh_robot_model_dump_hierarchy,fqv[321],fqv[140],fqv[322]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4627bvh_robot_model_dump_motion,fqv[323],fqv[140],fqv[324]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4637bvh_robot_model_copy_state_to,fqv[157],fqv[140],fqv[325]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4639bvh_robot_model_fix_joint_angle,fqv[326],fqv[140],fqv[327]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4641bvh_robot_model_fix_joint_order,fqv[328],fqv[140],fqv[329]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4643bvh_robot_model_bvh_offset_rotate,fqv[65],fqv[140],fqv[330]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[331],module,irtbvhF4469parse_bvh_sexp,fqv[332]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[333],module,irtbvhF4470read_bvh,fqv[334]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[335],module,irtbvhF4471make_bvh_robot_model,fqv[336]);
	local[0]= fqv[265];
	local[1]= fqv[286];
	local[2]= fqv[265];
	local[3]= fqv[287];
	local[4]= loadglobal(fqv[337]);
	local[5]= fqv[288];
	local[6]= fqv[338];
	local[7]= fqv[290];
	local[8]= NIL;
	local[9]= fqv[291];
	local[10]= NIL;
	local[11]= fqv[292];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[293];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[34])(ctx,13,local+2,&ftab[34],fqv[294]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4685motion_capture_data_init,fqv[15],fqv[265],fqv[339]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4689motion_capture_data_model,fqv[156],fqv[265],fqv[340]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4692motion_capture_data_animation,fqv[341],fqv[265],fqv[342]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4695motion_capture_data_frame,fqv[149],fqv[265],fqv[343]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4704motion_capture_data_frame_length,fqv[148],fqv[265],fqv[344]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4706motion_capture_data_animate,fqv[150],fqv[265],fqv[345]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[266],module,irtbvhF4472bvh2eus,fqv[346]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4733bvh_robot_model_init_end_coords,fqv[185],fqv[140],fqv[347]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4741bvh_robot_model_init_root_link,fqv[186],fqv[140],fqv[348]);
	local[0]= fqv[268];
	local[1]= fqv[286];
	local[2]= fqv[268];
	local[3]= fqv[287];
	local[4]= loadglobal(fqv[140]);
	local[5]= fqv[288];
	local[6]= fqv[315];
	local[7]= fqv[290];
	local[8]= NIL;
	local[9]= fqv[291];
	local[10]= NIL;
	local[11]= fqv[292];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[293];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[34])(ctx,13,local+2,&ftab[34],fqv[294]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4749rikiya_bvh_robot_model_init,fqv[15],fqv[268],fqv[349]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4769rikiya_bvh_robot_model_larm_collar,fqv[350],fqv[268],fqv[351]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4772rikiya_bvh_robot_model_larm_shoulder,fqv[352],fqv[268],fqv[353]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4775rikiya_bvh_robot_model_larm_elbow,fqv[354],fqv[268],fqv[355]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4778rikiya_bvh_robot_model_larm_wrist,fqv[356],fqv[268],fqv[357]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4781rikiya_bvh_robot_model_rarm_collar,fqv[358],fqv[268],fqv[359]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4784rikiya_bvh_robot_model_rarm_shoulder,fqv[360],fqv[268],fqv[361]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4787rikiya_bvh_robot_model_rarm_elbow,fqv[362],fqv[268],fqv[363]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4790rikiya_bvh_robot_model_rarm_wrist,fqv[364],fqv[268],fqv[365]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4793rikiya_bvh_robot_model_lleg_crotch,fqv[366],fqv[268],fqv[367]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4796rikiya_bvh_robot_model_lleg_knee,fqv[368],fqv[268],fqv[369]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4799rikiya_bvh_robot_model_lleg_ankle,fqv[370],fqv[268],fqv[371]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4802rikiya_bvh_robot_model_rleg_crotch,fqv[372],fqv[268],fqv[373]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4805rikiya_bvh_robot_model_rleg_knee,fqv[374],fqv[268],fqv[375]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4808rikiya_bvh_robot_model_rleg_ankle,fqv[376],fqv[268],fqv[377]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4811rikiya_bvh_robot_model_torso_chest,fqv[378],fqv[268],fqv[379]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4814rikiya_bvh_robot_model_head_neck,fqv[380],fqv[268],fqv[381]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4817rikiya_bvh_robot_model_copy_joint_to,fqv[205],fqv[268],fqv[382]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4827rikiya_bvh_robot_model_copy_state_to,fqv[157],fqv[268],fqv[383]);
	local[0]= fqv[270];
	local[1]= fqv[286];
	local[2]= fqv[270];
	local[3]= fqv[287];
	local[4]= loadglobal(fqv[140]);
	local[5]= fqv[288];
	local[6]= fqv[315];
	local[7]= fqv[290];
	local[8]= NIL;
	local[9]= fqv[291];
	local[10]= NIL;
	local[11]= fqv[292];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[293];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[34])(ctx,13,local+2,&ftab[34],fqv[294]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4853tum_bvh_robot_model_init,fqv[15],fqv[270],fqv[384]);
	local[0]= fqv[269];
	local[1]= fqv[286];
	local[2]= fqv[269];
	local[3]= fqv[287];
	local[4]= loadglobal(fqv[140]);
	local[5]= fqv[288];
	local[6]= fqv[315];
	local[7]= fqv[290];
	local[8]= NIL;
	local[9]= fqv[291];
	local[10]= NIL;
	local[11]= fqv[292];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[293];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[34])(ctx,13,local+2,&ftab[34],fqv[294]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtbvhM4882cmu_bvh_robot_model_init,fqv[15],fqv[269],fqv[385]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[163],module,irtbvhF4473load_mcd,fqv[386]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[387],module,irtbvhF4474rikiya_bvh2eus,fqv[388]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[389],module,irtbvhF4475cmu_bvh2eus,fqv[390]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[391],module,irtbvhF4476tum_bvh2eus,fqv[392]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[393],module,irtbvhF4477rikiya_file,fqv[394]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[395],module,irtbvhF4478tum_kitchen_file,fqv[396]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[397],module,irtbvhF4479cmu_mocap_file,fqv[398]);
	local[0]= fqv[399];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtbvhIF4932;
	local[0]= fqv[400];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[284],w);
	goto irtbvhIF4933;
irtbvhIF4932:
	local[0]= fqv[401];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtbvhIF4933:
	local[0]= fqv[402];
	local[1]= fqv[403];
	ctx->vsp=local+2;
	w=(*ftab[35])(ctx,2,local+0,&ftab[35],fqv[404]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<36; i++) ftab[i]=fcallx;
}
