/* ./irtdyna.c :  entry=irtdyna */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "irtdyna.h"
#pragma init (register_irtdyna)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___irtdyna();
extern pointer build_quote_vector();
static int register_irtdyna()
  { add_module_initializer("___irtdyna", ___irtdyna);}

static pointer irtdynaF2817calc_inertia_matrix_rotational();
static pointer irtdynaF2818calc_inertia_matrix_linear();

/*:calc-inertia-matrix*/
static pointer irtdynaM2819joint_calc_inertia_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtdynaRST2821:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= fqv[0];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,2,local+1,&ftab[0],fqv[1]); /*warn*/
	local[0]= w;
irtdynaBLK2820:
	ctx->vsp=local; return(local[0]);}

/*calc-inertia-matrix-rotational*/
static pointer irtdynaF2817calc_inertia_matrix_rotational(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=20) maerror();
	local[0]= argv[9];
	local[1]= fqv[2];
	local[2]= argv[3];
	local[3]= argv[15];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	local[1]= argv[15];
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,2,local+0,&ftab[1],fqv[3]); /*normalize-vector*/
	local[0]= w;
	local[1]= makeflt(1.0000000000000000208167e-03);
	local[2]= argv[4];
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	local[2]= makeflt(1.0000000000000000208167e-03);
	local[3]= argv[5];
	local[4]= argv[16];
	ctx->vsp=local+5;
	w=(pointer)SCALEVEC(ctx,3,local+2); /*scale*/
	local[2]= w;
	local[3]= makeflt(9.9999999999999985548644e-10);
	local[4]= argv[6];
	local[5]= argv[19];
	ctx->vsp=local+6;
	w=(*ftab[2])(ctx,3,local+3,&ftab[2],fqv[4]); /*scale-matrix*/
	local[3]= w;
	local[4]= local[1];
	local[5]= local[0];
	local[6]= local[2];
	local[7]= makeflt(1.0000000000000000208167e-03);
	local[8]= argv[8];
	local[9]= fqv[5];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= argv[17];
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,3,local+7); /*scale*/
	local[7]= w;
	local[8]= argv[17];
	ctx->vsp=local+9;
	w=(pointer)VMINUS(ctx,3,local+6); /*v-*/
	local[6]= w;
	local[7]= argv[18];
	ctx->vsp=local+8;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+5); /*v**/
	local[5]= w;
	local[6]= argv[17];
	ctx->vsp=local+7;
	w=(pointer)SCALEVEC(ctx,3,local+4); /*scale*/
	local[4]= w;
	local[5]= local[2];
	local[6]= local[4];
	local[7]= argv[18];
	ctx->vsp=local+8;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+5); /*v**/
	local[5]= w;
	local[6]= local[3];
	local[7]= local[0];
	local[8]= argv[16];
	ctx->vsp=local+9;
	w=(pointer)TRANSFORM(ctx,3,local+6); /*transform*/
	local[6]= w;
	local[7]= argv[16];
	ctx->vsp=local+8;
	w=(pointer)VPLUS(ctx,3,local+5); /*v+*/
	local[5]= w;
	local[6]= makeflt(1.0000000000000000208167e-03);
	local[7]= argv[7];
	local[8]= argv[15];
	ctx->vsp=local+9;
	w=(pointer)SCALEVEC(ctx,3,local+6); /*scale*/
	local[6]= w;
	local[7]= local[4];
	local[8]= argv[18];
	ctx->vsp=local+9;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+6); /*v**/
	local[6]= w;
	local[7]= argv[16];
	ctx->vsp=local+8;
	w=(pointer)VMINUS(ctx,3,local+5); /*v-*/
	local[5]= w;
	local[6]= local[4];
	local[7]= argv[10];
	local[8]= argv[12];
	local[9]= argv[13];
	local[10]= argv[14];
	ctx->vsp=local+11;
	w=(*ftab[3])(ctx,5,local+6,&ftab[3],fqv[6]); /*calc-dif-with-axis*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)LENGTH(ctx,1,local+8); /*length*/
	local[8]= w;
irtdynaWHL2823:
	local[9]= local[7];
	w = local[8];
	if ((eusinteger_t)local[9] >= (eusinteger_t)w) goto irtdynaWHX2824;
	local[9]= argv[0];
	local[10]= argv[1];
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[10]= w;
	local[11]= argv[2];
	local[12]= local[6];
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)ASET(ctx,4,local+9); /*aset*/
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[7] = w;
	goto irtdynaWHL2823;
irtdynaWHX2824:
	local[9]= NIL;
irtdynaBLK2825:
	w = NIL;
	local[7]= local[5];
	local[8]= argv[11];
	local[9]= argv[12];
	local[10]= argv[13];
	local[11]= argv[14];
	ctx->vsp=local+12;
	w=(*ftab[3])(ctx,5,local+7,&ftab[3],fqv[6]); /*calc-dif-with-axis*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
irtdynaWHL2826:
	local[10]= local[8];
	w = local[9];
	if ((eusinteger_t)local[10] >= (eusinteger_t)w) goto irtdynaWHX2827;
	local[10]= argv[0];
	local[11]= argv[1];
	local[12]= local[8];
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(pointer)LENGTH(ctx,1,local+13); /*length*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)PLUS(ctx,3,local+11); /*+*/
	local[11]= w;
	local[12]= argv[2];
	local[13]= local[7];
	local[14]= local[8];
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)ASET(ctx,4,local+10); /*aset*/
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	goto irtdynaWHL2826;
irtdynaWHX2827:
	local[10]= NIL;
irtdynaBLK2828:
	w = NIL;
	local[0]= w;
irtdynaBLK2822:
	ctx->vsp=local; return(local[0]);}

/*calc-inertia-matrix-linear*/
static pointer irtdynaF2818calc_inertia_matrix_linear(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=20) maerror();
	local[0]= argv[9];
	local[1]= fqv[2];
	local[2]= argv[3];
	local[3]= argv[15];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	local[1]= argv[15];
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,2,local+0,&ftab[1],fqv[3]); /*normalize-vector*/
	local[0]= w;
	local[1]= makeflt(1.0000000000000000208167e-03);
	local[2]= argv[4];
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	local[2]= makeflt(1.0000000000000000208167e-03);
	local[3]= argv[5];
	local[4]= argv[16];
	ctx->vsp=local+5;
	w=(pointer)SCALEVEC(ctx,3,local+2); /*scale*/
	local[2]= w;
	local[3]= makeflt(9.9999999999999985548644e-10);
	local[4]= argv[6];
	local[5]= argv[19];
	ctx->vsp=local+6;
	w=(*ftab[2])(ctx,3,local+3,&ftab[2],fqv[4]); /*scale-matrix*/
	local[3]= w;
	local[4]= local[1];
	local[5]= local[0];
	local[6]= argv[15];
	ctx->vsp=local+7;
	w=(pointer)SCALEVEC(ctx,3,local+4); /*scale*/
	local[4]= w;
	local[5]= local[2];
	local[6]= local[4];
	local[7]= argv[17];
	ctx->vsp=local+8;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+5); /*v**/
	local[5]= w;
	local[6]= makeflt(1.0000000000000000208167e-03);
	local[7]= argv[7];
	local[8]= argv[16];
	ctx->vsp=local+9;
	w=(pointer)SCALEVEC(ctx,3,local+6); /*scale*/
	local[6]= w;
	local[7]= local[4];
	local[8]= argv[18];
	ctx->vsp=local+9;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+6); /*v**/
	local[6]= w;
	local[7]= argv[16];
	ctx->vsp=local+8;
	w=(pointer)VMINUS(ctx,3,local+5); /*v-*/
	local[5]= w;
	local[6]= local[4];
	local[7]= argv[10];
	local[8]= argv[12];
	local[9]= argv[13];
	local[10]= argv[14];
	ctx->vsp=local+11;
	w=(*ftab[3])(ctx,5,local+6,&ftab[3],fqv[6]); /*calc-dif-with-axis*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)LENGTH(ctx,1,local+8); /*length*/
	local[8]= w;
irtdynaWHL2830:
	local[9]= local[7];
	w = local[8];
	if ((eusinteger_t)local[9] >= (eusinteger_t)w) goto irtdynaWHX2831;
	local[9]= argv[0];
	local[10]= argv[1];
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[10]= w;
	local[11]= argv[2];
	local[12]= local[6];
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)ASET(ctx,4,local+9); /*aset*/
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[7] = w;
	goto irtdynaWHL2830;
irtdynaWHX2831:
	local[9]= NIL;
irtdynaBLK2832:
	w = NIL;
	local[7]= local[5];
	local[8]= argv[11];
	local[9]= argv[12];
	local[10]= argv[13];
	local[11]= argv[14];
	ctx->vsp=local+12;
	w=(*ftab[3])(ctx,5,local+7,&ftab[3],fqv[6]); /*calc-dif-with-axis*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
irtdynaWHL2833:
	local[10]= local[8];
	w = local[9];
	if ((eusinteger_t)local[10] >= (eusinteger_t)w) goto irtdynaWHX2834;
	local[10]= argv[0];
	local[11]= argv[1];
	local[12]= local[8];
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(pointer)LENGTH(ctx,1,local+13); /*length*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)PLUS(ctx,3,local+11); /*+*/
	local[11]= w;
	local[12]= argv[2];
	local[13]= local[7];
	local[14]= local[8];
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)ASET(ctx,4,local+10); /*aset*/
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	goto irtdynaWHL2833;
irtdynaWHX2834:
	local[10]= NIL;
irtdynaBLK2835:
	w = NIL;
	local[0]= w;
irtdynaBLK2829:
	ctx->vsp=local; return(local[0]);}

/*:calc-inertia-matrix*/
static pointer irtdynaM2836rotational_joint_calc_inertia_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=21) maerror();
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[4];
	local[3]= argv[5];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[8];
	local[7]= argv[9];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[10];
	local[10]= argv[11];
	local[11]= argv[12];
	local[12]= argv[13];
	local[13]= argv[14];
	local[14]= argv[15];
	local[15]= argv[16];
	local[16]= argv[17];
	local[17]= argv[18];
	local[18]= argv[19];
	local[19]= argv[20];
	ctx->vsp=local+20;
	w=(pointer)irtdynaF2817calc_inertia_matrix_rotational(ctx,20,local+0); /*calc-inertia-matrix-rotational*/
	local[0]= w;
irtdynaBLK2837:
	ctx->vsp=local; return(local[0]);}

/*:calc-inertia-matrix*/
static pointer irtdynaM2838linear_joint_calc_inertia_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=21) maerror();
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[4];
	local[3]= argv[5];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[8];
	local[7]= argv[9];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[10];
	local[10]= argv[11];
	local[11]= argv[12];
	local[12]= argv[13];
	local[13]= argv[14];
	local[14]= argv[15];
	local[15]= argv[16];
	local[16]= argv[17];
	local[17]= argv[18];
	local[18]= argv[19];
	local[19]= argv[20];
	ctx->vsp=local+20;
	w=(pointer)irtdynaF2818calc_inertia_matrix_linear(ctx,20,local+0); /*calc-inertia-matrix-linear*/
	local[0]= w;
irtdynaBLK2839:
	ctx->vsp=local; return(local[0]);}

/*:calc-inertia-matrix*/
static pointer irtdynaM2840omniwheel_joint_calc_inertia_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=21) maerror();
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[4];
	local[3]= fqv[7];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[8];
	local[7]= argv[9];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[10];
	local[10]= argv[11];
	local[11]= argv[12];
	local[12]= argv[13];
	local[13]= argv[14];
	local[14]= argv[15];
	local[15]= argv[16];
	local[16]= argv[17];
	local[17]= argv[18];
	local[18]= argv[19];
	local[19]= argv[20];
	ctx->vsp=local+20;
	w=(pointer)irtdynaF2818calc_inertia_matrix_linear(ctx,20,local+0); /*calc-inertia-matrix-linear*/
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[4];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= fqv[8];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[8];
	local[7]= argv[9];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[10];
	local[10]= argv[11];
	local[11]= argv[12];
	local[12]= argv[13];
	local[13]= argv[14];
	local[14]= argv[15];
	local[15]= argv[16];
	local[16]= argv[17];
	local[17]= argv[18];
	local[18]= argv[19];
	local[19]= argv[20];
	ctx->vsp=local+20;
	w=(pointer)irtdynaF2818calc_inertia_matrix_linear(ctx,20,local+0); /*calc-inertia-matrix-linear*/
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[4];
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= fqv[9];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[8];
	local[7]= argv[9];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[10];
	local[10]= argv[11];
	local[11]= argv[12];
	local[12]= argv[13];
	local[13]= argv[14];
	local[14]= argv[15];
	local[15]= argv[16];
	local[16]= argv[17];
	local[17]= argv[18];
	local[18]= argv[19];
	local[19]= argv[20];
	ctx->vsp=local+20;
	w=(pointer)irtdynaF2817calc_inertia_matrix_rotational(ctx,20,local+0); /*calc-inertia-matrix-rotational*/
	local[0]= w;
irtdynaBLK2841:
	ctx->vsp=local; return(local[0]);}

/*:calc-inertia-matrix*/
static pointer irtdynaM2842sphere_joint_calc_inertia_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=21) maerror();
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[4];
	local[3]= fqv[10];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[8];
	local[7]= argv[9];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[10];
	local[10]= argv[11];
	local[11]= argv[12];
	local[12]= argv[13];
	local[13]= argv[14];
	local[14]= argv[15];
	local[15]= argv[16];
	local[16]= argv[17];
	local[17]= argv[18];
	local[18]= argv[19];
	local[19]= argv[20];
	ctx->vsp=local+20;
	w=(pointer)irtdynaF2817calc_inertia_matrix_rotational(ctx,20,local+0); /*calc-inertia-matrix-rotational*/
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[4];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= fqv[11];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[8];
	local[7]= argv[9];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[10];
	local[10]= argv[11];
	local[11]= argv[12];
	local[12]= argv[13];
	local[13]= argv[14];
	local[14]= argv[15];
	local[15]= argv[16];
	local[16]= argv[17];
	local[17]= argv[18];
	local[18]= argv[19];
	local[19]= argv[20];
	ctx->vsp=local+20;
	w=(pointer)irtdynaF2817calc_inertia_matrix_rotational(ctx,20,local+0); /*calc-inertia-matrix-rotational*/
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[4];
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= fqv[12];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[8];
	local[7]= argv[9];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[10];
	local[10]= argv[11];
	local[11]= argv[12];
	local[12]= argv[13];
	local[13]= argv[14];
	local[14]= argv[15];
	local[15]= argv[16];
	local[16]= argv[17];
	local[17]= argv[18];
	local[18]= argv[19];
	local[19]= argv[20];
	ctx->vsp=local+20;
	w=(pointer)irtdynaF2817calc_inertia_matrix_rotational(ctx,20,local+0); /*calc-inertia-matrix-rotational*/
	local[0]= w;
irtdynaBLK2843:
	ctx->vsp=local; return(local[0]);}

/*:calc-inertia-matrix*/
static pointer irtdynaM28446dof_joint_calc_inertia_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=21) maerror();
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[4];
	local[3]= fqv[13];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[8];
	local[7]= argv[9];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[10];
	local[10]= argv[11];
	local[11]= argv[12];
	local[12]= argv[13];
	local[13]= argv[14];
	local[14]= argv[15];
	local[15]= argv[16];
	local[16]= argv[17];
	local[17]= argv[18];
	local[18]= argv[19];
	local[19]= argv[20];
	ctx->vsp=local+20;
	w=(pointer)irtdynaF2818calc_inertia_matrix_linear(ctx,20,local+0); /*calc-inertia-matrix-linear*/
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[4];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= fqv[14];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[8];
	local[7]= argv[9];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[10];
	local[10]= argv[11];
	local[11]= argv[12];
	local[12]= argv[13];
	local[13]= argv[14];
	local[14]= argv[15];
	local[15]= argv[16];
	local[16]= argv[17];
	local[17]= argv[18];
	local[18]= argv[19];
	local[19]= argv[20];
	ctx->vsp=local+20;
	w=(pointer)irtdynaF2818calc_inertia_matrix_linear(ctx,20,local+0); /*calc-inertia-matrix-linear*/
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[4];
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= fqv[15];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[8];
	local[7]= argv[9];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[10];
	local[10]= argv[11];
	local[11]= argv[12];
	local[12]= argv[13];
	local[13]= argv[14];
	local[14]= argv[15];
	local[15]= argv[16];
	local[16]= argv[17];
	local[17]= argv[18];
	local[18]= argv[19];
	local[19]= argv[20];
	ctx->vsp=local+20;
	w=(pointer)irtdynaF2818calc_inertia_matrix_linear(ctx,20,local+0); /*calc-inertia-matrix-linear*/
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[4];
	local[3]= makeint((eusinteger_t)3L);
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= fqv[16];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[8];
	local[7]= argv[9];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[10];
	local[10]= argv[11];
	local[11]= argv[12];
	local[12]= argv[13];
	local[13]= argv[14];
	local[14]= argv[15];
	local[15]= argv[16];
	local[16]= argv[17];
	local[17]= argv[18];
	local[18]= argv[19];
	local[19]= argv[20];
	ctx->vsp=local+20;
	w=(pointer)irtdynaF2817calc_inertia_matrix_rotational(ctx,20,local+0); /*calc-inertia-matrix-rotational*/
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[4];
	local[3]= makeint((eusinteger_t)4L);
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= fqv[17];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[8];
	local[7]= argv[9];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[10];
	local[10]= argv[11];
	local[11]= argv[12];
	local[12]= argv[13];
	local[13]= argv[14];
	local[14]= argv[15];
	local[15]= argv[16];
	local[16]= argv[17];
	local[17]= argv[18];
	local[18]= argv[19];
	local[19]= argv[20];
	ctx->vsp=local+20;
	w=(pointer)irtdynaF2817calc_inertia_matrix_rotational(ctx,20,local+0); /*calc-inertia-matrix-rotational*/
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[4];
	local[3]= makeint((eusinteger_t)5L);
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= fqv[18];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[8];
	local[7]= argv[9];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[10];
	local[10]= argv[11];
	local[11]= argv[12];
	local[12]= argv[13];
	local[13]= argv[14];
	local[14]= argv[15];
	local[15]= argv[16];
	local[16]= argv[17];
	local[17]= argv[18];
	local[18]= argv[19];
	local[19]= argv[20];
	ctx->vsp=local+20;
	w=(pointer)irtdynaF2817calc_inertia_matrix_rotational(ctx,20,local+0); /*calc-inertia-matrix-rotational*/
	local[0]= w;
irtdynaBLK2845:
	ctx->vsp=local; return(local[0]);}

/*:append-weight-no-update*/
static pointer irtdynaM2846bodyset_link_append_weight_no_update(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[19], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY2848;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[0] = w;
irtdynaKEY2848:
	local[1]= argv[0];
	local[2]= fqv[20];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= local[0];
irtdynaWHL2849:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto irtdynaWHX2850;
	local[4]= argv[2];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[1] = w;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto irtdynaWHL2849;
irtdynaWHX2850:
	local[4]= NIL;
irtdynaBLK2851:
	w = NIL;
	w = local[1];
	local[0]= w;
irtdynaBLK2847:
	ctx->vsp=local; return(local[0]);}

/*:append-centroid-no-update*/
static pointer irtdynaM2852bodyset_link_append_centroid_no_update(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<6) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[21], &argv[6], n-6, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY2854;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[0] = w;
irtdynaKEY2854:
	if (n & (1<<1)) goto irtdynaKEY2855;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[1] = w;
irtdynaKEY2855:
	if (n & (1<<2)) goto irtdynaKEY2856;
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[2] = w;
irtdynaKEY2856:
	local[3]= argv[5];
	ctx->vsp=local+4;
	w=(pointer)EUSFLOAT(ctx,1,local+3); /*float*/
	local[3]= w;
	local[4]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(*ftab[4])(ctx,2,local+3,&ftab[4],fqv[22]); /*eps=*/
	if (w==NIL) goto irtdynaIF2857;
	local[3]= argv[4];
	goto irtdynaIF2858;
irtdynaIF2857:
	local[3]= makeflt(1.0000000000000000000000e+00);
	local[4]= argv[5];
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[20];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= argv[4];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)SCALEVEC(ctx,3,local+4); /*scale*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[2];
irtdynaWHL2859:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto irtdynaWHX2860;
	local[7]= local[4];
	local[8]= argv[2];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	local[9]= argv[3];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)SCALEVEC(ctx,3,local+8); /*scale*/
	local[8]= w;
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)VPLUS(ctx,3,local+7); /*v+*/
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto irtdynaWHL2859;
irtdynaWHX2860:
	local[7]= NIL;
irtdynaBLK2861:
	w = NIL;
	w = local[4];
	local[4]= w;
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SCALEVEC(ctx,3,local+3); /*scale*/
	local[3]= w;
irtdynaIF2858:
	w = local[3];
	local[0]= w;
irtdynaBLK2853:
	ctx->vsp=local; return(local[0]);}

/*:append-inertia-no-update*/
static pointer irtdynaM2862bodyset_link_append_inertia_no_update(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<7) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[23], &argv[7], n-7, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY2864;
	local[6]= makeint((eusinteger_t)3L);
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(*ftab[5])(ctx,2,local+6,&ftab[5],fqv[24]); /*make-matrix*/
	local[0] = w;
irtdynaKEY2864:
	if (n & (1<<1)) goto irtdynaKEY2865;
	local[6]= makeint((eusinteger_t)3L);
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(*ftab[5])(ctx,2,local+6,&ftab[5],fqv[24]); /*make-matrix*/
	local[1] = w;
irtdynaKEY2865:
	if (n & (1<<2)) goto irtdynaKEY2866;
	local[6]= makeint((eusinteger_t)3L);
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(*ftab[5])(ctx,2,local+6,&ftab[5],fqv[24]); /*make-matrix*/
	local[2] = w;
irtdynaKEY2866:
	if (n & (1<<3)) goto irtdynaKEY2867;
	local[6]= makeint((eusinteger_t)3L);
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(*ftab[5])(ctx,2,local+6,&ftab[5],fqv[24]); /*make-matrix*/
	local[3] = w;
irtdynaKEY2867:
	if (n & (1<<4)) goto irtdynaKEY2868;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,3,local+6); /*float-vector*/
	local[4] = w;
irtdynaKEY2868:
	if (n & (1<<5)) goto irtdynaKEY2869;
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[5] = w;
irtdynaKEY2869:
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtdynaFLET2870,env,argv,local);
	local[7]= argv[0];
	local[8]= fqv[25];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= fqv[26];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)MATTIMES(ctx,3,local+7); /*m**/
	local[7]= w;
	local[8]= argv[0];
	local[9]= fqv[25];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)TRANSPOSE(ctx,2,local+8); /*transpose*/
	local[8]= w;
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)MATTIMES(ctx,3,local+7); /*m**/
	local[7]= w;
	local[8]= argv[0];
	local[9]= fqv[20];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= argv[5];
	local[10]= argv[6];
	local[11]= local[4];
	ctx->vsp=local+12;
	w=(pointer)VMINUS(ctx,3,local+9); /*v-*/
	local[9]= w;
	w = local[6];
	ctx->vsp=local+10;
	w=irtdynaFLET2870(ctx,1,local+9,w);
	local[9]= w;
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(*ftab[2])(ctx,3,local+8,&ftab[2],fqv[4]); /*scale-matrix*/
	local[8]= w;
	local[9]= local[7];
	local[10]= local[7];
	ctx->vsp=local+11;
	w=(*ftab[6])(ctx,3,local+8,&ftab[6],fqv[27]); /*m+*/
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[5];
irtdynaWHL2871:
	local[10]= local[8];
	w = local[9];
	if ((eusinteger_t)local[10] >= (eusinteger_t)w) goto irtdynaWHX2872;
	local[10]= argv[4];
	local[11]= local[8];
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	local[11]= local[7];
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(*ftab[6])(ctx,3,local+10,&ftab[6],fqv[27]); /*m+*/
	local[10]= argv[2];
	local[11]= local[8];
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	local[11]= argv[3];
	local[12]= local[8];
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= argv[6];
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(pointer)VMINUS(ctx,3,local+11); /*v-*/
	local[11]= w;
	w = local[6];
	ctx->vsp=local+12;
	w=irtdynaFLET2870(ctx,1,local+11,w);
	local[11]= w;
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(*ftab[2])(ctx,3,local+10,&ftab[2],fqv[4]); /*scale-matrix*/
	local[10]= w;
	local[11]= local[7];
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(*ftab[6])(ctx,3,local+10,&ftab[6],fqv[27]); /*m+*/
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	goto irtdynaWHL2871;
irtdynaWHX2872:
	local[10]= NIL;
irtdynaBLK2873:
	w = NIL;
	w = local[7];
	local[0]= w;
irtdynaBLK2863:
	ctx->vsp=local; return(local[0]);}

/*:append-mass-properties*/
static pointer irtdynaM2874bodyset_link_append_mass_properties(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[28], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY2876;
	local[0] = T;
irtdynaKEY2876:
	if (n & (1<<1)) goto irtdynaKEY2877;
	local[11]= makeint((eusinteger_t)0L);
	local[12]= makeint((eusinteger_t)0L);
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)MKFLTVEC(ctx,3,local+11); /*float-vector*/
	local[1] = w;
irtdynaKEY2877:
	if (n & (1<<2)) goto irtdynaKEY2878;
	local[11]= makeint((eusinteger_t)0L);
	local[12]= makeint((eusinteger_t)0L);
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)MKFLTVEC(ctx,3,local+11); /*float-vector*/
	local[2] = w;
irtdynaKEY2878:
	if (n & (1<<3)) goto irtdynaKEY2879;
	local[11]= makeint((eusinteger_t)3L);
	local[12]= makeint((eusinteger_t)3L);
	ctx->vsp=local+13;
	w=(*ftab[5])(ctx,2,local+11,&ftab[5],fqv[24]); /*make-matrix*/
	local[3] = w;
irtdynaKEY2879:
	if (n & (1<<4)) goto irtdynaKEY2880;
	local[11]= makeint((eusinteger_t)3L);
	local[12]= makeint((eusinteger_t)3L);
	ctx->vsp=local+13;
	w=(*ftab[5])(ctx,2,local+11,&ftab[5],fqv[24]); /*make-matrix*/
	local[4] = w;
irtdynaKEY2880:
	if (n & (1<<5)) goto irtdynaKEY2881;
	local[11]= makeint((eusinteger_t)3L);
	local[12]= makeint((eusinteger_t)3L);
	ctx->vsp=local+13;
	w=(*ftab[5])(ctx,2,local+11,&ftab[5],fqv[24]); /*make-matrix*/
	local[5] = w;
irtdynaKEY2881:
	if (n & (1<<6)) goto irtdynaKEY2882;
	local[11]= makeint((eusinteger_t)3L);
	local[12]= makeint((eusinteger_t)3L);
	ctx->vsp=local+13;
	w=(*ftab[5])(ctx,2,local+11,&ftab[5],fqv[24]); /*make-matrix*/
	local[6] = w;
irtdynaKEY2882:
	if (n & (1<<7)) goto irtdynaKEY2883;
	local[11]= argv[2];
	local[12]= fqv[20];
	ctx->vsp=local+13;
	w=(*ftab[7])(ctx,2,local+11,&ftab[7],fqv[29]); /*send-all*/
	local[7] = w;
irtdynaKEY2883:
	if (n & (1<<8)) goto irtdynaKEY2884;
	local[11]= argv[2];
	local[12]= fqv[30];
	ctx->vsp=local+13;
	w=(*ftab[7])(ctx,2,local+11,&ftab[7],fqv[29]); /*send-all*/
	local[8] = w;
irtdynaKEY2884:
	if (n & (1<<9)) goto irtdynaKEY2885;
	ctx->vsp=local+11;
	local[11]= makeclosure(codevec,quotevec,irtdynaCLO2886,env,argv,local);
	local[12]= argv[2];
	ctx->vsp=local+13;
	w=(pointer)MAPCAR(ctx,2,local+11); /*mapcar*/
	local[9] = w;
irtdynaKEY2885:
	if (n & (1<<10)) goto irtdynaKEY2887;
	local[11]= argv[0];
	local[12]= fqv[30];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[10] = w;
irtdynaKEY2887:
	local[11]= argv[2];
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
	local[12]= argv[0];
	local[13]= fqv[31];
	local[14]= local[7];
	local[15]= fqv[32];
	local[16]= local[11];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,5,local+12); /*send*/
	local[12]= w;
	local[13]= argv[0];
	local[14]= fqv[33];
	local[15]= local[7];
	local[16]= local[8];
	local[17]= local[10];
	local[18]= local[12];
	local[19]= fqv[34];
	local[20]= local[1];
	local[21]= fqv[35];
	local[22]= local[2];
	local[23]= fqv[32];
	local[24]= local[11];
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,12,local+13); /*send*/
	local[13]= w;
	local[14]= argv[0];
	local[15]= fqv[36];
	local[16]= local[7];
	local[17]= local[8];
	local[18]= local[9];
	local[19]= local[10];
	local[20]= local[13];
	local[21]= fqv[37];
	local[22]= local[3];
	local[23]= fqv[38];
	local[24]= local[4];
	local[25]= fqv[39];
	local[26]= local[5];
	local[27]= fqv[40];
	local[28]= local[6];
	local[29]= fqv[34];
	local[30]= local[1];
	local[31]= fqv[32];
	local[32]= local[11];
	ctx->vsp=local+33;
	w=(pointer)SEND(ctx,19,local+14); /*send*/
	local[14]= w;
	if (local[0]==NIL) goto irtdynaIF2888;
	local[15]= argv[0];
	local[16]= fqv[20];
	local[17]= local[12];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[15]= argv[0];
	local[16]= fqv[41];
	local[17]= local[13];
	local[18]= argv[0]->c.obj.iv[15];
	local[19]= local[1];
	local[20]= local[3];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,6,local+15); /*send*/
	argv[0]->c.obj.iv[15] = w;
	local[15]= argv[0];
	local[16]= fqv[26];
	local[17]= argv[0];
	local[18]= fqv[25];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,2,local+17); /*send*/
	local[17]= w;
	local[18]= local[3];
	ctx->vsp=local+19;
	w=(pointer)TRANSPOSE(ctx,2,local+17); /*transpose*/
	local[17]= w;
	local[18]= local[14];
	local[19]= local[4];
	ctx->vsp=local+20;
	w=(pointer)MATTIMES(ctx,3,local+17); /*m**/
	local[17]= w;
	local[18]= argv[0];
	local[19]= fqv[25];
	ctx->vsp=local+20;
	w=(pointer)SEND(ctx,2,local+18); /*send*/
	local[18]= w;
	local[19]= argv[0];
	local[20]= fqv[26];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,2,local+19); /*send*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)MATTIMES(ctx,3,local+17); /*m**/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[15]= w;
	goto irtdynaIF2889;
irtdynaIF2888:
	local[15]= NIL;
irtdynaIF2889:
	local[15]= local[12];
	local[16]= local[13];
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)LIST(ctx,3,local+15); /*list*/
	local[0]= w;
irtdynaBLK2875:
	ctx->vsp=local; return(local[0]);}

/*:propagate-mass-properties*/
static pointer irtdynaM2890bodyset_link_propagate_mass_properties(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[42], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY2892;
	local[0] = NIL;
irtdynaKEY2892:
	if (n & (1<<1)) goto irtdynaKEY2893;
	local[6]= loadglobal(fqv[43]);
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,2,local+6); /*instantiate*/
	local[1] = w;
irtdynaKEY2893:
	if (n & (1<<2)) goto irtdynaKEY2894;
	local[6]= loadglobal(fqv[43]);
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,2,local+6); /*instantiate*/
	local[2] = w;
irtdynaKEY2894:
	if (n & (1<<3)) goto irtdynaKEY2895;
	local[6]= makeint((eusinteger_t)3L);
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(*ftab[5])(ctx,2,local+6,&ftab[5],fqv[24]); /*make-matrix*/
	local[3] = w;
irtdynaKEY2895:
	if (n & (1<<4)) goto irtdynaKEY2896;
	local[6]= makeint((eusinteger_t)3L);
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(*ftab[5])(ctx,2,local+6,&ftab[5],fqv[24]); /*make-matrix*/
	local[4] = w;
irtdynaKEY2896:
	if (n & (1<<5)) goto irtdynaKEY2897;
	local[6]= makeint((eusinteger_t)3L);
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(*ftab[5])(ctx,2,local+6,&ftab[5],fqv[24]); /*make-matrix*/
	local[5] = w;
irtdynaKEY2897:
	if (argv[0]->c.obj.iv[11]==NIL) goto irtdynaIF2898;
	local[6]= NIL;
	local[7]= argv[0]->c.obj.iv[11];
irtdynaWHL2900:
	if (local[7]==NIL) goto irtdynaWHX2901;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= local[6];
	local[9]= fqv[44];
	local[10]= fqv[45];
	local[11]= local[0];
	local[12]= fqv[34];
	local[13]= local[1];
	local[14]= fqv[35];
	local[15]= local[2];
	local[16]= fqv[37];
	local[17]= local[3];
	local[18]= fqv[38];
	local[19]= local[4];
	local[20]= fqv[39];
	local[21]= local[5];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,14,local+8); /*send*/
	goto irtdynaWHL2900;
irtdynaWHX2901:
	local[8]= NIL;
irtdynaBLK2902:
	w = NIL;
	local[6]= argv[0];
	local[7]= fqv[46];
	local[8]= fqv[47];
	local[9]= argv[0];
	local[10]= fqv[48];
	local[11]= argv[0]->c.obj.iv[11];
	local[12]= fqv[37];
	local[13]= local[3];
	local[14]= fqv[38];
	local[15]= local[4];
	local[16]= fqv[39];
	local[17]= local[5];
	local[18]= fqv[40];
	local[19]= argv[0];
	local[20]= fqv[49];
	local[21]= fqv[50];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,3,local+19); /*send*/
	local[19]= w;
	local[20]= fqv[34];
	local[21]= local[1];
	local[22]= fqv[35];
	local[23]= argv[0];
	local[24]= fqv[49];
	local[25]= fqv[51];
	ctx->vsp=local+26;
	w=(pointer)SEND(ctx,3,local+23); /*send*/
	local[23]= w;
	local[24]= fqv[52];
	local[25]= argv[0]->c.obj.iv[11];
	local[26]= fqv[49];
	local[27]= fqv[47];
	ctx->vsp=local+28;
	w=(*ftab[7])(ctx,3,local+25,&ftab[7],fqv[29]); /*send-all*/
	local[25]= w;
	local[26]= fqv[53];
	local[27]= argv[0]->c.obj.iv[11];
	local[28]= fqv[49];
	local[29]= fqv[51];
	ctx->vsp=local+30;
	w=(*ftab[7])(ctx,3,local+27,&ftab[7],fqv[29]); /*send-all*/
	local[27]= w;
	local[28]= fqv[54];
	local[29]= argv[0]->c.obj.iv[11];
	local[30]= fqv[49];
	local[31]= fqv[50];
	ctx->vsp=local+32;
	w=(*ftab[7])(ctx,3,local+29,&ftab[7],fqv[29]); /*send-all*/
	local[29]= w;
	local[30]= fqv[55];
	local[31]= argv[0];
	local[32]= fqv[30];
	ctx->vsp=local+33;
	w=(pointer)SEND(ctx,2,local+31); /*send*/
	local[31]= w;
	local[32]= fqv[56];
	local[33]= NIL;
	ctx->vsp=local+34;
	w=(pointer)SEND(ctx,25,local+9); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= w;
	goto irtdynaIF2899;
irtdynaIF2898:
	local[6]= argv[0];
	local[7]= fqv[30];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)3L);
irtdynaWHL2903:
	local[9]= local[7];
	w = local[8];
	if ((eusinteger_t)local[9] >= (eusinteger_t)w) goto irtdynaWHX2904;
	local[9]= argv[0];
	local[10]= fqv[49];
	local[11]= fqv[51];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	local[10]= local[7];
	local[11]= local[6];
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SETELT(ctx,3,local+9); /*setelt*/
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[7] = w;
	goto irtdynaWHL2903;
irtdynaWHX2904:
	local[9]= NIL;
irtdynaBLK2905:
	w = NIL;
	local[7]= argv[0];
	local[8]= fqv[46];
	local[9]= fqv[47];
	local[10]= argv[0];
	local[11]= fqv[20];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[7]= argv[0];
	local[8]= fqv[25];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= fqv[26];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)MATTIMES(ctx,3,local+7); /*m**/
	local[7]= w;
	local[8]= argv[0];
	local[9]= fqv[25];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)TRANSPOSE(ctx,2,local+8); /*transpose*/
	local[8]= w;
	local[9]= argv[0];
	local[10]= fqv[49];
	local[11]= fqv[50];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MATTIMES(ctx,3,local+7); /*m**/
	local[6]= w;
irtdynaIF2899:
	if (local[0]==NIL) goto irtdynaIF2906;
	local[6]= fqv[57];
	local[7]= argv[0];
	local[8]= fqv[58];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= fqv[49];
	local[10]= fqv[47];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	local[9]= argv[0];
	local[10]= fqv[49];
	local[11]= fqv[51];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[0])(ctx,4,local+6,&ftab[0],fqv[1]); /*warn*/
	local[6]= w;
	goto irtdynaIF2907;
irtdynaIF2906:
	local[6]= NIL;
irtdynaIF2907:
	w = T;
	local[0]= w;
irtdynaBLK2891:
	ctx->vsp=local; return(local[0]);}

/*:calc-inertia-matrix-column*/
static pointer irtdynaM2908bodyset_link_calc_inertia_matrix_column(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtdynaRST2910:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[59], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtdynaKEY2911;
	local[1] = NIL;
irtdynaKEY2911:
	if (n & (1<<1)) goto irtdynaKEY2912;
	local[2] = T;
irtdynaKEY2912:
	if (n & (1<<2)) goto irtdynaKEY2913;
	local[3] = NIL;
irtdynaKEY2913:
	if (n & (1<<3)) goto irtdynaKEY2914;
	local[13]= makeint((eusinteger_t)0L);
	local[14]= makeint((eusinteger_t)0L);
	local[15]= makeint((eusinteger_t)0L);
	ctx->vsp=local+16;
	w=(pointer)MKFLTVEC(ctx,3,local+13); /*float-vector*/
	local[4] = w;
irtdynaKEY2914:
	if (n & (1<<4)) goto irtdynaKEY2915;
	local[13]= loadglobal(fqv[43]);
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(pointer)INSTANTIATE(ctx,2,local+13); /*instantiate*/
	local[5] = w;
irtdynaKEY2915:
	if (n & (1<<5)) goto irtdynaKEY2916;
	local[13]= loadglobal(fqv[43]);
	local[14]= makeint((eusinteger_t)1L);
	ctx->vsp=local+15;
	w=(pointer)INSTANTIATE(ctx,2,local+13); /*instantiate*/
	local[6] = w;
irtdynaKEY2916:
	if (n & (1<<6)) goto irtdynaKEY2917;
	local[13]= loadglobal(fqv[43]);
	local[14]= makeint((eusinteger_t)2L);
	ctx->vsp=local+15;
	w=(pointer)INSTANTIATE(ctx,2,local+13); /*instantiate*/
	local[7] = w;
irtdynaKEY2917:
	if (n & (1<<7)) goto irtdynaKEY2918;
	local[13]= loadglobal(fqv[43]);
	local[14]= makeint((eusinteger_t)3L);
	ctx->vsp=local+15;
	w=(pointer)INSTANTIATE(ctx,2,local+13); /*instantiate*/
	local[8] = w;
irtdynaKEY2918:
	if (n & (1<<8)) goto irtdynaKEY2919;
	local[13]= loadglobal(fqv[43]);
	local[14]= makeint((eusinteger_t)3L);
	ctx->vsp=local+15;
	w=(pointer)INSTANTIATE(ctx,2,local+13); /*instantiate*/
	local[9] = w;
irtdynaKEY2919:
	if (n & (1<<9)) goto irtdynaKEY2920;
	local[13]= loadglobal(fqv[43]);
	local[14]= makeint((eusinteger_t)3L);
	ctx->vsp=local+15;
	w=(pointer)INSTANTIATE(ctx,2,local+13); /*instantiate*/
	local[10] = w;
irtdynaKEY2920:
	if (n & (1<<10)) goto irtdynaKEY2921;
	local[13]= loadglobal(fqv[43]);
	local[14]= makeint((eusinteger_t)3L);
	ctx->vsp=local+15;
	w=(pointer)INSTANTIATE(ctx,2,local+13); /*instantiate*/
	local[11] = w;
irtdynaKEY2921:
	if (n & (1<<11)) goto irtdynaKEY2922;
	local[13]= makeint((eusinteger_t)3L);
	local[14]= makeint((eusinteger_t)3L);
	ctx->vsp=local+15;
	w=(*ftab[5])(ctx,2,local+13,&ftab[5],fqv[24]); /*make-matrix*/
	local[12] = w;
irtdynaKEY2922:
	local[13]= *(ovafptr(argv[0]->c.obj.iv[9],fqv[60]));
	local[14]= local[13];
	if (fqv[61]!=local[14]) goto irtdynaIF2923;
	local[14]= makeint((eusinteger_t)1L);
	local[15]= makeint((eusinteger_t)0L);
	local[16]= makeint((eusinteger_t)0L);
	ctx->vsp=local+17;
	w=(pointer)MKFLTVEC(ctx,3,local+14); /*float-vector*/
	local[14]= w;
	goto irtdynaIF2924;
irtdynaIF2923:
	local[14]= local[13];
	if (fqv[62]!=local[14]) goto irtdynaIF2925;
	local[14]= makeint((eusinteger_t)-1L);
	local[15]= makeint((eusinteger_t)0L);
	local[16]= makeint((eusinteger_t)0L);
	ctx->vsp=local+17;
	w=(pointer)MKFLTVEC(ctx,3,local+14); /*float-vector*/
	local[14]= w;
	goto irtdynaIF2926;
irtdynaIF2925:
	local[14]= local[13];
	if (fqv[63]!=local[14]) goto irtdynaIF2927;
	local[14]= makeint((eusinteger_t)0L);
	local[15]= makeint((eusinteger_t)1L);
	local[16]= makeint((eusinteger_t)0L);
	ctx->vsp=local+17;
	w=(pointer)MKFLTVEC(ctx,3,local+14); /*float-vector*/
	local[14]= w;
	goto irtdynaIF2928;
irtdynaIF2927:
	local[14]= local[13];
	if (fqv[64]!=local[14]) goto irtdynaIF2929;
	local[14]= makeint((eusinteger_t)0L);
	local[15]= makeint((eusinteger_t)-1L);
	local[16]= makeint((eusinteger_t)0L);
	ctx->vsp=local+17;
	w=(pointer)MKFLTVEC(ctx,3,local+14); /*float-vector*/
	local[14]= w;
	goto irtdynaIF2930;
irtdynaIF2929:
	local[14]= local[13];
	if (fqv[65]!=local[14]) goto irtdynaIF2931;
	local[14]= makeint((eusinteger_t)0L);
	local[15]= makeint((eusinteger_t)0L);
	local[16]= makeint((eusinteger_t)1L);
	ctx->vsp=local+17;
	w=(pointer)MKFLTVEC(ctx,3,local+14); /*float-vector*/
	local[14]= w;
	goto irtdynaIF2932;
irtdynaIF2931:
	local[14]= local[13];
	if (fqv[66]!=local[14]) goto irtdynaIF2933;
	local[14]= makeint((eusinteger_t)0L);
	local[15]= makeint((eusinteger_t)0L);
	local[16]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+17;
	w=(pointer)MKFLTVEC(ctx,3,local+14); /*float-vector*/
	local[14]= w;
	goto irtdynaIF2934;
irtdynaIF2933:
	if (T==NIL) goto irtdynaIF2935;
	local[14]= *(ovafptr(argv[0]->c.obj.iv[9],fqv[60]));
	goto irtdynaIF2936;
irtdynaIF2935:
	local[14]= NIL;
irtdynaIF2936:
irtdynaIF2934:
irtdynaIF2932:
irtdynaIF2930:
irtdynaIF2928:
irtdynaIF2926:
irtdynaIF2924:
	w = local[14];
	local[13]= w;
	local[14]= makeint((eusinteger_t)0L);
	local[15]= argv[0]->c.obj.iv[9];
	local[16]= fqv[67];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	local[16]= fqv[68];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	local[16]= fqv[69];
	local[17]= *(ovafptr(argv[0]->c.obj.iv[9],fqv[70]));
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[15]= w;
	local[16]= argv[0]->c.obj.iv[9];
	local[17]= fqv[71];
	local[18]= local[3];
	local[19]= local[14];
	local[20]= argv[2];
	local[21]= local[13];
	local[22]= argv[0];
	local[23]= fqv[49];
	local[24]= fqv[47];
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,3,local+22); /*send*/
	local[22]= w;
	local[23]= argv[0];
	local[24]= fqv[49];
	local[25]= fqv[51];
	ctx->vsp=local+26;
	w=(pointer)SEND(ctx,3,local+23); /*send*/
	local[23]= w;
	local[24]= argv[0];
	local[25]= fqv[49];
	local[26]= fqv[50];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,3,local+24); /*send*/
	local[24]= w;
	local[25]= local[4];
	local[26]= local[15];
	local[27]= local[2];
	local[28]= local[1];
	local[29]= local[5];
	local[30]= local[6];
	local[31]= local[7];
	local[32]= local[8];
	local[33]= local[9];
	local[34]= local[10];
	local[35]= local[11];
	local[36]= local[12];
	ctx->vsp=local+37;
	w=(pointer)SEND(ctx,21,local+16); /*send*/
	w = T;
	local[0]= w;
irtdynaBLK2909:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaFLET2870(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env2[0];
	ctx->vsp=local+2;
	w=(*ftab[8])(ctx,2,local+0,&ftab[8],fqv[72]); /*outer-product-matrix*/
	local[0]= w;
	local[1]= local[0];
	local[2]= env->c.clo.env2[1];
	ctx->vsp=local+3;
	w=(pointer)TRANSPOSE(ctx,2,local+1); /*transpose*/
	local[1]= w;
	local[2]= local[0];
	local[3]= env->c.clo.env2[2];
	ctx->vsp=local+4;
	w=(pointer)MATTIMES(ctx,3,local+1); /*m**/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO2886(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[25];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[26];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= env->c.clo.env2[3];
	ctx->vsp=local+3;
	w=(pointer)MATTIMES(ctx,3,local+0); /*m**/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[25];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= env->c.clo.env2[4];
	ctx->vsp=local+3;
	w=(pointer)TRANSPOSE(ctx,2,local+1); /*transpose*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MATTIMES(ctx,2,local+0); /*m**/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:update-mass-properties*/
static pointer irtdynaM2937cascaded_link_update_mass_properties(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[73], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY2939;
	local[5]= loadglobal(fqv[43]);
	local[6]= makeint((eusinteger_t)3L);
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,2,local+5); /*instantiate*/
	local[0] = w;
irtdynaKEY2939:
	if (n & (1<<1)) goto irtdynaKEY2940;
	local[5]= loadglobal(fqv[43]);
	local[6]= makeint((eusinteger_t)3L);
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,2,local+5); /*instantiate*/
	local[1] = w;
irtdynaKEY2940:
	if (n & (1<<2)) goto irtdynaKEY2941;
	local[5]= makeint((eusinteger_t)3L);
	local[6]= makeint((eusinteger_t)3L);
	ctx->vsp=local+7;
	w=(*ftab[5])(ctx,2,local+5,&ftab[5],fqv[24]); /*make-matrix*/
	local[2] = w;
irtdynaKEY2941:
	if (n & (1<<3)) goto irtdynaKEY2942;
	local[5]= makeint((eusinteger_t)3L);
	local[6]= makeint((eusinteger_t)3L);
	ctx->vsp=local+7;
	w=(*ftab[5])(ctx,2,local+5,&ftab[5],fqv[24]); /*make-matrix*/
	local[3] = w;
irtdynaKEY2942:
	if (n & (1<<4)) goto irtdynaKEY2943;
	local[5]= makeint((eusinteger_t)3L);
	local[6]= makeint((eusinteger_t)3L);
	ctx->vsp=local+7;
	w=(*ftab[5])(ctx,2,local+5,&ftab[5],fqv[24]); /*make-matrix*/
	local[4] = w;
irtdynaKEY2943:
	local[5]= argv[0];
	local[6]= fqv[74];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtdynaCLO2944,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[9])(ctx,2,local+5,&ftab[9],fqv[75]); /*all-child-links*/
	local[5]= argv[0];
	local[6]= fqv[74];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= fqv[44];
	local[7]= fqv[34];
	local[8]= local[0];
	local[9]= fqv[35];
	local[10]= local[1];
	local[11]= fqv[37];
	local[12]= local[2];
	local[13]= fqv[38];
	local[14]= local[3];
	local[15]= fqv[39];
	local[16]= local[4];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,12,local+5); /*send*/
	local[0]= w;
irtdynaBLK2938:
	ctx->vsp=local; return(local[0]);}

/*:calc-inertia-matrix-from-link-list*/
static pointer irtdynaM2945cascaded_link_calc_inertia_matrix_from_link_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtdynaRST2947:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[76], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtdynaKEY2948;
	local[18]= argv[0]->c.obj.iv[9];
	local[19]= fqv[77];
	ctx->vsp=local+20;
	w=(*ftab[7])(ctx,2,local+18,&ftab[7],fqv[29]); /*send-all*/
	local[1] = w;
irtdynaKEY2948:
	if (n & (1<<1)) goto irtdynaKEY2949;
	local[2] = NIL;
irtdynaKEY2949:
	if (n & (1<<2)) goto irtdynaKEY2950;
	local[3] = T;
irtdynaKEY2950:
	if (n & (1<<3)) goto irtdynaKEY2951;
	local[18]= argv[0];
	local[19]= fqv[78];
	local[20]= local[2];
	local[21]= local[3];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,4,local+18); /*send*/
	local[4] = w;
irtdynaKEY2951:
	if (n & (1<<4)) goto irtdynaKEY2952;
	local[18]= local[4];
	local[19]= argv[0];
	local[20]= fqv[79];
	local[21]= local[1];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,3,local+19); /*send*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(*ftab[5])(ctx,2,local+18,&ftab[5],fqv[24]); /*make-matrix*/
	local[5] = w;
irtdynaKEY2952:
	if (n & (1<<5)) goto irtdynaKEY2953;
	local[6] = T;
irtdynaKEY2953:
	if (n & (1<<6)) goto irtdynaKEY2954;
	local[7] = NIL;
irtdynaKEY2954:
	if (n & (1<<7)) goto irtdynaKEY2955;
	local[18]= loadglobal(fqv[43]);
	local[19]= makeint((eusinteger_t)0L);
	ctx->vsp=local+20;
	w=(pointer)INSTANTIATE(ctx,2,local+18); /*instantiate*/
	local[8] = w;
irtdynaKEY2955:
	if (n & (1<<8)) goto irtdynaKEY2956;
	local[18]= loadglobal(fqv[43]);
	local[19]= makeint((eusinteger_t)1L);
	ctx->vsp=local+20;
	w=(pointer)INSTANTIATE(ctx,2,local+18); /*instantiate*/
	local[9] = w;
irtdynaKEY2956:
	if (n & (1<<9)) goto irtdynaKEY2957;
	local[18]= loadglobal(fqv[43]);
	local[19]= makeint((eusinteger_t)2L);
	ctx->vsp=local+20;
	w=(pointer)INSTANTIATE(ctx,2,local+18); /*instantiate*/
	local[10] = w;
irtdynaKEY2957:
	if (n & (1<<10)) goto irtdynaKEY2958;
	local[18]= loadglobal(fqv[43]);
	local[19]= makeint((eusinteger_t)3L);
	ctx->vsp=local+20;
	w=(pointer)INSTANTIATE(ctx,2,local+18); /*instantiate*/
	local[11] = w;
irtdynaKEY2958:
	if (n & (1<<11)) goto irtdynaKEY2959;
	local[18]= loadglobal(fqv[43]);
	local[19]= makeint((eusinteger_t)3L);
	ctx->vsp=local+20;
	w=(pointer)INSTANTIATE(ctx,2,local+18); /*instantiate*/
	local[12] = w;
irtdynaKEY2959:
	if (n & (1<<12)) goto irtdynaKEY2960;
	local[18]= loadglobal(fqv[43]);
	local[19]= makeint((eusinteger_t)3L);
	ctx->vsp=local+20;
	w=(pointer)INSTANTIATE(ctx,2,local+18); /*instantiate*/
	local[13] = w;
irtdynaKEY2960:
	if (n & (1<<13)) goto irtdynaKEY2961;
	local[18]= loadglobal(fqv[43]);
	local[19]= makeint((eusinteger_t)3L);
	ctx->vsp=local+20;
	w=(pointer)INSTANTIATE(ctx,2,local+18); /*instantiate*/
	local[14] = w;
irtdynaKEY2961:
	if (n & (1<<14)) goto irtdynaKEY2962;
	local[18]= makeint((eusinteger_t)3L);
	local[19]= makeint((eusinteger_t)3L);
	ctx->vsp=local+20;
	w=(*ftab[5])(ctx,2,local+18,&ftab[5],fqv[24]); /*make-matrix*/
	local[15] = w;
irtdynaKEY2962:
	if (n & (1<<15)) goto irtdynaKEY2963;
	local[18]= makeint((eusinteger_t)3L);
	local[19]= makeint((eusinteger_t)3L);
	ctx->vsp=local+20;
	w=(*ftab[5])(ctx,2,local+18,&ftab[5],fqv[24]); /*make-matrix*/
	local[16] = w;
irtdynaKEY2963:
	if (n & (1<<16)) goto irtdynaKEY2964;
	local[18]= makeint((eusinteger_t)3L);
	local[19]= makeint((eusinteger_t)3L);
	ctx->vsp=local+20;
	w=(*ftab[5])(ctx,2,local+18,&ftab[5],fqv[24]); /*make-matrix*/
	local[17] = w;
irtdynaKEY2964:
	if (local[6]==NIL) goto irtdynaIF2965;
	local[18]= argv[0];
	local[19]= fqv[80];
	local[20]= fqv[34];
	local[21]= local[11];
	local[22]= fqv[35];
	local[23]= local[12];
	local[24]= fqv[37];
	local[25]= local[15];
	local[26]= fqv[38];
	local[27]= local[16];
	local[28]= fqv[39];
	local[29]= local[17];
	ctx->vsp=local+30;
	w=(pointer)SEND(ctx,12,local+18); /*send*/
	local[18]= w;
	goto irtdynaIF2966;
irtdynaIF2965:
	local[18]= NIL;
irtdynaIF2966:
	local[18]= NIL;
	local[19]= makeint((eusinteger_t)0L);
	local[20]= makeint((eusinteger_t)0L);
irtdynaTAG2968:
	local[21]= local[20];
	local[22]= local[1];
	ctx->vsp=local+23;
	w=(pointer)LENGTH(ctx,1,local+22); /*length*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)GREQP(ctx,2,local+21); /*>=*/
	if (w==NIL) goto irtdynaIF2969;
	w = NIL;
	ctx->vsp=local+21;
	local[19]=w;
	goto irtdynaBLK2967;
	goto irtdynaIF2970;
irtdynaIF2969:
	local[21]= NIL;
irtdynaIF2970:
	local[21]= local[1];
	local[22]= local[20];
	ctx->vsp=local+23;
	w=(pointer)ELT(ctx,2,local+21); /*elt*/
	local[21]= w;
	local[22]= fqv[81];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,2,local+21); /*send*/
	local[18] = w;
	local[21]= (pointer)get_sym_func(fqv[82]);
	local[22]= local[1];
	local[23]= local[20];
	ctx->vsp=local+24;
	w=(pointer)ELT(ctx,2,local+22); /*elt*/
	local[22]= w;
	local[23]= fqv[83];
	local[24]= local[19];
	local[25]= fqv[84];
	local[26]= local[5];
	local[27]= fqv[85];
	if (local[7]==NIL) goto irtdynaIF2971;
	local[28]= local[7];
	goto irtdynaIF2972;
irtdynaIF2971:
	local[28]= argv[0];
	local[29]= fqv[30];
	local[30]= NIL;
	ctx->vsp=local+31;
	w=(pointer)SEND(ctx,3,local+28); /*send*/
	local[28]= w;
irtdynaIF2972:
	local[29]= fqv[86];
	local[30]= local[3];
	local[31]= fqv[87];
	local[32]= local[2];
	local[33]= local[0];
	ctx->vsp=local+34;
	w=(pointer)APPLY(ctx,13,local+21); /*apply*/
	local[21]= local[19];
	local[22]= local[18];
	local[23]= fqv[88];
	ctx->vsp=local+24;
	w=(pointer)SEND(ctx,2,local+22); /*send*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)PLUS(ctx,2,local+21); /*+*/
	local[21]= w;
	local[22]= local[20];
	local[23]= makeint((eusinteger_t)1L);
	ctx->vsp=local+24;
	w=(pointer)PLUS(ctx,2,local+22); /*+*/
	local[22]= w;
	local[19] = local[21];
	local[20] = local[22];
	w = NIL;
	ctx->vsp=local+21;
	goto irtdynaTAG2968;
	w = NIL;
	local[19]= w;
irtdynaBLK2967:
	w = local[19];
	w = local[5];
	local[0]= w;
irtdynaBLK2946:
	ctx->vsp=local; return(local[0]);}

/*:calc-cog-jacobian-from-link-list*/
static pointer irtdynaM2973cascaded_link_calc_cog_jacobian_from_link_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtdynaRST2975:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[89], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtdynaKEY2976;
	local[7]= argv[0]->c.obj.iv[9];
	local[8]= fqv[77];
	ctx->vsp=local+9;
	w=(*ftab[7])(ctx,2,local+7,&ftab[7],fqv[29]); /*send-all*/
	local[1] = w;
irtdynaKEY2976:
	if (n & (1<<1)) goto irtdynaKEY2977;
	local[2] = NIL;
irtdynaKEY2977:
	if (n & (1<<2)) goto irtdynaKEY2978;
	local[3] = T;
irtdynaKEY2978:
	if (n & (1<<3)) goto irtdynaKEY2979;
	local[7]= argv[0];
	local[8]= fqv[78];
	local[9]= local[2];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[4] = w;
irtdynaKEY2979:
	if (n & (1<<4)) goto irtdynaKEY2980;
	local[7]= local[4];
	local[8]= argv[0];
	local[9]= fqv[79];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[5])(ctx,2,local+7,&ftab[5],fqv[24]); /*make-matrix*/
	local[5] = w;
irtdynaKEY2980:
	if (n & (1<<5)) goto irtdynaKEY2981;
	local[6] = T;
irtdynaKEY2981:
	local[7]= makeflt(1.0000000000000000208167e-03);
	local[8]= argv[0];
	local[9]= fqv[20];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	local[8]= (pointer)get_sym_func(fqv[82]);
	local[9]= argv[0];
	local[10]= fqv[90];
	local[11]= fqv[80];
	local[12]= NIL;
	local[13]= fqv[84];
	local[14]= local[5];
	local[15]= fqv[91];
	local[16]= local[1];
	local[17]= local[0];
	ctx->vsp=local+18;
	w=(pointer)APPLY(ctx,10,local+8); /*apply*/
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[4];
irtdynaWHL2982:
	local[10]= local[8];
	w = local[9];
	if ((eusinteger_t)local[10] >= (eusinteger_t)w) goto irtdynaWHX2983;
	local[10]= makeint((eusinteger_t)0L);
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(*ftab[10])(ctx,1,local+11,&ftab[10],fqv[92]); /*array-dimensions*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
irtdynaWHL2985:
	local[12]= local[10];
	w = local[11];
	if ((eusinteger_t)local[12] >= (eusinteger_t)w) goto irtdynaWHX2986;
	local[12]= local[5];
	local[13]= local[8];
	local[14]= local[10];
	local[15]= local[5];
	local[16]= local[8];
	local[17]= local[10];
	ctx->vsp=local+18;
	w=(pointer)AREF(ctx,3,local+15); /*aref*/
	local[15]= w;
	local[16]= local[7];
	ctx->vsp=local+17;
	w=(pointer)QUOTIENT(ctx,2,local+15); /*/*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)ASET(ctx,4,local+12); /*aset*/
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)ADD1(ctx,1,local+12); /*1+*/
	local[10] = w;
	goto irtdynaWHL2985;
irtdynaWHX2986:
	local[12]= NIL;
irtdynaBLK2987:
	w = NIL;
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	goto irtdynaWHL2982;
irtdynaWHX2983:
	local[10]= NIL;
irtdynaBLK2984:
	w = NIL;
	w = local[5];
	local[0]= w;
irtdynaBLK2974:
	ctx->vsp=local; return(local[0]);}

/*:cog-jacobian-balance-nspace*/
static pointer irtdynaM2988cascaded_link_cog_jacobian_balance_nspace(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtdynaRST2990:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[93], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtdynaKEY2991;
	local[1] = makeflt(1.0000000000000000000000e+00);
irtdynaKEY2991:
	if (n & (1<<1)) goto irtdynaKEY2992;
	local[2] = fqv[65];
irtdynaKEY2992:
	if (n & (1<<2)) goto irtdynaKEY2993;
	local[3] = NIL;
irtdynaKEY2993:
	if (n & (1<<3)) goto irtdynaKEY2994;
	local[4] = NIL;
irtdynaKEY2994:
	if (n & (1<<4)) goto irtdynaKEY2995;
	local[5] = T;
irtdynaKEY2995:
	local[6]= (pointer)get_sym_func(fqv[82]);
	local[7]= argv[0];
	local[8]= fqv[94];
	local[9]= (pointer)get_sym_func(fqv[82]);
	local[10]= argv[0];
	local[11]= fqv[95];
	local[12]= fqv[80];
	local[13]= local[5];
	local[14]= fqv[91];
	local[15]= argv[2];
	local[16]= fqv[86];
	local[17]= local[2];
	local[18]= local[0];
	ctx->vsp=local+19;
	w=(pointer)APPLY(ctx,10,local+9); /*apply*/
	local[9]= w;
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)APPLY(ctx,5,local+6); /*apply*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= fqv[96];
	local[9]= local[1];
	local[10]= local[2];
	local[11]= local[3];
	local[12]= fqv[97];
	local[13]= local[4];
	local[14]= fqv[80];
	local[15]= NIL;
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,9,local+7); /*send*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= fqv[49];
	local[10]= fqv[98];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	if (w==NIL) goto irtdynaIF2996;
	local[8]= fqv[30];
	local[9]= argv[0];
	local[10]= fqv[49];
	local[11]= fqv[98];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[11])(ctx,2,local+8,&ftab[11],fqv[99]); /*assoc*/
	local[8]= w;
	local[9]= local[7];
	local[10]= fqv[30];
	local[11]= argv[0];
	local[12]= fqv[49];
	local[13]= fqv[98];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[11])(ctx,2,local+10,&ftab[11],fqv[99]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)RPLACD2(ctx,2,local+8); /*rplacd2*/
	local[8]= w;
	goto irtdynaIF2997;
irtdynaIF2996:
	local[8]= NIL;
irtdynaIF2997:
	w = local[7];
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)TRANSFORM(ctx,2,local+6); /*transform*/
	local[0]= w;
irtdynaBLK2989:
	ctx->vsp=local; return(local[0]);}

/*:calc-vel-for-cog*/
static pointer irtdynaM2998cascaded_link_calc_vel_for_cog(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[100], &argv[5], n-5, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3000;
	local[0] = NIL;
irtdynaKEY3000:
	if (n & (1<<1)) goto irtdynaKEY3001;
	local[1] = T;
irtdynaKEY3001:
	local[2]= makeflt(1.0000000000000000208167e-03);
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[101];
	local[5]= argv[4];
	local[6]= fqv[97];
	local[7]= local[0];
	local[8]= fqv[86];
	local[9]= argv[3];
	local[10]= fqv[102];
	local[11]= T;
	local[12]= fqv[80];
	local[13]= local[1];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,11,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SCALEVEC(ctx,2,local+2); /*scale*/
	local[0]= w;
irtdynaBLK2999:
	ctx->vsp=local; return(local[0]);}

/*:difference-cog-position*/
static pointer irtdynaM3002cascaded_link_difference_cog_position(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[103], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3004;
	local[0] = NIL;
irtdynaKEY3004:
	if (n & (1<<1)) goto irtdynaKEY3005;
	local[1] = fqv[65];
irtdynaKEY3005:
	if (n & (1<<2)) goto irtdynaKEY3006;
	local[2] = NIL;
irtdynaKEY3006:
	if (n & (1<<3)) goto irtdynaKEY3007;
	local[3] = T;
irtdynaKEY3007:
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[12])(ctx,1,local+4,&ftab[12],fqv[104]); /*functionp*/
	if (w==NIL) goto irtdynaIF3008;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)FUNCALL(ctx,1,local+4); /*funcall*/
	local[4]= w;
	goto irtdynaIF3009;
irtdynaIF3008:
	local[4]= argv[0];
	local[5]= fqv[30];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
irtdynaIF3009:
	if (local[2]==NIL) goto irtdynaIF3010;
	local[5]= argv[0];
	local[6]= fqv[46];
	local[7]= fqv[105];
	local[8]= argv[0];
	local[9]= fqv[49];
	local[10]= fqv[105];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	local[9]= argv[2];
	local[10]= fqv[106];
	local[11]= fqv[107];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,3,local+9); /*list*/
	local[9]= w;
	local[10]= local[4];
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	local[11]= local[4];
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= argv[2];
	local[13]= makeint((eusinteger_t)2L);
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)MKFLTVEC(ctx,3,local+10); /*float-vector*/
	local[10]= w;
	local[11]= fqv[108];
	local[12]= makeint((eusinteger_t)100L);
	local[13]= fqv[106];
	local[14]= fqv[109];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,5,local+10); /*list*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,2,local+9); /*list*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)APPEND(ctx,2,local+8); /*append*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= w;
	goto irtdynaIF3011;
irtdynaIF3010:
	local[5]= NIL;
irtdynaIF3011:
	local[5]= argv[2];
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)VMINUS(ctx,2,local+5); /*v-*/
	local[5]= w;
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(*ftab[3])(ctx,2,local+5,&ftab[3],fqv[6]); /*calc-dif-with-axis*/
	local[0]= w;
irtdynaBLK3003:
	ctx->vsp=local; return(local[0]);}

/*:cog-convergence-check*/
static pointer irtdynaM3012cascaded_link_cog_convergence_check(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[110], &argv[4], n-4, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3014;
	local[0] = NIL;
irtdynaKEY3014:
	if (n & (1<<1)) goto irtdynaKEY3015;
	local[1] = fqv[65];
irtdynaKEY3015:
	if (n & (1<<2)) goto irtdynaKEY3016;
	local[2] = T;
irtdynaKEY3016:
	local[3]= argv[0];
	local[4]= fqv[101];
	local[5]= argv[3];
	local[6]= fqv[97];
	local[7]= local[0];
	local[8]= fqv[86];
	local[9]= local[1];
	local[10]= fqv[80];
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,9,local+3); /*send*/
	local[3]= w;
	w = argv[2];
	if (!isnum(w)) goto irtdynaCON3018;
	local[4]= argv[2];
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)VNORM(ctx,1,local+5); /*norm*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)GREATERP(ctx,2,local+4); /*>*/
	local[4]= w;
	goto irtdynaCON3017;
irtdynaCON3018:
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(*ftab[12])(ctx,1,local+4,&ftab[12],fqv[104]); /*functionp*/
	if (w==NIL) goto irtdynaCON3019;
	local[4]= argv[2];
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)FUNCALL(ctx,2,local+4); /*funcall*/
	local[4]= w;
	goto irtdynaCON3017;
irtdynaCON3019:
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)VECTORP(ctx,1,local+4); /*vectorp*/
	if (w==NIL) goto irtdynaCON3020;
	local[4]= loadglobal(fqv[43]);
	local[5]= (pointer)get_sym_func(fqv[111]);
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)MAP(ctx,3,local+4); /*map*/
	local[4]= w;
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)VLESSP(ctx,2,local+4); /*v<*/
	local[4]= w;
	goto irtdynaCON3017;
irtdynaCON3020:
	local[4]= NIL;
irtdynaCON3017:
	w = local[4];
	local[0]= w;
irtdynaBLK3013:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO2944(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[46];
	local[2]= fqv[47];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)3L);
irtdynaWHL3021:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto irtdynaWHX3022;
	local[2]= argv[0];
	local[3]= fqv[49];
	local[4]= fqv[51];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= local[0];
	local[4]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(pointer)SETELT(ctx,3,local+2); /*setelt*/
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto irtdynaWHL3021;
irtdynaWHX3022:
	local[2]= NIL;
irtdynaBLK3023:
	w = NIL;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)3L);
irtdynaWHL3024:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto irtdynaWHX3025;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)3L);
irtdynaWHL3027:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto irtdynaWHX3028;
	local[4]= argv[0];
	local[5]= fqv[49];
	local[6]= fqv[50];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= local[2];
	local[6]= local[0];
	local[7]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+8;
	w=(pointer)ASET(ctx,4,local+4); /*aset*/
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto irtdynaWHL3027;
irtdynaWHX3028:
	local[4]= NIL;
irtdynaBLK3029:
	w = NIL;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto irtdynaWHL3024;
irtdynaWHX3025:
	local[2]= NIL;
irtdynaBLK3026:
	w = NIL;
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:calc-spacial-velocity-jacobian*/
static pointer irtdynaM3030joint_calc_spacial_velocity_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtdynaRST3032:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= fqv[112];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,2,local+1,&ftab[0],fqv[1]); /*warn*/
	local[0]= w;
irtdynaBLK3031:
	ctx->vsp=local; return(local[0]);}

/*:calc-angular-velocity-jacobian*/
static pointer irtdynaM3033joint_calc_angular_velocity_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtdynaRST3035:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= fqv[113];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,2,local+1,&ftab[0],fqv[1]); /*warn*/
	local[0]= w;
irtdynaBLK3034:
	ctx->vsp=local; return(local[0]);}

/*:calc-spacial-acceleration-jacobian*/
static pointer irtdynaM3036joint_calc_spacial_acceleration_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtdynaRST3038:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= fqv[114];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,2,local+1,&ftab[0],fqv[1]); /*warn*/
	local[0]= w;
irtdynaBLK3037:
	ctx->vsp=local; return(local[0]);}

/*:calc-angular-acceleration-jacobian*/
static pointer irtdynaM3039joint_calc_angular_acceleration_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtdynaRST3041:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= fqv[115];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,2,local+1,&ftab[0],fqv[1]); /*warn*/
	local[0]= w;
irtdynaBLK3040:
	ctx->vsp=local; return(local[0]);}

/*:calc-spacial-velocity-jacobian*/
static pointer irtdynaM3042rotational_joint_calc_spacial_velocity_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= makeflt(1.0000000000000000208167e-03);
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= fqv[5];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)SCALEVEC(ctx,3,local+0); /*scale*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= argv[4];
	ctx->vsp=local+3;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+0); /*v**/
	local[0]= w;
irtdynaBLK3043:
	ctx->vsp=local; return(local[0]);}

/*:calc-angular-velocity-jacobian*/
static pointer irtdynaM3044rotational_joint_calc_angular_velocity_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)3L);
irtdynaWHL3046:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto irtdynaWHX3047;
	local[2]= argv[3];
	local[3]= local[0];
	local[4]= argv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SETELT(ctx,3,local+2); /*setelt*/
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto irtdynaWHL3046;
irtdynaWHX3047:
	local[2]= NIL;
irtdynaBLK3048:
	w = NIL;
	w = argv[3];
	local[0]= w;
irtdynaBLK3045:
	ctx->vsp=local; return(local[0]);}

/*:calc-spacial-acceleration-jacobian*/
static pointer irtdynaM3049rotational_joint_calc_spacial_acceleration_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=6) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= fqv[116];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= argv[4];
	ctx->vsp=local+3;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+0); /*v**/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= fqv[117];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[3];
	local[3]= argv[5];
	ctx->vsp=local+4;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+1); /*v**/
	local[1]= w;
	local[2]= argv[5];
	ctx->vsp=local+3;
	w=(pointer)VPLUS(ctx,3,local+0); /*v+*/
	local[0]= w;
irtdynaBLK3050:
	ctx->vsp=local; return(local[0]);}

/*:calc-angular-acceleration-jacobian*/
static pointer irtdynaM3051rotational_joint_calc_angular_acceleration_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= fqv[116];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+0); /*v**/
	local[0]= w;
irtdynaBLK3052:
	ctx->vsp=local; return(local[0]);}

/*:calc-spacial-velocity-jacobian*/
static pointer irtdynaM3053linear_joint_calc_spacial_velocity_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)3L);
irtdynaWHL3055:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto irtdynaWHX3056;
	local[2]= argv[4];
	local[3]= local[0];
	local[4]= argv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SETELT(ctx,3,local+2); /*setelt*/
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto irtdynaWHL3055;
irtdynaWHX3056:
	local[2]= NIL;
irtdynaBLK3057:
	w = NIL;
	w = argv[4];
	local[0]= w;
irtdynaBLK3054:
	ctx->vsp=local; return(local[0]);}

/*:calc-angular-velocity-jacobian*/
static pointer irtdynaM3058linear_joint_calc_angular_velocity_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)3L);
irtdynaWHL3060:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto irtdynaWHX3061;
	local[2]= argv[3];
	local[3]= local[0];
	local[4]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(pointer)SETELT(ctx,3,local+2); /*setelt*/
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto irtdynaWHL3060;
irtdynaWHX3061:
	local[2]= NIL;
irtdynaBLK3062:
	w = NIL;
	w = argv[3];
	local[0]= w;
irtdynaBLK3059:
	ctx->vsp=local; return(local[0]);}

/*:calc-spacial-acceleration-jacobian*/
static pointer irtdynaM3063linear_joint_calc_spacial_acceleration_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=6) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= fqv[116];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= argv[5];
	ctx->vsp=local+3;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+0); /*v**/
	local[0]= w;
irtdynaBLK3064:
	ctx->vsp=local; return(local[0]);}

/*:calc-angular-acceleration-jacobian*/
static pointer irtdynaM3065linear_joint_calc_angular_acceleration_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)3L);
irtdynaWHL3067:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto irtdynaWHX3068;
	local[2]= argv[3];
	local[3]= local[0];
	local[4]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(pointer)SETELT(ctx,3,local+2); /*setelt*/
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto irtdynaWHL3067;
irtdynaWHX3068:
	local[2]= NIL;
irtdynaBLK3069:
	w = NIL;
	w = argv[3];
	local[0]= w;
irtdynaBLK3066:
	ctx->vsp=local; return(local[0]);}

/*:reset-dynamics*/
static pointer irtdynaM3070bodyset_link_reset_dynamics(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[46];
	local[2]= fqv[47];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[46];
	local[2]= fqv[51];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[46];
	local[2]= fqv[50];
	local[3]= makeint((eusinteger_t)3L);
	local[4]= makeint((eusinteger_t)3L);
	ctx->vsp=local+5;
	w=(*ftab[5])(ctx,2,local+3,&ftab[5],fqv[24]); /*make-matrix*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	argv[0]->c.obj.iv[17] = w;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	argv[0]->c.obj.iv[18] = w;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	argv[0]->c.obj.iv[19] = w;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	argv[0]->c.obj.iv[20] = w;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	argv[0]->c.obj.iv[24] = w;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	argv[0]->c.obj.iv[23] = w;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	argv[0]->c.obj.iv[22] = w;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	argv[0]->c.obj.iv[21] = w;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	argv[0]->c.obj.iv[25] = w;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	argv[0]->c.obj.iv[26] = w;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	argv[0]->c.obj.iv[27] = w;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	argv[0]->c.obj.iv[28] = w;
	w = argv[0]->c.obj.iv[28];
	local[0]= w;
irtdynaBLK3071:
	ctx->vsp=local; return(local[0]);}

/*:angular-velocity*/
static pointer irtdynaM3072bodyset_link_angular_velocity(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtdynaENT3075;}
	local[0]= NIL;
irtdynaENT3075:
irtdynaENT3074:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtdynaIF3076;
	argv[0]->c.obj.iv[17] = local[0];
	local[1]= argv[0]->c.obj.iv[17];
	goto irtdynaIF3077;
irtdynaIF3076:
	local[1]= argv[0]->c.obj.iv[17];
irtdynaIF3077:
	w = local[1];
	local[0]= w;
irtdynaBLK3073:
	ctx->vsp=local; return(local[0]);}

/*:angular-acceleration*/
static pointer irtdynaM3078bodyset_link_angular_acceleration(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtdynaENT3081;}
	local[0]= NIL;
irtdynaENT3081:
irtdynaENT3080:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtdynaIF3082;
	argv[0]->c.obj.iv[18] = local[0];
	local[1]= argv[0]->c.obj.iv[18];
	goto irtdynaIF3083;
irtdynaIF3082:
	local[1]= argv[0]->c.obj.iv[18];
irtdynaIF3083:
	w = local[1];
	local[0]= w;
irtdynaBLK3079:
	ctx->vsp=local; return(local[0]);}

/*:spacial-velocity*/
static pointer irtdynaM3084bodyset_link_spacial_velocity(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtdynaENT3087;}
	local[0]= NIL;
irtdynaENT3087:
irtdynaENT3086:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtdynaIF3088;
	argv[0]->c.obj.iv[19] = local[0];
	local[1]= argv[0]->c.obj.iv[19];
	goto irtdynaIF3089;
irtdynaIF3088:
	local[1]= argv[0]->c.obj.iv[19];
irtdynaIF3089:
	w = local[1];
	local[0]= w;
irtdynaBLK3085:
	ctx->vsp=local; return(local[0]);}

/*:spacial-acceleration*/
static pointer irtdynaM3090bodyset_link_spacial_acceleration(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtdynaENT3093;}
	local[0]= NIL;
irtdynaENT3093:
irtdynaENT3092:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtdynaIF3094;
	argv[0]->c.obj.iv[20] = local[0];
	local[1]= argv[0]->c.obj.iv[20];
	goto irtdynaIF3095;
irtdynaIF3094:
	local[1]= argv[0]->c.obj.iv[20];
irtdynaIF3095:
	w = local[1];
	local[0]= w;
irtdynaBLK3091:
	ctx->vsp=local; return(local[0]);}

/*:force*/
static pointer irtdynaM3096bodyset_link_force(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[25];
	local[0]= w;
irtdynaBLK3097:
	ctx->vsp=local; return(local[0]);}

/*:moment*/
static pointer irtdynaM3098bodyset_link_moment(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[26];
	local[0]= w;
irtdynaBLK3099:
	ctx->vsp=local; return(local[0]);}

/*:ext-force*/
static pointer irtdynaM3100bodyset_link_ext_force(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtdynaENT3103;}
	local[0]= NIL;
irtdynaENT3103:
irtdynaENT3102:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtdynaIF3104;
	argv[0]->c.obj.iv[27] = local[0];
	local[1]= argv[0]->c.obj.iv[27];
	goto irtdynaIF3105;
irtdynaIF3104:
	local[1]= argv[0]->c.obj.iv[27];
irtdynaIF3105:
	w = local[1];
	local[0]= w;
irtdynaBLK3101:
	ctx->vsp=local; return(local[0]);}

/*:ext-moment*/
static pointer irtdynaM3106bodyset_link_ext_moment(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtdynaENT3109;}
	local[0]= NIL;
irtdynaENT3109:
irtdynaENT3108:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtdynaIF3110;
	argv[0]->c.obj.iv[28] = local[0];
	local[1]= argv[0]->c.obj.iv[28];
	goto irtdynaIF3111;
irtdynaIF3110:
	local[1]= argv[0]->c.obj.iv[28];
irtdynaIF3111:
	w = local[1];
	local[0]= w;
irtdynaBLK3107:
	ctx->vsp=local; return(local[0]);}

/*:forward-all-kinematics*/
static pointer irtdynaM3112bodyset_link_forward_all_kinematics(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[118], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3114;
	local[0] = NIL;
irtdynaKEY3114:
	if (n & (1<<1)) goto irtdynaKEY3115;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[1] = w;
irtdynaKEY3115:
	if (local[0]==NIL) goto irtdynaIF3116;
	local[2]= T;
	local[3]= fqv[119];
	local[4]= argv[0];
	local[5]= fqv[58];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	goto irtdynaIF3117;
irtdynaIF3116:
	local[2]= NIL;
irtdynaIF3117:
	if (argv[0]->c.obj.iv[10]==NIL) goto irtdynaIF3118;
	local[2]= argv[0];
	local[3]= fqv[120];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= loadglobal(fqv[121]);
	ctx->vsp=local+4;
	w=(pointer)DERIVEDP(ctx,2,local+2); /*derivedp*/
	if (w==NIL) goto irtdynaIF3118;
	local[2]= *(ovafptr(argv[0]->c.obj.iv[9],fqv[60]));
	local[3]= local[2];
	if (fqv[61]!=local[3]) goto irtdynaIF3120;
	local[3]= fqv[122];
	goto irtdynaIF3121;
irtdynaIF3120:
	local[3]= local[2];
	if (fqv[63]!=local[3]) goto irtdynaIF3122;
	local[3]= fqv[123];
	goto irtdynaIF3123;
irtdynaIF3122:
	local[3]= local[2];
	if (fqv[65]!=local[3]) goto irtdynaIF3124;
	local[3]= fqv[124];
	goto irtdynaIF3125;
irtdynaIF3124:
	local[3]= local[2];
	if (fqv[125]!=local[3]) goto irtdynaIF3126;
	local[3]= fqv[126];
	goto irtdynaIF3127;
irtdynaIF3126:
	local[3]= local[2];
	if (fqv[127]!=local[3]) goto irtdynaIF3128;
	local[3]= fqv[128];
	goto irtdynaIF3129;
irtdynaIF3128:
	local[3]= local[2];
	if (fqv[129]!=local[3]) goto irtdynaIF3130;
	local[3]= fqv[130];
	goto irtdynaIF3131;
irtdynaIF3130:
	local[3]= local[2];
	if (fqv[62]!=local[3]) goto irtdynaIF3132;
	local[3]= fqv[131];
	goto irtdynaIF3133;
irtdynaIF3132:
	local[3]= local[2];
	if (fqv[64]!=local[3]) goto irtdynaIF3134;
	local[3]= fqv[132];
	goto irtdynaIF3135;
irtdynaIF3134:
	local[3]= local[2];
	if (fqv[66]!=local[3]) goto irtdynaIF3136;
	local[3]= fqv[133];
	goto irtdynaIF3137;
irtdynaIF3136:
	if (T==NIL) goto irtdynaIF3138;
	local[3]= *(ovafptr(argv[0]->c.obj.iv[9],fqv[60]));
	goto irtdynaIF3139;
irtdynaIF3138:
	local[3]= NIL;
irtdynaIF3139:
irtdynaIF3137:
irtdynaIF3135:
irtdynaIF3133:
irtdynaIF3131:
irtdynaIF3129:
irtdynaIF3127:
irtdynaIF3125:
irtdynaIF3123:
irtdynaIF3121:
	w = local[3];
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[10];
	local[4]= fqv[68];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= fqv[69];
	local[5]= *(ovafptr(argv[0]->c.obj.iv[9],fqv[70]));
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	local[4]= fqv[2];
	local[5]= local[2];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[49];
	local[6]= fqv[134];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,2,local+3,&ftab[1],fqv[3]); /*normalize-vector*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[9];
	local[5]= fqv[135];
	local[6]= local[3];
	local[7]= local[1];
	local[8]= argv[0];
	local[9]= fqv[49];
	local[10]= fqv[136];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[9];
	local[6]= fqv[137];
	local[7]= local[3];
	local[8]= argv[0];
	local[9]= fqv[49];
	local[10]= fqv[134];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= w;
	local[6]= argv[0]->c.obj.iv[10];
	local[7]= fqv[116];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[9];
	local[8]= fqv[138];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= local[5];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,3,local+7); /*scale*/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[17];
	ctx->vsp=local+9;
	w=(pointer)VPLUS(ctx,3,local+6); /*v+*/
	argv[0]->c.obj.iv[17] = w;
	local[6]= argv[0]->c.obj.iv[10];
	local[7]= fqv[117];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[9];
	local[8]= fqv[138];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= local[4];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,3,local+7); /*scale*/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[19];
	ctx->vsp=local+9;
	w=(pointer)VPLUS(ctx,3,local+6); /*v+*/
	argv[0]->c.obj.iv[19] = w;
	local[6]= argv[0]->c.obj.iv[9];
	local[7]= fqv[139];
	local[8]= local[4];
	local[9]= local[5];
	local[10]= local[1];
	local[11]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,6,local+6); /*send*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[10];
	local[8]= fqv[140];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[9];
	local[9]= fqv[138];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[6];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)SCALEVEC(ctx,3,local+8); /*scale*/
	local[8]= w;
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)VPLUS(ctx,3,local+7); /*v+*/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[9];
	local[9]= fqv[141];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[4];
	local[10]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+11;
	w=(pointer)SCALEVEC(ctx,3,local+8); /*scale*/
	local[8]= w;
	local[9]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+10;
	w=(pointer)VPLUS(ctx,3,local+7); /*v+*/
	argv[0]->c.obj.iv[20] = w;
	w = argv[0]->c.obj.iv[20];
	local[6]= argv[0]->c.obj.iv[9];
	local[7]= fqv[142];
	local[8]= local[5];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[10];
	local[8]= fqv[143];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[9];
	local[9]= fqv[138];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[6];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)SCALEVEC(ctx,3,local+8); /*scale*/
	local[8]= w;
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)VPLUS(ctx,3,local+7); /*v+*/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[9];
	local[9]= fqv[141];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[5];
	local[10]= argv[0]->c.obj.iv[18];
	ctx->vsp=local+11;
	w=(pointer)SCALEVEC(ctx,3,local+8); /*scale*/
	local[8]= w;
	local[9]= argv[0]->c.obj.iv[18];
	ctx->vsp=local+10;
	w=(pointer)VPLUS(ctx,3,local+7); /*v+*/
	argv[0]->c.obj.iv[18] = w;
	w = argv[0]->c.obj.iv[18];
	local[2]= w;
	goto irtdynaIF3119;
irtdynaIF3118:
	local[2]= NIL;
irtdynaIF3119:
	local[2]= argv[0]->c.obj.iv[11];
	local[3]= fqv[144];
	local[4]= fqv[45];
	local[5]= local[0];
	local[6]= fqv[34];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(*ftab[7])(ctx,6,local+2,&ftab[7],fqv[29]); /*send-all*/
	local[0]= w;
irtdynaBLK3113:
	ctx->vsp=local; return(local[0]);}

/*:inverse-dynamics*/
static pointer irtdynaM3140bodyset_link_inverse_dynamics(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[145], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3142;
	local[0] = NIL;
irtdynaKEY3142:
	if (n & (1<<1)) goto irtdynaKEY3143;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[1] = w;
irtdynaKEY3143:
	if (n & (1<<2)) goto irtdynaKEY3144;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[2] = w;
irtdynaKEY3144:
	if (n & (1<<3)) goto irtdynaKEY3145;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[3] = w;
irtdynaKEY3145:
	if (n & (1<<4)) goto irtdynaKEY3146;
	local[8]= makeint((eusinteger_t)3L);
	local[9]= makeint((eusinteger_t)3L);
	ctx->vsp=local+10;
	w=(*ftab[5])(ctx,2,local+8,&ftab[5],fqv[24]); /*make-matrix*/
	local[4] = w;
irtdynaKEY3146:
	if (n & (1<<5)) goto irtdynaKEY3147;
	local[8]= makeint((eusinteger_t)3L);
	local[9]= makeint((eusinteger_t)3L);
	ctx->vsp=local+10;
	w=(*ftab[5])(ctx,2,local+8,&ftab[5],fqv[24]); /*make-matrix*/
	local[5] = w;
irtdynaKEY3147:
	if (n & (1<<6)) goto irtdynaKEY3148;
	local[8]= makeint((eusinteger_t)3L);
	local[9]= makeint((eusinteger_t)3L);
	ctx->vsp=local+10;
	w=(*ftab[5])(ctx,2,local+8,&ftab[5],fqv[24]); /*make-matrix*/
	local[6] = w;
irtdynaKEY3148:
	if (n & (1<<7)) goto irtdynaKEY3149;
	local[8]= makeint((eusinteger_t)3L);
	local[9]= makeint((eusinteger_t)3L);
	ctx->vsp=local+10;
	w=(*ftab[5])(ctx,2,local+8,&ftab[5],fqv[24]); /*make-matrix*/
	local[7] = w;
irtdynaKEY3149:
	if (local[0]==NIL) goto irtdynaIF3150;
	local[8]= T;
	local[9]= fqv[146];
	local[10]= argv[0];
	local[11]= fqv[58];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,3,local+8); /*format*/
	local[8]= w;
	goto irtdynaIF3151;
irtdynaIF3150:
	local[8]= NIL;
irtdynaIF3151:
	local[8]= makeflt(1.0000000000000000208167e-03);
	local[9]= argv[0];
	local[10]= fqv[20];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	local[9]= makeflt(-1.0000000000000000000000e+00);
	local[10]= local[8];
	local[11]= makeflt(1.0000000000000000208167e-03);
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,3,local+9); /***/
	local[9]= w;
	local[10]= loadglobal(fqv[147]);
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)SCALEVEC(ctx,3,local+9); /*scale*/
	local[9]= w;
	local[10]= makeflt(1.0000000000000000208167e-03);
	local[11]= argv[0];
	local[12]= fqv[30];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)SCALEVEC(ctx,3,local+10); /*scale*/
	local[10]= w;
	local[11]= argv[0];
	local[12]= fqv[25];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	local[12]= makeflt(9.9999999999999985548644e-10);
	local[13]= argv[0];
	local[14]= fqv[26];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(*ftab[2])(ctx,3,local+12,&ftab[2],fqv[4]); /*scale-matrix*/
	local[12]= w;
	local[13]= local[5];
	ctx->vsp=local+14;
	w=(pointer)MATTIMES(ctx,3,local+11); /*m**/
	local[11]= w;
	local[12]= argv[0];
	local[13]= fqv[25];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(pointer)TRANSPOSE(ctx,2,local+12); /*transpose*/
	local[12]= w;
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(pointer)MATTIMES(ctx,3,local+11); /*m**/
	local[11]= w;
	local[12]= local[10];
	local[13]= local[5];
	ctx->vsp=local+14;
	w=(*ftab[8])(ctx,2,local+12,&ftab[8],fqv[72]); /*outer-product-matrix*/
	local[12]= w;
	local[13]= local[11];
	local[14]= local[8];
	local[15]= local[12];
	local[16]= local[12];
	local[17]= local[6];
	ctx->vsp=local+18;
	w=(pointer)TRANSPOSE(ctx,2,local+16); /*transpose*/
	local[16]= w;
	local[17]= local[7];
	ctx->vsp=local+18;
	w=(pointer)MATTIMES(ctx,3,local+15); /*m**/
	local[15]= w;
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(*ftab[2])(ctx,3,local+14,&ftab[2],fqv[4]); /*scale-matrix*/
	local[14]= w;
	local[15]= local[5];
	ctx->vsp=local+16;
	w=(*ftab[6])(ctx,3,local+13,&ftab[6],fqv[27]); /*m+*/
	local[13]= w;
	local[14]= local[8];
	local[15]= argv[0]->c.obj.iv[19];
	local[16]= argv[0]->c.obj.iv[17];
	local[17]= local[10];
	local[18]= local[3];
	ctx->vsp=local+19;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+16); /*v**/
	local[16]= w;
	local[17]= local[3];
	ctx->vsp=local+18;
	w=(pointer)VPLUS(ctx,3,local+15); /*v+*/
	local[15]= w;
	local[16]= argv[0]->c.obj.iv[23];
	ctx->vsp=local+17;
	w=(pointer)SCALEVEC(ctx,3,local+14); /*scale*/
	argv[0]->c.obj.iv[23] = w;
	local[14]= local[8];
	local[15]= local[10];
	local[16]= argv[0]->c.obj.iv[19];
	local[17]= local[3];
	ctx->vsp=local+18;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+15); /*v**/
	local[15]= w;
	local[16]= argv[0]->c.obj.iv[24];
	ctx->vsp=local+17;
	w=(pointer)SCALEVEC(ctx,3,local+14); /*scale*/
	local[14]= w;
	local[15]= local[13];
	local[16]= argv[0]->c.obj.iv[17];
	local[17]= local[3];
	ctx->vsp=local+18;
	w=(pointer)TRANSFORM(ctx,3,local+15); /*transform*/
	local[15]= w;
	local[16]= argv[0]->c.obj.iv[24];
	ctx->vsp=local+17;
	w=(pointer)VPLUS(ctx,3,local+14); /*v+*/
	argv[0]->c.obj.iv[24] = w;
	local[14]= local[8];
	local[15]= argv[0]->c.obj.iv[20];
	local[16]= argv[0]->c.obj.iv[18];
	local[17]= local[10];
	local[18]= local[3];
	ctx->vsp=local+19;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+16); /*v**/
	local[16]= w;
	local[17]= argv[0]->c.obj.iv[25];
	ctx->vsp=local+18;
	w=(pointer)VPLUS(ctx,3,local+15); /*v+*/
	local[15]= w;
	local[16]= argv[0]->c.obj.iv[25];
	ctx->vsp=local+17;
	w=(pointer)SCALEVEC(ctx,3,local+14); /*scale*/
	local[14]= w;
	local[15]= argv[0]->c.obj.iv[17];
	local[16]= argv[0]->c.obj.iv[23];
	local[17]= local[3];
	ctx->vsp=local+18;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+15); /*v**/
	local[15]= w;
	local[16]= argv[0]->c.obj.iv[25];
	ctx->vsp=local+17;
	w=(pointer)VPLUS(ctx,3,local+14); /*v+*/
	argv[0]->c.obj.iv[25] = w;
	local[14]= local[8];
	local[15]= local[10];
	local[16]= argv[0]->c.obj.iv[20];
	local[17]= local[3];
	ctx->vsp=local+18;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+15); /*v**/
	local[15]= w;
	local[16]= argv[0]->c.obj.iv[26];
	ctx->vsp=local+17;
	w=(pointer)SCALEVEC(ctx,3,local+14); /*scale*/
	local[14]= w;
	local[15]= local[13];
	local[16]= argv[0]->c.obj.iv[18];
	local[17]= local[3];
	ctx->vsp=local+18;
	w=(pointer)TRANSFORM(ctx,3,local+15); /*transform*/
	local[15]= w;
	local[16]= argv[0]->c.obj.iv[26];
	ctx->vsp=local+17;
	w=(pointer)VPLUS(ctx,3,local+14); /*v+*/
	local[14]= w;
	local[15]= argv[0]->c.obj.iv[19];
	local[16]= argv[0]->c.obj.iv[23];
	local[17]= local[3];
	ctx->vsp=local+18;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+15); /*v**/
	local[15]= w;
	local[16]= argv[0]->c.obj.iv[26];
	ctx->vsp=local+17;
	w=(pointer)VPLUS(ctx,3,local+14); /*v+*/
	local[14]= w;
	local[15]= argv[0]->c.obj.iv[17];
	local[16]= argv[0]->c.obj.iv[24];
	local[17]= local[3];
	ctx->vsp=local+18;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+15); /*v**/
	local[15]= w;
	local[16]= argv[0]->c.obj.iv[26];
	ctx->vsp=local+17;
	w=(pointer)VPLUS(ctx,3,local+14); /*v+*/
	argv[0]->c.obj.iv[26] = w;
	local[14]= argv[0]->c.obj.iv[25];
	local[15]= local[9];
	local[16]= argv[0]->c.obj.iv[27];
	local[17]= local[3];
	ctx->vsp=local+18;
	w=(pointer)VPLUS(ctx,3,local+15); /*v+*/
	local[15]= w;
	local[16]= argv[0]->c.obj.iv[25];
	ctx->vsp=local+17;
	w=(pointer)VMINUS(ctx,3,local+14); /*v-*/
	argv[0]->c.obj.iv[25] = w;
	local[14]= argv[0]->c.obj.iv[26];
	local[15]= local[10];
	local[16]= local[9];
	local[17]= local[3];
	ctx->vsp=local+18;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+15); /*v**/
	local[15]= w;
	local[16]= argv[0]->c.obj.iv[28];
	local[17]= local[1];
	ctx->vsp=local+18;
	w=(pointer)VPLUS(ctx,3,local+15); /*v+*/
	local[15]= w;
	local[16]= argv[0]->c.obj.iv[26];
	ctx->vsp=local+17;
	w=(pointer)VMINUS(ctx,3,local+14); /*v-*/
	argv[0]->c.obj.iv[26] = w;
	w = argv[0]->c.obj.iv[26];
	local[8]= NIL;
	local[9]= argv[0]->c.obj.iv[11];
irtdynaWHL3152:
	if (local[9]==NIL) goto irtdynaWHX3153;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= local[8];
	local[11]= fqv[148];
	local[12]= fqv[45];
	local[13]= local[0];
	local[14]= fqv[34];
	local[15]= local[1];
	local[16]= fqv[35];
	local[17]= local[2];
	local[18]= fqv[149];
	local[19]= local[3];
	local[20]= fqv[37];
	local[21]= local[4];
	local[22]= fqv[38];
	local[23]= local[5];
	local[24]= fqv[39];
	local[25]= local[6];
	local[26]= fqv[40];
	local[27]= local[7];
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,18,local+10); /*send*/
	local[10]= argv[0]->c.obj.iv[25];
	local[11]= local[8];
	local[12]= fqv[150];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	local[12]= argv[0]->c.obj.iv[25];
	ctx->vsp=local+13;
	w=(pointer)VPLUS(ctx,3,local+10); /*v+*/
	argv[0]->c.obj.iv[25] = w;
	local[10]= argv[0]->c.obj.iv[26];
	local[11]= local[8];
	local[12]= fqv[151];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	local[12]= argv[0]->c.obj.iv[26];
	ctx->vsp=local+13;
	w=(pointer)VPLUS(ctx,3,local+10); /*v+*/
	argv[0]->c.obj.iv[26] = w;
	goto irtdynaWHL3152;
irtdynaWHX3153:
	local[10]= NIL;
irtdynaBLK3154:
	w = NIL;
	if (argv[0]->c.obj.iv[9]==NIL) goto irtdynaIF3155;
	if (argv[0]->c.obj.iv[10]==NIL) goto irtdynaIF3155;
	local[8]= argv[0];
	local[9]= fqv[120];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= loadglobal(fqv[121]);
	ctx->vsp=local+10;
	w=(pointer)DERIVEDP(ctx,2,local+8); /*derivedp*/
	if (w==NIL) goto irtdynaIF3155;
	local[8]= argv[0]->c.obj.iv[9];
	local[9]= fqv[152];
	local[10]= argv[0];
	local[11]= fqv[49];
	local[12]= fqv[136];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[10]= w;
	local[11]= argv[0]->c.obj.iv[25];
	ctx->vsp=local+12;
	w=(pointer)VINNERPRODUCT(ctx,2,local+10); /*v.*/
	local[10]= w;
	local[11]= argv[0];
	local[12]= fqv[49];
	local[13]= fqv[134];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	local[11]= w;
	local[12]= argv[0]->c.obj.iv[26];
	ctx->vsp=local+13;
	w=(pointer)VINNERPRODUCT(ctx,2,local+11); /*v.*/
	{ double x,y;
		y=fltval(w); x=fltval(local[10]);
		local[10]=(makeflt(x + y));}
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	goto irtdynaIF3156;
irtdynaIF3155:
	local[8]= NIL;
irtdynaIF3156:
	w = local[8];
	local[0]= w;
irtdynaBLK3141:
	ctx->vsp=local; return(local[0]);}

/*:max-torque-vector*/
static pointer irtdynaM3157cascaded_link_max_torque_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[43]);
	local[1]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+2;
	w=(*ftab[13])(ctx,1,local+1,&ftab[13],fqv[153]); /*calc-target-joint-dimension*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,2,local+0); /*instantiate*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= NIL;
	local[3]= argv[0]->c.obj.iv[9];
irtdynaWHL3159:
	if (local[3]==NIL) goto irtdynaWHX3160;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[2];
	local[6]= fqv[88];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
irtdynaWHL3162:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto irtdynaWHX3163;
	local[6]= local[0];
	local[7]= local[1];
	local[8]= local[2];
	local[9]= fqv[88];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[8];
	if (fqv[154]!=local[9]) goto irtdynaIF3165;
	local[9]= local[2];
	local[10]= fqv[155];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	goto irtdynaIF3166;
irtdynaIF3165:
	if (T==NIL) goto irtdynaIF3167;
	local[9]= local[2];
	local[10]= fqv[155];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	goto irtdynaIF3168;
irtdynaIF3167:
	local[9]= NIL;
irtdynaIF3168:
irtdynaIF3166:
	w = local[9];
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SETELT(ctx,3,local+6); /*setelt*/
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[1] = w;
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto irtdynaWHL3162;
irtdynaWHX3163:
	local[6]= NIL;
irtdynaBLK3164:
	w = NIL;
	goto irtdynaWHL3159;
irtdynaWHX3160:
	local[4]= NIL;
irtdynaBLK3161:
	w = NIL;
	w = local[0];
	local[0]= w;
irtdynaBLK3158:
	ctx->vsp=local; return(local[0]);}

/*:torque-ratio-vector*/
static pointer irtdynaM3169cascaded_link_torque_ratio_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtdynaRST3171:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[156], &argv[2], n-2, local+1, 0);
	if (n & (1<<0)) goto irtdynaKEY3172;
	local[2]= (pointer)get_sym_func(fqv[82]);
	local[3]= argv[0];
	local[4]= fqv[157];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,4,local+2); /*apply*/
	local[1] = w;
irtdynaKEY3172:
	local[2]= argv[0];
	local[3]= fqv[158];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= loadglobal(fqv[43]);
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)INSTANTIATE(ctx,2,local+3); /*instantiate*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
irtdynaWHL3173:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto irtdynaWHX3174;
	local[6]= local[3];
	local[7]= local[4];
	local[8]= local[1];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	local[9]= local[2];
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SETELT(ctx,3,local+6); /*setelt*/
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto irtdynaWHL3173;
irtdynaWHX3174:
	local[6]= NIL;
irtdynaBLK3175:
	w = NIL;
	w = local[3];
	local[0]= w;
irtdynaBLK3170:
	ctx->vsp=local; return(local[0]);}

/*:calc-torque-buffer-args*/
static pointer irtdynaM3176cascaded_link_calc_torque_buffer_args(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[34];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,3,local+1); /*float-vector*/
	local[1]= w;
	local[2]= fqv[35];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[3]= w;
	local[4]= fqv[149];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[5]= w;
	local[6]= fqv[37];
	local[7]= makeint((eusinteger_t)3L);
	local[8]= makeint((eusinteger_t)3L);
	ctx->vsp=local+9;
	w=(*ftab[5])(ctx,2,local+7,&ftab[5],fqv[24]); /*make-matrix*/
	local[7]= w;
	local[8]= fqv[38];
	local[9]= makeint((eusinteger_t)3L);
	local[10]= makeint((eusinteger_t)3L);
	ctx->vsp=local+11;
	w=(*ftab[5])(ctx,2,local+9,&ftab[5],fqv[24]); /*make-matrix*/
	local[9]= w;
	local[10]= fqv[39];
	local[11]= makeint((eusinteger_t)3L);
	local[12]= makeint((eusinteger_t)3L);
	ctx->vsp=local+13;
	w=(*ftab[5])(ctx,2,local+11,&ftab[5],fqv[24]); /*make-matrix*/
	local[11]= w;
	local[12]= fqv[40];
	local[13]= makeint((eusinteger_t)3L);
	local[14]= makeint((eusinteger_t)3L);
	ctx->vsp=local+15;
	w=(*ftab[5])(ctx,2,local+13,&ftab[5],fqv[24]); /*make-matrix*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,14,local+0); /*list*/
	local[0]= w;
irtdynaBLK3177:
	ctx->vsp=local; return(local[0]);}

/*:calc-torque*/
static pointer irtdynaM3178cascaded_link_calc_torque(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[159], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3180;
	local[0] = NIL;
irtdynaKEY3180:
	if (n & (1<<1)) goto irtdynaKEY3181;
	local[1] = T;
irtdynaKEY3181:
	if (n & (1<<2)) goto irtdynaKEY3182;
	local[2] = makeflt(4.9999999999999975019982e-03);
irtdynaKEY3182:
	if (n & (1<<3)) goto irtdynaKEY3183;
	local[9]= argv[0];
	local[10]= fqv[160];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[3] = w;
irtdynaKEY3183:
	if (n & (1<<4)) goto irtdynaKEY3184;
	local[9]= argv[0];
	local[10]= fqv[74];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= fqv[68];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[4] = w;
irtdynaKEY3184:
	if (n & (1<<5)) goto irtdynaKEY3185;
	local[5] = NIL;
irtdynaKEY3185:
	if (n & (1<<6)) goto irtdynaKEY3186;
	local[6] = NIL;
irtdynaKEY3186:
	if (n & (1<<7)) goto irtdynaKEY3187;
	local[7] = NIL;
irtdynaKEY3187:
	if (n & (1<<8)) goto irtdynaKEY3188;
	local[9]= argv[0];
	local[10]= fqv[161];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[8] = w;
irtdynaKEY3188:
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)LENGTH(ctx,1,local+10); /*length*/
	local[10]= w;
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)NUMEQUAL(ctx,3,local+9); /*=*/
	if (w!=NIL) goto irtdynaIF3189;
	local[9]= fqv[162];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)LENGTH(ctx,1,local+10); /*length*/
	local[10]= w;
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(pointer)LENGTH(ctx,1,local+12); /*length*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)SIGERROR(ctx,4,local+9); /*error*/
	local[9]= w;
	goto irtdynaIF3190;
irtdynaIF3189:
	local[9]= NIL;
irtdynaIF3190:
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,irtdynaCLO3191,env,argv,local);
	local[10]= local[5];
	local[11]= local[6];
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(pointer)MAPCAR(ctx,4,local+9); /*mapcar*/
	local[9]= argv[0];
	local[10]= fqv[163];
	local[11]= fqv[45];
	local[12]= local[0];
	local[13]= fqv[164];
	local[14]= local[1];
	local[15]= fqv[165];
	local[16]= local[3];
	local[17]= fqv[166];
	local[18]= local[4];
	local[19]= fqv[167];
	local[20]= local[2];
	local[21]= fqv[161];
	local[22]= local[8];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,14,local+9); /*send*/
	local[0]= w;
irtdynaBLK3179:
	ctx->vsp=local; return(local[0]);}

/*:calc-torque-without-ext-wrench*/
static pointer irtdynaM3192cascaded_link_calc_torque_without_ext_wrench(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[168], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3194;
	local[0] = NIL;
irtdynaKEY3194:
	if (n & (1<<1)) goto irtdynaKEY3195;
	local[1] = T;
irtdynaKEY3195:
	if (n & (1<<2)) goto irtdynaKEY3196;
	local[2] = makeflt(4.9999999999999975019982e-03);
irtdynaKEY3196:
	if (n & (1<<3)) goto irtdynaKEY3197;
	local[6]= argv[0];
	local[7]= fqv[160];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[3] = w;
irtdynaKEY3197:
	if (n & (1<<4)) goto irtdynaKEY3198;
	local[6]= argv[0];
	local[7]= fqv[74];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	local[7]= fqv[68];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[4] = w;
irtdynaKEY3198:
	if (n & (1<<5)) goto irtdynaKEY3199;
	local[6]= argv[0];
	local[7]= fqv[161];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[5] = w;
irtdynaKEY3199:
	local[6]= (pointer)get_sym_func(fqv[82]);
	local[7]= argv[0];
	local[8]= fqv[169];
	local[9]= fqv[45];
	local[10]= local[0];
	local[11]= fqv[161];
	local[12]= local[5];
	if (local[1]!=NIL) goto irtdynaIF3200;
	local[13]= argv[0];
	local[14]= fqv[170];
	local[15]= local[2];
	local[16]= local[4];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,4,local+13); /*send*/
	local[13]= w;
	local[14]= argv[0];
	local[15]= fqv[171];
	local[16]= local[2];
	local[17]= local[3];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,4,local+14); /*send*/
	local[14]= w;
	local[15]= fqv[172];
	local[16]= fqv[173];
	w = local[14];
	w=memq(local[16],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	local[17]= fqv[174];
	local[18]= fqv[175];
	w = local[14];
	w=memq(local[18],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.car;
	local[19]= fqv[176];
	local[20]= fqv[176];
	w = local[13];
	w=memq(local[20],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.car;
	local[21]= fqv[177];
	local[22]= fqv[177];
	w = local[13];
	w=memq(local[22],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22]= (w)->c.cons.car;
	local[23]= fqv[178];
	local[24]= fqv[178];
	w = local[13];
	w=memq(local[24],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[24]= (w)->c.cons.car;
	local[25]= fqv[179];
	local[26]= fqv[179];
	w = local[13];
	w=memq(local[26],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[26]= (w)->c.cons.car;
	ctx->vsp=local+27;
	w=(pointer)LIST(ctx,12,local+15); /*list*/
	local[13]= w;
	goto irtdynaIF3201;
irtdynaIF3200:
	local[13]= NIL;
irtdynaIF3201:
	ctx->vsp=local+14;
	w=(pointer)APPLY(ctx,8,local+6); /*apply*/
	local[0]= w;
irtdynaBLK3193:
	ctx->vsp=local; return(local[0]);}

/*:calc-torque-from-vel-acc*/
static pointer irtdynaM3202cascaded_link_calc_torque_from_vel_acc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[180], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3204;
	local[0] = NIL;
irtdynaKEY3204:
	if (n & (1<<1)) goto irtdynaKEY3205;
	local[8]= loadglobal(fqv[43]);
	local[9]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,2,local+8); /*instantiate*/
	local[1] = w;
irtdynaKEY3205:
	if (n & (1<<2)) goto irtdynaKEY3206;
	local[8]= loadglobal(fqv[43]);
	local[9]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,2,local+8); /*instantiate*/
	local[2] = w;
irtdynaKEY3206:
	if (n & (1<<3)) goto irtdynaKEY3207;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[3] = w;
irtdynaKEY3207:
	if (n & (1<<4)) goto irtdynaKEY3208;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[4] = w;
irtdynaKEY3208:
	if (n & (1<<5)) goto irtdynaKEY3209;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[5] = w;
irtdynaKEY3209:
	if (n & (1<<6)) goto irtdynaKEY3210;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[6] = w;
irtdynaKEY3210:
	if (n & (1<<7)) goto irtdynaKEY3211;
	local[8]= argv[0];
	local[9]= fqv[161];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[7] = w;
irtdynaKEY3211:
	local[8]= loadglobal(fqv[43]);
	local[9]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,2,local+8); /*instantiate*/
	local[8]= w;
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,irtdynaCLO3212,env,argv,local);
	local[10]= argv[0];
	local[11]= fqv[74];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)MAPCAR(ctx,2,local+9); /*mapcar*/
	local[9]= w;
	local[10]= argv[0];
	local[11]= fqv[74];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	local[11]= fqv[181];
	local[12]= fqv[182];
	ctx->vsp=local+13;
	w=(*ftab[7])(ctx,3,local+10,&ftab[7],fqv[29]); /*send-all*/
	local[10]= argv[0];
	local[11]= fqv[74];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	ctx->vsp=local+11;
	local[11]= makeclosure(codevec,quotevec,irtdynaCLO3213,env,argv,local);
	ctx->vsp=local+12;
	w=(*ftab[9])(ctx,2,local+10,&ftab[9],fqv[75]); /*all-child-links*/
	local[10]= makeint((eusinteger_t)0L);
	local[11]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
irtdynaWHL3214:
	local[12]= local[10];
	w = local[11];
	if ((eusinteger_t)local[12] >= (eusinteger_t)w) goto irtdynaWHX3215;
	local[12]= argv[0]->c.obj.iv[9];
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= local[12];
	local[14]= fqv[138];
	local[15]= local[1];
	local[16]= local[10];
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= local[12];
	local[14]= fqv[141];
	local[15]= local[2];
	local[16]= local[10];
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)ADD1(ctx,1,local+12); /*1+*/
	local[10] = w;
	goto irtdynaWHL3214;
irtdynaWHX3215:
	local[12]= NIL;
irtdynaBLK3216:
	w = NIL;
	local[10]= argv[0];
	local[11]= fqv[74];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= fqv[140];
	local[12]= local[5];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[10]= argv[0];
	local[11]= fqv[74];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= fqv[143];
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[10]= argv[0];
	local[11]= fqv[74];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= fqv[117];
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[10]= argv[0];
	local[11]= fqv[74];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= fqv[116];
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[10]= (pointer)get_sym_func(fqv[82]);
	local[11]= argv[0];
	local[12]= fqv[74];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= fqv[144];
	local[13]= fqv[45];
	local[14]= local[0];
	local[15]= local[7];
	local[16]= makeint((eusinteger_t)0L);
	local[17]= makeint((eusinteger_t)2L);
	ctx->vsp=local+18;
	w=(pointer)SUBSEQ(ctx,3,local+15); /*subseq*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)APPLY(ctx,6,local+10); /*apply*/
	local[10]= (pointer)get_sym_func(fqv[82]);
	local[11]= argv[0];
	local[12]= fqv[74];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= fqv[148];
	local[13]= fqv[45];
	local[14]= local[0];
	local[15]= local[7];
	ctx->vsp=local+16;
	w=(pointer)APPLY(ctx,6,local+10); /*apply*/
	local[10]= argv[0];
	local[11]= fqv[74];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	ctx->vsp=local+11;
	local[11]= makeclosure(codevec,quotevec,irtdynaCLO3217,env,argv,local);
	ctx->vsp=local+12;
	w=(*ftab[9])(ctx,2,local+10,&ftab[9],fqv[75]); /*all-child-links*/
	local[10]= makeint((eusinteger_t)0L);
	local[11]= local[8];
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
irtdynaWHL3218:
	local[12]= local[10];
	w = local[11];
	if ((eusinteger_t)local[12] >= (eusinteger_t)w) goto irtdynaWHX3219;
	local[12]= local[8];
	local[13]= local[10];
	local[14]= argv[0]->c.obj.iv[9];
	local[15]= local[10];
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[14]= w;
	local[15]= fqv[152];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SETELT(ctx,3,local+12); /*setelt*/
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)ADD1(ctx,1,local+12); /*1+*/
	local[10] = w;
	goto irtdynaWHL3218;
irtdynaWHX3219:
	local[12]= NIL;
irtdynaBLK3220:
	w = NIL;
	ctx->vsp=local+10;
	local[10]= makeclosure(codevec,quotevec,irtdynaCLO3221,env,argv,local);
	local[11]= argv[0];
	local[12]= fqv[74];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)MAPCAR(ctx,3,local+10); /*mapcar*/
	w = local[8];
	local[0]= w;
irtdynaBLK3203:
	ctx->vsp=local; return(local[0]);}

/*:calc-root-coords-vel-acc-from-pos*/
static pointer irtdynaM3222cascaded_link_calc_root_coords_vel_acc_from_pos(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtdynaFLET3224,env,argv,local);
	local[1]= makeflt(1.0000000000000000000000e+00);
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)QUOTIENT(ctx,2,local+1); /*/*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[49];
	local[4]= fqv[183];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	if (w==NIL) goto irtdynaIF3225;
	local[2]= argv[0];
	local[3]= fqv[49];
	local[4]= fqv[183];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto irtdynaIF3226;
irtdynaIF3225:
	local[2]= argv[3];
irtdynaIF3226:
	local[3]= local[1];
	local[4]= local[2];
	local[5]= fqv[2];
	local[6]= local[2];
	local[7]= fqv[25];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)TRANSPOSE(ctx,1,local+6); /*transpose*/
	local[6]= w;
	local[7]= argv[3];
	local[8]= fqv[25];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MATTIMES(ctx,2,local+6); /*m**/
	local[6]= w;
	w = local[0];
	ctx->vsp=local+7;
	w=irtdynaFLET3224(ctx,1,local+6,w);
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SCALEVEC(ctx,2,local+3); /*scale*/
	local[3]= w;
	local[4]= makeflt(1.0000000000000000208167e-03);
	local[5]= argv[3];
	local[6]= fqv[5];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SCALEVEC(ctx,2,local+4); /*scale*/
	local[4]= w;
	local[5]= makeflt(1.0000000000000000208167e-03);
	local[6]= local[2];
	local[7]= fqv[5];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SCALEVEC(ctx,2,local+5); /*scale*/
	local[5]= w;
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)VNORM(ctx,1,local+6); /*norm*/
	local[6]= w;
	local[7]= makeflt(0.0000000000000000000000e+00);
	local[8]= makeflt(4.9999999999999975019982e-03);
	ctx->vsp=local+9;
	w=(*ftab[4])(ctx,3,local+6,&ftab[4],fqv[22]); /*eps=*/
	if (w==NIL) goto irtdynaIF3227;
	local[6]= local[1];
	local[7]= local[4];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)VMINUS(ctx,2,local+7); /*v-*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SCALEVEC(ctx,2,local+6); /*scale*/
	local[6]= w;
	goto irtdynaIF3228;
irtdynaIF3227:
	local[6]= local[3];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+6); /*v**/
	local[6]= w;
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)VNORM(ctx,1,local+7); /*norm*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)3L);
	ctx->vsp=local+9;
	w=(*ftab[14])(ctx,1,local+8,&ftab[14],fqv[184]); /*unit-matrix*/
	local[8]= w;
	local[9]= argv[2];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)SCALEVEC(ctx,2,local+9); /*scale*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[15])(ctx,1,local+9,&ftab[15],fqv[185]); /*matrix-exponent*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[16])(ctx,2,local+8,&ftab[16],fqv[186]); /*m-*/
	local[8]= w;
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(*ftab[1])(ctx,1,local+9,&ftab[1],fqv[3]); /*normalize-vector*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[8])(ctx,1,local+9,&ftab[8],fqv[72]); /*outer-product-matrix*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MATTIMES(ctx,2,local+8); /*m**/
	local[8]= w;
	local[9]= argv[2];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)VNORM(ctx,1,local+10); /*norm*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)1L);
	local[11]= makeint((eusinteger_t)3L);
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(*ftab[5])(ctx,3,local+10,&ftab[5],fqv[24]); /*make-matrix*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)TRANSPOSE(ctx,1,local+10); /*transpose*/
	local[10]= w;
	local[11]= makeint((eusinteger_t)1L);
	local[12]= makeint((eusinteger_t)3L);
	local[13]= local[3];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(*ftab[5])(ctx,3,local+11,&ftab[5],fqv[24]); /*make-matrix*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)MATTIMES(ctx,2,local+10); /*m**/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[2])(ctx,2,local+9,&ftab[2],fqv[4]); /*scale-matrix*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[6])(ctx,2,local+8,&ftab[6],fqv[27]); /*m+*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[17])(ctx,1,local+8,&ftab[17],fqv[187]); /*inverse-matrix*/
	local[8]= w;
	local[9]= local[4];
	local[10]= argv[2];
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)SCALEVEC(ctx,2,local+10); /*scale*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[15])(ctx,1,local+10,&ftab[15],fqv[185]); /*matrix-exponent*/
	local[10]= w;
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)TRANSFORM(ctx,2,local+10); /*transform*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)VMINUS(ctx,2,local+9); /*v-*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)TRANSFORM(ctx,2,local+8); /*transform*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SCALEVEC(ctx,2,local+7); /*scale*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)VPLUS(ctx,2,local+6); /*v+*/
	local[6]= w;
irtdynaIF3228:
	local[7]= argv[0];
	local[8]= fqv[49];
	local[9]= fqv[188];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	if (w==NIL) goto irtdynaIF3229;
	local[7]= argv[0];
	local[8]= fqv[49];
	local[9]= fqv[188];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	goto irtdynaIF3230;
irtdynaIF3229:
	local[7]= local[6];
irtdynaIF3230:
	local[8]= argv[0];
	local[9]= fqv[49];
	local[10]= fqv[189];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	if (w==NIL) goto irtdynaIF3231;
	local[8]= argv[0];
	local[9]= fqv[49];
	local[10]= fqv[189];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	goto irtdynaIF3232;
irtdynaIF3231:
	local[8]= local[3];
irtdynaIF3232:
	local[9]= local[1];
	local[10]= local[3];
	local[11]= local[8];
	ctx->vsp=local+12;
	w=(pointer)VMINUS(ctx,2,local+10); /*v-*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SCALEVEC(ctx,2,local+9); /*scale*/
	local[9]= w;
	local[10]= local[1];
	local[11]= local[6];
	local[12]= argv[2];
	local[13]= local[3];
	ctx->vsp=local+14;
	w=(pointer)SCALEVEC(ctx,2,local+12); /*scale*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(*ftab[15])(ctx,1,local+12,&ftab[15],fqv[185]); /*matrix-exponent*/
	local[12]= w;
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(pointer)TRANSFORM(ctx,2,local+12); /*transform*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)VMINUS(ctx,2,local+11); /*v-*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SCALEVEC(ctx,2,local+10); /*scale*/
	local[10]= w;
	local[11]= local[9];
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+11); /*v**/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)VMINUS(ctx,2,local+10); /*v-*/
	local[10]= w;
	local[11]= argv[0];
	local[12]= fqv[46];
	local[13]= fqv[183];
	local[14]= argv[3];
	local[15]= fqv[68];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,4,local+11); /*send*/
	local[11]= argv[0];
	local[12]= fqv[46];
	local[13]= fqv[188];
	local[14]= local[6];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,4,local+11); /*send*/
	local[11]= argv[0];
	local[12]= fqv[46];
	local[13]= fqv[189];
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,4,local+11); /*send*/
	local[11]= fqv[176];
	local[12]= local[6];
	local[13]= local[3];
	local[14]= makeflt(1.0000000000000000208167e-03);
	local[15]= argv[3];
	local[16]= fqv[5];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)SCALEVEC(ctx,2,local+14); /*scale*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+13); /*v**/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)VMINUS(ctx,2,local+12); /*v-*/
	local[12]= w;
	local[13]= fqv[177];
	local[14]= local[3];
	local[15]= fqv[178];
	local[16]= local[10];
	local[17]= fqv[179];
	local[18]= local[9];
	ctx->vsp=local+19;
	w=(pointer)LIST(ctx,8,local+11); /*list*/
	local[0]= w;
irtdynaBLK3223:
	ctx->vsp=local; return(local[0]);}

/*:calc-av-vel-acc-from-pos*/
static pointer irtdynaM3233cascaded_link_calc_av_vel_acc_from_pos(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= makeflt(1.0000000000000000000000e+00);
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[49];
	local[3]= fqv[190];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	if (w==NIL) goto irtdynaIF3235;
	local[1]= argv[0];
	local[2]= fqv[49];
	local[3]= fqv[190];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto irtdynaIF3236;
irtdynaIF3235:
	local[1]= argv[3];
irtdynaIF3236:
	local[2]= loadglobal(fqv[43]);
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,2,local+2); /*instantiate*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
irtdynaWHL3237:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto irtdynaWHX3238;
	local[5]= local[2];
	local[6]= local[3];
	local[7]= local[0];
	local[8]= argv[0]->c.obj.iv[9];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	local[9]= fqv[191];
	local[10]= argv[3];
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	local[11]= local[1];
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)MINUS(ctx,2,local+10); /*-*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SETELT(ctx,3,local+5); /*setelt*/
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto irtdynaWHL3237;
irtdynaWHX3238:
	local[5]= NIL;
irtdynaBLK3239:
	w = NIL;
	w = local[2];
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[49];
	local[5]= fqv[192];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	if (w==NIL) goto irtdynaIF3240;
	local[3]= argv[0];
	local[4]= fqv[49];
	local[5]= fqv[192];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto irtdynaIF3241;
irtdynaIF3240:
	local[3]= local[2];
irtdynaIF3241:
	local[4]= local[0];
	local[5]= local[2];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)VMINUS(ctx,2,local+5); /*v-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SCALEVEC(ctx,2,local+4); /*scale*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[46];
	local[7]= fqv[190];
	local[8]= argv[3];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= argv[0];
	local[6]= fqv[46];
	local[7]= fqv[192];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= fqv[173];
	local[6]= local[2];
	local[7]= fqv[175];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,4,local+5); /*list*/
	local[0]= w;
irtdynaBLK3234:
	ctx->vsp=local; return(local[0]);}

/*:calc-torque-from-ext-wrenches*/
static pointer irtdynaM3242cascaded_link_calc_torque_from_ext_wrenches(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[193], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3244;
	local[0] = NIL;
irtdynaKEY3244:
	if (n & (1<<1)) goto irtdynaKEY3245;
	local[1] = NIL;
irtdynaKEY3245:
	if (n & (1<<2)) goto irtdynaKEY3246;
	local[2] = NIL;
irtdynaKEY3246:
	if (n & (1<<3)) goto irtdynaKEY3247;
	local[3] = NIL;
irtdynaKEY3247:
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtdynaCLO3248,env,argv,local);
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)MAPCAR(ctx,2,local+4); /*mapcar*/
	local[4]= w;
	if (local[3]==NIL) goto irtdynaIF3249;
	local[5]= local[3];
	goto irtdynaIF3250;
irtdynaIF3249:
	local[5]= argv[0];
	local[6]= fqv[194];
	local[7]= local[4];
	local[8]= fqv[195];
	local[9]= local[2];
	local[10]= fqv[196];
	ctx->vsp=local+11;
	local[11]= makeclosure(codevec,quotevec,irtdynaCLO3251,env,argv,local);
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)MAPCAR(ctx,2,local+11); /*mapcar*/
	local[11]= w;
	local[12]= fqv[87];
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(pointer)LENGTH(ctx,1,local+13); /*length*/
	local[13]= w;
	local[14]= fqv[197];
	local[15]= T;
	ctx->vsp=local+16;
	w=(*ftab[18])(ctx,3,local+13,&ftab[18],fqv[198]); /*make-list*/
	local[13]= w;
	local[14]= fqv[86];
	local[15]= local[2];
	ctx->vsp=local+16;
	w=(pointer)LENGTH(ctx,1,local+15); /*length*/
	local[15]= w;
	local[16]= fqv[197];
	local[17]= T;
	ctx->vsp=local+18;
	w=(*ftab[18])(ctx,3,local+15,&ftab[18],fqv[198]); /*make-list*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,11,local+5); /*send*/
	local[5]= w;
irtdynaIF3250:
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtdynaCLO3252,env,argv,local);
	local[7]= local[0];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)MAPCAR(ctx,3,local+6); /*mapcar*/
	local[6]= w;
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)TRANSPOSE(ctx,1,local+7); /*transpose*/
	local[7]= w;
	local[8]= (pointer)get_sym_func(fqv[199]);
	local[9]= loadglobal(fqv[43]);
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)APPLY(ctx,3,local+8); /*apply*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)TRANSFORM(ctx,2,local+7); /*transform*/
	local[7]= w;
	local[8]= loadglobal(fqv[43]);
	local[9]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,2,local+8); /*instantiate*/
	local[8]= w;
	local[9]= argv[0];
	local[10]= fqv[200];
	local[11]= local[4];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)0L);
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
irtdynaWHL3253:
	local[12]= local[10];
	w = local[11];
	if ((eusinteger_t)local[12] >= (eusinteger_t)w) goto irtdynaWHX3254;
	local[12]= local[8];
	local[13]= local[9];
	local[14]= local[10];
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	local[14]= fqv[81];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	local[14]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,2,local+13,&ftab[19],fqv[201]); /*position*/
	local[13]= w;
	local[14]= local[7];
	local[15]= local[10];
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SETELT(ctx,3,local+12); /*setelt*/
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)ADD1(ctx,1,local+12); /*1+*/
	local[10] = w;
	goto irtdynaWHL3253;
irtdynaWHX3254:
	local[12]= NIL;
irtdynaBLK3255:
	w = NIL;
	w = local[8];
	local[0]= w;
irtdynaBLK3243:
	ctx->vsp=local; return(local[0]);}

/*:calc-zmp*/
static pointer irtdynaM3256cascaded_link_calc_zmp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtdynaENT3260;}
	local[0]= argv[0];
	local[1]= fqv[160];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
irtdynaENT3260:
	if (n>=4) { local[1]=(argv[3]); goto irtdynaENT3259;}
	local[1]= argv[0];
	local[2]= fqv[74];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[68];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
irtdynaENT3259:
irtdynaENT3258:
	ctx->vsp=local+2;
	n=parsekeyparams(fqv[202], &argv[4], n-4, local+2, 0);
	if (n & (1<<0)) goto irtdynaKEY3261;
	local[2] = makeflt(0.0000000000000000000000e+00);
irtdynaKEY3261:
	if (n & (1<<1)) goto irtdynaKEY3262;
	local[3] = makeflt(4.9999999999999975019982e-03);
irtdynaKEY3262:
	if (n & (1<<2)) goto irtdynaKEY3263;
	local[4] = T;
irtdynaKEY3263:
	if (n & (1<<3)) goto irtdynaKEY3264;
	local[5] = NIL;
irtdynaKEY3264:
	if (n & (1<<4)) goto irtdynaKEY3265;
	local[7]= argv[0];
	local[8]= fqv[161];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[6] = w;
irtdynaKEY3265:
	if (local[4]==NIL) goto irtdynaIF3266;
	local[7]= argv[0];
	local[8]= fqv[74];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtdynaCLO3268,env,argv,local);
	ctx->vsp=local+9;
	w=(*ftab[9])(ctx,2,local+7,&ftab[9],fqv[75]); /*all-child-links*/
	local[7]= argv[0];
	local[8]= fqv[203];
	local[9]= fqv[167];
	local[10]= local[3];
	local[11]= fqv[165];
	local[12]= local[0];
	local[13]= fqv[166];
	local[14]= local[1];
	local[15]= fqv[45];
	local[16]= local[5];
	local[17]= fqv[164];
	local[18]= NIL;
	local[19]= fqv[161];
	local[20]= local[6];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,14,local+7); /*send*/
	local[7]= w;
	goto irtdynaIF3267;
irtdynaIF3266:
	local[7]= NIL;
irtdynaIF3267:
	local[7]= argv[0];
	local[8]= fqv[74];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= fqv[150];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= fqv[74];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= fqv[151];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[7];
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	local[10]= local[7];
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	local[11]= local[7];
	local[12]= makeint((eusinteger_t)2L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= local[8];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= local[8];
	local[14]= makeint((eusinteger_t)1L);
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	local[14]= local[8];
	local[15]= makeint((eusinteger_t)2L);
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[14]= w;
	local[15]= makeflt(1.0000000000000000208167e-03);
	local[16]= local[2];
	ctx->vsp=local+17;
	w=(pointer)TIMES(ctx,2,local+15); /***/
	local[15]= w;
	local[16]= local[13];
	ctx->vsp=local+17;
	w=(pointer)MINUS(ctx,1,local+16); /*-*/
	local[16]= w;
	local[17]= local[15];
	local[18]= local[9];
	ctx->vsp=local+19;
	w=(pointer)TIMES(ctx,2,local+17); /***/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)PLUS(ctx,2,local+16); /*+*/
	local[16]= w;
	local[17]= local[11];
	ctx->vsp=local+18;
	w=(pointer)QUOTIENT(ctx,2,local+16); /*/*/
	local[16]= w;
	local[17]= local[12];
	local[18]= local[15];
	local[19]= local[10];
	ctx->vsp=local+20;
	w=(pointer)TIMES(ctx,2,local+18); /***/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)PLUS(ctx,2,local+17); /*+*/
	local[17]= w;
	local[18]= local[11];
	ctx->vsp=local+19;
	w=(pointer)QUOTIENT(ctx,2,local+17); /*/*/
	local[17]= w;
	local[18]= local[15];
	ctx->vsp=local+19;
	w=(pointer)MKFLTVEC(ctx,3,local+16); /*float-vector*/
	local[16]= w;
	local[17]= argv[0];
	local[18]= fqv[46];
	local[19]= fqv[204];
	local[20]= makeflt(1.0000000000000000000000e+03);
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)SCALEVEC(ctx,2,local+20); /*scale*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,4,local+17); /*send*/
	local[17]= argv[0];
	local[18]= fqv[46];
	local[19]= fqv[205];
	local[20]= makeint((eusinteger_t)0L);
	local[21]= makeint((eusinteger_t)0L);
	local[22]= local[14];
	local[23]= makeflt(1.0000000000000000208167e-03);
	local[24]= argv[0];
	local[25]= fqv[49];
	local[26]= fqv[204];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,3,local+24); /*send*/
	local[24]= w;
	local[25]= makeint((eusinteger_t)0L);
	ctx->vsp=local+26;
	w=(pointer)ELT(ctx,2,local+24); /*elt*/
	local[24]= w;
	ctx->vsp=local+25;
	w=(pointer)TIMES(ctx,2,local+23); /***/
	local[23]= w;
	local[24]= local[10];
	local[25]= makeflt(-1.0000000000000000000000e+00);
	ctx->vsp=local+26;
	w=(pointer)TIMES(ctx,3,local+23); /***/
	local[23]= w;
	local[24]= makeflt(1.0000000000000000208167e-03);
	local[25]= argv[0];
	local[26]= fqv[49];
	local[27]= fqv[204];
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,3,local+25); /*send*/
	local[25]= w;
	local[26]= makeint((eusinteger_t)1L);
	ctx->vsp=local+27;
	w=(pointer)ELT(ctx,2,local+25); /*elt*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(pointer)TIMES(ctx,2,local+24); /***/
	local[24]= w;
	local[25]= local[9];
	ctx->vsp=local+26;
	w=(pointer)TIMES(ctx,2,local+24); /***/
	local[24]= w;
	ctx->vsp=local+25;
	w=(pointer)PLUS(ctx,3,local+22); /*+*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)MKFLTVEC(ctx,3,local+20); /*float-vector*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,4,local+17); /*send*/
	local[7]= argv[0];
	local[8]= fqv[49];
	local[9]= fqv[204];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[0]= w;
irtdynaBLK3257:
	ctx->vsp=local; return(local[0]);}

/*:calc-cop-from-force-moment*/
static pointer irtdynaM3269cascaded_link_calc_cop_from_force_moment(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<6) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[206], &argv[6], n-6, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3271;
	local[0] = makeint((eusinteger_t)1L);
irtdynaKEY3271:
	if (n & (1<<1)) goto irtdynaKEY3272;
	local[1] = NIL;
irtdynaKEY3272:
	local[2]= argv[5];
	local[3]= fqv[207];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= argv[5];
	local[4]= fqv[207];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	local[4]= makeflt(1.0000000000000000208167e-03);
	local[5]= argv[5];
	local[6]= fqv[41];
	local[7]= argv[4];
	local[8]= fqv[5];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SCALEVEC(ctx,2,local+4); /*scale*/
	local[4]= w;
	local[5]= local[2];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= local[4];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	local[6]= local[4];
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= local[2];
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,1,local+6); /*-*/
	local[6]= w;
	local[7]= local[3];
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,1,local+7); /*-*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,3,local+5); /*+*/
	local[5]= w;
	local[6]= local[2];
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= local[4];
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	local[7]= local[4];
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	local[8]= local[2];
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,1,local+7); /*-*/
	local[7]= w;
	local[8]= local[3];
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,3,local+6); /*+*/
	local[6]= w;
	local[7]= local[2];
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	local[8]= local[7];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)LESSP(ctx,2,local+8); /*<*/
	if (w==NIL) goto irtdynaCON3274;
	local[8]= NIL;
	goto irtdynaCON3273;
irtdynaCON3274:
	if (local[1]==NIL) goto irtdynaCON3275;
	local[8]= fqv[208];
	local[9]= argv[5];
	local[10]= fqv[209];
	local[11]= makeflt(1.0000000000000000000000e+03);
	local[12]= local[5];
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(pointer)QUOTIENT(ctx,2,local+12); /*/*/
	local[12]= w;
	local[13]= local[6];
	local[14]= local[7];
	ctx->vsp=local+15;
	w=(pointer)QUOTIENT(ctx,2,local+13); /*/*/
	local[13]= w;
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(pointer)MKFLTVEC(ctx,3,local+12); /*float-vector*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)SCALEVEC(ctx,2,local+11); /*scale*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	local[10]= fqv[210];
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,4,local+8); /*list*/
	local[8]= w;
	goto irtdynaCON3273;
irtdynaCON3275:
	local[8]= argv[5];
	local[9]= fqv[209];
	local[10]= makeflt(1.0000000000000000000000e+03);
	local[11]= local[5];
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	local[11]= w;
	local[12]= local[6];
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(pointer)QUOTIENT(ctx,2,local+12); /*/*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)MKFLTVEC(ctx,3,local+11); /*float-vector*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SCALEVEC(ctx,2,local+10); /*scale*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	goto irtdynaCON3273;
irtdynaCON3276:
	local[8]= NIL;
irtdynaCON3273:
	w = local[8];
	local[0]= w;
irtdynaBLK3270:
	ctx->vsp=local; return(local[0]);}

/*:wrench-vector->wrench-list*/
static pointer irtdynaM3277cascaded_link_wrench_vector__wrench_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)6L);
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
irtdynaWHL3279:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto irtdynaWHX3280;
	local[4]= argv[2];
	local[5]= makeint((eusinteger_t)6L);
	{ eusinteger_t i,j;
		j=intval(local[2]); i=intval(local[5]);
		local[5]=(makeint(i * j));}
	local[6]= makeint((eusinteger_t)3L);
	local[7]= makeint((eusinteger_t)6L);
	{ eusinteger_t i,j;
		j=intval(local[2]); i=intval(local[7]);
		local[7]=(makeint(i * j));}
	w = local[7];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[6]= (pointer)((eusinteger_t)local[6] + (eusinteger_t)w);
	ctx->vsp=local+7;
	w=(pointer)SUBSEQ(ctx,3,local+4); /*subseq*/
	local[4]= w;
	w = local[0];
	ctx->vsp=local+5;
	local[0] = cons(ctx,local[4],w);
	local[4]= argv[2];
	local[5]= makeint((eusinteger_t)3L);
	local[6]= makeint((eusinteger_t)6L);
	{ eusinteger_t i,j;
		j=intval(local[2]); i=intval(local[6]);
		local[6]=(makeint(i * j));}
	w = local[6];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[5]= (pointer)((eusinteger_t)local[5] + (eusinteger_t)w);
	local[6]= makeint((eusinteger_t)6L);
	local[7]= makeint((eusinteger_t)6L);
	{ eusinteger_t i,j;
		j=intval(local[2]); i=intval(local[7]);
		local[7]=(makeint(i * j));}
	w = local[7];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[6]= (pointer)((eusinteger_t)local[6] + (eusinteger_t)w);
	ctx->vsp=local+7;
	w=(pointer)SUBSEQ(ctx,3,local+4); /*subseq*/
	local[4]= w;
	w = local[1];
	ctx->vsp=local+5;
	local[1] = cons(ctx,local[4],w);
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto irtdynaWHL3279;
irtdynaWHX3280:
	local[4]= NIL;
irtdynaBLK3281:
	w = NIL;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)REVERSE(ctx,1,local+2); /*reverse*/
	local[2]= w;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)REVERSE(ctx,1,local+3); /*reverse*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,2,local+2); /*list*/
	local[0]= w;
irtdynaBLK3278:
	ctx->vsp=local; return(local[0]);}

/*:wrench-list->wrench-vector*/
static pointer irtdynaM3282cascaded_link_wrench_list__wrench_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= (pointer)get_sym_func(fqv[199]);
	local[1]= loadglobal(fqv[43]);
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtdynaCLO3284,env,argv,local);
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)MAPCAR(ctx,3,local+2); /*mapcar*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)APPLY(ctx,3,local+0); /*apply*/
	local[0]= w;
irtdynaBLK3283:
	ctx->vsp=local; return(local[0]);}

/*:calc-contact-wrenches-from-total-wrench*/
static pointer irtdynaM3285cascaded_link_calc_contact_wrenches_from_total_wrench(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[211], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3287;
	local[0] = NIL;
irtdynaKEY3287:
	if (n & (1<<1)) goto irtdynaKEY3288;
	local[2]= loadglobal(fqv[43]);
	local[3]= makeint((eusinteger_t)6L);
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	{ eusinteger_t i,j;
		j=intval(w); i=intval(local[3]);
		local[3]=(makeint(i * j));}
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,2,local+2); /*instantiate*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(*ftab[20])(ctx,2,local+2,&ftab[20],fqv[212]); /*fill*/
	local[1] = w;
irtdynaKEY3288:
	if (local[0]!=NIL) goto irtdynaIF3289;
	local[2]= argv[0];
	local[3]= fqv[20];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= makeflt(9.9999999999999974298988e-07);
	local[4]= loadglobal(fqv[147]);
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,3,local+2); /***/
	local[2]= w;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[2];
	local[6]= makeflt(1.0000000000000000208167e-03);
	local[7]= argv[0];
	local[8]= fqv[30];
	local[9]= NIL;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,3,local+6); /***/
	local[6]= w;
	local[7]= makeflt(-1.0000000000000000208167e-03);
	local[8]= argv[0];
	local[9]= fqv[30];
	local[10]= NIL;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,3,local+7); /***/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,6,local+3); /*float-vector*/
	local[0] = w;
	local[2]= local[0];
	goto irtdynaIF3290;
irtdynaIF3289:
	local[2]= NIL;
irtdynaIF3290:
	local[2]= argv[0];
	local[3]= fqv[94];
	local[4]= argv[0];
	local[5]= fqv[213];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= fqv[20];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,5,local+2); /*send*/
	local[2]= w;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)TRANSFORM(ctx,2,local+2); /*transform*/
	local[2]= w;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
irtdynaWHL3291:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto irtdynaWHX3292;
	local[7]= local[2];
	local[8]= local[5];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)6L)); i=intval(local[8]);
		local[8]=(makeint(i * j));}
	local[9]= local[5];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)6L)); i=intval(local[9]);
		local[9]=(makeint(i * j));}
	w = makeint((eusinteger_t)3L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[9]= (pointer)((eusinteger_t)local[9] + (eusinteger_t)w);
	ctx->vsp=local+10;
	w=(pointer)SUBSEQ(ctx,3,local+7); /*subseq*/
	local[7]= w;
	w = local[3];
	ctx->vsp=local+8;
	local[3] = cons(ctx,local[7],w);
	local[7]= local[2];
	local[8]= local[5];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)6L)); i=intval(local[8]);
		local[8]=(makeint(i * j));}
	w = makeint((eusinteger_t)3L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[8]= (pointer)((eusinteger_t)local[8] + (eusinteger_t)w);
	local[9]= local[5];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)6L)); i=intval(local[9]);
		local[9]=(makeint(i * j));}
	w = makeint((eusinteger_t)6L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[9]= (pointer)((eusinteger_t)local[9] + (eusinteger_t)w);
	ctx->vsp=local+10;
	w=(pointer)SUBSEQ(ctx,3,local+7); /*subseq*/
	local[7]= w;
	w = local[4];
	ctx->vsp=local+8;
	local[4] = cons(ctx,local[7],w);
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto irtdynaWHL3291;
irtdynaWHX3292:
	local[7]= NIL;
irtdynaBLK3293:
	w = NIL;
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)REVERSE(ctx,1,local+5); /*reverse*/
	local[5]= w;
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)REVERSE(ctx,1,local+6); /*reverse*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,2,local+5); /*list*/
	local[0]= w;
irtdynaBLK3286:
	ctx->vsp=local; return(local[0]);}

/*:draw-torque*/
static pointer irtdynaM3294cascaded_link_draw_torque(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[214], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3296;
	local[0] = NIL;
irtdynaKEY3296:
	if (n & (1<<1)) goto irtdynaKEY3297;
	local[1] = makeint((eusinteger_t)2L);
irtdynaKEY3297:
	if (n & (1<<2)) goto irtdynaKEY3298;
	local[2] = makeint((eusinteger_t)100L);
irtdynaKEY3298:
	if (n & (1<<3)) goto irtdynaKEY3299;
	local[8]= makeint((eusinteger_t)1L);
	local[9]= makeflt(2.9999999999999982236432e-01);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[3] = w;
irtdynaKEY3299:
	if (n & (1<<4)) goto irtdynaKEY3300;
	local[8]= makeint((eusinteger_t)1L);
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[4] = w;
irtdynaKEY3300:
	if (n & (1<<5)) goto irtdynaKEY3301;
	local[5] = NIL;
irtdynaKEY3301:
	if (n & (1<<6)) goto irtdynaKEY3302;
	local[8]= argv[0];
	local[9]= fqv[157];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[6] = w;
irtdynaKEY3302:
	if (n & (1<<7)) goto irtdynaKEY3303;
	local[8]= argv[0];
	local[9]= fqv[215];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[7] = w;
irtdynaKEY3303:
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtdynaCLO3304,env,argv,local);
	local[9]= local[7];
	local[10]= local[6];
	local[11]= loadglobal(fqv[216]);
	ctx->vsp=local+12;
	w=(pointer)COERCE(ctx,2,local+10); /*coerce*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)MAPCAR(ctx,3,local+8); /*mapcar*/
	if (local[0]==NIL) goto irtdynaIF3305;
	local[8]= argv[2];
	local[9]= fqv[217];
	local[10]= fqv[218];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	goto irtdynaIF3306;
irtdynaIF3305:
	local[8]= NIL;
irtdynaIF3306:
	w = local[8];
	local[0]= w;
irtdynaBLK3295:
	ctx->vsp=local; return(local[0]);}

/*:weight*/
static pointer irtdynaM3307cascaded_link_weight(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtdynaENT3310;}
	local[0]= T;
irtdynaENT3310:
irtdynaENT3309:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtdynaIF3311;
	local[1]= argv[0];
	local[2]= fqv[80];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	goto irtdynaIF3312;
irtdynaIF3311:
	local[1]= NIL;
irtdynaIF3312:
	local[1]= argv[0];
	local[2]= fqv[74];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[49];
	local[3]= fqv[47];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
irtdynaBLK3308:
	ctx->vsp=local; return(local[0]);}

/*:centroid*/
static pointer irtdynaM3313cascaded_link_centroid(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtdynaENT3316;}
	local[0]= T;
irtdynaENT3316:
irtdynaENT3315:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtdynaIF3317;
	local[1]= argv[0];
	local[2]= fqv[80];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	goto irtdynaIF3318;
irtdynaIF3317:
	local[1]= NIL;
irtdynaIF3318:
	local[1]= argv[0];
	local[2]= fqv[74];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[49];
	local[3]= fqv[51];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
irtdynaBLK3314:
	ctx->vsp=local; return(local[0]);}

/*:inertia-tensor*/
static pointer irtdynaM3319cascaded_link_inertia_tensor(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtdynaENT3322;}
	local[0]= T;
irtdynaENT3322:
irtdynaENT3321:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtdynaIF3323;
	local[1]= argv[0];
	local[2]= fqv[80];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	goto irtdynaIF3324;
irtdynaIF3323:
	local[1]= NIL;
irtdynaIF3324:
	local[1]= argv[0];
	local[2]= fqv[74];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[49];
	local[3]= fqv[50];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
irtdynaBLK3320:
	ctx->vsp=local; return(local[0]);}

/*:preview-control-dynamics-filter*/
static pointer irtdynaM3325cascaded_link_preview_control_dynamics_filter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[219], &argv[4], n-4, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3327;
	local[0] = loadglobal(fqv[220]);
irtdynaKEY3327:
	if (n & (1<<1)) goto irtdynaKEY3328;
	local[1] = fqv[221];
irtdynaKEY3328:
	if (n & (1<<2)) goto irtdynaKEY3329;
	local[2] = makeflt(7.9999999999999982236432e-01);
irtdynaKEY3329:
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,irtdynaFLET3330,env,argv,local);
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w = local[3];
	ctx->vsp=local+5;
	w=irtdynaFLET3330(ctx,1,local+4,w);
	local[4]= loadglobal(fqv[222]);
	ctx->vsp=local+5;
	w=(pointer)INSTANTIATE(ctx,1,local+4); /*instantiate*/
	local[4]= w;
	local[5]= local[4];
	local[6]= fqv[223];
	local[7]= argv[2];
	local[8]= argv[0];
	local[9]= fqv[30];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	local[9]= fqv[224];
	local[10]= local[2];
	local[11]= fqv[225];
	local[12]= T;
	local[13]= fqv[226];
	local[14]= local[0];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,10,local+5); /*send*/
	w = local[4];
	local[4]= w;
	local[5]= NIL;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)2L);
irtdynaWHL3331:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto irtdynaWHX3332;
	local[8]= argv[0];
	local[9]= fqv[227];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto irtdynaWHL3331;
irtdynaWHX3332:
	local[8]= NIL;
irtdynaBLK3333:
	w = NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= NIL;
	local[10]= NIL;
	local[11]= argv[3];
	ctx->vsp=local+12;
	w=(pointer)COPYOBJ(ctx,1,local+11); /*copy-object*/
	local[11]= w;
irtdynaWHL3334:
	local[12]= local[4];
	local[13]= fqv[228];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	if (w!=NIL) goto irtdynaWHX3335;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11] = (w)->c.cons.cdr;
	w = local[12];
	local[10] = w;
	if (local[10]==NIL) goto irtdynaIF3337;
	local[12]= local[10];
	w = local[3];
	ctx->vsp=local+13;
	w=irtdynaFLET3330(ctx,1,local+12,w);
	local[7] = local[10];
	local[12]= local[7];
	goto irtdynaIF3338;
irtdynaIF3337:
	local[12]= local[7];
	w = local[3];
	ctx->vsp=local+13;
	w=irtdynaFLET3330(ctx,1,local+12,w);
	local[12]= w;
irtdynaIF3338:
	local[12]= argv[0];
	local[13]= fqv[227];
	local[14]= argv[0];
	local[15]= fqv[160];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= w;
	local[15]= argv[0];
	local[16]= fqv[68];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	local[16]= fqv[167];
	local[17]= argv[2];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,6,local+12); /*send*/
	local[12]= w;
	local[13]= fqv[204];
	w = local[10];
	w=memq(local[13],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	if (local[13]==NIL) goto irtdynaIF3339;
	local[9] = local[13];
	local[14]= local[9];
	goto irtdynaIF3340;
irtdynaIF3339:
	local[14]= local[9];
irtdynaIF3340:
	w = local[14];
	local[13]= w;
	local[14]= local[12];
	local[15]= local[13];
	ctx->vsp=local+16;
	w=(pointer)VMINUS(ctx,2,local+14); /*v-*/
	local[14]= w;
	local[15]= local[4];
	local[16]= fqv[229];
	if (local[10]==NIL) goto irtdynaIF3341;
	local[17]= local[14];
	goto irtdynaIF3342;
irtdynaIF3341:
	local[17]= NIL;
irtdynaIF3342:
	local[18]= local[10];
	local[19]= local[12];
	local[20]= argv[0];
	local[21]= fqv[30];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,2,local+20); /*send*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)COPYOBJ(ctx,1,local+20); /*copy-object*/
	local[20]= w;
	local[21]= local[13];
	ctx->vsp=local+22;
	w=(pointer)LIST(ctx,4,local+18); /*list*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,4,local+15); /*send*/
	local[5] = w;
	if (local[5]==NIL) goto irtdynaIF3343;
	local[15]= local[4];
	local[16]= fqv[230];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,2,local+15); /*list*/
	local[15]= w;
	w = local[6];
	ctx->vsp=local+16;
	local[6] = cons(ctx,local[15],w);
	local[15]= argv[0];
	local[16]= fqv[160];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	local[16]= argv[0];
	local[17]= fqv[68];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[16]= w;
	local[17]= local[4];
	local[18]= fqv[230];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,2,local+17); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	w = local[3];
	ctx->vsp=local+18;
	w=irtdynaFLET3330(ctx,1,local+17,w);
	local[17]= local[1];
	local[18]= local[17];
	if (fqv[231]!=local[18]) goto irtdynaIF3345;
	local[18]= argv[0];
	local[19]= fqv[231];
	local[20]= fqv[232];
	local[21]= fqv[233];
	local[22]= fqv[234];
	local[23]= makeflt(9.9999999999999977795540e-02);
	local[24]= fqv[235];
	local[25]= argv[0];
	local[26]= fqv[30];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,2,local+25); /*send*/
	local[25]= w;
	local[26]= local[4];
	local[27]= fqv[236];
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,2,local+26); /*send*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)VMINUS(ctx,2,local+25); /*v-*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(pointer)SEND(ctx,8,local+18); /*send*/
	local[18]= w;
	goto irtdynaIF3346;
irtdynaIF3345:
	local[18]= local[17];
	if (fqv[221]!=local[18]) goto irtdynaIF3347;
	ctx->vsp=local+18;
	local[18]= makeclosure(codevec,quotevec,irtdynaCLO3349,env,argv,local);
	local[19]= fqv[237];
	ctx->vsp=local+20;
	w=(pointer)MAPCAR(ctx,2,local+18); /*mapcar*/
	local[18]= w;
	local[19]= argv[0];
	local[20]= fqv[238];
	local[21]= local[4];
	local[22]= fqv[236];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,2,local+21); /*send*/
	local[21]= w;
	local[22]= makeint((eusinteger_t)0L);
	ctx->vsp=local+23;
	w=(pointer)ELT(ctx,2,local+21); /*elt*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)MINUS(ctx,1,local+21); /*-*/
	local[21]= w;
	local[22]= local[4];
	local[23]= fqv[236];
	ctx->vsp=local+24;
	w=(pointer)SEND(ctx,2,local+22); /*send*/
	local[22]= w;
	local[23]= makeint((eusinteger_t)1L);
	ctx->vsp=local+24;
	w=(pointer)ELT(ctx,2,local+22); /*elt*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)MINUS(ctx,1,local+22); /*-*/
	local[22]= w;
	local[23]= makeint((eusinteger_t)0L);
	ctx->vsp=local+24;
	w=(pointer)MKFLTVEC(ctx,3,local+21); /*float-vector*/
	local[21]= w;
	local[22]= fqv[239];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,4,local+19); /*send*/
	ctx->vsp=local+19;
	local[19]= makeclosure(codevec,quotevec,irtdynaCLO3350,env,argv,local);
	local[20]= fqv[240];
	local[21]= local[18];
	ctx->vsp=local+22;
	w=(pointer)MAPCAR(ctx,3,local+19); /*mapcar*/
	local[18]= w;
	goto irtdynaIF3348;
irtdynaIF3347:
	local[18]= NIL;
irtdynaIF3348:
irtdynaIF3346:
	w = local[18];
	local[17]= fqv[160];
	local[18]= argv[0];
	local[19]= fqv[160];
	ctx->vsp=local+20;
	w=(pointer)SEND(ctx,2,local+18); /*send*/
	local[18]= w;
	local[19]= fqv[166];
	local[20]= argv[0];
	local[21]= fqv[74];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,2,local+20); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.car;
	local[21]= fqv[68];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,2,local+20); /*send*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)LIST(ctx,4,local+17); /*list*/
	local[17]= w;
	w = local[8];
	ctx->vsp=local+18;
	local[8] = cons(ctx,local[17],w);
	local[17]= argv[0];
	local[18]= fqv[160];
	local[19]= local[15];
	ctx->vsp=local+20;
	w=(pointer)SEND(ctx,3,local+17); /*send*/
	local[17]= argv[0];
	local[18]= fqv[241];
	local[19]= local[16];
	ctx->vsp=local+20;
	w=(pointer)SEND(ctx,3,local+17); /*send*/
	local[15]= w;
	goto irtdynaIF3344;
irtdynaIF3343:
	local[15]= NIL;
irtdynaIF3344:
	w = local[15];
	goto irtdynaWHL3334;
irtdynaWHX3335:
	local[12]= NIL;
irtdynaBLK3336:
	local[12]= local[8];
	ctx->vsp=local+13;
	w=(pointer)REVERSE(ctx,1,local+12); /*reverse*/
	local[8] = w;
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(pointer)REVERSE(ctx,1,local+12); /*reverse*/
	local[6] = w;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w = local[3];
	ctx->vsp=local+13;
	w=irtdynaFLET3330(ctx,1,local+12,w);
	local[12]= makeint((eusinteger_t)0L);
	local[13]= makeint((eusinteger_t)2L);
irtdynaWHL3351:
	local[14]= local[12];
	w = local[13];
	if ((eusinteger_t)local[14] >= (eusinteger_t)w) goto irtdynaWHX3352;
	local[14]= argv[0];
	local[15]= fqv[227];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= local[12];
	ctx->vsp=local+15;
	w=(pointer)ADD1(ctx,1,local+14); /*1+*/
	local[12] = w;
	goto irtdynaWHL3351;
irtdynaWHX3352:
	local[14]= NIL;
irtdynaBLK3353:
	w = NIL;
	local[12]= argv[0];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(*ftab[21])(ctx,1,local+12,&ftab[21],fqv[242]); /*objects*/
	local[12]= argv[2];
	ctx->vsp=local+13;
	w=(pointer)MINUS(ctx,1,local+12); /*-*/
	local[12]= w;
	ctx->vsp=local+13;
	local[13]= makeclosure(codevec,quotevec,irtdynaCLO3354,env,argv,local);
	local[14]= local[8];
	local[15]= local[6];
	ctx->vsp=local+16;
	w=(pointer)MAPCAR(ctx,3,local+13); /*mapcar*/
	local[13]= w;
	ctx->vsp=local+14;
	local[14]= makeclosure(codevec,quotevec,irtdynaCLO3355,env,argv,local);
	local[15]= local[8];
	local[16]= local[13];
	ctx->vsp=local+17;
	w=(pointer)MAPCAR(ctx,3,local+14); /*mapcar*/
	local[0]= w;
irtdynaBLK3326:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3191(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= fqv[120];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[243];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= makeflt(1.0000000000000000208167e-03);
	local[1]= argv[2];
	local[2]= fqv[5];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)SCALEVEC(ctx,2,local+0); /*scale*/
	local[0]= w;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+0); /*v**/
	local[0]= w;
	local[1]= argv[2];
	local[2]= fqv[120];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[244];
	local[3]= argv[1];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)VPLUS(ctx,2,local+3); /*v+*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3212(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[181];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3213(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[46];
	local[2]= fqv[136];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[46];
	local[2]= fqv[134];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3217(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[243];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[244];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3221(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[181];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaFLET3224(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= makeflt(5.0000000000000000000000e-01);
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)AREF(ctx,3,local+1); /*aref*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= makeint((eusinteger_t)1L);
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)AREF(ctx,3,local+2); /*aref*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= makeint((eusinteger_t)2L);
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,3,local+3); /*aref*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,4,local+1); /*+*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)ABS(ctx,1,local+1); /*abs*/
	local[1]= w;
	local[2]= makeflt(0.0000000000000000000000e+00);
	local[3]= makeflt(9.9999999999999949376344e-21);
	ctx->vsp=local+4;
	w=(*ftab[4])(ctx,3,local+1,&ftab[4],fqv[22]); /*eps=*/
	if (w==NIL) goto irtdynaIF3356;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,3,local+1); /*float-vector*/
	local[1]= w;
	goto irtdynaIF3357;
irtdynaIF3356:
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(*ftab[22])(ctx,1,local+1,&ftab[22],fqv[245]); /*acos*/
	local[1]= w;
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(pointer)SIN(ctx,1,local+2); /*sin*/
	local[2]= w;
	local[3]= local[2];
	local[4]= makeflt(9.9999999999999949376344e-21);
	ctx->vsp=local+5;
	w=(pointer)LESSP(ctx,2,local+3); /*<*/
	if (w==NIL) goto irtdynaIF3358;
	local[3]= local[1];
	local[4]= makeflt(5.0000000000000000000000e-01);
	local[5]= argv[0];
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,3,local+5); /*aref*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SQRT(ctx,1,local+3); /*sqrt*/
	local[3]= w;
	local[4]= local[1];
	local[5]= makeflt(5.0000000000000000000000e-01);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,2,local+6); /*+*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SQRT(ctx,1,local+4); /*sqrt*/
	local[4]= w;
	local[5]= local[1];
	local[6]= makeflt(5.0000000000000000000000e-01);
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)2L);
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,2,local+7); /*+*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SQRT(ctx,1,local+5); /*sqrt*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[3]= w;
	goto irtdynaIF3359;
irtdynaIF3358:
	local[3]= makeflt(-5.0000000000000000000000e-01);
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	local[4]= local[3];
	local[5]= argv[0];
	local[6]= makeint((eusinteger_t)1L);
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,3,local+5); /*aref*/
	local[5]= w;
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	local[5]= local[3];
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	local[6]= local[3];
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= makeint((eusinteger_t)1L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,2,local+7); /*-*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,3,local+4); /*float-vector*/
	local[3]= w;
irtdynaIF3359:
	w = local[3];
	local[1]= w;
irtdynaIF3357:
	w = local[1];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3248(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[91];
	local[2]= argv[0];
	local[3]= fqv[120];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3251(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	w=(*ftab[23])(ctx,0,local+0,&ftab[23],fqv[246]); /*make-coords*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3252(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[43]);
	local[1]= argv[0];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)CONCATENATE(ctx,3,local+0); /*concatenate*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3268(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[243];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[244];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3284(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[43]);
	local[1]= argv[0];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)CONCATENATE(ctx,3,local+0); /*concatenate*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3304(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= fqv[155];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[77];
	local[3]= fqv[2];
	local[4]= *(ovafptr(argv[0],fqv[60]));
	local[5]= local[4];
	if (fqv[61]!=local[5]) goto irtdynaIF3360;
	local[5]= fqv[247];
	goto irtdynaIF3361;
irtdynaIF3360:
	local[5]= local[4];
	if (fqv[63]!=local[5]) goto irtdynaIF3362;
	local[5]= fqv[248];
	goto irtdynaIF3363;
irtdynaIF3362:
	local[5]= local[4];
	if (fqv[65]!=local[5]) goto irtdynaIF3364;
	local[5]= fqv[249];
	goto irtdynaIF3365;
irtdynaIF3364:
	local[5]= local[4];
	if (fqv[62]!=local[5]) goto irtdynaIF3366;
	local[5]= fqv[250];
	goto irtdynaIF3367;
irtdynaIF3366:
	local[5]= local[4];
	if (fqv[64]!=local[5]) goto irtdynaIF3368;
	local[5]= fqv[251];
	goto irtdynaIF3369;
irtdynaIF3368:
	local[5]= local[4];
	if (fqv[66]!=local[5]) goto irtdynaIF3370;
	local[5]= fqv[252];
	goto irtdynaIF3371;
irtdynaIF3370:
	if (T==NIL) goto irtdynaIF3372;
	local[5]= *(ovafptr(argv[0],fqv[60]));
	goto irtdynaIF3373;
irtdynaIF3372:
	local[5]= NIL;
irtdynaIF3373:
irtdynaIF3371:
irtdynaIF3369:
irtdynaIF3367:
irtdynaIF3365:
irtdynaIF3363:
irtdynaIF3361:
	w = local[5];
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[2]= w;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)VINNERPRODUCT(ctx,2,local+2); /*v.*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[22])(ctx,1,local+2,&ftab[22],fqv[245]); /*acos*/
	local[2]= w;
	local[3]= local[2];
	local[4]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(*ftab[4])(ctx,2,local+3,&ftab[4],fqv[22]); /*eps=*/
	if (w==NIL) goto irtdynaIF3374;
	local[3]= makeint((eusinteger_t)3L);
	ctx->vsp=local+4;
	w=(*ftab[14])(ctx,1,local+3,&ftab[14],fqv[184]); /*unit-matrix*/
	local[3]= w;
	goto irtdynaIF3375;
irtdynaIF3374:
	local[3]= local[2];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[0];
	local[7]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+8;
	w=(pointer)GREATERP(ctx,2,local+6); /*>*/
	if (w==NIL) goto irtdynaIF3376;
	local[6]= makeflt(1.0000000000000000000000e+00);
	goto irtdynaIF3377;
irtdynaIF3376:
	local[6]= makeflt(-1.0000000000000000000000e+00);
irtdynaIF3377:
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,3,local+4); /*float-vector*/
	local[4]= w;
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+4); /*v**/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ROTATION_MATRIX(ctx,2,local+3); /*rotation-matrix*/
	local[3]= w;
irtdynaIF3375:
	local[4]= env->c.clo.env2[1];
	local[5]= env->c.clo.env2[3];
	if (local[3]!=NIL) goto irtdynaIF3378;
	local[6]= makeint((eusinteger_t)3L);
	ctx->vsp=local+7;
	w=(*ftab[14])(ctx,1,local+6,&ftab[14],fqv[184]); /*unit-matrix*/
	local[3] = w;
	local[6]= local[3];
	goto irtdynaIF3379;
irtdynaIF3378:
	local[6]= NIL;
irtdynaIF3379:
	if (env->c.clo.env2[5]==NIL) goto irtdynaIF3380;
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)ABS(ctx,1,local+6); /*abs*/
	local[6]= w;
	local[7]= env->c.clo.env2[5];
	ctx->vsp=local+8;
	w=(pointer)GREATERP(ctx,2,local+6); /*>*/
	if (w==NIL) goto irtdynaIF3380;
	local[6]= makeint((eusinteger_t)2L);
	local[7]= env->c.clo.env2[1];
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	env->c.clo.env2[1] = w;
	env->c.clo.env2[3] = env->c.clo.env2[4];
	local[6]= env->c.clo.env2[3];
	goto irtdynaIF3381;
irtdynaIF3380:
	local[6]= NIL;
irtdynaIF3381:
	local[6]= env->c.clo.env1[2];
	local[7]= fqv[217];
	local[8]= fqv[253];
	local[9]= env->c.clo.env2[1];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= env->c.clo.env1[2];
	local[7]= fqv[217];
	local[8]= fqv[106];
	local[9]= env->c.clo.env2[3];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= env->c.clo.env1[2];
	local[7]= fqv[254];
	local[8]= fqv[255];
	local[9]= argv[0];
	local[10]= fqv[77];
	local[11]= fqv[5];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	local[10]= fqv[256];
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(*ftab[23])(ctx,4,local+8,&ftab[23],fqv[246]); /*make-coords*/
	local[8]= w;
	local[9]= fqv[257];
	local[10]= env->c.clo.env2[2];
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(pointer)ABS(ctx,1,local+11); /*abs*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	local[11]= fqv[258];
	local[12]= T;
	local[13]= fqv[259];
	local[14]= makeint((eusinteger_t)330L);
	ctx->vsp=local+15;
	w=(*ftab[24])(ctx,1,local+14,&ftab[24],fqv[260]); /*deg2rad*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,9,local+6); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaFLET3330(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[160];
	local[2]= fqv[160];
	w = argv[0];
	w=memq(local[2],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[261];
	local[2]= fqv[166];
	w = argv[0];
	w=memq(local[2],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= env->c.clo.env1[0];
	local[4]= fqv[74];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3349(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= argv[0];
	local[2]= fqv[262];
	local[3]= fqv[68];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3350(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= argv[0];
	local[2]= fqv[263];
	local[3]= argv[1];
	local[4]= fqv[264];
	local[5]= makeflt(9.9999999999999977795540e-02);
	local[6]= fqv[265];
	local[7]= makeflt(9.9999999999999977795540e-02);
	ctx->vsp=local+8;
	w=(*ftab[24])(ctx,1,local+7,&ftab[24],fqv[260]); /*deg2rad*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,8,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3354(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	w = env->c.clo.env2[3];
	ctx->vsp=local+1;
	w=irtdynaFLET3330(ctx,1,local+0,w);
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[227];
	local[2]= env->c.clo.env1[0];
	local[3]= fqv[160];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= env->c.clo.env1[0];
	local[4]= fqv[68];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= fqv[167];
	local[5]= env->c.clo.env1[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,6,local+0); /*send*/
	local[0]= w;
	local[1]= loadglobal(fqv[266]);
	local[2]= fqv[267];
	local[3]= fqv[218];
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[268];
	local[3]= fqv[218];
	local[4]= NIL;
	local[5]= fqv[108];
	local[6]= makeint((eusinteger_t)400L);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	local[1]= env->c.clo.env1[0];
	local[2]= fqv[30];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[268];
	local[3]= fqv[218];
	local[4]= NIL;
	local[5]= fqv[108];
	local[6]= makeint((eusinteger_t)300L);
	local[7]= fqv[106];
	local[8]= fqv[269];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,8,local+1); /*send*/
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[268];
	local[3]= fqv[218];
	local[4]= NIL;
	local[5]= fqv[108];
	local[6]= makeint((eusinteger_t)400L);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	local[1]= local[0];
	local[2]= fqv[268];
	local[3]= fqv[218];
	local[4]= T;
	local[5]= fqv[108];
	local[6]= makeint((eusinteger_t)300L);
	local[7]= fqv[106];
	local[8]= fqv[270];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,8,local+1); /*send*/
	ctx->vsp=local+1;
	w=(*ftab[25])(ctx,0,local+1,&ftab[25],fqv[271]); /*x::window-main-one*/
	local[1]= makeint((eusinteger_t)10000L);
	ctx->vsp=local+2;
	w=(*ftab[26])(ctx,1,local+1,&ftab[26],fqv[272]); /*unix:usleep*/
	local[1]= env->c.clo.env2[12];
	local[2]= env->c.clo.env1[2];
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,2,local+1); /*+*/
	env->c.clo.env2[12] = w;
	local[1]= fqv[273];
	local[2]= env->c.clo.env2[12];
	local[3]= fqv[274];
	local[4]= local[0];
	local[5]= fqv[275];
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	local[7]= fqv[276];
	local[8]= env->c.clo.env1[0];
	local[9]= fqv[30];
	local[10]= NIL;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	local[9]= fqv[277];
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	ctx->vsp=local+11;
	w=(*ftab[27])(ctx,1,local+10,&ftab[27],fqv[278]); /*cadddr*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,10,local+1); /*list*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3355(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)APPEND(ctx,2,local+0); /*append*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtdynaM3382riccati_equation_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=7) maerror();
	argv[0]->c.obj.iv[1] = argv[2];
	argv[0]->c.obj.iv[2] = argv[3];
	argv[0]->c.obj.iv[3] = argv[4];
	argv[0]->c.obj.iv[5] = argv[5];
	argv[0]->c.obj.iv[6] = argv[6];
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(*ftab[28])(ctx,2,local+0,&ftab[28],fqv[279]); /*array-dimension*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(*ftab[28])(ctx,2,local+1,&ftab[28],fqv[279]); /*array-dimension*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[5])(ctx,2,local+0,&ftab[5],fqv[24]); /*make-matrix*/
	argv[0]->c.obj.iv[4] = w;
	w = argv[0]->c.obj.iv[4];
	local[0]= w;
irtdynaBLK3383:
	ctx->vsp=local; return(local[0]);}

/*:solve*/
static pointer irtdynaM3384riccati_equation_solve(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)TRANSPOSE(ctx,1,local+1); /*transpose*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+3;
	w=(pointer)TRANSPOSE(ctx,1,local+2); /*transpose*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+4;
	w=(pointer)TRANSPOSE(ctx,1,local+3); /*transpose*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(*ftab[28])(ctx,2,local+4,&ftab[28],fqv[279]); /*array-dimension*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[3];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(*ftab[28])(ctx,2,local+5,&ftab[28],fqv[279]); /*array-dimension*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[5])(ctx,2,local+4,&ftab[5],fqv[24]); /*make-matrix*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)0L);
irtdynaTAG3387:
	local[6]= local[5];
	local[7]= makeint((eusinteger_t)10000L);
	ctx->vsp=local+8;
	w=(pointer)GREQP(ctx,2,local+6); /*>=*/
	if (w==NIL) goto irtdynaIF3388;
	w = NIL;
	ctx->vsp=local+6;
	local[5]=w;
	goto irtdynaBLK3386;
	goto irtdynaIF3389;
irtdynaIF3388:
	local[6]= NIL;
irtdynaIF3389:
	local[6]= argv[0]->c.obj.iv[4];
	local[7]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+8;
	w=(pointer)MATTIMES(ctx,2,local+6); /*m**/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[6];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(*ftab[28])(ctx,2,local+8,&ftab[28],fqv[279]); /*array-dimension*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[14])(ctx,1,local+8,&ftab[14],fqv[184]); /*unit-matrix*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[2])(ctx,2,local+7,&ftab[2],fqv[4]); /*scale-matrix*/
	local[7]= w;
	local[8]= local[2];
	local[9]= argv[0]->c.obj.iv[4];
	local[10]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+11;
	w=(pointer)MATTIMES(ctx,2,local+9); /*m**/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MATTIMES(ctx,2,local+8); /*m**/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[6])(ctx,2,local+7,&ftab[6],fqv[27]); /*m+*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[17])(ctx,1,local+7,&ftab[17],fqv[187]); /*inverse-matrix*/
	argv[0]->c.obj.iv[9] = w;
	local[7]= argv[0]->c.obj.iv[9];
	local[8]= local[2];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)MATTIMES(ctx,2,local+8); /*m**/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MATTIMES(ctx,2,local+7); /*m**/
	argv[0]->c.obj.iv[7] = w;
	local[7]= local[1];
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)MATTIMES(ctx,2,local+7); /*m**/
	local[7]= w;
	local[8]= local[3];
	local[9]= argv[0]->c.obj.iv[5];
	local[10]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+11;
	w=(*ftab[2])(ctx,2,local+9,&ftab[2],fqv[4]); /*scale-matrix*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MATTIMES(ctx,2,local+8); /*m**/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[6])(ctx,2,local+7,&ftab[6],fqv[27]); /*m+*/
	local[7]= w;
	local[8]= local[1];
	local[9]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+10;
	w=(pointer)MATTIMES(ctx,2,local+8); /*m**/
	local[8]= w;
	local[9]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+10;
	w=(pointer)MATTIMES(ctx,2,local+8); /*m**/
	local[8]= w;
	local[9]= argv[0]->c.obj.iv[7];
	ctx->vsp=local+10;
	w=(pointer)MATTIMES(ctx,2,local+8); /*m**/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[16])(ctx,2,local+7,&ftab[16],fqv[186]); /*m-*/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[4];
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(*ftab[16])(ctx,2,local+8,&ftab[16],fqv[186]); /*m-*/
	local[0] = w;
	local[8]= local[0]->c.obj.iv[1];
	local[9]= local[4]->c.obj.iv[1];
	local[10]= loadglobal(fqv[280]);
	local[11]= makeflt(9.9999999999999950039964e-03);
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[29])(ctx,3,local+8,&ftab[29],fqv[281]); /*eps-v=*/
	if (w==NIL) goto irtdynaIF3390;
	local[8]= argv[0]->c.obj.iv[1];
	local[9]= argv[0]->c.obj.iv[2];
	local[10]= argv[0]->c.obj.iv[7];
	ctx->vsp=local+11;
	w=(pointer)MATTIMES(ctx,2,local+9); /*m**/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[16])(ctx,2,local+8,&ftab[16],fqv[186]); /*m-*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)TRANSPOSE(ctx,1,local+8); /*transpose*/
	argv[0]->c.obj.iv[8] = w;
	local[8]= argv[0]->c.obj.iv[4];
	local[9]= argv[0]->c.obj.iv[7];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,2,local+8); /*list*/
	ctx->vsp=local+8;
	local[0]=w;
	goto irtdynaBLK3385;
	goto irtdynaIF3391;
irtdynaIF3390:
	local[8]= NIL;
irtdynaIF3391:
	argv[0]->c.obj.iv[4] = local[7];
	w = argv[0]->c.obj.iv[4];
	local[6]= local[5];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[6]= w;
	local[5] = local[6];
	w = NIL;
	ctx->vsp=local+6;
	goto irtdynaTAG3387;
	w = NIL;
	local[5]= w;
irtdynaBLK3386:
	local[5]= fqv[282];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(*ftab[0])(ctx,2,local+5,&ftab[0],fqv[1]); /*warn*/
	local[0]= w;
irtdynaBLK3385:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtdynaM3392preview_controller_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[283], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3394;
	local[0] = NIL;
irtdynaKEY3394:
	if (n & (1<<1)) goto irtdynaKEY3395;
	local[1] = NIL;
irtdynaKEY3395:
	if (n & (1<<2)) goto irtdynaKEY3396;
	local[2] = NIL;
irtdynaKEY3396:
	if (n & (1<<3)) goto irtdynaKEY3397;
	local[3] = NIL;
irtdynaKEY3397:
	if (n & (1<<4)) goto irtdynaKEY3398;
	local[4] = NIL;
irtdynaKEY3398:
	if (n & (1<<5)) goto irtdynaKEY3399;
	local[5] = NIL;
irtdynaKEY3399:
	if (n & (1<<6)) goto irtdynaKEY3400;
	local[12]= local[3];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(*ftab[28])(ctx,2,local+12,&ftab[28],fqv[279]); /*array-dimension*/
	local[6] = w;
irtdynaKEY3400:
	if (n & (1<<7)) goto irtdynaKEY3401;
	local[12]= local[5];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(*ftab[28])(ctx,2,local+12,&ftab[28],fqv[279]); /*array-dimension*/
	local[7] = w;
irtdynaKEY3401:
	if (n & (1<<8)) goto irtdynaKEY3402;
	local[12]= local[4];
	local[13]= makeint((eusinteger_t)1L);
	ctx->vsp=local+14;
	w=(*ftab[28])(ctx,2,local+12,&ftab[28],fqv[279]); /*array-dimension*/
	local[8] = w;
irtdynaKEY3402:
	if (n & (1<<9)) goto irtdynaKEY3403;
	local[12]= loadglobal(fqv[43]);
	local[13]= local[3];
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(*ftab[28])(ctx,2,local+13,&ftab[28],fqv[279]); /*array-dimension*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)INSTANTIATE(ctx,2,local+12); /*instantiate*/
	local[9] = w;
irtdynaKEY3403:
	if (n & (1<<10)) goto irtdynaKEY3404;
	local[12]= local[4];
	local[13]= makeint((eusinteger_t)1L);
	ctx->vsp=local+14;
	w=(*ftab[28])(ctx,2,local+12,&ftab[28],fqv[279]); /*array-dimension*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)1L);
	ctx->vsp=local+14;
	w=(*ftab[5])(ctx,2,local+12,&ftab[5],fqv[24]); /*make-matrix*/
	local[10] = w;
irtdynaKEY3404:
	if (n & (1<<11)) goto irtdynaKEY3405;
	local[11] = NIL;
irtdynaKEY3405:
	local[12]= local[2];
	local[13]= argv[2];
	ctx->vsp=local+14;
	w=(pointer)QUOTIENT(ctx,2,local+12); /*/*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)ROUND(ctx,1,local+12); /*round*/
	argv[0]->c.obj.iv[12] = w;
	argv[0]->c.obj.iv[16] = local[11];
	argv[0]->c.obj.iv[20] = local[7];
	argv[0]->c.obj.iv[21] = local[8];
	local[12]= argv[0];
	local[13]= *(ovafptr(argv[1],fqv[284]));
	local[14]= fqv[223];
	local[15]= local[3];
	local[16]= local[4];
	local[17]= local[5];
	local[18]= local[0];
	local[19]= local[1];
	ctx->vsp=local+20;
	w=(pointer)SENDMESSAGE(ctx,8,local+12); /*send-message*/
	argv[0]->c.obj.iv[15] = makeint((eusinteger_t)0L);
	if (argv[0]->c.obj.iv[10]!=NIL) goto irtdynaIF3406;
	local[12]= local[6];
	local[13]= makeint((eusinteger_t)1L);
	ctx->vsp=local+14;
	w=(*ftab[5])(ctx,2,local+12,&ftab[5],fqv[24]); /*make-matrix*/
	argv[0]->c.obj.iv[10] = w;
	local[12]= makeint((eusinteger_t)0L);
	local[13]= local[6];
irtdynaWHL3408:
	local[14]= local[12];
	w = local[13];
	if ((eusinteger_t)local[14] >= (eusinteger_t)w) goto irtdynaWHX3409;
	local[14]= argv[0]->c.obj.iv[10];
	local[15]= local[12];
	local[16]= makeint((eusinteger_t)0L);
	local[17]= local[9];
	local[18]= local[12];
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)ASET(ctx,4,local+14); /*aset*/
	local[14]= local[12];
	ctx->vsp=local+15;
	w=(pointer)ADD1(ctx,1,local+14); /*1+*/
	local[12] = w;
	goto irtdynaWHL3408;
irtdynaWHX3409:
	local[14]= NIL;
irtdynaBLK3410:
	w = NIL;
	local[12]= w;
	goto irtdynaIF3407;
irtdynaIF3406:
	local[12]= NIL;
irtdynaIF3407:
	argv[0]->c.obj.iv[11] = local[10];
	local[12]= argv[0];
	local[13]= fqv[285];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= argv[0];
	local[13]= fqv[286];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	w = argv[0];
	local[0]= w;
irtdynaBLK3393:
	ctx->vsp=local; return(local[0]);}

/*:calc-f*/
static pointer irtdynaM3411preview_controller_calc_f(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[21];
	local[1]= argv[0]->c.obj.iv[20];
	local[2]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[5])(ctx,2,local+0,&ftab[5],fqv[24]); /*make-matrix*/
	argv[0]->c.obj.iv[13] = w;
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(*ftab[28])(ctx,2,local+0,&ftab[28],fqv[279]); /*array-dimension*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[14])(ctx,1,local+0,&ftab[14],fqv[184]); /*unit-matrix*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(pointer)TRANSPOSE(ctx,1,local+1); /*transpose*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+3;
	w=(pointer)TRANSPOSE(ctx,1,local+2); /*transpose*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[0]->c.obj.iv[12];
irtdynaWHL3413:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto irtdynaWHX3414;
	local[5]= argv[0]->c.obj.iv[5];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(*ftab[2])(ctx,2,local+5,&ftab[2],fqv[4]); /*scale-matrix*/
	local[5]= w;
	local[6]= argv[0]->c.obj.iv[9];
	local[7]= local[1];
	local[8]= local[0];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)MATTIMES(ctx,2,local+8); /*m**/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MATTIMES(ctx,2,local+7); /*m**/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MATTIMES(ctx,2,local+6); /*m**/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[8];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)MATTIMES(ctx,2,local+7); /*m**/
	local[0] = w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= argv[0]->c.obj.iv[21];
irtdynaWHL3416:
	local[9]= local[7];
	w = local[8];
	if ((eusinteger_t)local[9] >= (eusinteger_t)w) goto irtdynaWHX3417;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= argv[0]->c.obj.iv[20];
irtdynaWHL3419:
	local[11]= local[9];
	w = local[10];
	if ((eusinteger_t)local[11] >= (eusinteger_t)w) goto irtdynaWHX3420;
	local[11]= argv[0]->c.obj.iv[13];
	local[12]= local[7];
	local[13]= argv[0]->c.obj.iv[20];
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)ADD1(ctx,1,local+14); /*1+*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)TIMES(ctx,2,local+13); /***/
	local[13]= w;
	local[14]= local[9];
	ctx->vsp=local+15;
	w=(pointer)PLUS(ctx,2,local+13); /*+*/
	local[13]= w;
	local[14]= local[6];
	local[15]= local[7];
	local[16]= local[9];
	ctx->vsp=local+17;
	w=(pointer)AREF(ctx,3,local+14); /*aref*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)ASET(ctx,4,local+11); /*aset*/
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[9] = w;
	goto irtdynaWHL3419;
irtdynaWHX3420:
	local[11]= NIL;
irtdynaBLK3421:
	w = NIL;
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[7] = w;
	goto irtdynaWHL3416;
irtdynaWHX3417:
	local[9]= NIL;
irtdynaBLK3418:
	w = NIL;
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto irtdynaWHL3413;
irtdynaWHX3414:
	local[5]= NIL;
irtdynaBLK3415:
	w = NIL;
	local[0]= w;
irtdynaBLK3412:
	ctx->vsp=local; return(local[0]);}

/*:calc-u*/
static pointer irtdynaM3422preview_controller_calc_u(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[13];
	local[1]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+2;
	w=(pointer)MATTIMES(ctx,2,local+0); /*m**/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[7];
	local[2]= argv[0]->c.obj.iv[10];
	ctx->vsp=local+3;
	w=(pointer)MATTIMES(ctx,2,local+1); /*m**/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[186]); /*m-*/
	argv[0]->c.obj.iv[11] = w;
	w = argv[0]->c.obj.iv[11];
	local[0]= w;
irtdynaBLK3423:
	ctx->vsp=local; return(local[0]);}

/*:calc-xk*/
static pointer irtdynaM3424preview_controller_calc_xk(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[0]->c.obj.iv[10];
	ctx->vsp=local+2;
	w=(pointer)MATTIMES(ctx,2,local+0); /*m**/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= argv[0];
	local[3]= fqv[287];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MATTIMES(ctx,2,local+1); /*m**/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,2,local+0,&ftab[6],fqv[27]); /*m+*/
	argv[0]->c.obj.iv[10] = w;
	w = argv[0]->c.obj.iv[10];
	local[0]= w;
irtdynaBLK3425:
	ctx->vsp=local; return(local[0]);}

/*:update-xk*/
static pointer irtdynaM3426preview_controller_update_xk(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtdynaENT3429;}
	local[0]= NIL;
irtdynaENT3429:
irtdynaENT3428:
	if (n>4) maerror();
	if (argv[2]==NIL) goto irtdynaIF3430;
	if (argv[0]->c.obj.iv[19]!=NIL) goto irtdynaIF3432;
	local[1]= argv[0]->c.obj.iv[15];
	ctx->vsp=local+2;
	w=(pointer)ADD1(ctx,1,local+1); /*1+*/
	argv[0]->c.obj.iv[15] = w;
	local[1]= argv[0]->c.obj.iv[15];
	local[2]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)GREQP(ctx,2,local+1); /*>=*/
	argv[0]->c.obj.iv[19] = w;
	local[1]= argv[0]->c.obj.iv[19];
	goto irtdynaIF3433;
irtdynaIF3432:
	local[1]= NIL;
irtdynaIF3433:
	if (argv[0]->c.obj.iv[14]!=NIL) goto irtdynaIF3434;
	local[1]= argv[0]->c.obj.iv[20];
	local[2]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(*ftab[5])(ctx,2,local+1,&ftab[5],fqv[24]); /*make-matrix*/
	argv[0]->c.obj.iv[14] = w;
	local[1]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+2;
	w=(pointer)ADD1(ctx,1,local+1); /*1+*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[18])(ctx,1,local+1,&ftab[18],fqv[198]); /*make-list*/
	argv[0]->c.obj.iv[17] = w;
	if (argv[0]->c.obj.iv[16]==NIL) goto irtdynaIF3436;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[2]= w;
irtdynaWHL3438:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto irtdynaWHX3439;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[0]->c.obj.iv[20];
irtdynaWHL3441:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto irtdynaWHX3442;
	local[5]= argv[0]->c.obj.iv[14];
	local[6]= argv[0]->c.obj.iv[20];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,2,local+6); /*+*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= argv[2];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)ASET(ctx,4,local+5); /*aset*/
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto irtdynaWHL3441;
irtdynaWHX3442:
	local[5]= NIL;
irtdynaBLK3443:
	w = NIL;
	local[3]= argv[0]->c.obj.iv[17];
	local[4]= local[1];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SETELT(ctx,3,local+3); /*setelt*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto irtdynaWHL3438;
irtdynaWHX3439:
	local[3]= NIL;
irtdynaBLK3440:
	w = NIL;
	local[1]= w;
	goto irtdynaIF3437;
irtdynaIF3436:
	local[1]= NIL;
irtdynaIF3437:
	goto irtdynaIF3435;
irtdynaIF3434:
	local[1]= NIL;
irtdynaIF3435:
	if (argv[0]->c.obj.iv[16]!=NIL) goto irtdynaIF3444;
	local[1]= argv[0]->c.obj.iv[15];
	local[2]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LESSP(ctx,2,local+1); /*<*/
	if (w==NIL) goto irtdynaIF3446;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[20];
irtdynaWHL3448:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto irtdynaWHX3449;
	local[3]= argv[0]->c.obj.iv[14];
	local[4]= argv[0]->c.obj.iv[20];
	local[5]= argv[0]->c.obj.iv[15];
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[2];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ASET(ctx,4,local+3); /*aset*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto irtdynaWHL3448;
irtdynaWHX3449:
	local[3]= NIL;
irtdynaBLK3450:
	w = NIL;
	local[1]= argv[0]->c.obj.iv[17];
	local[2]= argv[0]->c.obj.iv[15];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SETELT(ctx,3,local+1); /*setelt*/
	w = NIL;
	ctx->vsp=local+1;
	local[0]=w;
	goto irtdynaBLK3427;
	goto irtdynaIF3447;
irtdynaIF3446:
	local[1]= NIL;
irtdynaIF3447:
	goto irtdynaIF3445;
irtdynaIF3444:
	local[1]= NIL;
irtdynaIF3445:
	goto irtdynaIF3431;
irtdynaIF3430:
	local[1]= argv[0]->c.obj.iv[15];
	ctx->vsp=local+2;
	w=(pointer)SUB1(ctx,1,local+1); /*1-*/
	argv[0]->c.obj.iv[15] = w;
	local[1]= argv[0];
	local[2]= fqv[288];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	argv[2] = w;
	local[1]= argv[0]->c.obj.iv[15];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)LSEQP(ctx,2,local+1); /*<=*/
	if (w==NIL) goto irtdynaIF3451;
	argv[0]->c.obj.iv[18] = T;
	local[1]= argv[0]->c.obj.iv[18];
	goto irtdynaIF3452;
irtdynaIF3451:
	local[1]= NIL;
irtdynaIF3452:
irtdynaIF3431:
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[12];
irtdynaWHL3453:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto irtdynaWHX3454;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[0]->c.obj.iv[20];
irtdynaWHL3456:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto irtdynaWHX3457;
	local[5]= argv[0]->c.obj.iv[14];
	local[6]= argv[0]->c.obj.iv[20];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,2,local+6); /*+*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= argv[0]->c.obj.iv[14];
	local[9]= argv[0]->c.obj.iv[20];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)ASET(ctx,4,local+5); /*aset*/
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto irtdynaWHL3456;
irtdynaWHX3457:
	local[5]= NIL;
irtdynaBLK3458:
	w = NIL;
	local[3]= argv[0]->c.obj.iv[17];
	local[4]= local[1];
	local[5]= argv[0]->c.obj.iv[17];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SETELT(ctx,3,local+3); /*setelt*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto irtdynaWHL3453;
irtdynaWHX3454:
	local[3]= NIL;
irtdynaBLK3455:
	w = NIL;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[20];
irtdynaWHL3459:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto irtdynaWHX3460;
	local[3]= argv[0]->c.obj.iv[14];
	local[4]= argv[0]->c.obj.iv[20];
	local[5]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[2];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ASET(ctx,4,local+3); /*aset*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto irtdynaWHL3459;
irtdynaWHX3460:
	local[3]= NIL;
irtdynaBLK3461:
	w = NIL;
	local[1]= argv[0]->c.obj.iv[17];
	local[2]= argv[0]->c.obj.iv[12];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SETELT(ctx,3,local+1); /*setelt*/
	local[1]= argv[0];
	local[2]= fqv[289];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (argv[0]->c.obj.iv[19]==NIL) goto irtdynaIF3462;
	if (argv[0]->c.obj.iv[18]!=NIL) goto irtdynaIF3462;
	local[1]= argv[0];
	local[2]= fqv[290];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[291];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[292];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,3,local+1); /*list*/
	local[1]= w;
	goto irtdynaIF3463;
irtdynaIF3462:
	local[1]= NIL;
irtdynaIF3463:
	w = local[1];
	local[0]= w;
irtdynaBLK3427:
	ctx->vsp=local; return(local[0]);}

/*:finishedp*/
static pointer irtdynaM3464preview_controller_finishedp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[18];
	local[0]= w;
irtdynaBLK3465:
	ctx->vsp=local; return(local[0]);}

/*:last-reference-output-vector*/
static pointer irtdynaM3466preview_controller_last_reference_output_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[14];
	local[1]= argv[0]->c.obj.iv[20];
	local[2]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[20];
	local[3]= argv[0]->c.obj.iv[20];
	local[4]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SUBSEQ(ctx,3,local+0); /*subseq*/
	local[0]= w;
irtdynaBLK3467:
	ctx->vsp=local; return(local[0]);}

/*:current-reference-output-vector*/
static pointer irtdynaM3468preview_controller_current_reference_output_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[14];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+3;
	w=(pointer)SUBSEQ(ctx,3,local+0); /*subseq*/
	local[0]= w;
irtdynaBLK3469:
	ctx->vsp=local; return(local[0]);}

/*:current-state-vector*/
static pointer irtdynaM3470preview_controller_current_state_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[10];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(*ftab[30])(ctx,2,local+0,&ftab[30],fqv[293]); /*matrix-column*/
	local[0]= w;
irtdynaBLK3471:
	ctx->vsp=local; return(local[0]);}

/*:current-output-vector*/
static pointer irtdynaM3472preview_controller_current_output_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= argv[0]->c.obj.iv[10];
	ctx->vsp=local+2;
	w=(pointer)MATTIMES(ctx,2,local+0); /*m**/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(*ftab[30])(ctx,2,local+0,&ftab[30],fqv[293]); /*matrix-column*/
	local[0]= w;
irtdynaBLK3473:
	ctx->vsp=local; return(local[0]);}

/*:current-additional-data*/
static pointer irtdynaM3474preview_controller_current_additional_data(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[17];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
irtdynaBLK3475:
	ctx->vsp=local; return(local[0]);}

/*:pass-preview-controller*/
static pointer irtdynaM3476preview_controller_pass_preview_controller(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= NIL;
irtdynaWHL3478:
	local[2]= argv[0];
	local[3]= fqv[229];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[4];
	local[4]= w;
	local[5]= NIL;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[0] = w;
	if (local[0]!=NIL) goto irtdynaWHX3479;
	goto irtdynaWHL3478;
irtdynaWHX3479:
	local[2]= NIL;
irtdynaBLK3480:
	local[2]= local[0];
	w = local[1];
	ctx->vsp=local+3;
	local[1] = cons(ctx,local[2],w);
irtdynaWHL3481:
	local[2]= argv[0];
	local[3]= fqv[229];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[4];
	local[4]= w;
	local[5]= NIL;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[0] = w;
	if (local[0]==NIL) goto irtdynaWHX3482;
	local[2]= local[0];
	w = local[1];
	ctx->vsp=local+3;
	local[1] = cons(ctx,local[2],w);
	goto irtdynaWHL3481;
irtdynaWHX3482:
	local[2]= NIL;
irtdynaBLK3483:
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(pointer)REVERSE(ctx,1,local+2); /*reverse*/
	local[0]= w;
irtdynaBLK3477:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtdynaM3484extended_preview_controller_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[294], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3486;
	local[0] = NIL;
irtdynaKEY3486:
	if (n & (1<<1)) goto irtdynaKEY3487;
	local[1] = NIL;
irtdynaKEY3487:
	if (n & (1<<2)) goto irtdynaKEY3488;
	local[2] = NIL;
irtdynaKEY3488:
	if (n & (1<<3)) goto irtdynaKEY3489;
	local[3] = NIL;
irtdynaKEY3489:
	if (n & (1<<4)) goto irtdynaKEY3490;
	local[4] = NIL;
irtdynaKEY3490:
	if (n & (1<<5)) goto irtdynaKEY3491;
	local[5] = NIL;
irtdynaKEY3491:
	if (n & (1<<6)) goto irtdynaKEY3492;
	local[11]= loadglobal(fqv[43]);
	local[12]= local[3];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(*ftab[28])(ctx,2,local+12,&ftab[28],fqv[279]); /*array-dimension*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)INSTANTIATE(ctx,2,local+11); /*instantiate*/
	local[6] = w;
irtdynaKEY3492:
	if (n & (1<<7)) goto irtdynaKEY3493;
	local[11]= local[4];
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(*ftab[28])(ctx,2,local+11,&ftab[28],fqv[279]); /*array-dimension*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(*ftab[5])(ctx,2,local+11,&ftab[5],fqv[24]); /*make-matrix*/
	local[7] = w;
irtdynaKEY3493:
	if (n & (1<<8)) goto irtdynaKEY3494;
	local[11]= local[3];
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(*ftab[28])(ctx,2,local+11,&ftab[28],fqv[279]); /*array-dimension*/
	local[8] = w;
irtdynaKEY3494:
	if (n & (1<<9)) goto irtdynaKEY3495;
	local[9] = NIL;
irtdynaKEY3495:
	if (n & (1<<10)) goto irtdynaKEY3496;
	local[10] = NIL;
irtdynaKEY3496:
	argv[0]->c.obj.iv[22] = local[3];
	argv[0]->c.obj.iv[23] = local[4];
	argv[0]->c.obj.iv[24] = local[5];
	local[11]= argv[0]->c.obj.iv[24];
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(*ftab[28])(ctx,2,local+11,&ftab[28],fqv[279]); /*array-dimension*/
	argv[0]->c.obj.iv[20] = w;
	local[11]= argv[0]->c.obj.iv[23];
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(*ftab[28])(ctx,2,local+11,&ftab[28],fqv[279]); /*array-dimension*/
	argv[0]->c.obj.iv[21] = w;
	local[11]= argv[0]->c.obj.iv[22];
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(*ftab[28])(ctx,2,local+11,&ftab[28],fqv[279]); /*array-dimension*/
	local[11]= w;
	local[12]= argv[0]->c.obj.iv[20];
	local[13]= local[11];
	ctx->vsp=local+14;
	w=(pointer)PLUS(ctx,2,local+12); /*+*/
	local[12]= w;
	local[13]= argv[0]->c.obj.iv[24];
	local[14]= argv[0]->c.obj.iv[22];
	ctx->vsp=local+15;
	w=(pointer)MATTIMES(ctx,2,local+13); /*m**/
	local[13]= w;
	local[14]= local[12];
	local[15]= local[12];
	ctx->vsp=local+16;
	w=(*ftab[5])(ctx,2,local+14,&ftab[5],fqv[24]); /*make-matrix*/
	local[14]= w;
	local[15]= argv[0]->c.obj.iv[24];
	local[16]= argv[0]->c.obj.iv[23];
	ctx->vsp=local+17;
	w=(pointer)MATTIMES(ctx,2,local+15); /*m**/
	local[15]= w;
	local[16]= local[12];
	local[17]= argv[0]->c.obj.iv[23];
	local[18]= makeint((eusinteger_t)1L);
	ctx->vsp=local+19;
	w=(*ftab[28])(ctx,2,local+17,&ftab[28],fqv[279]); /*array-dimension*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(*ftab[5])(ctx,2,local+16,&ftab[5],fqv[24]); /*make-matrix*/
	local[16]= w;
	local[17]= argv[0]->c.obj.iv[20];
	local[18]= local[12];
	ctx->vsp=local+19;
	w=(*ftab[5])(ctx,2,local+17,&ftab[5],fqv[24]); /*make-matrix*/
	local[17]= w;
	local[18]= makeint((eusinteger_t)0L);
	local[19]= argv[0]->c.obj.iv[20];
irtdynaWHL3497:
	local[20]= local[18];
	w = local[19];
	if ((eusinteger_t)local[20] >= (eusinteger_t)w) goto irtdynaWHX3498;
	local[20]= local[14];
	local[21]= local[18];
	local[22]= local[18];
	local[23]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+24;
	w=(pointer)ASET(ctx,4,local+20); /*aset*/
	local[20]= local[18];
	ctx->vsp=local+21;
	w=(pointer)ADD1(ctx,1,local+20); /*1+*/
	local[18] = w;
	goto irtdynaWHL3497;
irtdynaWHX3498:
	local[20]= NIL;
irtdynaBLK3499:
	w = NIL;
	local[18]= makeint((eusinteger_t)0L);
	local[19]= argv[0]->c.obj.iv[20];
irtdynaWHL3500:
	local[20]= local[18];
	w = local[19];
	if ((eusinteger_t)local[20] >= (eusinteger_t)w) goto irtdynaWHX3501;
	local[20]= makeint((eusinteger_t)0L);
	local[21]= local[11];
irtdynaWHL3503:
	local[22]= local[20];
	w = local[21];
	if ((eusinteger_t)local[22] >= (eusinteger_t)w) goto irtdynaWHX3504;
	local[22]= local[14];
	local[23]= local[18];
	local[24]= argv[0]->c.obj.iv[20];
	local[25]= local[20];
	ctx->vsp=local+26;
	w=(pointer)PLUS(ctx,2,local+24); /*+*/
	local[24]= w;
	local[25]= local[13];
	local[26]= local[18];
	local[27]= local[20];
	ctx->vsp=local+28;
	w=(pointer)AREF(ctx,3,local+25); /*aref*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(pointer)ASET(ctx,4,local+22); /*aset*/
	local[22]= local[20];
	ctx->vsp=local+23;
	w=(pointer)ADD1(ctx,1,local+22); /*1+*/
	local[20] = w;
	goto irtdynaWHL3503;
irtdynaWHX3504:
	local[22]= NIL;
irtdynaBLK3505:
	w = NIL;
	local[20]= local[18];
	ctx->vsp=local+21;
	w=(pointer)ADD1(ctx,1,local+20); /*1+*/
	local[18] = w;
	goto irtdynaWHL3500;
irtdynaWHX3501:
	local[20]= NIL;
irtdynaBLK3502:
	w = NIL;
	local[18]= makeint((eusinteger_t)0L);
	local[19]= local[11];
irtdynaWHL3506:
	local[20]= local[18];
	w = local[19];
	if ((eusinteger_t)local[20] >= (eusinteger_t)w) goto irtdynaWHX3507;
	local[20]= makeint((eusinteger_t)0L);
	local[21]= local[11];
irtdynaWHL3509:
	local[22]= local[20];
	w = local[21];
	if ((eusinteger_t)local[22] >= (eusinteger_t)w) goto irtdynaWHX3510;
	local[22]= local[14];
	local[23]= argv[0]->c.obj.iv[20];
	local[24]= local[18];
	ctx->vsp=local+25;
	w=(pointer)PLUS(ctx,2,local+23); /*+*/
	local[23]= w;
	local[24]= argv[0]->c.obj.iv[20];
	local[25]= local[20];
	ctx->vsp=local+26;
	w=(pointer)PLUS(ctx,2,local+24); /*+*/
	local[24]= w;
	local[25]= argv[0]->c.obj.iv[22];
	local[26]= local[18];
	local[27]= local[20];
	ctx->vsp=local+28;
	w=(pointer)AREF(ctx,3,local+25); /*aref*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(pointer)ASET(ctx,4,local+22); /*aset*/
	local[22]= local[20];
	ctx->vsp=local+23;
	w=(pointer)ADD1(ctx,1,local+22); /*1+*/
	local[20] = w;
	goto irtdynaWHL3509;
irtdynaWHX3510:
	local[22]= NIL;
irtdynaBLK3511:
	w = NIL;
	local[20]= local[18];
	ctx->vsp=local+21;
	w=(pointer)ADD1(ctx,1,local+20); /*1+*/
	local[18] = w;
	goto irtdynaWHL3506;
irtdynaWHX3507:
	local[20]= NIL;
irtdynaBLK3508:
	w = NIL;
	local[18]= makeint((eusinteger_t)0L);
	local[19]= argv[0]->c.obj.iv[20];
irtdynaWHL3512:
	local[20]= local[18];
	w = local[19];
	if ((eusinteger_t)local[20] >= (eusinteger_t)w) goto irtdynaWHX3513;
	local[20]= makeint((eusinteger_t)0L);
	local[21]= argv[0]->c.obj.iv[21];
irtdynaWHL3515:
	local[22]= local[20];
	w = local[21];
	if ((eusinteger_t)local[22] >= (eusinteger_t)w) goto irtdynaWHX3516;
	local[22]= local[16];
	local[23]= local[18];
	local[24]= local[20];
	local[25]= local[15];
	local[26]= local[18];
	local[27]= local[20];
	ctx->vsp=local+28;
	w=(pointer)AREF(ctx,3,local+25); /*aref*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(pointer)ASET(ctx,4,local+22); /*aset*/
	local[22]= local[20];
	ctx->vsp=local+23;
	w=(pointer)ADD1(ctx,1,local+22); /*1+*/
	local[20] = w;
	goto irtdynaWHL3515;
irtdynaWHX3516:
	local[22]= NIL;
irtdynaBLK3517:
	w = NIL;
	local[20]= local[18];
	ctx->vsp=local+21;
	w=(pointer)ADD1(ctx,1,local+20); /*1+*/
	local[18] = w;
	goto irtdynaWHL3512;
irtdynaWHX3513:
	local[20]= NIL;
irtdynaBLK3514:
	w = NIL;
	local[18]= makeint((eusinteger_t)0L);
	local[19]= local[11];
irtdynaWHL3518:
	local[20]= local[18];
	w = local[19];
	if ((eusinteger_t)local[20] >= (eusinteger_t)w) goto irtdynaWHX3519;
	local[20]= makeint((eusinteger_t)0L);
	local[21]= argv[0]->c.obj.iv[21];
irtdynaWHL3521:
	local[22]= local[20];
	w = local[21];
	if ((eusinteger_t)local[22] >= (eusinteger_t)w) goto irtdynaWHX3522;
	local[22]= local[16];
	local[23]= argv[0]->c.obj.iv[20];
	local[24]= local[18];
	ctx->vsp=local+25;
	w=(pointer)PLUS(ctx,2,local+23); /*+*/
	local[23]= w;
	local[24]= local[20];
	local[25]= argv[0]->c.obj.iv[23];
	local[26]= local[18];
	local[27]= local[20];
	ctx->vsp=local+28;
	w=(pointer)AREF(ctx,3,local+25); /*aref*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(pointer)ASET(ctx,4,local+22); /*aset*/
	local[22]= local[20];
	ctx->vsp=local+23;
	w=(pointer)ADD1(ctx,1,local+22); /*1+*/
	local[20] = w;
	goto irtdynaWHL3521;
irtdynaWHX3522:
	local[22]= NIL;
irtdynaBLK3523:
	w = NIL;
	local[20]= local[18];
	ctx->vsp=local+21;
	w=(pointer)ADD1(ctx,1,local+20); /*1+*/
	local[18] = w;
	goto irtdynaWHL3518;
irtdynaWHX3519:
	local[20]= NIL;
irtdynaBLK3520:
	w = NIL;
	if (local[10]==NIL) goto irtdynaIF3524;
	local[18]= makeint((eusinteger_t)0L);
	local[19]= argv[0]->c.obj.iv[20];
irtdynaWHL3526:
	local[20]= local[18];
	w = local[19];
	if ((eusinteger_t)local[20] >= (eusinteger_t)w) goto irtdynaWHX3527;
	local[20]= local[17];
	local[21]= local[18];
	local[22]= local[18];
	local[23]= local[10];
	local[24]= local[18];
	local[25]= local[18];
	ctx->vsp=local+26;
	w=(pointer)AREF(ctx,3,local+23); /*aref*/
	local[23]= w;
	ctx->vsp=local+24;
	w=(pointer)ASET(ctx,4,local+20); /*aset*/
	local[20]= local[18];
	ctx->vsp=local+21;
	w=(pointer)ADD1(ctx,1,local+20); /*1+*/
	local[18] = w;
	goto irtdynaWHL3526;
irtdynaWHX3527:
	local[20]= NIL;
irtdynaBLK3528:
	w = NIL;
	local[18]= w;
	goto irtdynaIF3525;
irtdynaIF3524:
	local[18]= makeint((eusinteger_t)0L);
	local[19]= argv[0]->c.obj.iv[20];
irtdynaWHL3529:
	local[20]= local[18];
	w = local[19];
	if ((eusinteger_t)local[20] >= (eusinteger_t)w) goto irtdynaWHX3530;
	local[20]= local[17];
	local[21]= local[18];
	local[22]= local[18];
	local[23]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+24;
	w=(pointer)ASET(ctx,4,local+20); /*aset*/
	local[20]= local[18];
	ctx->vsp=local+21;
	w=(pointer)ADD1(ctx,1,local+20); /*1+*/
	local[18] = w;
	goto irtdynaWHL3529;
irtdynaWHX3530:
	local[20]= NIL;
irtdynaBLK3531:
	w = NIL;
	local[18]= w;
irtdynaIF3525:
	local[18]= argv[0];
	local[19]= *(ovafptr(argv[1],fqv[284]));
	local[20]= fqv[223];
	local[21]= argv[2];
	local[22]= fqv[295];
	local[23]= local[14];
	local[24]= fqv[296];
	local[25]= local[16];
	local[26]= fqv[297];
	local[27]= local[17];
	local[28]= fqv[298];
	local[29]= local[8];
	local[30]= fqv[299];
	local[31]= local[0];
	local[32]= fqv[300];
	local[33]= local[1];
	local[34]= fqv[224];
	local[35]= local[2];
	local[36]= fqv[301];
	local[37]= local[6];
	local[38]= fqv[302];
	local[39]= local[7];
	local[40]= fqv[225];
	local[41]= local[9];
	local[42]= fqv[303];
	local[43]= argv[0]->c.obj.iv[20];
	local[44]= fqv[304];
	local[45]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+46;
	w=(pointer)SENDMESSAGE(ctx,28,local+18); /*send-message*/
	if (argv[0]->c.obj.iv[25]!=NIL) goto irtdynaIF3532;
	local[18]= local[12];
	local[19]= makeint((eusinteger_t)1L);
	ctx->vsp=local+20;
	w=(*ftab[5])(ctx,2,local+18,&ftab[5],fqv[24]); /*make-matrix*/
	argv[0]->c.obj.iv[25] = w;
	local[18]= argv[0]->c.obj.iv[24];
	local[19]= argv[0]->c.obj.iv[10];
	ctx->vsp=local+20;
	w=(pointer)MATTIMES(ctx,2,local+18); /*m**/
	local[18]= w;
	local[19]= makeint((eusinteger_t)0L);
	local[20]= argv[0]->c.obj.iv[20];
irtdynaWHL3534:
	local[21]= local[19];
	w = local[20];
	if ((eusinteger_t)local[21] >= (eusinteger_t)w) goto irtdynaWHX3535;
	local[21]= argv[0]->c.obj.iv[25];
	local[22]= local[19];
	local[23]= makeint((eusinteger_t)0L);
	local[24]= local[18];
	local[25]= local[19];
	local[26]= makeint((eusinteger_t)0L);
	ctx->vsp=local+27;
	w=(pointer)AREF(ctx,3,local+24); /*aref*/
	local[24]= w;
	ctx->vsp=local+25;
	w=(pointer)ASET(ctx,4,local+21); /*aset*/
	local[21]= local[19];
	ctx->vsp=local+22;
	w=(pointer)ADD1(ctx,1,local+21); /*1+*/
	local[19] = w;
	goto irtdynaWHL3534;
irtdynaWHX3535:
	local[21]= NIL;
irtdynaBLK3536:
	w = NIL;
	local[18]= w;
	goto irtdynaIF3533;
irtdynaIF3532:
	local[18]= NIL;
irtdynaIF3533:
	w = argv[0];
	local[0]= w;
irtdynaBLK3485:
	ctx->vsp=local; return(local[0]);}

/*:calc-f*/
static pointer irtdynaM3537extended_preview_controller_calc_f(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[21];
	local[1]= argv[0]->c.obj.iv[20];
	local[2]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[5])(ctx,2,local+0,&ftab[5],fqv[24]); /*make-matrix*/
	argv[0]->c.obj.iv[13] = w;
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(*ftab[28])(ctx,2,local+0,&ftab[28],fqv[279]); /*array-dimension*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[14])(ctx,1,local+0,&ftab[14],fqv[184]); /*unit-matrix*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(pointer)TRANSPOSE(ctx,1,local+1); /*transpose*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+3;
	w=(pointer)TRANSPOSE(ctx,1,local+2); /*transpose*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[9];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)MATTIMES(ctx,2,local+3); /*m**/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[5];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(*ftab[2])(ctx,2,local+4,&ftab[2],fqv[4]); /*scale-matrix*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0]->c.obj.iv[12];
irtdynaWHL3539:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto irtdynaWHX3540;
	local[7]= local[5];
	local[8]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+9;
	w=(pointer)SUB1(ctx,1,local+8); /*1-*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)NUMEQUAL(ctx,2,local+7); /*=*/
	if (w==NIL) goto irtdynaIF3542;
	local[7]= argv[0]->c.obj.iv[4];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)MATTIMES(ctx,2,local+7); /*m**/
	local[7]= w;
	goto irtdynaIF3543;
irtdynaIF3542:
	local[7]= local[4];
irtdynaIF3543:
	local[8]= argv[0]->c.obj.iv[9];
	local[9]= local[1];
	local[10]= local[0];
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)MATTIMES(ctx,2,local+10); /*m**/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)MATTIMES(ctx,2,local+9); /*m**/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MATTIMES(ctx,2,local+8); /*m**/
	local[8]= w;
	local[9]= argv[0]->c.obj.iv[8];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)MATTIMES(ctx,2,local+9); /*m**/
	local[0] = w;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= argv[0]->c.obj.iv[21];
irtdynaWHL3544:
	local[11]= local[9];
	w = local[10];
	if ((eusinteger_t)local[11] >= (eusinteger_t)w) goto irtdynaWHX3545;
	local[11]= makeint((eusinteger_t)0L);
	local[12]= argv[0]->c.obj.iv[20];
irtdynaWHL3547:
	local[13]= local[11];
	w = local[12];
	if ((eusinteger_t)local[13] >= (eusinteger_t)w) goto irtdynaWHX3548;
	local[13]= argv[0]->c.obj.iv[13];
	local[14]= local[9];
	local[15]= argv[0]->c.obj.iv[20];
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(pointer)ADD1(ctx,1,local+16); /*1+*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)TIMES(ctx,2,local+15); /***/
	local[15]= w;
	local[16]= local[11];
	ctx->vsp=local+17;
	w=(pointer)PLUS(ctx,2,local+15); /*+*/
	local[15]= w;
	local[16]= local[8];
	local[17]= local[9];
	local[18]= local[11];
	ctx->vsp=local+19;
	w=(pointer)AREF(ctx,3,local+16); /*aref*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)ASET(ctx,4,local+13); /*aset*/
	local[13]= local[11];
	ctx->vsp=local+14;
	w=(pointer)ADD1(ctx,1,local+13); /*1+*/
	local[11] = w;
	goto irtdynaWHL3547;
irtdynaWHX3548:
	local[13]= NIL;
irtdynaBLK3549:
	w = NIL;
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[9] = w;
	goto irtdynaWHL3544;
irtdynaWHX3545:
	local[11]= NIL;
irtdynaBLK3546:
	w = NIL;
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto irtdynaWHL3539;
irtdynaWHX3540:
	local[7]= NIL;
irtdynaBLK3541:
	w = NIL;
	local[0]= w;
irtdynaBLK3538:
	ctx->vsp=local; return(local[0]);}

/*:calc-u*/
static pointer irtdynaM3550extended_preview_controller_calc_u(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[13];
	local[1]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+2;
	w=(pointer)MATTIMES(ctx,2,local+0); /*m**/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[7];
	local[2]= argv[0]->c.obj.iv[25];
	ctx->vsp=local+3;
	w=(pointer)MATTIMES(ctx,2,local+1); /*m**/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[186]); /*m-*/
	local[0]= w;
	local[1]= local[0];
	local[2]= argv[0]->c.obj.iv[11];
	ctx->vsp=local+3;
	w=(*ftab[6])(ctx,2,local+1,&ftab[6],fqv[27]); /*m+*/
	argv[0]->c.obj.iv[11] = w;
	w = local[0];
	local[0]= w;
irtdynaBLK3551:
	ctx->vsp=local; return(local[0]);}

/*:calc-xk*/
static pointer irtdynaM3552extended_preview_controller_calc_xk(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[0]->c.obj.iv[25];
	ctx->vsp=local+2;
	w=(pointer)MATTIMES(ctx,2,local+0); /*m**/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= argv[0];
	local[3]= fqv[287];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MATTIMES(ctx,2,local+1); /*m**/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,2,local+0,&ftab[6],fqv[27]); /*m+*/
	argv[0]->c.obj.iv[25] = w;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[0]->c.obj.iv[22];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(*ftab[28])(ctx,2,local+1,&ftab[28],fqv[279]); /*array-dimension*/
	local[1]= w;
irtdynaWHL3554:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto irtdynaWHX3555;
	local[2]= argv[0]->c.obj.iv[10];
	local[3]= local[0];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= argv[0]->c.obj.iv[10];
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,3,local+5); /*aref*/
	local[5]= w;
	local[6]= argv[0]->c.obj.iv[25];
	local[7]= argv[0]->c.obj.iv[20];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,2,local+7); /*+*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)ASET(ctx,4,local+2); /*aset*/
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto irtdynaWHL3554;
irtdynaWHX3555:
	local[2]= NIL;
irtdynaBLK3556:
	w = NIL;
	local[0]= w;
irtdynaBLK3553:
	ctx->vsp=local; return(local[0]);}

/*:current-output-vector*/
static pointer irtdynaM3557extended_preview_controller_current_output_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[25];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(*ftab[30])(ctx,2,local+0,&ftab[30],fqv[293]); /*matrix-column*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+3;
	w=(pointer)SUBSEQ(ctx,3,local+0); /*subseq*/
	local[0]= w;
irtdynaBLK3558:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtdynaM3559preview_control_cart_table_cog_trajectory_generator_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[305], &argv[4], n-4, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3561;
	local[0] = makeint((eusinteger_t)1L);
irtdynaKEY3561:
	if (n & (1<<1)) goto irtdynaKEY3562;
	local[1] = makeflt(9.9999999999999974298988e-07);
irtdynaKEY3562:
	if (n & (1<<2)) goto irtdynaKEY3563;
	local[2] = makeflt(1.5999999999999996447286e+00);
irtdynaKEY3563:
	if (n & (1<<3)) goto irtdynaKEY3564;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)MKFLTVEC(ctx,3,local+9); /*float-vector*/
	local[3] = w;
irtdynaKEY3564:
	if (n & (1<<4)) goto irtdynaKEY3565;
	local[9]= makeint((eusinteger_t)3L);
	local[10]= makeint((eusinteger_t)3L);
	local[11]= makeint((eusinteger_t)1L);
	local[12]= argv[2];
	local[13]= makeflt(5.0000000000000000000000e-01);
	local[14]= argv[2];
	local[15]= argv[2];
	ctx->vsp=local+16;
	w=(pointer)TIMES(ctx,3,local+13); /***/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,3,local+11); /*list*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)0L);
	local[13]= makeint((eusinteger_t)1L);
	local[14]= argv[2];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,3,local+12); /*list*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)0L);
	local[14]= makeint((eusinteger_t)0L);
	local[15]= makeint((eusinteger_t)1L);
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,3,local+13); /*list*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,3,local+11); /*list*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[5])(ctx,3,local+9,&ftab[5],fqv[24]); /*make-matrix*/
	local[4] = w;
irtdynaKEY3565:
	if (n & (1<<5)) goto irtdynaKEY3566;
	local[9]= makeint((eusinteger_t)3L);
	local[10]= makeint((eusinteger_t)1L);
	local[11]= makeflt(1.0000000000000000000000e+00);
	local[12]= makeflt(6.0000000000000000000000e+00);
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	local[11]= w;
	local[12]= argv[2];
	local[13]= argv[2];
	local[14]= argv[2];
	ctx->vsp=local+15;
	w=(pointer)TIMES(ctx,4,local+11); /***/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	local[11]= w;
	local[12]= makeflt(5.0000000000000000000000e-01);
	local[13]= argv[2];
	local[14]= argv[2];
	ctx->vsp=local+15;
	w=(pointer)TIMES(ctx,3,local+12); /***/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	local[12]= w;
	local[13]= argv[2];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,3,local+11); /*list*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[5])(ctx,3,local+9,&ftab[5],fqv[24]); /*make-matrix*/
	local[5] = w;
irtdynaKEY3566:
	if (n & (1<<6)) goto irtdynaKEY3567;
	local[9]= makeint((eusinteger_t)1L);
	local[10]= makeint((eusinteger_t)3L);
	local[11]= makeflt(1.0000000000000000000000e+00);
	local[12]= makeflt(0.0000000000000000000000e+00);
	local[13]= argv[3];
	local[14]= loadglobal(fqv[147]);
	local[15]= makeint((eusinteger_t)2L);
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)QUOTIENT(ctx,2,local+13); /*/*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)MINUS(ctx,1,local+13); /*-*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,3,local+11); /*list*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[5])(ctx,3,local+9,&ftab[5],fqv[24]); /*make-matrix*/
	local[6] = w;
irtdynaKEY3567:
	if (n & (1<<7)) goto irtdynaKEY3568;
	local[7] = NIL;
irtdynaKEY3568:
	if (n & (1<<8)) goto irtdynaKEY3569;
	local[8] = loadglobal(fqv[306]);
irtdynaKEY3569:
	local[9]= local[8];
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,1,local+9); /*instantiate*/
	local[9]= w;
	local[10]= local[9];
	local[11]= fqv[223];
	local[12]= argv[2];
	local[13]= fqv[299];
	local[14]= local[0];
	local[15]= fqv[300];
	local[16]= local[1];
	local[17]= fqv[224];
	local[18]= local[2];
	local[19]= fqv[301];
	local[20]= local[3];
	local[21]= makeint((eusinteger_t)0L);
	ctx->vsp=local+22;
	w=(pointer)ELT(ctx,2,local+20); /*elt*/
	local[20]= w;
	local[21]= makeint((eusinteger_t)0L);
	local[22]= makeint((eusinteger_t)0L);
	ctx->vsp=local+23;
	w=(pointer)MKFLTVEC(ctx,3,local+20); /*float-vector*/
	local[20]= w;
	local[21]= fqv[295];
	local[22]= local[4];
	local[23]= fqv[296];
	local[24]= local[5];
	local[25]= fqv[297];
	local[26]= local[6];
	local[27]= fqv[298];
	local[28]= makeint((eusinteger_t)3L);
	local[29]= fqv[225];
	local[30]= local[7];
	ctx->vsp=local+31;
	w=(pointer)SEND(ctx,21,local+10); /*send*/
	w = local[9];
	local[9]= w;
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)INSTANTIATE(ctx,1,local+10); /*instantiate*/
	local[10]= w;
	local[11]= local[10];
	local[12]= fqv[223];
	local[13]= argv[2];
	local[14]= fqv[299];
	local[15]= local[0];
	local[16]= fqv[300];
	local[17]= local[1];
	local[18]= fqv[224];
	local[19]= local[2];
	local[20]= fqv[301];
	local[21]= local[3];
	local[22]= makeint((eusinteger_t)1L);
	ctx->vsp=local+23;
	w=(pointer)ELT(ctx,2,local+21); /*elt*/
	local[21]= w;
	local[22]= makeint((eusinteger_t)0L);
	local[23]= makeint((eusinteger_t)0L);
	ctx->vsp=local+24;
	w=(pointer)MKFLTVEC(ctx,3,local+21); /*float-vector*/
	local[21]= w;
	local[22]= fqv[295];
	local[23]= local[4];
	local[24]= fqv[296];
	local[25]= local[5];
	local[26]= fqv[297];
	local[27]= local[6];
	local[28]= fqv[298];
	local[29]= makeint((eusinteger_t)3L);
	local[30]= fqv[225];
	local[31]= local[7];
	ctx->vsp=local+32;
	w=(pointer)SEND(ctx,21,local+11); /*send*/
	w = local[10];
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,2,local+9); /*list*/
	argv[0]->c.obj.iv[1] = w;
	argv[0]->c.obj.iv[2] = argv[3];
	w = argv[0];
	local[0]= w;
irtdynaBLK3560:
	ctx->vsp=local; return(local[0]);}

/*:refcog*/
static pointer irtdynaM3570preview_control_cart_table_cog_trajectory_generator_refcog(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= fqv[291];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[291];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
irtdynaBLK3571:
	ctx->vsp=local; return(local[0]);}

/*:cart-zmp*/
static pointer irtdynaM3572preview_control_cart_table_cog_trajectory_generator_cart_zmp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= fqv[292];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[292];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
irtdynaBLK3573:
	ctx->vsp=local; return(local[0]);}

/*:last-refzmp*/
static pointer irtdynaM3574preview_control_cart_table_cog_trajectory_generator_last_refzmp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= fqv[288];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[288];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
irtdynaBLK3575:
	ctx->vsp=local; return(local[0]);}

/*:current-refzmp*/
static pointer irtdynaM3576preview_control_cart_table_cog_trajectory_generator_current_refzmp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= fqv[290];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[290];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
irtdynaBLK3577:
	ctx->vsp=local; return(local[0]);}

/*:update-xk*/
static pointer irtdynaM3578preview_control_cart_table_cog_trajectory_generator_update_xk(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtdynaENT3581;}
	local[0]= NIL;
irtdynaENT3581:
irtdynaENT3580:
	if (n>4) maerror();
	if (argv[2]==NIL) goto irtdynaIF3582;
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	argv[0]->c.obj.iv[3] = w;
	local[1]= argv[0]->c.obj.iv[3];
	goto irtdynaIF3583;
irtdynaIF3582:
	local[1]= NIL;
irtdynaIF3583:
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[229];
	local[3]= argv[2];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)SUBSEQ(ctx,3,local+3); /*subseq*/
	local[3]= w;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= fqv[229];
	local[4]= argv[2];
	local[5]= makeint((eusinteger_t)1L);
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)SUBSEQ(ctx,3,local+4); /*subseq*/
	local[4]= w;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	local[1]= w;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	if (local[2]==NIL) goto irtdynaAND3584;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
irtdynaAND3584:
	local[1] = local[2];
	if (local[1]==NIL) goto irtdynaIF3585;
	local[2]= argv[0];
	local[3]= fqv[307];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[236];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[308];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,3,local+2); /*list*/
	local[2]= w;
	goto irtdynaIF3586;
irtdynaIF3585:
	local[2]= NIL;
irtdynaIF3586:
	w = local[2];
	local[0]= w;
irtdynaBLK3579:
	ctx->vsp=local; return(local[0]);}

/*:finishedp*/
static pointer irtdynaM3587preview_control_cart_table_cog_trajectory_generator_finishedp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= fqv[228];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	if (w==NIL) goto irtdynaAND3589;
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= fqv[228];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
irtdynaAND3589:
	w = local[0];
	local[0]= w;
irtdynaBLK3588:
	ctx->vsp=local; return(local[0]);}

/*:current-additional-data*/
static pointer irtdynaM3590preview_control_cart_table_cog_trajectory_generator_current_additional_data(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= fqv[230];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
irtdynaBLK3591:
	ctx->vsp=local; return(local[0]);}

/*:pass-preview-controller*/
static pointer irtdynaM3592preview_control_cart_table_cog_trajectory_generator_pass_preview_controller(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= NIL;
irtdynaWHL3594:
	local[2]= argv[0];
	local[3]= fqv[229];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[4];
	local[4]= w;
	local[5]= NIL;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[0] = w;
	if (local[0]!=NIL) goto irtdynaWHX3595;
	goto irtdynaWHL3594;
irtdynaWHX3595:
	local[2]= NIL;
irtdynaBLK3596:
	local[2]= local[0];
	w = local[1];
	ctx->vsp=local+3;
	local[1] = cons(ctx,local[2],w);
irtdynaWHL3597:
	local[2]= argv[0];
	local[3]= fqv[229];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[4];
	local[4]= w;
	local[5]= NIL;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[0] = w;
	if (local[0]==NIL) goto irtdynaWHX3598;
	local[2]= local[0];
	w = local[1];
	ctx->vsp=local+3;
	local[1] = cons(ctx,local[2],w);
	goto irtdynaWHL3597;
irtdynaWHX3598:
	local[2]= NIL;
irtdynaBLK3599:
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(pointer)REVERSE(ctx,1,local+2); /*reverse*/
	local[0]= w;
irtdynaBLK3593:
	ctx->vsp=local; return(local[0]);}

/*:cog-z*/
static pointer irtdynaM3600preview_control_cart_table_cog_trajectory_generator_cog_z(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
irtdynaBLK3601:
	ctx->vsp=local; return(local[0]);}

/*:update-cog-z*/
static pointer irtdynaM3602preview_control_cart_table_cog_trajectory_generator_update_cog_z(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtdynaCLO3604,env,argv,local);
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
irtdynaBLK3603:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3604(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= *(ovafptr(argv[0],fqv[309]));
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)2L);
	local[3]= env->c.clo.env1[2];
	local[4]= loadglobal(fqv[147]);
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,1,local+3); /*-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)ASET(ctx,4,local+0); /*aset*/
	local[0]= argv[0];
	local[1]= fqv[285];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[286];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtdynaM3605gait_generator_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	argv[0]->c.obj.iv[1] = argv[2];
	argv[0]->c.obj.iv[2] = argv[3];
	local[0]= NIL;
	local[1]= fqv[310];
irtdynaWHL3607:
	if (local[1]==NIL) goto irtdynaWHX3608;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= fqv[311];
	local[3]= fqv[312];
	local[4]= NIL;
	local[5]= fqv[313];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,3,local+4); /*format*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,1,local+4,&ftab[31],fqv[314]); /*read-from-string*/
	local[4]= w;
	local[5]= fqv[315];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	local[5]= w;
	local[6]= fqv[316];
	local[7]= local[0];
	local[8]= fqv[317];
	local[9]= local[0];
	local[10]= fqv[318];
	local[11]= fqv[315];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)EVAL(ctx,1,local+2); /*eval*/
	goto irtdynaWHL3607;
irtdynaWHX3608:
	local[2]= NIL;
irtdynaBLK3609:
	w = NIL;
	w = argv[0];
	local[0]= w;
irtdynaBLK3606:
	ctx->vsp=local; return(local[0]);}

/*:get-footstep-limbs*/
static pointer irtdynaM3610gait_generator_get_footstep_limbs(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtdynaCLO3612,env,argv,local);
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
irtdynaBLK3611:
	ctx->vsp=local; return(local[0]);}

/*:get-counter-footstep-limbs*/
static pointer irtdynaM3613gait_generator_get_counter_footstep_limbs(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!issymbol(w)) goto irtdynaIF3615;
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtdynaCLO3617,env,argv,local);
	local[1]= argv[0]->c.obj.iv[19];
	ctx->vsp=local+2;
	w=(*ftab[32])(ctx,2,local+0,&ftab[32],fqv[319]); /*remove-if*/
	local[0]= w;
	goto irtdynaIF3616;
irtdynaIF3615:
	local[0]= argv[0];
	local[1]= fqv[320];
	local[2]= argv[0];
	local[3]= fqv[321];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
irtdynaIF3616:
	w = local[0];
	local[0]= w;
irtdynaBLK3614:
	ctx->vsp=local; return(local[0]);}

/*:get-limbs-zmp-list*/
static pointer irtdynaM3618gait_generator_get_limbs_zmp_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtdynaCLO3620,env,argv,local);
	local[1]= argv[2];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,3,local+0); /*mapcar*/
	local[0]= w;
irtdynaBLK3619:
	ctx->vsp=local; return(local[0]);}

/*:get-limbs-zmp*/
static pointer irtdynaM3621gait_generator_get_limbs_zmp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= makeflt(1.0000000000000000000000e+00);
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
	local[1]= (pointer)get_sym_func(fqv[322]);
	local[2]= argv[0];
	local[3]= fqv[323];
	local[4]= argv[2];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	local[3]= fqv[324];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,3,local+4); /*float-vector*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[33])(ctx,4,local+1,&ftab[33],fqv[325]); /*reduce*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)SCALEVEC(ctx,2,local+0); /*scale*/
	local[0]= w;
irtdynaBLK3622:
	ctx->vsp=local; return(local[0]);}

/*:get-swing-limbs*/
static pointer irtdynaM3623gait_generator_get_swing_limbs(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtdynaCLO3625,env,argv,local);
	local[1]= argv[0]->c.obj.iv[19];
	ctx->vsp=local+2;
	w=(*ftab[32])(ctx,2,local+0,&ftab[32],fqv[319]); /*remove-if*/
	local[0]= w;
irtdynaBLK3624:
	ctx->vsp=local; return(local[0]);}

/*:initialize-gait-parameter*/
static pointer irtdynaM3626gait_generator_initialize_gait_parameter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[326], &argv[5], n-5, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3628;
	local[0] = makeint((eusinteger_t)50L);
irtdynaKEY3628:
	if (n & (1<<1)) goto irtdynaKEY3629;
	local[1] = makeflt(1.9999999999999995559108e-01);
irtdynaKEY3629:
	if (n & (1<<2)) goto irtdynaKEY3630;
	local[2] = makeflt(1.5999999999999996447286e+00);
irtdynaKEY3630:
	if (n & (1<<3)) goto irtdynaKEY3631;
	local[3] = fqv[327];
irtdynaKEY3631:
	if (n & (1<<4)) goto irtdynaKEY3632;
	ctx->vsp=local+11;
	local[11]= makeclosure(codevec,quotevec,irtdynaCLO3633,env,argv,local);
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)MAPCAN(ctx,2,local+11); /*mapcan*/
	local[4] = w;
irtdynaKEY3632:
	if (n & (1<<5)) goto irtdynaKEY3634;
	local[5] = makeflt(1.0000000000000000000000e+00);
irtdynaKEY3634:
	if (n & (1<<6)) goto irtdynaKEY3635;
	local[6] = makeflt(9.9999999999999974298988e-07);
irtdynaKEY3635:
	if (n & (1<<7)) goto irtdynaKEY3636;
	local[7] = makeint((eusinteger_t)1L);
irtdynaKEY3636:
	if (n & (1<<8)) goto irtdynaKEY3637;
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(*ftab[24])(ctx,1,local+11,&ftab[24],fqv[260]); /*deg2rad*/
	local[8] = w;
irtdynaKEY3637:
	if (n & (1<<9)) goto irtdynaKEY3638;
	local[9] = T;
irtdynaKEY3638:
	if (n & (1<<10)) goto irtdynaKEY3639;
	local[10] = T;
irtdynaKEY3639:
	ctx->vsp=local+11;
	local[11]= makeclosure(codevec,quotevec,irtdynaCLO3640,env,argv,local);
	local[12]= argv[2];
	ctx->vsp=local+13;
	w=(pointer)MAPCAR(ctx,2,local+11); /*mapcar*/
	argv[0]->c.obj.iv[3] = w;
	local[11]= argv[3];
	local[12]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)ROUND(ctx,1,local+11); /*round*/
	argv[0]->c.obj.iv[12] = w;
	argv[0]->c.obj.iv[5] = NIL;
	argv[0]->c.obj.iv[4] = NIL;
	argv[0]->c.obj.iv[6] = NIL;
	argv[0]->c.obj.iv[8] = NIL;
	argv[0]->c.obj.iv[11] = NIL;
	argv[0]->c.obj.iv[14] = local[0];
	argv[0]->c.obj.iv[15] = local[1];
	argv[0]->c.obj.iv[16] = local[4];
	argv[0]->c.obj.iv[13] = argv[0]->c.obj.iv[12];
	argv[0]->c.obj.iv[17] = NIL;
	argv[0]->c.obj.iv[19] = local[3];
	argv[0]->c.obj.iv[21] = local[7];
	argv[0]->c.obj.iv[22] = local[8];
	argv[0]->c.obj.iv[20] = local[10];
	argv[0]->c.obj.iv[25] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[24] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[23] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[28] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[27] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[26] = makeint((eusinteger_t)0L);
	local[11]= argv[0];
	local[12]= fqv[321];
	w=argv[0]->c.obj.iv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	local[11]= w;
	local[12]= argv[0];
	local[13]= fqv[328];
	local[14]= argv[0];
	local[15]= fqv[320];
	w=argv[0]->c.obj.iv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	w=argv[0]->c.obj.iv[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= argv[0];
	local[14]= fqv[329];
	ctx->vsp=local+15;
	local[15]= makeclosure(codevec,quotevec,irtdynaCLO3641,env,argv,local);
	local[16]= local[12];
	ctx->vsp=local+17;
	w=(pointer)MAPCAR(ctx,2,local+15); /*mapcar*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= argv[0];
	local[14]= fqv[330];
	ctx->vsp=local+15;
	local[15]= makeclosure(codevec,quotevec,irtdynaCLO3642,env,argv,local);
	local[16]= local[11];
	ctx->vsp=local+17;
	w=(pointer)MAPCAR(ctx,2,local+15); /*mapcar*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	w=argv[0]->c.obj.iv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	local[15]= argv[0];
	local[16]= fqv[331];
	local[17]= argv[0];
	local[18]= fqv[332];
	if (local[9]==NIL) goto irtdynaIF3643;
	local[19]= local[14];
	local[20]= local[13];
	ctx->vsp=local+21;
	w=(pointer)APPEND(ctx,2,local+19); /*append*/
	local[19]= w;
	goto irtdynaIF3644;
irtdynaIF3643:
	local[19]= local[14];
irtdynaIF3644:
	if (local[9]==NIL) goto irtdynaIF3645;
	local[20]= local[11];
	local[21]= local[12];
	ctx->vsp=local+22;
	w=(pointer)APPEND(ctx,2,local+20); /*append*/
	local[20]= w;
	goto irtdynaIF3646;
irtdynaIF3645:
	local[20]= local[11];
irtdynaIF3646:
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,4,local+17); /*send*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[15]= argv[0];
	local[16]= fqv[333];
	local[17]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	w=argv[0]->c.obj.iv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[3] = (w)->c.cons.cdr;
	w = local[15];
	local[15]= loadglobal(fqv[222]);
	ctx->vsp=local+16;
	w=(pointer)INSTANTIATE(ctx,1,local+15); /*instantiate*/
	local[15]= w;
	local[16]= local[15];
	local[17]= fqv[223];
	local[18]= argv[0]->c.obj.iv[2];
	local[19]= argv[4];
	local[20]= makeint((eusinteger_t)2L);
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[19]= w;
	w=argv[0]->c.obj.iv[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.car;
	local[21]= makeint((eusinteger_t)2L);
	ctx->vsp=local+22;
	w=(pointer)ELT(ctx,2,local+20); /*elt*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)MINUS(ctx,2,local+19); /*-*/
	local[19]= w;
	local[20]= fqv[224];
	local[21]= local[2];
	local[22]= fqv[299];
	local[23]= local[5];
	local[24]= fqv[300];
	local[25]= local[6];
	local[26]= fqv[301];
	local[27]= argv[4];
	local[28]= fqv[226];
	local[29]= loadglobal(fqv[306]);
	ctx->vsp=local+30;
	w=(pointer)SEND(ctx,14,local+16); /*send*/
	w = local[15];
	argv[0]->c.obj.iv[18] = w;
	argv[0]->c.obj.iv[7] = local[14];
	local[15]= argv[0];
	local[16]= fqv[332];
	ctx->vsp=local+17;
	local[17]= makeclosure(codevec,quotevec,irtdynaCLO3647,env,argv,local);
	local[18]= argv[0];
	local[19]= fqv[320];
	w=argv[0]->c.obj.iv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.car;
	local[21]= fqv[58];
	ctx->vsp=local+22;
	w=(*ftab[7])(ctx,2,local+20,&ftab[7],fqv[29]); /*send-all*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,3,local+18); /*send*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)MAPCAR(ctx,2,local+17); /*mapcar*/
	local[17]= w;
	local[18]= argv[0];
	local[19]= fqv[320];
	w=argv[0]->c.obj.iv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.car;
	local[21]= fqv[58];
	ctx->vsp=local+22;
	w=(*ftab[7])(ctx,2,local+20,&ftab[7],fqv[29]); /*send-all*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,3,local+18); /*send*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,4,local+15); /*send*/
	argv[0]->c.obj.iv[9] = w;
	w=argv[0]->c.obj.iv[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[10] = (w)->c.cons.car;
	local[15]= argv[0];
	local[16]= fqv[334];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	w = T;
	local[0]= w;
irtdynaBLK3627:
	ctx->vsp=local; return(local[0]);}

/*:finalize-gait-parameter*/
static pointer irtdynaM3648gait_generator_finalize_gait_parameter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+1;
	w=(*ftab[34])(ctx,1,local+0,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+2;
	w=(*ftab[34])(ctx,1,local+1,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= argv[0];
	local[3]= fqv[328];
	local[4]= argv[0];
	local[5]= fqv[320];
	local[6]= argv[0];
	local[7]= fqv[336];
	local[8]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+9;
	w=(pointer)REVERSE(ctx,1,local+8); /*reverse*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[329];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtdynaCLO3650,env,argv,local);
	local[5]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+6;
	w=(*ftab[34])(ctx,1,local+5,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	ctx->vsp=local+6;
	w=(pointer)MAPCAR(ctx,2,local+4); /*mapcar*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[330];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtdynaCLO3651,env,argv,local);
	local[5]= argv[0];
	local[6]= fqv[336];
	local[7]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+8;
	w=(*ftab[34])(ctx,1,local+7,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MAPCAR(ctx,2,local+4); /*mapcar*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[331];
	local[4]= argv[0];
	local[5]= fqv[332];
	if (argv[0]->c.obj.iv[20]==NIL) goto irtdynaIF3652;
	local[6]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+7;
	w=(*ftab[34])(ctx,1,local+6,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	local[7]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+8;
	w=(*ftab[34])(ctx,1,local+7,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)APPEND(ctx,2,local+6); /*append*/
	local[6]= w;
	goto irtdynaIF3653;
irtdynaIF3652:
	local[6]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+7;
	w=(*ftab[34])(ctx,1,local+6,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
irtdynaIF3653:
	if (argv[0]->c.obj.iv[20]==NIL) goto irtdynaIF3654;
	local[7]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+8;
	w=(*ftab[34])(ctx,1,local+7,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= argv[0];
	local[9]= fqv[320];
	local[10]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+11;
	w=(*ftab[34])(ctx,1,local+10,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)APPEND(ctx,2,local+7); /*append*/
	local[7]= w;
	goto irtdynaIF3655;
irtdynaIF3654:
	local[7]= argv[0];
	local[8]= fqv[320];
	local[9]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+10;
	w=(*ftab[34])(ctx,1,local+9,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
irtdynaIF3655:
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[333];
	local[4]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+3;
	w=(*ftab[34])(ctx,1,local+2,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[9] = (w)->c.cons.car;
	w = T;
	local[0]= w;
irtdynaBLK3649:
	ctx->vsp=local; return(local[0]);}

/*:make-gait-parameter*/
static pointer irtdynaM3656gait_generator_make_gait_parameter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[3] = (w)->c.cons.cdr;
	w = local[0];
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+2;
	w=(*ftab[34])(ctx,1,local+1,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= argv[0];
	local[3]= fqv[328];
	local[4]= argv[0];
	local[5]= fqv[320];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[329];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtdynaCLO3658,env,argv,local);
	local[5]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+6;
	w=(*ftab[34])(ctx,1,local+5,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	ctx->vsp=local+6;
	w=(pointer)MAPCAR(ctx,2,local+4); /*mapcar*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[330];
	local[4]= local[0];
	local[5]= fqv[337];
	ctx->vsp=local+6;
	w=(*ftab[7])(ctx,2,local+4,&ftab[7],fqv[29]); /*send-all*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[331];
	local[4]= argv[0];
	local[5]= fqv[332];
	local[6]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+7;
	w=(*ftab[34])(ctx,1,local+6,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	local[7]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+8;
	w=(*ftab[34])(ctx,1,local+7,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[333];
	local[4]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	w = T;
	local[0]= w;
irtdynaBLK3657:
	ctx->vsp=local; return(local[0]);}

/*:calc-hoffarbib-pos-vel-acc*/
static pointer irtdynaM3659gait_generator_calc_hoffarbib_pos_vel_acc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=7) maerror();
	local[0]= makeflt(-9.0000000000000000000000e+00);
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
	local[1]= argv[4];
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= makeflt(-3.6000000000000000000000e+01);
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(*ftab[35])(ctx,2,local+2,&ftab[35],fqv[338]); /*expt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)QUOTIENT(ctx,2,local+1); /*/*/
	local[1]= w;
	local[2]= argv[5];
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	local[0]= w;
	local[1]= makeflt(6.0000000000000000000000e+01);
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)3L);
	ctx->vsp=local+4;
	w=(*ftab[35])(ctx,2,local+2,&ftab[35],fqv[338]); /*expt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)QUOTIENT(ctx,2,local+1); /*/*/
	local[1]= w;
	local[2]= argv[3];
	local[3]= argv[6];
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,2,local+2); /*-*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	local[0]= w;
	local[1]= argv[4];
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,2,local+1); /*+*/
	local[1]= w;
	local[2]= argv[5];
	local[3]= argv[0]->c.obj.iv[2];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= argv[6];
	local[4]= argv[0]->c.obj.iv[2];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	local[3]= w;
	local[4]= local[1];
	local[5]= local[2];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,3,local+4); /*list*/
	local[0]= w;
irtdynaBLK3660:
	ctx->vsp=local; return(local[0]);}

/*:calc-current-swing-leg-coords*/
static pointer irtdynaM3661gait_generator_calc_current_swing_leg_coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[339],w);
	ctx->vsp=local+3;
	n=parsekeyparams(fqv[340], &argv[5], n-5, local+3, 0);
	if (n & (1<<0)) goto irtdynaKEY3663;
	local[3] = fqv[341];
irtdynaKEY3663:
	if (n & (1<<1)) goto irtdynaKEY3664;
	local[4] = argv[0]->c.obj.iv[14];
irtdynaKEY3664:
	local[5]= local[3];
	local[6]= local[5];
	if (fqv[341]!=local[6]) goto irtdynaIF3665;
	local[6]= loadglobal(fqv[339]);
	local[7]= argv[3];
	local[8]= argv[4];
	ctx->vsp=local+9;
	w=(*ftab[36])(ctx,3,local+6,&ftab[36],fqv[342]); /*midcoords*/
	local[6]= w;
	goto irtdynaIF3666;
irtdynaIF3665:
	local[6]= local[5];
	if (fqv[343]!=local[6]) goto irtdynaIF3667;
	local[6]= argv[0];
	local[7]= fqv[344];
	local[8]= loadglobal(fqv[339]);
	local[9]= argv[3];
	local[10]= argv[4];
	local[11]= local[4];
	local[12]= fqv[345];
	local[13]= argv[0]->c.obj.iv[28];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,8,local+6); /*send*/
	local[6]= w;
	goto irtdynaIF3668;
irtdynaIF3667:
	local[6]= NIL;
irtdynaIF3668:
irtdynaIF3666:
	w = local[6];
	local[5]= w;
	ctx->vsp=local+6;
	unbindx(ctx,1);
	w = local[5];
	local[0]= w;
irtdynaBLK3662:
	ctx->vsp=local; return(local[0]);}

/*:calc-ratio-from-double-support-ratio*/
static pointer irtdynaM3669gait_generator_calc_ratio_from_double_support_ratio(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeflt(1.0000000000000000000000e+00);
	local[1]= argv[0]->c.obj.iv[15];
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= makeflt(1.0000000000000000000000e+00);
	local[2]= argv[0]->c.obj.iv[13];
	ctx->vsp=local+3;
	w=(pointer)EUSFLOAT(ctx,1,local+2); /*float*/
	local[2]= w;
	local[3]= makeflt(5.0000000000000000000000e-01);
	local[4]= argv[0]->c.obj.iv[15];
	local[5]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,3,local+3); /***/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,2,local+2); /*-*/
	local[2]= w;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
	local[2]= local[1];
	local[3]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,2,local+2); /*<*/
	if (w==NIL) goto irtdynaCON3672;
	local[2]= makeflt(0.0000000000000000000000e+00);
	goto irtdynaCON3671;
irtdynaCON3672:
	local[2]= local[1];
	local[3]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+4;
	w=(pointer)GREATERP(ctx,2,local+2); /*>*/
	if (w==NIL) goto irtdynaCON3673;
	local[2]= makeflt(1.0000000000000000000000e+00);
	goto irtdynaCON3671;
irtdynaCON3673:
	local[2]= local[1];
	goto irtdynaCON3671;
irtdynaCON3674:
	local[2]= NIL;
irtdynaCON3671:
	w = local[2];
	local[0]= w;
irtdynaBLK3670:
	ctx->vsp=local; return(local[0]);}

/*:calc-current-refzmp*/
static pointer irtdynaM3675gait_generator_calc_current_refzmp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0]->c.obj.iv[12];
	local[1]= argv[0]->c.obj.iv[13];
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	local[0]= w;
	local[1]= makeflt(5.0000000000000000000000e-01);
	local[2]= argv[0]->c.obj.iv[15];
	local[3]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,3,local+1); /***/
	local[1]= w;
	local[2]= local[0];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,2,local+2); /*<*/
	if (w==NIL) goto irtdynaCON3678;
	local[2]= makeflt(-5.0000000000000000000000e-01);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
	local[3]= local[0];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	local[3]= argv[3];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(*ftab[37])(ctx,3,local+2,&ftab[37],fqv[346]); /*midpoint*/
	local[2]= w;
	goto irtdynaCON3677;
irtdynaCON3678:
	local[2]= local[0];
	local[3]= argv[0]->c.obj.iv[12];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)GREATERP(ctx,2,local+2); /*>*/
	if (w==NIL) goto irtdynaCON3679;
	local[2]= makeflt(5.0000000000000000000000e-01);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
	local[3]= local[0];
	local[4]= argv[0]->c.obj.iv[12];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	local[3]= argv[3];
	local[4]= argv[4];
	ctx->vsp=local+5;
	w=(*ftab[37])(ctx,3,local+2,&ftab[37],fqv[346]); /*midpoint*/
	local[2]= w;
	goto irtdynaCON3677;
irtdynaCON3679:
	local[2]= argv[3];
	goto irtdynaCON3677;
irtdynaCON3680:
	local[2]= NIL;
irtdynaCON3677:
	w = local[2];
	local[0]= w;
irtdynaBLK3676:
	ctx->vsp=local; return(local[0]);}

/*:calc-one-tick-gait-parameter*/
static pointer irtdynaM3681gait_generator_calc_one_tick_gait_parameter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeflt(5.0000000000000000000000e-01);
	local[1]= argv[0]->c.obj.iv[15];
	local[2]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,3,local+0); /***/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)TRUNCATE(ctx,1,local+0); /*truncate*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[13];
	local[2]= argv[0]->c.obj.iv[12];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,2,local+2); /*-*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)GREATERP(ctx,2,local+1); /*>*/
	if (w==NIL) goto irtdynaCON3684;
	argv[0]->c.obj.iv[28] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[27] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[26] = makeint((eusinteger_t)0L);
	local[1]= argv[0]->c.obj.iv[26];
	goto irtdynaCON3683;
irtdynaCON3684:
	local[1]= argv[0]->c.obj.iv[13];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)LESSP(ctx,2,local+1); /*<*/
	if (w==NIL) goto irtdynaCON3685;
	argv[0]->c.obj.iv[28] = makeflt(1.0000000000000000000000e+00);
	argv[0]->c.obj.iv[27] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[26] = makeint((eusinteger_t)0L);
	local[1]= argv[0]->c.obj.iv[26];
	goto irtdynaCON3683;
irtdynaCON3685:
	local[1]= argv[0];
	local[2]= fqv[347];
	local[3]= argv[0]->c.obj.iv[13];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	local[4]= makeflt(1.0000000000000000000000e+00);
	local[5]= argv[0]->c.obj.iv[26];
	local[6]= argv[0]->c.obj.iv[27];
	local[7]= argv[0]->c.obj.iv[28];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,7,local+1); /*send*/
	local[1]= w;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[28] = (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[27] = (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[26] = (w)->c.cons.car;
	w = argv[0]->c.obj.iv[26];
	local[1]= w;
	goto irtdynaCON3683;
irtdynaCON3686:
	local[1]= NIL;
irtdynaCON3683:
	w = local[1];
	w=argv[0]->c.obj.iv[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtdynaCLO3687,env,argv,local);
	local[3]= argv[0]->c.obj.iv[7];
	w=argv[0]->c.obj.iv[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)MAPCAR(ctx,3,local+2); /*mapcar*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[348];
	local[5]= argv[0]->c.obj.iv[10];
	w=argv[0]->c.obj.iv[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	local[7]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,5,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[13];
	local[5]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+6;
	w=(pointer)NUMEQUAL(ctx,2,local+4); /*=*/
	if (w==NIL) goto irtdynaIF3688;
	argv[0]->c.obj.iv[25] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[24] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[23] = makeint((eusinteger_t)0L);
	local[4]= argv[0]->c.obj.iv[23];
	goto irtdynaIF3689;
irtdynaIF3688:
	local[4]= NIL;
irtdynaIF3689:
	local[4]= argv[0];
	local[5]= fqv[347];
	local[6]= argv[0]->c.obj.iv[13];
	local[7]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	local[7]= makeflt(1.0000000000000000000000e+00);
	local[8]= argv[0]->c.obj.iv[23];
	local[9]= argv[0]->c.obj.iv[24];
	local[10]= argv[0]->c.obj.iv[25];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,7,local+4); /*send*/
	local[4]= w;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[25] = (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[24] = (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[23] = (w)->c.cons.car;
	w = argv[0]->c.obj.iv[23];
	local[4]= argv[0]->c.obj.iv[25];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtdynaCLO3690,env,argv,local);
	local[6]= argv[0]->c.obj.iv[7];
	w=argv[0]->c.obj.iv[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)MAPCAR(ctx,3,local+5); /*mapcar*/
	local[5]= w;
	local[6]= argv[0];
	local[7]= fqv[320];
	w=argv[0]->c.obj.iv[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	w=argv[0]->c.obj.iv[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)APPEND(ctx,2,local+6); /*append*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[18];
	local[8]= fqv[349];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= fqv[332];
	local[10]= local[5];
	w=argv[0]->c.obj.iv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	ctx->vsp=local+12;
	w=(pointer)APPEND(ctx,2,local+10); /*append*/
	local[10]= w;
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,2,local+7); /*+*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[12];
	local[6]= argv[0]->c.obj.iv[13];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	local[6]= makeflt(5.0000000000000000000000e-01);
	local[7]= argv[0]->c.obj.iv[15];
	local[8]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,3,local+6); /***/
	local[6]= w;
	local[7]= local[5];
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)LESSP(ctx,2,local+7); /*<*/
	if (w!=NIL) goto irtdynaOR3693;
	local[7]= local[5];
	local[8]= argv[0]->c.obj.iv[12];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,2,local+8); /*-*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)GREATERP(ctx,2,local+7); /*>*/
	if (w!=NIL) goto irtdynaOR3693;
	w=argv[0]->c.obj.iv[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)EUSFLOAT(ctx,1,local+7); /*float*/
	local[7]= w;
	local[8]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+9;
	w=(*ftab[4])(ctx,2,local+7,&ftab[4],fqv[22]); /*eps=*/
	if (w!=NIL) goto irtdynaOR3693;
	goto irtdynaIF3691;
irtdynaOR3693:
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtdynaCLO3694,env,argv,local);
	local[8]= argv[0]->c.obj.iv[19];
	ctx->vsp=local+9;
	w=(pointer)MAPCAR(ctx,2,local+7); /*mapcar*/
	local[7]= w;
	goto irtdynaIF3692;
irtdynaIF3691:
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtdynaCLO3695,env,argv,local);
	local[8]= argv[0]->c.obj.iv[19];
	ctx->vsp=local+9;
	w=(pointer)MAPCAR(ctx,2,local+7); /*mapcar*/
	local[7]= w;
irtdynaIF3692:
	w = local[7];
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,6,local+0); /*list*/
	local[0]= w;
irtdynaBLK3682:
	ctx->vsp=local; return(local[0]);}

/*:proc-one-tick*/
static pointer irtdynaM3696gait_generator_proc_one_tick(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[350], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3698;
	local[0] = fqv[341];
irtdynaKEY3698:
	if (n & (1<<1)) goto irtdynaKEY3699;
	local[1] = fqv[351];
irtdynaKEY3699:
	if (n & (1<<2)) goto irtdynaKEY3700;
	local[2] = NIL;
irtdynaKEY3700:
	if (n & (1<<3)) goto irtdynaKEY3701;
	local[3] = NIL;
irtdynaKEY3701:
	if (argv[0]->c.obj.iv[5]==NIL) goto irtdynaIF3702;
	local[4]= argv[0];
	local[5]= fqv[352];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto irtdynaIF3703;
irtdynaIF3702:
	local[4]= NIL;
irtdynaIF3703:
	local[5]= argv[0]->c.obj.iv[18];
	local[6]= fqv[229];
	if (local[4]==NIL) goto irtdynaIF3704;
	local[7]= local[4];
	local[8]= makeint((eusinteger_t)3L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	goto irtdynaIF3705;
irtdynaIF3704:
	local[7]= NIL;
irtdynaIF3705:
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= w;
	local[6]= argv[0]->c.obj.iv[18];
	local[7]= fqv[230];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	if (local[5]==NIL) goto irtdynaIF3706;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= makeint((eusinteger_t)2L);
	local[9]= local[6];
	local[10]= makeint((eusinteger_t)4L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SETELT(ctx,3,local+7); /*setelt*/
	local[7]= w;
	goto irtdynaIF3707;
irtdynaIF3706:
	local[7]= NIL;
irtdynaIF3707:
	if (local[5]==NIL) goto irtdynaIF3708;
	if (local[1]==NIL) goto irtdynaIF3708;
	local[7]= argv[0];
	local[8]= fqv[353];
	local[9]= local[6];
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	local[10]= local[6];
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	local[11]= local[6];
	local[12]= makeint((eusinteger_t)2L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= fqv[353];
	local[14]= local[1];
	local[15]= fqv[354];
	local[16]= local[2];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,10,local+7); /*send*/
	local[7]= w;
	if (local[3]==NIL) goto irtdynaIF3710;
	local[8]= local[6];
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)BUTLAST(ctx,2,local+8); /*butlast*/
	local[8]= w;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= argv[0]->c.obj.iv[18];
	local[11]= fqv[308];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,2,local+9); /*list*/
	local[9]= w;
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(*ftab[34])(ctx,1,local+10,&ftab[34],fqv[335]); /*last*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)APPEND(ctx,3,local+8); /*append*/
	local[8]= w;
	goto irtdynaIF3711;
irtdynaIF3710:
	local[8]= NIL;
irtdynaIF3711:
	ctx->vsp=local+9;
	w=(pointer)APPEND(ctx,2,local+7); /*append*/
	local[7]= w;
	goto irtdynaIF3709;
irtdynaIF3708:
	local[7]= NIL;
irtdynaIF3709:
	local[8]= makeint((eusinteger_t)0L);
	local[9]= argv[0]->c.obj.iv[13];
	ctx->vsp=local+10;
	w=(pointer)SUB1(ctx,1,local+9); /*1-*/
	argv[0]->c.obj.iv[13] = w;
	local[9]= argv[0]->c.obj.iv[13];
	ctx->vsp=local+10;
	w=(pointer)GREQP(ctx,2,local+8); /*>=*/
	if (w==NIL) goto irtdynaIF3712;
	local[8]= argv[0];
	local[9]= fqv[355];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	goto irtdynaIF3713;
irtdynaIF3712:
	local[8]= NIL;
irtdynaIF3713:
	w = local[7];
	local[0]= w;
irtdynaBLK3697:
	ctx->vsp=local; return(local[0]);}

/*:update-current-gait-parameter*/
static pointer irtdynaM3714gait_generator_update_current_gait_parameter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[10] = (w)->c.cons.car;
	w=argv[0]->c.obj.iv[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	if (argv[0]->c.obj.iv[3]==NIL) goto irtdynaCON3717;
	local[1]= argv[0];
	local[2]= fqv[334];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	goto irtdynaCON3716;
irtdynaCON3717:
	if (argv[0]->c.obj.iv[17]!=NIL) goto irtdynaCON3718;
	local[1]= argv[0];
	local[2]= fqv[356];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	argv[0]->c.obj.iv[17] = T;
	local[1]= argv[0]->c.obj.iv[17];
	goto irtdynaCON3716;
irtdynaCON3718:
	local[1]= NIL;
irtdynaCON3716:
	argv[0]->c.obj.iv[13] = argv[0]->c.obj.iv[12];
	w=argv[0]->c.obj.iv[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[4] = (w)->c.cons.cdr;
	w = local[1];
	if (argv[0]->c.obj.iv[4]==NIL) goto irtdynaIF3719;
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtdynaCLO3721,env,argv,local);
	local[2]= argv[0];
	local[3]= fqv[336];
	w=argv[0]->c.obj.iv[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	local[1]= w;
	goto irtdynaIF3720;
irtdynaIF3719:
	local[1]= NIL;
irtdynaIF3720:
	argv[0]->c.obj.iv[7] = local[1];
	w=argv[0]->c.obj.iv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[5] = (w)->c.cons.cdr;
	w = local[1];
	w=argv[0]->c.obj.iv[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[6] = (w)->c.cons.cdr;
	w = local[0];
	w=argv[0]->c.obj.iv[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[8] = (w)->c.cons.cdr;
	w = local[0];
	w=argv[0]->c.obj.iv[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[11] = (w)->c.cons.cdr;
	w = local[0];
	w=argv[0]->c.obj.iv[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car==NIL) goto irtdynaIF3722;
	w=argv[0]->c.obj.iv[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[9] = (w)->c.cons.car;
	local[0]= argv[0]->c.obj.iv[9];
	goto irtdynaIF3723;
irtdynaIF3722:
	w=argv[0]->c.obj.iv[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[9] = (w)->c.cons.car;
	local[0]= argv[0]->c.obj.iv[9];
irtdynaIF3723:
	w = local[0];
	local[0]= w;
irtdynaBLK3715:
	ctx->vsp=local; return(local[0]);}

/*:solve-angle-vector*/
static pointer irtdynaM3724gait_generator_solve_angle_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<6) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[357], &argv[6], n-6, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3726;
	local[0] = fqv[351];
irtdynaKEY3726:
	if (n & (1<<1)) goto irtdynaKEY3727;
	local[1] = NIL;
irtdynaKEY3727:
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[12])(ctx,1,local+2,&ftab[12],fqv[104]); /*functionp*/
	if (w==NIL) goto irtdynaCON3729;
	local[2]= local[0];
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= argv[5];
	local[7]= argv[0]->c.obj.iv[1];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)APPLY(ctx,7,local+2); /*apply*/
	local[2]= w;
	goto irtdynaCON3728;
irtdynaCON3729:
	w = local[0];
	if (!issymbol(w)) goto irtdynaCON3730;
	local[2]= argv[0];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(*ftab[38])(ctx,2,local+2,&ftab[38],fqv[358]); /*find-method*/
	if (w==NIL) goto irtdynaCON3730;
	local[2]= (pointer)get_sym_func(fqv[82]);
	local[3]= argv[0];
	local[4]= local[0];
	local[5]= argv[2];
	local[6]= argv[3];
	local[7]= argv[4];
	local[8]= argv[5];
	local[9]= argv[0]->c.obj.iv[1];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)APPLY(ctx,9,local+2); /*apply*/
	local[2]= w;
	goto irtdynaCON3728;
irtdynaCON3730:
	local[2]= fqv[359];
	ctx->vsp=local+3;
	w=(pointer)SIGERROR(ctx,1,local+2); /*error*/
	local[2]= w;
	goto irtdynaCON3728;
irtdynaCON3731:
	local[2]= NIL;
irtdynaCON3728:
	local[3]= local[2];
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= fqv[74];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= fqv[68];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,2,local+3); /*list*/
	local[0]= w;
irtdynaBLK3725:
	ctx->vsp=local; return(local[0]);}

/*:solve-av-by-move-centroid-on-foot*/
static pointer irtdynaM3732gait_generator_solve_av_by_move_centroid_on_foot(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<7) maerror();
irtdynaRST3734:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-7);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[360], &argv[7], n-7, local+1, 1);
	if (n & (1<<0)) goto irtdynaKEY3735;
	local[1] = makeflt(3.5000000000000000000000e+00);
irtdynaKEY3735:
	if (n & (1<<1)) goto irtdynaKEY3736;
	local[2] = makeint((eusinteger_t)100L);
irtdynaKEY3736:
	if (n & (1<<2)) goto irtdynaKEY3737;
	local[3] = NIL;
irtdynaKEY3737:
	local[4]= argv[0];
	local[5]= fqv[320];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)APPEND(ctx,2,local+4); /*append*/
	local[4]= w;
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtdynaCLO3738,env,argv,local);
	local[6]= argv[0]->c.obj.iv[19];
	ctx->vsp=local+7;
	w=(pointer)MAPCAR(ctx,2,local+5); /*mapcar*/
	local[5]= w;
	local[6]= argv[4];
	local[7]= argv[3];
	ctx->vsp=local+8;
	w=(pointer)APPEND(ctx,2,local+6); /*append*/
	local[6]= w;
	local[7]= fqv[264];
	w = local[0];
	if (memq(local[7],w)!=NIL) goto irtdynaIF3739;
	local[7]= local[0];
	local[8]= fqv[264];
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,irtdynaCLO3741,env,argv,local);
	local[10]= argv[0]->c.obj.iv[19];
	ctx->vsp=local+11;
	w=(pointer)MAPCAR(ctx,2,local+9); /*mapcar*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,2,local+8); /*list*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)APPEND(ctx,2,local+7); /*append*/
	local[0] = w;
	local[7]= local[0];
	goto irtdynaIF3740;
irtdynaIF3739:
	local[7]= NIL;
irtdynaIF3740:
	local[7]= fqv[265];
	w = local[0];
	if (memq(local[7],w)!=NIL) goto irtdynaIF3742;
	local[7]= local[0];
	local[8]= fqv[265];
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,irtdynaCLO3744,env,argv,local);
	local[10]= argv[0]->c.obj.iv[19];
	ctx->vsp=local+11;
	w=(pointer)MAPCAR(ctx,2,local+9); /*mapcar*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,2,local+8); /*list*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)APPEND(ctx,2,local+7); /*append*/
	local[0] = w;
	local[7]= local[0];
	goto irtdynaIF3743;
irtdynaIF3742:
	local[7]= NIL;
irtdynaIF3743:
	local[7]= (pointer)get_sym_func(fqv[82]);
	local[8]= argv[6];
	local[9]= fqv[231];
	local[10]= fqv[232];
	local[11]= argv[0]->c.obj.iv[19];
	local[12]= fqv[235];
	local[13]= argv[5];
	local[14]= fqv[361];
	ctx->vsp=local+15;
	local[15]= makeclosure(codevec,quotevec,irtdynaCLO3745,env,argv,local);
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(pointer)MAPCAR(ctx,2,local+15); /*mapcar*/
	local[15]= w;
	local[16]= fqv[362];
	local[17]= local[1];
	local[18]= fqv[363];
	local[19]= local[2];
	local[20]= fqv[364];
	local[21]= local[3];
	local[22]= argv[6];
	local[23]= fqv[74];
	ctx->vsp=local+24;
	w=(pointer)SEND(ctx,2,local+22); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22]= (w)->c.cons.car;
	ctx->vsp=local+23;
	local[23]= makeclosure(codevec,quotevec,irtdynaCLO3746,env,argv,local);
	ctx->vsp=local+24;
	w=(pointer)LIST(ctx,2,local+22); /*list*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)LIST(ctx,1,local+22); /*list*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)APPEND(ctx,2,local+21); /*append*/
	local[21]= w;
	local[22]= local[0];
	ctx->vsp=local+23;
	w=(pointer)APPLY(ctx,16,local+7); /*apply*/
	local[0]= w;
irtdynaBLK3733:
	ctx->vsp=local; return(local[0]);}

/*:cycloid-midpoint*/
static pointer irtdynaM3747gait_generator_cycloid_midpoint(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<6) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[339],w);
	ctx->vsp=local+3;
	n=parsekeyparams(fqv[365], &argv[6], n-6, local+3, 0);
	if (n & (1<<0)) goto irtdynaKEY3749;
	local[3] = makeflt(5.0000000000000000000000e-01);
irtdynaKEY3749:
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[5];
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,3,local+4); /*float-vector*/
	local[4]= w;
	local[5]= local[3];
	local[6]= argv[3];
	local[7]= argv[4];
	ctx->vsp=local+8;
	w=(*ftab[37])(ctx,3,local+5,&ftab[37],fqv[346]); /*midpoint*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)VPLUS(ctx,2,local+4); /*v+*/
	local[4]= w;
	local[5]= loadglobal(fqv[339]);
	local[6]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+7;
	w=(pointer)GREATERP(ctx,2,local+5); /*>*/
	if (w==NIL) goto irtdynaIF3750;
	local[5]= argv[4];
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)VMINUS(ctx,2,local+5); /*v-*/
	local[5]= w;
	goto irtdynaIF3751;
irtdynaIF3750:
	local[5]= local[4];
	local[6]= argv[3];
	ctx->vsp=local+7;
	w=(pointer)VMINUS(ctx,2,local+5); /*v-*/
	local[5]= w;
irtdynaIF3751:
	local[6]= argv[4];
	local[7]= argv[3];
	ctx->vsp=local+8;
	w=(pointer)VMINUS(ctx,2,local+6); /*v-*/
	local[6]= w;
	local[7]= local[5];
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)ABS(ctx,1,local+7); /*abs*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SCALEVEC(ctx,2,local+7); /*scale*/
	local[7]= w;
	local[8]= local[5];
	local[9]= makeint((eusinteger_t)2L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)SETELT(ctx,3,local+8); /*setelt*/
	local[8]= local[6];
	local[9]= makeint((eusinteger_t)2L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)SETELT(ctx,3,local+8); /*setelt*/
	local[8]= makeflt(2.0000000000000000000000e+00);
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)VNORM(ctx,1,local+9); /*norm*/
	{ double x,y;
		y=fltval(w); x=fltval(local[8]);
		local[8]=(makeflt(x * y));}
	local[9]= makeflt(3.1415926535897931159980e+00);
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	local[8]= w;
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(*ftab[1])(ctx,1,local+9,&ftab[1],fqv[3]); /*normalize-vector*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,2,local+8); /*scale*/
	local[8]= w;
	local[9]= local[7];
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+9); /*v**/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[1])(ctx,1,local+9,&ftab[1],fqv[3]); /*normalize-vector*/
	local[9]= w;
	local[10]= makeflt(6.2831853071795862319959e+00);
	local[11]= loadglobal(fqv[339]);
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	local[11]= loadglobal(fqv[339]);
	local[12]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+13;
	w=(pointer)GREATERP(ctx,2,local+11); /*>*/
	if (w==NIL) goto irtdynaIF3752;
	local[11]= makeflt(-1.5707963267948965579990e+00);
	goto irtdynaIF3753;
irtdynaIF3752:
	local[11]= makeflt(0.0000000000000000000000e+00);
irtdynaIF3753:
	local[12]= makeflt(5.0000000000000000000000e-01);
	local[13]= local[10];
	local[14]= local[10];
	ctx->vsp=local+15;
	w=(pointer)SIN(ctx,1,local+14); /*sin*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)MINUS(ctx,2,local+13); /*-*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)TIMES(ctx,2,local+12); /***/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	local[11]= w;
	local[12]= makeflt(0.0000000000000000000000e+00);
	local[13]= loadglobal(fqv[339]);
	local[14]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+15;
	w=(pointer)GREATERP(ctx,2,local+13); /*>*/
	if (w==NIL) goto irtdynaIF3754;
	local[13]= makeint((eusinteger_t)-1L);
	goto irtdynaIF3755;
irtdynaIF3754:
	local[13]= makeflt(0.0000000000000000000000e+00);
irtdynaIF3755:
	local[14]= makeflt(5.0000000000000000000000e-01);
	local[15]= makeflt(1.0000000000000000000000e+00);
	local[16]= local[10];
	ctx->vsp=local+17;
	w=(pointer)COS(ctx,1,local+16); /*cos*/
	{ double x,y;
		y=fltval(w); x=fltval(local[15]);
		local[15]=(makeflt(x - y));}
	{ double x,y;
		y=fltval(local[15]); x=fltval(local[14]);
		local[14]=(makeflt(x * y));}
	ctx->vsp=local+15;
	w=(pointer)PLUS(ctx,2,local+13); /*+*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)MKFLTVEC(ctx,3,local+11); /*float-vector*/
	local[11]= w;
	local[12]= local[11];
	local[13]= local[8];
	local[14]= local[9];
	local[15]= local[7];
	ctx->vsp=local+16;
	w=(*ftab[39])(ctx,3,local+13,&ftab[39],fqv[366]); /*matrix*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)TRANSFORM(ctx,2,local+12); /*transform*/
	local[12]= w;
	local[13]= local[12];
	local[14]= loadglobal(fqv[339]);
	local[15]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+16;
	w=(pointer)GREATERP(ctx,2,local+14); /*>*/
	if (w==NIL) goto irtdynaIF3756;
	local[14]= local[4];
	goto irtdynaIF3757;
irtdynaIF3756:
	local[14]= argv[3];
irtdynaIF3757:
	ctx->vsp=local+15;
	w=(pointer)VPLUS(ctx,2,local+13); /*v+*/
	local[4]= w;
	ctx->vsp=local+5;
	unbindx(ctx,1);
	w = local[4];
	local[0]= w;
irtdynaBLK3748:
	ctx->vsp=local; return(local[0]);}

/*:cycloid-midcoords*/
static pointer irtdynaM3758gait_generator_cycloid_midcoords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<6) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[339],w);
	ctx->vsp=local+3;
	n=parsekeyparams(fqv[367], &argv[6], n-6, local+3, 0);
	if (n & (1<<0)) goto irtdynaKEY3760;
	local[3] = makeflt(5.0000000000000000000000e-01);
irtdynaKEY3760:
	if (n & (1<<1)) goto irtdynaKEY3761;
	local[4] = loadglobal(fqv[339]);
irtdynaKEY3761:
	local[5]= argv[0];
	local[6]= fqv[368];
	local[7]= loadglobal(fqv[339]);
	local[8]= argv[3];
	local[9]= fqv[5];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= argv[4];
	local[10]= fqv[5];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	local[10]= argv[5];
	local[11]= fqv[369];
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,8,local+5); /*send*/
	local[5]= w;
	local[6]= fqv[255];
	local[7]= local[5];
	local[8]= fqv[256];
	local[9]= local[4];
	local[10]= argv[3];
	local[11]= argv[4];
	ctx->vsp=local+12;
	w=(*ftab[36])(ctx,3,local+9,&ftab[36],fqv[342]); /*midcoords*/
	local[9]= w;
	local[10]= fqv[25];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[23])(ctx,4,local+6,&ftab[23],fqv[246]); /*make-coords*/
	local[5]= w;
	ctx->vsp=local+6;
	unbindx(ctx,1);
	w = local[5];
	local[0]= w;
irtdynaBLK3759:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3612(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[370];
	ctx->vsp=local+2;
	w=(*ftab[38])(ctx,2,local+0,&ftab[38],fqv[358]); /*find-method*/
	if (w==NIL) goto irtdynaIF3762;
	local[0]= argv[0];
	local[1]= fqv[370];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto irtdynaIF3763;
irtdynaIF3762:
	local[0]= argv[0];
	local[1]= fqv[58];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
irtdynaIF3763:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3617(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtdynaCLO3764,env,argv,local);
	local[2]= env->c.clo.env1[0]->c.obj.iv[19];
	ctx->vsp=local+3;
	w=(*ftab[40])(ctx,2,local+1,&ftab[40],fqv[371]); /*remove-if-not*/
	w = memq(local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3764(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w = env->c.clo.env0->c.clo.env1[2];
	w = memq(local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3620(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[5];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[2];
	local[3]= argv[1];
	w = env->c.clo.env1[0]->c.obj.iv[16];
	w=memq(local[3],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)VPLUS(ctx,2,local+0); /*v+*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3625(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w = env->c.clo.env1[2];
	w = memq(local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3633(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,3,local+1); /*float-vector*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,2,local+0); /*list*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3640(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	if (!iscons(w)) goto irtdynaIF3765;
	local[0]= argv[0];
	goto irtdynaIF3766;
irtdynaIF3765:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
irtdynaIF3766:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3641(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0]->c.obj.iv[1];
	local[1]= argv[0];
	local[2]= fqv[262];
	local[3]= fqv[68];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3642(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0]->c.obj.iv[1];
	local[1]= argv[0];
	local[2]= fqv[262];
	local[3]= fqv[68];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3647(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0]->c.obj.iv[1];
	local[1]= argv[0];
	local[2]= fqv[262];
	local[3]= fqv[68];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3650(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w = env->c.clo.env2[1];
	if (memq(local[0],w)==NIL) goto irtdynaIF3767;
	local[0]= env->c.clo.env1[0]->c.obj.iv[5];
	ctx->vsp=local+1;
	w=(*ftab[34])(ctx,1,local+0,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= argv[0];
	local[2]= env->c.clo.env2[1];
	ctx->vsp=local+3;
	w=(*ftab[19])(ctx,2,local+1,&ftab[19],fqv[201]); /*position*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	goto irtdynaIF3768;
irtdynaIF3767:
	local[0]= env->c.clo.env1[0]->c.obj.iv[6];
	ctx->vsp=local+1;
	w=(*ftab[34])(ctx,1,local+0,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= argv[0];
	local[2]= env->c.clo.env1[0];
	local[3]= fqv[336];
	local[4]= env->c.clo.env2[1];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[19])(ctx,2,local+1,&ftab[19],fqv[201]); /*position*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
irtdynaIF3768:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3651(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env2[0];
	local[1]= argv[0];
	local[2]= env->c.clo.env2[1];
	ctx->vsp=local+3;
	w=(*ftab[19])(ctx,2,local+1,&ftab[19],fqv[201]); /*position*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3658(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w = env->c.clo.env2[1];
	if (memq(local[0],w)==NIL) goto irtdynaIF3769;
	local[0]= env->c.clo.env1[0]->c.obj.iv[5];
	ctx->vsp=local+1;
	w=(*ftab[34])(ctx,1,local+0,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= argv[0];
	local[2]= env->c.clo.env2[1];
	ctx->vsp=local+3;
	w=(*ftab[19])(ctx,2,local+1,&ftab[19],fqv[201]); /*position*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	goto irtdynaIF3770;
irtdynaIF3769:
	local[0]= env->c.clo.env1[0]->c.obj.iv[6];
	ctx->vsp=local+1;
	w=(*ftab[34])(ctx,1,local+0,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= argv[0];
	local[2]= env->c.clo.env1[0];
	local[3]= fqv[336];
	local[4]= env->c.clo.env2[1];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[19])(ctx,2,local+1,&ftab[19],fqv[201]); /*position*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
irtdynaIF3770:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3687(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[372];
	local[2]= env->c.clo.env1[0];
	local[3]= fqv[373];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= argv[1];
	local[5]= fqv[374];
	local[6]= env->c.clo.env1[2];
	local[7]= fqv[375];
	w=env->c.clo.env1[0]->c.obj.iv[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,9,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3690(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= env->c.clo.env2[4];
	local[1]= argv[0];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(*ftab[36])(ctx,3,local+0,&ftab[36],fqv[342]); /*midcoords*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3694(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = fqv[376];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3695(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w=env->c.clo.env1[0]->c.obj.iv[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (memq(local[0],w)==NIL) goto irtdynaIF3771;
	local[0]= fqv[376];
	goto irtdynaIF3772;
irtdynaIF3771:
	local[0]= fqv[377];
irtdynaIF3772:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3721(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=env->c.clo.env1[0]->c.obj.iv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= argv[0];
	local[2]= env->c.clo.env2[0];
	ctx->vsp=local+3;
	w=(*ftab[19])(ctx,2,local+1,&ftab[19],fqv[201]); /*position*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3738(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env2[4];
	ctx->vsp=local+2;
	w=(*ftab[19])(ctx,2,local+0,&ftab[19],fqv[201]); /*position*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3741(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w = fqv[378];
	if (memq(local[0],w)==NIL) goto irtdynaIF3773;
	local[0]= env->c.clo.env1[0]->c.obj.iv[21];
	goto irtdynaIF3774;
irtdynaIF3773:
	local[0]= makeint((eusinteger_t)5L);
	local[1]= env->c.clo.env1[0]->c.obj.iv[21];
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
irtdynaIF3774:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3744(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w = fqv[379];
	if (memq(local[0],w)==NIL) goto irtdynaIF3775;
	local[0]= env->c.clo.env1[0]->c.obj.iv[22];
	goto irtdynaIF3776;
irtdynaIF3775:
	local[0]= makeint((eusinteger_t)5L);
	local[1]= env->c.clo.env1[0]->c.obj.iv[22];
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
irtdynaIF3776:
	ctx->vsp=local+1;
	w=(*ftab[24])(ctx,1,local+0,&ftab[24],fqv[260]); /*deg2rad*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3745(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env2[6];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3746(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= (pointer)get_sym_func(fqv[342]);
	local[1]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtdynaCLO3777,env,argv,local);
	local[3]= fqv[380];
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)APPLY(ctx,3,local+0); /*apply*/
	local[0]= w;
	local[1]= env->c.clo.env1[6];
	local[2]= fqv[2];
	local[3]= env->c.clo.env2[4];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	local[4]= local[3];
	if (fqv[381]!=local[4]) goto irtdynaIF3778;
	local[4]= fqv[382];
	goto irtdynaIF3779;
irtdynaIF3778:
	local[4]= local[3];
	if (fqv[383]!=local[4]) goto irtdynaIF3780;
	local[4]= fqv[384];
	goto irtdynaIF3781;
irtdynaIF3780:
	local[4]= NIL;
irtdynaIF3781:
irtdynaIF3779:
	w = local[4];
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= local[0];
	local[3]= fqv[2];
	local[4]= fqv[385];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= local[0];
	local[4]= fqv[207];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)GREATERP(ctx,2,local+3); /*>*/
	if (w==NIL) goto irtdynaIF3782;
	local[3]= makeint((eusinteger_t)-1L);
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)SCALEVEC(ctx,2,local+3); /*scale*/
	local[1] = w;
	local[3]= local[1];
	goto irtdynaIF3783;
irtdynaIF3782:
	local[3]= NIL;
irtdynaIF3783:
	local[3]= NIL;
	local[4]= local[1];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,2,local+4); /*list*/
	local[4]= w;
irtdynaWHL3784:
	if (local[4]==NIL) goto irtdynaWHX3785;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[3];
	local[6]= makeint((eusinteger_t)2L);
	local[7]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+8;
	w=(pointer)SETELT(ctx,3,local+5); /*setelt*/
	goto irtdynaWHL3784;
irtdynaWHX3785:
	local[5]= NIL;
irtdynaBLK3786:
	w = NIL;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)VNORM(ctx,1,local+3); /*norm*/
	local[3]= w;
	local[4]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(*ftab[4])(ctx,2,local+3,&ftab[4],fqv[22]); /*eps=*/
	if (w==NIL) goto irtdynaIF3787;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)VNORM(ctx,1,local+3); /*norm*/
	local[3]= w;
	local[4]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(*ftab[4])(ctx,2,local+3,&ftab[4],fqv[22]); /*eps=*/
	if (w==NIL) goto irtdynaIF3787;
	local[3]= makeflt(0.0000000000000000000000e+00);
	goto irtdynaIF3788;
irtdynaIF3787:
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(*ftab[1])(ctx,1,local+3,&ftab[1],fqv[3]); /*normalize-vector*/
	local[3]= w;
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,1,local+4,&ftab[1],fqv[3]); /*normalize-vector*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+3); /*v**/
	local[3]= w;
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[41])(ctx,1,local+3,&ftab[41],fqv[386]); /*asin*/
	local[3]= w;
irtdynaIF3788:
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,6,local+4); /*float-vector*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3777(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env0->c.clo.env2[6];
	local[1]= argv[0];
	local[2]= env->c.clo.env0->c.clo.env2[4];
	ctx->vsp=local+3;
	w=(*ftab[19])(ctx,2,local+1,&ftab[19],fqv[201]); /*position*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___irtdyna(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[387];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtdynaIF3789;
	local[0]= fqv[388];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[389],w);
	goto irtdynaIF3790;
irtdynaIF3789:
	local[0]= fqv[390];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtdynaIF3790:
	local[0]= fqv[391];
	ctx->vsp=local+1;
	w=(*ftab[42])(ctx,1,local+0,&ftab[42],fqv[392]); /*require*/
	local[0]= fqv[393];
	ctx->vsp=local+1;
	w=(*ftab[42])(ctx,1,local+0,&ftab[42],fqv[392]); /*require*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2819joint_calc_inertia_matrix,fqv[71],fqv[394],fqv[395]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[396],module,irtdynaF2817calc_inertia_matrix_rotational,fqv[397]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[398],module,irtdynaF2818calc_inertia_matrix_linear,fqv[399]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2836rotational_joint_calc_inertia_matrix,fqv[71],fqv[400],fqv[401]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2838linear_joint_calc_inertia_matrix,fqv[71],fqv[402],fqv[403]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2840omniwheel_joint_calc_inertia_matrix,fqv[71],fqv[404],fqv[405]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2842sphere_joint_calc_inertia_matrix,fqv[71],fqv[406],fqv[407]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM28446dof_joint_calc_inertia_matrix,fqv[71],fqv[408],fqv[409]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2846bodyset_link_append_weight_no_update,fqv[31],fqv[121],fqv[410]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2852bodyset_link_append_centroid_no_update,fqv[33],fqv[121],fqv[411]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2862bodyset_link_append_inertia_no_update,fqv[36],fqv[121],fqv[412]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2874bodyset_link_append_mass_properties,fqv[48],fqv[121],fqv[413]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2890bodyset_link_propagate_mass_properties,fqv[44],fqv[121],fqv[414]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2908bodyset_link_calc_inertia_matrix_column,fqv[83],fqv[121],fqv[415]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2937cascaded_link_update_mass_properties,fqv[80],fqv[416],fqv[417]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2945cascaded_link_calc_inertia_matrix_from_link_list,fqv[90],fqv[416],fqv[418]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2973cascaded_link_calc_cog_jacobian_from_link_list,fqv[95],fqv[416],fqv[419]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2988cascaded_link_cog_jacobian_balance_nspace,fqv[420],fqv[416],fqv[421]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2998cascaded_link_calc_vel_for_cog,fqv[96],fqv[416],fqv[422]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3002cascaded_link_difference_cog_position,fqv[101],fqv[416],fqv[423]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3012cascaded_link_cog_convergence_check,fqv[424],fqv[416],fqv[425]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3030joint_calc_spacial_velocity_jacobian,fqv[135],fqv[394],fqv[426]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3033joint_calc_angular_velocity_jacobian,fqv[137],fqv[394],fqv[427]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3036joint_calc_spacial_acceleration_jacobian,fqv[139],fqv[394],fqv[428]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3039joint_calc_angular_acceleration_jacobian,fqv[142],fqv[394],fqv[429]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3042rotational_joint_calc_spacial_velocity_jacobian,fqv[135],fqv[400],fqv[430]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3044rotational_joint_calc_angular_velocity_jacobian,fqv[137],fqv[400],fqv[431]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3049rotational_joint_calc_spacial_acceleration_jacobian,fqv[139],fqv[400],fqv[432]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3051rotational_joint_calc_angular_acceleration_jacobian,fqv[142],fqv[400],fqv[433]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3053linear_joint_calc_spacial_velocity_jacobian,fqv[135],fqv[402],fqv[434]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3058linear_joint_calc_angular_velocity_jacobian,fqv[137],fqv[402],fqv[435]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3063linear_joint_calc_spacial_acceleration_jacobian,fqv[139],fqv[402],fqv[436]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3065linear_joint_calc_angular_acceleration_jacobian,fqv[142],fqv[402],fqv[437]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3070bodyset_link_reset_dynamics,fqv[438],fqv[121],fqv[439]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3072bodyset_link_angular_velocity,fqv[116],fqv[121],fqv[440]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3078bodyset_link_angular_acceleration,fqv[143],fqv[121],fqv[441]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3084bodyset_link_spacial_velocity,fqv[117],fqv[121],fqv[442]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3090bodyset_link_spacial_acceleration,fqv[140],fqv[121],fqv[443]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3096bodyset_link_force,fqv[150],fqv[121],fqv[444]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3098bodyset_link_moment,fqv[151],fqv[121],fqv[445]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3100bodyset_link_ext_force,fqv[243],fqv[121],fqv[446]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3106bodyset_link_ext_moment,fqv[244],fqv[121],fqv[447]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3112bodyset_link_forward_all_kinematics,fqv[144],fqv[121],fqv[448]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3140bodyset_link_inverse_dynamics,fqv[148],fqv[121],fqv[449]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3157cascaded_link_max_torque_vector,fqv[158],fqv[416],fqv[450]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3169cascaded_link_torque_ratio_vector,fqv[451],fqv[416],fqv[452]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3176cascaded_link_calc_torque_buffer_args,fqv[161],fqv[416],fqv[453]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3178cascaded_link_calc_torque,fqv[203],fqv[416],fqv[454]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3192cascaded_link_calc_torque_without_ext_wrench,fqv[163],fqv[416],fqv[455]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3202cascaded_link_calc_torque_from_vel_acc,fqv[169],fqv[416],fqv[456]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3222cascaded_link_calc_root_coords_vel_acc_from_pos,fqv[170],fqv[416],fqv[457]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3233cascaded_link_calc_av_vel_acc_from_pos,fqv[171],fqv[416],fqv[458]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3242cascaded_link_calc_torque_from_ext_wrenches,fqv[459],fqv[416],fqv[460]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3256cascaded_link_calc_zmp,fqv[227],fqv[416],fqv[461]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3269cascaded_link_calc_cop_from_force_moment,fqv[462],fqv[416],fqv[463]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3277cascaded_link_wrench_vector__wrench_list,fqv[464],fqv[416],fqv[465]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3282cascaded_link_wrench_list__wrench_vector,fqv[466],fqv[416],fqv[467]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3285cascaded_link_calc_contact_wrenches_from_total_wrench,fqv[468],fqv[416],fqv[469]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3294cascaded_link_draw_torque,fqv[470],fqv[416],fqv[471]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3307cascaded_link_weight,fqv[20],fqv[416],fqv[472]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3313cascaded_link_centroid,fqv[30],fqv[416],fqv[473]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3319cascaded_link_inertia_tensor,fqv[26],fqv[416],fqv[474]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3325cascaded_link_preview_control_dynamics_filter,fqv[475],fqv[416],fqv[476]);
	local[0]= fqv[477];
	local[1]= fqv[478];
	local[2]= fqv[477];
	local[3]= fqv[479];
	local[4]= loadglobal(fqv[480]);
	local[5]= fqv[481];
	local[6]= fqv[482];
	local[7]= fqv[483];
	local[8]= NIL;
	local[9]= fqv[484];
	local[10]= NIL;
	local[11]= fqv[108];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[485];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[43])(ctx,13,local+2,&ftab[43],fqv[486]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3382riccati_equation_init,fqv[223],fqv[477],fqv[487]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3384riccati_equation_solve,fqv[285],fqv[477],fqv[488]);
	local[0]= fqv[220];
	local[1]= fqv[478];
	local[2]= fqv[220];
	local[3]= fqv[479];
	local[4]= loadglobal(fqv[477]);
	local[5]= fqv[481];
	local[6]= fqv[489];
	local[7]= fqv[483];
	local[8]= NIL;
	local[9]= fqv[484];
	local[10]= NIL;
	local[11]= fqv[108];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[485];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[43])(ctx,13,local+2,&ftab[43],fqv[486]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3392preview_controller_init,fqv[223],fqv[220],fqv[490]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3411preview_controller_calc_f,fqv[286],fqv[220],fqv[491]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3422preview_controller_calc_u,fqv[287],fqv[220],fqv[492]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3424preview_controller_calc_xk,fqv[289],fqv[220],fqv[493]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3426preview_controller_update_xk,fqv[229],fqv[220],fqv[494]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3464preview_controller_finishedp,fqv[228],fqv[220],fqv[495]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3466preview_controller_last_reference_output_vector,fqv[288],fqv[220],fqv[496]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3468preview_controller_current_reference_output_vector,fqv[290],fqv[220],fqv[497]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3470preview_controller_current_state_vector,fqv[291],fqv[220],fqv[498]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3472preview_controller_current_output_vector,fqv[292],fqv[220],fqv[499]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3474preview_controller_current_additional_data,fqv[230],fqv[220],fqv[500]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3476preview_controller_pass_preview_controller,fqv[501],fqv[220],fqv[502]);
	local[0]= fqv[306];
	local[1]= fqv[478];
	local[2]= fqv[306];
	local[3]= fqv[479];
	local[4]= loadglobal(fqv[220]);
	local[5]= fqv[481];
	local[6]= fqv[503];
	local[7]= fqv[483];
	local[8]= NIL;
	local[9]= fqv[484];
	local[10]= NIL;
	local[11]= fqv[108];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[485];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[43])(ctx,13,local+2,&ftab[43],fqv[486]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3484extended_preview_controller_init,fqv[223],fqv[306],fqv[504]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3537extended_preview_controller_calc_f,fqv[286],fqv[306],fqv[505]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3550extended_preview_controller_calc_u,fqv[287],fqv[306],fqv[506]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3552extended_preview_controller_calc_xk,fqv[289],fqv[306],fqv[507]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3557extended_preview_controller_current_output_vector,fqv[292],fqv[306],fqv[508]);
	local[0]= fqv[222];
	local[1]= fqv[478];
	local[2]= fqv[222];
	local[3]= fqv[479];
	local[4]= loadglobal(fqv[480]);
	local[5]= fqv[481];
	local[6]= fqv[509];
	local[7]= fqv[483];
	local[8]= NIL;
	local[9]= fqv[484];
	local[10]= NIL;
	local[11]= fqv[108];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[485];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[43])(ctx,13,local+2,&ftab[43],fqv[486]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3559preview_control_cart_table_cog_trajectory_generator_init,fqv[223],fqv[222],fqv[510]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3570preview_control_cart_table_cog_trajectory_generator_refcog,fqv[236],fqv[222],fqv[511]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3572preview_control_cart_table_cog_trajectory_generator_cart_zmp,fqv[308],fqv[222],fqv[512]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3574preview_control_cart_table_cog_trajectory_generator_last_refzmp,fqv[513],fqv[222],fqv[514]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3576preview_control_cart_table_cog_trajectory_generator_current_refzmp,fqv[307],fqv[222],fqv[515]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3578preview_control_cart_table_cog_trajectory_generator_update_xk,fqv[229],fqv[222],fqv[516]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3587preview_control_cart_table_cog_trajectory_generator_finishedp,fqv[228],fqv[222],fqv[517]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3590preview_control_cart_table_cog_trajectory_generator_current_additional_data,fqv[230],fqv[222],fqv[518]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3592preview_control_cart_table_cog_trajectory_generator_pass_preview_controller,fqv[501],fqv[222],fqv[519]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3600preview_control_cart_table_cog_trajectory_generator_cog_z,fqv[349],fqv[222],fqv[520]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3602preview_control_cart_table_cog_trajectory_generator_update_cog_z,fqv[521],fqv[222],fqv[522]);
	local[0]= fqv[312];
	local[1]= fqv[478];
	local[2]= fqv[312];
	local[3]= fqv[479];
	local[4]= loadglobal(fqv[480]);
	local[5]= fqv[481];
	local[6]= fqv[523];
	local[7]= fqv[483];
	local[8]= NIL;
	local[9]= fqv[484];
	local[10]= NIL;
	local[11]= fqv[108];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[485];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[43])(ctx,13,local+2,&ftab[43],fqv[486]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3605gait_generator_init,fqv[223],fqv[312],fqv[524]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3610gait_generator_get_footstep_limbs,fqv[321],fqv[312],fqv[525]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3613gait_generator_get_counter_footstep_limbs,fqv[320],fqv[312],fqv[526]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3618gait_generator_get_limbs_zmp_list,fqv[323],fqv[312],fqv[527]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3621gait_generator_get_limbs_zmp,fqv[332],fqv[312],fqv[528]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3623gait_generator_get_swing_limbs,fqv[336],fqv[312],fqv[529]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3626gait_generator_initialize_gait_parameter,fqv[530],fqv[312],fqv[531]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3648gait_generator_finalize_gait_parameter,fqv[356],fqv[312],fqv[532]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3656gait_generator_make_gait_parameter,fqv[334],fqv[312],fqv[533]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3659gait_generator_calc_hoffarbib_pos_vel_acc,fqv[347],fqv[312],fqv[534]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3661gait_generator_calc_current_swing_leg_coords,fqv[372],fqv[312],fqv[535]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3669gait_generator_calc_ratio_from_double_support_ratio,fqv[373],fqv[312],fqv[536]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3675gait_generator_calc_current_refzmp,fqv[348],fqv[312],fqv[537]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3681gait_generator_calc_one_tick_gait_parameter,fqv[352],fqv[312],fqv[538]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3696gait_generator_proc_one_tick,fqv[539],fqv[312],fqv[540]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3714gait_generator_update_current_gait_parameter,fqv[355],fqv[312],fqv[541]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3724gait_generator_solve_angle_vector,fqv[353],fqv[312],fqv[542]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3732gait_generator_solve_av_by_move_centroid_on_foot,fqv[351],fqv[312],fqv[543]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3747gait_generator_cycloid_midpoint,fqv[368],fqv[312],fqv[544]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3758gait_generator_cycloid_midcoords,fqv[344],fqv[312],fqv[545]);
	local[0]= fqv[546];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtdynaIF3791;
	local[0]= fqv[547];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[389],w);
	goto irtdynaIF3792;
irtdynaIF3791:
	local[0]= fqv[548];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtdynaIF3792:
	local[0]= fqv[549];
	ctx->vsp=local+1;
	w=(*ftab[44])(ctx,1,local+0,&ftab[44],fqv[550]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<45; i++) ftab[i]=fcallx;
}
