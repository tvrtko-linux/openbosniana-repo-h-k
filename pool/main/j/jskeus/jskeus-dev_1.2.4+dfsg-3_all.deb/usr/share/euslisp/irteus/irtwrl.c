/* ./irtwrl.c :  entry=irtwrl */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "irtwrl.h"
#pragma init (register_irtwrl)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___irtwrl();
extern pointer build_quote_vector();
static int register_irtwrl()
  { add_module_initializer("___irtwrl", ___irtwrl);}

static pointer irtwrlF5526eus2wrl();
static pointer irtwrlF5527dump_object_to_wrl();

/*eus2wrl*/
static pointer irtwrlF5526eus2wrl(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtwrlRST5529:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= NIL;
	local[2]= argv[1];
	local[3]= fqv[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	if (w!=NIL) goto irtwrlIF5530;
	local[1] = T;
	local[2]= argv[1];
	local[3]= fqv[0];
	local[4]= fqv[1];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto irtwrlIF5531;
irtwrlIF5530:
	local[2]= NIL;
irtwrlIF5531:
	local[2]= argv[0];
	local[3]= fqv[2];
	local[4]= fqv[3];
	ctx->vsp=local+5;
	w=(*ftab[0])(ctx,3,local+2,&ftab[0],fqv[4]); /*open*/
	local[2]= w;
	ctx->vsp=local+3;
	w = makeclosure(codevec,quotevec,irtwrlUWP5532,env,argv,local);
	local[3]=(pointer)(ctx->protfp); local[4]=w;
	ctx->protfp=(struct protectframe *)(local+3);
	local[5]= (pointer)get_sym_func(fqv[5]);
	local[6]= argv[1];
	local[7]= local[2];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)APPLY(ctx,4,local+5); /*apply*/
	ctx->vsp=local+5;
	irtwrlUWP5532(ctx,0,local+5,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	if (local[1]==NIL) goto irtwrlIF5533;
	local[2]= argv[1];
	local[3]= fqv[0];
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto irtwrlIF5534;
irtwrlIF5533:
	local[2]= NIL;
irtwrlIF5534:
	w = local[2];
	local[0]= w;
irtwrlBLK5528:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtwrlUWP5532(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[2];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*dump-object-to-wrl*/
static pointer irtwrlF5527dump_object_to_wrl(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[6], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtwrlKEY5536;
	local[0] = makeflt(1.0000000000000000208167e-03);
irtwrlKEY5536:
	local[1]= local[0];
	local[2]= argv[0];
	local[3]= fqv[7];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SCALEVEC(ctx,2,local+1); /*scale*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[8];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)ROTANGLE(ctx,1,local+2); /*rotation-angle*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[9];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[10];
	ctx->vsp=local+6;
	w=(pointer)GETPROP(ctx,2,local+4); /*get*/
	local[4]= w;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= NIL;
	local[10]= NIL;
	local[11]= NIL;
	local[12]= NIL;
	local[13]= NIL;
	local[14]= argv[0];
	local[15]= fqv[11];
	ctx->vsp=local+16;
	w=(pointer)GETPROP(ctx,2,local+14); /*get*/
	if (w==NIL) goto irtwrlIF5537;
	local[14]= argv[0];
	local[15]= fqv[11];
	ctx->vsp=local+16;
	w=(pointer)GETPROP(ctx,2,local+14); /*get*/
	local[5] = w;
	local[14]= local[5];
	goto irtwrlIF5538;
irtwrlIF5537:
	local[14]= argv[0];
	local[15]= fqv[0];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	if (w==NIL) goto irtwrlIF5539;
	local[14]= argv[0];
	local[15]= fqv[0];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[5] = w;
	local[14]= local[5];
	goto irtwrlIF5540;
irtwrlIF5539:
	w = NIL;
	ctx->vsp=local+14;
	local[0]=w;
	goto irtwrlBLK5535;
irtwrlIF5540:
irtwrlIF5538:
	if (local[2]==NIL) goto irtwrlOR5543;
	local[14]= loadglobal(fqv[12]);
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	local[16]= loadglobal(fqv[13]);
	ctx->vsp=local+17;
	w=(pointer)COERCE(ctx,2,local+15); /*coerce*/
	if (memq(local[14],w)!=NIL) goto irtwrlOR5543;
	goto irtwrlIF5541;
irtwrlOR5543:
	local[14]= makeint((eusinteger_t)0L);
	local[15]= makeint((eusinteger_t)0L);
	local[16]= makeint((eusinteger_t)1L);
	ctx->vsp=local+17;
	w=(pointer)MKFLTVEC(ctx,3,local+14); /*float-vector*/
	local[12] = w;
	local[13] = makeint((eusinteger_t)0L);
	local[14]= local[13];
	goto irtwrlIF5542;
irtwrlIF5541:
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12] = (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13] = (w)->c.cons.car;
	local[14]= local[13];
irtwrlIF5542:
	local[14]= argv[1];
	local[15]= fqv[14];
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(pointer)XFORMAT(ctx,3,local+14); /*format*/
	local[14]= argv[1];
	local[15]= fqv[15];
	local[16]= local[1];
	local[17]= makeint((eusinteger_t)0L);
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	local[17]= local[1];
	local[18]= makeint((eusinteger_t)1L);
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	local[18]= local[1];
	local[19]= makeint((eusinteger_t)2L);
	ctx->vsp=local+20;
	w=(pointer)ELT(ctx,2,local+18); /*elt*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)XFORMAT(ctx,5,local+14); /*format*/
	local[14]= argv[1];
	local[15]= fqv[16];
	local[16]= local[12];
	local[17]= makeint((eusinteger_t)0L);
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	local[17]= local[12];
	local[18]= makeint((eusinteger_t)1L);
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	local[18]= local[12];
	local[19]= makeint((eusinteger_t)2L);
	ctx->vsp=local+20;
	w=(pointer)ELT(ctx,2,local+18); /*elt*/
	local[18]= w;
	local[19]= local[13];
	ctx->vsp=local+20;
	w=(pointer)XFORMAT(ctx,6,local+14); /*format*/
	local[14]= argv[1];
	local[15]= fqv[17];
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,2,local+14); /*format*/
	local[14]= argv[0];
	local[15]= loadglobal(fqv[18]);
	ctx->vsp=local+16;
	w=(pointer)DERIVEDP(ctx,2,local+14); /*derivedp*/
	if (w!=NIL) goto irtwrlOR5546;
	local[14]= argv[0];
	local[15]= loadglobal(fqv[19]);
	ctx->vsp=local+16;
	w=(pointer)DERIVEDP(ctx,2,local+14); /*derivedp*/
	if (w!=NIL) goto irtwrlOR5546;
	goto irtwrlIF5544;
irtwrlOR5546:
	local[14]= argv[0];
	local[15]= loadglobal(fqv[18]);
	ctx->vsp=local+16;
	w=(pointer)DERIVEDP(ctx,2,local+14); /*derivedp*/
	if (w==NIL) goto irtwrlIF5547;
	local[14]= argv[0];
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,1,local+14,&ftab[1],fqv[20]); /*body-to-faces*/
	local[14]= w;
	local[15]= fqv[21];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[8] = w;
	local[9] = argv[0]->c.obj.iv[12];
	local[10] = local[9];
	local[14]= local[10];
	goto irtwrlIF5548;
irtwrlIF5547:
	local[14]= NIL;
irtwrlIF5548:
	local[14]= argv[0];
	local[15]= loadglobal(fqv[19]);
	ctx->vsp=local+16;
	w=(pointer)DERIVEDP(ctx,2,local+14); /*derivedp*/
	if (w==NIL) goto irtwrlIF5549;
	local[14]= argv[0];
	ctx->vsp=local+15;
	w=(*ftab[1])(ctx,1,local+14,&ftab[1],fqv[20]); /*body-to-faces*/
	local[14]= w;
	local[15]= fqv[21];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[8] = w;
	ctx->vsp=local+14;
	local[14]= makeclosure(codevec,quotevec,irtwrlCLO5551,env,argv,local);
	local[15]= argv[0];
	local[16]= fqv[22];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)MAPCAR(ctx,2,local+14); /*mapcar*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(*ftab[2])(ctx,1,local+14,&ftab[2],fqv[23]); /*flatten*/
	local[9] = w;
	local[10] = local[9];
	local[14]= local[10];
	goto irtwrlIF5550;
irtwrlIF5549:
	local[14]= NIL;
irtwrlIF5550:
	local[14]= argv[1];
	local[15]= fqv[24];
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,2,local+14); /*format*/
	local[14]= argv[1];
	local[15]= fqv[25];
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,2,local+14); /*format*/
	if (local[4]==NIL) goto irtwrlIF5552;
	local[14]= fqv[26];
	ctx->vsp=local+15;
	w=(pointer)FINDPACKAGE(ctx,1,local+14); /*find-package*/
	if (w==NIL) goto irtwrlIF5552;
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(*ftab[3])(ctx,1,local+14,&ftab[3],fqv[27]); /*gl::find-color*/
	local[6] = w;
	local[14]= local[6];
	local[15]= fqv[28];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[7] = w;
	local[14]= argv[1];
	local[15]= fqv[29];
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,2,local+14); /*format*/
	local[14]= argv[1];
	local[15]= fqv[30];
	local[16]= local[7];
	local[17]= makeint((eusinteger_t)0L);
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	local[17]= local[7];
	local[18]= makeint((eusinteger_t)1L);
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	local[18]= local[7];
	local[19]= makeint((eusinteger_t)2L);
	ctx->vsp=local+20;
	w=(pointer)ELT(ctx,2,local+18); /*elt*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)XFORMAT(ctx,5,local+14); /*format*/
	local[14]= argv[1];
	local[15]= fqv[31];
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,2,local+14); /*format*/
	local[14]= w;
	goto irtwrlIF5553;
irtwrlIF5552:
	local[14]= NIL;
irtwrlIF5553:
	local[14]= argv[1];
	local[15]= fqv[32];
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,2,local+14); /*format*/
	local[14]= argv[1];
	local[15]= fqv[33];
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(pointer)XFORMAT(ctx,3,local+14); /*format*/
	local[14]= argv[1];
	local[15]= fqv[34];
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,2,local+14); /*format*/
	local[14]= argv[1];
	local[15]= fqv[35];
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,2,local+14); /*format*/
	local[14]= argv[1];
	local[15]= fqv[36];
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(pointer)XFORMAT(ctx,3,local+14); /*format*/
	local[14]= argv[1];
	local[15]= fqv[37];
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,2,local+14); /*format*/
irtwrlWHL5554:
	if (local[10]==NIL) goto irtwrlWHX5555;
	local[14]= local[0];
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10] = (w)->c.cons.cdr;
	w = local[15];
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)SCALEVEC(ctx,2,local+14); /*scale*/
	local[11] = w;
	if (local[10]==NIL) goto irtwrlIF5557;
	local[14]= argv[1];
	local[15]= fqv[38];
	local[16]= local[11];
	local[17]= makeint((eusinteger_t)0L);
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	local[17]= local[11];
	local[18]= makeint((eusinteger_t)1L);
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	local[18]= local[11];
	local[19]= makeint((eusinteger_t)2L);
	ctx->vsp=local+20;
	w=(pointer)ELT(ctx,2,local+18); /*elt*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)XFORMAT(ctx,5,local+14); /*format*/
	local[14]= w;
	goto irtwrlIF5558;
irtwrlIF5557:
	local[14]= argv[1];
	local[15]= fqv[39];
	local[16]= local[11];
	local[17]= makeint((eusinteger_t)0L);
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	local[17]= local[11];
	local[18]= makeint((eusinteger_t)1L);
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	local[18]= local[11];
	local[19]= makeint((eusinteger_t)2L);
	ctx->vsp=local+20;
	w=(pointer)ELT(ctx,2,local+18); /*elt*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)XFORMAT(ctx,5,local+14); /*format*/
	local[14]= w;
irtwrlIF5558:
	goto irtwrlWHL5554;
irtwrlWHX5555:
	local[14]= NIL;
irtwrlBLK5556:
	local[14]= argv[1];
	local[15]= fqv[40];
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,2,local+14); /*format*/
	local[14]= argv[1];
	local[15]= fqv[41];
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,2,local+14); /*format*/
	local[14]= argv[1];
	local[15]= fqv[42];
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,2,local+14); /*format*/
irtwrlWHL5559:
	if (local[8]==NIL) goto irtwrlWHX5560;
	local[14]= argv[1];
	local[15]= fqv[43];
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,2,local+14); /*format*/
	local[14]= NIL;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[15];
	local[15]= w;
	local[16]= fqv[44];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.cdr;
irtwrlWHL5562:
	if (local[15]==NIL) goto irtwrlWHX5563;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15] = (w)->c.cons.cdr;
	w = local[16];
	local[14] = w;
	local[16]= argv[1];
	local[17]= fqv[45];
	local[18]= argv[0];
	local[19]= fqv[46];
	local[20]= local[14];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,3,local+18); /*send*/
	local[18]= w;
	local[19]= local[9];
	local[20]= fqv[47];
	local[21]= (pointer)get_sym_func(fqv[48]);
	ctx->vsp=local+22;
	w=(*ftab[4])(ctx,4,local+18,&ftab[4],fqv[49]); /*position*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)XFORMAT(ctx,3,local+16); /*format*/
	goto irtwrlWHL5562;
irtwrlWHX5563:
	local[16]= NIL;
irtwrlBLK5564:
	w = NIL;
	local[14]= argv[1];
	local[15]= fqv[50];
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,2,local+14); /*format*/
	goto irtwrlWHL5559;
irtwrlWHX5560:
	local[14]= NIL;
irtwrlBLK5561:
	local[14]= argv[1];
	local[15]= fqv[51];
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,2,local+14); /*format*/
	local[14]= argv[1];
	local[15]= fqv[52];
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,2,local+14); /*format*/
	local[14]= argv[1];
	local[15]= fqv[53];
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,2,local+14); /*format*/
	local[14]= w;
	goto irtwrlIF5545;
irtwrlIF5544:
	local[14]= NIL;
irtwrlIF5545:
irtwrlWHL5565:
	if (local[3]==NIL) goto irtwrlWHX5566;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[14];
	local[14]= w;
	local[15]= argv[1];
	local[16]= fqv[54];
	local[17]= local[0];
	ctx->vsp=local+18;
	w=(pointer)irtwrlF5527dump_object_to_wrl(ctx,4,local+14); /*dump-object-to-wrl*/
	if (w==NIL) goto irtwrlIF5568;
	local[14]= makeint((eusinteger_t)1L);
	local[15]= local[3];
	ctx->vsp=local+16;
	w=(pointer)LENGTH(ctx,1,local+15); /*length*/
	if ((eusinteger_t)local[14] >= (eusinteger_t)w) goto irtwrlIF5568;
	local[14]= argv[1];
	local[15]= fqv[55];
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,2,local+14); /*format*/
	local[14]= w;
	goto irtwrlIF5569;
irtwrlIF5568:
	local[14]= NIL;
irtwrlIF5569:
	goto irtwrlWHL5565;
irtwrlWHX5566:
	local[14]= NIL;
irtwrlBLK5567:
	local[14]= argv[1];
	local[15]= fqv[56];
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,2,local+14); /*format*/
	local[14]= argv[1];
	local[15]= fqv[57];
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,2,local+14); /*format*/
	w = T;
	local[0]= w;
irtwrlBLK5535:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtwrlCLO5551(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0]->c.obj.iv[12];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___irtwrl(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[58];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtwrlIF5570;
	local[0]= fqv[59];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[60],w);
	goto irtwrlIF5571;
irtwrlIF5570:
	local[0]= fqv[61];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtwrlIF5571:
	local[0]= fqv[62];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[63],module,irtwrlF5526eus2wrl,fqv[64]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[5],module,irtwrlF5527dump_object_to_wrl,fqv[65]);
	local[0]= fqv[66];
	local[1]= fqv[67];
	ctx->vsp=local+2;
	w=(*ftab[5])(ctx,2,local+0,&ftab[5],fqv[68]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<6; i++) ftab[i]=fcallx;
}
