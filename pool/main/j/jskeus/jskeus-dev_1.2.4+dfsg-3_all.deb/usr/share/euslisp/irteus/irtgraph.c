/* ./irtgraph.c :  entry=irtgraph */
/* compiled by EusLisp 9.27 for Linux64 created on Thu, 03 Sep 2020 07:38:01 +0000 */
#include "eus.h"
#include "irtgraph.h"
#pragma init (register_irtgraph)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___irtgraph();
extern pointer build_quote_vector();
static int register_irtgraph()
  { add_module_initializer("___irtgraph", ___irtgraph);}


/*:init*/
static pointer irtgraphM757node_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtgraphENT760;}
	local[0]= NIL;
irtgraphENT760:
irtgraphENT759:
	if (n>4) maerror();
	local[1]= argv[0];
	local[2]= fqv[0];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[1];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	w = argv[0];
	local[0]= w;
irtgraphBLK758:
	ctx->vsp=local; return(local[0]);}

/*:arc-list*/
static pointer irtgraphM761node_arc_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK762:
	ctx->vsp=local; return(local[0]);}

/*:successors*/
static pointer irtgraphM763node_successors(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtgraphCLO765,env,argv,local);
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
irtgraphBLK764:
	ctx->vsp=local; return(local[0]);}

/*:add-arc*/
static pointer irtgraphM766node_add_arc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	w = argv[0]->c.obj.iv[1];
	ctx->vsp=local+1;
	argv[0]->c.obj.iv[1] = cons(ctx,local[0],w);
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK767:
	ctx->vsp=local; return(local[0]);}

/*:remove-arc*/
static pointer irtgraphM768node_remove_arc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(*ftab[0])(ctx,2,local+0,&ftab[0],fqv[2]); /*remove*/
	argv[0]->c.obj.iv[1] = w;
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK769:
	ctx->vsp=local; return(local[0]);}

/*:remove-all-arcs*/
static pointer irtgraphM770node_remove_all_arcs(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	argv[0]->c.obj.iv[1] = NIL;
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK771:
	ctx->vsp=local; return(local[0]);}

/*:unlink*/
static pointer irtgraphM772node_unlink(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtgraphCLO774,env,argv,local);
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,2,local+0,&ftab[1],fqv[3]); /*remove-if*/
	argv[0]->c.obj.iv[1] = w;
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK773:
	ctx->vsp=local; return(local[0]);}

/*:image*/
static pointer irtgraphM775node_image(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT778;}
	local[0]= NIL;
irtgraphENT778:
irtgraphENT777:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtgraphIF779;
	argv[0]->c.obj.iv[2] = local[0];
	local[1]= argv[0]->c.obj.iv[2];
	goto irtgraphIF780;
irtgraphIF779:
	local[1]= NIL;
irtgraphIF780:
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
irtgraphBLK776:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgraphCLO765(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= argv[0];
	local[2]= fqv[4];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgraphCLO774(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[2];
	local[1]= argv[0];
	local[2]= fqv[4];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	w = ((w)==(local[0])?T:NIL);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtgraphM781arc_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	argv[0]->c.obj.iv[1] = argv[2];
	argv[0]->c.obj.iv[2] = argv[3];
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= fqv[5];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	w = argv[0];
	local[0]= w;
irtgraphBLK782:
	ctx->vsp=local; return(local[0]);}

/*:from*/
static pointer irtgraphM783arc_from(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK784:
	ctx->vsp=local; return(local[0]);}

/*:to*/
static pointer irtgraphM785arc_to(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
irtgraphBLK786:
	ctx->vsp=local; return(local[0]);}

/*:prin1*/
static pointer irtgraphM787arc_prin1(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT790;}
	local[0]= T;
irtgraphENT790:
irtgraphENT789:
	ctx->vsp=local+1;
	local[1]= minilist(ctx,&argv[n],n-3);
	local[2]= argv[0];
	local[3]= *(ovafptr(argv[1],fqv[6]));
	local[4]= fqv[7];
	local[5]= local[0];
	local[6]= NIL;
	local[7]= fqv[8];
	local[8]= argv[0]->c.obj.iv[1];
	local[9]= argv[0]->c.obj.iv[2];
	local[10]= local[1];
	if (local[10]!=NIL) goto irtgraphOR791;
	local[10]= fqv[9];
irtgraphOR791:
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,5,local+6); /*format*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SENDMESSAGE(ctx,5,local+2); /*send-message*/
	local[0]= w;
irtgraphBLK788:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtgraphM792directed_graph_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0];
	local[0]= w;
irtgraphBLK793:
	ctx->vsp=local; return(local[0]);}

/*:successors*/
static pointer irtgraphM794directed_graph_successors(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[10],w);
irtgraphRST796:
	ctx->vsp=local+3;
	local[3]= minilist(ctx,&argv[n],n-3);
	local[4]= loadglobal(fqv[10]);
	local[5]= fqv[11];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	unbindx(ctx,1);
	w = local[4];
	local[0]= w;
irtgraphBLK795:
	ctx->vsp=local; return(local[0]);}

/*:node*/
static pointer irtgraphM797directed_graph_node(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= fqv[12];
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,irtgraphCLO799,env,argv,local);
	local[4]= fqv[13];
	local[5]= (pointer)get_sym_func(fqv[14]);
	ctx->vsp=local+6;
	w=(*ftab[2])(ctx,6,local+0,&ftab[2],fqv[15]); /*find*/
	local[0]= w;
irtgraphBLK798:
	ctx->vsp=local; return(local[0]);}

/*:nodes*/
static pointer irtgraphM800directed_graph_nodes(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT803;}
	local[0]= NIL;
irtgraphENT803:
irtgraphENT802:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtgraphIF804;
	local[1]= NIL;
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(*ftab[3])(ctx,2,local+2,&ftab[3],fqv[16]); /*set-difference*/
	local[2]= w;
irtgraphWHL806:
	if (local[2]==NIL) goto irtgraphWHX807;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= local[0];
	local[4]= fqv[17];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(*ftab[4])(ctx,3,local+3,&ftab[4],fqv[18]); /*send-all*/
	goto irtgraphWHL806;
irtgraphWHX807:
	local[3]= NIL;
irtgraphBLK808:
	w = NIL;
	argv[0]->c.obj.iv[1] = local[0];
	local[1]= argv[0]->c.obj.iv[1];
	goto irtgraphIF805;
irtgraphIF804:
	local[1]= NIL;
irtgraphIF805:
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK801:
	ctx->vsp=local; return(local[0]);}

/*:add-node*/
static pointer irtgraphM809directed_graph_add_node(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	w = argv[0]->c.obj.iv[1];
	ctx->vsp=local+1;
	argv[0]->c.obj.iv[1] = cons(ctx,local[0],w);
	w = argv[2];
	local[0]= w;
irtgraphBLK810:
	ctx->vsp=local; return(local[0]);}

/*:remove-node*/
static pointer irtgraphM811directed_graph_remove_node(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(*ftab[0])(ctx,2,local+0,&ftab[0],fqv[2]); /*remove*/
	argv[0]->c.obj.iv[1] = w;
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= fqv[17];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(*ftab[4])(ctx,3,local+0,&ftab[4],fqv[18]); /*send-all*/
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK812:
	ctx->vsp=local; return(local[0]);}

/*:clear-nodes*/
static pointer irtgraphM813directed_graph_clear_nodes(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= fqv[19];
	ctx->vsp=local+2;
	w=(*ftab[4])(ctx,2,local+0,&ftab[4],fqv[18]); /*send-all*/
	argv[0]->c.obj.iv[1] = NIL;
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK814:
	ctx->vsp=local; return(local[0]);}

/*:add-arc-from-to*/
static pointer irtgraphM815directed_graph_add_arc_from_to(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= loadglobal(fqv[20]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[21];
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	w = local[0];
	local[0]= w;
irtgraphBLK816:
	ctx->vsp=local; return(local[0]);}

/*:remove-arc*/
static pointer irtgraphM817directed_graph_remove_arc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[20],w);
	local[3]= loadglobal(fqv[20]);
	local[4]= fqv[22];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= fqv[23];
	local[5]= loadglobal(fqv[20]);
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtgraphBLK818:
	ctx->vsp=local; return(local[0]);}

/*:adjacency-matrix*/
static pointer irtgraphM819directed_graph_adjacency_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= local[0];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[5])(ctx,2,local+3,&ftab[5],fqv[24]); /*make-matrix*/
	local[1] = w;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= local[0];
irtgraphWHL821:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto irtgraphWHX822;
	local[5]= NIL;
	local[6]= argv[0]->c.obj.iv[1];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= fqv[25];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= fqv[4];
	ctx->vsp=local+8;
	w=(*ftab[4])(ctx,2,local+6,&ftab[4],fqv[18]); /*send-all*/
	local[6]= w;
irtgraphWHL824:
	if (local[6]==NIL) goto irtgraphWHX825;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= local[5];
	local[8]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+9;
	w=(*ftab[6])(ctx,2,local+7,&ftab[6],fqv[26]); /*position*/
	local[2] = w;
	if (local[2]==NIL) goto irtgraphIF827;
	local[7]= local[1];
	local[8]= local[3];
	local[9]= local[2];
	local[10]= local[1];
	local[11]= local[3];
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)AREF(ctx,3,local+10); /*aref*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)ASET(ctx,4,local+7); /*aset*/
	local[7]= w;
	goto irtgraphIF828;
irtgraphIF827:
	local[7]= NIL;
irtgraphIF828:
	goto irtgraphWHL824;
irtgraphWHX825:
	local[7]= NIL;
irtgraphBLK826:
	w = NIL;
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto irtgraphWHL821;
irtgraphWHX822:
	local[5]= NIL;
irtgraphBLK823:
	w = NIL;
	w = local[1];
	local[0]= w;
irtgraphBLK820:
	ctx->vsp=local; return(local[0]);}

/*:adjacency-list*/
static pointer irtgraphM829directed_graph_adjacency_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtgraphCLO831,env,argv,local);
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
irtgraphBLK830:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgraphCLO799(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[0];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgraphCLO831(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtgraphCLO832,env,argv,local);
	local[1]= argv[0];
	local[2]= fqv[25];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[4];
	ctx->vsp=local+3;
	w=(*ftab[4])(ctx,2,local+1,&ftab[4],fqv[18]); /*send-all*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
	local[1]= (pointer)get_sym_func(fqv[27]);
	ctx->vsp=local+2;
	w=(pointer)SORT(ctx,2,local+0); /*sort*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgraphCLO832(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env0->c.clo.env1[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,2,local+0,&ftab[6],fqv[26]); /*position*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtgraphM833costed_arc_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	argv[0]->c.obj.iv[3] = argv[4];
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[6]));
	local[2]= fqv[21];
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)SENDMESSAGE(ctx,5,local+0); /*send-message*/
	local[0]= w;
irtgraphBLK834:
	ctx->vsp=local; return(local[0]);}

/*:cost*/
static pointer irtgraphM835costed_arc_cost(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
irtgraphBLK836:
	ctx->vsp=local; return(local[0]);}

/*:add-arc*/
static pointer irtgraphM837costed_graph_add_arc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[28], &argv[5], n-5, local+0, 0);
	if (n & (1<<0)) goto irtgraphKEY839;
	local[0] = NIL;
irtgraphKEY839:
	local[1]= argv[0];
	local[2]= fqv[29];
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= fqv[30];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,7,local+1); /*send*/
	local[0]= w;
irtgraphBLK838:
	ctx->vsp=local; return(local[0]);}

/*:add-arc-from-to*/
static pointer irtgraphM840costed_graph_add_arc_from_to(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[31], &argv[5], n-5, local+0, 0);
	if (n & (1<<0)) goto irtgraphKEY842;
	local[0] = NIL;
irtgraphKEY842:
	local[1]= loadglobal(fqv[32]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[21];
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= argv[4];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,5,local+2); /*send*/
	w = local[1];
	local[1]= w;
	if (local[0]==NIL) goto irtgraphIF843;
	local[2]= local[1];
	local[3]= loadglobal(fqv[32]);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= local[3];
	local[5]= fqv[21];
	local[6]= argv[3];
	local[7]= argv[2];
	local[8]= argv[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	w = local[3];
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,2,local+2); /*list*/
	local[2]= w;
	goto irtgraphIF844;
irtgraphIF843:
	local[2]= local[1];
irtgraphIF844:
	w = local[2];
	local[0]= w;
irtgraphBLK841:
	ctx->vsp=local; return(local[0]);}

/*:path-cost*/
static pointer irtgraphM845costed_graph_path_cost(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	w = argv[3];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[20],w);
	local[3]= loadglobal(fqv[20]);
	local[4]= fqv[33];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtgraphBLK846:
	ctx->vsp=local; return(local[0]);}

/*:goal-test*/
static pointer irtgraphM847graph_goal_test(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[3];
	w = ((argv[2])==(local[0])?T:NIL);
	local[0]= w;
irtgraphBLK848:
	ctx->vsp=local; return(local[0]);}

/*:path-cost*/
static pointer irtgraphM849graph_path_cost(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	w = argv[3];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[20],w);
	local[3]= argv[2];
	local[4]= fqv[33];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= loadglobal(fqv[20]);
	local[5]= fqv[33];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
irtgraphBLK850:
	ctx->vsp=local; return(local[0]);}

/*:start-state*/
static pointer irtgraphM851graph_start_state(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT854;}
	local[0]= NIL;
irtgraphENT854:
irtgraphENT853:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtgraphIF855;
	argv[0]->c.obj.iv[2] = local[0];
	local[1]= argv[0]->c.obj.iv[2];
	goto irtgraphIF856;
irtgraphIF855:
	local[1]= NIL;
irtgraphIF856:
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
irtgraphBLK852:
	ctx->vsp=local; return(local[0]);}

/*:goal-state*/
static pointer irtgraphM857graph_goal_state(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT860;}
	local[0]= NIL;
irtgraphENT860:
irtgraphENT859:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtgraphIF861;
	argv[0]->c.obj.iv[3] = local[0];
	local[1]= argv[0]->c.obj.iv[3];
	goto irtgraphIF862;
irtgraphIF861:
	local[1]= NIL;
irtgraphIF862:
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
irtgraphBLK858:
	ctx->vsp=local; return(local[0]);}

/*:add-arc*/
static pointer irtgraphM863graph_add_arc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[34], &argv[4], n-4, local+0, 0);
	if (n & (1<<0)) goto irtgraphKEY865;
	local[0] = NIL;
irtgraphKEY865:
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)LISTP(ctx,1,local+1); /*listp*/
	if (w!=NIL) goto irtgraphIF866;
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	argv[3] = w;
	local[1]= argv[3];
	goto irtgraphIF867;
irtgraphIF866:
	local[1]= NIL;
irtgraphIF867:
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtgraphCLO868,env,argv,local);
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	local[0]= w;
irtgraphBLK864:
	ctx->vsp=local; return(local[0]);}

/*:add-arc-from-to*/
static pointer irtgraphM869graph_add_arc_from_to(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[35], &argv[4], n-4, local+0, 0);
	if (n & (1<<0)) goto irtgraphKEY871;
	local[0] = NIL;
irtgraphKEY871:
	local[1]= argv[0];
	local[2]= *(ovafptr(argv[1],fqv[6]));
	local[3]= fqv[29];
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= makeint((eusinteger_t)1L);
	local[7]= fqv[30];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)SENDMESSAGE(ctx,8,local+1); /*send-message*/
	local[0]= w;
irtgraphBLK870:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgraphCLO868(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[29];
	local[2]= env->c.clo.env1[2];
	local[3]= argv[0];
	local[4]= fqv[30];
	local[5]= env->c.clo.env2[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,6,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:write-to-dot-stream*/
static pointer irtgraphM872directed_graph_write_to_dot_stream(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT877;}
	local[0]= loadglobal(fqv[36]);
irtgraphENT877:
	if (n>=4) { local[1]=(argv[3]); goto irtgraphENT876;}
	local[1]= NIL;
irtgraphENT876:
	if (n>=5) { local[2]=(argv[4]); goto irtgraphENT875;}
	local[2]= fqv[37];
irtgraphENT875:
irtgraphENT874:
	if (n>5) maerror();
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,irtgraphCLO878,env,argv,local);
	local[4]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+5;
	w=(pointer)MAPCAR(ctx,2,local+3); /*mapcar*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[38];
	local[6]= fqv[39];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[38];
	local[7]= fqv[40];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= argv[0];
	local[7]= fqv[38];
	local[8]= fqv[41];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= ((w)==NIL?T:NIL);
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtgraphFLET879,env,argv,local);
	local[8]= local[0];
	local[9]= fqv[42];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,3,local+8); /*format*/
	local[8]= NIL;
	local[9]= argv[0]->c.obj.iv[1];
irtgraphWHL880:
	if (local[9]==NIL) goto irtgraphWHX881;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= local[0];
	local[11]= fqv[43];
	ctx->vsp=local+12;
	w=(pointer)XFORMAT(ctx,2,local+10); /*format*/
	local[10]= local[0];
	local[11]= fqv[44];
	local[12]= local[8];
	w = local[7];
	ctx->vsp=local+13;
	w=irtgraphFLET879(ctx,1,local+12,w);
	local[12]= w;
	local[13]= local[8];
	local[14]= fqv[0];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	local[14]= local[8];
	local[15]= fqv[1];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	if (w==NIL) goto irtgraphIF883;
	local[14]= NIL;
	local[15]= fqv[45];
	local[16]= local[8];
	local[17]= fqv[1];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)XFORMAT(ctx,3,local+14); /*format*/
	local[14]= w;
	goto irtgraphIF884;
irtgraphIF883:
	local[14]= fqv[46];
irtgraphIF884:
	ctx->vsp=local+15;
	w=(pointer)XFORMAT(ctx,5,local+10); /*format*/
	goto irtgraphWHL880;
irtgraphWHX881:
	local[10]= NIL;
irtgraphBLK882:
	w = NIL;
	local[8]= fqv[13];
	local[9]= (pointer)get_sym_func(fqv[14]);
	ctx->vsp=local+10;
	w=(*ftab[7])(ctx,2,local+8,&ftab[7],fqv[47]); /*make-hash-table*/
	local[8]= w;
	local[9]= fqv[13];
	local[10]= (pointer)get_sym_func(fqv[14]);
	ctx->vsp=local+11;
	w=(*ftab[7])(ctx,2,local+9,&ftab[7],fqv[47]); /*make-hash-table*/
	local[9]= w;
	local[10]= NIL;
irtgraphWHL885:
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[11];
	local[10] = w;
	if (local[10]==NIL) goto irtgraphWHX886;
	if (local[1]==NIL) goto irtgraphWHX886;
	local[11]= local[10];
	local[12]= fqv[48];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= fqv[48];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	local[12]= local[8];
	local[13]= fqv[49];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(*ftab[8])(ctx,3,local+11,&ftab[8],fqv[50]); /*sethash*/
	goto irtgraphWHL885;
irtgraphWHX886:
	local[11]= NIL;
irtgraphBLK887:
	w = local[11];
	local[10]= NIL;
	local[11]= argv[0]->c.obj.iv[1];
irtgraphWHL888:
	if (local[11]==NIL) goto irtgraphWHX889;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11] = (w)->c.cons.cdr;
	w = local[12];
	local[10] = w;
	local[12]= argv[0];
	local[13]= fqv[11];
	local[14]= local[10];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= w;
	local[13]= NIL;
	local[14]= local[12];
irtgraphWHL891:
	if (local[14]==NIL) goto irtgraphWHX892;
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14] = (w)->c.cons.cdr;
	w = local[15];
	local[13] = w;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.cdr;
	local[17]= T;
	local[18]= NIL;
	local[19]= NIL;
	if (local[6]!=NIL) goto irtgraphIF894;
	local[20]= local[10];
	w = local[16];
	ctx->vsp=local+21;
	local[20]= cons(ctx,local[20],w);
	local[21]= local[8];
	ctx->vsp=local+22;
	w=(*ftab[9])(ctx,2,local+20,&ftab[9],fqv[51]); /*gethash*/
	if (w==NIL) goto irtgraphIF894;
	local[18] = T;
	local[20]= fqv[52];
	w = local[19];
	ctx->vsp=local+21;
	local[19] = cons(ctx,local[20],w);
	local[20]= local[19];
	goto irtgraphIF895;
irtgraphIF894:
	local[20]= NIL;
irtgraphIF895:
	if (local[5]==NIL) goto irtgraphIF896;
	local[20]= NIL;
	local[21]= fqv[53];
	local[22]= local[15];
	local[23]= fqv[0];
	ctx->vsp=local+24;
	w=(pointer)SEND(ctx,2,local+22); /*send*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)XFORMAT(ctx,3,local+20); /*format*/
	local[20]= w;
	w = local[19];
	ctx->vsp=local+21;
	local[19] = cons(ctx,local[20],w);
	local[20]= local[19];
	goto irtgraphIF897;
irtgraphIF896:
	local[20]= NIL;
irtgraphIF897:
	if (local[4]!=NIL) goto irtgraphIF898;
	local[20]= local[10];
	w = local[16];
	ctx->vsp=local+21;
	local[20]= cons(ctx,local[20],w);
	local[21]= local[9];
	ctx->vsp=local+22;
	w=(*ftab[9])(ctx,2,local+20,&ftab[9],fqv[51]); /*gethash*/
	if (w==NIL) goto irtgraphCON901;
	local[17] = NIL;
	local[20]= local[17];
	goto irtgraphCON900;
irtgraphCON901:
	local[20]= local[16];
	w = local[10];
	ctx->vsp=local+21;
	local[20]= cons(ctx,local[20],w);
	local[21]= local[9];
	ctx->vsp=local+22;
	w=(*ftab[9])(ctx,2,local+20,&ftab[9],fqv[51]); /*gethash*/
	if (w==NIL) goto irtgraphCON902;
	local[17] = NIL;
	local[20]= local[17];
	goto irtgraphCON900;
irtgraphCON902:
	local[20]= local[10];
	local[21]= (pointer)get_sym_func(fqv[54]);
	local[22]= argv[0];
	local[23]= fqv[11];
	local[24]= local[16];
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,3,local+22); /*send*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)MAPCAR(ctx,2,local+21); /*mapcar*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(*ftab[10])(ctx,2,local+20,&ftab[10],fqv[55]); /*member*/
	if (w==NIL) goto irtgraphCON903;
	local[20]= fqv[56];
	w = local[19];
	ctx->vsp=local+21;
	local[19] = cons(ctx,local[20],w);
	local[20]= local[19];
	goto irtgraphCON900;
irtgraphCON903:
	local[20]= NIL;
irtgraphCON900:
	goto irtgraphIF899;
irtgraphIF898:
	local[20]= NIL;
irtgraphIF899:
	if (local[19]!=NIL) goto irtgraphIF904;
	local[19] = fqv[57];
	local[20]= local[19];
	goto irtgraphIF905;
irtgraphIF904:
	local[20]= NIL;
irtgraphIF905:
	if (local[17]==NIL) goto irtgraphIF906;
	local[20]= local[10];
	w = local[16];
	ctx->vsp=local+21;
	local[20]= cons(ctx,local[20],w);
	local[21]= local[9];
	local[22]= local[19];
	ctx->vsp=local+23;
	w=(*ftab[8])(ctx,3,local+20,&ftab[8],fqv[50]); /*sethash*/
	local[20]= w;
	goto irtgraphIF907;
irtgraphIF906:
	local[20]= NIL;
irtgraphIF907:
	w = local[20];
	goto irtgraphWHL891;
irtgraphWHX892:
	local[15]= NIL;
irtgraphBLK893:
	w = NIL;
	goto irtgraphWHL888;
irtgraphWHX889:
	local[12]= NIL;
irtgraphBLK890:
	w = NIL;
	ctx->vsp=local+10;
	local[10]= makeclosure(codevec,quotevec,irtgraphFLET908,env,argv,local);
	if (local[6]==NIL) goto irtgraphIF909;
	local[11]= local[8];
	w = local[10];
	ctx->vsp=local+12;
	w=irtgraphFLET908(ctx,1,local+11,w);
	local[11]= w;
	goto irtgraphIF910;
irtgraphIF909:
	local[11]= NIL;
irtgraphIF910:
	local[11]= local[9];
	w = local[10];
	ctx->vsp=local+12;
	w=irtgraphFLET908(ctx,1,local+11,w);
	local[10]= local[0];
	local[11]= fqv[58];
	ctx->vsp=local+12;
	w=(pointer)XFORMAT(ctx,2,local+10); /*format*/
	w = T;
	local[0]= w;
irtgraphBLK873:
	ctx->vsp=local; return(local[0]);}

/*:write-to-dot*/
static pointer irtgraphM911directed_graph_write_to_dot(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtgraphENT915;}
	local[0]= NIL;
irtgraphENT915:
	if (n>=5) { local[1]=(argv[4]); goto irtgraphENT914;}
	local[1]= fqv[59];
irtgraphENT914:
irtgraphENT913:
	if (n>5) maerror();
	local[2]= argv[2];
	local[3]= fqv[60];
	local[4]= fqv[61];
	ctx->vsp=local+5;
	w=(*ftab[11])(ctx,3,local+2,&ftab[11],fqv[62]); /*open*/
	local[2]= w;
	ctx->vsp=local+3;
	w = makeclosure(codevec,quotevec,irtgraphUWP916,env,argv,local);
	local[3]=(pointer)(ctx->protfp); local[4]=w;
	ctx->protfp=(struct protectframe *)(local+3);
	local[5]= argv[0];
	local[6]= fqv[63];
	local[7]= local[2];
	local[8]= local[0];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,5,local+5); /*send*/
	ctx->vsp=local+5;
	irtgraphUWP916(ctx,0,local+5,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	w = T;
	local[0]= w;
irtgraphBLK912:
	ctx->vsp=local; return(local[0]);}

/*:write-to-file*/
static pointer irtgraphM917directed_graph_write_to_file(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtgraphENT922;}
	local[0]= NIL;
irtgraphENT922:
	if (n>=5) { local[1]=(argv[4]); goto irtgraphENT921;}
	local[1]= NIL;
irtgraphENT921:
	if (n>=6) { local[2]=(argv[5]); goto irtgraphENT920;}
	local[2]= fqv[64];
irtgraphENT920:
irtgraphENT919:
	if (n>6) maerror();
	local[3]= NIL;
	local[4]= fqv[65];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,3,local+3); /*format*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[66];
	local[6]= local[3];
	local[7]= local[0];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	local[4]= NIL;
	local[5]= fqv[67];
	local[6]= local[3];
	local[7]= local[2];
	local[8]= NIL;
	local[9]= fqv[68];
	local[10]= argv[2];
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)XFORMAT(ctx,4,local+8); /*format*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,5,local+4); /*format*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SYSTEM(ctx,1,local+4); /*unix:system*/
	w = T;
	local[0]= w;
irtgraphBLK918:
	ctx->vsp=local; return(local[0]);}

/*:write-to-pdf*/
static pointer irtgraphM923directed_graph_write_to_pdf(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtgraphENT927;}
	local[0]= NIL;
irtgraphENT927:
	if (n>=5) { local[1]=(argv[4]); goto irtgraphENT926;}
	local[1]= fqv[69];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(*ftab[12])(ctx,2,local+1,&ftab[12],fqv[70]); /*string-right-trim*/
	local[1]= w;
irtgraphENT926:
irtgraphENT925:
	if (n>5) maerror();
	local[2]= fqv[71];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(*ftab[13])(ctx,2,local+2,&ftab[13],fqv[72]); /*substringp*/
	if (w==NIL) goto irtgraphIF928;
	local[2]= fqv[73];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(*ftab[12])(ctx,2,local+2,&ftab[12],fqv[70]); /*string-right-trim*/
	local[2]= w;
	local[3]= local[2];
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SUB1(ctx,1,local+4); /*1-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)46L);
	ctx->vsp=local+5;
	w=(pointer)NUMEQUAL(ctx,2,local+3); /*=*/
	if (w==NIL) goto irtgraphIF930;
	local[3]= local[2];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SUB1(ctx,1,local+5); /*1-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SUBSEQ(ctx,3,local+3); /*subseq*/
	argv[2] = w;
	local[3]= argv[2];
	goto irtgraphIF931;
irtgraphIF930:
	local[3]= NIL;
irtgraphIF931:
	w = local[3];
	local[2]= w;
	goto irtgraphIF929;
irtgraphIF928:
	local[2]= NIL;
irtgraphIF929:
	local[2]= argv[0];
	local[3]= fqv[74];
	local[4]= argv[2];
	local[5]= local[0];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,5,local+2); /*send*/
	local[0]= w;
irtgraphBLK924:
	ctx->vsp=local; return(local[0]);}

/*:original-draw-mode*/
static pointer irtgraphM932directed_graph_original_draw_mode(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[39];
	local[2]= NIL;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[40];
	local[2]= NIL;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[41];
	local[2]= NIL;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
irtgraphBLK933:
	ctx->vsp=local; return(local[0]);}

/*:current-draw-mode*/
static pointer irtgraphM934directed_graph_current_draw_mode(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[39];
	local[2]= T;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[40];
	local[2]= T;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[41];
	local[2]= T;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
irtgraphBLK935:
	ctx->vsp=local; return(local[0]);}

/*:draw-both-arc*/
static pointer irtgraphM936directed_graph_draw_both_arc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT939;}
	local[0]= fqv[30];
irtgraphENT939:
irtgraphENT938:
	if (n>3) maerror();
	local[1]= local[0];
	if (fqv[30]==local[1]) goto irtgraphIF940;
	local[1]= argv[0];
	local[2]= fqv[75];
	local[3]= fqv[39];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto irtgraphIF941;
irtgraphIF940:
	local[1]= NIL;
irtgraphIF941:
	local[1]= argv[0];
	local[2]= fqv[38];
	local[3]= fqv[39];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
irtgraphBLK937:
	ctx->vsp=local; return(local[0]);}

/*:draw-arc-label*/
static pointer irtgraphM942directed_graph_draw_arc_label(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT945;}
	local[0]= fqv[76];
irtgraphENT945:
irtgraphENT944:
	if (n>3) maerror();
	local[1]= local[0];
	if (fqv[76]==local[1]) goto irtgraphIF946;
	local[1]= argv[0];
	local[2]= fqv[75];
	local[3]= fqv[40];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto irtgraphIF947;
irtgraphIF946:
	local[1]= NIL;
irtgraphIF947:
	local[1]= argv[0];
	local[2]= fqv[38];
	local[3]= fqv[40];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
irtgraphBLK943:
	ctx->vsp=local; return(local[0]);}

/*:draw-merged-result*/
static pointer irtgraphM948directed_graph_draw_merged_result(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT951;}
	local[0]= fqv[77];
irtgraphENT951:
irtgraphENT950:
	if (n>3) maerror();
	local[1]= local[0];
	if (fqv[77]==local[1]) goto irtgraphIF952;
	local[1]= argv[0];
	local[2]= fqv[75];
	local[3]= fqv[41];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto irtgraphIF953;
irtgraphIF952:
	local[1]= NIL;
irtgraphIF953:
	local[1]= argv[0];
	local[2]= fqv[38];
	local[3]= fqv[41];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
irtgraphBLK949:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgraphCLO878(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)GENSYM(ctx,0,local+1); /*gensym*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[14])(ctx,1,local+1,&ftab[14],fqv[78]); /*string*/
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgraphFLET879(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env2[3];
	ctx->vsp=local+2;
	w=(*ftab[15])(ctx,2,local+0,&ftab[15],fqv[79]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgraphFLET908(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtgraphCLO954,env,argv,local);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[80]); /*maphash*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgraphCLO954(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= env->c.clo.env0->c.clo.env2[0];
	local[1]= fqv[81];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= env->c.clo.env0->c.clo.env2[0];
	local[1]= fqv[82];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w = env->c.clo.env0->c.clo.env2[7];
	ctx->vsp=local+3;
	w=irtgraphFLET879(ctx,1,local+2,w);
	local[2]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	w = env->c.clo.env0->c.clo.env2[7];
	ctx->vsp=local+4;
	w=irtgraphFLET879(ctx,1,local+3,w);
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,4,local+0); /*format*/
	local[0]= argv[1];
	if (fqv[57]!=local[0]) goto irtgraphIF955;
	local[0]= env->c.clo.env0->c.clo.env2[0];
	local[1]= fqv[83];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= w;
	goto irtgraphIF956;
irtgraphIF955:
	local[0]= env->c.clo.env0->c.clo.env2[0];
	local[1]= fqv[84];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= NIL;
	local[1]= argv[1];
irtgraphWHL957:
	if (local[1]==NIL) goto irtgraphWHX958;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= local[0];
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car==local[2]) goto irtgraphIF960;
	local[2]= env->c.clo.env0->c.clo.env2[0];
	local[3]= fqv[85];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,2,local+2); /*format*/
	local[2]= w;
	goto irtgraphIF961;
irtgraphIF960:
	local[2]= NIL;
irtgraphIF961:
	local[2]= env->c.clo.env0->c.clo.env2[0];
	local[3]= fqv[86];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	goto irtgraphWHL957;
irtgraphWHX958:
	local[2]= NIL;
irtgraphBLK959:
	w = NIL;
	local[0]= env->c.clo.env0->c.clo.env2[0];
	local[1]= fqv[87];
	ctx->vsp=local+2;
	w=(pointer)XFORMAT(ctx,2,local+0); /*format*/
	local[0]= w;
irtgraphIF956:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgraphUWP916(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[2];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:add-neighbor*/
static pointer irtgraphM962node_add_neighbor(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtgraphENT965;}
	local[0]= NIL;
irtgraphENT965:
irtgraphENT964:
	if (n>4) maerror();
	local[1]= loadglobal(fqv[20]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[21];
	local[4]= argv[0];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	w = local[1];
	local[1]= w;
	if (local[0]==NIL) goto irtgraphIF966;
	local[2]= local[1];
	local[3]= fqv[0];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto irtgraphIF967;
irtgraphIF966:
	local[2]= NIL;
irtgraphIF967:
	local[2]= argv[0];
	local[3]= fqv[88];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[0]= w;
irtgraphBLK963:
	ctx->vsp=local; return(local[0]);}

/*:neighbors*/
static pointer irtgraphM968node_neighbors(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT971;}
	local[0]= NIL;
irtgraphENT971:
irtgraphENT970:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtgraphIF972;
	local[1]= NIL;
	local[2]= local[0];
irtgraphWHL974:
	if (local[2]==NIL) goto irtgraphWHX975;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= loadglobal(fqv[20]);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= local[3];
	local[5]= fqv[21];
	local[6]= argv[0];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	w = local[3];
	goto irtgraphWHL974;
irtgraphWHX975:
	local[3]= NIL;
irtgraphBLK976:
	w = NIL;
	local[1]= w;
	goto irtgraphIF973;
irtgraphIF972:
	local[1]= NIL;
irtgraphIF973:
	local[1]= (pointer)get_sym_func(fqv[54]);
	local[2]= argv[0];
	local[3]= fqv[11];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	local[0]= w;
irtgraphBLK969:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtgraphM977arced_node_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[89], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtgraphKEY979;
	local[0] = NIL;
irtgraphKEY979:
	local[1]= argv[0];
	local[2]= *(ovafptr(argv[1],fqv[6]));
	local[3]= fqv[21];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SENDMESSAGE(ctx,4,local+1); /*send-message*/
	w = argv[0];
	local[0]= w;
irtgraphBLK978:
	ctx->vsp=local; return(local[0]);}

/*:find-action*/
static pointer irtgraphM980arced_node_find_action(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= fqv[12];
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,irtgraphCLO982,env,argv,local);
	ctx->vsp=local+4;
	w=(*ftab[2])(ctx,4,local+0,&ftab[2],fqv[15]); /*find*/
	local[0]= w;
	if (local[0]==NIL) goto irtgraphIF983;
	local[1]= local[0];
	local[2]= fqv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	goto irtgraphIF984;
irtgraphIF983:
	local[1]= NIL;
irtgraphIF984:
	w = local[1];
	local[0]= w;
irtgraphBLK981:
	ctx->vsp=local; return(local[0]);}

/*:neighbor-action-alist*/
static pointer irtgraphM985arced_node_neighbor_action_alist(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtgraphCLO987,env,argv,local);
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
irtgraphBLK986:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgraphCLO982(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[4];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtgraphCLO987(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[0];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[4];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtgraphM988solver_node_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[90], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtgraphKEY990;
	local[0] = makeint((eusinteger_t)0L);
irtgraphKEY990:
	if (n & (1<<1)) goto irtgraphKEY991;
	local[1] = NIL;
irtgraphKEY991:
	if (n & (1<<2)) goto irtgraphKEY992;
	local[2] = NIL;
irtgraphKEY992:
	argv[0]->c.obj.iv[1] = argv[2];
	argv[0]->c.obj.iv[2] = local[0];
	argv[0]->c.obj.iv[3] = local[1];
	argv[0]->c.obj.iv[4] = local[2];
	w = argv[0];
	local[0]= w;
irtgraphBLK989:
	ctx->vsp=local; return(local[0]);}

/*:path*/
static pointer irtgraphM993solver_node_path(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT996;}
	local[0]= NIL;
irtgraphENT996:
irtgraphENT995:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtgraphIF997;
	local[1]= argv[0];
	local[2]= fqv[91];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (w==NIL) goto irtgraphIF999;
	local[1]= argv[0];
	local[2]= fqv[91];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[92];
	local[3]= argv[0];
	w = local[0];
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto irtgraphIF1000;
irtgraphIF999:
	local[1]= argv[0];
	w = local[0];
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
irtgraphIF1000:
	goto irtgraphIF998;
irtgraphIF997:
	if (argv[0]->c.obj.iv[5]==NIL) goto irtgraphIF1001;
	local[1]= argv[0]->c.obj.iv[5];
	goto irtgraphIF1002;
irtgraphIF1001:
	local[1]= argv[0];
	local[2]= fqv[91];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (w==NIL) goto irtgraphIF1003;
	local[1]= argv[0];
	local[2]= fqv[91];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[92];
	local[3]= argv[0];
	w = local[0];
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto irtgraphIF1004;
irtgraphIF1003:
	local[1]= argv[0];
	w = local[0];
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
irtgraphIF1004:
	argv[0]->c.obj.iv[5] = local[1];
	local[1]= argv[0]->c.obj.iv[5];
irtgraphIF1002:
irtgraphIF998:
	w = local[1];
	local[0]= w;
irtgraphBLK994:
	ctx->vsp=local; return(local[0]);}

/*:expand*/
static pointer irtgraphM1005solver_node_expand(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtgraphRST1007:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	local[1]= (pointer)get_sym_func(fqv[93]);
	local[2]= argv[2];
	local[3]= fqv[11];
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,5,local+1); /*apply*/
	local[1]= w;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= local[1];
irtgraphWHL1008:
	if (local[4]==NIL) goto irtgraphWHX1009;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= loadglobal(fqv[94]);
	ctx->vsp=local+6;
	w=(pointer)INSTANTIATE(ctx,1,local+5); /*instantiate*/
	local[5]= w;
	local[6]= local[5];
	local[7]= fqv[21];
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.cdr;
	local[9]= fqv[91];
	local[10]= argv[0];
	local[11]= fqv[95];
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= fqv[33];
	local[14]= argv[2];
	local[15]= fqv[96];
	local[16]= argv[0];
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.cdr;
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,5,local+14); /*send*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,9,local+6); /*send*/
	w = local[5];
	local[5]= w;
	w = local[2];
	ctx->vsp=local+6;
	local[2] = cons(ctx,local[5],w);
	goto irtgraphWHL1008;
irtgraphWHX1009:
	local[5]= NIL;
irtgraphBLK1010:
	w = NIL;
	w = local[2];
	local[0]= w;
irtgraphBLK1006:
	ctx->vsp=local; return(local[0]);}

/*:state*/
static pointer irtgraphM1011solver_node_state(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT1014;}
	local[0]= NIL;
irtgraphENT1014:
irtgraphENT1013:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtgraphIF1015;
	argv[0]->c.obj.iv[1] = local[0];
	local[1]= argv[0]->c.obj.iv[1];
	goto irtgraphIF1016;
irtgraphIF1015:
	local[1]= NIL;
irtgraphIF1016:
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK1012:
	ctx->vsp=local; return(local[0]);}

/*:cost*/
static pointer irtgraphM1017solver_node_cost(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT1020;}
	local[0]= NIL;
irtgraphENT1020:
irtgraphENT1019:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtgraphIF1021;
	argv[0]->c.obj.iv[2] = local[0];
	local[1]= argv[0]->c.obj.iv[2];
	goto irtgraphIF1022;
irtgraphIF1021:
	local[1]= NIL;
irtgraphIF1022:
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
irtgraphBLK1018:
	ctx->vsp=local; return(local[0]);}

/*:parent*/
static pointer irtgraphM1023solver_node_parent(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT1026;}
	local[0]= NIL;
irtgraphENT1026:
irtgraphENT1025:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtgraphIF1027;
	argv[0]->c.obj.iv[3] = local[0];
	local[1]= argv[0]->c.obj.iv[3];
	goto irtgraphIF1028;
irtgraphIF1027:
	local[1]= NIL;
irtgraphIF1028:
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
irtgraphBLK1024:
	ctx->vsp=local; return(local[0]);}

/*:action*/
static pointer irtgraphM1029solver_node_action(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT1032;}
	local[0]= NIL;
irtgraphENT1032:
irtgraphENT1031:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtgraphIF1033;
	argv[0]->c.obj.iv[4] = local[0];
	local[1]= argv[0]->c.obj.iv[4];
	goto irtgraphIF1034;
irtgraphIF1033:
	local[1]= NIL;
irtgraphIF1034:
	w = argv[0]->c.obj.iv[4];
	local[0]= w;
irtgraphBLK1030:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtgraphM1035solver_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0];
	local[0]= w;
irtgraphBLK1036:
	ctx->vsp=local; return(local[0]);}

/*:solve*/
static pointer irtgraphM1037solver_solve(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = NIL;
	local[0]= w;
irtgraphBLK1038:
	ctx->vsp=local; return(local[0]);}

/*:solve-by-name*/
static pointer irtgraphM1039solver_solve_by_name(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[97], &argv[5], n-5, local+0, 0);
	if (n & (1<<0)) goto irtgraphKEY1041;
	local[0] = NIL;
irtgraphKEY1041:
	local[1]= argv[2];
	local[2]= fqv[98];
	local[3]= argv[2];
	local[4]= fqv[99];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= argv[2];
	local[2]= fqv[100];
	local[3]= argv[2];
	local[4]= fqv[99];
	local[5]= argv[4];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[101];
	local[3]= argv[2];
	local[4]= fqv[102];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[0]= w;
irtgraphBLK1040:
	ctx->vsp=local; return(local[0]);}

/*:solve-init*/
static pointer irtgraphM1042graph_search_solver_solve_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	argv[0]->c.obj.iv[2] = NIL;
	local[0]= argv[0];
	local[1]= fqv[103];
	local[2]= loadglobal(fqv[94]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= local[2];
	local[4]= fqv[21];
	local[5]= argv[2];
	local[6]= fqv[98];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= fqv[33];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,5,local+3); /*send*/
	w = local[2];
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
irtgraphBLK1043:
	ctx->vsp=local; return(local[0]);}

/*:find-node-in-close-list*/
static pointer irtgraphM1044graph_search_solver_find_node_in_close_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= fqv[48];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[15]); /*find*/
	local[0]= w;
irtgraphBLK1045:
	ctx->vsp=local; return(local[0]);}

/*:solve*/
static pointer irtgraphM1046graph_search_solver_solve(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[104], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtgraphKEY1048;
	local[0] = NIL;
irtgraphKEY1048:
	local[1]= argv[0];
	local[2]= fqv[105];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
irtgraphWHL1049:
	local[1]= argv[0];
	local[2]= fqv[106];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (w!=NIL) goto irtgraphWHX1050;
	local[1]= argv[0];
	local[2]= fqv[107];
	local[3]= fqv[108];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	local[2]= argv[2];
	local[3]= fqv[109];
	local[4]= local[1];
	local[5]= fqv[48];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	if (w==NIL) goto irtgraphCON1053;
	local[2]= local[1];
	local[3]= fqv[92];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	ctx->vsp=local+2;
	local[0]=w;
	goto irtgraphBLK1047;
	goto irtgraphCON1052;
irtgraphCON1053:
	local[2]= argv[0];
	local[3]= fqv[110];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	if (w!=NIL) goto irtgraphCON1054;
	local[2]= local[1];
	local[3]= fqv[48];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	w = argv[0]->c.obj.iv[2];
	ctx->vsp=local+3;
	argv[0]->c.obj.iv[2] = cons(ctx,local[2],w);
	local[2]= argv[0];
	local[3]= fqv[111];
	local[4]= local[1];
	local[5]= fqv[112];
	local[6]= argv[2];
	local[7]= fqv[102];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto irtgraphCON1052;
irtgraphCON1054:
	local[2]= NIL;
irtgraphCON1052:
	w = local[2];
	goto irtgraphWHL1049;
irtgraphWHX1050:
	local[1]= NIL;
irtgraphBLK1051:
	local[1]= fqv[113];
	local[2]= fqv[101];
	ctx->vsp=local+3;
	w=(*ftab[17])(ctx,2,local+1,&ftab[17],fqv[114]); /*warn*/
	local[1]= fqv[115];
	local[2]= fqv[101];
	ctx->vsp=local+3;
	w=(*ftab[17])(ctx,2,local+1,&ftab[17],fqv[114]); /*warn*/
	local[1]= argv[0];
	local[2]= fqv[116];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	argv[0]->c.obj.iv[2] = NIL;
	w = NIL;
	local[0]= w;
irtgraphBLK1047:
	ctx->vsp=local; return(local[0]);}

/*:add-to-open-list*/
static pointer irtgraphM1055graph_search_solver_add_to_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)LISTP(ctx,1,local+0); /*listp*/
	if (w==NIL) goto irtgraphIF1057;
	local[0]= argv[0];
	local[1]= fqv[111];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto irtgraphIF1058;
irtgraphIF1057:
	local[0]= argv[0];
	local[1]= fqv[117];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
irtgraphIF1058:
	w = local[0];
	local[0]= w;
irtgraphBLK1056:
	ctx->vsp=local; return(local[0]);}

/*:null-open-list?*/
static pointer irtgraphM1059graph_search_solver_null_open_list_(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = ((argv[0]->c.obj.iv[1])==NIL?T:NIL);
	local[0]= w;
irtgraphBLK1060:
	ctx->vsp=local; return(local[0]);}

/*:clear-open-list*/
static pointer irtgraphM1061graph_search_solver_clear_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[118];
	ctx->vsp=local+1;
	w=(*ftab[17])(ctx,1,local+0,&ftab[17],fqv[114]); /*warn*/
	w = NIL;
	local[0]= w;
irtgraphBLK1062:
	ctx->vsp=local; return(local[0]);}

/*:add-list-to-open-list*/
static pointer irtgraphM1063graph_search_solver_add_list_to_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= fqv[119];
	ctx->vsp=local+1;
	w=(*ftab[17])(ctx,1,local+0,&ftab[17],fqv[114]); /*warn*/
	w = NIL;
	local[0]= w;
irtgraphBLK1064:
	ctx->vsp=local; return(local[0]);}

/*:add-object-to-open-list*/
static pointer irtgraphM1065graph_search_solver_add_object_to_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= fqv[120];
	ctx->vsp=local+1;
	w=(*ftab[17])(ctx,1,local+0,&ftab[17],fqv[114]); /*warn*/
	w = NIL;
	local[0]= w;
irtgraphBLK1066:
	ctx->vsp=local; return(local[0]);}

/*:pop-from-open-list*/
static pointer irtgraphM1067graph_search_solver_pop_from_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[121], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtgraphKEY1069;
	local[0] = NIL;
irtgraphKEY1069:
	local[1]= fqv[122];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,1,local+1,&ftab[17],fqv[114]); /*warn*/
	w = NIL;
	local[0]= w;
irtgraphBLK1068:
	ctx->vsp=local; return(local[0]);}

/*:open-list*/
static pointer irtgraphM1070graph_search_solver_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT1073;}
	local[0]= NIL;
irtgraphENT1073:
irtgraphENT1072:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtgraphIF1074;
	argv[0]->c.obj.iv[1] = local[0];
	local[1]= argv[0]->c.obj.iv[1];
	goto irtgraphIF1075;
irtgraphIF1074:
	local[1]= NIL;
irtgraphIF1075:
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK1071:
	ctx->vsp=local; return(local[0]);}

/*:close-list*/
static pointer irtgraphM1076graph_search_solver_close_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtgraphENT1079;}
	local[0]= NIL;
irtgraphENT1079:
irtgraphENT1078:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtgraphIF1080;
	argv[0]->c.obj.iv[2] = local[0];
	local[1]= argv[0]->c.obj.iv[2];
	goto irtgraphIF1081;
irtgraphIF1080:
	local[1]= NIL;
irtgraphIF1081:
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
irtgraphBLK1077:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtgraphM1082breadth_first_graph_search_solver_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	ctx->vsp=local+0;
	w=(pointer)LIST(ctx,0,local+0); /*list*/
	argv[0]->c.obj.iv[1] = w;
	w = argv[0];
	local[0]= w;
irtgraphBLK1083:
	ctx->vsp=local; return(local[0]);}

/*:clear-open-list*/
static pointer irtgraphM1084breadth_first_graph_search_solver_clear_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	argv[0]->c.obj.iv[1] = NIL;
	w = NIL;
	local[0]= w;
irtgraphBLK1085:
	ctx->vsp=local; return(local[0]);}

/*:add-list-to-open-list*/
static pointer irtgraphM1086breadth_first_graph_search_solver_add_list_to_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)NCONC(ctx,2,local+0); /*nconc*/
	argv[0]->c.obj.iv[1] = w;
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK1087:
	ctx->vsp=local; return(local[0]);}

/*:add-object-to-open-list*/
static pointer irtgraphM1088breadth_first_graph_search_solver_add_object_to_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)NCONC(ctx,2,local+0); /*nconc*/
	argv[0]->c.obj.iv[1] = w;
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK1089:
	ctx->vsp=local; return(local[0]);}

/*:pop-from-open-list*/
static pointer irtgraphM1090breadth_first_graph_search_solver_pop_from_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[123], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtgraphKEY1092;
	local[0] = NIL;
irtgraphKEY1092:
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[1] = (w)->c.cons.cdr;
	w = local[1];
	local[0]= w;
irtgraphBLK1091:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtgraphM1093depth_first_graph_search_solver_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	ctx->vsp=local+0;
	w=(pointer)LIST(ctx,0,local+0); /*list*/
	argv[0]->c.obj.iv[1] = w;
	w = argv[0];
	local[0]= w;
irtgraphBLK1094:
	ctx->vsp=local; return(local[0]);}

/*:clear-open-list*/
static pointer irtgraphM1095depth_first_graph_search_solver_clear_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	argv[0]->c.obj.iv[1] = NIL;
	w = NIL;
	local[0]= w;
irtgraphBLK1096:
	ctx->vsp=local; return(local[0]);}

/*:add-list-to-open-list*/
static pointer irtgraphM1097depth_first_graph_search_solver_add_list_to_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)NCONC(ctx,2,local+0); /*nconc*/
	argv[0]->c.obj.iv[1] = w;
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK1098:
	ctx->vsp=local; return(local[0]);}

/*:add-object-to-open-list*/
static pointer irtgraphM1099depth_first_graph_search_solver_add_object_to_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	w = argv[0]->c.obj.iv[1];
	ctx->vsp=local+1;
	argv[0]->c.obj.iv[1] = cons(ctx,local[0],w);
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK1100:
	ctx->vsp=local; return(local[0]);}

/*:pop-from-open-list*/
static pointer irtgraphM1101depth_first_graph_search_solver_pop_from_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[124], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtgraphKEY1103;
	local[0] = NIL;
irtgraphKEY1103:
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[1] = (w)->c.cons.cdr;
	w = local[1];
	local[0]= w;
irtgraphBLK1102:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtgraphM1104best_first_graph_search_solver_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	argv[0]->c.obj.iv[3] = argv[2];
	ctx->vsp=local+0;
	w=(pointer)LIST(ctx,0,local+0); /*list*/
	argv[0]->c.obj.iv[1] = w;
	w = argv[0];
	local[0]= w;
irtgraphBLK1105:
	ctx->vsp=local; return(local[0]);}

/*:clear-open-list*/
static pointer irtgraphM1106best_first_graph_search_solver_clear_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	argv[0]->c.obj.iv[1] = NIL;
	w = NIL;
	local[0]= w;
irtgraphBLK1107:
	ctx->vsp=local; return(local[0]);}

/*:add-list-to-open-list*/
static pointer irtgraphM1108best_first_graph_search_solver_add_list_to_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)NCONC(ctx,2,local+0); /*nconc*/
	argv[0]->c.obj.iv[1] = w;
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK1109:
	ctx->vsp=local; return(local[0]);}

/*:add-object-to-open-list*/
static pointer irtgraphM1110best_first_graph_search_solver_add_object_to_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	w = argv[0]->c.obj.iv[1];
	ctx->vsp=local+1;
	argv[0]->c.obj.iv[1] = cons(ctx,local[0],w);
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtgraphBLK1111:
	ctx->vsp=local; return(local[0]);}

/*:pop-from-open-list*/
static pointer irtgraphM1112best_first_graph_search_solver_pop_from_open_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[125], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtgraphKEY1114;
	local[0] = NIL;
irtgraphKEY1114:
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= local[1];
	local[3]= fqv[38];
	local[4]= fqv[126];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	if (w!=NIL) goto irtgraphOR1115;
	local[2]= local[1];
	local[3]= fqv[75];
	local[4]= fqv[126];
	local[5]= argv[0];
	local[6]= fqv[127];
	local[7]= local[1];
	local[8]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= local[1];
	local[3]= fqv[38];
	local[4]= fqv[126];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
irtgraphOR1115:
	if (local[0]==NIL) goto irtgraphIF1116;
	local[3]= fqv[128];
	local[4]= local[1];
	local[5]= fqv[92];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= fqv[48];
	ctx->vsp=local+6;
	w=(*ftab[4])(ctx,2,local+4,&ftab[4],fqv[18]); /*send-all*/
	local[4]= w;
	local[5]= fqv[0];
	ctx->vsp=local+6;
	w=(*ftab[4])(ctx,2,local+4,&ftab[4],fqv[18]); /*send-all*/
	local[4]= w;
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(*ftab[17])(ctx,3,local+3,&ftab[17],fqv[114]); /*warn*/
	local[3]= w;
	goto irtgraphIF1117;
irtgraphIF1116:
	local[3]= NIL;
irtgraphIF1117:
	local[3]= NIL;
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
irtgraphWHL1118:
	if (local[4]==NIL) goto irtgraphWHX1119;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[3];
	local[6]= fqv[126];
	ctx->vsp=local+7;
	w=(pointer)GETPROP(ctx,2,local+5); /*get*/
	local[5]= w;
	if (w!=NIL) goto irtgraphOR1121;
	local[5]= local[3];
	local[6]= argv[0];
	local[7]= fqv[127];
	local[8]= local[3];
	local[9]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= w;
	local[7]= fqv[126];
	ctx->vsp=local+8;
	w=(pointer)PUTPROP(ctx,3,local+5); /*putprop*/
	local[5]= local[3];
	local[6]= fqv[126];
	ctx->vsp=local+7;
	w=(pointer)GETPROP(ctx,2,local+5); /*get*/
	local[5]= w;
irtgraphOR1121:
	if (local[0]==NIL) goto irtgraphIF1122;
	local[6]= fqv[129];
	local[7]= local[3];
	local[8]= fqv[92];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= fqv[48];
	ctx->vsp=local+9;
	w=(*ftab[4])(ctx,2,local+7,&ftab[4],fqv[18]); /*send-all*/
	local[7]= w;
	local[8]= fqv[0];
	ctx->vsp=local+9;
	w=(*ftab[4])(ctx,2,local+7,&ftab[4],fqv[18]); /*send-all*/
	local[7]= w;
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(*ftab[17])(ctx,3,local+6,&ftab[17],fqv[114]); /*warn*/
	local[6]= w;
	goto irtgraphIF1123;
irtgraphIF1122:
	local[6]= NIL;
irtgraphIF1123:
	local[6]= local[5];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)LESSP(ctx,2,local+6); /*<*/
	if (w==NIL) goto irtgraphIF1124;
	local[2] = local[5];
	local[1] = local[3];
	local[6]= local[1];
	goto irtgraphIF1125;
irtgraphIF1124:
	local[6]= NIL;
irtgraphIF1125:
	w = local[6];
	goto irtgraphWHL1118;
irtgraphWHX1119:
	local[5]= NIL;
irtgraphBLK1120:
	w = NIL;
	if (local[0]==NIL) goto irtgraphIF1126;
	local[3]= fqv[130];
	ctx->vsp=local+4;
	w=(*ftab[17])(ctx,1,local+3,&ftab[17],fqv[114]); /*warn*/
	local[3]= fqv[131];
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(*ftab[17])(ctx,2,local+3,&ftab[17],fqv[114]); /*warn*/
	local[3]= fqv[132];
	local[4]= local[1];
	local[5]= fqv[92];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= fqv[48];
	ctx->vsp=local+6;
	w=(*ftab[4])(ctx,2,local+4,&ftab[4],fqv[18]); /*send-all*/
	local[4]= w;
	local[5]= fqv[0];
	ctx->vsp=local+6;
	w=(*ftab[4])(ctx,2,local+4,&ftab[4],fqv[18]); /*send-all*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[17])(ctx,2,local+3,&ftab[17],fqv[114]); /*warn*/
	local[3]= w;
	goto irtgraphIF1127;
irtgraphIF1126:
	local[3]= NIL;
irtgraphIF1127:
	local[3]= local[1];
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= fqv[133];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(*ftab[18])(ctx,4,local+3,&ftab[18],fqv[134]); /*delete*/
	argv[0]->c.obj.iv[1] = w;
	w = local[1];
	local[0]= w;
irtgraphBLK1113:
	ctx->vsp=local; return(local[0]);}

/*:fn*/
static pointer irtgraphM1128best_first_graph_search_solver_fn(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[2];
	local[1]= fqv[33];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
irtgraphBLK1129:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtgraphM1130a__graph_search_solver_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[6]));
	local[2]= fqv[21];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SENDMESSAGE(ctx,4,local+0); /*send-message*/
	w = argv[0];
	local[0]= w;
irtgraphBLK1131:
	ctx->vsp=local; return(local[0]);}

/*:fn*/
static pointer irtgraphM1132a__graph_search_solver_fn(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[135], &argv[4], n-4, local+0, 0);
	if (n & (1<<0)) goto irtgraphKEY1134;
	local[0] = NIL;
irtgraphKEY1134:
	if (local[0]==NIL) goto irtgraphIF1135;
	local[1]= fqv[136];
	local[2]= argv[0];
	local[3]= fqv[137];
	local[4]= argv[2];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[17])(ctx,2,local+1,&ftab[17],fqv[114]); /*warn*/
	local[1]= fqv[138];
	local[2]= argv[0];
	local[3]= fqv[139];
	local[4]= argv[2];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[17])(ctx,2,local+1,&ftab[17],fqv[114]); /*warn*/
	local[1]= w;
	goto irtgraphIF1136;
irtgraphIF1135:
	local[1]= NIL;
irtgraphIF1136:
	local[1]= argv[0];
	local[2]= fqv[137];
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[139];
	local[4]= argv[2];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,2,local+1); /*+*/
	local[0]= w;
irtgraphBLK1133:
	ctx->vsp=local; return(local[0]);}

/*:gn*/
static pointer irtgraphM1137a__graph_search_solver_gn(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[2];
	local[1]= fqv[33];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
irtgraphBLK1138:
	ctx->vsp=local; return(local[0]);}

/*:hn*/
static pointer irtgraphM1139a__graph_search_solver_hn(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= fqv[140];
	ctx->vsp=local+1;
	w=(*ftab[17])(ctx,1,local+0,&ftab[17],fqv[114]); /*warn*/
	w = makeflt(0.0000000000000000000000e+00);
	local[0]= w;
irtgraphBLK1140:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___irtgraph(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[10];
	local[1]= fqv[141];
	local[2]= fqv[10];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[143]);
	local[5]= fqv[144];
	local[6]= fqv[145];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,13,local+2,&ftab[19],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM757node_init,fqv[21],fqv[10],fqv[151]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM761node_arc_list,fqv[25],fqv[10],fqv[152]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM763node_successors,fqv[11],fqv[10],fqv[153]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM766node_add_arc,fqv[5],fqv[10],fqv[154]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM768node_remove_arc,fqv[23],fqv[10],fqv[155]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM770node_remove_all_arcs,fqv[19],fqv[10],fqv[156]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM772node_unlink,fqv[17],fqv[10],fqv[157]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM775node_image,fqv[1],fqv[10],fqv[158]);
	local[0]= fqv[20];
	local[1]= fqv[141];
	local[2]= fqv[20];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[143]);
	local[5]= fqv[144];
	local[6]= fqv[159];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,13,local+2,&ftab[19],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM781arc_init,fqv[21],fqv[20],fqv[160]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM783arc_from,fqv[22],fqv[20],fqv[161]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM785arc_to,fqv[4],fqv[20],fqv[162]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM787arc_prin1,fqv[7],fqv[20],fqv[163]);
	local[0]= fqv[164];
	local[1]= fqv[141];
	local[2]= fqv[164];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[143]);
	local[5]= fqv[144];
	local[6]= fqv[165];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,13,local+2,&ftab[19],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM792directed_graph_init,fqv[21],fqv[164],fqv[166]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM794directed_graph_successors,fqv[11],fqv[164],fqv[167]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM797directed_graph_node,fqv[99],fqv[164],fqv[168]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM800directed_graph_nodes,fqv[169],fqv[164],fqv[170]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM809directed_graph_add_node,fqv[171],fqv[164],fqv[172]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM811directed_graph_remove_node,fqv[173],fqv[164],fqv[174]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM813directed_graph_clear_nodes,fqv[175],fqv[164],fqv[176]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM815directed_graph_add_arc_from_to,fqv[29],fqv[164],fqv[177]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM817directed_graph_remove_arc,fqv[23],fqv[164],fqv[178]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM819directed_graph_adjacency_matrix,fqv[179],fqv[164],fqv[180]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM829directed_graph_adjacency_list,fqv[181],fqv[164],fqv[182]);
	local[0]= fqv[32];
	local[1]= fqv[141];
	local[2]= fqv[32];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[20]);
	local[5]= fqv[144];
	local[6]= fqv[183];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,13,local+2,&ftab[19],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM833costed_arc_init,fqv[21],fqv[32],fqv[184]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM835costed_arc_cost,fqv[33],fqv[32],fqv[185]);
	local[0]= fqv[186];
	local[1]= fqv[141];
	local[2]= fqv[186];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[164]);
	local[5]= fqv[144];
	local[6]= fqv[187];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,13,local+2,&ftab[19],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM837costed_graph_add_arc,fqv[5],fqv[186],fqv[188]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM840costed_graph_add_arc_from_to,fqv[29],fqv[186],fqv[189]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM845costed_graph_path_cost,fqv[96],fqv[186],fqv[190]);
	local[0]= fqv[191];
	local[1]= fqv[141];
	local[2]= fqv[191];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[186]);
	local[5]= fqv[144];
	local[6]= fqv[192];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,13,local+2,&ftab[19],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM847graph_goal_test,fqv[109],fqv[191],fqv[193]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM849graph_path_cost,fqv[96],fqv[191],fqv[194]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM851graph_start_state,fqv[98],fqv[191],fqv[195]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM857graph_goal_state,fqv[100],fqv[191],fqv[196]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM863graph_add_arc,fqv[5],fqv[191],fqv[197]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM869graph_add_arc_from_to,fqv[29],fqv[191],fqv[198]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM872directed_graph_write_to_dot_stream,fqv[63],fqv[164],fqv[199]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM911directed_graph_write_to_dot,fqv[66],fqv[164],fqv[200]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM917directed_graph_write_to_file,fqv[74],fqv[164],fqv[201]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM923directed_graph_write_to_pdf,fqv[202],fqv[164],fqv[203]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM932directed_graph_original_draw_mode,fqv[204],fqv[164],fqv[205]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM934directed_graph_current_draw_mode,fqv[206],fqv[164],fqv[207]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM936directed_graph_draw_both_arc,fqv[39],fqv[164],fqv[208]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM942directed_graph_draw_arc_label,fqv[40],fqv[164],fqv[209]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM948directed_graph_draw_merged_result,fqv[41],fqv[164],fqv[210]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM962node_add_neighbor,fqv[211],fqv[10],fqv[212]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM968node_neighbors,fqv[88],fqv[10],fqv[213]);
	local[0]= fqv[214];
	local[1]= fqv[141];
	local[2]= fqv[214];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[10]);
	local[5]= fqv[144];
	local[6]= fqv[187];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,13,local+2,&ftab[19],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM977arced_node_init,fqv[21],fqv[214],fqv[215]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM980arced_node_find_action,fqv[216],fqv[214],fqv[217]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM985arced_node_neighbor_action_alist,fqv[218],fqv[214],fqv[219]);
	local[0]= fqv[94];
	local[1]= fqv[141];
	local[2]= fqv[94];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[143]);
	local[5]= fqv[144];
	local[6]= fqv[220];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,13,local+2,&ftab[19],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM988solver_node_init,fqv[21],fqv[94],fqv[221]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM993solver_node_path,fqv[92],fqv[94],fqv[222]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1005solver_node_expand,fqv[112],fqv[94],fqv[223]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1011solver_node_state,fqv[48],fqv[94],fqv[224]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1017solver_node_cost,fqv[33],fqv[94],fqv[225]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1023solver_node_parent,fqv[91],fqv[94],fqv[226]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1029solver_node_action,fqv[95],fqv[94],fqv[227]);
	local[0]= fqv[228];
	local[1]= fqv[141];
	local[2]= fqv[228];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[143]);
	local[5]= fqv[144];
	local[6]= fqv[187];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,13,local+2,&ftab[19],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1035solver_init,fqv[21],fqv[228],fqv[229]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1037solver_solve,fqv[101],fqv[228],fqv[230]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1039solver_solve_by_name,fqv[231],fqv[228],fqv[232]);
	local[0]= fqv[233];
	local[1]= fqv[141];
	local[2]= fqv[233];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[228]);
	local[5]= fqv[144];
	local[6]= fqv[234];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,13,local+2,&ftab[19],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1042graph_search_solver_solve_init,fqv[105],fqv[233],fqv[235]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1044graph_search_solver_find_node_in_close_list,fqv[110],fqv[233],fqv[236]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1046graph_search_solver_solve,fqv[101],fqv[233],fqv[237]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1055graph_search_solver_add_to_open_list,fqv[103],fqv[233],fqv[238]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1059graph_search_solver_null_open_list_,fqv[106],fqv[233],fqv[239]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1061graph_search_solver_clear_open_list,fqv[116],fqv[233],fqv[240]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1063graph_search_solver_add_list_to_open_list,fqv[111],fqv[233],fqv[241]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1065graph_search_solver_add_object_to_open_list,fqv[117],fqv[233],fqv[242]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1067graph_search_solver_pop_from_open_list,fqv[107],fqv[233],fqv[243]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1070graph_search_solver_open_list,fqv[244],fqv[233],fqv[245]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1076graph_search_solver_close_list,fqv[246],fqv[233],fqv[247]);
	local[0]= fqv[248];
	local[1]= fqv[141];
	local[2]= fqv[248];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[233]);
	local[5]= fqv[144];
	local[6]= fqv[187];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,13,local+2,&ftab[19],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1082breadth_first_graph_search_solver_init,fqv[21],fqv[248],fqv[249]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1084breadth_first_graph_search_solver_clear_open_list,fqv[116],fqv[248],fqv[250]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1086breadth_first_graph_search_solver_add_list_to_open_list,fqv[111],fqv[248],fqv[251]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1088breadth_first_graph_search_solver_add_object_to_open_list,fqv[117],fqv[248],fqv[252]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1090breadth_first_graph_search_solver_pop_from_open_list,fqv[107],fqv[248],fqv[253]);
	local[0]= fqv[254];
	local[1]= fqv[141];
	local[2]= fqv[254];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[233]);
	local[5]= fqv[144];
	local[6]= fqv[187];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,13,local+2,&ftab[19],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1093depth_first_graph_search_solver_init,fqv[21],fqv[254],fqv[255]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1095depth_first_graph_search_solver_clear_open_list,fqv[116],fqv[254],fqv[256]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1097depth_first_graph_search_solver_add_list_to_open_list,fqv[111],fqv[254],fqv[257]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1099depth_first_graph_search_solver_add_object_to_open_list,fqv[117],fqv[254],fqv[258]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1101depth_first_graph_search_solver_pop_from_open_list,fqv[107],fqv[254],fqv[259]);
	local[0]= fqv[260];
	local[1]= fqv[141];
	local[2]= fqv[260];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[233]);
	local[5]= fqv[144];
	local[6]= fqv[261];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,13,local+2,&ftab[19],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1104best_first_graph_search_solver_init,fqv[21],fqv[260],fqv[262]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1106best_first_graph_search_solver_clear_open_list,fqv[116],fqv[260],fqv[263]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1108best_first_graph_search_solver_add_list_to_open_list,fqv[111],fqv[260],fqv[264]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1110best_first_graph_search_solver_add_object_to_open_list,fqv[117],fqv[260],fqv[265]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1112best_first_graph_search_solver_pop_from_open_list,fqv[107],fqv[260],fqv[266]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1128best_first_graph_search_solver_fn,fqv[127],fqv[260],fqv[267]);
	local[0]= fqv[268];
	local[1]= fqv[141];
	local[2]= fqv[268];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[260]);
	local[5]= fqv[144];
	local[6]= fqv[187];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,13,local+2,&ftab[19],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1130a__graph_search_solver_init,fqv[21],fqv[268],fqv[269]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1132a__graph_search_solver_fn,fqv[127],fqv[268],fqv[270]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1137a__graph_search_solver_gn,fqv[137],fqv[268],fqv[271]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtgraphM1139a__graph_search_solver_hn,fqv[139],fqv[268],fqv[272]);
	local[0]= fqv[273];
	local[1]= fqv[274];
	ctx->vsp=local+2;
	w=(*ftab[20])(ctx,2,local+0,&ftab[20],fqv[275]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<21; i++) ftab[i]=fcallx;
}
