export default function serialize(input: unknown): string | undefined;
