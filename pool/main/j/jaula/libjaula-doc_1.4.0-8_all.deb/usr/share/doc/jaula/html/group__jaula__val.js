var group__jaula__val =
[
    [ "JAULA::Value", "classJAULA_1_1Value.html", [
      [ "ValueType", "classJAULA_1_1Value.html#abd733466d82038744096c9e511a34f9a", [
        [ "TYPE_NULL", "classJAULA_1_1Value.html#abd733466d82038744096c9e511a34f9aa7e6263d35b7e7eca07d8f18cc4435da2", null ],
        [ "TYPE_BOOLEAN", "classJAULA_1_1Value.html#abd733466d82038744096c9e511a34f9aa2797ae23806954099da3c647a963a709", null ],
        [ "TYPE_STRING", "classJAULA_1_1Value.html#abd733466d82038744096c9e511a34f9aa1214957f1c910b629e6475daff41664c", null ],
        [ "TYPE_NUMBER", "classJAULA_1_1Value.html#abd733466d82038744096c9e511a34f9aaa7b080dad5a7e691aa340e329d09f83e", null ],
        [ "TYPE_NUMBER_INT", "classJAULA_1_1Value.html#abd733466d82038744096c9e511a34f9aa3766b562ba180f08d2da542d70d86523", null ],
        [ "TYPE_ARRAY", "classJAULA_1_1Value.html#abd733466d82038744096c9e511a34f9aaf068f23add6ce94d00d4cf9959c9ded1", null ],
        [ "TYPE_OBJECT", "classJAULA_1_1Value.html#abd733466d82038744096c9e511a34f9aa8e165011482b42e8389137a615170e99", null ]
      ] ],
      [ "~Value", "classJAULA_1_1Value.html#a9097e24411e0497ff18e76f413e35333", null ],
      [ "Value", "classJAULA_1_1Value.html#a0344bd340e96d19d7290f0235eaed282", null ],
      [ "duplicate", "classJAULA_1_1Value.html#ac8f298fd9f0a0e7b76f2c597560e96b1", null ],
      [ "getType", "classJAULA_1_1Value.html#a3fbf54f53e1db4929794b45ed6d77fbf", null ],
      [ "operator=", "classJAULA_1_1Value.html#af27b1a6c4bd029fafbd7e4ef1cffc345", null ],
      [ "repr", "classJAULA_1_1Value.html#acc0fcc910630095dcd08a37b29398008", null ],
      [ "set", "classJAULA_1_1Value.html#a2b35b2be89e4d01368f6867a149446ad", null ],
      [ "Type_", "classJAULA_1_1Value.html#acf280538476a1e4e5612a3b1e6fc698a", null ]
    ] ],
    [ "JAULA::Value_Array", "classJAULA_1_1Value__Array.html", [
      [ "dataType", "classJAULA_1_1Value__Array.html#a89db587e6bf38647f0465d90a3800a45", null ],
      [ "Value_Array", "classJAULA_1_1Value__Array.html#ac98ae5971379adcd017a089f2c8ce3c4", null ],
      [ "Value_Array", "classJAULA_1_1Value__Array.html#abff8b3501a40426df320870b58ebf598", null ],
      [ "~Value_Array", "classJAULA_1_1Value__Array.html#a1fd3de7d789020200a958897936896fa", null ],
      [ "addItem", "classJAULA_1_1Value__Array.html#aeda311fb2a8632c378bdba0ac03e5545", null ],
      [ "clear", "classJAULA_1_1Value__Array.html#a89f9ec85656b0e6f5296ee8bb39e25b0", null ],
      [ "empty", "classJAULA_1_1Value__Array.html#ad368ed48bda3ff03a9b64eb3f11827b5", null ],
      [ "getData", "classJAULA_1_1Value__Array.html#a0ef22e554e839bfb7154bab1c8b2dab2", null ],
      [ "repr", "classJAULA_1_1Value__Array.html#a239c7bf8296192eb6fffd486ee22999e", null ],
      [ "set", "classJAULA_1_1Value__Array.html#a9ba693dd38f1b70c0773f42ee3dc6509", null ],
      [ "set", "classJAULA_1_1Value__Array.html#acf11a7dfe65b6a92a5338d0e98020592", null ],
      [ "size", "classJAULA_1_1Value__Array.html#a6109738e660820dec57f4b1faaf6bd46", null ],
      [ "data_", "classJAULA_1_1Value__Array.html#abf6e1ed306ee93489b8ef5b8c63a4ba8", null ]
    ] ],
    [ "JAULA::Value_Boolean", "classJAULA_1_1Value__Boolean.html", [
      [ "Value_Boolean", "classJAULA_1_1Value__Boolean.html#a1dbb7fcd75ebb97fadd621a829a5ad22", null ],
      [ "~Value_Boolean", "classJAULA_1_1Value__Boolean.html#a95af263d775013a6ff2ba58237a63d36", null ],
      [ "getData", "classJAULA_1_1Value__Boolean.html#a4b69fa6710772db87caad0847b71c9a2", null ],
      [ "repr", "classJAULA_1_1Value__Boolean.html#a97a1c8118746b9a42a042b4223a7f222", null ],
      [ "set", "classJAULA_1_1Value__Boolean.html#a862c31266760fb92c54403a087107928", null ],
      [ "set", "classJAULA_1_1Value__Boolean.html#a1c1f1bec7cb40bbf1a0a8dc14fda0dc2", null ],
      [ "data_", "classJAULA_1_1Value__Boolean.html#ad4e388c78f1fe152596cd7316c6ac38b", null ]
    ] ],
    [ "JAULA::Value_Complex", "classJAULA_1_1Value__Complex.html", [
      [ "~Value_Complex", "classJAULA_1_1Value__Complex.html#a4e598f3923e069416f2140e33f20fce6", null ],
      [ "Value_Complex", "classJAULA_1_1Value__Complex.html#a2a1e6558917011885a4908317aac95a6", null ],
      [ "clear", "classJAULA_1_1Value__Complex.html#a493465720c815c87641fa6f45f28ba1a", null ],
      [ "empty", "classJAULA_1_1Value__Complex.html#a178a2bf3183f5edf660af182e1227067", null ],
      [ "size", "classJAULA_1_1Value__Complex.html#a29f510f33963f51a1bcf7d48ba421b5a", null ]
    ] ],
    [ "JAULA::Value_Null", "classJAULA_1_1Value__Null.html", [
      [ "Value_Null", "classJAULA_1_1Value__Null.html#aa32dcddadf082d1f62331359c2ca8669", null ],
      [ "~Value_Null", "classJAULA_1_1Value__Null.html#aa704279f4ca14ee11936010145b4b59a", null ],
      [ "repr", "classJAULA_1_1Value__Null.html#ac58942e4f4d1e9647433668ef036abcd", null ],
      [ "set", "classJAULA_1_1Value__Null.html#ae5ac8c4be7c0db9bb58bfabc42d8cca6", null ]
    ] ],
    [ "JAULA::Value_Number", "classJAULA_1_1Value__Number.html", [
      [ "Value_Number", "classJAULA_1_1Value__Number.html#ab20abebf668729492d058ef03436b7e9", null ],
      [ "~Value_Number", "classJAULA_1_1Value__Number.html#a6ed17ebea7b819bd7974bdd4b01d719f", null ],
      [ "getData", "classJAULA_1_1Value__Number.html#a7d4aa9c914927363a6a33061d5770c56", null ],
      [ "repr", "classJAULA_1_1Value__Number.html#a16e97624c87960cc09552b2ad4034746", null ],
      [ "set", "classJAULA_1_1Value__Number.html#a76524c63a1b949e296d34f5a62973cfb", null ],
      [ "set", "classJAULA_1_1Value__Number.html#a67a8ab461f22fa43201453ec23eff2f2", null ],
      [ "data_", "classJAULA_1_1Value__Number.html#aac7152d19db86eb45064bf6df198aa5c", null ]
    ] ],
    [ "JAULA::Value_Number_Int", "classJAULA_1_1Value__Number__Int.html", [
      [ "Value_Number_Int", "classJAULA_1_1Value__Number__Int.html#a907b4c94ba0d2d6ebebefb666eb8ae1c", null ],
      [ "~Value_Number_Int", "classJAULA_1_1Value__Number__Int.html#a9aae97691c8dfb7d07a145e80a4ac43b", null ],
      [ "getData", "classJAULA_1_1Value__Number__Int.html#a05d1e7240721b2701b14cf4a4178b3c5", null ],
      [ "repr", "classJAULA_1_1Value__Number__Int.html#a589b3a4ca1d77169cdd7f98a3e3c098f", null ],
      [ "set", "classJAULA_1_1Value__Number__Int.html#a591286c9be292d44e7402dff33d76794", null ],
      [ "set", "classJAULA_1_1Value__Number__Int.html#a713fbbc4c660945c876753f20fd12529", null ],
      [ "data_", "classJAULA_1_1Value__Number__Int.html#a866b413815d48a041b53c6fc99e42396", null ]
    ] ],
    [ "JAULA::Value_Object", "classJAULA_1_1Value__Object.html", [
      [ "dataType", "classJAULA_1_1Value__Object.html#af541279d9132754a676ff26115b93be2", null ],
      [ "Value_Object", "classJAULA_1_1Value__Object.html#ad50b5f9ea8ca0f570d394fba61940c0e", null ],
      [ "Value_Object", "classJAULA_1_1Value__Object.html#a0b769838b067671cadeabcd2e9c22e55", null ],
      [ "~Value_Object", "classJAULA_1_1Value__Object.html#a6a6ceeb8972f04f0006e91ee65b25a48", null ],
      [ "clear", "classJAULA_1_1Value__Object.html#aa35cc195392c86fdb97fda72a9ae598a", null ],
      [ "empty", "classJAULA_1_1Value__Object.html#a5ddee639f136d30e0f2285c4f7f0ec36", null ],
      [ "getData", "classJAULA_1_1Value__Object.html#a2231e1090a11bda642027f0cef6d79ba", null ],
      [ "insertItem", "classJAULA_1_1Value__Object.html#a1a92fbeccb14d0f4ea400fec1effb52a", null ],
      [ "repr", "classJAULA_1_1Value__Object.html#a1b107db1a14986f64d9e8e6487c5e24f", null ],
      [ "set", "classJAULA_1_1Value__Object.html#aa6f6a6fdf36f1ed7e22361e36effaa69", null ],
      [ "set", "classJAULA_1_1Value__Object.html#a16d34f4682b4a06ffa9748b40c8c1ce0", null ],
      [ "size", "classJAULA_1_1Value__Object.html#a7748ad0a6c26f47781b1b3f62beff77c", null ],
      [ "data_", "classJAULA_1_1Value__Object.html#afe9e461d1c8f6994b0ea3f3a66a5f0de", null ]
    ] ],
    [ "JAULA::Value_String", "classJAULA_1_1Value__String.html", [
      [ "Value_String", "classJAULA_1_1Value__String.html#a3a52c369c1fc334ab8f8ad84ef3ead1e", null ],
      [ "~Value_String", "classJAULA_1_1Value__String.html#ab46965ffe7db555a3f6d1fd9a2d7db61", null ],
      [ "getData", "classJAULA_1_1Value__String.html#a0effa17b5660c2f4b1396213824919d2", null ],
      [ "repr", "classJAULA_1_1Value__String.html#ae0360e5c1392b06f4149996feef59730", null ],
      [ "set", "classJAULA_1_1Value__String.html#a788603869666c069ec0475dab84411fb", null ],
      [ "set", "classJAULA_1_1Value__String.html#a4a0f641caf2451278de24f26ecd2dece", null ],
      [ "stringRepr", "classJAULA_1_1Value__String.html#a6c0470fd0d6f225f6af42319d84b4553", null ],
      [ "data_", "classJAULA_1_1Value__String.html#acd86e835696cad5077c10895b1af5cec", null ]
    ] ],
    [ "operator<<", "group__jaula__val.html#ga74ddaaf55e4e83cd7a8a56a2d6d36ce2", null ]
];