var classJAULA_1_1Name__Duplicated =
[
    [ "Name_Duplicated", "classJAULA_1_1Name__Duplicated.html#a09ff11bf97073b9d3eff30733d8501ad", null ],
    [ "~Name_Duplicated", "classJAULA_1_1Name__Duplicated.html#a49a2259c4120953b07da7677f4d912e4", null ],
    [ "getDetail", "classJAULA_1_1Name__Duplicated.html#a75edf183bf03de812ebcf3fa33c0ea28", null ],
    [ "getName", "classJAULA_1_1Name__Duplicated.html#a05d8b3a3870833eef1496b5e69efa4db", null ],
    [ "operator=", "classJAULA_1_1Name__Duplicated.html#a50f5128f305adf80fc7eb763d5e71421", null ],
    [ "setName", "classJAULA_1_1Name__Duplicated.html#ab0b0a6e160bb8f586ed0096f2da5a866", null ],
    [ "detail_", "classJAULA_1_1Name__Duplicated.html#a6086d4a94a27fb467c5b48d3bd043147", null ],
    [ "name_", "classJAULA_1_1Name__Duplicated.html#a1a5aa292df9195cb89b5d55e06cfe7b5", null ]
];