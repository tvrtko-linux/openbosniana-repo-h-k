var classJAULA_1_1Value__Boolean =
[
    [ "Value_Boolean", "classJAULA_1_1Value__Boolean.html#a1dbb7fcd75ebb97fadd621a829a5ad22", null ],
    [ "~Value_Boolean", "classJAULA_1_1Value__Boolean.html#a95af263d775013a6ff2ba58237a63d36", null ],
    [ "getData", "classJAULA_1_1Value__Boolean.html#a4b69fa6710772db87caad0847b71c9a2", null ],
    [ "repr", "classJAULA_1_1Value__Boolean.html#a97a1c8118746b9a42a042b4223a7f222", null ],
    [ "set", "classJAULA_1_1Value__Boolean.html#a862c31266760fb92c54403a087107928", null ],
    [ "set", "classJAULA_1_1Value__Boolean.html#a1c1f1bec7cb40bbf1a0a8dc14fda0dc2", null ],
    [ "data_", "classJAULA_1_1Value__Boolean.html#ad4e388c78f1fe152596cd7316c6ac38b", null ]
];