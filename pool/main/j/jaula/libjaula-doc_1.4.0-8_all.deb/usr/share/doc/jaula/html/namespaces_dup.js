var namespaces_dup =
[
    [ "JAULA", "namespaceJAULA.html", "namespaceJAULA" ]
];