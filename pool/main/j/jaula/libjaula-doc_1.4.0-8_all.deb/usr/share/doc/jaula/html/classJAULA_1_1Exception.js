var classJAULA_1_1Exception =
[
    [ "ExCode", "classJAULA_1_1Exception.html#adb741eb42c09a2ee47538a20c735cc22", [
      [ "NO_ERROR", "classJAULA_1_1Exception.html#adb741eb42c09a2ee47538a20c735cc22ae904bb86a2dd018cc39d5c6a10c1d7df", null ],
      [ "BAD_DATA_TYPE", "classJAULA_1_1Exception.html#adb741eb42c09a2ee47538a20c735cc22a2bb72d2d5b315222d3504fa50a206657", null ],
      [ "NAME_DUPLICATED", "classJAULA_1_1Exception.html#adb741eb42c09a2ee47538a20c735cc22a606130b60f1046dc7eb370702f3e0dc7", null ],
      [ "LEXAN_ERROR", "classJAULA_1_1Exception.html#adb741eb42c09a2ee47538a20c735cc22a7183f074a353c54d9afd3173936ad239", null ],
      [ "SYNTAX_ERROR", "classJAULA_1_1Exception.html#adb741eb42c09a2ee47538a20c735cc22a872ecbf630c7421813fa77e3595aad8d", null ]
    ] ],
    [ "Exception", "classJAULA_1_1Exception.html#a702b23df403b1bacd7e7f31f36d04cb2", null ],
    [ "Exception", "classJAULA_1_1Exception.html#a3355139c025c3d04f7c1b06bc2803512", null ],
    [ "~Exception", "classJAULA_1_1Exception.html#a8eb5af8430a39a901d56a17434945238", null ],
    [ "addOrigin", "classJAULA_1_1Exception.html#a5a8a30a5c52dbda332d7a6cee79a7476", null ],
    [ "display", "classJAULA_1_1Exception.html#aedfe06df5a39c61227f6edbb3fc16756", null ],
    [ "getAction", "classJAULA_1_1Exception.html#a3e4900952cffd353bc4813d7d6172721", null ],
    [ "getCode", "classJAULA_1_1Exception.html#afb80a12f7d037452ff723468d8a687c7", null ],
    [ "getDetail", "classJAULA_1_1Exception.html#ab0bb7cc2cbeb060fac3482e7f23008a7", null ],
    [ "getOrigin", "classJAULA_1_1Exception.html#a3acf1d99f4cebc8adad4abd2d19545b9", null ],
    [ "operator=", "classJAULA_1_1Exception.html#a157d4229b59b0049ddcfc3d3b75d4930", null ],
    [ "setAction", "classJAULA_1_1Exception.html#a8e09e793ea77558933148bef0cc397f8", null ],
    [ "setCode", "classJAULA_1_1Exception.html#a12da584d1673e08d22051e675c58b6a7", null ],
    [ "setDetail", "classJAULA_1_1Exception.html#a3b17bc1cc6e1a16d2b42206d774128b2", null ],
    [ "setOrigin", "classJAULA_1_1Exception.html#abe19d7bc6c4ecd8a8054d01f40652363", null ],
    [ "action_", "classJAULA_1_1Exception.html#a3d02af4c8813d95a53dd8c9181d19c4f", null ],
    [ "code_", "classJAULA_1_1Exception.html#afa99db2a5d35794ff067a5a5f01017e4", null ],
    [ "detail_", "classJAULA_1_1Exception.html#a555961b3d8b8572ff335d66ebcbad4f6", null ],
    [ "origin_", "classJAULA_1_1Exception.html#a216e6801fbc15ee8ec4c05388449b40f", null ]
];