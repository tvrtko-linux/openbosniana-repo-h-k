var group__jaula__exc =
[
    [ "JAULA::Bad_Data_Type", "classJAULA_1_1Bad__Data__Type.html", [
      [ "Bad_Data_Type", "classJAULA_1_1Bad__Data__Type.html#aacbec3a61758074f96093cceb23198b8", null ],
      [ "~Bad_Data_Type", "classJAULA_1_1Bad__Data__Type.html#a952e8bcbfafcb8c27812aaeff3502281", null ],
      [ "operator=", "classJAULA_1_1Bad__Data__Type.html#abdb0067b901bd53d146dfad7dfeb163a", null ]
    ] ],
    [ "JAULA::Exception", "classJAULA_1_1Exception.html", [
      [ "ExCode", "classJAULA_1_1Exception.html#adb741eb42c09a2ee47538a20c735cc22", [
        [ "NO_ERROR", "classJAULA_1_1Exception.html#adb741eb42c09a2ee47538a20c735cc22ae904bb86a2dd018cc39d5c6a10c1d7df", null ],
        [ "BAD_DATA_TYPE", "classJAULA_1_1Exception.html#adb741eb42c09a2ee47538a20c735cc22a2bb72d2d5b315222d3504fa50a206657", null ],
        [ "NAME_DUPLICATED", "classJAULA_1_1Exception.html#adb741eb42c09a2ee47538a20c735cc22a606130b60f1046dc7eb370702f3e0dc7", null ],
        [ "LEXAN_ERROR", "classJAULA_1_1Exception.html#adb741eb42c09a2ee47538a20c735cc22a7183f074a353c54d9afd3173936ad239", null ],
        [ "SYNTAX_ERROR", "classJAULA_1_1Exception.html#adb741eb42c09a2ee47538a20c735cc22a872ecbf630c7421813fa77e3595aad8d", null ]
      ] ],
      [ "Exception", "classJAULA_1_1Exception.html#a702b23df403b1bacd7e7f31f36d04cb2", null ],
      [ "Exception", "classJAULA_1_1Exception.html#a3355139c025c3d04f7c1b06bc2803512", null ],
      [ "~Exception", "classJAULA_1_1Exception.html#a8eb5af8430a39a901d56a17434945238", null ],
      [ "addOrigin", "classJAULA_1_1Exception.html#a5a8a30a5c52dbda332d7a6cee79a7476", null ],
      [ "display", "classJAULA_1_1Exception.html#aedfe06df5a39c61227f6edbb3fc16756", null ],
      [ "getAction", "classJAULA_1_1Exception.html#a3e4900952cffd353bc4813d7d6172721", null ],
      [ "getCode", "classJAULA_1_1Exception.html#afb80a12f7d037452ff723468d8a687c7", null ],
      [ "getDetail", "classJAULA_1_1Exception.html#ab0bb7cc2cbeb060fac3482e7f23008a7", null ],
      [ "getOrigin", "classJAULA_1_1Exception.html#a3acf1d99f4cebc8adad4abd2d19545b9", null ],
      [ "operator=", "classJAULA_1_1Exception.html#a157d4229b59b0049ddcfc3d3b75d4930", null ],
      [ "setAction", "classJAULA_1_1Exception.html#a8e09e793ea77558933148bef0cc397f8", null ],
      [ "setCode", "classJAULA_1_1Exception.html#a12da584d1673e08d22051e675c58b6a7", null ],
      [ "setDetail", "classJAULA_1_1Exception.html#a3b17bc1cc6e1a16d2b42206d774128b2", null ],
      [ "setOrigin", "classJAULA_1_1Exception.html#abe19d7bc6c4ecd8a8054d01f40652363", null ],
      [ "action_", "classJAULA_1_1Exception.html#a3d02af4c8813d95a53dd8c9181d19c4f", null ],
      [ "code_", "classJAULA_1_1Exception.html#afa99db2a5d35794ff067a5a5f01017e4", null ],
      [ "detail_", "classJAULA_1_1Exception.html#a555961b3d8b8572ff335d66ebcbad4f6", null ],
      [ "origin_", "classJAULA_1_1Exception.html#a216e6801fbc15ee8ec4c05388449b40f", null ]
    ] ],
    [ "JAULA::Lexan_Error", "classJAULA_1_1Lexan__Error.html", [
      [ "Lexan_Error", "classJAULA_1_1Lexan__Error.html#abde651848dc5071b7a5fc0d6c0588d50", null ],
      [ "~Lexan_Error", "classJAULA_1_1Lexan__Error.html#ac9f30a7ec49114965d1b0781481fb5ed", null ],
      [ "operator=", "classJAULA_1_1Lexan__Error.html#a9b52fe1aadf62eb021221a513f2d524f", null ]
    ] ],
    [ "JAULA::Name_Duplicated", "classJAULA_1_1Name__Duplicated.html", [
      [ "Name_Duplicated", "classJAULA_1_1Name__Duplicated.html#a09ff11bf97073b9d3eff30733d8501ad", null ],
      [ "~Name_Duplicated", "classJAULA_1_1Name__Duplicated.html#a49a2259c4120953b07da7677f4d912e4", null ],
      [ "getDetail", "classJAULA_1_1Name__Duplicated.html#a75edf183bf03de812ebcf3fa33c0ea28", null ],
      [ "getName", "classJAULA_1_1Name__Duplicated.html#a05d8b3a3870833eef1496b5e69efa4db", null ],
      [ "operator=", "classJAULA_1_1Name__Duplicated.html#a50f5128f305adf80fc7eb763d5e71421", null ],
      [ "setName", "classJAULA_1_1Name__Duplicated.html#ab0b0a6e160bb8f586ed0096f2da5a866", null ],
      [ "detail_", "classJAULA_1_1Name__Duplicated.html#a6086d4a94a27fb467c5b48d3bd043147", null ],
      [ "name_", "classJAULA_1_1Name__Duplicated.html#a1a5aa292df9195cb89b5d55e06cfe7b5", null ]
    ] ],
    [ "JAULA::No_Error", "classJAULA_1_1No__Error.html", [
      [ "No_Error", "classJAULA_1_1No__Error.html#a1c8c78770bc47c6020456d30ddb4bda4", null ],
      [ "~No_Error", "classJAULA_1_1No__Error.html#a346a0b022ab40653196db72309a71c0a", null ],
      [ "operator=", "classJAULA_1_1No__Error.html#a49c319b46943c56d46a6c67c083d5604", null ]
    ] ],
    [ "JAULA::Syntax_Error", "classJAULA_1_1Syntax__Error.html", [
      [ "Syntax_Error", "classJAULA_1_1Syntax__Error.html#a5487874713190af5f108a534b1c1e67e", null ],
      [ "~Syntax_Error", "classJAULA_1_1Syntax__Error.html#a0900330719b4ec7bf67fc46d088bc927", null ],
      [ "operator=", "classJAULA_1_1Syntax__Error.html#a9ddcd302a7e24b58854c3fd593ef8fdd", null ]
    ] ],
    [ "operator<<", "group__jaula__exc.html#ga80ddbaaf6c271490c3c9727ee4dcf331", null ]
];