var classJAULA_1_1Value =
[
    [ "ValueType", "classJAULA_1_1Value.html#abd733466d82038744096c9e511a34f9a", [
      [ "TYPE_NULL", "classJAULA_1_1Value.html#abd733466d82038744096c9e511a34f9aa7e6263d35b7e7eca07d8f18cc4435da2", null ],
      [ "TYPE_BOOLEAN", "classJAULA_1_1Value.html#abd733466d82038744096c9e511a34f9aa2797ae23806954099da3c647a963a709", null ],
      [ "TYPE_STRING", "classJAULA_1_1Value.html#abd733466d82038744096c9e511a34f9aa1214957f1c910b629e6475daff41664c", null ],
      [ "TYPE_NUMBER", "classJAULA_1_1Value.html#abd733466d82038744096c9e511a34f9aaa7b080dad5a7e691aa340e329d09f83e", null ],
      [ "TYPE_NUMBER_INT", "classJAULA_1_1Value.html#abd733466d82038744096c9e511a34f9aa3766b562ba180f08d2da542d70d86523", null ],
      [ "TYPE_ARRAY", "classJAULA_1_1Value.html#abd733466d82038744096c9e511a34f9aaf068f23add6ce94d00d4cf9959c9ded1", null ],
      [ "TYPE_OBJECT", "classJAULA_1_1Value.html#abd733466d82038744096c9e511a34f9aa8e165011482b42e8389137a615170e99", null ]
    ] ],
    [ "~Value", "classJAULA_1_1Value.html#a9097e24411e0497ff18e76f413e35333", null ],
    [ "Value", "classJAULA_1_1Value.html#a0344bd340e96d19d7290f0235eaed282", null ],
    [ "duplicate", "classJAULA_1_1Value.html#ac8f298fd9f0a0e7b76f2c597560e96b1", null ],
    [ "getType", "classJAULA_1_1Value.html#a3fbf54f53e1db4929794b45ed6d77fbf", null ],
    [ "operator=", "classJAULA_1_1Value.html#af27b1a6c4bd029fafbd7e4ef1cffc345", null ],
    [ "repr", "classJAULA_1_1Value.html#acc0fcc910630095dcd08a37b29398008", null ],
    [ "set", "classJAULA_1_1Value.html#a2b35b2be89e4d01368f6867a149446ad", null ],
    [ "Type_", "classJAULA_1_1Value.html#acf280538476a1e4e5612a3b1e6fc698a", null ]
];