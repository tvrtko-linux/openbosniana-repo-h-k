jenkins-debian-glue
===================

Continuous Integration for Debian and Ubuntu made easy.
jenkins-debian-glue allows you to build Debian and Ubuntu packages
directly from the Jenkins Continuous Integration system.

Please head over to [jenkins-debian-glue.org](http://jenkins-debian-glue.org/)
for setup instructions and documentation.
