#ifndef SRC_MOD_COMMON_TRACE_H_
#define SRC_MOD_COMMON_TRACE_H_

#include "mod/common/translation_state.h"

void pkt_trace6(struct xlation *state);
void pkt_trace4(struct xlation *state);

#endif /* SRC_MOD_COMMON_TRACE_H_ */
