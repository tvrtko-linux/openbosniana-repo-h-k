--8<-- "LICENSE.md"

---
### MIT License
--8<-- "LICENSES/MIT.txt"


---
### GPL License
--8<-- "LICENSES/GPL-3.0.txt"

---
### LGPL License
--8<-- "LICENSES/LGPL-3.0-only.txt"