SITE PROPERTIES

Any property files (with extension .props) placed in this directory will
be loaded by jEdit before the user-specific properties. On multi-user
machines, this can be used to enforce a site-wide color scheme, for example.
Just copy the relevant entries from your user properties file into a new .props file, and place it in this directory.

As of jEdit 5.0, keyboard shortcuts should not be placed in this file.  If
you want to define a site-wide set of keyboard shortcuts, you should create
a named keymap and place it in the "keymaps" directory.


