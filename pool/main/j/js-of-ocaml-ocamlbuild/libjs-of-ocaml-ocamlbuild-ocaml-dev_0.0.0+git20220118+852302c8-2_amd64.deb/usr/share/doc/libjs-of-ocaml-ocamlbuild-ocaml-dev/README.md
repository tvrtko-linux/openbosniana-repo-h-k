# js_of_ocaml-ocamlbuild, an ocamlbuild plugin to compile to JavaScript

[![Build Status](https://github.com/ocsigen/js_of_ocaml-ocamlbuild/workflows/build/badge.svg?branch=master)](https://github.com/ocsigen/js_of_ocaml-ocamlbuild/actions)

## Installation

### Opam

```
opam install js_of_ocaml-ocamlbuild
```

