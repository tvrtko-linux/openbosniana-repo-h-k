c.JupyterHub.proxy_class = 'jupyterhub.proxy.ConfigurableHTTPProxy'
