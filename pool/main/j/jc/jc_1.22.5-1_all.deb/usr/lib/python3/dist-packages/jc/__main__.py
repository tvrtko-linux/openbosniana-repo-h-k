import jc.cli

jc.cli.main()
