# frozen_string_literal: true

module Jekyll
  Generator = Class.new(Plugin)
end
