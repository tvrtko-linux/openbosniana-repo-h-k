### BEGIN DOCUMENT
The domino puzzle cards have the following entries.  ("(BLANK)"
indicates than an entry is blank.)

<: puzzlenote :>

| Left entry | Right entry | Left label | Right label |
|:----------:|:-----------:|:----------:|:-----------:|
### BEGIN ITEM
| <: textL :> | <: textR :> | <: labelL :> | <: labelR :> |
### END DOCUMENT

