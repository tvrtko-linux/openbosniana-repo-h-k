The puzzle cards have the following edges.  ("(BLANK)" indicates than
an edge is blank.  Cards which have an empty "Edge 4" are triangular.
It is possible that some edges do not match, if they are are the
outside of the puzzle.)

<: puzzlenote :>

| Edge 1 | Edge 2 | Edge 3 |
|:------:|:------:|:------:|
<: puzcards4 :>
