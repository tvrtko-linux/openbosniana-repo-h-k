The pairs match up as follows:

<: hiddennotemd :>

| Edge 1 | Edge 2 |
|:------:|:------:|
<: pairs :>

The following border edges did not match any other edges:

| Edge 1 |
|:------:|
<: edges :>
