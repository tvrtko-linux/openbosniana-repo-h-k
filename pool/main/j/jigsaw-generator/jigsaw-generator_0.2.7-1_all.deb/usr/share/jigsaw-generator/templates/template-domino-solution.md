### BEGIN DOCUMENT
The correct pairing is as follows (in order).

<: hiddennotemd :>

| Right entry | Left entry | Right label | Left label |
|:-----------:|:----------:|:-----------:|:----------:|
### BEGIN ITEM
| <: textR :> | <: textL :> | <: labelR :> | <: labelL :> |
### END DOCUMENT

