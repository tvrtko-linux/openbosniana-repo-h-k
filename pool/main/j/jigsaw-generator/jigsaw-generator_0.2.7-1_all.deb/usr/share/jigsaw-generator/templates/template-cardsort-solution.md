### BEGIN DOCUMENT
The correct order is as follows.

<: hiddennotemd :>

| Row | Column | Card number | Card | Label |
|:---:|:------:|:-----------:|:----:|:-----:|
### BEGIN ITEM
| <: rownum :> | <: colnum :> | <: cardnum :> | <: text :> | <: label :> |
### END DOCUMENT

