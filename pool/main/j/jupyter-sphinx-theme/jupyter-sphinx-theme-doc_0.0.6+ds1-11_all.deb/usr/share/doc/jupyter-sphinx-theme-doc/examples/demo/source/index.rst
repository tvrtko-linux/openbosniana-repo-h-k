==========================
 Jupyter Sphinx Theme Demo
==========================

This is a basic demo site for the `Jupyter Sphinx Theme`_ that provides a
minimal working Sphinx site using the theme.

.. _`Jupyter Sphinx Theme`: https://github.com/jupyter/jupyter-sphinx-theme

Contents
========

Setting up and using the theme.

.. toctree::
   :maxdepth: 2

   examples
   sidebar
   subdir/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
