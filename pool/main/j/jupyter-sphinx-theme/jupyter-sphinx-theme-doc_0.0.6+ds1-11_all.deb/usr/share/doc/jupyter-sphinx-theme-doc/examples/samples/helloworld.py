#!/usr/bin/python3

def main():
	print 'Hello world !'

if __name__ == '__main__':
	main()

## eos
