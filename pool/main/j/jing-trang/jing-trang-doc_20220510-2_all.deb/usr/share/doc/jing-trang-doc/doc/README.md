# Moved

On 2 December, 2018, these files were moved to the website repository:

> https://github.com/relaxng/relaxng.org

where they appear under the `/jclark/` directory. The are also available
at https://relaxng.org/jclark/

