"""Module with NApp directories."""
