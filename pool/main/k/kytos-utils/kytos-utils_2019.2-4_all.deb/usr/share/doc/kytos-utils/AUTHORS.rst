#######
Authors
#######

- Beraldo Leal <beraldo AT ncc DOT unesp DOT br>
- Carlos Eduardo Moreira dos Santos <cadu AT ncc DOT unesp DOT br>
- Diego Rabatone Oliveira <diraol AT ncc DOT unesp DOT br>
- Macártur de Sousa Carvalho <macartur.sc AT gmail DOT com>
- Gleyberson Andrade <gleybersonandrade AT gmail DOT com>
- Humberto Diógenes <hdiogenes AT gmail DOT com>
- Lucas Felix <lucasgsfelix AT gmail DOT com>
- Rogerio Motitsuki <rogerio.motitsuki AT gmail DOT com>

Contributors
------------

- Luan Gonçalves <luanlg.cco AT gmail DOT com>
- Erick Vermot <erick.vermot AT gmail DOT com>
- Vinicius Arcanjo <viniciusarcanjov AT gmail DOT com>
- Carlos Magno Barbosa <cmagnobarbosa AT gmail DOT com>
