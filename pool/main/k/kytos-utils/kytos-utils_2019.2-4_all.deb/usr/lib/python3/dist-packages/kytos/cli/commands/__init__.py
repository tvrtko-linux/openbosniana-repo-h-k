"""Basic CLI commands."""
