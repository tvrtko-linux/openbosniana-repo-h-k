"""NAPPS CLI Commands."""
