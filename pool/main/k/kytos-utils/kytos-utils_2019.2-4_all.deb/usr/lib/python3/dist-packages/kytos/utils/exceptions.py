"""Kytos utils exceptions."""


class KytosException(Exception):
    """Kytos utils main exception."""
