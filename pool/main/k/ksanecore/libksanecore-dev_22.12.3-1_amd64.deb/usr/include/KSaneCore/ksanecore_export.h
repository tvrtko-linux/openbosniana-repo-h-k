
#ifndef KSANECORE_EXPORT_H
#define KSANECORE_EXPORT_H

#ifdef KSANECORE_STATIC_DEFINE
#  define KSANECORE_EXPORT
#  define KSANECORE_NO_EXPORT
#else
#  ifndef KSANECORE_EXPORT
#    ifdef KSaneCore_EXPORTS
        /* We are building this library */
#      define KSANECORE_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KSANECORE_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KSANECORE_NO_EXPORT
#    define KSANECORE_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KSANECORE_DEPRECATED
#  define KSANECORE_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KSANECORE_DEPRECATED_EXPORT
#  define KSANECORE_DEPRECATED_EXPORT KSANECORE_EXPORT KSANECORE_DEPRECATED
#endif

#ifndef KSANECORE_DEPRECATED_NO_EXPORT
#  define KSANECORE_DEPRECATED_NO_EXPORT KSANECORE_NO_EXPORT KSANECORE_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KSANECORE_NO_DEPRECATED
#    define KSANECORE_NO_DEPRECATED
#  endif
#endif

#endif /* KSANECORE_EXPORT_H */
