
#ifndef KCHART_EXPORT_H
#define KCHART_EXPORT_H

#ifdef KCHART_STATIC_DEFINE
#  define KCHART_EXPORT
#  define KCHART_NO_EXPORT
#else
#  ifndef KCHART_EXPORT
#    ifdef KChart_EXPORTS
        /* We are building this library */
#      define KCHART_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KCHART_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KCHART_NO_EXPORT
#    define KCHART_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KCHART_DEPRECATED
#  define KCHART_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KCHART_DEPRECATED_EXPORT
#  define KCHART_DEPRECATED_EXPORT KCHART_EXPORT KCHART_DEPRECATED
#endif

#ifndef KCHART_DEPRECATED_NO_EXPORT
#  define KCHART_DEPRECATED_NO_EXPORT KCHART_NO_EXPORT KCHART_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KCHART_NO_DEPRECATED
#    define KCHART_NO_DEPRECATED
#  endif
#endif

#endif /* KCHART_EXPORT_H */
