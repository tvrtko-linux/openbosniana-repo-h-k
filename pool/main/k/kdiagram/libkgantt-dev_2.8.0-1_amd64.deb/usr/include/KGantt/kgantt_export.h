
#ifndef KGANTT_EXPORT_H
#define KGANTT_EXPORT_H

#ifdef KGANTT_STATIC_DEFINE
#  define KGANTT_EXPORT
#  define KGANTT_NO_EXPORT
#else
#  ifndef KGANTT_EXPORT
#    ifdef KGantt_EXPORTS
        /* We are building this library */
#      define KGANTT_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KGANTT_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KGANTT_NO_EXPORT
#    define KGANTT_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KGANTT_DEPRECATED
#  define KGANTT_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KGANTT_DEPRECATED_EXPORT
#  define KGANTT_DEPRECATED_EXPORT KGANTT_EXPORT KGANTT_DEPRECATED
#endif

#ifndef KGANTT_DEPRECATED_NO_EXPORT
#  define KGANTT_DEPRECATED_NO_EXPORT KGANTT_NO_EXPORT KGANTT_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KGANTT_NO_DEPRECATED
#    define KGANTT_NO_DEPRECATED
#  endif
#endif

#endif /* KGANTT_EXPORT_H */
