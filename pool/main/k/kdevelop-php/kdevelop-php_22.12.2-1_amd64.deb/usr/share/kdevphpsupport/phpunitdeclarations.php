<?php

class PHPUnit_Framework_TestCase {}

class PHPUnit_Extensions_SeleniumTestCase extends PHPUnit_Framework_TestCase {}

class PHPUnit_Framework_TestSuite {
    public function suite() {}
}
?>