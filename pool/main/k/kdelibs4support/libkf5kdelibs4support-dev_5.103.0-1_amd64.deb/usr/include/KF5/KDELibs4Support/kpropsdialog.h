// krazy:exclude=includes
// This is now called kpropertiesdialog.h
#ifndef KPROPSDIALOG_H
#define KPROPSDIALOG_H

#ifndef KDE_NO_COMPAT
#include <kpropertiesdialog.h>
#endif

#endif
