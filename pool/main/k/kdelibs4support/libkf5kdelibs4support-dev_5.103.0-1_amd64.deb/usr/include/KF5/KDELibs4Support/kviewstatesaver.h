
#ifndef KVIEWSTATESAVER_H
#define KVIEWSTATESAVER_H

#include "kconfigviewstatesaver.h"

typedef KConfigViewStateSaver KViewStateSaver;

#endif
