// kde4 compat
#include <kparts/listingfilterextension.h>
#include <kparts/listingnotificationextension.h>
