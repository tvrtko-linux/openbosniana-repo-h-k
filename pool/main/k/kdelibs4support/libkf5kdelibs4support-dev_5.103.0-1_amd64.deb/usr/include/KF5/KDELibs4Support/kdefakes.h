#warning This header is deprecated. Port to the appropriate Qt API instead.
