#include <kns3/downloadwidget.h>
