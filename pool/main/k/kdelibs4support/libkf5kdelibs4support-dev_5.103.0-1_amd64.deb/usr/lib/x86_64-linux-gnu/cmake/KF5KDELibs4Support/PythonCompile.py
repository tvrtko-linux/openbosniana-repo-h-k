# By Simon Edwards <simon@simonzone.com>
# This file is in the public domain.
import py_compile, sys
sys.exit(py_compile.main())
