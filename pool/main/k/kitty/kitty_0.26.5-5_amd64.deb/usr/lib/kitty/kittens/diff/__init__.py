class GlobalData:

    def __init__(self) -> None:
        self.title = ''
        self.cmd = ''


global_data = GlobalData
