/*  This file is part of the KDE libraries
    SPDX-FileCopyrightText: 2013 Chusslove Illich <caslav.ilic@gmx.net>

    SPDX-License-Identifier: LGPL-2.0-or-later
*/

#ifndef KUITSETUP_H
#define KUITSETUP_H

#include <kuitmarkup.h>

#endif // KUITSETUP_H
