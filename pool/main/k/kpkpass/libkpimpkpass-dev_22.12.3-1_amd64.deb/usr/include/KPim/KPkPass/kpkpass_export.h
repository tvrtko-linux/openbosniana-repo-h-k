
#ifndef KPKPASS_EXPORT_H
#define KPKPASS_EXPORT_H

#ifdef KPKPASS_STATIC_DEFINE
#  define KPKPASS_EXPORT
#  define KPKPASS_NO_EXPORT
#else
#  ifndef KPKPASS_EXPORT
#    ifdef KPimPkPass_EXPORTS
        /* We are building this library */
#      define KPKPASS_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KPKPASS_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KPKPASS_NO_EXPORT
#    define KPKPASS_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KPKPASS_DEPRECATED
#  define KPKPASS_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KPKPASS_DEPRECATED_EXPORT
#  define KPKPASS_DEPRECATED_EXPORT KPKPASS_EXPORT KPKPASS_DEPRECATED
#endif

#ifndef KPKPASS_DEPRECATED_NO_EXPORT
#  define KPKPASS_DEPRECATED_NO_EXPORT KPKPASS_NO_EXPORT KPKPASS_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KPKPASS_NO_DEPRECATED
#    define KPKPASS_NO_DEPRECATED
#  endif
#endif

#endif /* KPKPASS_EXPORT_H */
