
#ifndef KPROPERTYCORE_EXPORT_H
#define KPROPERTYCORE_EXPORT_H

#ifdef KPROPERTYCORE_STATIC_DEFINE
#  define KPROPERTYCORE_EXPORT
#  define KPROPERTYCORE_NO_EXPORT
#else
#  ifndef KPROPERTYCORE_EXPORT
#    ifdef KPropertyCore_EXPORTS
        /* We are building this library */
#      define KPROPERTYCORE_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KPROPERTYCORE_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KPROPERTYCORE_NO_EXPORT
#    define KPROPERTYCORE_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KPROPERTYCORE_DEPRECATED
#  define KPROPERTYCORE_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KPROPERTYCORE_DEPRECATED_EXPORT
#  define KPROPERTYCORE_DEPRECATED_EXPORT KPROPERTYCORE_EXPORT KPROPERTYCORE_DEPRECATED
#endif

#ifndef KPROPERTYCORE_DEPRECATED_NO_EXPORT
#  define KPROPERTYCORE_DEPRECATED_NO_EXPORT KPROPERTYCORE_NO_EXPORT KPROPERTYCORE_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KPROPERTYCORE_NO_DEPRECATED
#    define KPROPERTYCORE_NO_DEPRECATED
#  endif
#endif

#endif /* KPROPERTYCORE_EXPORT_H */
