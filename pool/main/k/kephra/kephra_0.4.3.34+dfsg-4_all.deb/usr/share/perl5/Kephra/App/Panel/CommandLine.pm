package Kephra::App::Panel::CommandLine;
$VERSION = '0.00';

use strict;
use warnings;

1;
