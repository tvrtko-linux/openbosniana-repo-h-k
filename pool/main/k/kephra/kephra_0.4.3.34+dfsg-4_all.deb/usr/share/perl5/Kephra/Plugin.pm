package Kephra::Plugin;
our $VERSION = '0.00';

use strict;
use warnings;

sub install{}
sub deinstall{}
sub init {}
1;