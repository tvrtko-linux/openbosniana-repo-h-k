package Kephra::App::Panel::TreeTool;
use strict;
use warnings;

our $VERSION = '0.01';

sub _config { Kephra::API::settings()->{app}{panel}{lib}}

sub start{}

1;
