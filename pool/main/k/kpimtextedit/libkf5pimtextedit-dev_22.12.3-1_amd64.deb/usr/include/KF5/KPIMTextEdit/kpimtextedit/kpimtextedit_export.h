
#ifndef KPIMTEXTEDIT_EXPORT_H
#define KPIMTEXTEDIT_EXPORT_H

#ifdef KPIMTEXTEDIT_STATIC_DEFINE
#  define KPIMTEXTEDIT_EXPORT
#  define KPIMTEXTEDIT_NO_EXPORT
#else
#  ifndef KPIMTEXTEDIT_EXPORT
#    ifdef KF5PimTextEdit_EXPORTS
        /* We are building this library */
#      define KPIMTEXTEDIT_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KPIMTEXTEDIT_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KPIMTEXTEDIT_NO_EXPORT
#    define KPIMTEXTEDIT_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KPIMTEXTEDIT_DEPRECATED
#  define KPIMTEXTEDIT_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KPIMTEXTEDIT_DEPRECATED_EXPORT
#  define KPIMTEXTEDIT_DEPRECATED_EXPORT KPIMTEXTEDIT_EXPORT KPIMTEXTEDIT_DEPRECATED
#endif

#ifndef KPIMTEXTEDIT_DEPRECATED_NO_EXPORT
#  define KPIMTEXTEDIT_DEPRECATED_NO_EXPORT KPIMTEXTEDIT_NO_EXPORT KPIMTEXTEDIT_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KPIMTEXTEDIT_NO_DEPRECATED
#    define KPIMTEXTEDIT_NO_DEPRECATED
#  endif
#endif

#endif /* KPIMTEXTEDIT_EXPORT_H */
