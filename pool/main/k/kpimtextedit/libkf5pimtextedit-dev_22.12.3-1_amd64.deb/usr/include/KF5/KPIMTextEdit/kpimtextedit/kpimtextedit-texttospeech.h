/*
  SPDX-FileCopyrightText: 2022 Laurent Montel <montel@kde.org>

  SPDX-License-Identifier: GPL-2.0-or-later
*/

#define KPIMTEXTEDIT_TEXT_TO_SPEECH  1

