
#ifndef KDAV_EXPORT_H
#define KDAV_EXPORT_H

#ifdef KDAV_STATIC_DEFINE
#  define KDAV_EXPORT
#  define KDAV_NO_EXPORT
#else
#  ifndef KDAV_EXPORT
#    ifdef KF5DAV_EXPORTS
        /* We are building this library */
#      define KDAV_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KDAV_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KDAV_NO_EXPORT
#    define KDAV_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KDAV_DEPRECATED
#  define KDAV_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KDAV_DEPRECATED_EXPORT
#  define KDAV_DEPRECATED_EXPORT KDAV_EXPORT KDAV_DEPRECATED
#endif

#ifndef KDAV_DEPRECATED_NO_EXPORT
#  define KDAV_DEPRECATED_NO_EXPORT KDAV_NO_EXPORT KDAV_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KDAV_NO_DEPRECATED
#    define KDAV_NO_DEPRECATED
#  endif
#endif

#endif /* KDAV_EXPORT_H */
