/* A Bison parser, made by GNU Bison 2.7.  */

/* Bison interface for Yacc-like parsers in C

      Copyright (C) 1984, 1989-1990, 2000-2012 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_KJSYY_GRAMMAR_H_INCLUDED
# define YY_KJSYY_GRAMMAR_H_INCLUDED
/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int kjsyydebug;
#endif

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
/* Put the tokens into the symbol table, so that GDB and other debuggers
   know about them.  */
enum yytokentype {
    NULLTOKEN = 258,
    TRUETOKEN = 259,
    FALSETOKEN = 260,
    BREAK = 261,
    CASE = 262,
    DEFAULT = 263,
    FOR = 264,
    NEW = 265,
    VAR = 266,
    CONSTTOKEN = 267,
    CONTINUE = 268,
    FUNCTION = 269,
    RETURN = 270,
    VOIDTOKEN = 271,
    DELETETOKEN = 272,
    IF = 273,
    THISTOKEN = 274,
    DO = 275,
    WHILE = 276,
    INTOKEN = 277,
    INSTANCEOF = 278,
    TYPEOF = 279,
    SWITCH = 280,
    WITH = 281,
    RESERVED = 282,
    THROW = 283,
    TRY = 284,
    CATCH = 285,
    FINALLY = 286,
    DEBUGGER = 287,
    IMPORT = 288,
    IF_WITHOUT_ELSE = 289,
    ELSE = 290,
    EQEQ = 291,
    NE = 292,
    STREQ = 293,
    STRNEQ = 294,
    LE = 295,
    GE = 296,
    OR = 297,
    AND = 298,
    PLUSPLUS = 299,
    MINUSMINUS = 300,
    LSHIFT = 301,
    RSHIFT = 302,
    URSHIFT = 303,
    T_EXP = 304,
    PLUSEQUAL = 305,
    MINUSEQUAL = 306,
    MULTEQUAL = 307,
    DIVEQUAL = 308,
    EXPEQUAL = 309,
    LSHIFTEQUAL = 310,
    RSHIFTEQUAL = 311,
    URSHIFTEQUAL = 312,
    ANDEQUAL = 313,
    MODEQUAL = 314,
    XOREQUAL = 315,
    OREQUAL = 316,
    NUMBER = 317,
    STRING = 318,
    IDENT = 319,
    AUTOPLUSPLUS = 320,
    AUTOMINUSMINUS = 321
};
#endif

#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE {
    /* Line 2058 of yacc.c  */
#line 63 "grammar.y"

    int                 ival;
    double              dval;
    UString             *ustr;
    Identifier          *ident;
    Node                *node;
    StatementNode       *stat;
    ParameterNode       *param;
    FunctionBodyNode    *body;
    FuncDeclNode        *func;
    FuncExprNode        *funcExpr;
    ProgramNode         *prog;
    AssignExprNode      *init;
    SourceElementsNode  *srcs;
    ArgumentsNode       *args;
    ArgumentListNode    *alist;
    VarDeclNode         *decl;
    VarDeclListNode     *vlist;
    CaseBlockNode       *cblk;
    ClauseListNode      *clist;
    CaseClauseNode      *ccl;
    ElementNode         *elm;
    Operator            op;
    PropertyListNode   *plist;
    PropertyNode       *pnode;
    PropertyNameNode   *pname;
    PackageNameNode     *pkgn;

    /* Line 2058 of yacc.c  */
#line 153 "grammar.h"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif

#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE {
    int first_line;
    int first_column;
    int last_line;
    int last_column;
} YYLTYPE;
# define yyltype YYLTYPE /* obsolescent; will be withdrawn */
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif

extern YYSTYPE kjsyylval;
extern YYLTYPE kjsyylloc;
#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int kjsyyparse(void *YYPARSE_PARAM);
#else
int kjsyyparse();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int kjsyyparse(void);
#else
int kjsyyparse();
#endif
#endif /* ! YYPARSE_PARAM */

#endif /* !YY_KJSYY_GRAMMAR_H_INCLUDED  */
