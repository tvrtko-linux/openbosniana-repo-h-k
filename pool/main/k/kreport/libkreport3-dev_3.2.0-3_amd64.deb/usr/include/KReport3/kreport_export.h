
#ifndef KREPORT_EXPORT_H
#define KREPORT_EXPORT_H

#ifdef KREPORT_STATIC_DEFINE
#  define KREPORT_EXPORT
#  define KREPORT_NO_EXPORT
#else
#  ifndef KREPORT_EXPORT
#    ifdef KReport_EXPORTS
        /* We are building this library */
#      define KREPORT_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KREPORT_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KREPORT_NO_EXPORT
#    define KREPORT_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KREPORT_DEPRECATED
#  define KREPORT_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KREPORT_DEPRECATED_EXPORT
#  define KREPORT_DEPRECATED_EXPORT KREPORT_EXPORT KREPORT_DEPRECATED
#endif

#ifndef KREPORT_DEPRECATED_NO_EXPORT
#  define KREPORT_DEPRECATED_NO_EXPORT KREPORT_NO_EXPORT KREPORT_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KREPORT_NO_DEPRECATED
#    define KREPORT_NO_DEPRECATED
#  endif
#endif

#endif /* KREPORT_EXPORT_H */
