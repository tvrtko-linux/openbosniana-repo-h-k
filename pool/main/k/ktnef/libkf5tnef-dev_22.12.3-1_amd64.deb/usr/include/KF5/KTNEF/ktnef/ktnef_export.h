
#ifndef KTNEF_EXPORT_H
#define KTNEF_EXPORT_H

#ifdef KTNEF_STATIC_DEFINE
#  define KTNEF_EXPORT
#  define KTNEF_NO_EXPORT
#else
#  ifndef KTNEF_EXPORT
#    ifdef KF5Tnef_EXPORTS
        /* We are building this library */
#      define KTNEF_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KTNEF_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KTNEF_NO_EXPORT
#    define KTNEF_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KTNEF_DEPRECATED
#  define KTNEF_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KTNEF_DEPRECATED_EXPORT
#  define KTNEF_DEPRECATED_EXPORT KTNEF_EXPORT KTNEF_DEPRECATED
#endif

#ifndef KTNEF_DEPRECATED_NO_EXPORT
#  define KTNEF_DEPRECATED_NO_EXPORT KTNEF_NO_EXPORT KTNEF_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KTNEF_NO_DEPRECATED
#    define KTNEF_NO_DEPRECATED
#  endif
#endif

#endif /* KTNEF_EXPORT_H */
