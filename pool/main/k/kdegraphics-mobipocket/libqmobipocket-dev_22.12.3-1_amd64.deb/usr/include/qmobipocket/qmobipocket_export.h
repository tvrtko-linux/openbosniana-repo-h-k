
#ifndef QMOBIPOCKET_EXPORT_H
#define QMOBIPOCKET_EXPORT_H

#ifdef QMOBIPOCKET_STATIC_DEFINE
#  define QMOBIPOCKET_EXPORT
#  define QMOBIPOCKET_NO_EXPORT
#else
#  ifndef QMOBIPOCKET_EXPORT
#    ifdef qmobipocket_EXPORTS
        /* We are building this library */
#      define QMOBIPOCKET_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define QMOBIPOCKET_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef QMOBIPOCKET_NO_EXPORT
#    define QMOBIPOCKET_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef QMOBIPOCKET_DEPRECATED
#  define QMOBIPOCKET_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef QMOBIPOCKET_DEPRECATED_EXPORT
#  define QMOBIPOCKET_DEPRECATED_EXPORT QMOBIPOCKET_EXPORT QMOBIPOCKET_DEPRECATED
#endif

#ifndef QMOBIPOCKET_DEPRECATED_NO_EXPORT
#  define QMOBIPOCKET_DEPRECATED_NO_EXPORT QMOBIPOCKET_NO_EXPORT QMOBIPOCKET_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef QMOBIPOCKET_NO_DEPRECATED
#    define QMOBIPOCKET_NO_DEPRECATED
#  endif
#endif

#endif /* QMOBIPOCKET_EXPORT_H */
