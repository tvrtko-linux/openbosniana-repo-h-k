## @package kapidox
#
# The root of the module
#