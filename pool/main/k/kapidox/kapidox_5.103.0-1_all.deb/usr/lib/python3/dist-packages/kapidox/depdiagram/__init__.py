from kapidox.depdiagram.generate import *
