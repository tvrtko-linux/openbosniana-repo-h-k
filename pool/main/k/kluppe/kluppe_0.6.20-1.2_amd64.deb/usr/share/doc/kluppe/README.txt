INTRO:
------
kluppe is a loop-player and recorder, designed for live use.
kluppe is open source (see LICENSE.txt)
kluppe is the austrian word for clip or peg and sounds even crazier if you loop it 
for details about the word kluppe see http://lists.debian.org/debian-devel/2004/05/msg00182.html ;-)

kluppe is written in c using jack, gtk, libasound, libxml libusb liblo and libsndfile.
libasound:  http://www.alsa-project.orh
libsndfile: http://www.mega-nerd.com/libsndfile/
libjack: http://jackit.sf.net (at least version 0.90)
gtk2.0: http://gtk.org (at least version 2.6)
libxml2 http://xmlsoft.org/
libusb http://libusb.sourceforge.net/
liblo http://liblo.sourceforge.net/
kluppe is linux only (kernel >= 2.4) so far.
in theory it should work on all platforms with existing ports for the used libraries...

COMPILING:
----------
if you have all libraries (and their corresponding developer-sources) installed, 
it should simply compile with 'make'.
'make install' as root copies the binary to /usr/local/bin
sorry - no nifty autogen, configure... yet
if you run into any troubles please let me know.

KLOPFER:
--------
there is a special non-gui version of kluppe. 
i use it for my self-built mini-itx stage computer.
it's called klopfer and you will most likely *not* need it.
in case you still want to compile it, 
you can do so with "make klopfer" and "make klopfer_install".


FEATURES:
---------
*) loading of (.wav, .aiff...) soundfiles into (memory-)buffers
*) saving / loading of settings
*) creating of empty buffers
*) playing and recording of multiple buffers via loop-players
*) playing directly from disc via "disc-streams"
*) direct (gui-) access to all loopers
*) combined- and per loop output-ports for jack
*) different playmodes including "granular"
*) uses 32bit buffers internally


USAGE:
------
after starting the program you first have to create one or more "new looper" and at least one buffer (either from file or empty).
then you can select the buffer for every looper in the "buffer" menu and start playing.
since kluppe is a jack-app it's easy to connect the output(s) to other aplications like jack-rack.

- using the waveformview:
    *) with the left moude-button you can change the play-selection in the loopview 
       (shift to keep length, ctrl to change position of the locator or "scratch" ).
    *) right mousebutton is for the rec-selection 
       (shift to keep length, ctrl to change position of the locator)
    *) middle-button is for zoom (shift for unzoom)

- the vu-meters will keep you informed about playback and recordingvolumes
- the "playmodes"-menu gives you options about the playback-modes.
  "edit custom playmode" lets you draw a speedchange-over-time-curve.
- the "N" button normalizes the whole buffer
- you will find out what the "volume"- "pan"- and "recmix"- slider do.
- also the spinbuttons for position and speed are self-explainig.

- if you set the number of grains to more than zero, you enter the granular playmode.
  see also "option" -> "grainsettings" for more

- kluppe supports a usb HID device called "contour shuttle Xpress". 
  if such a device is found at /dev/input/event[0-9] it will be automatically used.
  all you need to make it work is loading the usb hid and input kerneldrivers.
  if you need help or want to use other usb devices for "remote" controlling kluppe, let me know.

CONTRIBUTIONS:
-------------
ideas, suggestions, bugreports by: 
billy roisz, oliver stotz, michael aschauer, 
arnold haberl, klaus filip, steve harris, 
dave griffith, esben stien

CONTACT:
--------
written by dieter kovacic 
kluppe at klingt dot org
http://kluppe.klingt.org
