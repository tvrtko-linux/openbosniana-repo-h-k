// KDE4 compat header
#include "actioncollectionview.h"
