// KDE4 compat header
#include "scriptingplugin.h"
