// KDE4 compat header
#include "actioncollectionmodel.h"
