import matplotlib.backend_bases
import matplotlib.axes
class class_Figure:
    def function_set_canvas(self):
        l_canvas = matplotlib.backend_bases.FigureCanvasBase()
    def function_add_subplot(self):
        returns = matplotlib.axes.Axes()
class class_AxesStack:
    def function_get(self):
        returns = matplotlib.axes.Axes()
