# AUTO-GENERATED FILE -- DO NOT EDIT


AFMT_A_LAW = 2
AFMT_MU_LAW = 1
AFMT_S16_BE = 32
AFMT_S16_LE = 16
AFMT_S16_NE = 16
AFMT_S8 = 64
AFMT_U16_BE = 256
AFMT_U16_LE = 128
AFMT_U8 = 8
__package__ = None

class error(Exception):

  pass

def open():
  pass

