from matplotlib.backend_bases import FigureManagerBase

class class_Gcf():
    def function_get_fig_manager(self):
        l_manager = FigureManagerBase()
