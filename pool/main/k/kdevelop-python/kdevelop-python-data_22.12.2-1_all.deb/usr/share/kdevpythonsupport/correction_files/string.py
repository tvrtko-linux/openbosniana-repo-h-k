class class_Template:
    def function_safe_substitute(self):
        returns = str()
    def function_substitute(self):
        returns = str()
