# AUTO-GENERATED FILE -- DO NOT EDIT


__package__ = None

class error(Exception):

  pass

library = 'GNU gdbm'

def open(path, flag=None, mode=None):
  """ open(path[, flag[, mode]]) -> mapping
  Return a database object. """
  return None

