import _sre
def function__compile():
    returns = _sre.RegexObject()
