# This file is used to unit-test the "correction files" feature,
# and can serve as an example of the capabilities of this feature.

def function_global_func():
    returns = int()

class class_some_class():
    def function___init__(self):
        l_bar = float()

    def function_member_func1(self):
        l_baz = [3]

    def function_member_func2(self):
        returns = [float()]
