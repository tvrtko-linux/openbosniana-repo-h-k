# Example file for correcting libraries.

from matplotlib.figure import Figure
from matplotlib.backend_bases import FigureCanvasBase

class class_FigureCanvasBase():
    def function___init__(self):
        l_figure = Figure()

class class_FigureManagerBase():
    def function___init__(self):
        l_canvas = FigureCanvasBase()

class class_NavigationToolbar2:
    def function___init__(self):
        l_canvas = FigureCanvasBase()

    def function_foo(self):
        returns = [Figure()]
