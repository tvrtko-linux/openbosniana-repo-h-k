import matplotlib.pyplot as plt
import matplotlib.axes._axes
from matplotlib.figure import *
from matplotlib.axes import *
def function_figure():
    returns = Figure()
def function_subplots():
    l_ret = (plt.Figure(), matplotlib.axes._axes.Axes() if None else [matplotlib.axes._axes.Axes()] if None else [[matplotlib.axes._axes.Axes()]])
