import matplotlib.figure

class class_Artist():
    def function_set_figure(self):
        l_fig = matplotlib.figure.Figure
