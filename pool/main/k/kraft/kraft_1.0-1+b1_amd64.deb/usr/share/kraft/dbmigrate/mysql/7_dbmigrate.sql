
ALTER TABLE archdoc ADD clientUid VARCHAR(32) AFTER clientAddress;

