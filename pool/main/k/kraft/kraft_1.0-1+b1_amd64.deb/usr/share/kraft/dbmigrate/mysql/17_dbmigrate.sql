ALTER TABLE CatalogChapters ADD COLUMN parentChapter int(11) default 0;
ALTER TABLE CatalogChapters ADD COLUMN description text;

