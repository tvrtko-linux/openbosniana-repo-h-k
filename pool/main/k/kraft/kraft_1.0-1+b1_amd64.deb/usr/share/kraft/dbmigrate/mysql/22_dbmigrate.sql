

INSERT INTO taxes (fullTax, reducedTax, startDate) VALUES (16.0, 5.0, '2020-07-01');
INSERT INTO taxes (fullTax, reducedTax, startDate) VALUES (19.0, 7.0, '2021-01-01');

