
#ifndef KOPENINGHOURS_EXPORT_H
#define KOPENINGHOURS_EXPORT_H

#ifdef KOPENINGHOURS_STATIC_DEFINE
#  define KOPENINGHOURS_EXPORT
#  define KOPENINGHOURS_NO_EXPORT
#else
#  ifndef KOPENINGHOURS_EXPORT
#    ifdef KOpeningHours_EXPORTS
        /* We are building this library */
#      define KOPENINGHOURS_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KOPENINGHOURS_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KOPENINGHOURS_NO_EXPORT
#    define KOPENINGHOURS_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KOPENINGHOURS_DEPRECATED
#  define KOPENINGHOURS_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KOPENINGHOURS_DEPRECATED_EXPORT
#  define KOPENINGHOURS_DEPRECATED_EXPORT KOPENINGHOURS_EXPORT KOPENINGHOURS_DEPRECATED
#endif

#ifndef KOPENINGHOURS_DEPRECATED_NO_EXPORT
#  define KOPENINGHOURS_DEPRECATED_NO_EXPORT KOPENINGHOURS_NO_EXPORT KOPENINGHOURS_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KOPENINGHOURS_NO_DEPRECATED
#    define KOPENINGHOURS_NO_DEPRECATED
#  endif
#endif

#endif /* KOPENINGHOURS_EXPORT_H */
