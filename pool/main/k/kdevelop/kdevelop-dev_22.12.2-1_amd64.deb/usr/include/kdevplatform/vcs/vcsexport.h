
#ifndef KDEVPLATFORMVCS_EXPORT_H
#define KDEVPLATFORMVCS_EXPORT_H

#ifdef KDEVPLATFORMVCS_STATIC_DEFINE
#  define KDEVPLATFORMVCS_EXPORT
#  define KDEVPLATFORMVCS_NO_EXPORT
#else
#  ifndef KDEVPLATFORMVCS_EXPORT
#    ifdef KDevPlatformVcs_EXPORTS
        /* We are building this library */
#      define KDEVPLATFORMVCS_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KDEVPLATFORMVCS_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KDEVPLATFORMVCS_NO_EXPORT
#    define KDEVPLATFORMVCS_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KDEVPLATFORMVCS_DEPRECATED
#  define KDEVPLATFORMVCS_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KDEVPLATFORMVCS_DEPRECATED_EXPORT
#  define KDEVPLATFORMVCS_DEPRECATED_EXPORT KDEVPLATFORMVCS_EXPORT KDEVPLATFORMVCS_DEPRECATED
#endif

#ifndef KDEVPLATFORMVCS_DEPRECATED_NO_EXPORT
#  define KDEVPLATFORMVCS_DEPRECATED_NO_EXPORT KDEVPLATFORMVCS_NO_EXPORT KDEVPLATFORMVCS_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KDEVPLATFORMVCS_NO_DEPRECATED
#    define KDEVPLATFORMVCS_NO_DEPRECATED
#  endif
#endif

#endif /* KDEVPLATFORMVCS_EXPORT_H */
