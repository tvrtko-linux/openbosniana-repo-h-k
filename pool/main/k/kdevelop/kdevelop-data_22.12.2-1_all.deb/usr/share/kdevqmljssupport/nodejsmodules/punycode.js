/*
    SPDX-FileCopyrightText: 2014 Denis Steckelmacher <steckdenis@yahoo.fr>

    SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only OR LicenseRef-KDE-Accepted-GPL
*/

exports.decode = function (string) { return ""; };
exports.decode("");

exports.encode = function (string) { return ""; };
exports.encode("");

exports.toUnicode = function (domain) { return ""; };
exports.toUnicode("");

exports.toASCII = function (domain) { return ""; };
exports.toASCII("");

/*
 * exports.ucs2
 */
exports.ucs2 = {};

exports.ucs2.decode = function (string) { return ""; };
exports.ucs2.decode("");

exports.ucs2.encode = function (codePoints) { return ""; };
exports.ucs2.encode([]);


exports.version = "";

