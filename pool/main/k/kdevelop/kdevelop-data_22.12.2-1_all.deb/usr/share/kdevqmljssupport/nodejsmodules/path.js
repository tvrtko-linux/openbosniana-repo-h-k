/*
    SPDX-FileCopyrightText: 2014 Denis Steckelmacher <steckdenis@yahoo.fr>

    SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only OR LicenseRef-KDE-Accepted-GPL
*/

exports.normalize = function (p) { return ""; };
exports.normalize("");

exports.join = function (path1, path2) { return ""; };
exports.join("", "");

exports.resolve = function (path) { return ""; };
exports.resolve("");

exports.relative = function (from, to) { return ""; };
exports.relative("", "");

exports.dirname = function (p) { return ""; };
exports.dirname("");

exports.basename = function (p, ext) { return ""; };
exports.basename("", "");

exports.extname = function (p) { return ""; };
exports.extname("");

exports.sep = "";

exports.delimiter = "";

