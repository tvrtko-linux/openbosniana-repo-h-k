/*
    SPDX-FileCopyrightText: 2014 Denis Steckelmacher <steckdenis@yahoo.fr>

    SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only OR LicenseRef-KDE-Accepted-GPL
*/

exports.log = function (data) { return ; };
exports.log(_mixed);

exports.info = function (data) { return ; };
exports.info(_mixed);

exports.error = function (data) { return ; };
exports.error(_mixed);

exports.warn = function (data) { return ; };
exports.warn(_mixed);

exports.dir = function (obj) { return ; };
exports.dir(new Object());

exports.time = function (label) { return ; };
exports.time("");

exports.timeEnd = function (label) { return ; };
exports.timeEnd("");

exports.trace = function (label) { return ; };
exports.trace("");

exports.assert = function (expression, message) { return ; };
exports.assert(true, "");

