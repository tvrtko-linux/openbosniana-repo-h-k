// Forwarding header for <KHTMLPart>
#include "khtml_part.h"
