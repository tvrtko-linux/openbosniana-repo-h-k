// Forwarding header for <KHTMLSettings>
#include "khtml_settings.h"
