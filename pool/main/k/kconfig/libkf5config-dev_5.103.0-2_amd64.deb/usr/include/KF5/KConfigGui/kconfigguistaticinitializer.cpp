// SPDX-FileCopyrightText: 2022 Alexander Lohnau <alexander.lohnau@gmx.de>
// SPDX-License-Identifier: LGPL-2.1-only OR LGPL-3.0-only OR LicenseRef-KDE-Accepted-LGPL

extern int initKConfigGroupGui();

static int myInit = initKConfigGroupGui();
