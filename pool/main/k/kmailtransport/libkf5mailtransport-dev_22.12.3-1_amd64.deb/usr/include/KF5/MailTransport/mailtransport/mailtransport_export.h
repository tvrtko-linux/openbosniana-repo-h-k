
#ifndef MAILTRANSPORT_EXPORT_H
#define MAILTRANSPORT_EXPORT_H

#ifdef MAILTRANSPORT_STATIC_DEFINE
#  define MAILTRANSPORT_EXPORT
#  define MAILTRANSPORT_NO_EXPORT
#else
#  ifndef MAILTRANSPORT_EXPORT
#    ifdef KF5MailTransport_EXPORTS
        /* We are building this library */
#      define MAILTRANSPORT_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define MAILTRANSPORT_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef MAILTRANSPORT_NO_EXPORT
#    define MAILTRANSPORT_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef MAILTRANSPORT_DEPRECATED
#  define MAILTRANSPORT_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef MAILTRANSPORT_DEPRECATED_EXPORT
#  define MAILTRANSPORT_DEPRECATED_EXPORT MAILTRANSPORT_EXPORT MAILTRANSPORT_DEPRECATED
#endif

#ifndef MAILTRANSPORT_DEPRECATED_NO_EXPORT
#  define MAILTRANSPORT_DEPRECATED_NO_EXPORT MAILTRANSPORT_NO_EXPORT MAILTRANSPORT_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef MAILTRANSPORT_NO_DEPRECATED
#    define MAILTRANSPORT_NO_DEPRECATED
#  endif
#endif

#endif /* MAILTRANSPORT_EXPORT_H */
