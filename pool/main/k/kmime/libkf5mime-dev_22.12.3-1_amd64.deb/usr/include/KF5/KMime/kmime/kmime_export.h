
#ifndef KMIME_EXPORT_H
#define KMIME_EXPORT_H

#ifdef KMIME_STATIC_DEFINE
#  define KMIME_EXPORT
#  define KMIME_NO_EXPORT
#else
#  ifndef KMIME_EXPORT
#    ifdef KF5Mime_EXPORTS
        /* We are building this library */
#      define KMIME_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KMIME_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KMIME_NO_EXPORT
#    define KMIME_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KMIME_DEPRECATED
#  define KMIME_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KMIME_DEPRECATED_EXPORT
#  define KMIME_DEPRECATED_EXPORT KMIME_EXPORT KMIME_DEPRECATED
#endif

#ifndef KMIME_DEPRECATED_NO_EXPORT
#  define KMIME_DEPRECATED_NO_EXPORT KMIME_NO_EXPORT KMIME_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KMIME_NO_DEPRECATED
#    define KMIME_NO_DEPRECATED
#  endif
#endif

#endif /* KMIME_EXPORT_H */
