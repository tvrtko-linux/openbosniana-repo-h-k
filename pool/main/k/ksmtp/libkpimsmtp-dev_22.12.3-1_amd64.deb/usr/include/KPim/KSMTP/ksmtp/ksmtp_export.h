
#ifndef KSMTP_EXPORT_H
#define KSMTP_EXPORT_H

#ifdef KSMTP_STATIC_DEFINE
#  define KSMTP_EXPORT
#  define KSMTP_NO_EXPORT
#else
#  ifndef KSMTP_EXPORT
#    ifdef KPimSMTP_EXPORTS
        /* We are building this library */
#      define KSMTP_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KSMTP_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KSMTP_NO_EXPORT
#    define KSMTP_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KSMTP_DEPRECATED
#  define KSMTP_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KSMTP_DEPRECATED_EXPORT
#  define KSMTP_DEPRECATED_EXPORT KSMTP_EXPORT KSMTP_DEPRECATED
#endif

#ifndef KSMTP_DEPRECATED_NO_EXPORT
#  define KSMTP_DEPRECATED_NO_EXPORT KSMTP_NO_EXPORT KSMTP_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KSMTP_NO_DEPRECATED
#    define KSMTP_NO_DEPRECATED
#  endif
#endif

#endif /* KSMTP_EXPORT_H */
