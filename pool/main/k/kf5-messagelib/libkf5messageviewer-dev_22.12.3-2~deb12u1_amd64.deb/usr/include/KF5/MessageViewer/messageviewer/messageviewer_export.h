
#ifndef MESSAGEVIEWER_EXPORT_H
#define MESSAGEVIEWER_EXPORT_H

#ifdef MESSAGEVIEWER_STATIC_DEFINE
#  define MESSAGEVIEWER_EXPORT
#  define MESSAGEVIEWER_NO_EXPORT
#else
#  ifndef MESSAGEVIEWER_EXPORT
#    ifdef KF5MessageViewer_EXPORTS
        /* We are building this library */
#      define MESSAGEVIEWER_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define MESSAGEVIEWER_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef MESSAGEVIEWER_NO_EXPORT
#    define MESSAGEVIEWER_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef MESSAGEVIEWER_DEPRECATED
#  define MESSAGEVIEWER_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef MESSAGEVIEWER_DEPRECATED_EXPORT
#  define MESSAGEVIEWER_DEPRECATED_EXPORT MESSAGEVIEWER_EXPORT MESSAGEVIEWER_DEPRECATED
#endif

#ifndef MESSAGEVIEWER_DEPRECATED_NO_EXPORT
#  define MESSAGEVIEWER_DEPRECATED_NO_EXPORT MESSAGEVIEWER_NO_EXPORT MESSAGEVIEWER_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef MESSAGEVIEWER_NO_DEPRECATED
#    define MESSAGEVIEWER_NO_DEPRECATED
#  endif
#endif

#endif /* MESSAGEVIEWER_EXPORT_H */
