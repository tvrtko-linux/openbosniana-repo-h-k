
#ifndef MIMETREEPARSER_EXPORT_H
#define MIMETREEPARSER_EXPORT_H

#ifdef MIMETREEPARSER_STATIC_DEFINE
#  define MIMETREEPARSER_EXPORT
#  define MIMETREEPARSER_NO_EXPORT
#else
#  ifndef MIMETREEPARSER_EXPORT
#    ifdef KF5MimeTreeParser_EXPORTS
        /* We are building this library */
#      define MIMETREEPARSER_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define MIMETREEPARSER_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef MIMETREEPARSER_NO_EXPORT
#    define MIMETREEPARSER_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef MIMETREEPARSER_DEPRECATED
#  define MIMETREEPARSER_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef MIMETREEPARSER_DEPRECATED_EXPORT
#  define MIMETREEPARSER_DEPRECATED_EXPORT MIMETREEPARSER_EXPORT MIMETREEPARSER_DEPRECATED
#endif

#ifndef MIMETREEPARSER_DEPRECATED_NO_EXPORT
#  define MIMETREEPARSER_DEPRECATED_NO_EXPORT MIMETREEPARSER_NO_EXPORT MIMETREEPARSER_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef MIMETREEPARSER_NO_DEPRECATED
#    define MIMETREEPARSER_NO_DEPRECATED
#  endif
#endif

#endif /* MIMETREEPARSER_EXPORT_H */
