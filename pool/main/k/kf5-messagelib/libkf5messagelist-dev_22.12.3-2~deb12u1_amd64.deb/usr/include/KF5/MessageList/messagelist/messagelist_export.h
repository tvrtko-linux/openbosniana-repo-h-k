
#ifndef MESSAGELIST_EXPORT_H
#define MESSAGELIST_EXPORT_H

#ifdef MESSAGELIST_STATIC_DEFINE
#  define MESSAGELIST_EXPORT
#  define MESSAGELIST_NO_EXPORT
#else
#  ifndef MESSAGELIST_EXPORT
#    ifdef KF5MessageList_EXPORTS
        /* We are building this library */
#      define MESSAGELIST_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define MESSAGELIST_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef MESSAGELIST_NO_EXPORT
#    define MESSAGELIST_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef MESSAGELIST_DEPRECATED
#  define MESSAGELIST_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef MESSAGELIST_DEPRECATED_EXPORT
#  define MESSAGELIST_DEPRECATED_EXPORT MESSAGELIST_EXPORT MESSAGELIST_DEPRECATED
#endif

#ifndef MESSAGELIST_DEPRECATED_NO_EXPORT
#  define MESSAGELIST_DEPRECATED_NO_EXPORT MESSAGELIST_NO_EXPORT MESSAGELIST_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef MESSAGELIST_NO_DEPRECATED
#    define MESSAGELIST_NO_DEPRECATED
#  endif
#endif

#endif /* MESSAGELIST_EXPORT_H */
