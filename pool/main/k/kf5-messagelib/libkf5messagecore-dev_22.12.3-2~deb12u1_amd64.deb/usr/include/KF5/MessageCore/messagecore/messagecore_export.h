
#ifndef MESSAGECORE_EXPORT_H
#define MESSAGECORE_EXPORT_H

#ifdef MESSAGECORE_STATIC_DEFINE
#  define MESSAGECORE_EXPORT
#  define MESSAGECORE_NO_EXPORT
#else
#  ifndef MESSAGECORE_EXPORT
#    ifdef KF5MessageCore_EXPORTS
        /* We are building this library */
#      define MESSAGECORE_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define MESSAGECORE_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef MESSAGECORE_NO_EXPORT
#    define MESSAGECORE_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef MESSAGECORE_DEPRECATED
#  define MESSAGECORE_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef MESSAGECORE_DEPRECATED_EXPORT
#  define MESSAGECORE_DEPRECATED_EXPORT MESSAGECORE_EXPORT MESSAGECORE_DEPRECATED
#endif

#ifndef MESSAGECORE_DEPRECATED_NO_EXPORT
#  define MESSAGECORE_DEPRECATED_NO_EXPORT MESSAGECORE_NO_EXPORT MESSAGECORE_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef MESSAGECORE_NO_DEPRECATED
#    define MESSAGECORE_NO_DEPRECATED
#  endif
#endif

#endif /* MESSAGECORE_EXPORT_H */
