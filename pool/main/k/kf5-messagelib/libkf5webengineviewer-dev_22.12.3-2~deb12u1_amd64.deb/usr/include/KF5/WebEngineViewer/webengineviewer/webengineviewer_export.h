
#ifndef WEBENGINEVIEWER_EXPORT_H
#define WEBENGINEVIEWER_EXPORT_H

#ifdef WEBENGINEVIEWER_STATIC_DEFINE
#  define WEBENGINEVIEWER_EXPORT
#  define WEBENGINEVIEWER_NO_EXPORT
#else
#  ifndef WEBENGINEVIEWER_EXPORT
#    ifdef KF5WebEngineViewer_EXPORTS
        /* We are building this library */
#      define WEBENGINEVIEWER_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define WEBENGINEVIEWER_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef WEBENGINEVIEWER_NO_EXPORT
#    define WEBENGINEVIEWER_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef WEBENGINEVIEWER_DEPRECATED
#  define WEBENGINEVIEWER_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef WEBENGINEVIEWER_DEPRECATED_EXPORT
#  define WEBENGINEVIEWER_DEPRECATED_EXPORT WEBENGINEVIEWER_EXPORT WEBENGINEVIEWER_DEPRECATED
#endif

#ifndef WEBENGINEVIEWER_DEPRECATED_NO_EXPORT
#  define WEBENGINEVIEWER_DEPRECATED_NO_EXPORT WEBENGINEVIEWER_NO_EXPORT WEBENGINEVIEWER_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef WEBENGINEVIEWER_NO_DEPRECATED
#    define WEBENGINEVIEWER_NO_DEPRECATED
#  endif
#endif

#endif /* WEBENGINEVIEWER_EXPORT_H */
