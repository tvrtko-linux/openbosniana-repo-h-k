#include <klocalizedstring.h>

/********************************************************************************
** Form generated from reading UI file 'templatesconfiguration_base.ui'
**
** Created by: Qt User Interface Compiler version 5.15.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TEMPLATESCONFIGURATION_BASE_H
#define UI_TEMPLATESCONFIGURATION_BASE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QToolBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "templatesinsertcommandpushbutton.h"
#include "templatestextedit.h"

QT_BEGIN_NAMESPACE

class Ui_TemplatesConfigurationBase
{
public:
    QVBoxLayout *vboxLayout;
    QToolBox *toolBox1;
    QWidget *page_new;
    QGridLayout *gridLayout;
    TemplateParser::TemplatesTextEdit *textEdit_new;
    QWidget *page_reply;
    QHBoxLayout *hboxLayout;
    TemplateParser::TemplatesTextEdit *textEdit_reply;
    QWidget *page_reply_all;
    QHBoxLayout *hboxLayout1;
    TemplateParser::TemplatesTextEdit *textEdit_reply_all;
    QWidget *page_forward;
    QHBoxLayout *hboxLayout2;
    TemplateParser::TemplatesTextEdit *textEdit_forward;
    QLabel *mHelp;
    QHBoxLayout *hboxLayout3;
    TemplateParser::TemplatesInsertCommandPushButton *mInsertCommand;
    QLabel *textLabel1;
    QLineEdit *lineEdit_quote;

    void setupUi(QWidget *TemplatesConfigurationBase)
    {
        if (TemplatesConfigurationBase->objectName().isEmpty())
            TemplatesConfigurationBase->setObjectName(QString::fromUtf8("TemplatesConfigurationBase"));
        TemplatesConfigurationBase->resize(450, 541);
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(3);
        sizePolicy.setVerticalStretch(3);
        sizePolicy.setHeightForWidth(TemplatesConfigurationBase->sizePolicy().hasHeightForWidth());
        TemplatesConfigurationBase->setSizePolicy(sizePolicy);
        TemplatesConfigurationBase->setMinimumSize(QSize(400, 300));
        vboxLayout = new QVBoxLayout(TemplatesConfigurationBase);
        vboxLayout->setSpacing(6);
        vboxLayout->setObjectName(QString::fromUtf8("vboxLayout"));
        vboxLayout->setContentsMargins(0, 0, 0, 0);
        toolBox1 = new QToolBox(TemplatesConfigurationBase);
        toolBox1->setObjectName(QString::fromUtf8("toolBox1"));
        sizePolicy.setHeightForWidth(toolBox1->sizePolicy().hasHeightForWidth());
        toolBox1->setSizePolicy(sizePolicy);
        toolBox1->setMinimumSize(QSize(0, 0));
        toolBox1->setFrameShape(QFrame::StyledPanel);
        toolBox1->setFrameShadow(QFrame::Sunken);
        page_new = new QWidget();
        page_new->setObjectName(QString::fromUtf8("page_new"));
        page_new->setGeometry(QRect(0, 0, 96, 86));
        gridLayout = new QGridLayout(page_new);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        textEdit_new = new TemplateParser::TemplatesTextEdit(page_new);
        textEdit_new->setObjectName(QString::fromUtf8("textEdit_new"));
        QFont font;
        font.setFamily(QString::fromUtf8("Monospace"));
        font.setPointSize(9);
        textEdit_new->setFont(font);

        gridLayout->addWidget(textEdit_new, 0, 0, 1, 1);

        toolBox1->addItem(page_new, QString::fromUtf8("New Message"));
        page_reply = new QWidget();
        page_reply->setObjectName(QString::fromUtf8("page_reply"));
        page_reply->setGeometry(QRect(0, 0, 256, 192));
        hboxLayout = new QHBoxLayout(page_reply);
        hboxLayout->setSpacing(6);
        hboxLayout->setObjectName(QString::fromUtf8("hboxLayout"));
        hboxLayout->setContentsMargins(0, 0, 0, 0);
        textEdit_reply = new TemplateParser::TemplatesTextEdit(page_reply);
        textEdit_reply->setObjectName(QString::fromUtf8("textEdit_reply"));
        QSizePolicy sizePolicy1(QSizePolicy::MinimumExpanding, QSizePolicy::MinimumExpanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(textEdit_reply->sizePolicy().hasHeightForWidth());
        textEdit_reply->setSizePolicy(sizePolicy1);
        QFont font1;
        font1.setFamily(QString::fromUtf8("Monospace"));
        font1.setPointSize(9);
        font1.setBold(false);
        font1.setItalic(false);
        font1.setUnderline(false);
        font1.setWeight(50);
        font1.setStrikeOut(false);
        textEdit_reply->setFont(font1);

        hboxLayout->addWidget(textEdit_reply);

        toolBox1->addItem(page_reply, QString::fromUtf8("Reply to Sender"));
        page_reply_all = new QWidget();
        page_reply_all->setObjectName(QString::fromUtf8("page_reply_all"));
        page_reply_all->setGeometry(QRect(0, 0, 446, 345));
        hboxLayout1 = new QHBoxLayout(page_reply_all);
        hboxLayout1->setSpacing(6);
        hboxLayout1->setObjectName(QString::fromUtf8("hboxLayout1"));
        hboxLayout1->setContentsMargins(0, 0, 0, 0);
        textEdit_reply_all = new TemplateParser::TemplatesTextEdit(page_reply_all);
        textEdit_reply_all->setObjectName(QString::fromUtf8("textEdit_reply_all"));
        sizePolicy1.setHeightForWidth(textEdit_reply_all->sizePolicy().hasHeightForWidth());
        textEdit_reply_all->setSizePolicy(sizePolicy1);
        textEdit_reply_all->setFont(font1);

        hboxLayout1->addWidget(textEdit_reply_all);

        toolBox1->addItem(page_reply_all, QString::fromUtf8("Reply to All / Reply to List"));
        page_forward = new QWidget();
        page_forward->setObjectName(QString::fromUtf8("page_forward"));
        page_forward->setGeometry(QRect(0, 0, 256, 192));
        hboxLayout2 = new QHBoxLayout(page_forward);
        hboxLayout2->setSpacing(6);
        hboxLayout2->setObjectName(QString::fromUtf8("hboxLayout2"));
        hboxLayout2->setContentsMargins(0, 0, 0, 0);
        textEdit_forward = new TemplateParser::TemplatesTextEdit(page_forward);
        textEdit_forward->setObjectName(QString::fromUtf8("textEdit_forward"));
        sizePolicy1.setHeightForWidth(textEdit_forward->sizePolicy().hasHeightForWidth());
        textEdit_forward->setSizePolicy(sizePolicy1);
        textEdit_forward->setFont(font1);

        hboxLayout2->addWidget(textEdit_forward);

        toolBox1->addItem(page_forward, QString::fromUtf8("Forward Message"));

        vboxLayout->addWidget(toolBox1);

        mHelp = new QLabel(TemplatesConfigurationBase);
        mHelp->setObjectName(QString::fromUtf8("mHelp"));

        vboxLayout->addWidget(mHelp);

        hboxLayout3 = new QHBoxLayout();
        hboxLayout3->setSpacing(6);
        hboxLayout3->setObjectName(QString::fromUtf8("hboxLayout3"));
        hboxLayout3->setContentsMargins(0, 0, 0, 0);
        mInsertCommand = new TemplateParser::TemplatesInsertCommandPushButton(TemplatesConfigurationBase);
        mInsertCommand->setObjectName(QString::fromUtf8("mInsertCommand"));

        hboxLayout3->addWidget(mInsertCommand);

        textLabel1 = new QLabel(TemplatesConfigurationBase);
        textLabel1->setObjectName(QString::fromUtf8("textLabel1"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy2.setHorizontalStretch(2);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(textLabel1->sizePolicy().hasHeightForWidth());
        textLabel1->setSizePolicy(sizePolicy2);
        textLabel1->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        hboxLayout3->addWidget(textLabel1);

        lineEdit_quote = new QLineEdit(TemplatesConfigurationBase);
        lineEdit_quote->setObjectName(QString::fromUtf8("lineEdit_quote"));

        hboxLayout3->addWidget(lineEdit_quote);


        vboxLayout->addLayout(hboxLayout3);

#if QT_CONFIG(shortcut)
        textLabel1->setBuddy(lineEdit_quote);
#endif // QT_CONFIG(shortcut)

        retranslateUi(TemplatesConfigurationBase);

        toolBox1->setCurrentIndex(2);


        QMetaObject::connectSlotsByName(TemplatesConfigurationBase);
    } // setupUi

    void retranslateUi(QWidget *TemplatesConfigurationBase)
    {
        TemplatesConfigurationBase->setWindowTitle(tr2i18n("Template Configuration", "@title:window"));
#if QT_CONFIG(tooltip)
        textEdit_new->setToolTip(tr2i18n("Create the template for new messages", "@info:tooltip"));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        textEdit_new->setWhatsThis(tr2i18n("In this area you create the template for new email messages.  For more information about how to create the template, press the \"How does this work?\" link on this dialog.", "@info:whatsthis"));
#endif // QT_CONFIG(whatsthis)
        toolBox1->setItemText(toolBox1->indexOf(page_new), tr2i18n("New Message", "@title Message template"));
#if QT_CONFIG(tooltip)
        textEdit_reply->setToolTip(tr2i18n("Create the template for message replies", "@info:tooltip"));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        textEdit_reply->setWhatsThis(tr2i18n("In this area you create the template for messages replies. For more information about how to create the template, press the \"How does this work?\" link on this dialog.", "@info:whatsthis"));
#endif // QT_CONFIG(whatsthis)
        toolBox1->setItemText(toolBox1->indexOf(page_reply), tr2i18n("Reply to Sender", "@title Message template"));
#if QT_CONFIG(tooltip)
        textEdit_reply_all->setToolTip(tr2i18n("Create the template for replying to all recipients or to a mailing list", "@info:tooltip"));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        textEdit_reply_all->setWhatsThis(tr2i18n("In this area you create the template for reply-to-all messages or replies to a mailing list.  For more information about how to create the template, press the \"How does this work?\" link on this dialog.", "@info:whatsthis"));
#endif // QT_CONFIG(whatsthis)
        toolBox1->setItemText(toolBox1->indexOf(page_reply_all), tr2i18n("Reply to All / Reply to List", "@title Message template"));
#if QT_CONFIG(tooltip)
        textEdit_forward->setToolTip(tr2i18n("Create the template for message forwards", "@info:tooltip"));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        textEdit_forward->setWhatsThis(tr2i18n("In this area you create the template for message forwards.  For more information about how to create the template, press the \"How does this work?\" link on this dialog.", "@info:whatsthis"));
#endif // QT_CONFIG(whatsthis)
        toolBox1->setItemText(toolBox1->indexOf(page_forward), tr2i18n("Forward Message", "@title Message template"));
        textLabel1->setText(tr2i18n("&Quote indicator:", "@label:textbox Prefix for quoted message lines"));
#if QT_CONFIG(tooltip)
        lineEdit_quote->setToolTip(tr2i18n("Set the Prefix for quoted message lines", "@info:tooltip"));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(whatsthis)
        lineEdit_quote->setWhatsThis(tr2i18n("\n"
"             <qt>The following placeholders are supported in the quote indicator:\n"
"             <ul>\n"
"             <li>%f: sender's initials</li>\n"
"             <li>%%: percent sign</li>\n"
"             <li>%_: space</li>\n"
"             </ul></qt>\n"
"           ", "@info:whatsthis"));
#endif // QT_CONFIG(whatsthis)
    } // retranslateUi

};

namespace Ui {
    class TemplatesConfigurationBase: public Ui_TemplatesConfigurationBase {};
} // namespace Ui

QT_END_NAMESPACE

#endif // TEMPLATESCONFIGURATION_BASE_H

