
#ifndef TEMPLATEPARSER_EXPORT_H
#define TEMPLATEPARSER_EXPORT_H

#ifdef TEMPLATEPARSER_STATIC_DEFINE
#  define TEMPLATEPARSER_EXPORT
#  define TEMPLATEPARSER_NO_EXPORT
#else
#  ifndef TEMPLATEPARSER_EXPORT
#    ifdef KF5TemplateParser_EXPORTS
        /* We are building this library */
#      define TEMPLATEPARSER_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define TEMPLATEPARSER_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef TEMPLATEPARSER_NO_EXPORT
#    define TEMPLATEPARSER_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef TEMPLATEPARSER_DEPRECATED
#  define TEMPLATEPARSER_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef TEMPLATEPARSER_DEPRECATED_EXPORT
#  define TEMPLATEPARSER_DEPRECATED_EXPORT TEMPLATEPARSER_EXPORT TEMPLATEPARSER_DEPRECATED
#endif

#ifndef TEMPLATEPARSER_DEPRECATED_NO_EXPORT
#  define TEMPLATEPARSER_DEPRECATED_NO_EXPORT TEMPLATEPARSER_NO_EXPORT TEMPLATEPARSER_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef TEMPLATEPARSER_NO_DEPRECATED
#    define TEMPLATEPARSER_NO_DEPRECATED
#  endif
#endif

#endif /* TEMPLATEPARSER_EXPORT_H */
