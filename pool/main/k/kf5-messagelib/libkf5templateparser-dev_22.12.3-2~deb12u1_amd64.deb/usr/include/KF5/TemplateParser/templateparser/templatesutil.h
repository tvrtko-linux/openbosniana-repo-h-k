/*
  SPDX-FileCopyrightText: 2011-2022 Laurent Montel <montel@kde.org>

  SPDX-License-Identifier: GPL-2.0-or-later
*/

#pragma once

#include "templateparser_export.h"
#include <QString>

namespace TemplateParser
{
namespace Util
{
TEMPLATEPARSER_EXPORT void deleteTemplate(const QString &id);
Q_REQUIRED_RESULT TEMPLATEPARSER_EXPORT QString getLastNameFromEmail(const QString &str);
Q_REQUIRED_RESULT TEMPLATEPARSER_EXPORT QString getFirstNameFromEmail(const QString &str);
}
}
