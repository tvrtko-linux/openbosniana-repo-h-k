
#ifndef MESSAGECOMPOSER_EXPORT_H
#define MESSAGECOMPOSER_EXPORT_H

#ifdef MESSAGECOMPOSER_STATIC_DEFINE
#  define MESSAGECOMPOSER_EXPORT
#  define MESSAGECOMPOSER_NO_EXPORT
#else
#  ifndef MESSAGECOMPOSER_EXPORT
#    ifdef KF5MessageComposer_EXPORTS
        /* We are building this library */
#      define MESSAGECOMPOSER_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define MESSAGECOMPOSER_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef MESSAGECOMPOSER_NO_EXPORT
#    define MESSAGECOMPOSER_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef MESSAGECOMPOSER_DEPRECATED
#  define MESSAGECOMPOSER_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef MESSAGECOMPOSER_DEPRECATED_EXPORT
#  define MESSAGECOMPOSER_DEPRECATED_EXPORT MESSAGECOMPOSER_EXPORT MESSAGECOMPOSER_DEPRECATED
#endif

#ifndef MESSAGECOMPOSER_DEPRECATED_NO_EXPORT
#  define MESSAGECOMPOSER_DEPRECATED_NO_EXPORT MESSAGECOMPOSER_NO_EXPORT MESSAGECOMPOSER_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef MESSAGECOMPOSER_NO_DEPRECATED
#    define MESSAGECOMPOSER_NO_DEPRECATED
#  endif
#endif

#endif /* MESSAGECOMPOSER_EXPORT_H */
