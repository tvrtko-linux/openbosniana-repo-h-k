<p align="center"><img src="https://github.com/katholt/Kaptive/blob/master/extras/kaptive_logo.png" alt="Kaptive" width="400"></p>


Kaptive reports information about surface polysaccharide loci for _Klebsiella pneumoniae_ species complex and _Acinetobacter baumannii_ genome assemblies. You can also run a graphical version of Kaptive via [this web interface](http://kaptive.holtlab.net/) ([source code](https://github.com/kelwyres/Kaptive-Web)).

**For information on how to install, run, interpret and cite Kaptive please visit the [Wiki](https://github.com/katholt/Kaptive/wiki).**
