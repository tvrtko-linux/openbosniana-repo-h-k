# coding: utf-8
version = "0.10.5"
version_tuple = (0, 10, 5)
