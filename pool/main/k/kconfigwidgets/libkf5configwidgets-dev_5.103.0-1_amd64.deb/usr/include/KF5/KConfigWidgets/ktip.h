/*
    SPDX-FileCopyrightText: 2000-2003 Matthias Hoelzer-Kluepfel <mhk@kde.org>
    SPDX-FileCopyrightText: 2000-2003 Tobias Koenig <tokoe@kde.org>
    SPDX-FileCopyrightText: 2000-2003 Daniel Molkentin <molkentin@kde.org>

    SPDX-License-Identifier: MIT
*/

// ktip.h only exists for kde4 compatibility reasons

#include "ktipdialog.h"
