
#ifndef KCALUTILS_EXPORT_H
#define KCALUTILS_EXPORT_H

#ifdef KCALUTILS_STATIC_DEFINE
#  define KCALUTILS_EXPORT
#  define KCALUTILS_NO_EXPORT
#else
#  ifndef KCALUTILS_EXPORT
#    ifdef KF5CalendarUtils_EXPORTS
        /* We are building this library */
#      define KCALUTILS_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KCALUTILS_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KCALUTILS_NO_EXPORT
#    define KCALUTILS_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KCALUTILS_DEPRECATED
#  define KCALUTILS_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KCALUTILS_DEPRECATED_EXPORT
#  define KCALUTILS_DEPRECATED_EXPORT KCALUTILS_EXPORT KCALUTILS_DEPRECATED
#endif

#ifndef KCALUTILS_DEPRECATED_NO_EXPORT
#  define KCALUTILS_DEPRECATED_NO_EXPORT KCALUTILS_NO_EXPORT KCALUTILS_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KCALUTILS_NO_DEPRECATED
#    define KCALUTILS_NO_DEPRECATED
#  endif
#endif

#endif /* KCALUTILS_EXPORT_H */
