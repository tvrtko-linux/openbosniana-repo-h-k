
#ifndef KLDAP_EXPORT_H
#define KLDAP_EXPORT_H

#ifdef KLDAP_STATIC_DEFINE
#  define KLDAP_EXPORT
#  define KLDAP_NO_EXPORT
#else
#  ifndef KLDAP_EXPORT
#    ifdef KF5Ldap_EXPORTS
        /* We are building this library */
#      define KLDAP_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KLDAP_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KLDAP_NO_EXPORT
#    define KLDAP_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KLDAP_DEPRECATED
#  define KLDAP_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KLDAP_DEPRECATED_EXPORT
#  define KLDAP_DEPRECATED_EXPORT KLDAP_EXPORT KLDAP_DEPRECATED
#endif

#ifndef KLDAP_DEPRECATED_NO_EXPORT
#  define KLDAP_DEPRECATED_NO_EXPORT KLDAP_NO_EXPORT KLDAP_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KLDAP_NO_DEPRECATED
#    define KLDAP_NO_DEPRECATED
#  endif
#endif

#endif /* KLDAP_EXPORT_H */
