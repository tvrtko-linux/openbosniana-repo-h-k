<?php

namespace Kanboard\Core\Controller;

/**
 * Class PageNotFoundException
 *
 * @package Kanboard\Core\Controller
 * @author  Frederic Guillot
 */
class PageNotFoundException extends BaseException
{

}
