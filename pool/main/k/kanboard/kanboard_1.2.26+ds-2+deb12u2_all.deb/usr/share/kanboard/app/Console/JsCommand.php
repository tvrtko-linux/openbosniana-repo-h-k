<?php

namespace Kanboard\Console;

use MatthiasMullie\Minify;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Class JsCommand
 *
 * @package Kanboard\Console
 * @author  Frederic Guillot
 */
class JsCommand extends BaseCommand
{
    const CSS_DIST_PATH = 'assets/js/';

    private $appFiles = [
        '/usr/share/nodejs/textarea-caret/index.js',
        'assets/js/polyfills/*.js',
        'assets/js/core/base.js',
        'assets/js/core/dom.js',
        'assets/js/core/html.js',
        'assets/js/core/http.js',
        'assets/js/core/modal.js',
        'assets/js/core/tooltip.js',
        'assets/js/core/utils.js',
        'assets/js/components/*.js',
        'assets/js/core/bootstrap.js',
        'assets/js/src/Namespace.js',
        'assets/js/src/App.js',
        'assets/js/src/BoardCollapsedMode.js',
        'assets/js/src/BoardColumnView.js',
        'assets/js/src/BoardHorizontalScrolling.js',
        'assets/js/src/BoardPolling.js',
        'assets/js/src/BoardVerticalScrolling.js',
        'assets/js/src/Column.js',
        'assets/js/src/Dropdown.js',
        'assets/js/src/Search.js',
        'assets/js/src/Swimlane.js',
        'assets/js/src/Task.js',
        'assets/js/src/BoardDragAndDrop.js',
        'assets/js/src/Bootstrap.js'
    ];

    private $vendorFiles = [
        '/usr/share/javascript/jquery/jquery.min.js',
        '/usr/share/javascript/jquery-ui/jquery-ui.min.js',
        '/usr/share/javascript/jquery-ui/ui/i18n/datepicker-*.min.js',
        '/usr/share/javascript/jquery-timepicker/jquery-ui-timepicker-addon.min.js',
        '/usr/share/doc/libjs-jquery-timepicker/html/jquery-ui-timepicker-addon-i18n.min.js',
        '/usr/share/javascript/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js',
        '/usr/share/javascript/select2.js/select2.min.js',
        '/usr/share/javascript/select2.js/i18n/*.js',
        '/usr/share/javascript/d3/d3.min.js',
        '/usr/share/javascript/c3/c3.min.js',
        '/usr/share/javascript/ismobilejs/isMobile.min.js',
    ];

    protected function configure()
    {
        $this
            ->setName('js')
            ->setDescription('Minify Javascript files')
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $appBundle = concat_files($this->appFiles);
        $vendorBundle = concat_files($this->vendorFiles);

        $minifier = new Minify\JS($appBundle);

        file_put_contents('assets/js/app.min.js', $minifier->minify());
        file_put_contents('assets/js/vendor.min.js', $vendorBundle);
        return 0;
    }
}
