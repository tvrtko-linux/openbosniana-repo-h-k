var classcl_1_1_device =
[
    [ "Device", "classcl_1_1_device.html#a6131ff3eb77c31dfba11091a3c0f4235", null ],
    [ "Device", "classcl_1_1_device.html#ad28b573c8a28028a06ded4e1dc7fa725", null ],
    [ "Device", "classcl_1_1_device.html#a8445328fa0af11c93f20615f820b93fc", null ],
    [ "Device", "classcl_1_1_device.html#a9a8f38bb1636628bdb31d3a47c8cee36", null ],
    [ "createSubDevices", "classcl_1_1_device.html#ab60bfd190bf8f82cb8f0adb0a869a2f2", null ],
    [ "getDeviceAndHostTimer", "classcl_1_1_device.html#aaff2a95751ef5b9fb3e2604f9f31f837", null ],
    [ "getHostTimer", "classcl_1_1_device.html#a61b9be541cdcbfd9d4d9f5b0a946a9ed", null ],
    [ "getInfo", "classcl_1_1_device.html#a575493c25049dae087540ed8a65efd6d", null ],
    [ "getInfo", "classcl_1_1_device.html#a80887bb6e52b92225dca31fdad796ffa", null ],
    [ "operator=", "classcl_1_1_device.html#a24478e608183c70319367afec954e779", null ],
    [ "operator=", "classcl_1_1_device.html#a1f39426d96c76588310d3edd77fa17e1", null ],
    [ "operator=", "classcl_1_1_device.html#afabf34d38e5a7db85f17ae34ef675c74", null ]
];