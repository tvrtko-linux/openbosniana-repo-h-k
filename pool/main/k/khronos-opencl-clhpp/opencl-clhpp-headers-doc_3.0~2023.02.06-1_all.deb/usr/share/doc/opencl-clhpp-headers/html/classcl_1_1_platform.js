var classcl_1_1_platform =
[
    [ "Platform", "classcl_1_1_platform.html#a616344e02c3723347c752c02b7015212", null ],
    [ "Platform", "classcl_1_1_platform.html#a339232a64068fe7157e124b82fb4b9fa", null ],
    [ "getDevices", "classcl_1_1_platform.html#a73cf4b02df3beafae1a97a91ee3e9565", null ],
    [ "getInfo", "classcl_1_1_platform.html#a436c09964ac6314a3763f5c15fb92e7d", null ],
    [ "getInfo", "classcl_1_1_platform.html#af19b9194c46f545ffe62950f6e7cf377", null ],
    [ "operator=", "classcl_1_1_platform.html#aeaee2d9f15f2927c4a0467cc734a29a3", null ],
    [ "unloadCompiler", "classcl_1_1_platform.html#a70313ea76e0e369c4dc951a7f47b531f", null ]
];