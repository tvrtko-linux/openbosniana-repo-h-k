var searchData=
[
  ['ndrange_0',['NDRange',['../classcl_1_1_n_d_range.html',1,'cl::NDRange'],['../classcl_1_1_n_d_range.html#ad7121613ed829d6a21f4866e96b84217',1,'cl::NDRange::NDRange()'],['../classcl_1_1_n_d_range.html#aecea642547cae272e0b108a3049afeeb',1,'cl::NDRange::NDRange(size_type size0)'],['../classcl_1_1_n_d_range.html#a6562c4ffea059267582aa22bc96d7435',1,'cl::NDRange::NDRange(size_type size0, size_type size1)'],['../classcl_1_1_n_d_range.html#a8fd331a55e1c4871e8ffa3a35b95e538',1,'cl::NDRange::NDRange(size_type size0, size_type size1, size_type size2)']]]
];
