var searchData=
[
  ['rebind_0',['rebind',['../structcl_1_1_s_v_m_allocator_1_1rebind.html',1,'cl::SVMAllocator&lt; T, SVMTrait &gt;::rebind&lt; U &gt;'],['../structcl_1_1_s_v_m_allocator_3_01void_00_01_s_v_m_trait_01_4_1_1rebind.html',1,'cl::SVMAllocator&lt; void, SVMTrait &gt;::rebind&lt; U &gt;']]],
  ['referencehandler_1',['ReferenceHandler',['../structcl_1_1detail_1_1_reference_handler.html',1,'cl::detail']]],
  ['referencehandler_3c_20cl_5fcommand_5fqueue_20_3e_2',['ReferenceHandler&lt; cl_command_queue &gt;',['../structcl_1_1detail_1_1_reference_handler_3_01cl__command__queue_01_4.html',1,'cl::detail']]],
  ['referencehandler_3c_20cl_5fcontext_20_3e_3',['ReferenceHandler&lt; cl_context &gt;',['../structcl_1_1detail_1_1_reference_handler_3_01cl__context_01_4.html',1,'cl::detail']]],
  ['referencehandler_3c_20cl_5fdevice_5fid_20_3e_4',['ReferenceHandler&lt; cl_device_id &gt;',['../structcl_1_1detail_1_1_reference_handler_3_01cl__device__id_01_4.html',1,'cl::detail']]],
  ['referencehandler_3c_20cl_5fevent_20_3e_5',['ReferenceHandler&lt; cl_event &gt;',['../structcl_1_1detail_1_1_reference_handler_3_01cl__event_01_4.html',1,'cl::detail']]],
  ['referencehandler_3c_20cl_5fkernel_20_3e_6',['ReferenceHandler&lt; cl_kernel &gt;',['../structcl_1_1detail_1_1_reference_handler_3_01cl__kernel_01_4.html',1,'cl::detail']]],
  ['referencehandler_3c_20cl_5fmem_20_3e_7',['ReferenceHandler&lt; cl_mem &gt;',['../structcl_1_1detail_1_1_reference_handler_3_01cl__mem_01_4.html',1,'cl::detail']]],
  ['referencehandler_3c_20cl_5fplatform_5fid_20_3e_8',['ReferenceHandler&lt; cl_platform_id &gt;',['../structcl_1_1detail_1_1_reference_handler_3_01cl__platform__id_01_4.html',1,'cl::detail']]],
  ['referencehandler_3c_20cl_5fprogram_20_3e_9',['ReferenceHandler&lt; cl_program &gt;',['../structcl_1_1detail_1_1_reference_handler_3_01cl__program_01_4.html',1,'cl::detail']]],
  ['referencehandler_3c_20cl_5fsampler_20_3e_10',['ReferenceHandler&lt; cl_sampler &gt;',['../structcl_1_1detail_1_1_reference_handler_3_01cl__sampler_01_4.html',1,'cl::detail']]],
  ['release_11',['release',['../structcl_1_1detail_1_1_reference_handler_3_01cl__device__id_01_4.html#a70614c8eeee136fb4887bae35216d620',1,'cl::detail::ReferenceHandler&lt; cl_device_id &gt;']]],
  ['result_5ftype_12',['result_type',['../classcl_1_1_kernel_functor.html#a925e6594f59e5e8038770efa2bd4b532',1,'cl::KernelFunctor::result_type()'],['../structcl_1_1compatibility_1_1make__kernel.html#ab5a793302f7651ad151a1e4b585be5d4',1,'cl::compatibility::make_kernel::result_type()']]],
  ['retain_13',['retain',['../structcl_1_1detail_1_1_reference_handler_3_01cl__device__id_01_4.html#ae3392ce2c4055446680bde82e60c976c',1,'cl::detail::ReferenceHandler&lt; cl_device_id &gt;']]]
];
