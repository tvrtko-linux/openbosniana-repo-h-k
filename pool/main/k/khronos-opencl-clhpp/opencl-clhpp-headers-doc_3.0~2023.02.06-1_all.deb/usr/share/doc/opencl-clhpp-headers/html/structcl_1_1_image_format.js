var structcl_1_1_image_format =
[
    [ "ImageFormat", "structcl_1_1_image_format.html#adf48b6e9dfdfefb7583e20826c3b4a14", null ],
    [ "ImageFormat", "structcl_1_1_image_format.html#a039deeaa451a52448014794e7dae30ba", null ],
    [ "ImageFormat", "structcl_1_1_image_format.html#a935a0799f110ada43afb5ccfacf6197b", null ],
    [ "operator=", "structcl_1_1_image_format.html#a74296cd49ed08b0521e8b6b26e51608f", null ]
];