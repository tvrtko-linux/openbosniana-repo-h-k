var structcl_1_1compatibility_1_1make__kernel =
[
    [ "result_type", "structcl_1_1compatibility_1_1make__kernel.html#ab5a793302f7651ad151a1e4b585be5d4", null ],
    [ "type_", "structcl_1_1compatibility_1_1make__kernel.html#aaa094f5455d73fae53eb99b374f05eec", null ]
];