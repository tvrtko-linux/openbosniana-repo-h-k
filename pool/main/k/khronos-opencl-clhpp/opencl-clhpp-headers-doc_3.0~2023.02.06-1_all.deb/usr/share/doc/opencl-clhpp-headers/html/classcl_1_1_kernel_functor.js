var classcl_1_1_kernel_functor =
[
    [ "result_type", "classcl_1_1_kernel_functor.html#a925e6594f59e5e8038770efa2bd4b532", null ],
    [ "operator()", "classcl_1_1_kernel_functor.html#a03d94b7e13205bc28d0d8ee391e02a0a", null ],
    [ "operator()", "classcl_1_1_kernel_functor.html#a94a347dc04af6b06cf4354750853db6e", null ]
];