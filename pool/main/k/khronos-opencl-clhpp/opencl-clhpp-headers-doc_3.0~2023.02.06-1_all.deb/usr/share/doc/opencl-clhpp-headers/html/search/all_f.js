var searchData=
[
  ['sampler_0',['Sampler',['../classcl_1_1_sampler.html',1,'cl::Sampler'],['../classcl_1_1_sampler.html#a41d7df0a069717bc570a6ccdab3d3acd',1,'cl::Sampler::Sampler(const Context &amp;context, cl_bool normalized_coords, cl_addressing_mode addressing_mode, cl_filter_mode filter_mode, cl_int *err=NULL)'],['../classcl_1_1_sampler.html#a487aa40df9ababf70fe4c19a0b538f6f',1,'cl::Sampler::Sampler(Sampler &amp;&amp;sam) CL_HPP_NOEXCEPT_'],['../classcl_1_1_sampler.html#a684ea0f7bb85233239ba3a266795c1a4',1,'cl::Sampler::Sampler(const Sampler &amp;sam)'],['../classcl_1_1_sampler.html#aa32c71d59ca20e83fc283273d0b102cd',1,'cl::Sampler::Sampler(const cl_sampler &amp;sampler, bool retainObject=false)'],['../classcl_1_1_sampler.html#a1c8395b386e3b1c09dc43f4134909390',1,'cl::Sampler::Sampler()']]],
  ['setarg_1',['setArg',['../classcl_1_1_kernel.html#a7d5ad9296c70602f6c04b841115afec6',1,'cl::Kernel::setArg(cl_uint index, const T &amp;value)'],['../classcl_1_1_kernel.html#a4d14a69325def406165c391aee2c844b',1,'cl::Kernel::setArg(cl_uint index, const T argPtr)'],['../classcl_1_1_kernel.html#a3ec081fb9656b0780d808563256dfeff',1,'cl::Kernel::setArg(cl_uint index, const cl::pointer&lt; T, D &gt; &amp;argPtr)'],['../classcl_1_1_kernel.html#a9516e70e10909526dfb01f6cfe8b61bd',1,'cl::Kernel::setArg(cl_uint index, const cl::vector&lt; T, Alloc &gt; &amp;argPtr)']]],
  ['setcallback_2',['setCallback',['../classcl_1_1_event.html#a4730c3b113e65efcf88aea0c9da13f52',1,'cl::Event']]],
  ['setdefault_3',['setDefault',['../classcl_1_1_context.html#a24a8392d2cb8fcdc5dbf4dd723ee74b4',1,'cl::Context::setDefault()'],['../classcl_1_1_command_queue.html#a736a138dd72e39056e8a9aa3dec5d132',1,'cl::CommandQueue::setDefault()'],['../classcl_1_1_platform.html#afcf93176bebefc3add081c2d93935453',1,'cl::Platform::setDefault()'],['../classcl_1_1_device.html#abff439f0de1ed8699a1b93a702d0fc65',1,'cl::Device::setDefault()']]],
  ['setdestructorcallback_4',['setDestructorCallback',['../classcl_1_1_memory.html#a15e14fda4062d21ad354126a599a6111',1,'cl::Memory']]],
  ['setreleasecallback_5',['setReleaseCallback',['../classcl_1_1_program.html#a6722c3f9459432087d82c5ff4d16a72e',1,'cl::Program']]],
  ['setspecializationconstant_6',['setSpecializationConstant',['../classcl_1_1_program.html#a9fefc53ce623dd7180260d83fc991ca4',1,'cl::Program::setSpecializationConstant(cl_uint index, size_type size, const void *value)'],['../classcl_1_1_program.html#aca8d65a532ffd042fa45f88addcb9c88',1,'cl::Program::setSpecializationConstant(cl_uint index, const T &amp;value)']]],
  ['setstatus_7',['setStatus',['../classcl_1_1_user_event.html#ad1df3a34596fee2bf6f1de6893192ae5',1,'cl::UserEvent']]],
  ['setsvmpointers_8',['setSVMPointers',['../classcl_1_1_kernel.html#abadacb0037f711f3460cf5c44b2d4796',1,'cl::Kernel::setSVMPointers(const std::array&lt; void *, ArrayLength &gt; &amp;pointerList)'],['../classcl_1_1_kernel.html#a36633bcfea86c512cbb4fd9b20c6087e',1,'cl::Kernel::setSVMPointers(const vector&lt; void * &gt; &amp;pointerList)']]],
  ['size_9',['size',['../classcl_1_1_n_d_range.html#ad197ecf968b6dce338137909827cb66f',1,'cl::NDRange']]],
  ['svmallocator_10',['SVMAllocator',['../classcl_1_1_s_v_m_allocator.html',1,'cl']]],
  ['svmallocator_3c_20void_2c_20svmtrait_20_3e_11',['SVMAllocator&lt; void, SVMTrait &gt;',['../classcl_1_1_s_v_m_allocator_3_01void_00_01_s_v_m_trait_01_4.html',1,'cl']]],
  ['svmtraitatomic_12',['SVMTraitAtomic',['../classcl_1_1_s_v_m_trait_atomic.html',1,'cl']]],
  ['svmtraitcoarse_13',['SVMTraitCoarse',['../classcl_1_1_s_v_m_trait_coarse.html',1,'cl']]],
  ['svmtraitfine_14',['SVMTraitFine',['../classcl_1_1_s_v_m_trait_fine.html',1,'cl']]],
  ['svmtraitnull_15',['SVMTraitNull',['../classcl_1_1detail_1_1_s_v_m_trait_null.html',1,'cl::detail']]],
  ['svmtraitreadonly_16',['SVMTraitReadOnly',['../classcl_1_1_s_v_m_trait_read_only.html',1,'cl']]],
  ['svmtraitreadwrite_17',['SVMTraitReadWrite',['../classcl_1_1_s_v_m_trait_read_write.html',1,'cl']]],
  ['svmtraitwriteonly_18',['SVMTraitWriteOnly',['../classcl_1_1_s_v_m_trait_write_only.html',1,'cl']]]
];
