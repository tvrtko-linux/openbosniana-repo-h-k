var searchData=
[
  ['allocate_0',['allocate',['../classcl_1_1_s_v_m_allocator.html#a44858d70971c7801aa62d7a64d18df00',1,'cl::SVMAllocator']]],
  ['allocate_5fpointer_1',['allocate_pointer',['../namespacecl.html#a8e1fce10cd1b8118f51aa91ce0a589e5',1,'cl']]]
];
