var searchData=
[
  ['atomic_5fsvm_5fvector_0',['atomic_svm_vector',['../namespacecl.html#aebc48a598e41f0cb98397460ca04ffb6',1,'cl']]]
];
