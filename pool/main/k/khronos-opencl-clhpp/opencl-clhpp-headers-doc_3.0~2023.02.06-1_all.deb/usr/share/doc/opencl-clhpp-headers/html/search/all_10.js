var searchData=
[
  ['type_5f_0',['type_',['../structcl_1_1compatibility_1_1make__kernel.html#aaa094f5455d73fae53eb99b374f05eec',1,'cl::compatibility::make_kernel']]]
];
