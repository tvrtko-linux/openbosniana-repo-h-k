var searchData=
[
  ['wait_0',['wait',['../classcl_1_1_event.html#a51f83064c2024df649667071e81fb847',1,'cl::Event']]],
  ['waitforevents_1',['waitForEvents',['../classcl_1_1_event.html#ae84b90e930f72c1019435dd7cefa2fbd',1,'cl::Event']]]
];
