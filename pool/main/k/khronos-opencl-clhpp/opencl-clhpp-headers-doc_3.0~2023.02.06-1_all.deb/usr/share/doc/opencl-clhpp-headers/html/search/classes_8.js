var searchData=
[
  ['make_5fkernel_0',['make_kernel',['../structcl_1_1compatibility_1_1make__kernel.html',1,'cl::compatibility']]],
  ['memory_1',['Memory',['../classcl_1_1_memory.html',1,'cl']]]
];
