var searchData=
[
  ['getinfofunctor0_0',['GetInfoFunctor0',['../structcl_1_1detail_1_1_get_info_functor0.html',1,'cl::detail']]],
  ['getinfofunctor1_1',['GetInfoFunctor1',['../structcl_1_1detail_1_1_get_info_functor1.html',1,'cl::detail']]]
];
