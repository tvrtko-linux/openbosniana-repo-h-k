var searchData=
[
  ['unloadcompiler_0',['unloadCompiler',['../classcl_1_1_platform.html#a70313ea76e0e369c4dc951a7f47b531f',1,'cl::Platform']]],
  ['unloadcompiler_1',['UnloadCompiler',['../namespacecl.html#a2fc824c118740089633cc15e7107f3f0',1,'cl']]],
  ['unmapsvm_2',['unmapSVM',['../namespacecl.html#af9f49b386b20c55c04a9e6cd21849fd5',1,'cl']]],
  ['updatedefault_3',['updateDefault',['../classcl_1_1_device_command_queue.html#a310598cf108f6cfcc22b1ce578e1df0a',1,'cl::DeviceCommandQueue']]],
  ['userevent_4',['UserEvent',['../classcl_1_1_user_event.html#a4255beef279789245d402a00830c841f',1,'cl::UserEvent::UserEvent(const Context &amp;context, cl_int *err=NULL)'],['../classcl_1_1_user_event.html#a1ee5bc016d511a4fec5f23b50a70821a',1,'cl::UserEvent::UserEvent()']]]
];
