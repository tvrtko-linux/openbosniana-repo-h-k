var searchData=
[
  ['deleter_0',['Deleter',['../classcl_1_1detail_1_1_deleter.html',1,'cl::detail']]],
  ['device_1',['Device',['../classcl_1_1_device.html',1,'cl']]],
  ['devicecommandqueue_2',['DeviceCommandQueue',['../classcl_1_1_device_command_queue.html',1,'cl']]]
];
