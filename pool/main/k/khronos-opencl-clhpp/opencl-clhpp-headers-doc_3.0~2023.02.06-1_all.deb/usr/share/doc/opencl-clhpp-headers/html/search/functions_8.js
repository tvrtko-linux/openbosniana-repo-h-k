var searchData=
[
  ['local_0',['Local',['../namespacecl.html#a2f9d06d8196d7a2f4cf196d5bb7e5dd0',1,'cl']]]
];
