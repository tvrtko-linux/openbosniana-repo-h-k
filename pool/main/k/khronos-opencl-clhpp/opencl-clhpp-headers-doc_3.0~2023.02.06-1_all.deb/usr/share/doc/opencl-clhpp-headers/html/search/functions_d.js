var searchData=
[
  ['release_0',['release',['../structcl_1_1detail_1_1_reference_handler_3_01cl__device__id_01_4.html#a70614c8eeee136fb4887bae35216d620',1,'cl::detail::ReferenceHandler&lt; cl_device_id &gt;']]],
  ['retain_1',['retain',['../structcl_1_1detail_1_1_reference_handler_3_01cl__device__id_01_4.html#ae3392ce2c4055446680bde82e60c976c',1,'cl::detail::ReferenceHandler&lt; cl_device_id &gt;']]]
];
