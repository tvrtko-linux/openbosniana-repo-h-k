var searchData=
[
  ['coarse_5fsvm_5fvector_0',['coarse_svm_vector',['../namespacecl.html#abd957be3ad58ee2932a99ed8bc6cc049',1,'cl']]]
];
