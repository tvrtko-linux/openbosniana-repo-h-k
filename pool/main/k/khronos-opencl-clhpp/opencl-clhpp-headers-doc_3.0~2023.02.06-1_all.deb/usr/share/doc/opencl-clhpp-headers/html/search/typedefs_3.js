var searchData=
[
  ['result_5ftype_0',['result_type',['../classcl_1_1_kernel_functor.html#a925e6594f59e5e8038770efa2bd4b532',1,'cl::KernelFunctor::result_type()'],['../structcl_1_1compatibility_1_1make__kernel.html#ab5a793302f7651ad151a1e4b585be5d4',1,'cl::compatibility::make_kernel::result_type()']]]
];
