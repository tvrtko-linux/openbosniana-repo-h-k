var searchData=
[
  ['param_5ftraits_0',['param_traits',['../structcl_1_1detail_1_1param__traits.html',1,'cl::detail']]],
  ['pipe_1',['Pipe',['../classcl_1_1_pipe.html',1,'cl']]],
  ['platform_2',['Platform',['../classcl_1_1_platform.html',1,'cl']]],
  ['program_3',['Program',['../classcl_1_1_program.html',1,'cl']]]
];
