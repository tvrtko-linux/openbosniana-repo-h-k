var searchData=
[
  ['ndrange_0',['NDRange',['../classcl_1_1_n_d_range.html',1,'cl']]]
];
