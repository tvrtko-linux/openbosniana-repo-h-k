var searchData=
[
  ['kernel_0',['Kernel',['../classcl_1_1_kernel.html#a69b2fc97f80d90a23927a74395d09ec9',1,'cl::Kernel::Kernel()'],['../classcl_1_1_kernel.html#a0c71f37cb53fbe492847fbb2dff2bfed',1,'cl::Kernel::Kernel(const cl_kernel &amp;kernel, bool retainObject=false)'],['../classcl_1_1_kernel.html#a93b516f37993297101dd9d30a4572b23',1,'cl::Kernel::Kernel(const Kernel &amp;kernel)'],['../classcl_1_1_kernel.html#a0869347f24520f2d59222f74297c5fe5',1,'cl::Kernel::Kernel(Kernel &amp;&amp;kernel) CL_HPP_NOEXCEPT_']]]
];
