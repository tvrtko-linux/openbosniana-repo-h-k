var searchData=
[
  ['local_0',['Local',['../namespacecl.html#a2f9d06d8196d7a2f4cf196d5bb7e5dd0',1,'cl']]],
  ['localspacearg_1',['LocalSpaceArg',['../structcl_1_1_local_space_arg.html',1,'cl']]]
];
