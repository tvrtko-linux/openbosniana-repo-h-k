var searchData=
[
  ['kernel_0',['Kernel',['../classcl_1_1_kernel.html',1,'cl']]],
  ['kernelargumenthandler_1',['KernelArgumentHandler',['../structcl_1_1detail_1_1_kernel_argument_handler.html',1,'cl::detail']]],
  ['kernelargumenthandler_3c_20cl_3a_3adevicecommandqueue_2c_20void_20_3e_2',['KernelArgumentHandler&lt; cl::DeviceCommandQueue, void &gt;',['../structcl_1_1detail_1_1_kernel_argument_handler_3_01cl_1_1_device_command_queue_00_01void_01_4.html',1,'cl::detail']]],
  ['kernelargumenthandler_3c_20localspacearg_2c_20void_20_3e_3',['KernelArgumentHandler&lt; LocalSpaceArg, void &gt;',['../structcl_1_1detail_1_1_kernel_argument_handler_3_01_local_space_arg_00_01void_01_4.html',1,'cl::detail']]],
  ['kernelargumenthandler_3c_20t_2c_20typename_20std_3a_3aenable_5fif_3c_20std_3a_3ais_5fbase_5fof_3c_20cl_3a_3amemory_2c_20t_20_3e_3a_3avalue_20_3e_3a_3atype_20_3e_4',['KernelArgumentHandler&lt; T, typename std::enable_if&lt; std::is_base_of&lt; cl::Memory, T &gt;::value &gt;::type &gt;',['../structcl_1_1detail_1_1_kernel_argument_handler_3_01_t_00_01typename_01std_1_1enable__if_3_01std_cb5bfaca8096193f715a7bbe8a3fa84f.html',1,'cl::detail']]],
  ['kernelargumenthandler_3c_20t_2c_20typename_20std_3a_3aenable_5fif_3c_21std_3a_3ais_5fbase_5fof_3c_20cl_3a_3amemory_2c_20t_20_3e_3a_3avalue_20_3e_3a_3atype_20_3e_5',['KernelArgumentHandler&lt; T, typename std::enable_if&lt;!std::is_base_of&lt; cl::Memory, T &gt;::value &gt;::type &gt;',['../structcl_1_1detail_1_1_kernel_argument_handler_3_01_t_00_01typename_01std_1_1enable__if_3_9std_10affa824618af864313998f2e6bcf08f.html',1,'cl::detail']]],
  ['kernelfunctor_6',['KernelFunctor',['../classcl_1_1_kernel_functor.html',1,'cl']]],
  ['kernelfunctor_3c_20ts_2e_2e_2e_20_3e_7',['KernelFunctor&lt; Ts... &gt;',['../classcl_1_1_kernel_functor.html',1,'cl']]]
];
