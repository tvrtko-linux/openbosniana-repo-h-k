var searchData=
[
  ['makedefault_0',['makeDefault',['../classcl_1_1_device_command_queue.html#acf98d7e70d84afc31789a6f26a95d14b',1,'cl::DeviceCommandQueue::makeDefault(cl_int *err=nullptr)'],['../classcl_1_1_device_command_queue.html#a2188fe106a515329fd90ac58ee95e10e',1,'cl::DeviceCommandQueue::makeDefault(const Context &amp;context, const Device &amp;device, cl_int *err=nullptr)'],['../classcl_1_1_device_command_queue.html#a74abbdd1ba59525634baa4334ae70215',1,'cl::DeviceCommandQueue::makeDefault(const Context &amp;context, const Device &amp;device, cl_uint queueSize, cl_int *err=nullptr)']]],
  ['mapsvm_1',['mapSVM',['../namespacecl.html#ae97dc5bb86e2c3c3935280a86cda301c',1,'cl']]],
  ['max_5fsize_2',['max_size',['../classcl_1_1_s_v_m_allocator.html#aec263261a88fb1ec64a3e5f9a4ef41a7',1,'cl::SVMAllocator']]],
  ['memory_3',['Memory',['../classcl_1_1_memory.html#a9926612772ae6e016f1118ef4148da22',1,'cl::Memory::Memory()'],['../classcl_1_1_memory.html#a6fa9f585a65beebcb75e41cca70ee1bb',1,'cl::Memory::Memory(const cl_mem &amp;memory, bool retainObject)'],['../classcl_1_1_memory.html#a23691d3d5e70f47538f1cde3741b0367',1,'cl::Memory::Memory(const Memory &amp;mem)'],['../classcl_1_1_memory.html#a48a3ca6b8b6c4dbdcd6cc8e75d6503e6',1,'cl::Memory::Memory(Memory &amp;&amp;mem) CL_HPP_NOEXCEPT_']]]
];
