var searchData=
[
  ['localspacearg_0',['LocalSpaceArg',['../structcl_1_1_local_space_arg.html',1,'cl']]]
];
