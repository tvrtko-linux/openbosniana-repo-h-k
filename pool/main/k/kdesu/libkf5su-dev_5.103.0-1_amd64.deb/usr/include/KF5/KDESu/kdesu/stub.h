// KDE4 compat header
#include "stubprocess.h"
