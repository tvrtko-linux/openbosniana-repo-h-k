// KDE4 compat header
#include "ptyprocess.h"
