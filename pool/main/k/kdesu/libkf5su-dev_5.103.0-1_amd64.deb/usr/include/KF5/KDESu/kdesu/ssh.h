// KDE4 compat header
#include "sshprocess.h"
