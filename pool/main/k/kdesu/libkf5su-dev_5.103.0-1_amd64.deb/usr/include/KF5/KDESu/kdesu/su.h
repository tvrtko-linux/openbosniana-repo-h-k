// KDE4 compat header
#include "suprocess.h"
