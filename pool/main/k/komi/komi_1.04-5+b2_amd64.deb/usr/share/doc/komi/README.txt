Komi Readme
-----------

Komi is a 2D arcade game written in C, which uses the SDL library for graphics and sound. Komi is released under the GNU General Public License (see COPYING.txt for details).

Installation instructions are in INSTALL.txt

Problems? See TROUBLESHOOTING.txt (especially for trouble with the sound, or if the game speed seems wrong). You can email acrossman@users.sourceforge.net with bug-reports, questions, etc.

--

The aim of the game is to collect the money (in the forms of coins and diamonds) floating about the screen. Move Komi (the Space Frog) with the arrow keys, or keypad 4 and 6, or Q and W, and extend his tongue with the spacebar, or the return key.

--

Feedback to acrossman@users.sourceforge.net
