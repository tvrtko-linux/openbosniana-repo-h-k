#!/usr/bin/env python3

from .khard import main

main()
