
#ifndef KMBOX_EXPORT_H
#define KMBOX_EXPORT_H

#ifdef KMBOX_STATIC_DEFINE
#  define KMBOX_EXPORT
#  define KMBOX_NO_EXPORT
#else
#  ifndef KMBOX_EXPORT
#    ifdef KF5Mbox_EXPORTS
        /* We are building this library */
#      define KMBOX_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KMBOX_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KMBOX_NO_EXPORT
#    define KMBOX_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KMBOX_DEPRECATED
#  define KMBOX_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KMBOX_DEPRECATED_EXPORT
#  define KMBOX_DEPRECATED_EXPORT KMBOX_EXPORT KMBOX_DEPRECATED
#endif

#ifndef KMBOX_DEPRECATED_NO_EXPORT
#  define KMBOX_DEPRECATED_NO_EXPORT KMBOX_NO_EXPORT KMBOX_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KMBOX_NO_DEPRECATED
#    define KMBOX_NO_DEPRECATED
#  endif
#endif

#endif /* KMBOX_EXPORT_H */
