
#ifndef KTPMODELS_EXPORT_H
#define KTPMODELS_EXPORT_H

#ifdef KTPMODELS_STATIC_DEFINE
#  define KTPMODELS_EXPORT
#  define KTPMODELS_NO_EXPORT
#else
#  ifndef KTPMODELS_EXPORT
#    ifdef KTpModels_EXPORTS
        /* We are building this library */
#      define KTPMODELS_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KTPMODELS_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KTPMODELS_NO_EXPORT
#    define KTPMODELS_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KTPMODELS_DEPRECATED
#  define KTPMODELS_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KTPMODELS_DEPRECATED_EXPORT
#  define KTPMODELS_DEPRECATED_EXPORT KTPMODELS_EXPORT KTPMODELS_DEPRECATED
#endif

#ifndef KTPMODELS_DEPRECATED_NO_EXPORT
#  define KTPMODELS_DEPRECATED_NO_EXPORT KTPMODELS_NO_EXPORT KTPMODELS_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KTPMODELS_NO_DEPRECATED
#    define KTPMODELS_NO_DEPRECATED
#  endif
#endif

#endif /* KTPMODELS_EXPORT_H */
