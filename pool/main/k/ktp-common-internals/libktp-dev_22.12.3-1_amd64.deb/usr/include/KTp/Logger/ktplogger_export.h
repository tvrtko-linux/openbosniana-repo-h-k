
#ifndef KTPLOGGER_EXPORT_H
#define KTPLOGGER_EXPORT_H

#ifdef KTPLOGGER_STATIC_DEFINE
#  define KTPLOGGER_EXPORT
#  define KTPLOGGER_NO_EXPORT
#else
#  ifndef KTPLOGGER_EXPORT
#    ifdef KTpLogger_EXPORTS
        /* We are building this library */
#      define KTPLOGGER_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KTPLOGGER_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KTPLOGGER_NO_EXPORT
#    define KTPLOGGER_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KTPLOGGER_DEPRECATED
#  define KTPLOGGER_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KTPLOGGER_DEPRECATED_EXPORT
#  define KTPLOGGER_DEPRECATED_EXPORT KTPLOGGER_EXPORT KTPLOGGER_DEPRECATED
#endif

#ifndef KTPLOGGER_DEPRECATED_NO_EXPORT
#  define KTPLOGGER_DEPRECATED_NO_EXPORT KTPLOGGER_NO_EXPORT KTPLOGGER_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KTPLOGGER_NO_DEPRECATED
#    define KTPLOGGER_NO_DEPRECATED
#  endif
#endif

#endif /* KTPLOGGER_EXPORT_H */
