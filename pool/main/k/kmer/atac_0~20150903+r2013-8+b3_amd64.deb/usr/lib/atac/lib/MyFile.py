#!/usr/bin/python3
import sys, os, copy, tempfile, io

# from __future__ import generators  # Necessary before Python 2.3

class myfile():
    "A temporary anonymous file"
    def __init__(self):
        self.tmpfile = tempfile.NamedTemporaryFile(delete=False)
        self.name = self.tmpfile.name
    def __del__(self):                 
        self.close()
        return os.unlink(self.name)
    def __iter__(self):
        line = self.tmpfile.readline()
        if line:
            yield line
        else:
            return
    def write(self, data):
        return self.tmpfile.write(data.encode())
    def flush(self):
        return self.tmpfile.flush()
    def seek(self, pos):
        return self.tmpfile.seek(pos)
    def close(self):
        return self.tmpfile.close()
    def link(self,othername):
        return os.symlink(self.name, othername, target_is_directory=False)

class ListLikeFileIter:
    # See http://www.python.org/peps/pep-0234.html
    # for file iterators.
    def __init__(self,filename):
        self._filename = filename
        self._fileptr = open(self._filename,"r")
        self._fileIter = iter(self._fileptr.readline,"")
    def __del__(self):
        self._fileptr.close()
    def __next__(self):
        line = next(self._fileIter)
        if line:
            return line
        else:
            raise StopInteration
        # end if
    def __getitem__(self,ii):
        # For files, the list location ii is ignored.
        # line = self._fileptr.readline()
        line = next(self._fileIter)
        if line:
            return line
        else:
            raise IndexError
        # end if
    # end def
    
class ListLikeFile:
    # See Mark Lutz, Programming Python, edition 1, page 18 and page 128.
    def __init__(self):
        #self._filename = tempfile.mktemp()
        #self._fileptr = open(self._filename,"w")
        self._fileptr = io.StringIO()
        #self._list = []
    def __del__(self):
        self._fileptr.close()
        #pass
    def __iter__(self):
        self._fileptr.flush()
        return iter(io.StringIO(self._fileptr.getvalue()))
        #return iter(self._fileptr)
        #return ListLikeFileIter(self._filename)
        return iter(self._list)
    def write(self,x):
        self._fileptr.write(x)
        #self._list.append(x)
    # end def
# end class

def tester():
    x = ListLikeFile()
    print(4, file=x)
    print(5, file=x)

    xi = iter(x)
    print("test 1i")
    for i in xi: print(i, end=' ')

    print(6, file=x)
    print(7, file=x)
    print("test 2i")
    for i in xi: print(i, end=' ')

    xj = iter(x)
    print("test 3j")
    for i in xj: print(i, end=' ')

    print(8, file=x)
    print(9, file=x)
    
    print("test 3j")
    for i in xj: print(i, end=' ')

    print("test 3i")
    for i in xi: print(i, end=' ')

    xk = iter(x)
    print("test 3k")
    for i in xk: print(i, end=' ')

    x = None

if __name__ == '__main__':
    tester()
