
#ifndef KOSM_EXPORT_H
#define KOSM_EXPORT_H

#ifdef KOSM_STATIC_DEFINE
#  define KOSM_EXPORT
#  define KOSM_NO_EXPORT
#else
#  ifndef KOSM_EXPORT
#    ifdef KOSM_EXPORTS
        /* We are building this library */
#      define KOSM_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KOSM_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KOSM_NO_EXPORT
#    define KOSM_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KOSM_DEPRECATED
#  define KOSM_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KOSM_DEPRECATED_EXPORT
#  define KOSM_DEPRECATED_EXPORT KOSM_EXPORT KOSM_DEPRECATED
#endif

#ifndef KOSM_DEPRECATED_NO_EXPORT
#  define KOSM_DEPRECATED_NO_EXPORT KOSM_NO_EXPORT KOSM_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KOSM_NO_DEPRECATED
#    define KOSM_NO_DEPRECATED
#  endif
#endif

#endif /* KOSM_EXPORT_H */
