
#ifndef KOSMINDOORMAP_EXPORT_H
#define KOSMINDOORMAP_EXPORT_H

#ifdef KOSMINDOORMAP_STATIC_DEFINE
#  define KOSMINDOORMAP_EXPORT
#  define KOSMINDOORMAP_NO_EXPORT
#else
#  ifndef KOSMINDOORMAP_EXPORT
#    ifdef KOSMIndoorMap_EXPORTS
        /* We are building this library */
#      define KOSMINDOORMAP_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KOSMINDOORMAP_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KOSMINDOORMAP_NO_EXPORT
#    define KOSMINDOORMAP_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KOSMINDOORMAP_DEPRECATED
#  define KOSMINDOORMAP_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KOSMINDOORMAP_DEPRECATED_EXPORT
#  define KOSMINDOORMAP_DEPRECATED_EXPORT KOSMINDOORMAP_EXPORT KOSMINDOORMAP_DEPRECATED
#endif

#ifndef KOSMINDOORMAP_DEPRECATED_NO_EXPORT
#  define KOSMINDOORMAP_DEPRECATED_NO_EXPORT KOSMINDOORMAP_NO_EXPORT KOSMINDOORMAP_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KOSMINDOORMAP_NO_DEPRECATED
#    define KOSMINDOORMAP_NO_DEPRECATED
#  endif
#endif

#endif /* KOSMINDOORMAP_EXPORT_H */
