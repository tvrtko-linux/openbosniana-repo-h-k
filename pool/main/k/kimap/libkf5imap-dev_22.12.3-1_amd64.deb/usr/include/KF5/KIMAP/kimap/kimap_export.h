
#ifndef KIMAP_EXPORT_H
#define KIMAP_EXPORT_H

#ifdef KIMAP_STATIC_DEFINE
#  define KIMAP_EXPORT
#  define KIMAP_NO_EXPORT
#else
#  ifndef KIMAP_EXPORT
#    ifdef KF5IMAP_EXPORTS
        /* We are building this library */
#      define KIMAP_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define KIMAP_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef KIMAP_NO_EXPORT
#    define KIMAP_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef KIMAP_DEPRECATED
#  define KIMAP_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef KIMAP_DEPRECATED_EXPORT
#  define KIMAP_DEPRECATED_EXPORT KIMAP_EXPORT KIMAP_DEPRECATED
#endif

#ifndef KIMAP_DEPRECATED_NO_EXPORT
#  define KIMAP_DEPRECATED_NO_EXPORT KIMAP_NO_EXPORT KIMAP_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef KIMAP_NO_DEPRECATED
#    define KIMAP_NO_DEPRECATED
#  endif
#endif

#endif /* KIMAP_EXPORT_H */
