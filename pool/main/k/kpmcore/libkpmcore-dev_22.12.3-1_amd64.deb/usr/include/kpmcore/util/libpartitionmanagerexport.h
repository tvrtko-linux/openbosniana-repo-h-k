
#ifndef LIBKPMCORE_EXPORT_H
#define LIBKPMCORE_EXPORT_H

#ifdef LIBKPMCORE_STATIC_DEFINE
#  define LIBKPMCORE_EXPORT
#  define LIBKPMCORE_NO_EXPORT
#else
#  ifndef LIBKPMCORE_EXPORT
#    ifdef kpmcore_EXPORTS
        /* We are building this library */
#      define LIBKPMCORE_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define LIBKPMCORE_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef LIBKPMCORE_NO_EXPORT
#    define LIBKPMCORE_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef LIBKPMCORE_DEPRECATED
#  define LIBKPMCORE_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef LIBKPMCORE_DEPRECATED_EXPORT
#  define LIBKPMCORE_DEPRECATED_EXPORT LIBKPMCORE_EXPORT LIBKPMCORE_DEPRECATED
#endif

#ifndef LIBKPMCORE_DEPRECATED_NO_EXPORT
#  define LIBKPMCORE_DEPRECATED_NO_EXPORT LIBKPMCORE_NO_EXPORT LIBKPMCORE_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef LIBKPMCORE_NO_DEPRECATED
#    define LIBKPMCORE_NO_DEPRECATED
#  endif
#endif

#endif /* LIBKPMCORE_EXPORT_H */
