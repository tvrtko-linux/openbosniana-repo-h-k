
#ifndef LIBKONQ_EXPORT_H
#define LIBKONQ_EXPORT_H

#ifdef LIBKONQ_STATIC_DEFINE
#  define LIBKONQ_EXPORT
#  define LIBKONQ_NO_EXPORT
#else
#  ifndef LIBKONQ_EXPORT
#    ifdef KF5Konq_EXPORTS
        /* We are building this library */
#      define LIBKONQ_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define LIBKONQ_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef LIBKONQ_NO_EXPORT
#    define LIBKONQ_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef LIBKONQ_DEPRECATED
#  define LIBKONQ_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef LIBKONQ_DEPRECATED_EXPORT
#  define LIBKONQ_DEPRECATED_EXPORT LIBKONQ_EXPORT LIBKONQ_DEPRECATED
#endif

#ifndef LIBKONQ_DEPRECATED_NO_EXPORT
#  define LIBKONQ_DEPRECATED_NO_EXPORT LIBKONQ_NO_EXPORT LIBKONQ_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef LIBKONQ_NO_DEPRECATED
#    define LIBKONQ_NO_DEPRECATED
#  endif
#endif

#endif /* LIBKONQ_EXPORT_H */
