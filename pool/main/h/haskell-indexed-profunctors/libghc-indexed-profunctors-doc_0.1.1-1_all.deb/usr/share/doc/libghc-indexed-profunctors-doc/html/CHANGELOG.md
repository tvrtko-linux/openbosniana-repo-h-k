# indexed-profunctors-0.1.1 (2021-04-09)
* Remove unnecessary INLINE pragmas

# indexed-profunctors-0.1 (2019-10-11)
* Initial release
