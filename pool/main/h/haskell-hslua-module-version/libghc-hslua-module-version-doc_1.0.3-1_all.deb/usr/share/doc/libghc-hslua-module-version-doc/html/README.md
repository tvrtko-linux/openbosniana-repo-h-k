# hslua-module-version

[![GitHub CI][CI badge]](https://github.com/hslua/hslua-module-version/actions)
[![Hackage][Hackage badge]](https://hackage.haskell.org/package/hslua-module-version)
[![Stackage Lts][Stackage Lts badge]](http://stackage.org/lts/package/hslua-module-version)
[![Stackage Nightly][Stackage Nightly badge]](http://stackage.org/nightly/package/hslua-module-version)
[![MIT license][License badge]](LICENSE)

[CI badge]: https://img.shields.io/github/workflow/status/hslua/hslua/CI.svg?logo=github
[Hackage badge]: https://img.shields.io/hackage/v/hslua-module-version.svg?logo=haskell
[Stackage Lts badge]: http://stackage.org/package/hslua-module-version/badge/lts
[Stackage Nightly badge]: http://stackage.org/package/hslua-module-version/badge/nightly
[License badge]: https://img.shields.io/badge/license-MIT-blue.svg

Lua module to work with version specifiers.
