var searchData=
[
  ['nb_5fcolumns_0',['nb_columns',['../struct__h__result.html#a89005cca8583b65926b0b6493e115f4c',1,'_h_result']]],
  ['nb_5frows_1',['nb_rows',['../struct__h__result.html#a1f54b961d31584ab692e67d629c1e350',1,'_h_result']]]
];
