var searchData=
[
  ['_5fh_5fresult_20sql_20query_20management_20functions_0',['_h_result SQL query management functions',['../group__h__result.html',1,'']]]
];
