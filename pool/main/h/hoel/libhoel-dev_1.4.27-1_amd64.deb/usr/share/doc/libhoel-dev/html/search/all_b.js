var searchData=
[
  ['t_5fdata_0',['t_data',['../struct__h__data.html#aa4e6327290e2182af0d518e6ac62d0cc',1,'_h_data']]],
  ['type_1',['type',['../struct__h__connection.html#a5f73066044ef8afe4d8e8c2be5a8b8bb',1,'_h_connection::type()'],['../struct__h__data.html#a012cea152bfec077b2797193236a86fa',1,'_h_data::type()']]]
];
