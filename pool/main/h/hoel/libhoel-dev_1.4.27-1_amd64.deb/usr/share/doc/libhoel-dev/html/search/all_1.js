var searchData=
[
  ['connection_0',['connection',['../struct__h__connection.html#a9ed88f0f51c3c38cccee9b9d87b2697a',1,'_h_connection']]],
  ['constants_1',['Constants',['../group__const.html',1,'']]]
];
