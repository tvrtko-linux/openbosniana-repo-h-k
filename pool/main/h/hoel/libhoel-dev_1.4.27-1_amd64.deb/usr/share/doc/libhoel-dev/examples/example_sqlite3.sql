-- License: MIT
CREATE TABLE other_test (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    age INTEGER,
    temperature FLOAT
);
