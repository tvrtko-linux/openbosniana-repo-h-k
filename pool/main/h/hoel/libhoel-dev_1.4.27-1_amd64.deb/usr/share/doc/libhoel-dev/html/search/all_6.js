var searchData=
[
  ['json_20sql_20query_20management_20functions_0',['JSON SQL query management functions',['../group__json.html',1,'']]]
];
