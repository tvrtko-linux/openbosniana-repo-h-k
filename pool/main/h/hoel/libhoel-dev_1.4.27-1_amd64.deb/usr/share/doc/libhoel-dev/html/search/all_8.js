var searchData=
[
  ['memory_20management_20functions_0',['Memory management functions',['../group__memory.html',1,'']]]
];
