var searchData=
[
  ['initialize_20and_20cosing_20connection_20functions_0',['Initialize and cosing connection functions',['../group__init.html',1,'']]]
];
