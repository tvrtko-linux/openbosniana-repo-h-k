#define MD5_LENGTH 16

void md5(char *rhash, char *buf, int len, time_t *date, bool debug);
