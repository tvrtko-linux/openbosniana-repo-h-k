//
// Part of the ht://Dig package   <http://www.htdig.org/>
// Copyright (c) 1999-2004 The ht://Dig Group
// For copyright details, see the file COPYING in your distribution
// or the GNU Library General Public License (LGPL) version 2 or later
// <http://www.gnu.org/copyleft/lgpl.html>
//


#ifndef	_HtVector_int_h_
#define	_HtVector_int_h_

#define GType int
#define HtVectorGType HtVector_int
#include "HtVectorGeneric.h"


#endif



