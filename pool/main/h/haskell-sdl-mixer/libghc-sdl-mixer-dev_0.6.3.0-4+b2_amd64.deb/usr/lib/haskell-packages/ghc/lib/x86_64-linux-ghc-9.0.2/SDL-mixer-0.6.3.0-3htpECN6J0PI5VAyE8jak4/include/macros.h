
#include <SDL.h>
#include <SDL_mixer.h>

Mix_Chunk * HS_Mix_LoadWAV(const char* file);
