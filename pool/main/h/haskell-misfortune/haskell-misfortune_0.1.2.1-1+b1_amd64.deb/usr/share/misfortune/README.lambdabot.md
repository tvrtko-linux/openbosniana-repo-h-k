lambdabot fortune files
========================

The files in `data/normal/lambdabot` and `data/offensive/lambdabot` are filled with strings pulled out of the source code of the IRC bot [lambdabot](http://www.haskell.org/haskellwiki/Lambdabot) (or see [my fork](https://github.com/mokus0/lambdabot)).

Known / possible contributors
------------------------------

This list is based on `darcs annotate` output.

* Don Stewart
* Duncan Coutts
* Gwern Branwen
* Tim Newsham
* Spencer Janssen
* Twan van Laarhoven

If I've missed someone, or if you're on the list and prefer not to be blamed, let me know!
