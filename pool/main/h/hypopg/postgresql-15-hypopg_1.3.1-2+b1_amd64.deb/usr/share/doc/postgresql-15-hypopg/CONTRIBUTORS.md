People who contributed to hypopg:

  * Julien Rouhaud
  * Yuzuko Hosoya
  * Thom brown
  * Ronan Dunklau
  * Мосолов Константин
  * Andrew Kane
  * Rob Stolarz
  * Jeremy Finzel
  * Christoph Berg
  * Joel Van Horn
  * Michael Lroll
  * Godwottery
  * Jan Koßmann
  * Extortioner01
  * nagaraju11
  * ibrahim edib kokdemir
  * github user nikhil-postgres
