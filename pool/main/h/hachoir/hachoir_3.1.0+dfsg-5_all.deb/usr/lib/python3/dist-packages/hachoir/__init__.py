VERSION = (3, 1, 0)
__version__ = ".".join(map(str, VERSION))
