
new_theory `prog_logic88`;;

load_library `string`;;

new_parent `semantics`;;
new_parent `hoare_thms`;;
new_parent `halts`;;
new_parent `halts_thms`;;
new_parent `halts_logic`;;
new_parent `dijkstra`;;
new_parent `dynamic_logic`;;

close_theory();;
