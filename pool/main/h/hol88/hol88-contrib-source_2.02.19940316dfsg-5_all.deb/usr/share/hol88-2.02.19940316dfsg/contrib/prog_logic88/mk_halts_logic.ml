
new_theory `halts_logic`;;

load_library `string`;;
new_parent `hoare_thms`;;
new_parent `halts_thms`;;

close_theory();;
