set_search_path 
  (search_path() @ 
    [`defs/`
    ]);;

