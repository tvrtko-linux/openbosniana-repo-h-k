%< HOL Initalization File

   Created January 1991 by Flemming Andersen

>%

% Setting the Directory search path %
set_search_path ([`./`;`../`]@(search_path()));;
