set_search_path 
  (search_path() @ 
   [`/home/passat/jwright/hol/Library/more_lists/`;
    `/home/passat/jwright/hol/Library/string/`
   ] );;
