% thmkind.ml                                            (c) R.J.Boulton 1990 %
%----------------------------------------------------------------------------%


% Datatype for the three different kinds of theorem %

type thmkind = Axiom | Definition | Theorem;;


%----------------------------------------------------------------------------%
