
lettype ella = print_tree;;


top_print (\pt. pp full_ella_rules_fun `ella` [] pt);;
% top_print (\pt. pp raw_tree_rules_fun `` [] pt);; %


