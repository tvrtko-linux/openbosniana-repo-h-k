% Generated parser load file

  First load some basic definitions: %
loadf `/usr/users/jvt/HOL/CHEOPS/Parser/ml/general`;;

% Insert any other files you want loaded here: %

% Now load the declarations: %
loadf `blocks_decls`;;

% Finally load in the function definitions: %
loadf `blocks`;;
