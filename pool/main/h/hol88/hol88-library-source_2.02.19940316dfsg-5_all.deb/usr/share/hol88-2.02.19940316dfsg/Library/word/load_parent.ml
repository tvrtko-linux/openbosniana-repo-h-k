% ===================================================================== %
% FILE		: load_parent.ml					%
% DESCRIPTION   : loads the parent library of "word" into hol		%
%									%
% AUTHOR	: Wai Wong						%
% DATE		: 17 May 1993						%
% ===================================================================== %

% No need to load any parent libraries %

