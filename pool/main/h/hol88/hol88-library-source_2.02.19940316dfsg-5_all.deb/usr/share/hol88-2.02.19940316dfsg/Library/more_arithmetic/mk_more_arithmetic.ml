new_theory `more_arithmetic`;;

% PC 13/8/92 auxiliary library no longer needed%
%load_library `auxiliary`;;%

new_parent`ineq`;;
new_parent`pre`;;
new_parent`sub`;;
new_parent`mult`;;
new_parent`min_max`;;
new_parent`odd_even`;;
new_parent`div_mod`;;

close_theory ();;


