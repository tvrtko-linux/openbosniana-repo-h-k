letref tyname
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:preterm list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:preterm,fail:preterm list,fail:string,fail:string list);;

letref tyvar
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:preterm list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:preterm,fail:preterm list,fail:string,fail:string list);;

letref typ
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:preterm list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:preterm,fail:preterm list,fail:string,fail:string list);;

letref more_type
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:preterm list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:preterm,fail:preterm list,fail:string,fail:string list);;

letref more_prod_type
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:preterm list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:preterm,fail:preterm list,fail:string,fail:string list);;

letref sum_or_fun_type
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:preterm list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:preterm,fail:preterm list,fail:string,fail:string list);;

letref more_sum_type
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:preterm list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:preterm,fail:preterm list,fail:string,fail:string list);;

letref fun_type
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:preterm list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:preterm,fail:preterm list,fail:string,fail:string list);;

letref type1
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:preterm list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:preterm,fail:preterm list,fail:string,fail:string list);;

letref poss_cmpnd_type
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:preterm list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:preterm,fail:preterm list,fail:string,fail:string list);;

letref rest_of_cmpnd
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:preterm list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:preterm,fail:preterm list,fail:string,fail:string list);;

letref more_type1
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:preterm list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:preterm,fail:preterm list,fail:string,fail:string list);;

