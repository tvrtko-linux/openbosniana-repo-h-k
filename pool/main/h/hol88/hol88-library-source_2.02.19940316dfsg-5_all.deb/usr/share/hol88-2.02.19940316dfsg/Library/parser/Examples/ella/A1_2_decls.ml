letref MAIN_LOOP
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref more_decs
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

