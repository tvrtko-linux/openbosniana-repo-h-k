letref unit
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref units_l
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref unit_fn
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref unit_mac
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref mac_poss_parms_names
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref unit_names
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref more_unit_names
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref macparams
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref macparam
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref more_macparams
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref unit1
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref unit1_finish
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref poss_unit1_names
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref poss_1st_int
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref poss_2nd_int
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref unit2
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref unit2_stuff
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref name_stuff
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref unit3
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref more_units
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref caseclause
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref choices
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref more_choices
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref choosers
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref poss_case_else
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref more_elseofs
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref end_game_case
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

