letref intdec
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref int
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref formula
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref formula1
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref poss_ibinop
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref formula2
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref boolean
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

