letref series
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref BEGIN_steps
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref more_B_steps
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref bracket_steps
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref more_br_steps
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref step
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref makeitem
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref makeitem_body
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref make_mac
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref snd_macparams
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref more_makeitems
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref more_item_names
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref letitem
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref more_letitems
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref joinstep
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref multiplier
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref more_multipliers
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref joinitem
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref rest_of_joinitem
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref second_join_int
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref more_joinitems
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref printitem
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref more_printables
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref more_printitems
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref faultitem
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

letref more_faultitems
   (lst:string list) (whitespace:string)(prev:string)
   (result_list:ella list list)
   (FIRST_CHARS:string list) (CHARS:string list) (expected:string) =
   (fail:ella list,fail:ella list list,fail:string,fail:string list);;

