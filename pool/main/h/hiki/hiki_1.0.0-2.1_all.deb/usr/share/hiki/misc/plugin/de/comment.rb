# $Id: comment.rb,v 1.1 2005-08-02 13:37:41 yanagita Exp $
# Copyright (C) 2002-2003 TAKEUCHI Hitoshi <hitoshi@namaraii.com>

def comment_name_label
  'Name'
end

def comment_comment_label
  'Kommentar'
end

def comment_post_label
  'Nachricht'
end

def comment_anonymous_label
  'Anonymous'
end
