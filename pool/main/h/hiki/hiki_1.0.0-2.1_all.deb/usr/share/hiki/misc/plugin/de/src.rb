# $Id: src.rb,v 1.1 2005-08-02 13:37:41 yanagita Exp $
# Copyright (C) 2003 TAKEUCHI Hitoshi <hitoshi@namaraii.com>

def src_label
  'Source'
end
