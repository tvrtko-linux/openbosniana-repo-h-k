# $Id: show_plugins.rb,v 1.2 2006-02-18 06:00:35 yanagita Exp $
# Copyright (C) 2005 Kouhei Yanagita <yanagi@shakenbu.org>

# implemented in 01sp.rb

export_plugin_methods(:show_plugins)

