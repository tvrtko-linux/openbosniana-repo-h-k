# $Id: bbs.rb,v 1.1 2005-08-02 13:37:41 yanagita Exp $
# Copyright (C) 2002-2003 TAKEUCHI Hitoshi <hitoshi@namaraii.com>

def bbs_name_label
  'Name'
end

def bbs_subject_label
  'Titel'
end

def bbs_post_label
  'Nachricht'
end

def bbs_anonymous_label
  'Anonymous'
end

def bbs_notitle_label
  'kein Titel'
end
