def label_math_latex_ptsize; 'Font Size (pt)'; end
def label_math_latex_documentclass; 'Document Class'; end
def label_math_latex_preamble; 'Preamble'; end
def label_math_latex_log; 'Log'; end
def label_math_latex_log_description; 'When checked, the log to standard error output during execution won\'t be deleted afterwards'; end
def label_math_latex_cache_clear; 'Clear Cache'; end
def label_math_latex_cache_clear_description; 'When checked, the images stored in the cache will be removed'; end
def label_math_latex_latex; 'latex Command'; end
def label_math_latex_dvips; 'dvips Command'; end
def label_math_latex_convert; 'convert Command'; end
