# -*- coding: utf-8 -*-
def help_lineshelp_label
   '行支援'
end

def help_wordshelp_label
   '文字支援'
end

def help_tablehelp_label
   '表支援'
end

def help_pluginhelp_label
   'プラグイン支援'
end

def help_mathhelp_label
   '数式支援'
end

def help_heading_label
   '見出し'
end

def help_list_label
   '箇条書'
end

def help_numbered_label
   '番号付'
end

def help_preformatted_label
   '整形済'
end

def help_quotation_label
   '引用'
end

def help_comment_label
   'コメント'
end

def help_cancel_label
   '解除'
end

def help_link_label
   'リンク'
end

def help_url_label
   'URL'
end

def help_emphasized_label
   '強調'
end

def help_strongly_label
   'さらに'
end

def help_struckout_label
   '取消線'
end

def help_definition_label
   '用語解説'
end

def help_horizontal_label
   '水平線'
end

def help_cell_label
   'セル'
end

def help_headingcell_label
   '見出し'
end

def help_rows_label
   '縦連結'
end

def help_columns_label
   '横連結'
end

def help_plugin_label
   'プラグイン'
end

def help_br_label
   '改行'
end

def help_toc_label
   '目次'
end

def help_tochere_label
   'ここに'
end

def help_recent_label
   '最近'
end

def help_display_label
   'ディスプレイ'
end

def help_inline_label
   'インライン'
end
