# -*- coding: utf-8 -*-
def append_css_label
        'CSSの追加'
end

def append_css_desc
        <<-HTML
        <h3>CSS断片</h3>
        <p>現在指定してあるテーマに、スタイルシートを追加設定する場合、
        以下にCSSの断片を入力してください。</p>
        HTML
end
