# $Id: template.rb,v 1.1 2005-08-02 13:37:41 yanagita Exp $
# Copyright (C) 2003 TAKEUCHI Hitoshi <hitoshi@namaraii.com>

def template_label
  'Dokumentenvorlage'
end

def template_select_label
  'Import'
end

def label_template_default
  'Standardvorlage'
end

def label_template_default_desc
  'W&auml;hlen Sie eine Seite als Standard Dokumentenvorlage.'
end

def label_template_keyword
  'Stichwort f&uuml;r Dokumentenvorlagen.'
end

def label_template_keyword_desc
  'Nur Seiten mit diesem Stichwort werden als Vorlageseiten angezeigt.'
end

def label_template_autoinsert
  'Automatische Vorlage'
end

def label_template_autoinsert_desc
  'Automatisch bei dem Erstellen einer Seite eine Vorlage benutzen.'
end
