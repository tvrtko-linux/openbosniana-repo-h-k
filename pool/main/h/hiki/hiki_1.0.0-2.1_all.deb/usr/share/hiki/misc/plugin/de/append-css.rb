def append_css_label
  'CSS Anh&auml;ngen'
end

def append_css_desc
  <<-HTML
  <h3>CSS Elemente</h3>
  <p>Wenn Sie CSS Element anh&auml;ngen wollen, geben Sie diese unten an.</p>
  HTML
end
