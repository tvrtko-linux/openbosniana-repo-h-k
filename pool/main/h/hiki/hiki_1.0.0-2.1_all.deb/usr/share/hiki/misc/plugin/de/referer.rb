# $Id: referer.rb,v 1.1 2005-08-02 13:37:41 yanagita Exp $
# Copyright (C) 2003 TAKEUCHI Hitoshi <hitoshi@namaraii.com>

def referer_short_label
  'Referer'
end

def referer_long_label
  'Referer (zuvor besuchte Webseite)'
end
