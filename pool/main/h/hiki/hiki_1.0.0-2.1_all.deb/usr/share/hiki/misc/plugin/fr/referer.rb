# $Id: referer.rb,v 1.3 2005-03-03 15:53:56 fdiary Exp $
# Copyright (C) 2003 Laurent Sansonetti <laurent@datarescue.be>

def referer_short_label
  'R�f�rences externes'
end

def referer_long_label
  'R�f�rences externes'
end
