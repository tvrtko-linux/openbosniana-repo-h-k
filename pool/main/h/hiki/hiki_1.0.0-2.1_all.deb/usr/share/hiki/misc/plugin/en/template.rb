# $Id: template.rb,v 1.3 2005-06-27 05:21:42 fdiary Exp $
# Copyright (C) 2003 TAKEUCHI Hitoshi <hitoshi@namaraii.com>

def template_label
  'Template'
end

def template_select_label
  'Import'
end

def label_template_default
  'Default template'
end

def label_template_default_desc
  'Select the default template page.'
end

def label_template_keyword
  'A keyword of templates'
end

def label_template_keyword_desc
  'Only pages that has the specified keyword will be candidates.'
end

def label_template_autoinsert
  'Auto insert'
end

def label_template_autoinsert_desc
  'Insert the template in creating new pages.'
end
