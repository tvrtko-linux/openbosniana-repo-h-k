# $Id: bbs.rb,v 1.3 2005-03-03 15:53:56 fdiary Exp $
# Copyright (C) 2003 Laurent Sansonetti <laurent@datarescue.be>

def bbs_name_label
  'Nom'
end

def bbs_subject_label
  'Sujet'
end

def bbs_post_label
  'Envoyer'
end

def bbs_anonymous_label
  'Anonyme'
end

def bbs_notitle_label
  'Pas de titre'
end
