# $Id: attach.rb,v 1.3 2005-03-03 15:53:56 fdiary Exp $
# Copyright (C) 2003 Luigi Maselli <metnik@tiscali.it>

def attach_files_label
  'File allegati'
end

def attach_upload_label
  'File caricati'
end

def detach_upload_label
  'Rimuovi file'
end
