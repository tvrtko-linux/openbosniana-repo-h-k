def help_lineshelp_label
   'LinesHelp'
end

def help_wordshelp_label
   'WordsHelp'
end

def help_tablehelp_label
   'TableHelp'
end

def help_pluginhelp_label
   'PluginHelp'
end

def help_mathhelp_label
   'MathHelp'
end

def help_heading_label
   'Heading'
end

def help_list_label
   'List'
end

def help_numbered_label
   'numbered'
end

def help_preformatted_label
   'Preformatted'
end

def help_quotation_label
   'Quotation'
end

def help_comment_label
   'Comment'
end

def help_cancel_label
   'cancel'
end

def help_link_label
   'Link'
end

def help_url_label
   'URL'
end

def help_emphasized_label
   'Emphasized'
end

def help_strongly_label
   'strongly'
end

def help_struckout_label
   'Struck out'
end

def help_definition_label
   'Definition'
end

def help_horizontal_label
   'Horizontal'
end

def help_cell_label
   'cell'
end

def help_headingcell_label
   'heading'
end

def help_rows_label
   'rows'
end

def help_columns_label
   'columns'
end

def help_plugin_label
   'Plugin'
end

def help_br_label
   'Line break'
end

def help_toc_label
   'Contents'
end

def help_tochere_label
   'here'
end

def help_recent_label
   'Recent'
end

def help_display_label
   'display'
end

def help_inline_label
   'inline'
end
