# $Id: referer.rb,v 1.3 2005-03-03 15:53:56 fdiary Exp $
# Copyright (C) 2003 Luigi Maselli <metnik@tiscali.it>

def referer_short_label
  'Referente'
end

def referer_long_label
  'Referente'
end
