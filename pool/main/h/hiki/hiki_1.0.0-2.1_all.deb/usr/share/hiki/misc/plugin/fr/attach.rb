# $Id: attach.rb,v 1.3 2005-03-03 15:53:56 fdiary Exp $
# Copyright (C) 2003 Laurent Sansonetti <laurent@datarescue.be>

def attach_files_label
  'Fichiers joints'
end

def attach_upload_label
  'Attacher le fichier'
end

def detach_upload_label
  'Retirer les fichiers'
end
