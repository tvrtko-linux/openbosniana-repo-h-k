# $Id: comment.rb,v 1.2 2004-02-15 02:48:35 hitoshi Exp $
# Copyright (C) 2003 Luigi Maselli <metnik@tiscali.it>

def comment_name_label
  'Nome'
end

def comment_comment_label
  'Commento'
end

def comment_post_label
  'Post'
end

def comment_anonymous_label
  'Anonimo'
end
