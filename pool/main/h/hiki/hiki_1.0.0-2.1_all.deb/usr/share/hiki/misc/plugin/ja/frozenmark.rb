# -*- coding: utf-8 -*-
# $Id: frozenmark.rb,v 1.1 2005-03-03 15:53:56 fdiary Exp $
# Copyright (C) 2003 OZAWA Sakuro <crouton@users.sourceforge.jp>

def frozenmark_message; 'このページは凍結されています。'; end
