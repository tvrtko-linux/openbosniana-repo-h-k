# $Id: parser.rb,v 1.3 2005-09-29 04:53:01 fdiary Exp $

require "style/default/parser"

module Hiki
  class Parser_math < Parser_default
  end
end
