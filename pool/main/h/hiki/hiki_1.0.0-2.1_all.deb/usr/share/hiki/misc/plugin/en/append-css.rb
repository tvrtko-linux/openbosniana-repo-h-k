def append_css_label
        'Append CSS'
end

def append_css_desc
        <<-HTML
        <h3>CSS elements</h3>
        <p>If you want to append some elements of style sheet, specify below.</p>
        HTML
end
