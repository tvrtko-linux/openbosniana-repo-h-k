# Copyright (C) 2008, KURODA Hiraku <hiraku@hinet.mydns.jp>
# You can redistribute it and/or modify it under GPL2. 

module WordFilterMessage
  def self.word_filter; "Word filter"; end
  def self.use; "Filtering by bellow Regexp"; end
  def self.regexp_by_line; "Write one regular expression each line."; end
end
