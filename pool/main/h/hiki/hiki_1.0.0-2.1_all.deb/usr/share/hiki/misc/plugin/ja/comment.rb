# -*- coding: utf-8 -*-
# $Id: comment.rb,v 1.1 2005-03-03 15:53:56 fdiary Exp $
# Copyright (C) 2002-2003 TAKEUCHI Hitoshi <hitoshi@namaraii.com>

def comment_name_label
  'お名前'
end

def comment_comment_label
  'コメント'
end

def comment_post_label
  '投稿'
end

def comment_anonymous_label
  '名無しさん'
end
