def frozenmark_message
  'On a gel� cette page.'
end
