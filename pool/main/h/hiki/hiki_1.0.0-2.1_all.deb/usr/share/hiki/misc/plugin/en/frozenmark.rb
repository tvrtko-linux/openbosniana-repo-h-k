def frozenmark_message
  'This page is frozen.'
end
