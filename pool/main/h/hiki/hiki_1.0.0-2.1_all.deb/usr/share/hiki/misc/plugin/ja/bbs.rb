# -*- coding: utf-8 -*-
# $Id: bbs.rb,v 1.1 2005-03-03 15:53:56 fdiary Exp $
# Copyright (C) 2002-2003 TAKEUCHI Hitoshi <hitoshi@namaraii.com>

def bbs_name_label
  'お名前'
end

def bbs_subject_label
  '件名'
end

def bbs_post_label
  '投稿'
end

def bbs_anonymous_label
  '名無しさん'
end

def bbs_notitle_label
  '無題'
end
