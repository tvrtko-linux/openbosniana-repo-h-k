# $Id: comment.rb,v 1.2 2004-02-15 02:48:35 hitoshi Exp $
# Copyright (C) 2003 Laurent Sansonetti <laurent@datarescue.be>

def comment_name_label
  'Nom'
end

def comment_comment_label
  'Commentaire'
end

def comment_post_label
  'Envoyer'
end

def comment_anonymous_label
  'Anonyme'
end
