# $Id: bbs.rb,v 1.3 2005-03-03 15:53:55 fdiary Exp $
# Copyright (C) 2002-2003 TAKEUCHI Hitoshi <hitoshi@namaraii.com>

def bbs_name_label
  'Name'
end

def bbs_subject_label
  'Subject'
end

def bbs_post_label
  'Post'
end

def bbs_anonymous_label
  'Anonymous'
end

def bbs_notitle_label
  'No Title'
end
