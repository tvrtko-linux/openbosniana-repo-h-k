def search_post_label
  'Search'
end
