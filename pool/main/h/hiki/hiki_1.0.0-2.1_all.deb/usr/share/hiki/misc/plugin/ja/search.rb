# -*- coding: utf-8 -*-
def search_post_label
  '検索'
end
