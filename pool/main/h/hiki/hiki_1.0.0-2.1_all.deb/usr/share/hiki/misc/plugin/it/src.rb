# $Id: src.rb,v 1.2 2004-02-15 02:48:35 hitoshi Exp $
# Copyright (C) 2003 Luigi Maselli <metnik@tiscali.it>

def src_label
  'Sorgente'
end
