# $Id: referer.rb,v 1.3 2005-03-03 15:53:55 fdiary Exp $
# Copyright (C) 2003 TAKEUCHI Hitoshi <hitoshi@namaraii.com>

def referer_short_label
  'Referer'
end

def referer_long_label
  'Referer'
end
