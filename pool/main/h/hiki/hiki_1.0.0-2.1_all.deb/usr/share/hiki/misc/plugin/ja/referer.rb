# -*- coding: utf-8 -*-
# $Id: referer.rb,v 1.1 2005-03-03 15:53:56 fdiary Exp $
# Copyright (C) 2003 TAKEUCHI Hitoshi <hitoshi@namaraii.com>

def referer_short_label
  'リンク元'
end

def referer_long_label
  'このページへのリンク元'
end
