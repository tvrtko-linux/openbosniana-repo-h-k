# $Id: src.rb,v 1.2 2004-02-15 02:48:35 hitoshi Exp $
# Copyright (C) 2003 Laurent Sansonetti <laurent@datarescue.be>

def src_label
  'Source'
end
