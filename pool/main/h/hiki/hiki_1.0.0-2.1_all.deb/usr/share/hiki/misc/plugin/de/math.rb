def label_math_latex_ptsize; 'Schriftgr&ouml;&szlig;e (pt)'; end
def label_math_latex_documentclass; 'Dokument Klasse'; end
def label_math_latex_preamble; 'Preamble'; end
def label_math_latex_log; 'Protokoll'; end
def label_math_latex_log_description; 'Wenn angew&auml;hlt, wird das Fehlerprotokoll (standard error output) nach der ausf&uuml;hrung nicht gel&ouml;scht.'; end
def label_math_latex_cache_clear; 'Zwischenspeicher L&ouml;schen'; end
def label_math_latex_cache_clear_description; 'Wenn angew&auml;hlt, werden die zwischengespeicherten Bilder gel&ouml;scht.'; end
def label_math_latex_latex; 'latex Befehl'; end
def label_math_latex_dvips; 'dvips Befehl'; end
def label_math_latex_convert; 'convert Befehl'; end
