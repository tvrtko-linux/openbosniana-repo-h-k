# -*- coding: utf-8 -*-
def help_heading_label
   'Überschrift'
end

def help_list_label
   'Liste'
end

def help_numbered_label
   'Aufzählung'
end

def help_link_label
   'Link'
end

def help_url_label
   'URL'
end

def help_emphasized_label
   'Kursiv'
end

def help_strongly_label
   'Fett'
end

def help_struckout_label
   'Durchgestrichen'
end

def help_definition_label
   'Definition'
end

def help_table_label
   'Tabelle'
end

def help_cell_label
   'Zelle'
end

def help_headingcell_label
   'Überschrift'
end

def help_rows_label
   'Reihen'
end

def help_columns_label
   'Spalten'
end

def help_horizontal_label
   'Horizontal'
end

def help_multiplelines_label
   'mehrere Zeilen'
end

def help_preformatted_label
   'Vor-Formatiert'
end

def help_cancel_label
   'Beenden'
end

def help_quotation_label
   'Zitat'
end

def help_comment_label
   'Kommentar'
end

def help_math_label
   'Mathe'
end

def help_display_label
   'display'
end

def help_inline_label
   'inline'
end

def help_plugin_label
   'Plugin'
end

def help_br_label
   'Zeilenumbruch'
end

def help_toc_label
   'Inhaltsverzeichnis'
end

def help_tochere_label
   'hier'
end

def help_recent_label
   'Letzte Änderungen'
end
