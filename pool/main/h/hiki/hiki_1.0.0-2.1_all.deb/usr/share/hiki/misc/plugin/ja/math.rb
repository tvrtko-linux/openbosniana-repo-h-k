# -*- coding: utf-8 -*-
def label_math_latex_ptsize; 'フォントサイズ (pt)'; end
def label_math_latex_documentclass; 'ドキュメントクラス'; end
def label_math_latex_preamble; 'プリアンブル'; end
def label_math_latex_log; 'ログの保持'; end
def label_math_latex_log_description; 'タイプセット・コマンド実行時の標準出力・
標準エラー出力のログを削除しない．'; end
def label_math_latex_cache_clear; 'キャッシュのクリア'; end
def label_math_latex_cache_clear_description; 'チェックして OK すると，現時点で保持されている画像のキャッシュを削除する．'; end
def label_math_latex_latex; 'latex コマンド'; end
def label_math_latex_dvips; 'dvips コマンド'; end
def label_math_latex_convert; 'convert コマンド'; end
