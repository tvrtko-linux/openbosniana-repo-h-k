# $Id: bbs.rb,v 1.3 2005-03-03 15:53:56 fdiary Exp $
# Copyright (C) 2003 Luigi Maselli <metnik@tiscali.it>

def bbs_name_label
  'Nome'
end

def bbs_subject_label
  'Argomento'
end

def bbs_post_label
  'Post'
end

def bbs_anonymous_label
  'Anonimo'
end

def bbs_notitle_label
  'Senza titolo'
end
