# -*- coding: utf-8 -*-
# $Id: src.rb,v 1.1 2005-03-03 15:53:56 fdiary Exp $
# Copyright (C) 2003 TAKEUCHI Hitoshi <hitoshi@namaraii.com>

def src_label
  'ソース'
end
