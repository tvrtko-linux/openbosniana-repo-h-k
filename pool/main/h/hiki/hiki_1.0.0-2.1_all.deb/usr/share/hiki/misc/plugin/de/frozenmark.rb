def frozenmark_message
  'Diese Seite ist eingefrohren.'
end
