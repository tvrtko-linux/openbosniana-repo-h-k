#include <stdio.h>

FILE *PosixRedirect_stdout();
FILE *PosixRedirect_stderr();
