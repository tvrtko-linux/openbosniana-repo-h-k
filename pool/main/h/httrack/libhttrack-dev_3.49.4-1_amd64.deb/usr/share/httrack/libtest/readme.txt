HTTrack library example
-----------------------

Here is an example of how to integrate HTTrack Website Copier into a project
to use it as a "core library". 


Important Notice:
----------------

These sources are covered by the GNU General Public License (see below)
(Projects based on these sources must follow the GPL, too)


Copyright notice:
----------------

HTTrack Website Copier, Offline Browser for Windows and Unix
Copyright (C) Xavier Roche and other contributors

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

========================================================================
    MAKEFILE PROJECT : libtest Project Overview
========================================================================

AppWizard has created this libtest project for you.  

This file contains a summary of what you will find in each of the files that
make up your libtest project.


libtest.vcproj
    This is the main project file for VC++ projects generated using an Application Wizard. 
    It contains information about the version of Visual C++ that generated the file, and 
    information about the platforms, configurations, and project features selected with the
    Application Wizard.

This project allows you to build/clean/rebuild from within Visual Studio by calling the commands you have input 
in the wizard. The build command can be nmake or any other tool you use.

This project  does not contain any files, so there are none displayed in Solution Explorer.

/////////////////////////////////////////////////////////////////////////////
