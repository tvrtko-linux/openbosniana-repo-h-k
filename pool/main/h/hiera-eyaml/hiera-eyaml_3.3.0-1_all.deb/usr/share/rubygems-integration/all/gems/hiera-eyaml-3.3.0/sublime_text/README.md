Sublime Text Syntax Highlighting Package
========================================

The contents of this directory give syntax highlighting to .eyaml files in Sublime Text 2+

Install
=======

To install, simply copy eyaml.sublime-package into your "Installed Packages" directory in the data directory of your Sublime Text 2 installation. The data directory is:

* Windows: %APPDATA%/Sublime Text 2
* OS X: ~/Library/Application Support/Sublime Text 2
* Linux: ~/.Sublime Text 2

Then restart sublimetext

