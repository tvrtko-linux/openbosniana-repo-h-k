var _parameter_8h =
[
    [ "Halide::Internal::Parameter", "class_halide_1_1_internal_1_1_parameter.html", "class_halide_1_1_internal_1_1_parameter" ],
    [ "check_call_arg_types", "_parameter_8h.html#a0ce66817377fbb1918bbe7510ab47b29", null ]
];