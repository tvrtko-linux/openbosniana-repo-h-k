var _l_l_v_m___runtime___linker_8h =
[
    [ "get_triple_for_target", "_l_l_v_m___runtime___linker_8h.html#a496ad11988df981c987a2557c3cd2d8c", null ],
    [ "get_initial_module_for_target", "_l_l_v_m___runtime___linker_8h.html#ad04027d1e41197c21cc803367b612e08", null ],
    [ "get_initial_module_for_ptx_device", "_l_l_v_m___runtime___linker_8h.html#a67f50077affbb1487e3680d0d879e243", null ],
    [ "add_bitcode_to_module", "_l_l_v_m___runtime___linker_8h.html#af5c2253813b438bcb811778d84b98e94", null ],
    [ "link_with_wasm_jit_runtime", "_l_l_v_m___runtime___linker_8h.html#a7f7830b669a6e68edeeb27c58d65e55a", null ]
];