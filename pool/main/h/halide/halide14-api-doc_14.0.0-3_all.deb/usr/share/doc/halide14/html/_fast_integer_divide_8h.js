var _fast_integer_divide_8h =
[
    [ "fast_integer_divide", "_fast_integer_divide_8h.html#a3feb2bd4dfdc07441d1f88aa3dbe3ce1", null ],
    [ "fast_integer_divide_round_to_zero", "_fast_integer_divide_8h.html#aa5ff5fda50a464f353b19356352dc1fb", null ],
    [ "fast_integer_modulo", "_fast_integer_divide_8h.html#a3be7c825c5a8ca06cbb5c70dc7c9fcd8", null ]
];