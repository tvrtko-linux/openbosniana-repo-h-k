var _device_a_p_i_8h =
[
    [ "DeviceAPI", "_device_a_p_i_8h.html#aa26c7f430d2b1c44ba3e1d3f6df2ba6e", [
      [ "None", "_device_a_p_i_8h.html#aa26c7f430d2b1c44ba3e1d3f6df2ba6ea6adf97f83acf6453d4a6a4b1070f3754", null ],
      [ "Host", "_device_a_p_i_8h.html#aa26c7f430d2b1c44ba3e1d3f6df2ba6eac2ca16d048ec66e04bca283eab048ec2", null ],
      [ "Default_GPU", "_device_a_p_i_8h.html#aa26c7f430d2b1c44ba3e1d3f6df2ba6eaee977b69833eed1db30528c41d839ef8", null ],
      [ "CUDA", "_device_a_p_i_8h.html#aa26c7f430d2b1c44ba3e1d3f6df2ba6eaa33b7755e5f9b504d2d038eaca4ff28d", null ],
      [ "OpenCL", "_device_a_p_i_8h.html#aa26c7f430d2b1c44ba3e1d3f6df2ba6ea7982b09a852b37f2afb1227eaf552e47", null ],
      [ "OpenGLCompute", "_device_a_p_i_8h.html#aa26c7f430d2b1c44ba3e1d3f6df2ba6ea3adf0945d2bbb4c868f37d38e02684d5", null ],
      [ "Metal", "_device_a_p_i_8h.html#aa26c7f430d2b1c44ba3e1d3f6df2ba6eaeaa57a9b4248ce3968e718895e1c2f04", null ],
      [ "Hexagon", "_device_a_p_i_8h.html#aa26c7f430d2b1c44ba3e1d3f6df2ba6ea125e13c182697c5a282e4de6d7999eb0", null ],
      [ "HexagonDma", "_device_a_p_i_8h.html#aa26c7f430d2b1c44ba3e1d3f6df2ba6ea4b2626a6b8b94341748b21e603039989", null ],
      [ "D3D12Compute", "_device_a_p_i_8h.html#aa26c7f430d2b1c44ba3e1d3f6df2ba6eaac083508369e66fdeb744a9dbf917bee", null ]
    ] ],
    [ "all_device_apis", "_device_a_p_i_8h.html#abeae4f594180635f1a0a60c0dac5fe72", null ]
];