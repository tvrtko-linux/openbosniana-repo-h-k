var _i_r_equality_8h =
[
    [ "Halide::Internal::IRDeepCompare", "struct_halide_1_1_internal_1_1_i_r_deep_compare.html", "struct_halide_1_1_internal_1_1_i_r_deep_compare" ],
    [ "Halide::Internal::IRCompareCache", "class_halide_1_1_internal_1_1_i_r_compare_cache.html", "class_halide_1_1_internal_1_1_i_r_compare_cache" ],
    [ "Halide::Internal::ExprWithCompareCache", "struct_halide_1_1_internal_1_1_expr_with_compare_cache.html", "struct_halide_1_1_internal_1_1_expr_with_compare_cache" ],
    [ "equal", "_i_r_equality_8h.html#a1074fbd76b40a9cc210fbd22fdcda914", null ],
    [ "equal", "_i_r_equality_8h.html#a705ef4763a82b7907112099a01604d0d", null ],
    [ "graph_equal", "_i_r_equality_8h.html#a3fad2884f65d9bbb20c6cdcc65e08d47", null ],
    [ "graph_equal", "_i_r_equality_8h.html#a31b5e9d7137c035d913570030d474bac", null ],
    [ "ir_equality_test", "_i_r_equality_8h.html#ac59065f04bcf4e664007d95affa7ce3f", null ]
];