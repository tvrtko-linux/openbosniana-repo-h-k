var _memoization_8h =
[
    [ "inject_memoization", "_memoization_8h.html#ac66d64dd9cb646535816aff25b0d38ad", null ],
    [ "rewrite_memoized_allocations", "_memoization_8h.html#af597feabae6ec97802ee2f800667a0f7", null ]
];