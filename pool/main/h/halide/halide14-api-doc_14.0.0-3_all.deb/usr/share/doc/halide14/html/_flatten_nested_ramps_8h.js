var _flatten_nested_ramps_8h =
[
    [ "flatten_nested_ramps", "_flatten_nested_ramps_8h.html#afdf714a588746f3f1017dc77dad68a67", null ],
    [ "flatten_nested_ramps", "_flatten_nested_ramps_8h.html#a2729ffaedee0544f9b584f53bc91954b", null ]
];