var _apply_split_8h =
[
    [ "Halide::Internal::ApplySplitResult", "struct_halide_1_1_internal_1_1_apply_split_result.html", "struct_halide_1_1_internal_1_1_apply_split_result" ],
    [ "apply_split", "_apply_split_8h.html#a63dc004481b59a246434d882ed2d1409", null ],
    [ "compute_loop_bounds_after_split", "_apply_split_8h.html#ad3589e250311bb913b71fd2355258098", null ]
];