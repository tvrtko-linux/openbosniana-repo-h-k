var _simplify_8h =
[
    [ "simplify", "_simplify_8h.html#a27703ba7275487b2b51577b102ad35bc", null ],
    [ "simplify", "_simplify_8h.html#ad9f85e31bdbf4aae440e0f875538c22f", null ],
    [ "can_prove", "_simplify_8h.html#a5068393c9b9f8b58f7e1c164bee99f0b", null ],
    [ "simplify_exprs", "_simplify_8h.html#a0918e7154f0624c9f1a15d34f4776c54", null ]
];