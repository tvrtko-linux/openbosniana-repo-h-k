var _code_gen___open_c_l___dev_8h =
[
    [ "new_CodeGen_OpenCL_Dev", "_code_gen___open_c_l___dev_8h.html#a0c4bf60d96cab45e7145ca44a8542d0a", null ]
];