var _hexagon_offload_8h =
[
    [ "inject_hexagon_rpc", "_hexagon_offload_8h.html#a8696c48228f0cb335255ae46954909e1", null ],
    [ "compile_module_to_hexagon_shared_object", "_hexagon_offload_8h.html#ada520284696ef879c882132d47d56575", null ]
];