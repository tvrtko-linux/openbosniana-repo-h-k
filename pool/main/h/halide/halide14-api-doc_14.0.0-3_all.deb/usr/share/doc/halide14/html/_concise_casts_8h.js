var _concise_casts_8h =
[
    [ "f64", "_concise_casts_8h.html#aa489e644d91200dac34c620f1c4a1261", null ],
    [ "f32", "_concise_casts_8h.html#ad3a00bcd562633db7df8241bb4a97dcf", null ],
    [ "f16", "_concise_casts_8h.html#aaafd1baeff31b7d0293b95f041e0d116", null ],
    [ "bf16", "_concise_casts_8h.html#a8e2154ce76c37412e7d74c0c7fe5fecb", null ],
    [ "i64", "_concise_casts_8h.html#ae4681dce6418db5a9dfa174f5143e41e", null ],
    [ "i32", "_concise_casts_8h.html#a7531284c41bfa896b67f0e836bc3fe36", null ],
    [ "i16", "_concise_casts_8h.html#aeb8fa10f0e42d0a65aff8376d705a629", null ],
    [ "i8", "_concise_casts_8h.html#a1fbd2fc390aa0b055c1cf946207cb152", null ],
    [ "u64", "_concise_casts_8h.html#ad4ac3f9c0a7d879c00902be9e8854637", null ],
    [ "u32", "_concise_casts_8h.html#a2a3d36cdf58c4100be28b22f0d7a83c9", null ],
    [ "u16", "_concise_casts_8h.html#aac6d4c605db63c0b8e417f890b7dcfa3", null ],
    [ "u8", "_concise_casts_8h.html#abb82cc7f4dd3dd1a42cb0df78d8c4d8c", null ],
    [ "i8_sat", "_concise_casts_8h.html#a24bfbe6a85f9a4c659228c704c7362fe", null ],
    [ "u8_sat", "_concise_casts_8h.html#a5a1c665f5f09d2754b429cc9c5d97285", null ],
    [ "i16_sat", "_concise_casts_8h.html#ad066dcad4bc8e2335903fb16d199f5f8", null ],
    [ "u16_sat", "_concise_casts_8h.html#a0caaa27458b1c10c82477f54bad7c359", null ],
    [ "i32_sat", "_concise_casts_8h.html#aff10e6c30707d770f31065682bd077a9", null ],
    [ "u32_sat", "_concise_casts_8h.html#ad67f2162a35811e4b011adf167eac451", null ],
    [ "i64_sat", "_concise_casts_8h.html#a0a8433d8417bd5ae866d7cd4ad9a1a21", null ],
    [ "u64_sat", "_concise_casts_8h.html#a9b3ade1db71de94c8d45b294bb4460f3", null ]
];