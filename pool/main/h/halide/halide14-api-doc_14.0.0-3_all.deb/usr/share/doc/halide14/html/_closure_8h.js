var _closure_8h =
[
    [ "Halide::Internal::Closure", "class_halide_1_1_internal_1_1_closure.html", "class_halide_1_1_internal_1_1_closure" ],
    [ "Halide::Internal::Closure::Buffer", "struct_halide_1_1_internal_1_1_closure_1_1_buffer.html", "struct_halide_1_1_internal_1_1_closure_1_1_buffer" ]
];