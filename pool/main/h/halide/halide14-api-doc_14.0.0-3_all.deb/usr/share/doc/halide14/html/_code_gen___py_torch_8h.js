var _code_gen___py_torch_8h =
[
    [ "Halide::Internal::CodeGen_PyTorch", "class_halide_1_1_internal_1_1_code_gen___py_torch.html", "class_halide_1_1_internal_1_1_code_gen___py_torch" ]
];