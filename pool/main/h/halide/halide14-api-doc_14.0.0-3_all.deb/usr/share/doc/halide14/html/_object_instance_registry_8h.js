var _object_instance_registry_8h =
[
    [ "Halide::Internal::ObjectInstanceRegistry", "class_halide_1_1_internal_1_1_object_instance_registry.html", "class_halide_1_1_internal_1_1_object_instance_registry" ]
];