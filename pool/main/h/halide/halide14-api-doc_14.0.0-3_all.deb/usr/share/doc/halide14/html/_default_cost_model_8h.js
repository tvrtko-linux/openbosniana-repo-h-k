var _default_cost_model_8h =
[
    [ "Halide::DefaultCostModel", "class_halide_1_1_default_cost_model.html", "class_halide_1_1_default_cost_model" ],
    [ "make_default_cost_model", "_default_cost_model_8h.html#afa995c58d1a58d46a8905cd949098037", null ]
];