var _fuse_g_p_u_thread_loops_8h =
[
    [ "zero_gpu_loop_mins", "_fuse_g_p_u_thread_loops_8h.html#a4235fdb540be5dde3f9942604be666f0", null ],
    [ "fuse_gpu_thread_loops", "_fuse_g_p_u_thread_loops_8h.html#a0081752824625e87b5e95bfae979499f", null ]
];