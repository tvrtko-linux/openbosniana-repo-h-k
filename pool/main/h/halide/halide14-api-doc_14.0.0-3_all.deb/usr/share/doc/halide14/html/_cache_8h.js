var _cache_8h =
[
    [ "Halide::Internal::Autoscheduler::CachingOptions", "struct_halide_1_1_internal_1_1_autoscheduler_1_1_caching_options.html", "struct_halide_1_1_internal_1_1_autoscheduler_1_1_caching_options" ],
    [ "Halide::Internal::Autoscheduler::Cache", "struct_halide_1_1_internal_1_1_autoscheduler_1_1_cache.html", "struct_halide_1_1_internal_1_1_autoscheduler_1_1_cache" ],
    [ "BlockCache", "_cache_8h.html#ac4a760d4410b0ae30c06664402693f91", null ],
    [ "use_memoized_features", "_cache_8h.html#a463e9e284cee27aa8b61e53c24d04f42", null ],
    [ "is_memoize_blocks_enabled", "_cache_8h.html#ad2e5eb1517b8277d4411d1c9b56d8087", null ]
];