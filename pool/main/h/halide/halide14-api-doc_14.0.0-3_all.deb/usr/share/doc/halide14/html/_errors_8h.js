var _errors_8h =
[
    [ "user_error", "_errors_8h.html#a78a5394c1943bdf1a612fa2287a0ad62", null ],
    [ "user_warning", "_errors_8h.html#a79e0ccc806e809fe4f6d3cc952dea89b", null ],
    [ "user_assert", "_errors_8h.html#af439940098bb932fbd7e5b42365d377c", null ],
    [ "internal_assert", "_errors_8h.html#ac6b33d592fea72b20afd0039afd7360e", null ],
    [ "internal_error", "_errors_8h.html#a462c17e7e8b2753700f2d369b361cb68", null ]
];