var _device_argument_8h =
[
    [ "Halide::Internal::DeviceArgument", "struct_halide_1_1_internal_1_1_device_argument.html", "struct_halide_1_1_internal_1_1_device_argument" ],
    [ "Halide::Internal::HostClosure", "class_halide_1_1_internal_1_1_host_closure.html", "class_halide_1_1_internal_1_1_host_closure" ]
];