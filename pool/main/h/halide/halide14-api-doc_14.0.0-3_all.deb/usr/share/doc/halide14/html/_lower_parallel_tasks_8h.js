var _lower_parallel_tasks_8h =
[
    [ "lower_parallel_tasks", "_lower_parallel_tasks_8h.html#ac932a9ede73796baeeb77ff860e97472", null ]
];