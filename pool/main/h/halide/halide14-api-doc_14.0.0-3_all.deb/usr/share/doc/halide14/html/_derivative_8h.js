var _derivative_8h =
[
    [ "Halide::Derivative", "class_halide_1_1_derivative.html", "class_halide_1_1_derivative" ],
    [ "propagate_adjoints", "_derivative_8h.html#a1e455180d26c51953b64f318f3c8b11f", null ],
    [ "propagate_adjoints", "_derivative_8h.html#a754b88aa3b1aa18a7809f665ba10aad9", null ],
    [ "propagate_adjoints", "_derivative_8h.html#a98a3ed6633ddd588c45cfa98dcaf84ef", null ]
];