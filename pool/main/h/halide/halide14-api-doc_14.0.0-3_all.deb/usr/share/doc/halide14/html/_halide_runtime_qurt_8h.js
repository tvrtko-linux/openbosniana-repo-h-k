var _halide_runtime_qurt_8h =
[
    [ "halide_qurt_hvx_lock", "_halide_runtime_qurt_8h.html#a255a8350b89a669baa108ab4218a0457", null ],
    [ "halide_qurt_hvx_unlock", "_halide_runtime_qurt_8h.html#aba88d062a33d5b69001ef8351f181ae5", null ],
    [ "halide_qurt_hvx_unlock_as_destructor", "_halide_runtime_qurt_8h.html#a1efc5071b50f0619b34d992cad35cbde", null ]
];