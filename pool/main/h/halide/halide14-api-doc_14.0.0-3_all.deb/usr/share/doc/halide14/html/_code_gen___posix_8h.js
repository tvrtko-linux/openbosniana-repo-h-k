var _code_gen___posix_8h =
[
    [ "Halide::Internal::CodeGen_Posix", "class_halide_1_1_internal_1_1_code_gen___posix.html", "class_halide_1_1_internal_1_1_code_gen___posix" ],
    [ "Halide::Internal::CodeGen_Posix::Allocation", "struct_halide_1_1_internal_1_1_code_gen___posix_1_1_allocation.html", "struct_halide_1_1_internal_1_1_code_gen___posix_1_1_allocation" ]
];