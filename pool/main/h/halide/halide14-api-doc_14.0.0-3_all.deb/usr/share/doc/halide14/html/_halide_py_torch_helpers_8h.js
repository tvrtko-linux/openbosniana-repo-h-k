var _halide_py_torch_helpers_8h =
[
    [ "HLPT_CHECK_CONTIGUOUS", "_halide_py_torch_helpers_8h.html#a16fc1a1ae010da51439218deb7caf952", null ],
    [ "HLPT_CHECK_CUDA", "_halide_py_torch_helpers_8h.html#a0852506f5f759f5a1436fd51d72499e4", null ],
    [ "HLPT_CHECK_DEVICE", "_halide_py_torch_helpers_8h.html#a021dcf785b07c17ec7710776cc80ad36", null ],
    [ "HL_PYTORCH_API_VERSION", "_halide_py_torch_helpers_8h.html#a03aba3a5c76317f659b36f53683f677f", null ],
    [ "HL_PT_DEFINE_TYPECHECK", "_halide_py_torch_helpers_8h.html#ac7dad3a4d0d77b2c489c6fa7947b1668", null ],
    [ "halide_cuda_device_interface", "_halide_py_torch_helpers_8h.html#a689eb700acb9fa665a118ec5adbcd3d4", null ],
    [ "get_dims", "_halide_py_torch_helpers_8h.html#a2329ce16deb25143eb6517bc29f78523", null ],
    [ "check_type", "_halide_py_torch_helpers_8h.html#ae53aca5d30ab4e127f7f09294bdf1cbe", null ],
    [ "AT_FORALL_SCALAR_TYPES_WITH_COMPLEX", "_halide_py_torch_helpers_8h.html#ab44292622ebe073cd40bf9e8f3050789", null ],
    [ "wrap", "_halide_py_torch_helpers_8h.html#a30702d65f443d0ee10ea682b823ace6d", null ],
    [ "wrap_cuda", "_halide_py_torch_helpers_8h.html#a66cd6cd0207d2ff2b17b21018ab04060", null ]
];