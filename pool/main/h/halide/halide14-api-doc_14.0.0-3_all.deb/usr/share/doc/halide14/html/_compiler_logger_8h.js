var _compiler_logger_8h =
[
    [ "Halide::Internal::CompilerLogger", "class_halide_1_1_internal_1_1_compiler_logger.html", "class_halide_1_1_internal_1_1_compiler_logger" ],
    [ "Halide::Internal::JSONCompilerLogger", "class_halide_1_1_internal_1_1_j_s_o_n_compiler_logger.html", "class_halide_1_1_internal_1_1_j_s_o_n_compiler_logger" ],
    [ "set_compiler_logger", "_compiler_logger_8h.html#a04fe83125b8be0309eb52d612706da1e", null ],
    [ "get_compiler_logger", "_compiler_logger_8h.html#adc3ec914dec8d50c32639aec31f38285", null ]
];