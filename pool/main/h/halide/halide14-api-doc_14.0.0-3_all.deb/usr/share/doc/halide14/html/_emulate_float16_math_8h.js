var _emulate_float16_math_8h =
[
    [ "is_float16_transcendental", "_emulate_float16_math_8h.html#a860e1020025973b3e49f515e57e126d5", null ],
    [ "lower_float16_transcendental_to_float32_equivalent", "_emulate_float16_math_8h.html#a4cd9ff6cdf658b71397ad57ada686d8f", null ],
    [ "float32_to_bfloat16", "_emulate_float16_math_8h.html#a7c0d9776355fa799b71816c0ab2e97e6", null ],
    [ "float32_to_float16", "_emulate_float16_math_8h.html#aa8bc1fe74ae6a148b8e7ee57f26c994d", null ],
    [ "float16_to_float32", "_emulate_float16_math_8h.html#a386f43e07f78c9b4be57358b183150ce", null ],
    [ "bfloat16_to_float32", "_emulate_float16_math_8h.html#adfc4c96649e436c9f67531779788b077", null ],
    [ "lower_float16_cast", "_emulate_float16_math_8h.html#a79be785c18917d142a0fa55c86ab3a87", null ]
];