var _simplify_specializations_8h =
[
    [ "simplify_specializations", "_simplify_specializations_8h.html#af4259425c64a0a9b25760e1c38123c13", null ]
];