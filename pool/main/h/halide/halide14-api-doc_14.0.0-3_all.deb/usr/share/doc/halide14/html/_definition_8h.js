var _definition_8h =
[
    [ "Halide::Internal::Definition", "class_halide_1_1_internal_1_1_definition.html", "class_halide_1_1_internal_1_1_definition" ],
    [ "Halide::Internal::Specialization", "struct_halide_1_1_internal_1_1_specialization.html", "struct_halide_1_1_internal_1_1_specialization" ]
];