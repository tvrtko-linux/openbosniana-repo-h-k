var _argument_8h =
[
    [ "Halide::ArgumentEstimates", "struct_halide_1_1_argument_estimates.html", "struct_halide_1_1_argument_estimates" ],
    [ "Halide::Argument", "struct_halide_1_1_argument.html", "struct_halide_1_1_argument" ]
];