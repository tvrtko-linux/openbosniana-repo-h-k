var _intrusive_ptr_8h =
[
    [ "Halide::Internal::RefCount", "class_halide_1_1_internal_1_1_ref_count.html", "class_halide_1_1_internal_1_1_ref_count" ],
    [ "Halide::Internal::IntrusivePtr< T >", "struct_halide_1_1_internal_1_1_intrusive_ptr.html", "struct_halide_1_1_internal_1_1_intrusive_ptr" ],
    [ "ref_count", "_intrusive_ptr_8h.html#a5a81310ace17087de643bc9a31efeba1", null ],
    [ "destroy", "_intrusive_ptr_8h.html#a11ca920b642ef490aeac2b4e864d6254", null ]
];