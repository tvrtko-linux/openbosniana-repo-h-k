var _hexagon_optimize_8h =
[
    [ "optimize_hexagon_shuffles", "_hexagon_optimize_8h.html#a9944b3d2cbfb0262a46b72ec515ab130", null ],
    [ "scatter_gather_generator", "_hexagon_optimize_8h.html#ad61e99863aa9fd2833e535440b632093", null ],
    [ "optimize_hexagon_instructions", "_hexagon_optimize_8h.html#a2278e803f98fc7b6e2b382ace8052975", null ],
    [ "native_deinterleave", "_hexagon_optimize_8h.html#a33a62ca468e067e12843e66cfa0fb33d", null ],
    [ "native_interleave", "_hexagon_optimize_8h.html#ad90cfab6d9f71632c8e4b712c7c400e8", null ],
    [ "is_native_deinterleave", "_hexagon_optimize_8h.html#aaf5ab59246b78ff782aceed334637e4c", null ],
    [ "is_native_interleave", "_hexagon_optimize_8h.html#aaa264f8cbd16a2062c62a731ef88a261", null ],
    [ "type_suffix", "_hexagon_optimize_8h.html#ada5b91e32017e38df05ae28f39a8b78c", null ],
    [ "type_suffix", "_hexagon_optimize_8h.html#a6edb350d77a097d5b1dce8ba2a9890cf", null ],
    [ "type_suffix", "_hexagon_optimize_8h.html#af6b52d96bb5a9b758cbaf557e35f4695", null ],
    [ "type_suffix", "_hexagon_optimize_8h.html#a93d49ddfaea99d3ddf07425940e67dd0", null ]
];