var _inject_host_dev_buffer_copies_8h =
[
    [ "call_extern_and_assert", "_inject_host_dev_buffer_copies_8h.html#a50f932b31fe791a7b2002b829c8e5364", null ],
    [ "inject_host_dev_buffer_copies", "_inject_host_dev_buffer_copies_8h.html#a9fa15ced2f13142e6c4b5e5f4649aa15", null ]
];