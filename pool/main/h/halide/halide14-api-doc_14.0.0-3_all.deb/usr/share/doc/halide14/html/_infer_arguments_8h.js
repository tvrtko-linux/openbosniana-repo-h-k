var _infer_arguments_8h =
[
    [ "Halide::Internal::InferredArgument", "struct_halide_1_1_internal_1_1_inferred_argument.html", "struct_halide_1_1_internal_1_1_inferred_argument" ],
    [ "infer_arguments", "_infer_arguments_8h.html#ac100c7daa45cf5358113252833505ee8", null ]
];