var _simplify___internal_8h =
[
    [ "Halide::Internal::Simplify", "class_halide_1_1_internal_1_1_simplify.html", "class_halide_1_1_internal_1_1_simplify" ],
    [ "Halide::Internal::Simplify::ExprInfo", "struct_halide_1_1_internal_1_1_simplify_1_1_expr_info.html", "struct_halide_1_1_internal_1_1_simplify_1_1_expr_info" ],
    [ "Halide::Internal::Simplify::VarInfo", "struct_halide_1_1_internal_1_1_simplify_1_1_var_info.html", "struct_halide_1_1_internal_1_1_simplify_1_1_var_info" ],
    [ "Halide::Internal::Simplify::ScopedFact", "struct_halide_1_1_internal_1_1_simplify_1_1_scoped_fact.html", "struct_halide_1_1_internal_1_1_simplify_1_1_scoped_fact" ],
    [ "LOG_EXPR_MUTATIONS", "_simplify___internal_8h.html#a2e3632d304508f244998bd11d820b40a", null ],
    [ "LOG_STMT_MUTATIONS", "_simplify___internal_8h.html#a6f8680f779da8df3185f8faa36def1e4", null ],
    [ "EVAL_IN_LAMBDA", "_simplify___internal_8h.html#a64c2e7b154bc5752bcc3ae645df4ebda", null ],
    [ "saturating_mul", "_simplify___internal_8h.html#ae177aea0a9e8d6350e795c1828fb32e1", null ]
];