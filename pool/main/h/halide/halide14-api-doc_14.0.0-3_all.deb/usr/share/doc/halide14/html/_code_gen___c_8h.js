var _code_gen___c_8h =
[
    [ "Halide::Internal::CodeGen_C", "class_halide_1_1_internal_1_1_code_gen___c.html", "class_halide_1_1_internal_1_1_code_gen___c" ],
    [ "Halide::Internal::CodeGen_C::Allocation", "struct_halide_1_1_internal_1_1_code_gen___c_1_1_allocation.html", "struct_halide_1_1_internal_1_1_code_gen___c_1_1_allocation" ]
];