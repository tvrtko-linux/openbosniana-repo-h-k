var _halide_py_torch_cuda_helpers_8h =
[
    [ "Halide::PyTorch::UserContext", "struct_halide_1_1_py_torch_1_1_user_context.html", "struct_halide_1_1_py_torch_1_1_user_context" ],
    [ "UserContext", "_halide_py_torch_cuda_helpers_8h.html#a6bc8d3b161c16443e58751d7aac06b4c", null ],
    [ "halide_cuda_acquire_context", "_halide_py_torch_cuda_helpers_8h.html#a134bcbac801c2208d3e7c452803232d2", null ],
    [ "halide_cuda_get_stream", "_halide_py_torch_cuda_helpers_8h.html#ad2feeb2438e7f4b44ccc5672b02c9cf5", null ],
    [ "halide_get_gpu_device", "_halide_py_torch_cuda_helpers_8h.html#adc511579a9ad82da9c1c611f008dd454", null ]
];