var _code_gen___targets_8h =
[
    [ "new_CodeGen_ARM", "_code_gen___targets_8h.html#ab446ce0e3637ad7e9006c93022200a4c", null ],
    [ "new_CodeGen_Hexagon", "_code_gen___targets_8h.html#a3f72a928bf2d91cfba4dfc1046cfa3ae", null ],
    [ "new_CodeGen_MIPS", "_code_gen___targets_8h.html#a8e001cf906847ea7712ecd808d29c0b3", null ],
    [ "new_CodeGen_PowerPC", "_code_gen___targets_8h.html#af78c445df369d9606ab540cff1a85ebd", null ],
    [ "new_CodeGen_RISCV", "_code_gen___targets_8h.html#a43fa119b1d9cb91d6b0a7a94e9fd17ec", null ],
    [ "new_CodeGen_X86", "_code_gen___targets_8h.html#a377069a6a413445be03054d91043de25", null ],
    [ "new_CodeGen_WebAssembly", "_code_gen___targets_8h.html#ab096d5698556bf5900c1a54f4f4919e2", null ]
];