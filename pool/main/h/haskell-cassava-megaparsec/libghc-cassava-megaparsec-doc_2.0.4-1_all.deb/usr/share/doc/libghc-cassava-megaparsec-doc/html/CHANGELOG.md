## Cassava Megaparsec 2.0.4

* Allow bytestring-0.11

## Cassava Megaparsec 2.0.3

* Exposing Internals

## Cassava Megaparsec 2.0.2

* Add suppport for `megaparsec-9.0.0`

## Cassava Megaparsec 2.0.1

* Add suppport for `megaparsec-8.0.0`

## Cassava Megaparsec 2.0.0

* Works with Megaparsec 7.

## Cassava Megaparsec 1.0.0

* Works with Megaparsec 6.

* Instead of `Cec` we have `ConversionError` as custom component of error
  messages.

## Cassava Megaparsec 0.1.0

* Initial release.
