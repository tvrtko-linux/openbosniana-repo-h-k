#include <stdio.h>
#include "constants.h"

int main()
{
    printf("%s\n", message());
    return 0;
}
