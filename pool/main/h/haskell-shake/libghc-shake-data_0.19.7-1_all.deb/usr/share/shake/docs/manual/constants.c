
char msg[] = "Hello Shake Users!";

char* message()
{
    return msg;
}
