word-wrap
=========

This library provides text-wrapping functionality.
