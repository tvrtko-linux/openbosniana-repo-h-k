#### 1.5.0.7

* Don't make docs executable, thanks to Jens Petersen

#### 1.5.0.6

* Improve performance, thanks to David Farrell

#### 1.5.0.5

* Add license field in cabal file

#### 1.5.0.4

* Allow utf8-string 1.

#### 1.5.0.3

* Use `network-uri` instead of `network` when possible
