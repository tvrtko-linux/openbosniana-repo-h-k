<?php

$user = array();

$user["uid"] = 10;
$user["gid"] = 2;
$user["grp"] = "user";
$user["username"] = "tester";
$user["firstname"] = "Super";
$user["lastname"] = "Mario";
$user["email"] = "test@sipcapture.org";
$user["lastvisit"] = "2016-02-03 12:22:10";

?>