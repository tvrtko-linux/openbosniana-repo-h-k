var searchData=
[
  ['write_5fblock_0',['write_block',['../group__rig__internal.html#ga7175a32b837ab389714c36bc614b2e33',1,'write_block(hamlib_port_t *p, const unsigned char *txbuffer, size_t count):&#160;iofunc.c'],['../group__rig__internal.html#ga7175a32b837ab389714c36bc614b2e33',1,'write_block(hamlib_port_t *p, const unsigned char *txbuffer, size_t count):&#160;iofunc.c']]]
];
