var searchData=
[
  ['c_0',['c',['../group__rig.html#gaf3cbfb0bd2a6ad6ed9770e8c790b5092',1,'confparams::@0::c()'],['../group__rig.html#ga3156938209d1e66a772ef348a6bc3ba8',1,'confparams::c()']]],
  ['caps_1',['caps',['../structs__rot.html#ab096f6b9099f265f928113a2155cccee',1,'s_rot']]],
  ['center_5ffreq_2',['center_freq',['../group__rig.html#ga6ec0cdc4991f07fb948fb561a6efce9a',1,'rig_spectrum_line']]],
  ['cfgparams_3',['cfgparams',['../structrot__caps.html#ae912ca92ef391761da9702486cbc8133',1,'rot_caps']]],
  ['channel_5fdesc_4',['channel_desc',['../group__rig.html#ga97f9c5a953070c18762c361a330b0aed',1,'channel::channel_desc()'],['../group__rig.html#gaff5afced9b17c2db4b9d602fe434dcd0',1,'channel_cap::channel_desc()']]],
  ['channel_5fnum_5',['channel_num',['../group__rig.html#gae81db5af8138a6c23fd0efd39d22035e',1,'channel']]],
  ['combostr_6',['combostr',['../group__rig.html#ga17655d781916435af283eb99926a04c1',1,'confparams::combostr()'],['../group__rig.html#ga94cbc344738e99a57d8dc7488134112d',1,'confparams::@0::@2::combostr()']]],
  ['comm_5fstate_7',['comm_state',['../structrot__state.html#abcd9e22e5521997da14fd0b3c5f60ecc',1,'rot_state']]],
  ['common_5fctcss_5flist_8',['common_ctcss_list',['../group__rig.html#gaaeb4dff5cb5d96d202d64bb3ff820fb1',1,'common_ctcss_list():&#160;tones.c'],['../group__rig.html#gaaeb4dff5cb5d96d202d64bb3ff820fb1',1,'common_ctcss_list():&#160;tones.c']]],
  ['common_5fdcs_5flist_9',['common_dcs_list',['../group__rig.html#ga9bcc479b0c4d37c684bd844e8d0f8225',1,'common_dcs_list():&#160;tones.c'],['../group__rig.html#ga9bcc479b0c4d37c684bd844e8d0f8225',1,'common_dcs_list():&#160;tones.c']]],
  ['copyright_10',['copyright',['../structrot__caps.html#a491f8273d7205f032fb53878b60c9121',1,'rot_caps']]],
  ['cs_11',['cs',['../group__rig.html#ga8801f1af62193fe0582d192bee4b05fb',1,'value_t']]],
  ['ctcss_5fsql_12',['ctcss_sql',['../group__rig.html#ga90d82f89435932702691b74d184b05af',1,'channel_cap::ctcss_sql()'],['../group__rig.html#ga5b3392d0d20f1e0f05973973102e0952',1,'channel::ctcss_sql()']]],
  ['ctcss_5ftone_13',['ctcss_tone',['../group__rig.html#ga0e7f820fb97af956d1cb4e78d8c62711',1,'channel::ctcss_tone()'],['../group__rig.html#gaae0757cbc99a765dc637c46ab20163fb',1,'channel_cap::ctcss_tone()']]],
  ['current_5fspeed_14',['current_speed',['../structrot__state.html#a8cd400fac42426799aee743a17718cd3',1,'rot_state']]]
];
