var searchData=
[
  ['news_0',['NEWS',['../NEWS.html',1,'index']]]
];
