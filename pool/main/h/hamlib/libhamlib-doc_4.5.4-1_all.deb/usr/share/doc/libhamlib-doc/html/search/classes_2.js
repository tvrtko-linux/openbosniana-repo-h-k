var searchData=
[
  ['filter_5flist_0',['filter_list',['../structfilter__list.html',1,'']]],
  ['freq_5frange_5flist_1',['freq_range_list',['../structfreq__range__list.html',1,'']]]
];
