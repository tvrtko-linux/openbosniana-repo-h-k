var searchData=
[
  ['parallel_2ec_0',['parallel.c',['../parallel_8c.html',1,'']]]
];
