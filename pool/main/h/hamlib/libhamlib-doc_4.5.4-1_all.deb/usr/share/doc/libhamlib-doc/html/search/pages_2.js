var searchData=
[
  ['copying_0',['COPYING',['../COPYING.html',1,'index']]],
  ['copying_2elib_1',['COPYING.LIB',['../COPYING_8LIB.html',1,'']]],
  ['cross_2dcompiling_20hamlib_20on_20linux_20for_20ms_20windows_2',['Cross-compiling Hamlib on Linux for MS Windows',['../Rdmewin.html',1,'index']]]
];
