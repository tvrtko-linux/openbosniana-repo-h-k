var searchData=
[
  ['width_0',['width',['../group__rig.html#ga8454958c407c160c10b4e6b3fbf3b19b',1,'filter_list::width()'],['../group__rig.html#ga79048336e70e6b6a88ac965a5960b8f8',1,'channel::width()'],['../group__rig.html#ga68e2380ca70b7220ccecedff32c6966a',1,'channel_cap::width()']]],
  ['write_5fdelay_1',['write_delay',['../structrot__caps.html#a53fca874b502528b50484f257aebcacd',1,'rot_caps']]]
];
