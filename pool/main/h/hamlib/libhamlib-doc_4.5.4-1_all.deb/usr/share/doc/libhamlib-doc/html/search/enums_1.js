var searchData=
[
  ['chan_5ftype_5ft_0',['chan_type_t',['../group__rig.html#gafe350c7813c36d532a69cfc851076544',1,'rig.h']]],
  ['cookie_5fe_1',['cookie_e',['../group__rig.html#ga8dfd03ebdcf1ad04c245987488356969',1,'rig.h']]]
];
