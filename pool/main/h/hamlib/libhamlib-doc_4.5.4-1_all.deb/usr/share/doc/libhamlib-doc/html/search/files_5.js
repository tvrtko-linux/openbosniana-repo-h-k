var searchData=
[
  ['locator_2ec_0',['locator.c',['../locator_8c.html',1,'']]]
];
