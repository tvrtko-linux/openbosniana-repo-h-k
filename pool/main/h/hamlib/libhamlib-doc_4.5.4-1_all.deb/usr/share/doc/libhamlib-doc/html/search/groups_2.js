var searchData=
[
  ['utility_20routines_20api_0',['Utility Routines API',['../group__utilities.html',1,'']]]
];
