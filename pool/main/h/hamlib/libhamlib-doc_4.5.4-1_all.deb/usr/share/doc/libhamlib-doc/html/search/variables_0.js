var searchData=
[
  ['ant_0',['ant',['../group__rig.html#ga92741740b6dd7336dd05c666a5e49455',1,'freq_range_list::ant()'],['../group__rig.html#gab6787f5c96f3dff40b81b942f4a40b69',1,'channel::ant()'],['../group__rig.html#gacbab8fe1ffe425aa3c5f0e303671bccf',1,'channel_cap::ant()']]],
  ['az_5foffset_1',['az_offset',['../structrot__state.html#a4ca5a5a8f8b6e90889823c30d0dff354',1,'rot_state']]]
];
