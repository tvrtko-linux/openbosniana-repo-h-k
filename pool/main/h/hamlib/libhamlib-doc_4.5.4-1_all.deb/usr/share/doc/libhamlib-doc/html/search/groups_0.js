var searchData=
[
  ['amplifier_20api_0',['Amplifier API',['../group__amplifier.html',1,'']]],
  ['amplifier_20internal_20api_1',['Amplifier Internal API',['../group__amp__internal.html',1,'']]]
];
