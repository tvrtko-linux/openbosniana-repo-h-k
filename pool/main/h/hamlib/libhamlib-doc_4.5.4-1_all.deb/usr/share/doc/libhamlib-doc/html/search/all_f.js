var searchData=
[
  ['qrb_0',['qrb',['../group__utilities.html#ga6aa2c2880cd0cc7d0b2772290dc58c42',1,'locator.c']]]
];
