var searchData=
[
  ['reset_5ft_0',['reset_t',['../group__rig.html#gae7c43560e6c8192e9dfc2d7291beb6d4',1,'rig.h']]],
  ['rig_5fconf_5fe_1',['rig_conf_e',['../group__rig.html#ga8119f43f0a0a1dc6131e76060b7d5afd',1,'rig.h']]],
  ['rig_5fdebug_5flevel_5fe_2',['rig_debug_level_e',['../group__rig.html#gabc9874ed89a3e2be9654e84ca89d4ef3',1,'rig.h']]],
  ['rig_5ferrcode_5fe_3',['rig_errcode_e',['../group__rig.html#ga7e8e83074ddca12769cf89c9c1b13ed0',1,'rig.h']]],
  ['rig_5fparm_5fe_4',['rig_parm_e',['../group__rig.html#ga65aa3ef089732affdaa7711d9b1190f5',1,'rig.h']]],
  ['rig_5fport_5fe_5',['rig_port_e',['../group__rig.html#gab18cde73941ae9fa91c522939b88609c',1,'rig.h']]],
  ['rig_5fspectrum_5fmode_5fe_6',['rig_spectrum_mode_e',['../group__rig.html#gafd5cba99fb309107ad96d54cf6ac036b',1,'rig.h']]],
  ['rig_5fstatus_5fe_7',['rig_status_e',['../group__rig.html#gaf50bd190a2d06e6ec0461ee325d1b1b5',1,'rig.h']]],
  ['rig_5ftype_5ft_8',['rig_type_t',['../group__rig.html#ga2e18e82e98297189b53de155b003c028',1,'rig.h']]],
  ['rot_5flevel_5fe_9',['rot_level_e',['../group__rotator.html#ga907ef8a10e96cf42b7c75720559b4477',1,'rotator.h']]],
  ['rot_5fparm_5fe_10',['rot_parm_e',['../group__rotator.html#ga2e710d85afe9253637ac5acf6c4d9007',1,'rotator.h']]],
  ['rot_5fstatus_5ft_11',['rot_status_t',['../group__rotator.html#ga25d0df79a68461214657a4032bc829a5',1,'rotator.h']]],
  ['rot_5ftype_5ft_12',['rot_type_t',['../group__rotator.html#gac4fda2e4759d1a1a97223be653ef1fde',1,'rotator.h']]],
  ['rptr_5fshift_5ft_13',['rptr_shift_t',['../group__rig.html#ga3d4b0361463446709dbedf865a5c08f8',1,'rig.h']]]
];
