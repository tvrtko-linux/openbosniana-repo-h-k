var searchData=
[
  ['amp_5fmodel_5ft_0',['amp_model_t',['../group__amplifier.html#ga6fc62f3be24699f73b6b1728e866ed60',1,'amplist.h']]],
  ['ant_5ft_1',['ant_t',['../group__rig.html#gae4c1cfd7388133a5f47c41bf808e5e5e',1,'rig.h']]],
  ['azimuth_5ft_2',['azimuth_t',['../group__rotator.html#gaee66360e60de15b90089ada115b68899',1,'rotator.h']]]
];
