var searchData=
[
  ['license_0',['LICENSE',['../LICENSE.html',1,'index']]],
  ['license_20for_20documentation_1',['License for Documentation',['../doclicense.html',1,'index']]]
];
