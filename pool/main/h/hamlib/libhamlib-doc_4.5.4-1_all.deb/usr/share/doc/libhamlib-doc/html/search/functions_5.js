var searchData=
[
  ['locator2longlat_0',['locator2longlat',['../group__utilities.html#ga1ced5a285b77a949bafe6e054a14a5c7',1,'locator.c']]],
  ['longlat2locator_1',['longlat2locator',['../group__utilities.html#ga55288388396d1ee61eba8c55e79be84a',1,'locator.c']]]
];
