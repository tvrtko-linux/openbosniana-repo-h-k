var indexSectionsWithContent =
{
  0: "abcdefghiklmnopqrstuvwx",
  1: "cefgmrstv",
  2: "acdeilmnprstu",
  3: "acdfhlmnpqrstuw",
  4: "abcdefghilmnoprstuvwx",
  5: "acefgprstv",
  6: "acdhmprsv",
  7: "r",
  8: "aru",
  9: "abcdhilnprt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "groups",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Modules",
  9: "Pages"
};

