var searchData=
[
  ['bank_5fnum_0',['bank_num',['../group__rig.html#ga75aef98bbcfd934917f71c8c4cd7d128',1,'channel::bank_num()'],['../group__rig.html#ga619d769b5fca939be264fdf83d3ff37c',1,'channel_cap::bank_num()']]]
];
