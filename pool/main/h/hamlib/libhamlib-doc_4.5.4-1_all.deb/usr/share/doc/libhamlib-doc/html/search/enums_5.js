var searchData=
[
  ['powerstat_5ft_0',['powerstat_t',['../group__rig.html#ga776e2823671df964c0b12559c53ef30c',1,'rig.h']]],
  ['ptt_5ft_1',['ptt_t',['../group__rig.html#ga95f3c5dc1ea1e120cad829b7151a8bfe',1,'rig.h']]],
  ['ptt_5ftype_5ft_2',['ptt_type_t',['../group__rig.html#ga413c6c1c4b39e9cf5aebe1a27a87afaf',1,'rig.h']]]
];
