var searchData=
[
  ['vfo_5fop_5ft_0',['vfo_op_t',['../group__rig.html#gaa401c44e04ae71daa354b555c8b3b626',1,'rig.h']]]
];
