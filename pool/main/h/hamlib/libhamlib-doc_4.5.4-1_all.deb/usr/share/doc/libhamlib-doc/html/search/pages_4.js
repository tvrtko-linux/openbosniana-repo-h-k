var searchData=
[
  ['hamlib_20api_20reference_0',['Hamlib API Reference',['../index.html',1,'']]],
  ['hamlib_20general_20purpose_20api_1',['Hamlib general purpose API',['../group__utilities.html',1,'']]]
];
