var searchData=
[
  ['amplifier_20interface_0',['Amplifier interface',['../group__amplifier.html',1,'']]],
  ['authors_1',['AUTHORS',['../AUTHORS.html',1,'index']]]
];
