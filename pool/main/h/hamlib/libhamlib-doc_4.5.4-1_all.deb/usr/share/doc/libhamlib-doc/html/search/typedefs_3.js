var searchData=
[
  ['freq_5frange_5ft_0',['freq_range_t',['../group__rig.html#ga9fdc3528ad92893189f659c7d926d270',1,'rig.h']]],
  ['freq_5ft_1',['freq_t',['../group__rig.html#ga8c607ed599b82703db7d4029c780af27',1,'rig.h']]]
];
