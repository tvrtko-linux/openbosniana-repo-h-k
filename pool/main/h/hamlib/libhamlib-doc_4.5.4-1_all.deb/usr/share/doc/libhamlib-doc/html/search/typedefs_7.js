var searchData=
[
  ['setting_5ft_0',['setting_t',['../group__rig.html#ga7486212309392422dbf465a046e02fe4',1,'rig.h']]],
  ['shortfreq_5ft_1',['shortfreq_t',['../group__rig.html#gaa77ae04534cd8138022c731df9547c6a',1,'rig.h']]]
];
