var searchData=
[
  ['usb_5fport_5fclose_0',['usb_port_close',['../group__rig__internal.html#ga6ca9c3a92adbfed3ab40ffcdbe962174',1,'usb_port_close(hamlib_port_t *port):&#160;usb_port.c'],['../group__rig__internal.html#ga6ca9c3a92adbfed3ab40ffcdbe962174',1,'usb_port_close(hamlib_port_t *p):&#160;usb_port.c']]],
  ['usb_5fport_5fopen_1',['usb_port_open',['../group__rig__internal.html#ga671bfd882064590cc68792a3e71b86cd',1,'usb_port_open(hamlib_port_t *port):&#160;usb_port.c'],['../group__rig__internal.html#ga671bfd882064590cc68792a3e71b86cd',1,'usb_port_open(hamlib_port_t *p):&#160;usb_port.c']]]
];
