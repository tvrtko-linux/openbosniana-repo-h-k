var searchData=
[
  ['val_0',['val',['../group__rig.html#gafd01c20a0be71ac067518c7a3571b7a5',1,'ext_list::val()'],['../group__rig.html#ga131aaef59c65a38fe9c53de04563f691',1,'cal_table::val()'],['../group__rig.html#gaad2a2c0a43c07d3575510565f7b51ac6',1,'cal_table::@3::val()'],['../group__rig.html#ga3c8c20739fd59348c506ba675c10b3c3',1,'cal_table_float::val()'],['../group__rig.html#ga1e19c4a36eba6c9276b884e423b6f96a',1,'cal_table_float::@4::val()']]],
  ['version_1',['version',['../structrot__caps.html#a84263ae149f58215089ca08a60df77c4',1,'rot_caps']]],
  ['vfo_2',['vfo',['../group__rig.html#gad7f2fd32bc75650f61097f98f2be4b84',1,'freq_range_list::vfo()'],['../group__rig.html#ga104a46cf0de3086d5df97ebd96e8e0b2',1,'channel::vfo()'],['../group__rig.html#gabb19b88426fd2d1660ccec956ba67e08',1,'channel_cap::vfo()']]]
];
