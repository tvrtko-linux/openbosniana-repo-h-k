var searchData=
[
  ['vfo_5ft_0',['vfo_t',['../group__rig.html#ga041ded6d4c53ea98e10834ff0d95a5a9',1,'rig.h']]]
];
