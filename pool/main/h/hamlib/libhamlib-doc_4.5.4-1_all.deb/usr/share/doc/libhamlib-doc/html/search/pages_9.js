var searchData=
[
  ['readme_20_28general_29_0',['README (general)',['../Rdme.html',1,'index']]],
  ['readme_2ebetatester_1',['README.betatester',['../Rdmebeta.html',1,'index']]],
  ['readme_2edeveloper_2',['README.developer',['../Rdmedevel.html',1,'index']]],
  ['readme_2efreqranges_3',['README.freqranges',['../Rdmefrq.html',1,'index']]],
  ['readme_2emulticast_4',['README.multicast',['../Rdmemulti.html',1,'index']]],
  ['readme_2eosx_5',['README.osx',['../Rdmeosx.html',1,'index']]],
  ['rig_20_28radio_29_20interface_6',['Rig (radio) interface',['../group__rig.html',1,'']]],
  ['rotator_20interface_7',['Rotator interface',['../group__rotator.html',1,'']]]
];
