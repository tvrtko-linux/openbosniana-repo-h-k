var searchData=
[
  ['xit_0',['xit',['../group__rig.html#ga6c1e6163390c7e4b36194b11c29fe9ec',1,'channel::xit()'],['../group__rig.html#gaf025db95f6d54e1861543814d64e020c',1,'channel_cap::xit()']]]
];
