var searchData=
[
  ['f_0',['f',['../group__rig.html#ga5711002b44078a892f38d1b3a8d40f36',1,'value_t']]],
  ['filter_5flist_1',['filter_list',['../structfilter__list.html',1,'']]],
  ['flags_2',['flags',['../group__rig.html#gac0459c265979b8918aa64f1fff9e88ae',1,'channel::flags()'],['../group__rig.html#gadd0b683bc1b0c704e0f7b6912063f2fe',1,'channel_cap::flags()']]],
  ['foreach_5fopened_5frot_3',['foreach_opened_rot',['../group__rot__internal.html#ga4b291e4652cc03bf6923968f7b78ab65',1,'rotator.c']]],
  ['freq_4',['freq',['../group__rig.html#ga827c8e4701337ada5f71e442617c44ea',1,'channel::freq()'],['../group__rig.html#ga9ad222ed160f10766f22558c12cd4d8d',1,'channel_cap::freq()']]],
  ['freq_5frange_5flist_5',['freq_range_list',['../structfreq__range__list.html',1,'']]],
  ['freq_5frange_5ft_6',['freq_range_t',['../group__rig.html#ga9fdc3528ad92893189f659c7d926d270',1,'rig.h']]],
  ['freq_5ft_7',['freq_t',['../group__rig.html#ga8c607ed599b82703db7d4029c780af27',1,'rig.h']]],
  ['freqfmt_8',['FREQFMT',['../group__rig.html#ga3a2e8c5575126344db6582f6730e4c2d',1,'rig.h']]],
  ['from_5fbcd_9',['from_bcd',['../group__rig__internal.html#ga6962d8e1a8a045ae3e90418e2c41f877',1,'from_bcd(const unsigned char bcd_data[], unsigned bcd_len):&#160;misc.c'],['../group__rig__internal.html#ga6962d8e1a8a045ae3e90418e2c41f877',1,'from_bcd(const unsigned char bcd_data[], unsigned bcd_len):&#160;misc.c']]],
  ['from_5fbcd_5fbe_10',['from_bcd_be',['../group__rig__internal.html#ga6d1aef116216692e30d09db1cfb94db5',1,'from_bcd_be(const unsigned char bcd_data[], unsigned bcd_len):&#160;misc.c'],['../group__rig__internal.html#ga6d1aef116216692e30d09db1cfb94db5',1,'from_bcd_be(const unsigned char bcd_data[], unsigned bcd_len):&#160;misc.c']]],
  ['frontamp_5fget_5fconf2_11',['frontamp_get_conf2',['../group__amp__internal.html#gac6537c8784de59baf382eb78c279edfe',1,'amp_conf.c']]],
  ['frontamp_5fset_5fconf_12',['frontamp_set_conf',['../group__amp__internal.html#ga14e5e0b8799208c844548c6592b0eb16',1,'amp_conf.c']]],
  ['frontrot_5fget_5fconf_13',['frontrot_get_conf',['../group__rot__internal.html#ga30b15f6d526d32e084953b01308867c8',1,'frontrot_get_conf(ROT *rot, token_t token, char *val, int val_len):&#160;rot_conf.c'],['../group__rot__internal.html#ga30b15f6d526d32e084953b01308867c8',1,'frontrot_get_conf(ROT *rot, token_t token, char *val, int val_len):&#160;rot_conf.c']]],
  ['frontrot_5fset_5fconf_14',['frontrot_set_conf',['../group__rot__internal.html#gab2db9f73b3c713178560934b93c0a2f3',1,'frontrot_set_conf(ROT *rot, token_t token, const char *val):&#160;rot_conf.c'],['../group__rot__internal.html#gab2db9f73b3c713178560934b93c0a2f3',1,'frontrot_set_conf(ROT *rot, token_t token, const char *val):&#160;rot_conf.c']]],
  ['full_5fctcss_5flist_15',['full_ctcss_list',['../group__rig.html#gaeaebf7b90a6d509d7d47d1141702b802',1,'full_ctcss_list():&#160;tones.c'],['../group__rig.html#gaeaebf7b90a6d509d7d47d1141702b802',1,'full_ctcss_list():&#160;tones.c']]],
  ['full_5fdcs_5flist_16',['full_dcs_list',['../group__rig.html#ga27a78b86373edc3a675bf7c85a173425',1,'full_dcs_list():&#160;tones.c'],['../group__rig.html#ga27a78b86373edc3a675bf7c85a173425',1,'full_dcs_list():&#160;tones.c']]],
  ['funcs_17',['funcs',['../group__rig.html#gaa5b0bb92154359f45d8e66d2ae641233',1,'channel_cap::funcs()'],['../group__rig.html#ga342e1d4d5684cffb3eb57f92011176c9',1,'channel::funcs()']]]
];
