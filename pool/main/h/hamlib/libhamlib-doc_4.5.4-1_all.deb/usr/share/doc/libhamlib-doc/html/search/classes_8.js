var searchData=
[
  ['value_5ft_0',['value_t',['../unionvalue__t.html',1,'']]]
];
