import Distribution.Make
main = defaultMain
