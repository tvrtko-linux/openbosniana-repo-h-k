# These values will be populated by bin/hydrapaper

APPLICATIONS_DIR = '@applications_dir@'
DAEMON_BUILD_ENABLED = True
