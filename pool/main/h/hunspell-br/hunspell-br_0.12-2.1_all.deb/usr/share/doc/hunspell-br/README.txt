Hunspell Breton (br_FR) dictionary
Copyright (c) 2001-2014 Korvigelloù An Drouizig
drouizig@drouizig.org - http://www.drouizig.org	

Version 0.12 - release date: 2014-01-29
--
This dictionary is based on the original Breton 
wordlist created by Philippe Basciano-Le Gall for 
Korvigelloù an Drouizig. It is covered by the LGPL, 
MPL and GPL licenses. The affix file has been heavily 
modified by Michel "Boulc'hurun" Nedeleg.

Thanks to both authors for there wonderful work !
