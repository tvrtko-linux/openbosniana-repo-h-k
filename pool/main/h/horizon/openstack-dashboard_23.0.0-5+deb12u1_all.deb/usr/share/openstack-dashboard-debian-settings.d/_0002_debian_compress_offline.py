# To enable compressing offline set COMPRESS_OFFLINE = True
COMPRESS_OFFLINE = True
