# To specify path for static files, set STATIC_ROOT = "/path/to/static/files"
STATIC_ROOT = "/var/lib/openstack-dashboard/static/"
