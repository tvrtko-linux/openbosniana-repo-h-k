# To specify path for webroot, set WEBROOT = "/webroot"
WEBROOT = "/"
