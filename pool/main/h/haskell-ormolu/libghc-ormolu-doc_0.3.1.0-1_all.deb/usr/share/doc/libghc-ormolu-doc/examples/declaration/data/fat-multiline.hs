module Main where

-- | Something.

data Foo
  = Foo Int
        Int
    -- ^ Foo
  | Bar Bool
        Bool
    -- ^ Bar
