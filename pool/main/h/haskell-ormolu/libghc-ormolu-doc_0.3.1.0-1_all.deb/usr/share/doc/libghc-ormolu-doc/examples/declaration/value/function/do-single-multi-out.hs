foo = do
  ( bar
      baz
    )
