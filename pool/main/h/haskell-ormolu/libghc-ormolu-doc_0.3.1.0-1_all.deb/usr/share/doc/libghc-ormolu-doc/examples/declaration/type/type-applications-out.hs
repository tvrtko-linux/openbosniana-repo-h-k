{-# LANGUAGE TypeApplications #-}

type P = K @Bool @(Bool :: *) 'True 'False
