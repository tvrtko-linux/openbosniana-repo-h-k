_ = _
  where
    _ = [_ | let _ = _]
