module Main where

-- | Foo.

data Foo =
  Foo Int Int
  -- ^ Something
  | Bar Char
        Char
  -- ^ Something else
