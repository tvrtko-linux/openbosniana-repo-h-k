foo :: Int -> Int -> Int -> Int
foo (Foo g o)
    (Bar
       x y) z = x
