data Optimisation = PETransform | GeneralisedNatHack -- ^ partial eval and associated transforms
  deriving (Show, Eq, Generic)
