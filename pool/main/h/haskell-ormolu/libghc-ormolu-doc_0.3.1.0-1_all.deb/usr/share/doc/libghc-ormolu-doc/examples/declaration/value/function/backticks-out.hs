foo x y = x `bar` y
