infix 0 <?>
infix 9 <^-^>
