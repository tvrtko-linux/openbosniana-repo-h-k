module Main where

-- | Documentation.

data family Array e
