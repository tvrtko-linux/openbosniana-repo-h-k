foo =
  let

    x = 10

    y = 11
    z = 12

  in x + y + z
