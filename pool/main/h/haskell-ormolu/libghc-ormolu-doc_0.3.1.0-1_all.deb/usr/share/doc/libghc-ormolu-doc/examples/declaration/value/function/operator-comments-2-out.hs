x =
  y
    ++ f g -- commentA
    -- commentB
    -- commentC
