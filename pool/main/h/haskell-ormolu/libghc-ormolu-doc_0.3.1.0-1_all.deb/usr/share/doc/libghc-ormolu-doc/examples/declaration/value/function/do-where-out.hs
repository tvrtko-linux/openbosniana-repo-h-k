f :: Maybe Int
f = do
  return c
  where
    c = 0
