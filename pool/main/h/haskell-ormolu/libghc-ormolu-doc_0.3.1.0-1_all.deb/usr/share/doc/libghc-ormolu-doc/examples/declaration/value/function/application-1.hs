main =
  do
    x
    y
   z

main =
  case foo of
    x -> a
   foo a b

main = do
  if x then y else z
 foo a b
