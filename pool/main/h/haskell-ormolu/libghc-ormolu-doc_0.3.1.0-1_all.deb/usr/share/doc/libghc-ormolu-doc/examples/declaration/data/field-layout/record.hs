module Main where

-- | Foo.

data Foo = Foo
  { foo :: Foo Int Int
    -- ^ Something
  , bar :: Bar Char
           Char
    -- ^ Something else
  }
