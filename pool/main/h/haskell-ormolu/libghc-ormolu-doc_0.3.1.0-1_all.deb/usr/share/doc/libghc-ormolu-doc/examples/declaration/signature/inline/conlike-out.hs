foo :: Int
foo = 5
{-# INLINE CONLIKE foo #-}

bar :: Int
bar = 6
{-# INLINE CONLIKE bar #-}
