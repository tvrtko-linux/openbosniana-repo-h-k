module Main where

-- | Documentation.
type family Elem c :: Type
