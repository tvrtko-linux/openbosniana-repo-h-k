module Main where

-- | Foo!
class Foo a where
-- | Bar!
class Bar a
