x  =
      y ++ -- commentA
-- commentB
      f g -- commentC
