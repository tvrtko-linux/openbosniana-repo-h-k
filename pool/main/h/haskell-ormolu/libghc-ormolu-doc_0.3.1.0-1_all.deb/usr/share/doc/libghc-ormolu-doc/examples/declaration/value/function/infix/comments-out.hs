main =
  bar $ -- bar
    baz -- baz

bar $
  {- foo
   -}
  bar
