foo = 5 :: Int

bar =
  5 ::
    Int
