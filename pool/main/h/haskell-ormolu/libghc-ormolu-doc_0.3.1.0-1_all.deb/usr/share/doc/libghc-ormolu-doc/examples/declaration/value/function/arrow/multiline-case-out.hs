{-# LANGUAGE Arrows #-}

f = proc x -> do
  x <-
    case x of X -> x
      -<
        y
  a -< b
