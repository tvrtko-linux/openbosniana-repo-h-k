{-# LANGUAGE NegativeLiterals #-}

foo = - 1

foo = -1

foo = -x

foo = -x

pat = \case -1 -> 1

pat = \case - 1 -> 1
