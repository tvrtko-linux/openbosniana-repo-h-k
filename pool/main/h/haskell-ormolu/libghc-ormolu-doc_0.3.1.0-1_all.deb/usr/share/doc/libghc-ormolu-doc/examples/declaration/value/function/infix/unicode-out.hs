main = print ('a' → 'a')
  where
    (→) = (,)
