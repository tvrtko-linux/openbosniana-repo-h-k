data X
  = B
      !Int
      -- ^ y
      C
