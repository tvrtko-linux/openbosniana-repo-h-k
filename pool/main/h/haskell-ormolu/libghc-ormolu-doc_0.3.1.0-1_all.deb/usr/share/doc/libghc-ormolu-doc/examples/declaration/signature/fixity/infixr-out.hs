infixr 8 `Foo`

infixr 0 ***, &&&
