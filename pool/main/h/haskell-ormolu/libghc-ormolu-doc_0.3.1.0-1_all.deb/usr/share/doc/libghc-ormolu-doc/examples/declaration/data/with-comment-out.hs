data A
  = B -- C
  | -- D
    E
