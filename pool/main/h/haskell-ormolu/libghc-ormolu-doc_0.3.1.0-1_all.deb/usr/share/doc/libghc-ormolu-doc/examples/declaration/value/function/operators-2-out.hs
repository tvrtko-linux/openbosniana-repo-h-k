foo n
  | x || y && z || n ** x
      || x && n =
    42
