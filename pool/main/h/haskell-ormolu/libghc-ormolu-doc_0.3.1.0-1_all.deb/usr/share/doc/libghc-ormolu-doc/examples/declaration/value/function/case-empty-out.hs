absurd x = case x of {}
absurd = \case {}
absurd x = case x of {}
absurd = \case {}

foo = case () of {} 1
