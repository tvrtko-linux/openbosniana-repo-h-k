instance Typeable Int
instance Generic Int where
