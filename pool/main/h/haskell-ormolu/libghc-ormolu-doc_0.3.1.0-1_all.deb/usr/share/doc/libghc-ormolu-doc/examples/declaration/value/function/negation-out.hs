foo :: Int
foo = (-2)

bar :: Int
bar = -2

baz :: Int
baz = -2

neg :: Int -> Int
neg x = (-x)
neg x = -x
neg x = -x

weird :: Int -> Int -> Int
weird x y = x - y

pat = \case -1 -> 1

pat = \case -1 -> 1
