module Main where

-- | Something.
data Foo
  = -- | Foo
    Foo
      Int
      Int
  | -- | Bar
    Bar
      Bool
      Bool
