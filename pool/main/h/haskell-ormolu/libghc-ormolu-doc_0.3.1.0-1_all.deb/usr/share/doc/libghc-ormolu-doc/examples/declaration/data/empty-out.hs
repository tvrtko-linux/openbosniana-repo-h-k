{-# LANGUAGE EmptyDataDecls #-}

data Foo
