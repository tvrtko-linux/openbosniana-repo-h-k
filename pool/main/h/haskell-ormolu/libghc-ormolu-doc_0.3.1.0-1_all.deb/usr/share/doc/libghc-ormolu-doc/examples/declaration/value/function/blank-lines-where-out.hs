foo = x + y + z
  where
    x = 10

    y = 11
    z = 12
