data Foo
  = -- | Bar
    Bar
      Field1 -- ^ Field 1
      Field2 -- ^ Field 2
