default (Int, Foo, Bar)

default
  ( Int,
    Foo,
    Bar
  )
