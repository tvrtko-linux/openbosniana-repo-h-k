class Num a where
  (+) :: a -> a -> a

class Num a where


  (+) :: a -> a -> a
