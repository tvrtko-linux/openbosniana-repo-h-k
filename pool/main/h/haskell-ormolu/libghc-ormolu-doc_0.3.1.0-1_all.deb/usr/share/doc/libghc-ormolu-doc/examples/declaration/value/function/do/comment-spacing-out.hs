foo = do
  bar
  -- foo
  baz

  -- foo
  quux
