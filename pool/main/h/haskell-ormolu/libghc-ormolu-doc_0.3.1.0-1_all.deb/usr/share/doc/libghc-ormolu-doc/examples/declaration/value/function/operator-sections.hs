foo = (0  +)
bar = ( <> "hello" )
baz =
    ( 1 * 2
      + )
    ( *
      3 ^ 5)

quux = (,) <$> foo <$> bar
