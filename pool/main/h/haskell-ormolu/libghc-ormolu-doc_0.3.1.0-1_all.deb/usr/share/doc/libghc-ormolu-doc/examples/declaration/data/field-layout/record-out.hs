module Main where

-- | Foo.
data Foo = Foo
  { -- | Something
    foo :: Foo Int Int,
    -- | Something else
    bar ::
      Bar
        Char
        Char
  }
