data Optimisation
  = PETransform
  | -- | partial eval and associated transforms
    GeneralisedNatHack
  deriving (Show, Eq, Generic)
