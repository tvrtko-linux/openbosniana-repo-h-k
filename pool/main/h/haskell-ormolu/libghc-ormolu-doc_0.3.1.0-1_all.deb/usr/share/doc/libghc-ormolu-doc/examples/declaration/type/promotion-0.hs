type Foo = Cluster '[ 'NodeCore, 'NodeRelay', 'NodeEdge ]

type Query = Query '[] '[] DB '[ 'NotNull 'PGint4] (RowPG RawElementData)

data T = T' | T'T

type S0 = ' T'

type S1 = ' T'T
