longFunctionName
  :: a
  -> b
  -> c
  -> d
  -> (a, b, c, d)
