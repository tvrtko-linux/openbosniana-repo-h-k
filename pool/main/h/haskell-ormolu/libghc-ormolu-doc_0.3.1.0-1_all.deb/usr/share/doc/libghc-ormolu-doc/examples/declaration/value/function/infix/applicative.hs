f =
  Foo <$> bar
      <*> baz
      <*> baz'
