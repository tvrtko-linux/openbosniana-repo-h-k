type family Id a = r | r -> a

type family F a b c = d | d -> a c b
