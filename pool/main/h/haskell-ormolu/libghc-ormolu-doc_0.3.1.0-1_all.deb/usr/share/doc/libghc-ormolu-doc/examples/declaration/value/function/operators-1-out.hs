foo =
  f
    . g
    =<< h . i
