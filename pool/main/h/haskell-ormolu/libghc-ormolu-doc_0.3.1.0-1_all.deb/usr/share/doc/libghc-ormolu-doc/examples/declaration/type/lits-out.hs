type A = "foo"

type B =
  "foo\
  \bar" ->
  ()
