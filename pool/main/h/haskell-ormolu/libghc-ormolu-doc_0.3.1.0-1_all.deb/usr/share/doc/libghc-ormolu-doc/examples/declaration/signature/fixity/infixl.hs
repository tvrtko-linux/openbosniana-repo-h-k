infixl 8 ***
infixl 0 $, *, +, &&, **
