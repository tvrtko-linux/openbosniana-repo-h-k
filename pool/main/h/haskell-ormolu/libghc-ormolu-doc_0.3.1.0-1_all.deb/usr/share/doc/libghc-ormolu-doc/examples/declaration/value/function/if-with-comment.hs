foo =
  if undefined
    -- then comment
    then undefined
    -- else comment
    else
      do
        undefined
