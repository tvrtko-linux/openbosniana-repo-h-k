module Main where

-- | Something.

data Foo = Foo { fooX :: Int , fooY :: Int }
  deriving (Eq, Show)
