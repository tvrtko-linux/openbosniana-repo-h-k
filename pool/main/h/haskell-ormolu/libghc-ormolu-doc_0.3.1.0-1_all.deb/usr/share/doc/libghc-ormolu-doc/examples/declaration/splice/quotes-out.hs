foo = ''R

bar = 'foo

bar' = 'foo_bar

baz = ''(:#)

baz' = ''(Foo.Bar.:#)

equals = ''(==)

unit = ''()

list = ''[]

quolified = ''Semigroup.Option
