module Main where

-- | Documentation.
type family F a b :: Type -> Type
