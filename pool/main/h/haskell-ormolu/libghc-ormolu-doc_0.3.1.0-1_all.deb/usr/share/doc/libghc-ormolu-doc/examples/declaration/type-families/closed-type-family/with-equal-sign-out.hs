type family TF a b = result where
  TF a b = Int
