{-# COMPLETE A, B, C :: Foo #-}

{-# COMPLETE A, B #-}

{-# COMPLETE
  A,
  B,
  C ::
    Foo
  #-}
