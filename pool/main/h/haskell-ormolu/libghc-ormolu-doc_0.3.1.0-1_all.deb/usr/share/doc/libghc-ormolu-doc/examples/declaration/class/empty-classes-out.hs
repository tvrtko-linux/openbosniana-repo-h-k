module Main where

-- | Foo!
class Foo a

-- | Bar!
class Bar a
