module Main where

-- | Foo.
data Foo
  = -- | Something
    Foo Int Int
  | -- | Something else
    Bar
      Char
      Char
