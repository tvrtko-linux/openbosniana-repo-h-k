quux = something $ do
  foo
  case x of
    1 -> 10
    2 -> 20
  bar
  if something
  then x
  else y
  baz
