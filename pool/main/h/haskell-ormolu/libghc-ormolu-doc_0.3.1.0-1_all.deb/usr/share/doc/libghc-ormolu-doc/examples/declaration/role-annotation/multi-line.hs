type role
  D phantom nominal

type
  role
    E
      _
    nominal

type
    role
      E
        _
      nominal
    phantom
