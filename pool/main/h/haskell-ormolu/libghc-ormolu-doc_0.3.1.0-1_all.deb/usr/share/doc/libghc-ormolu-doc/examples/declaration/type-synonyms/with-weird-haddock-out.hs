type Elims =
  -- | eliminations ordered left-to-right.
  [Elim]
