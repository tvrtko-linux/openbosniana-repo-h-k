foo
  bar =
    body
