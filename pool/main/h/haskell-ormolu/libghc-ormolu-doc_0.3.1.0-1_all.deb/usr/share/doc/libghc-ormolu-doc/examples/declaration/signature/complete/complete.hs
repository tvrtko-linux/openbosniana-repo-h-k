{-#   ComPlETe       A  , B, C::         Foo

  #-}

{-#    COMPLETE          A , B
   #-}

{-#   ComPlETE
      A  , 
    B, C


    ::         Foo#-}
