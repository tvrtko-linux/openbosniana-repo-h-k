foo :: Int -> Int
foo 5 = 10
foo _ = 12
