module Main where

-- | And here we have 'Foo'.

data Foo = Foo | Bar Int | Baz
  deriving (Eq, Show)
