type family a ! b
type family a . b
