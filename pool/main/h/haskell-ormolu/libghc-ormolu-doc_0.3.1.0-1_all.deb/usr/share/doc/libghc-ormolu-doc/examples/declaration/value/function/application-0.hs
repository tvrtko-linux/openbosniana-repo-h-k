foo =
  f1
    p1
    p2 p3

foo' = f2 p1
  p2
  p3

foo'' =
  f3 p1 p2
    p3
