foo, bar :: Int
foo = 1
bar = 2

a, b, c :: Int
a = 1
b = 2
c = 3

foo,
  bar,
  baz ::
    Int
bar = 2
baz = 3
