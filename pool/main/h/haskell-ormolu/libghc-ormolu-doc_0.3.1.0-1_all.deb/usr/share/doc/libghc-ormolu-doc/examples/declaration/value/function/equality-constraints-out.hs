foo :: (a ~ b) => a -> b -> Int
foo = undefined
