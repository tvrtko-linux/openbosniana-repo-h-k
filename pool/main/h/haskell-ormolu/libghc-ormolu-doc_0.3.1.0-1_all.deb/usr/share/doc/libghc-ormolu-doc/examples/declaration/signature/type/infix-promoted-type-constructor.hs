fun1 :: Def ('[ Ref s (Stored Uint32), IBool] 'T.:-> IBool)
fun2 :: Def ('[ Ref s (Stored Uint32), IBool] ':-> IBool)
