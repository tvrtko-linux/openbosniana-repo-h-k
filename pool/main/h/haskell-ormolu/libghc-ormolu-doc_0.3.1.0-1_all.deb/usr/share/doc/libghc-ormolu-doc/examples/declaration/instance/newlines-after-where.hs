instance Num X where
  (+) = undefined

instance Num Y where


  (+) = undefined
