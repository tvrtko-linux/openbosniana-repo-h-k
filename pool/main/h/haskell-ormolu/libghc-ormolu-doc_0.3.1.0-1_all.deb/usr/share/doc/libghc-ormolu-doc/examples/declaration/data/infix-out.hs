data Foo a b = a `Foo` b
