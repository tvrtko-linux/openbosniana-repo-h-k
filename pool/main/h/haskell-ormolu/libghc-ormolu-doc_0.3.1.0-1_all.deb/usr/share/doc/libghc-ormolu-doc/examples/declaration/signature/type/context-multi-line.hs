functionName
  :: ( C1
     , C2
     , C3
     )
  => a
  -> b
  -> c
  -> d
  -> (a, b, c, d)
