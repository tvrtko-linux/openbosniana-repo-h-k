foo =
  if undefined
    then -- then comment
      undefined
    else -- else comment

    do
      undefined
