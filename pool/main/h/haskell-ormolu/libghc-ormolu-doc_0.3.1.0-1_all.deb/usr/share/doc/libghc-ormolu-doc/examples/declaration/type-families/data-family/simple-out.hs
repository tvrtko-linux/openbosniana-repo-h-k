module Main where

-- | Documentation.
data family GMap k :: Type -> Type
