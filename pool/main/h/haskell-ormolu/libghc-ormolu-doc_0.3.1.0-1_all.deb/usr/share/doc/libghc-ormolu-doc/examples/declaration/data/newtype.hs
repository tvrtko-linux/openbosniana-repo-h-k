module Main where

-- | Something.

newtype Foo = Foo Int
  deriving (Eq, Show)
