foo = do (bar
          baz)
