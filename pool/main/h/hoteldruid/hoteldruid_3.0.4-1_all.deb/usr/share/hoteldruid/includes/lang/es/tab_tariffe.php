<?php

switch ($messaggio) {

case "Tariffe":  				$messaggio = "Tarifas"; break;
case "Tabella tariffe del":  			$messaggio = "Tabla de tarifas del"; break;
case "Torna indietro":  			$messaggio = "Volver atrás"; break;
case "tariffa":  				$messaggio = "tarifa"; break;
case "aggiungi":  				$messaggio = "añadir"; break;
case "settimane":  				$messaggio = "semanas"; break;
case "giorni":  				$messaggio = "días"; break;
case "la nuova foto è stata aggiunta":  	$messaggio = "la nueva foto ha sido añadida"; break;
case "l'url della foto è sbagliata":  		$messaggio = "la url de la foto está equivocada"; break;
case "foto eliminata":  			$messaggio = "foto eliminada"; break;
case "foto della tariffa":  			$messaggio = "fotos de la tarifa"; break;
case "elimina":  				$messaggio = "eliminar"; break;
case "url di una nuova foto":  			$messaggio = "url de una nueva foto"; break;
case "descrizione della tariffa":  		$messaggio = "descripción de la tarifa"; break;
case "modifica":  				$messaggio = "modificar"; break;
case "aggiornata":  				$messaggio = "modificada"; break;
case "commento":  				$messaggio = "comentario"; break;
case "commento della foto":  			$messaggio = "comentario de la foto"; break;
case "aggiornato":  				$messaggio = "modificado"; break;
case "disponibilità":  				$messaggio = "disponibilidad"; break;
case "permanenza min.":  			$messaggio = "estadía mín."; break;
case "permanenza mass.":  			$messaggio = "estadía máx."; break;
case "mostra disponibilità":  			$messaggio = "mostrar disponibilidad"; break;
case "mostra permanenza minima":  		$messaggio = "mostrar estadía mínima"; break;
case "raggruppa le date":  			$messaggio = "agurpar las fechas"; break;
case "in modo predefinito per la tariffa":  	$messaggio = "por defecto para la tarifa"; break;
case "Numero di persone predefinito per la tariffa":	$messaggio = "Número de personas por defecto para la tarifa"; break;
case "Modifica i valori":  			$messaggio = "Modificar los valores"; break;
case "non definito":  				$messaggio = "no definido"; break;
case "Fai l'upload di":  			$messaggio = "Hacer el upload de"; break;
case "Eesiste già un file chiamato":  		$messaggio = "Ya existe un archivo llamado"; break;
case "La dimensione del file eccede il limite":	$messaggio = "La dimensióndel archivo supera el límite"; break;
case "Attenzione: l'indirizzo usato potrà essere raggiungibile solo da questo computer":	$messaggio = "Atención: la dirección utilizada podrá ser alcanzada solo desde este ordenador"; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;

} # fine switch ($messaggio)

?>