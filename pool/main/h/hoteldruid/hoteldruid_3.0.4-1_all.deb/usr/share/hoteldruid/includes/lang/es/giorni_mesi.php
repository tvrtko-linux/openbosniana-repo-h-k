<?php

switch ($messaggio) {

case " Do":  					$messaggio = " Do"; break;
case " Lu":  					$messaggio = " Lu"; break;
case " Ma":  					$messaggio = " Ma"; break;
case " Me":  					$messaggio = " Mi"; break;
case " Gi":  					$messaggio = " Ju"; break;
case " Ve":  					$messaggio = " Vi"; break;
case " Sa":  					$messaggio = " Sá"; break;
case "Gen":  					$messaggio = "Ene"; break;
case "Feb":  					$messaggio = "Feb"; break;
case "Mar":  					$messaggio = "Mar"; break;
case "Apr":  					$messaggio = "Abr"; break;
case "Mag":  					$messaggio = "May"; break;
case "Giu":  					$messaggio = "Jun"; break;
case "Lug":  					$messaggio = "Jul"; break;
case "Ago":  					$messaggio = "Ago"; break;
case "Set":  					$messaggio = "Sep"; break;
case "Ott":  					$messaggio = "Oct"; break;
case "Nov":  					$messaggio = "Nov"; break;
case "Dic":  					$messaggio = "Dic"; break;
case "Gennaio":  				$messaggio = "Enero"; break;
case "Febbraio":  				$messaggio = "Febrero"; break;
case "Marzo":  					$messaggio = "Marzo"; break;
case "Aprile":  				$messaggio = "Abril"; break;
case "Maggio":  				$messaggio = "Mayo"; break;
case "Giugno":  				$messaggio = "Junio"; break;
case "Luglio":  				$messaggio = "Julio"; break;
case "Agosto":  				$messaggio = "Agosto"; break;
case "Settembre":  				$messaggio = "Septiembre"; break;
case "Ottobre":  				$messaggio = "Octubre"; break;
case "Novembre":  				$messaggio = "Noviembre"; break;
case "Dicembre":  				$messaggio = "Diciembre"; break;
case "Domenica":  				$messaggio = "Domingo"; break;
case "Lunedì":  				$messaggio = "Lunes"; break;
case "Martedì":  				$messaggio = "Martes"; break;
case "Mercoledì":  				$messaggio = "Miercoles"; break;
case "Giovedì":  				$messaggio = "Jueves"; break;
case "Venerdì":  				$messaggio = "Viernes"; break;
case "Sabato":  				$messaggio = "Sábado"; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;

} # fine switch ($messaggio)

?>
