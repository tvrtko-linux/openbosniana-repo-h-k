<?php

switch ($messaggio) {

case "Disponibilità":  				$messaggio = "Availability"; break;
case "Le date sono sbagliate":  		$messaggio = "Dates are wrong"; break;
case "persone":  				$messaggio = "people"; break;
case "La settimana dal":  			$messaggio = "The week from"; break;
case "Il giorno dal":  				$messaggio = "The day from"; break;
case "al":  					$messaggio = "to"; break;
case "è piena":  				$messaggio = "is full"; break;
case "è pieno":  				$messaggio = "is full"; break;
case "<b>C'è</b> ancora disponibilità nel periodo richiesto":	$messaggio = "<b>There is</b> still availability in the requested period"; break;
case ", ma si dovranno fare degli spostamenti nei periodi della <div style=\"display: inline; color: blue;\">regola di assegnazione 1</div>":	$messaggio = ", but some movements will have to be made in periods of <div style=\"display: inline; color: blue;\">assignment rule 1</div>"; break;
case "<b>Non c'è</b> più disponibilità nel periodo richiesto":	$messaggio = "<b>There is not</b> availability in the requested period any more"; break;
case "Si potrebbe inserire la prenotazione dividendola in":	$messaggio = "The reservation could be inserted breaking it into"; break;
case "parti":  					$messaggio = "pieces"; break;
case "Periodo di":  				$messaggio = "Period of"; break;
case "dal":  					$messaggio = "from"; break;
case "settimane":  				$messaggio = "weeks"; break;
case "giorni":  				$messaggio = "days"; break;
case "Tariffa":  				$messaggio = "Rate"; break;
case "compresi":  				$messaggio = "including"; break;
case "di costi aggiuntivi fissi":  		$messaggio = "of fixed extra costs"; break;
case "Ricontrolla":  				$messaggio = "Check again"; break;
case "Torna al menù principale":  		$messaggio = "Back to main menu"; break;
case "documento di tipo":  			$messaggio = "document type"; break;
case "visualizza":  				$messaggio = "view"; break;
case "con la tariffa":  			$messaggio = "with rate"; break;
case "Inserisci la prenotazione":  		$messaggio = "Insert the reservation"; break;
case "settimana":  				$messaggio = "week"; break;
case "giorno":  				$messaggio = "day"; break;
case "TOTALE":  				$messaggio = "TOTAL"; break;
case "Non c'è nussun periodo delle regole 1 in cui sia consentito inserire prenotazioni per l'utente":	$messaggio = "There are no periods in assignment rule 1 in which is allowed to insert reservations for user"; break;
case "costo aggiuntivo unico":  		$messaggio = "single extra cost"; break;
case "costo aggiuntivo settimanale":  		$messaggio = "weekly extra cost"; break;
case "costo aggiuntivo giornaliero":  		$messaggio = "daily extra cost"; break;
case "nº di settimane da applicare":  		$messaggio = "nº of weeks to apply"; break;
case "nº di giorni da applicare":  		$messaggio = "nº of days to apply"; break;
case "di costi aggiuntivi":  			$messaggio = "of extra costs"; break;
case "Aggiungi":  				$messaggio = "Add"; break;
case "da moltiplicare per":  			$messaggio = "to multiply by"; break;
case "Non si sono potuti applicare alla tariffa uno o più costi":	$messaggio = "It was not possible to apply one or more costs to the rate"; break;
case "Scegliere le settimane in cui applicare il costo aggiuntivo":	$messaggio = "Choose the weeks to be applied for the extra cost"; break;
case "Continua":  				$messaggio = "Continue"; break;
case "tariffa":  				$messaggio = "rate"; break;
case "Quadro indicativo disponibilità":  	$messaggio = "Indicative availability overview"; break;
case "potrebbe non essere preciso":  		$messaggio = "might be not accurate"; break;
case "persona":  				$messaggio = "person"; break;
case "Caparra":  				$messaggio = "Deposit"; break;
case "con i costi aggiuntivi selezionati":  	$messaggio = "with selected extra costs"; break;
case "per":  					$messaggio = "for"; break;
case "Commissioni":  				$messaggio = "Commissions"; break;
case "Non c'è nessuna tariffa disponibile in questo periodo":	$messaggio = "There are no available rates in this period"; break;
case "Mostra le tariffe non disponibili":  	$messaggio = "Show not available rates"; break;
case "Scegliere le settimane in cui applicare il costo aggiuntivo":	$messaggio = "Choose the weeks to be applied for the extra cost"; break;
case "Scegliere i giorni in cui applicare il costo aggiuntivo":	$messaggio = "Choose the days to be applied for the extra cost"; break;
case "costo aggiuntivo":  			$messaggio = "extra cost"; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;

} # fine switch ($messaggio)

?>