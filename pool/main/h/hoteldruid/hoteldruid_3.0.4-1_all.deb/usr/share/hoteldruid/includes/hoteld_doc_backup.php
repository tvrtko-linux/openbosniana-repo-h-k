<?php exit(); ?>

<!--             2022-04-11 17:05:02             -->

<!--  **    SAVE THIS FILE AS hoteld_doc_backup.php     **  -->

<!--  **  SALVA QUESTO FILE COME hoteld_doc_backup.php  **  -->


<backup>
<versione>3.04</versione>
<database>
<tabella>
<nometabella>contratti</nometabella>
<colonnetabella>
<nomecolonna>numero</nomecolonna>
<tipocolonna>3</tipocolonna>
<nomecolonna>tipo</nomecolonna>
<tipocolonna>253</tipocolonna>
<nomecolonna>testo</nomecolonna>
<tipocolonna>252</tipocolonna>
</colonnetabella>
<righetabella>
<riga><cmp>18675</cmp><cmp>vett7</cmp><cmp>iva_perc_vett_rfel;num_iva_rfel</cmp></riga>
<riga><cmp>18676</cmp><cmp>vett7</cmp><cmp>iva_perc_esist_rfel;var_tmp_rfel</cmp></riga>
<riga><cmp>18677</cmp><cmp>vett7</cmp><cmp>natura_rfel;num_iva_rfel</cmp></riga>
<riga><cmp>18678</cmp><cmp>vett7</cmp><cmp>iva_perc_vett_rfel_p;num_iva_rfel</cmp></riga>
<riga><cmp>18679</cmp><cmp>vett7</cmp><cmp>tot_iva_vett_rfel_p;num_iva_rfel</cmp></riga>
<riga><cmp>18680</cmp><cmp>vett7</cmp><cmp>tot_no_iva_vett_rfel_p;num_iva_rfel</cmp></riga>
<riga><cmp>9335</cmp><cmp>vett4</cmp><cmp>iva_perc_vett_fael;num_iva_fael</cmp></riga>
<riga><cmp>9336</cmp><cmp>vett4</cmp><cmp>iva_perc_esist_fael;var_tmp_fael</cmp></riga>
<riga><cmp>9337</cmp><cmp>vett4</cmp><cmp>natura_fael;num_iva_fael</cmp></riga>
<riga><cmp>9338</cmp><cmp>vett4</cmp><cmp>iva_perc_vett_fael_p;num_iva_fael</cmp></riga>
<riga><cmp>9339</cmp><cmp>vett4</cmp><cmp>tot_iva_vett_fael_p;num_iva_fael</cmp></riga>
<riga><cmp>9340</cmp><cmp>vett4</cmp><cmp>tot_no_iva_vett_fael_p;num_iva_fael</cmp></riga>
<riga><cmp>65485</cmp><cmp>vett22</cmp><cmp>date_isa;data_isa</cmp></riga>
<riga><cmp>1032</cmp><cmp>vett21</cmp><cmp>date_turiweb;data_turiweb</cmp></riga>
<riga><cmp>1033</cmp><cmp>vett21</cmp><cmp>pos_naz_turiweb;nazione_turiweb</cmp></riga>
<riga><cmp>1034</cmp><cmp>vett21</cmp><cmp>naz_pos_turiweb;pos_turiweb</cmp></riga>
<riga><cmp>1035</cmp><cmp>vett21</cmp><cmp>arrivi_naz_turiweb;pos_turiweb</cmp></riga>
<riga><cmp>1036</cmp><cmp>vett21</cmp><cmp>partenze_naz_turiweb;pos_turiweb</cmp></riga>
<riga><cmp>1038</cmp><cmp>vett21</cmp><cmp>pos_prov_turiweb;provincia_turiweb</cmp></riga>
<riga><cmp>1039</cmp><cmp>vett21</cmp><cmp>prov_pos_turiweb;pos_turiweb</cmp></riga>
<riga><cmp>1040</cmp><cmp>vett21</cmp><cmp>arrivi_prov_turiweb;pos_turiweb</cmp></riga>
<riga><cmp>1041</cmp><cmp>vett21</cmp><cmp>partenze_prov_turiweb;pos_turiweb</cmp></riga>
<riga><cmp>1042</cmp><cmp>vett21</cmp><cmp>ripetizioni_tab_turiweb;pos_turiweb</cmp></riga>
<riga><cmp>2076</cmp><cmp>vett20</cmp><cmp>date_rimovcli;data_rimovcli</cmp></riga>
<riga><cmp>2077</cmp><cmp>vett20</cmp><cmp>pos_naz_rimovcli;nazione_rimovcli</cmp></riga>
<riga><cmp>2078</cmp><cmp>vett20</cmp><cmp>naz_pos_rimovcli;pos_rimovcli</cmp></riga>
<riga><cmp>2079</cmp><cmp>vett20</cmp><cmp>arrivi_naz_rimovcli;pos_rimovcli</cmp></riga>
<riga><cmp>2080</cmp><cmp>vett20</cmp><cmp>partenze_naz_rimovcli;pos_rimovcli</cmp></riga>
<riga><cmp>2082</cmp><cmp>vett20</cmp><cmp>pos_prov_rimovcli;provincia_rimovcli</cmp></riga>
<riga><cmp>2083</cmp><cmp>vett20</cmp><cmp>prov_pos_rimovcli;pos_rimovcli</cmp></riga>
<riga><cmp>2084</cmp><cmp>vett20</cmp><cmp>arrivi_prov_rimovcli;pos_rimovcli</cmp></riga>
<riga><cmp>2085</cmp><cmp>vett20</cmp><cmp>partenze_prov_rimovcli;pos_rimovcli</cmp></riga>
<riga><cmp>2086</cmp><cmp>vett20</cmp><cmp>ripetizioni_tab_rimovcli;pos_rimovcli</cmp></riga>
<riga><cmp>2087</cmp><cmp>vett20</cmp><cmp>presenze_naz_rimovcli;pos_rimovcli</cmp></riga>
<riga><cmp>2088</cmp><cmp>vett20</cmp><cmp>presenze_prov_rimovcli;pos_rimovcli</cmp></riga>
<riga><cmp>2089</cmp><cmp>vett20</cmp><cmp>mostra_naz_rimovcli;pos_rimovcli</cmp></riga>
<riga><cmp>2090</cmp><cmp>vett20</cmp><cmp>mostra_prov_rimovcli;pos_rimovcli</cmp></riga>
<riga><cmp>35</cmp><cmp>vett2</cmp><cmp>iva_perc_vett_fatt;num_iva_fatt</cmp></riga>
<riga><cmp>36</cmp><cmp>vett2</cmp><cmp>iva_perc_esist_fatt;var_tmp_fatt</cmp></riga>
<riga><cmp>65482</cmp><cmp>vett19</cmp><cmp>prenota_capo_gruppo_ross;num_prenota_tmp_ross</cmp></riga>
<riga><cmp>65483</cmp><cmp>vett19</cmp><cmp>prenota_in_gruppo_ross;num_prenota_tmp_ross</cmp></riga>
<riga><cmp>65484</cmp><cmp>vett19</cmp><cmp>cod_capo_prenota_ross;numero_prenotazione</cmp></riga>
<riga><cmp>2305</cmp><cmp>vett15</cmp><cmp>date_c59m;data_c59m</cmp></riga>
<riga><cmp>2308</cmp><cmp>vett15</cmp><cmp>arrivi_naz_c59m;pos_c59m</cmp></riga>
<riga><cmp>2309</cmp><cmp>vett15</cmp><cmp>partenze_naz_c59m;pos_c59m</cmp></riga>
<riga><cmp>2311</cmp><cmp>vett15</cmp><cmp>pos_prov_c59m;provincia_c59m</cmp></riga>
<riga><cmp>2312</cmp><cmp>vett15</cmp><cmp>prov_pos_c59m;pos_c59m</cmp></riga>
<riga><cmp>2313</cmp><cmp>vett15</cmp><cmp>arrivi_prov_c59m;pos_c59m</cmp></riga>
<riga><cmp>2314</cmp><cmp>vett15</cmp><cmp>partenze_prov_c59m;pos_c59m</cmp></riga>
<riga><cmp>2316</cmp><cmp>vett15</cmp><cmp>presenze_naz_c59m;pos_c59m</cmp></riga>
<riga><cmp>2318</cmp><cmp>vett15</cmp><cmp>presenze_prov_c59m;pos_c59m</cmp></riga>
<riga><cmp>215</cmp><cmp>vett14</cmp><cmp>date_istat;data_istat</cmp></riga>
<riga><cmp>218</cmp><cmp>vett14</cmp><cmp>arrivi_naz_istat;pos_istat</cmp></riga>
<riga><cmp>219</cmp><cmp>vett14</cmp><cmp>partenze_naz_istat;pos_istat</cmp></riga>
<riga><cmp>221</cmp><cmp>vett14</cmp><cmp>pos_prov_istat;provincia_istat</cmp></riga>
<riga><cmp>222</cmp><cmp>vett14</cmp><cmp>prov_pos_istat;pos_istat</cmp></riga>
<riga><cmp>223</cmp><cmp>vett14</cmp><cmp>arrivi_prov_istat;pos_istat</cmp></riga>
<riga><cmp>224</cmp><cmp>vett14</cmp><cmp>partenze_prov_istat;pos_istat</cmp></riga>
<riga><cmp>226</cmp><cmp>vett14</cmp><cmp>presenze_naz_istat;pos_istat</cmp></riga>
<riga><cmp>228</cmp><cmp>vett14</cmp><cmp>presenze_prov_istat;pos_istat</cmp></riga>
<riga><cmp>232</cmp><cmp>vett14</cmp><cmp>pres_notte_prec_naz_istat;pos_istat</cmp></riga>
<riga><cmp>233</cmp><cmp>vett14</cmp><cmp>pres_notte_prec_prov_istat;pos_istat</cmp></riga>
<riga><cmp>32</cmp><cmp>vett13</cmp><cmp>prenota_capo_gruppo_ps;num_prenota_tmp_ps</cmp></riga>
<riga><cmp>33</cmp><cmp>vett13</cmp><cmp>prenota_in_gruppo_ps;num_prenota_tmp_ps</cmp></riga>
<riga><cmp>34</cmp><cmp>vett13</cmp><cmp>cod_capo_prenota_ps;numero_prenotazione</cmp></riga>
<riga><cmp>13</cmp><cmp>vett12</cmp><cmp>lista_ospiti_sa;num_ospite_sa</cmp></riga>
<riga><cmp>14</cmp><cmp>vett12</cmp><cmp>linea_ospite_sa;num_ospite_sa</cmp></riga>
<riga><cmp>37</cmp><cmp>vett12</cmp><cmp>linee_altri_ospiti_sa;numero_sa</cmp></riga>
<riga><cmp>38</cmp><cmp>vett12</cmp><cmp>gruppo_sa;numero_sa</cmp></riga>
<riga><cmp>4638</cmp><cmp>vett11</cmp><cmp>situazione_pulizie;unita_pulizie</cmp></riga>
<riga><cmp>4639</cmp><cmp>vett11</cmp><cmp>persone_pulizie;unita_pulizie</cmp></riga>
<riga><cmp>4640</cmp><cmp>vett11</cmp><cmp>persone_part_pulizie;unita_pulizie</cmp></riga>
<riga><cmp>4641</cmp><cmp>vett11</cmp><cmp>num_persone_pulizie;unita_pulizie</cmp></riga>
<riga><cmp>4642</cmp><cmp>vett11</cmp><cmp>num_persone_part_pulizie;unita_pulizie</cmp></riga>
<riga><cmp>4643</cmp><cmp>vett11</cmp><cmp>num_persone_arr_pulizie;unita_pulizie</cmp></riga>
<riga><cmp>4644</cmp><cmp>vett11</cmp><cmp>orario_arrivo_pulizie;unita_pulizie</cmp></riga>
<riga><cmp>4645</cmp><cmp>vett11</cmp><cmp>costi_aggiuntivi_pulizie;num_ca_pulizie</cmp></riga>
<riga><cmp>4646</cmp><cmp>vett11</cmp><cmp>pos_ca_pulizie;nome_costo_agg</cmp></riga>
<riga><cmp>4648</cmp><cmp>vett11</cmp><cmp>riga_unita_ca_pulizie;unita_pulizie</cmp></riga>
<riga><cmp>4649</cmp><cmp>vett11</cmp><cmp>array_date_pulizie;giorno_pulizie</cmp></riga>
<riga><cmp>4650</cmp><cmp>vett11</cmp><cmp>totale_ca_pulizie;num_ca_pulizie</cmp></riga>
<riga><cmp>38</cmp><cmp>var9</cmp><cmp>cognome_ec</cmp></riga>
<riga><cmp>39</cmp><cmp>var9</cmp><cmp>cogn_no_sp_ec</cmp></riga>
<riga><cmp>19</cmp><cmp>var8</cmp><cmp>cognome_email_disp</cmp></riga>
<riga><cmp>406</cmp><cmp>var7</cmp><cmp>cod_fisc_strutt_rfel</cmp></riga>
<riga><cmp>407</cmp><cmp>var7</cmp><cmp>var_tmp_rfel</cmp></riga>
<riga><cmp>408</cmp><cmp>var7</cmp><cmp>tariffa_no_iva_rfel</cmp></riga>
<riga><cmp>409</cmp><cmp>var7</cmp><cmp>ultima_prenota_rfel</cmp></riga>
<riga><cmp>410</cmp><cmp>var7</cmp><cmp>nome_costo_agg_rfel</cmp></riga>
<riga><cmp>411</cmp><cmp>var7</cmp><cmp>tot_no_iva_rfel</cmp></riga>
<riga><cmp>412</cmp><cmp>var7</cmp><cmp>costo_tot_rfel</cmp></riga>
<riga><cmp>413</cmp><cmp>var7</cmp><cmp>costo_tot_rfel_p</cmp></riga>
<riga><cmp>414</cmp><cmp>var7</cmp><cmp>iva_rfel_p</cmp></riga>
<riga><cmp>415</cmp><cmp>var7</cmp><cmp>tot_no_iva_rfel_p</cmp></riga>
<riga><cmp>416</cmp><cmp>var7</cmp><cmp>costo_agg_no_iva_rfel</cmp></riga>
<riga><cmp>417</cmp><cmp>var7</cmp><cmp>sconto_no_iva_rfel_p</cmp></riga>
<riga><cmp>418</cmp><cmp>var7</cmp><cmp>num_iva_rfel</cmp></riga>
<riga><cmp>419</cmp><cmp>var7</cmp><cmp>mos_tariffa_rfel</cmp></riga>
<riga><cmp>420</cmp><cmp>var7</cmp><cmp>mos_sconto_rfel</cmp></riga>
<riga><cmp>421</cmp><cmp>var7</cmp><cmp>mos_costo_agg_rfel</cmp></riga>
<riga><cmp>422</cmp><cmp>var7</cmp><cmp>num_ripetizione_rfel</cmp></riga>
<riga><cmp>423</cmp><cmp>var7</cmp><cmp>tot_parz_no_iva_rfel</cmp></riga>
<riga><cmp>424</cmp><cmp>var7</cmp><cmp>tot_parz_iva_rfel</cmp></riga>
<riga><cmp>425</cmp><cmp>var7</cmp><cmp>max_num_iva_rfel</cmp></riga>
<riga><cmp>426</cmp><cmp>var7</cmp><cmp>accorpa_sconto_e_tariffa_rfel</cmp></riga>
<riga><cmp>427</cmp><cmp>var7</cmp><cmp>nome_costo_tassa_rfel</cmp></riga>
<riga><cmp>428</cmp><cmp>var7</cmp><cmp>mos_costo_tassa_rfel</cmp></riga>
<riga><cmp>429</cmp><cmp>var7</cmp><cmp>tot_costi_tassa_rfel</cmp></riga>
<riga><cmp>430</cmp><cmp>var7</cmp><cmp>iva_rfel</cmp></riga>
<riga><cmp>431</cmp><cmp>var7</cmp><cmp>oggi_rfel</cmp></riga>
<riga><cmp>432</cmp><cmp>var7</cmp><cmp>codice_natura_rfel</cmp></riga>
<riga><cmp>433</cmp><cmp>var7</cmp><cmp>tariffa_no_iva_rfel_p</cmp></riga>
<riga><cmp>434</cmp><cmp>var7</cmp><cmp>costo_agg_no_iva_rfel_p</cmp></riga>
<riga><cmp>435</cmp><cmp>var7</cmp><cmp>pec_rfel</cmp></riga>
<riga><cmp>12</cmp><cmp>var5</cmp><cmp>riga_citta_ricev</cmp></riga>
<riga><cmp>13</cmp><cmp>var5</cmp><cmp>riga_stato_ricev</cmp></riga>
<riga><cmp>14</cmp><cmp>var5</cmp><cmp>cod_fisc_strutt_ricev</cmp></riga>
<riga><cmp>15</cmp><cmp>var5</cmp><cmp>nome_ricev</cmp></riga>
<riga><cmp>16</cmp><cmp>var5</cmp><cmp>cognome_ricev</cmp></riga>
<riga><cmp>17</cmp><cmp>var5</cmp><cmp>telefono_strutt_ricev</cmp></riga>
<riga><cmp>18</cmp><cmp>var5</cmp><cmp>numcivico_ricev</cmp></riga>
<riga><cmp>152</cmp><cmp>var5</cmp><cmp>mostra_metodo_ricev</cmp></riga>
<riga><cmp>351</cmp><cmp>var5</cmp><cmp>logo_ricev</cmp></riga>
<riga><cmp>352</cmp><cmp>var4</cmp><cmp>riga_citta_fael</cmp></riga>
<riga><cmp>353</cmp><cmp>var4</cmp><cmp>riga_stato_fael</cmp></riga>
<riga><cmp>354</cmp><cmp>var4</cmp><cmp>cod_fisc_strutt_fael</cmp></riga>
<riga><cmp>355</cmp><cmp>var4</cmp><cmp>nome_fael</cmp></riga>
<riga><cmp>356</cmp><cmp>var4</cmp><cmp>cognome_fael</cmp></riga>
<riga><cmp>357</cmp><cmp>var4</cmp><cmp>telefono_strutt_fael</cmp></riga>
<riga><cmp>358</cmp><cmp>var4</cmp><cmp>var_tmp_fael</cmp></riga>
<riga><cmp>359</cmp><cmp>var4</cmp><cmp>tariffa_no_iva_fael</cmp></riga>
<riga><cmp>360</cmp><cmp>var4</cmp><cmp>ultima_prenota_fael</cmp></riga>
<riga><cmp>361</cmp><cmp>var4</cmp><cmp>nome_costo_agg_fael</cmp></riga>
<riga><cmp>362</cmp><cmp>var4</cmp><cmp>tot_no_iva_fael</cmp></riga>
<riga><cmp>363</cmp><cmp>var4</cmp><cmp>costo_tot_fael</cmp></riga>
<riga><cmp>364</cmp><cmp>var4</cmp><cmp>costo_tot_fael_p</cmp></riga>
<riga><cmp>365</cmp><cmp>var4</cmp><cmp>iva_fael_p</cmp></riga>
<riga><cmp>366</cmp><cmp>var4</cmp><cmp>tot_no_iva_fael_p</cmp></riga>
<riga><cmp>367</cmp><cmp>var4</cmp><cmp>costo_agg_no_iva_fael</cmp></riga>
<riga><cmp>368</cmp><cmp>var4</cmp><cmp>sconto_no_iva_fael_p</cmp></riga>
<riga><cmp>369</cmp><cmp>var4</cmp><cmp>numcivico_fael</cmp></riga>
<riga><cmp>370</cmp><cmp>var4</cmp><cmp>codice_fiscale_fael</cmp></riga>
<riga><cmp>371</cmp><cmp>var4</cmp><cmp>partita_iva_fael</cmp></riga>
<riga><cmp>372</cmp><cmp>var4</cmp><cmp>via_fael</cmp></riga>
<riga><cmp>373</cmp><cmp>var4</cmp><cmp>num_iva_fael</cmp></riga>
<riga><cmp>374</cmp><cmp>var4</cmp><cmp>mos_tariffa_fael</cmp></riga>
<riga><cmp>375</cmp><cmp>var4</cmp><cmp>mos_sconto_fael</cmp></riga>
<riga><cmp>376</cmp><cmp>var4</cmp><cmp>mos_costo_agg_fael</cmp></riga>
<riga><cmp>377</cmp><cmp>var4</cmp><cmp>num_ripetizione_fael</cmp></riga>
<riga><cmp>378</cmp><cmp>var4</cmp><cmp>tot_parz_no_iva_fael</cmp></riga>
<riga><cmp>379</cmp><cmp>var4</cmp><cmp>tot_parz_iva_fael</cmp></riga>
<riga><cmp>380</cmp><cmp>var4</cmp><cmp>max_num_iva_fael</cmp></riga>
<riga><cmp>381</cmp><cmp>var4</cmp><cmp>frase_persone_fael</cmp></riga>
<riga><cmp>382</cmp><cmp>var4</cmp><cmp>accorpa_sconto_e_tariffa_fael</cmp></riga>
<riga><cmp>383</cmp><cmp>var4</cmp><cmp>nome_costo_tassa_fael</cmp></riga>
<riga><cmp>384</cmp><cmp>var4</cmp><cmp>mos_costo_tassa_fael</cmp></riga>
<riga><cmp>385</cmp><cmp>var4</cmp><cmp>tot_costi_tassa_fael</cmp></riga>
<riga><cmp>386</cmp><cmp>var4</cmp><cmp>iva_fael</cmp></riga>
<riga><cmp>387</cmp><cmp>var4</cmp><cmp>mos_costo_come_tasse_fael</cmp></riga>
<riga><cmp>388</cmp><cmp>var4</cmp><cmp>mos_subtotale_fael</cmp></riga>
<riga><cmp>389</cmp><cmp>var4</cmp><cmp>codice_nazione_fael</cmp></riga>
<riga><cmp>390</cmp><cmp>var4</cmp><cmp>provincia_struttura_fael</cmp></riga>
<riga><cmp>391</cmp><cmp>var4</cmp><cmp>oggi_fael</cmp></riga>
<riga><cmp>392</cmp><cmp>var4</cmp><cmp>presso_fael</cmp></riga>
<riga><cmp>393</cmp><cmp>var4</cmp><cmp>num_linea_fael</cmp></riga>
<riga><cmp>394</cmp><cmp>var4</cmp><cmp>codice_natura_fael</cmp></riga>
<riga><cmp>395</cmp><cmp>var4</cmp><cmp>tariffa_no_iva_fael_p</cmp></riga>
<riga><cmp>396</cmp><cmp>var4</cmp><cmp>costo_agg_no_iva_fael_p</cmp></riga>
<riga><cmp>397</cmp><cmp>var4</cmp><cmp>contatti_trasmittente_fael</cmp></riga>
<riga><cmp>398</cmp><cmp>var4</cmp><cmp>cod_destinatario_fael</cmp></riga>
<riga><cmp>399</cmp><cmp>var4</cmp><cmp>linea_pecdestinatario_fael</cmp></riga>
<riga><cmp>400</cmp><cmp>var4</cmp><cmp>pec_fael</cmp></riga>
<riga><cmp>489</cmp><cmp>var22</cmp><cmp>presenze_isa</cmp></riga>
<riga><cmp>490</cmp><cmp>var22</cmp><cmp>data_isa</cmp></riga>
<riga><cmp>163</cmp><cmp>var21</cmp><cmp>num_turiweb</cmp></riga>
<riga><cmp>164</cmp><cmp>var21</cmp><cmp>data_turiweb</cmp></riga>
<riga><cmp>165</cmp><cmp>var21</cmp><cmp>pos_turiweb</cmp></riga>
<riga><cmp>166</cmp><cmp>var21</cmp><cmp>prox_num_turiweb</cmp></riga>
<riga><cmp>167</cmp><cmp>var21</cmp><cmp>arr_part_turiweb</cmp></riga>
<riga><cmp>168</cmp><cmp>var21</cmp><cmp>arrivo_turiweb</cmp></riga>
<riga><cmp>169</cmp><cmp>var21</cmp><cmp>partenza_turiweb</cmp></riga>
<riga><cmp>170</cmp><cmp>var21</cmp><cmp>italiano_turiweb</cmp></riga>
<riga><cmp>171</cmp><cmp>var21</cmp><cmp>ins_nuovo_num_turiweb</cmp></riga>
<riga><cmp>172</cmp><cmp>var21</cmp><cmp>agg_arr_turiweb</cmp></riga>
<riga><cmp>173</cmp><cmp>var21</cmp><cmp>agg_part_turiweb</cmp></riga>
<riga><cmp>174</cmp><cmp>var21</cmp><cmp>num_persone_turiweb</cmp></riga>
<riga><cmp>175</cmp><cmp>var21</cmp><cmp>anno_turiweb</cmp></riga>
<riga><cmp>176</cmp><cmp>var21</cmp><cmp>mese_turiweb</cmp></riga>
<riga><cmp>177</cmp><cmp>var21</cmp><cmp>giorno_turiweb</cmp></riga>
<riga><cmp>178</cmp><cmp>var21</cmp><cmp>null_turiweb</cmp></riga>
<riga><cmp>179</cmp><cmp>var21</cmp><cmp>num_prog_turiweb</cmp></riga>
<riga><cmp>180</cmp><cmp>var21</cmp><cmp>nazione_turiweb</cmp></riga>
<riga><cmp>181</cmp><cmp>var21</cmp><cmp>break_turiweb</cmp></riga>
<riga><cmp>182</cmp><cmp>var21</cmp><cmp>nazione1_turiweb</cmp></riga>
<riga><cmp>183</cmp><cmp>var21</cmp><cmp>provincia_turiweb</cmp></riga>
<riga><cmp>184</cmp><cmp>var21</cmp><cmp>provincia1_turiweb</cmp></riga>
<riga><cmp>185</cmp><cmp>var21</cmp><cmp>cli_giorno_prec_turiweb</cmp></riga>
<riga><cmp>186</cmp><cmp>var21</cmp><cmp>cli_arrivati_turiweb</cmp></riga>
<riga><cmp>187</cmp><cmp>var21</cmp><cmp>cli_totale_turiweb</cmp></riga>
<riga><cmp>188</cmp><cmp>var21</cmp><cmp>cli_partiti_turiweb</cmp></riga>
<riga><cmp>189</cmp><cmp>var21</cmp><cmp>cli_presenti_notte_turiweb</cmp></riga>
<riga><cmp>190</cmp><cmp>var21</cmp><cmp>agg_turiweb</cmp></riga>
<riga><cmp>191</cmp><cmp>var21</cmp><cmp>ospite_altra_naz_turiweb</cmp></riga>
<riga><cmp>192</cmp><cmp>var21</cmp><cmp>ospite_altra_prov_turiweb</cmp></riga>
<riga><cmp>193</cmp><cmp>var21</cmp><cmp>num_prov_turiweb</cmp></riga>
<riga><cmp>194</cmp><cmp>var21</cmp><cmp>prox_num_prov_turiweb</cmp></riga>
<riga><cmp>195</cmp><cmp>var21</cmp><cmp>tot_arr_naz_turiweb</cmp></riga>
<riga><cmp>196</cmp><cmp>var21</cmp><cmp>tot_part_naz_turiweb</cmp></riga>
<riga><cmp>197</cmp><cmp>var21</cmp><cmp>tot_arr_prov_turiweb</cmp></riga>
<riga><cmp>198</cmp><cmp>var21</cmp><cmp>tot_part_prov_turiweb</cmp></riga>
<riga><cmp>199</cmp><cmp>var21</cmp><cmp>mostra_pag_turiweb</cmp></riga>
<riga><cmp>200</cmp><cmp>var21</cmp><cmp>ultima_data_turiweb</cmp></riga>
<riga><cmp>201</cmp><cmp>var21</cmp><cmp>nuova_pag_turiweb</cmp></riga>
<riga><cmp>202</cmp><cmp>var21</cmp><cmp>mese_sel_turiweb</cmp></riga>
<riga><cmp>203</cmp><cmp>var21</cmp><cmp>anno_sel_turiweb</cmp></riga>
<riga><cmp>204</cmp><cmp>var21</cmp><cmp>var_aux_turiweb</cmp></riga>
<riga><cmp>205</cmp><cmp>var21</cmp><cmp>var_turiweb</cmp></riga>
<riga><cmp>206</cmp><cmp>var21</cmp><cmp>camere_occupate_turiweb</cmp></riga>
<riga><cmp>207</cmp><cmp>var21</cmp><cmp>id_struttura_turiweb</cmp></riga>
<riga><cmp>208</cmp><cmp>var20</cmp><cmp>num_rimovcli</cmp></riga>
<riga><cmp>209</cmp><cmp>var20</cmp><cmp>data_rimovcli</cmp></riga>
<riga><cmp>210</cmp><cmp>var20</cmp><cmp>pos_rimovcli</cmp></riga>
<riga><cmp>211</cmp><cmp>var20</cmp><cmp>prox_num_rimovcli</cmp></riga>
<riga><cmp>212</cmp><cmp>var20</cmp><cmp>arr_part_rimovcli</cmp></riga>
<riga><cmp>213</cmp><cmp>var20</cmp><cmp>arrivo_rimovcli</cmp></riga>
<riga><cmp>214</cmp><cmp>var20</cmp><cmp>partenza_rimovcli</cmp></riga>
<riga><cmp>215</cmp><cmp>var20</cmp><cmp>italiano_rimovcli</cmp></riga>
<riga><cmp>216</cmp><cmp>var20</cmp><cmp>ins_nuovo_num_rimovcli</cmp></riga>
<riga><cmp>217</cmp><cmp>var20</cmp><cmp>agg_arr_rimovcli</cmp></riga>
<riga><cmp>218</cmp><cmp>var20</cmp><cmp>agg_part_rimovcli</cmp></riga>
<riga><cmp>219</cmp><cmp>var20</cmp><cmp>num_persone_rimovcli</cmp></riga>
<riga><cmp>220</cmp><cmp>var20</cmp><cmp>anno_rimovcli</cmp></riga>
<riga><cmp>221</cmp><cmp>var20</cmp><cmp>mese_rimovcli</cmp></riga>
<riga><cmp>222</cmp><cmp>var20</cmp><cmp>giorno_rimovcli</cmp></riga>
<riga><cmp>223</cmp><cmp>var20</cmp><cmp>null_rimovcli</cmp></riga>
<riga><cmp>224</cmp><cmp>var20</cmp><cmp>num_prog_rimovcli</cmp></riga>
<riga><cmp>225</cmp><cmp>var20</cmp><cmp>nazione_rimovcli</cmp></riga>
<riga><cmp>226</cmp><cmp>var20</cmp><cmp>break_rimovcli</cmp></riga>
<riga><cmp>227</cmp><cmp>var20</cmp><cmp>nazione1_rimovcli</cmp></riga>
<riga><cmp>228</cmp><cmp>var20</cmp><cmp>provincia_rimovcli</cmp></riga>
<riga><cmp>229</cmp><cmp>var20</cmp><cmp>provincia1_rimovcli</cmp></riga>
<riga><cmp>230</cmp><cmp>var20</cmp><cmp>cli_giorno_prec_rimovcli</cmp></riga>
<riga><cmp>231</cmp><cmp>var20</cmp><cmp>cli_arrivati_rimovcli</cmp></riga>
<riga><cmp>232</cmp><cmp>var20</cmp><cmp>cli_totale_rimovcli</cmp></riga>
<riga><cmp>233</cmp><cmp>var20</cmp><cmp>cli_partiti_rimovcli</cmp></riga>
<riga><cmp>234</cmp><cmp>var20</cmp><cmp>cli_presenti_notte_rimovcli</cmp></riga>
<riga><cmp>235</cmp><cmp>var20</cmp><cmp>agg_rimovcli</cmp></riga>
<riga><cmp>236</cmp><cmp>var20</cmp><cmp>ospite_altra_naz_rimovcli</cmp></riga>
<riga><cmp>237</cmp><cmp>var20</cmp><cmp>ospite_altra_prov_rimovcli</cmp></riga>
<riga><cmp>238</cmp><cmp>var20</cmp><cmp>num_prov_rimovcli</cmp></riga>
<riga><cmp>239</cmp><cmp>var20</cmp><cmp>prox_num_prov_rimovcli</cmp></riga>
<riga><cmp>240</cmp><cmp>var20</cmp><cmp>tot_arr_naz_rimovcli</cmp></riga>
<riga><cmp>241</cmp><cmp>var20</cmp><cmp>tot_part_naz_rimovcli</cmp></riga>
<riga><cmp>242</cmp><cmp>var20</cmp><cmp>tot_arr_prov_rimovcli</cmp></riga>
<riga><cmp>243</cmp><cmp>var20</cmp><cmp>tot_part_prov_rimovcli</cmp></riga>
<riga><cmp>244</cmp><cmp>var20</cmp><cmp>mostra_pag_rimovcli</cmp></riga>
<riga><cmp>245</cmp><cmp>var20</cmp><cmp>ultima_data_rimovcli</cmp></riga>
<riga><cmp>246</cmp><cmp>var20</cmp><cmp>nuova_pag_rimovcli</cmp></riga>
<riga><cmp>247</cmp><cmp>var20</cmp><cmp>mese_sel_rimovcli</cmp></riga>
<riga><cmp>248</cmp><cmp>var20</cmp><cmp>anno_sel_rimovcli</cmp></riga>
<riga><cmp>249</cmp><cmp>var20</cmp><cmp>var_aux_rimovcli</cmp></riga>
<riga><cmp>250</cmp><cmp>var20</cmp><cmp>var_rimovcli</cmp></riga>
<riga><cmp>251</cmp><cmp>var20</cmp><cmp>camere_occupate_rimovcli</cmp></riga>
<riga><cmp>252</cmp><cmp>var20</cmp><cmp>data_corr_rimovcli</cmp></riga>
<riga><cmp>253</cmp><cmp>var20</cmp><cmp>tot_camere_occupate_rimovcli</cmp></riga>
<riga><cmp>254</cmp><cmp>var20</cmp><cmp>agg_pres_rimovcli</cmp></riga>
<riga><cmp>255</cmp><cmp>var20</cmp><cmp>id_struttura_rimovcli</cmp></riga>
<riga><cmp>256</cmp><cmp>var20</cmp><cmp>camere_disponibili_rimovcli</cmp></riga>
<riga><cmp>257</cmp><cmp>var20</cmp><cmp>letti_disponibili_rimovcli</cmp></riga>
<riga><cmp>258</cmp><cmp>var20</cmp><cmp>mostra_pag_tot_rimovcli</cmp></riga>
<riga><cmp>259</cmp><cmp>var20</cmp><cmp>break_prenota_rimovcli</cmp></riga>
<riga><cmp>65</cmp><cmp>var2</cmp><cmp>riga_citta_fatt</cmp></riga>
<riga><cmp>66</cmp><cmp>var2</cmp><cmp>riga_stato_fatt</cmp></riga>
<riga><cmp>67</cmp><cmp>var2</cmp><cmp>cod_fisc_strutt_fatt</cmp></riga>
<riga><cmp>68</cmp><cmp>var2</cmp><cmp>nome_fatt</cmp></riga>
<riga><cmp>69</cmp><cmp>var2</cmp><cmp>cognome_fatt</cmp></riga>
<riga><cmp>70</cmp><cmp>var2</cmp><cmp>telefono_strutt_fatt</cmp></riga>
<riga><cmp>71</cmp><cmp>var2</cmp><cmp>var_tmp_fatt</cmp></riga>
<riga><cmp>72</cmp><cmp>var2</cmp><cmp>tariffa_no_iva_fatt</cmp></riga>
<riga><cmp>73</cmp><cmp>var2</cmp><cmp>ultima_prenota_fatt</cmp></riga>
<riga><cmp>74</cmp><cmp>var2</cmp><cmp>nome_costo_agg_fatt</cmp></riga>
<riga><cmp>75</cmp><cmp>var2</cmp><cmp>tot_no_iva_fatt</cmp></riga>
<riga><cmp>76</cmp><cmp>var2</cmp><cmp>costo_tot_fatt</cmp></riga>
<riga><cmp>77</cmp><cmp>var2</cmp><cmp>costo_tot_fatt_p</cmp></riga>
<riga><cmp>78</cmp><cmp>var2</cmp><cmp>iva_fatt_p</cmp></riga>
<riga><cmp>79</cmp><cmp>var2</cmp><cmp>tot_no_iva_fatt_p</cmp></riga>
<riga><cmp>80</cmp><cmp>var2</cmp><cmp>costo_agg_no_iva_fatt_p</cmp></riga>
<riga><cmp>81</cmp><cmp>var2</cmp><cmp>sconto_no_iva_fatt_p</cmp></riga>
<riga><cmp>82</cmp><cmp>var2</cmp><cmp>tariffa_no_iva_fatt_p</cmp></riga>
<riga><cmp>83</cmp><cmp>var2</cmp><cmp>numcivico_fatt</cmp></riga>
<riga><cmp>84</cmp><cmp>var2</cmp><cmp>codice_fiscale_fatt</cmp></riga>
<riga><cmp>85</cmp><cmp>var2</cmp><cmp>partita_iva_fatt</cmp></riga>
<riga><cmp>86</cmp><cmp>var2</cmp><cmp>via_fatt</cmp></riga>
<riga><cmp>87</cmp><cmp>var2</cmp><cmp>num_iva_fatt</cmp></riga>
<riga><cmp>88</cmp><cmp>var2</cmp><cmp>mos_tariffa_fatt</cmp></riga>
<riga><cmp>89</cmp><cmp>var2</cmp><cmp>mos_sconto_fatt</cmp></riga>
<riga><cmp>90</cmp><cmp>var2</cmp><cmp>mos_costo_agg_fatt</cmp></riga>
<riga><cmp>91</cmp><cmp>var2</cmp><cmp>num_ripetizione_fatt</cmp></riga>
<riga><cmp>92</cmp><cmp>var2</cmp><cmp>tot_parz_no_iva_fatt</cmp></riga>
<riga><cmp>93</cmp><cmp>var2</cmp><cmp>tot_parz_iva_fatt</cmp></riga>
<riga><cmp>94</cmp><cmp>var2</cmp><cmp>tot_parz_no_iva_fatt_p</cmp></riga>
<riga><cmp>95</cmp><cmp>var2</cmp><cmp>tot_parz_iva_fatt_p</cmp></riga>
<riga><cmp>96</cmp><cmp>var2</cmp><cmp>max_num_iva_fatt</cmp></riga>
<riga><cmp>97</cmp><cmp>var2</cmp><cmp>frase_persone_fatt</cmp></riga>
<riga><cmp>98</cmp><cmp>var2</cmp><cmp>accorpa_sconto_e_tariffa</cmp></riga>
<riga><cmp>151</cmp><cmp>var2</cmp><cmp>logo_fatt</cmp></riga>
<riga><cmp>155</cmp><cmp>var2</cmp><cmp>nome_costo_tassa_fatt</cmp></riga>
<riga><cmp>156</cmp><cmp>var2</cmp><cmp>mos_costo_tassa_fatt</cmp></riga>
<riga><cmp>157</cmp><cmp>var2</cmp><cmp>tot_costi_tassa_fatt</cmp></riga>
<riga><cmp>158</cmp><cmp>var2</cmp><cmp>iva_fatt</cmp></riga>
<riga><cmp>160</cmp><cmp>var2</cmp><cmp>mos_costo_come_tasse_fatt</cmp></riga>
<riga><cmp>161</cmp><cmp>var2</cmp><cmp>mos_subtotale_fatt</cmp></riga>
<riga><cmp>452</cmp><cmp>var19</cmp><cmp>null_ross</cmp></riga>
<riga><cmp>453</cmp><cmp>var19</cmp><cmp>codice_ospite_ross</cmp></riga>
<riga><cmp>454</cmp><cmp>var19</cmp><cmp>data_inizio_ross</cmp></riga>
<riga><cmp>455</cmp><cmp>var19</cmp><cmp>cognome_ross</cmp></riga>
<riga><cmp>456</cmp><cmp>var19</cmp><cmp>nome_ross</cmp></riga>
<riga><cmp>457</cmp><cmp>var19</cmp><cmp>sesso_ross</cmp></riga>
<riga><cmp>458</cmp><cmp>var19</cmp><cmp>data_nascita_ross</cmp></riga>
<riga><cmp>459</cmp><cmp>var19</cmp><cmp>comune_ross</cmp></riga>
<riga><cmp>460</cmp><cmp>var19</cmp><cmp>provincia_ross</cmp></riga>
<riga><cmp>461</cmp><cmp>var19</cmp><cmp>comune_resid_ross</cmp></riga>
<riga><cmp>462</cmp><cmp>var19</cmp><cmp>provincia_resid_ross</cmp></riga>
<riga><cmp>463</cmp><cmp>var19</cmp><cmp>nazione_resid_ross</cmp></riga>
<riga><cmp>464</cmp><cmp>var19</cmp><cmp>indirizzo_ross</cmp></riga>
<riga><cmp>465</cmp><cmp>var19</cmp><cmp>tipo_doc_ross</cmp></riga>
<riga><cmp>466</cmp><cmp>var19</cmp><cmp>numero_doc_ross</cmp></riga>
<riga><cmp>467</cmp><cmp>var19</cmp><cmp>luogo_doc_ross</cmp></riga>
<riga><cmp>468</cmp><cmp>var19</cmp><cmp>acapo_ross</cmp></riga>
<riga><cmp>469</cmp><cmp>var19</cmp><cmp>cognome_prec_ross</cmp></riga>
<riga><cmp>470</cmp><cmp>var19</cmp><cmp>nome_prec_ross</cmp></riga>
<riga><cmp>471</cmp><cmp>var19</cmp><cmp>dataini_prec_ross</cmp></riga>
<riga><cmp>472</cmp><cmp>var19</cmp><cmp>datafine_prec_ross</cmp></riga>
<riga><cmp>473</cmp><cmp>var19</cmp><cmp>num_prenota_prec_ross</cmp></riga>
<riga><cmp>474</cmp><cmp>var19</cmp><cmp>num_prenota_tmp_ross</cmp></riga>
<riga><cmp>475</cmp><cmp>var19</cmp><cmp>dataini_corr_ross</cmp></riga>
<riga><cmp>476</cmp><cmp>var19</cmp><cmp>datafine_corr_ross</cmp></riga>
<riga><cmp>477</cmp><cmp>var19</cmp><cmp>num_ripetizione_ross</cmp></riga>
<riga><cmp>478</cmp><cmp>var19</cmp><cmp>mess_errore_ross</cmp></riga>
<riga><cmp>479</cmp><cmp>var19</cmp><cmp>num_periodi_ross</cmp></riga>
<riga><cmp>480</cmp><cmp>var19</cmp><cmp>tmp_ross</cmp></riga>
<riga><cmp>481</cmp><cmp>var19</cmp><cmp>codice_nazione_ross</cmp></riga>
<riga><cmp>482</cmp><cmp>var19</cmp><cmp>codice_nazione_nascita_ross</cmp></riga>
<riga><cmp>483</cmp><cmp>var19</cmp><cmp>codice_nazione_documento_ross</cmp></riga>
<riga><cmp>484</cmp><cmp>var19</cmp><cmp>codice_cittadinanza_ross</cmp></riga>
<riga><cmp>485</cmp><cmp>var19</cmp><cmp>data_fine_ross</cmp></riga>
<riga><cmp>486</cmp><cmp>var19</cmp><cmp>num_prenota_ross</cmp></riga>
<riga><cmp>487</cmp><cmp>var19</cmp><cmp>num_prenota2_ross</cmp></riga>
<riga><cmp>439</cmp><cmp>var18</cmp><cmp>cognome_rcsv</cmp></riga>
<riga><cmp>440</cmp><cmp>var18</cmp><cmp>nome_rcsv</cmp></riga>
<riga><cmp>441</cmp><cmp>var18</cmp><cmp>unita_rcsv</cmp></riga>
<riga><cmp>442</cmp><cmp>var18</cmp><cmp>nome_tariffa_rcsv</cmp></riga>
<riga><cmp>443</cmp><cmp>var18</cmp><cmp>email_rcsv</cmp></riga>
<riga><cmp>444</cmp><cmp>var18</cmp><cmp>telefono_rcsv</cmp></riga>
<riga><cmp>445</cmp><cmp>var18</cmp><cmp>prezzo_tariffa_rcsv</cmp></riga>
<riga><cmp>446</cmp><cmp>var18</cmp><cmp>prezzo_totale_rcsv</cmp></riga>
<riga><cmp>447</cmp><cmp>var18</cmp><cmp>pagato_rcsv</cmp></riga>
<riga><cmp>448</cmp><cmp>var18</cmp><cmp>totale_persone_rcsv</cmp></riga>
<riga><cmp>449</cmp><cmp>var18</cmp><cmp>commento_rcsv</cmp></riga>
<riga><cmp>450</cmp><cmp>var18</cmp><cmp>arrivo_rcsv</cmp></riga>
<riga><cmp>451</cmp><cmp>var18</cmp><cmp>partenza_rcsv</cmp></riga>
<riga><cmp>312</cmp><cmp>var17</cmp><cmp>cognome_csv</cmp></riga>
<riga><cmp>313</cmp><cmp>var17</cmp><cmp>nome_csv</cmp></riga>
<riga><cmp>314</cmp><cmp>var17</cmp><cmp>soprannome_csv</cmp></riga>
<riga><cmp>315</cmp><cmp>var17</cmp><cmp>titolo_csv</cmp></riga>
<riga><cmp>316</cmp><cmp>var17</cmp><cmp>email_csv</cmp></riga>
<riga><cmp>317</cmp><cmp>var17</cmp><cmp>telefono_csv</cmp></riga>
<riga><cmp>318</cmp><cmp>var17</cmp><cmp>fax_csv</cmp></riga>
<riga><cmp>319</cmp><cmp>var17</cmp><cmp>nazione_csv</cmp></riga>
<riga><cmp>320</cmp><cmp>var17</cmp><cmp>regione_csv</cmp></riga>
<riga><cmp>321</cmp><cmp>var17</cmp><cmp>citta_csv</cmp></riga>
<riga><cmp>322</cmp><cmp>var17</cmp><cmp>indirizzo_csv</cmp></riga>
<riga><cmp>323</cmp><cmp>var17</cmp><cmp>cap_csv</cmp></riga>
<riga><cmp>324</cmp><cmp>var17</cmp><cmp>cittadinanza_csv</cmp></riga>
<riga><cmp>325</cmp><cmp>var17</cmp><cmp>data_nascita_csv</cmp></riga>
<riga><cmp>326</cmp><cmp>var17</cmp><cmp>partita_iva_csv</cmp></riga>
<riga><cmp>327</cmp><cmp>var17</cmp><cmp>tmp_csv</cmp></riga>
<riga><cmp>328</cmp><cmp>var17</cmp><cmp>email2_csv</cmp></riga>
<riga><cmp>329</cmp><cmp>var17</cmp><cmp>pec_csv</cmp></riga>
<riga><cmp>330</cmp><cmp>var17</cmp><cmp>telefono2_csv</cmp></riga>
<riga><cmp>331</cmp><cmp>var17</cmp><cmp>telefono3_csv</cmp></riga>
<riga><cmp>260</cmp><cmp>var15</cmp><cmp>data_c59m</cmp></riga>
<riga><cmp>261</cmp><cmp>var15</cmp><cmp>pos_c59m</cmp></riga>
<riga><cmp>262</cmp><cmp>var15</cmp><cmp>arr_part_c59m</cmp></riga>
<riga><cmp>263</cmp><cmp>var15</cmp><cmp>arrivo_c59m</cmp></riga>
<riga><cmp>264</cmp><cmp>var15</cmp><cmp>partenza_c59m</cmp></riga>
<riga><cmp>265</cmp><cmp>var15</cmp><cmp>italiano_c59m</cmp></riga>
<riga><cmp>266</cmp><cmp>var15</cmp><cmp>ins_nuovo_num_c59m</cmp></riga>
<riga><cmp>267</cmp><cmp>var15</cmp><cmp>agg_arr_c59m</cmp></riga>
<riga><cmp>268</cmp><cmp>var15</cmp><cmp>agg_part_c59m</cmp></riga>
<riga><cmp>269</cmp><cmp>var15</cmp><cmp>num_persone_c59m</cmp></riga>
<riga><cmp>270</cmp><cmp>var15</cmp><cmp>anno_c59m</cmp></riga>
<riga><cmp>271</cmp><cmp>var15</cmp><cmp>mese_c59m</cmp></riga>
<riga><cmp>272</cmp><cmp>var15</cmp><cmp>giorno_c59m</cmp></riga>
<riga><cmp>273</cmp><cmp>var15</cmp><cmp>null_c59m</cmp></riga>
<riga><cmp>274</cmp><cmp>var15</cmp><cmp>num_prog_c59m</cmp></riga>
<riga><cmp>275</cmp><cmp>var15</cmp><cmp>nazione_c59m</cmp></riga>
<riga><cmp>276</cmp><cmp>var15</cmp><cmp>nazione1_c59m</cmp></riga>
<riga><cmp>277</cmp><cmp>var15</cmp><cmp>provincia_c59m</cmp></riga>
<riga><cmp>278</cmp><cmp>var15</cmp><cmp>provincia1_c59m</cmp></riga>
<riga><cmp>279</cmp><cmp>var15</cmp><cmp>cli_giorno_prec_c59m</cmp></riga>
<riga><cmp>280</cmp><cmp>var15</cmp><cmp>cli_arrivati_c59m</cmp></riga>
<riga><cmp>281</cmp><cmp>var15</cmp><cmp>cli_totale_c59m</cmp></riga>
<riga><cmp>282</cmp><cmp>var15</cmp><cmp>cli_partiti_c59m</cmp></riga>
<riga><cmp>283</cmp><cmp>var15</cmp><cmp>cli_presenti_notte_c59m</cmp></riga>
<riga><cmp>284</cmp><cmp>var15</cmp><cmp>agg_c59m</cmp></riga>
<riga><cmp>285</cmp><cmp>var15</cmp><cmp>ospite_altra_naz_c59m</cmp></riga>
<riga><cmp>286</cmp><cmp>var15</cmp><cmp>ospite_altra_prov_c59m</cmp></riga>
<riga><cmp>287</cmp><cmp>var15</cmp><cmp>num_prov_c59m</cmp></riga>
<riga><cmp>288</cmp><cmp>var15</cmp><cmp>prox_num_prov_c59m</cmp></riga>
<riga><cmp>289</cmp><cmp>var15</cmp><cmp>tot_arr_naz_c59m</cmp></riga>
<riga><cmp>290</cmp><cmp>var15</cmp><cmp>tot_part_naz_c59m</cmp></riga>
<riga><cmp>291</cmp><cmp>var15</cmp><cmp>tot_arr_prov_c59m</cmp></riga>
<riga><cmp>292</cmp><cmp>var15</cmp><cmp>tot_part_prov_c59m</cmp></riga>
<riga><cmp>293</cmp><cmp>var15</cmp><cmp>mostra_pag_c59m</cmp></riga>
<riga><cmp>294</cmp><cmp>var15</cmp><cmp>ultima_data_c59m</cmp></riga>
<riga><cmp>295</cmp><cmp>var15</cmp><cmp>nuova_pag_c59m</cmp></riga>
<riga><cmp>296</cmp><cmp>var15</cmp><cmp>agg_pres_c59m</cmp></riga>
<riga><cmp>297</cmp><cmp>var15</cmp><cmp>tot_pres_naz_c59m</cmp></riga>
<riga><cmp>298</cmp><cmp>var15</cmp><cmp>tot_pres_prov_c59m</cmp></riga>
<riga><cmp>299</cmp><cmp>var15</cmp><cmp>camere_occupate_c59m</cmp></riga>
<riga><cmp>300</cmp><cmp>var15</cmp><cmp>comune_c59m</cmp></riga>
<riga><cmp>301</cmp><cmp>var15</cmp><cmp>struttura_chiusa_c59m</cmp></riga>
<riga><cmp>302</cmp><cmp>var15</cmp><cmp>struttura_aperta_c59m</cmp></riga>
<riga><cmp>303</cmp><cmp>var15</cmp><cmp>inizio_chiusura_c59m</cmp></riga>
<riga><cmp>304</cmp><cmp>var15</cmp><cmp>fine_chiusura_c59m</cmp></riga>
<riga><cmp>305</cmp><cmp>var15</cmp><cmp>giorni_apertura_c59m</cmp></riga>
<riga><cmp>306</cmp><cmp>var15</cmp><cmp>mese_attuale_c59m</cmp></riga>
<riga><cmp>307</cmp><cmp>var15</cmp><cmp>camere_disponibili_c59m</cmp></riga>
<riga><cmp>308</cmp><cmp>var15</cmp><cmp>letti_disponibili_c59m</cmp></riga>
<riga><cmp>309</cmp><cmp>var15</cmp><cmp>nome_contatto_c59m</cmp></riga>
<riga><cmp>310</cmp><cmp>var15</cmp><cmp>email_contatto_c59m</cmp></riga>
<riga><cmp>311</cmp><cmp>var15</cmp><cmp>telefono_contatto_c59m</cmp></riga>
<riga><cmp>405</cmp><cmp>var15</cmp><cmp>var_tmp_c59m</cmp></riga>
<riga><cmp>108</cmp><cmp>var14</cmp><cmp>data_istat</cmp></riga>
<riga><cmp>109</cmp><cmp>var14</cmp><cmp>pos_istat</cmp></riga>
<riga><cmp>110</cmp><cmp>var14</cmp><cmp>arr_part_istat</cmp></riga>
<riga><cmp>111</cmp><cmp>var14</cmp><cmp>arrivo_istat</cmp></riga>
<riga><cmp>112</cmp><cmp>var14</cmp><cmp>partenza_istat</cmp></riga>
<riga><cmp>113</cmp><cmp>var14</cmp><cmp>italiano_istat</cmp></riga>
<riga><cmp>114</cmp><cmp>var14</cmp><cmp>ins_nuovo_num_istat</cmp></riga>
<riga><cmp>115</cmp><cmp>var14</cmp><cmp>agg_arr_istat</cmp></riga>
<riga><cmp>116</cmp><cmp>var14</cmp><cmp>agg_part_istat</cmp></riga>
<riga><cmp>117</cmp><cmp>var14</cmp><cmp>num_persone_istat</cmp></riga>
<riga><cmp>118</cmp><cmp>var14</cmp><cmp>anno_istat</cmp></riga>
<riga><cmp>119</cmp><cmp>var14</cmp><cmp>mese_istat</cmp></riga>
<riga><cmp>120</cmp><cmp>var14</cmp><cmp>giorno_istat</cmp></riga>
<riga><cmp>121</cmp><cmp>var14</cmp><cmp>null_istat</cmp></riga>
<riga><cmp>122</cmp><cmp>var14</cmp><cmp>num_prog_istat</cmp></riga>
<riga><cmp>123</cmp><cmp>var14</cmp><cmp>nazione_istat</cmp></riga>
<riga><cmp>124</cmp><cmp>var14</cmp><cmp>nazione1_istat</cmp></riga>
<riga><cmp>125</cmp><cmp>var14</cmp><cmp>provincia_istat</cmp></riga>
<riga><cmp>126</cmp><cmp>var14</cmp><cmp>provincia1_istat</cmp></riga>
<riga><cmp>127</cmp><cmp>var14</cmp><cmp>cli_giorno_prec_istat</cmp></riga>
<riga><cmp>128</cmp><cmp>var14</cmp><cmp>cli_arrivati_istat</cmp></riga>
<riga><cmp>129</cmp><cmp>var14</cmp><cmp>cli_totale_istat</cmp></riga>
<riga><cmp>130</cmp><cmp>var14</cmp><cmp>cli_partiti_istat</cmp></riga>
<riga><cmp>131</cmp><cmp>var14</cmp><cmp>cli_presenti_notte_istat</cmp></riga>
<riga><cmp>132</cmp><cmp>var14</cmp><cmp>agg_istat</cmp></riga>
<riga><cmp>133</cmp><cmp>var14</cmp><cmp>ospite_altra_naz_istat</cmp></riga>
<riga><cmp>134</cmp><cmp>var14</cmp><cmp>ospite_altra_prov_istat</cmp></riga>
<riga><cmp>135</cmp><cmp>var14</cmp><cmp>num_prov_istat</cmp></riga>
<riga><cmp>136</cmp><cmp>var14</cmp><cmp>prox_num_prov_istat</cmp></riga>
<riga><cmp>137</cmp><cmp>var14</cmp><cmp>tot_arr_naz_istat</cmp></riga>
<riga><cmp>138</cmp><cmp>var14</cmp><cmp>tot_part_naz_istat</cmp></riga>
<riga><cmp>139</cmp><cmp>var14</cmp><cmp>tot_arr_prov_istat</cmp></riga>
<riga><cmp>140</cmp><cmp>var14</cmp><cmp>tot_part_prov_istat</cmp></riga>
<riga><cmp>141</cmp><cmp>var14</cmp><cmp>mostra_pag_istat</cmp></riga>
<riga><cmp>142</cmp><cmp>var14</cmp><cmp>ultima_data_istat</cmp></riga>
<riga><cmp>143</cmp><cmp>var14</cmp><cmp>nuova_pag_istat</cmp></riga>
<riga><cmp>144</cmp><cmp>var14</cmp><cmp>agg_pres_istat</cmp></riga>
<riga><cmp>145</cmp><cmp>var14</cmp><cmp>agg_pres_notte_prec_istat</cmp></riga>
<riga><cmp>146</cmp><cmp>var14</cmp><cmp>tot_pres_naz_istat</cmp></riga>
<riga><cmp>147</cmp><cmp>var14</cmp><cmp>tot_pres_notte_prec_naz_istat</cmp></riga>
<riga><cmp>148</cmp><cmp>var14</cmp><cmp>tot_pres_prov_istat</cmp></riga>
<riga><cmp>149</cmp><cmp>var14</cmp><cmp>tot_pres_notte_prec_prov_istat</cmp></riga>
<riga><cmp>150</cmp><cmp>var14</cmp><cmp>camere_occupate_istat</cmp></riga>
<riga><cmp>404</cmp><cmp>var14</cmp><cmp>var_tmp_istat</cmp></riga>
<riga><cmp>40</cmp><cmp>var13</cmp><cmp>null_ps</cmp></riga>
<riga><cmp>41</cmp><cmp>var13</cmp><cmp>codice_ospite_ps</cmp></riga>
<riga><cmp>42</cmp><cmp>var13</cmp><cmp>data_inizio_ps</cmp></riga>
<riga><cmp>43</cmp><cmp>var13</cmp><cmp>cognome_ps</cmp></riga>
<riga><cmp>44</cmp><cmp>var13</cmp><cmp>nome_ps</cmp></riga>
<riga><cmp>45</cmp><cmp>var13</cmp><cmp>sesso_ps</cmp></riga>
<riga><cmp>46</cmp><cmp>var13</cmp><cmp>data_nascita_ps</cmp></riga>
<riga><cmp>47</cmp><cmp>var13</cmp><cmp>comune_ps</cmp></riga>
<riga><cmp>48</cmp><cmp>var13</cmp><cmp>provincia_ps</cmp></riga>
<riga><cmp>49</cmp><cmp>var13</cmp><cmp>comune_resid_ps</cmp></riga>
<riga><cmp>50</cmp><cmp>var13</cmp><cmp>provincia_resid_ps</cmp></riga>
<riga><cmp>51</cmp><cmp>var13</cmp><cmp>nazione_resid_ps</cmp></riga>
<riga><cmp>52</cmp><cmp>var13</cmp><cmp>indirizzo_ps</cmp></riga>
<riga><cmp>53</cmp><cmp>var13</cmp><cmp>tipo_doc_ps</cmp></riga>
<riga><cmp>54</cmp><cmp>var13</cmp><cmp>numero_doc_ps</cmp></riga>
<riga><cmp>55</cmp><cmp>var13</cmp><cmp>luogo_doc_ps</cmp></riga>
<riga><cmp>56</cmp><cmp>var13</cmp><cmp>acapo_ps</cmp></riga>
<riga><cmp>57</cmp><cmp>var13</cmp><cmp>cognome_prec_ps</cmp></riga>
<riga><cmp>58</cmp><cmp>var13</cmp><cmp>nome_prec_ps</cmp></riga>
<riga><cmp>59</cmp><cmp>var13</cmp><cmp>dataini_prec_ps</cmp></riga>
<riga><cmp>60</cmp><cmp>var13</cmp><cmp>datafine_prec_ps</cmp></riga>
<riga><cmp>61</cmp><cmp>var13</cmp><cmp>num_prenota_prec_ps</cmp></riga>
<riga><cmp>62</cmp><cmp>var13</cmp><cmp>num_prenota_tmp_ps</cmp></riga>
<riga><cmp>63</cmp><cmp>var13</cmp><cmp>dataini_corr_ps</cmp></riga>
<riga><cmp>64</cmp><cmp>var13</cmp><cmp>datafine_corr_ps</cmp></riga>
<riga><cmp>153</cmp><cmp>var13</cmp><cmp>num_ripetizione_ps</cmp></riga>
<riga><cmp>154</cmp><cmp>var13</cmp><cmp>mess_errore_ps</cmp></riga>
<riga><cmp>159</cmp><cmp>var13</cmp><cmp>num_periodi_ps</cmp></riga>
<riga><cmp>162</cmp><cmp>var13</cmp><cmp>tmp_ps</cmp></riga>
<riga><cmp>401</cmp><cmp>var13</cmp><cmp>codice_nazione_ps</cmp></riga>
<riga><cmp>402</cmp><cmp>var13</cmp><cmp>codice_nazione_nascita_ps</cmp></riga>
<riga><cmp>403</cmp><cmp>var13</cmp><cmp>codice_nazione_documento_ps</cmp></riga>
<riga><cmp>438</cmp><cmp>var13</cmp><cmp>codice_cittadinanza_ps</cmp></riga>
<riga><cmp>20</cmp><cmp>var12</cmp><cmp>capofamiglia_sa</cmp></riga>
<riga><cmp>21</cmp><cmp>var12</cmp><cmp>nuova_pag_sa</cmp></riga>
<riga><cmp>22</cmp><cmp>var12</cmp><cmp>num_ospite_sa</cmp></riga>
<riga><cmp>23</cmp><cmp>var12</cmp><cmp>mostra_ospite_sa</cmp></riga>
<riga><cmp>24</cmp><cmp>var12</cmp><cmp>null_sa</cmp></riga>
<riga><cmp>25</cmp><cmp>var12</cmp><cmp>ultima_prenota_sa</cmp></riga>
<riga><cmp>26</cmp><cmp>var12</cmp><cmp>nucleo_familiare</cmp></riga>
<riga><cmp>27</cmp><cmp>var12</cmp><cmp>cognome_sa</cmp></riga>
<riga><cmp>28</cmp><cmp>var12</cmp><cmp>nome_sa</cmp></riga>
<riga><cmp>29</cmp><cmp>var12</cmp><cmp>linea_nato_sa</cmp></riga>
<riga><cmp>30</cmp><cmp>var12</cmp><cmp>data_nascita_sa</cmp></riga>
<riga><cmp>31</cmp><cmp>var12</cmp><cmp>cittadinanza_sa</cmp></riga>
<riga><cmp>32</cmp><cmp>var12</cmp><cmp>linea_residenza_sa</cmp></riga>
<riga><cmp>33</cmp><cmp>var12</cmp><cmp>tipo_documento_sa</cmp></riga>
<riga><cmp>34</cmp><cmp>var12</cmp><cmp>numero_documento_sa</cmp></riga>
<riga><cmp>35</cmp><cmp>var12</cmp><cmp>scadenza_documento_sa</cmp></riga>
<riga><cmp>36</cmp><cmp>var12</cmp><cmp>rilascio_documento_sa</cmp></riga>
<riga><cmp>37</cmp><cmp>var12</cmp><cmp>var_tmp_sa</cmp></riga>
<riga><cmp>99</cmp><cmp>var12</cmp><cmp>cognome_prec_sa</cmp></riga>
<riga><cmp>100</cmp><cmp>var12</cmp><cmp>nome_prec_sa</cmp></riga>
<riga><cmp>101</cmp><cmp>var12</cmp><cmp>dataini_prec_sa</cmp></riga>
<riga><cmp>102</cmp><cmp>var12</cmp><cmp>datafine_prec_sa</cmp></riga>
<riga><cmp>103</cmp><cmp>var12</cmp><cmp>dataini_corr_sa</cmp></riga>
<riga><cmp>104</cmp><cmp>var12</cmp><cmp>datafine_corr_sa</cmp></riga>
<riga><cmp>105</cmp><cmp>var12</cmp><cmp>numero_sa</cmp></riga>
<riga><cmp>106</cmp><cmp>var12</cmp><cmp>numero_ripetizione_sa</cmp></riga>
<riga><cmp>107</cmp><cmp>var12</cmp><cmp>num_altri_ospiti_sa</cmp></riga>
<riga><cmp>332</cmp><cmp>var11</cmp><cmp>data_riepilogo_pulizie</cmp></riga>
<riga><cmp>333</cmp><cmp>var11</cmp><cmp>arrivo_pulizie</cmp></riga>
<riga><cmp>334</cmp><cmp>var11</cmp><cmp>partenza_pulizie</cmp></riga>
<riga><cmp>335</cmp><cmp>var11</cmp><cmp>unita_pulizie</cmp></riga>
<riga><cmp>336</cmp><cmp>var11</cmp><cmp>classe_riga_pulizie</cmp></riga>
<riga><cmp>337</cmp><cmp>var11</cmp><cmp>f_data_riepilogo_pulizie</cmp></riga>
<riga><cmp>338</cmp><cmp>var11</cmp><cmp>tot_persone_pulizie</cmp></riga>
<riga><cmp>339</cmp><cmp>var11</cmp><cmp>tot_persone_part_pulizie</cmp></riga>
<riga><cmp>340</cmp><cmp>var11</cmp><cmp>tot_persone_arr_pulizie</cmp></riga>
<riga><cmp>341</cmp><cmp>var11</cmp><cmp>num_ca_pulizie</cmp></riga>
<riga><cmp>342</cmp><cmp>var11</cmp><cmp>numero_ripetizione_pulizie</cmp></riga>
<riga><cmp>343</cmp><cmp>var11</cmp><cmp>var_tmp_pulizie</cmp></riga>
<riga><cmp>344</cmp><cmp>var11</cmp><cmp>intestazione_ca_tabella_pulizie</cmp></riga>
<riga><cmp>345</cmp><cmp>var11</cmp><cmp>riga_ca_tabella_pulizie</cmp></riga>
<riga><cmp>346</cmp><cmp>var11</cmp><cmp>giorno_pulizie</cmp></riga>
<riga><cmp>347</cmp><cmp>var11</cmp><cmp>riga_intestazione_tabella_pulizie</cmp></riga>
<riga><cmp>348</cmp><cmp>var11</cmp><cmp>numero_ripetizione_unita_pulizie</cmp></riga>
<riga><cmp>349</cmp><cmp>var11</cmp><cmp>ripetizione_riga_intestazione_pulizie</cmp></riga>
<riga><cmp>350</cmp><cmp>var11</cmp><cmp>numero_ripetizione_riga_intestazione_pulizie</cmp></riga>
<riga><cmp>436</cmp><cmp>var10</cmp><cmp>cognome_eb</cmp></riga>
<riga><cmp>437</cmp><cmp>var10</cmp><cmp>cogn_no_sp_eb</cmp></riga>
<riga><cmp>1</cmp><cmp>var</cmp><cmp>Mr</cmp></riga>
<riga><cmp>2</cmp><cmp>var</cmp><cmp>il</cmp></riga>
<riga><cmp>3</cmp><cmp>var</cmp><cmp>Il_</cmp></riga>
<riga><cmp>4</cmp><cmp>var</cmp><cmp>al</cmp></riga>
<riga><cmp>5</cmp><cmp>var</cmp><cmp>e</cmp></riga>
<riga><cmp>6</cmp><cmp>var</cmp><cmp>o</cmp></riga>
<riga><cmp>7</cmp><cmp>var</cmp><cmp>el</cmp></riga>
<riga><cmp>8</cmp><cmp>var</cmp><cmp>El_</cmp></riga>
<riga><cmp>9</cmp><cmp>var</cmp><cmp>al3</cmp></riga>
<riga><cmp>10</cmp><cmp>var</cmp><cmp>a</cmp></riga>
<riga><cmp>11</cmp><cmp>var</cmp><cmp>o3</cmp></riga>
<riga><cmp>8</cmp><cmp>opzeml</cmp><cmp>;SI;</cmp></riga>
<riga><cmp>9</cmp><cmp>opzeml</cmp><cmp>;SI;</cmp></riga>
<riga><cmp>10</cmp><cmp>opzeml</cmp><cmp>;SI;</cmp></riga>
<riga><cmp>8</cmp><cmp>oggetto</cmp><cmp>Disponibilità</cmp></riga>
<riga><cmp>9</cmp><cmp>oggetto</cmp><cmp>Conferma prenotazione</cmp></riga>
<riga><cmp>10</cmp><cmp>oggetto</cmp><cmp>Conferma prenotazione</cmp></riga>
<riga><cmp>1</cmp><cmp>nomi_con</cmp><cmp>1#?&Esempio#@&2#?&Fattura#@&3#?&Fattura - rtf#@&4#?&Fattura elettronica#@&5#?&Ricevuta ultimo pagamento#@&6#?&Ricevuta - rtf#@&7#?&Ricevuta elettronica prova#@&8#?&Email disponibilità#@&9#?&Email conferma#@&10#?&Email benvenuto#@&11#?&Riepilogo pulizie#@&12#?&Schedine alloggiati#@&13#?&File alloggiatiweb#@&14#?&ISTAT C/59_G#@&15#?&ISTAT C/59_M#@&16#?&Informativa sulla privacy#@&17#?&Esporta dati clienti#@&18#?&Esporta prenotazioni#@&19#?&ROSS1000#@&20#?&RIMOVCLI - ISTAT Liguria#@&21#?&Turiweb Ricestat#@&22#?&Dati per ISA</cmp></riga>
<riga><cmp>3</cmp><cmp>nomefile</cmp><cmp>Fattura</cmp></riga>
<riga><cmp>4</cmp><cmp>nomefile</cmp><cmp>Fattura_elettronica</cmp></riga>
<riga><cmp>7</cmp><cmp>nomefile</cmp><cmp>Ricevuta_elettronica</cmp></riga>
<riga><cmp>8</cmp><cmp>mln_ita</cmp><cmp>Gentile Signor[a] [cognome_email_disp],
le confermo la disponibilita' di un appartamento[c num_persone_tot!=""] per [num_persone_tot] persone[/c] per il periodo dal [data_inizio] al [data_fine]. Il prezzo per detto periodo e' di [costo_tot_p] [nome_valuta] (comprese le spese accessorie).

Nel caso desideri prenotare, la prego di inviarmi la sua conferma rispondendo a questa email.

Rimango comunque a sua disposizione per qualsiasi informazione.

Cordiali Saluti,
[nome_contatto_struttura]

[nome_struttura]
[sito_web_struttura]


[testo_quotato_email_richiesta]
</cmp></riga>
<riga><cmp>9</cmp><cmp>mln_ita</cmp><cmp>Gentile Signor[a] [cognome_ec],
le confermo che ho prenotato a suo nome un appartamento[c num_persone_tot!=""] per [num_persone_tot] persone[/c] per il periodo dal [data_inizio] al [data_fine]. Il prezzo per detto periodo e' di [costo_tot_p] [nome_valuta] (comprese le spese accessorie). Per completare la prenotazione è necessario versare un anticipo di [caparra_p] [nome_valuta], può effettuare il pagamento seguendo questo link:

[url_base_pagine_web]mdl_conferma_prenotazione.php?cn=[cogn_no_sp_ec]&cp=[codice_prenotazione]

Se questo link non funzionasse correttamente può provare ad utilizzare quest'altro:

[url_base_pagine_web]mdl_conferma_prenotazione.php

per poi inserire:

Cognome: [cognome]
Codice prenotazione: [codice_prenotazione]

Rimango comunque a sua disposizione per qualsiasi altra informazione.

Cordiali Saluti,
[nome_contatto_struttura]

[nome_struttura]
[sito_web_struttura]
</cmp></riga>
<riga><cmp>10</cmp><cmp>mln_ita</cmp><cmp>Gentile Signor[a] [cognome_eb],
ho allegato a questa e-mail un file con i nostri contatti e una mappa per aiutarvi a trovarci, per favore fatemi sapere se avete problemi a leggerlo.

Se volete risparmiare tempo al vostro arrivo, è possibile inserire i dati richiesti per il check-in da qui:

[url_base_pagine_web]mdl_conferma_prenotazione.php?cn=[cogn_no_sp_eb]&cp=[codice_prenotazione]&fe=1

[c orario_entrata_stimato=""]Sapreste indicarci il vostro orario di arrivo previsto? Grazie! [/c]Fatemi sapere se avete altre domande.

Cordiali Saluti,
[nome_contatto_struttura]

[nome_struttura]
[sito_web_struttura]
</cmp></riga>
<riga><cmp>8</cmp><cmp>mln_en</cmp><cmp>Dear Mr[Mr] [cognome_email_disp],
I confirm you the availability of an apartment[c people_num_tot!=""] for [people_num_tot] people[/c] in the period from [starting_date] to [ending_date]. The price for this period is [price_tot_p] [currency_name] (including cleaning and utilities).

If you are interested in reserving the apartment you can contact me by replaying to this email.

Please let me know if you have any question.

Best regards,
[structure_contact_name]

[structure_name]
[structure_website]


[enquiry_email_quoted_text]
</cmp></riga>
<riga><cmp>9</cmp><cmp>mln_en</cmp><cmp>Dear Mr[Mr] [cognome_ec],
I confirm you that I have reserved you an apartment[c people_num_tot!=""] for [people_num_tot] people[/c] in the period from [starting_date] to [ending_date]. The price for this period is [price_tot_p] [currency_name] (including cleaning and utilities). In order to complete the reservation you must send a down-payment of [deposit_p] [currency_name], you can pay it following this link:

[url_base_pagine_web]confirm_reservation_tpl.php?cn=[cogn_no_sp_ec]&cp=[codice_prenotazione]

If the above link does not work properly for you, try this other one:

[url_base_pagine_web]confirm_reservation_tpl.php

and then insert:

Surname: [surname]
Reservation code: [reservation_code]

Please let me know if you have any other question.

Best regards,
[structure_contact_name]

[structure_name]
[structure_website]
</cmp></riga>
<riga><cmp>10</cmp><cmp>mln_en</cmp><cmp>Dear Mr[Mr] [cognome_eb],
I’ve attached to this e-mail a file with our contacts and a map to help you find us, please let me know if you have problems reading it.

If you want to save time at your arrival you can fill in the data required for check-in from here:

[url_base_pagine_web]confirm_reservation_tpl.php?cn=[cogn_no_sp_eb]&cp=[codice_prenotazione]&fe=1

[c estimated_checkin_time=""]Do you know your estimated time of arrival? Thanks! [/c]Please let me know if you have any other question.

Best regards,
[structure_contact_name]

[structure_name]
[structure_website]
</cmp></riga>
<riga><cmp>3</cmp><cmp>impor_vc</cmp><cmp>2</cmp></riga>
<riga><cmp>6</cmp><cmp>impor_vc</cmp><cmp>5</cmp></riga>
<riga><cmp>11</cmp><cmp>headhtm</cmp><cmp><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" >
<title>Riepilogo pulizie</title>
<style type="text/css">
table.clrep { border-collapse: collapse; }
table.clrep td { border: 2px solid black; padding: 2px; text-align: center; }
.headrow { background-color: #cccccc; }
tr.bgclr { background-color: #eeeeee; }
</style>
</head>
<body style="background-color: #ffffff;">
</cmp></riga>
<riga><cmp>4</cmp><cmp>formati</cmp><cmp>usa></cmp></riga>
<riga><cmp>7</cmp><cmp>formati</cmp><cmp>usa></cmp></riga>
<riga><cmp>10</cmp><cmp>formati</cmp><cmp>usa></cmp></riga>
<riga><cmp>10</cmp><cmp>formati</cmp><cmp>usa></cmp></riga>
<riga><cmp>18</cmp><cmp>formati</cmp><cmp>usa></cmp></riga>
<riga><cmp>19</cmp><cmp>formati</cmp><cmp>usa></cmp></riga>
<riga><cmp>24</cmp><cmp>formati</cmp><cmp>usa></cmp></riga>
<riga><cmp>28</cmp><cmp>formati</cmp><cmp>usa></cmp></riga>
<riga><cmp>42</cmp><cmp>formati</cmp><cmp>usa></cmp></riga>
<riga><cmp>44</cmp><cmp>formati</cmp><cmp>usa></cmp></riga>
<riga><cmp>11</cmp><cmp>foothtm</cmp><cmp></body>
</html>
</cmp></riga>
<riga><cmp>4</cmp><cmp>est_txt</cmp><cmp>xml</cmp></riga>
<riga><cmp>7</cmp><cmp>est_txt</cmp><cmp>xml</cmp></riga>
<riga><cmp>17</cmp><cmp>est_txt</cmp><cmp>csv</cmp></riga>
<riga><cmp>18</cmp><cmp>est_txt</cmp><cmp>csv</cmp></riga>
<riga><cmp>20</cmp><cmp>est_txt</cmp><cmp>xml</cmp></riga>
<riga><cmp>2</cmp><cmp>dir</cmp><cmp>~</cmp></riga>
<riga><cmp>3</cmp><cmp>dir</cmp><cmp>~</cmp></riga>
<riga><cmp>4</cmp><cmp>dir</cmp><cmp>~</cmp></riga>
<riga><cmp>7</cmp><cmp>dir</cmp><cmp>~</cmp></riga>
<riga><cmp>4</cmp><cmp>contrtxt</cmp><cmp>[r][r3][/r3][valore_nullo][/r]<?xml version="1.0" encoding="UTF-8"?>
<p:FatturaElettronica versione="FPR12" xmlns:ds="http://www.w3.org/2000/09/xmldsig#" xmlns:p="http://ivaservizi.agenziaentrate.gov.it/docs/xsd/fatture/v1.2" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://ivaservizi.agenziaentrate.gov.it/docs/xsd/fatture/v1.2 http://www.fatturapa.gov.it/export/fatturazione/sdi/fatturapa/v1.2/Schema_del_file_xml_FatturaPA_versione_1.2.xsd">
  <FatturaElettronicaHeader>
    <DatiTrasmissione>
      <IdTrasmittente>
        <IdPaese>IT</IdPaese>
        <IdCodice>[partita_iva_struttura]</IdCodice>
      </IdTrasmittente>
      <ProgressivoInvio>[numero_progressivo_documento]</ProgressivoInvio>
      <FormatoTrasmissione>FPR12</FormatoTrasmissione>
      <CodiceDestinatario>[cod_destinatario_fael]</CodiceDestinatario>
      [contatti_trasmittente_fael]
      [linea_pecdestinatario_fael]
    </DatiTrasmissione>
    <CedentePrestatore>
      <DatiAnagrafici>
        <IdFiscaleIVA>
          <IdPaese>IT</IdPaese>
          <IdCodice>[partita_iva_struttura]</IdCodice>
        </IdFiscaleIVA>
        <Anagrafica>
          <Denominazione>[ragione_sociale_struttura]</Denominazione>
        </Anagrafica>
        <RegimeFiscale>RF11</RegimeFiscale>
      </DatiAnagrafici>
      <Sede>
        <Indirizzo>[indirizzo_struttura]</Indirizzo>
        <CAP>[CAP_struttura]</CAP>
        <Comune>[comune_struttura]</Comune>
        <Provincia>[provincia_struttura_fael]</Provincia>
        <Nazione>IT</Nazione>
      </Sede>
    </CedentePrestatore>
    <CessionarioCommittente>
      <DatiAnagrafici>
[c partita_iva_fael!=""]        <IdFiscaleIVA>
          <IdPaese>[codice_nazione_fael]</IdPaese>
          <IdCodice>[partita_iva_fael]</IdCodice>
        </IdFiscaleIVA>
[/c][c codice_fiscale_fael!=""]        <CodiceFiscale>[codice_fiscale_fael]</CodiceFiscale>
[/c]        <Anagrafica>
[c nome_fael=""]          <Denominazione>[cognome_fael]</Denominazione>
[/c][c nome_fael!=""]          <Nome>[nome_fael]</Nome>
          <Cognome>[cognome_fael]</Cognome>
[/c]        </Anagrafica>
      </DatiAnagrafici>
      <Sede>
        <Indirizzo>[via_fael]</Indirizzo>
        <CAP>[cap]</CAP>
        <Comune>[citta]</Comune>
[c codice_nazione_fael="IT"]        <Provincia>[codice_regione]</Provincia>
[/c]        <Nazione>[codice_nazione_fael]</Nazione>
      </Sede>
    </CessionarioCommittente>
  </FatturaElettronicaHeader>
  <FatturaElettronicaBody>
    <DatiGenerali>
      <DatiGeneraliDocumento>
        <TipoDocumento>TD01</TipoDocumento>
        <Divisa>EUR</Divisa>
        <Data>[oggi_fael]</Data>
        <Numero>[numero_progressivo_documento]</Numero>
        <ImportoTotaleDocumento>[costo_tot_fael_p]</ImportoTotaleDocumento>
        <Causale>Prenotazione di [nome] [cognome][presso_fael]</Causale>
      </DatiGeneraliDocumento>
    </DatiGenerali>
    <DatiBeniServizi>
[r4 array="iva_perc_vett_fael"][r][c mos_tariffa_fael="1"]      <DettaglioLinee>
        <NumeroLinea>[num_linea_fael]</NumeroLinea>
        <Descrizione>Pernottamento dal [data_inizio] al [data_fine][frase_persone_fael]</Descrizione>
        <Quantita>1.00</Quantita>
        <PrezzoUnitario>[tariffa_no_iva_fael_p]</PrezzoUnitario>
        <PrezzoTotale>[tariffa_no_iva_fael_p]</PrezzoTotale>
        <AliquotaIVA>[iva_perc_vett_fael_p(num_iva_fael)]</AliquotaIVA>
        [natura_fael(num_iva_fael)]
      </DettaglioLinee>
[/c][r3][c mos_costo_agg_fael="1"]      <DettaglioLinee>
        <NumeroLinea>[num_linea_fael]</NumeroLinea>
        <Descrizione>Extra: "[nome_costo_agg]"</Descrizione>
        <Quantita>1.00</Quantita>
        <PrezzoUnitario>[costo_agg_no_iva_fael_p]</PrezzoUnitario>
        <PrezzoTotale>[costo_agg_no_iva_fael_p]</PrezzoTotale>
        <AliquotaIVA>[iva_perc_vett_fael_p(num_iva_fael)]</AliquotaIVA>
        [natura_fael(num_iva_fael)]
      </DettaglioLinee>
[/c][/r3][/r][/r4][r4 array="iva_perc_vett_fael"]      <DatiRiepilogo>
        <AliquotaIVA>[iva_perc_vett_fael_p(num_iva_fael)]</AliquotaIVA>
        [natura_fael(num_iva_fael)]
        <ImponibileImporto>[tot_no_iva_vett_fael_p(num_iva_fael)]</ImponibileImporto>
        <Imposta>[tot_iva_vett_fael_p(num_iva_fael)]</Imposta>
      </DatiRiepilogo>
[/r4]    </DatiBeniServizi>
  </FatturaElettronicaBody>
</p:FatturaElettronica>
</cmp></riga>
<riga><cmp>7</cmp><cmp>contrtxt</cmp><cmp>[r][r3][/r3][valore_nullo][/r][r4 array="iva_perc_vett_rfel"][r][valore_nullo][r3][valore_nullo][/r3][/r][/r4]<?xml version="1.0" encoding="UTF-8"?>
  <DatiFatturaHeader>
      <ProgressivoInvio>[numero_progressivo_documento]</ProgressivoInvio>
  </DatiFatturaHeader>
  <DTE>
    <CedentePrestatoreDTE>
      <IdentificativiFiscali>
        <IdFiscaleIVA>
          <IdPaese>IT</IdPaese>
          <IdCodice>[partita_iva_struttura]</IdCodice>
        </IdFiscaleIVA>
        <CodiceFiscale>[cod_fisc_strutt_rfel]</CodiceFiscale>
      </IdentificativiFiscali>
    </CedentePrestatoreDTE>
    <CessionarioCommittenteDTE>
      <IdentificativiFiscali>
        <IdFiscaleIVA>
          <IdPaese>XX</IdPaese>
          <IdCodice>COR10</IdCodice>
        </IdFiscaleIVA>
      </IdentificativiFiscali>
      <DatiFatturaBodyDTE>
        <DatiGenerali>
          <TipoDocumento>TD12</TipoDocumento>
          <Data>[oggi_rfel]</Data>
          <Numero>[numero_progressivo_documento]</Numero>
        </DatiGenerali>
[r4 array="iva_perc_vett_rfel"]        <DatiRiepilogo>
          <ImponibileImporto>[tot_no_iva_vett_rfel_p(num_iva_rfel)]</ImponibileImporto>
          <DatiIVA>
            <Imposta>[tot_iva_vett_rfel_p(num_iva_rfel)]</Imposta>
            <AliquotaIVA>[iva_perc_vett_rfel_p(num_iva_rfel)]</AliquotaIVA>
          </DatiIVA>
          [natura_rfel(num_iva_rfel)]
        </DatiRiepilogo>
[/r4]      </DatiFatturaBodyDTE>
    </CessionarioCommittenteDTE>
  </DTE>
</cmp></riga>
<riga><cmp>13</cmp><cmp>contrtxt</cmp><cmp>[r][r2][null_ps][/r2][/r][r][r2][acapo_ps][codice_ospite_ps][data_inizio_ps][num_periodi_ps][cognome_ps][nome_ps][sesso_ps][data_nascita_ps][comune_ps][provincia_ps][codice_nazione_nascita_ps][codice_cittadinanza_ps][tipo_doc_ps][numero_doc_ps][luogo_doc_ps][/r2][/r]</cmp></riga>
<riga><cmp>16</cmp><cmp>contrtxt</cmp><cmp>[r][/r]Ai sensi dell'art. 13 D.Lgs. 196/2003 (informativa sul trattamento dei dati personali) autorizzo[c ragione_sociale_struttura!=""] "[ragione_sociale_struttura]"[/c] al trattamento dei miei dati personali ai fini dell'espletamento del servizio.</cmp></riga>
<riga><cmp>17</cmp><cmp>contrtxt</cmp><cmp>Cognome,Nome,Soprannome,Titolo,Sesso,Email,2ª Email,PEC,Telefono,2º Telefono,3º Telefono,Fax,Lingua,Nazione di Residenza,Regione di Residenza,Città di Residenza,Indirizzo,CAP,Cittadinanza,Data di Nascita,Partita Iva
[r][cognome_csv],[nome_csv],[soprannome_csv],[titolo_csv],[sesso],[email_csv],[email2_csv],[pec_csv],[telefono_csv],[telefono2_csv],[telefono3_csv],[fax_csv],[codice_lingua],[nazione_csv],[regione_csv],[citta_csv],[indirizzo_csv],[cap_csv],[cittadinanza_csv],[data_nascita_csv],[partita_iva_csv]
[/r]</cmp></riga>
<riga><cmp>18</cmp><cmp>contrtxt</cmp><cmp>Arrivo,Partenza,Cognome,Nome,Email,Telefono,Totale Persone,Unità Occupata,Nome Tariffa,Prezzo Tariffa,Prezzo Totale,Pagato,Commento
[r][arrivo_rcsv],[partenza_rcsv],[cognome_rcsv],[nome_rcsv],[email_rcsv],[telefono_rcsv],[totale_persone_rcsv],[unita_rcsv],[nome_tariffa_rcsv],[prezzo_tariffa_rcsv],[prezzo_totale_rcsv],[pagato_rcsv],[commento_rcsv]
[/r]</cmp></riga>
<riga><cmp>19</cmp><cmp>contrtxt</cmp><cmp>[r][r2][null_ross][/r2][/r][r][r2][acapo_ross][codice_ospite_ross][data_inizio_ross]                                                                                [sesso_ross][data_nascita_ross]           [codice_nazione_nascita_ross][codice_cittadinanza_ross][comune_resid_ross][provincia_resid_ross][codice_nazione_ross]                                                                                    [data_fine_ross]                                                            [c codice_ospite_ross="16"]001[/c][c codice_ospite_ross="17"]001[/c][c codice_ospite_ross="18"]001[/c][c codice_ospite_ross="19"]000[/c][c codice_ospite_ross="20"]000[/c]       0[num_prenota_ross][num_prenota2_ross]1[/r2][/r]</cmp></riga>
<riga><cmp>20</cmp><cmp>contrtxt</cmp><cmp><?xml version="1.0" encoding="UTF-8"?>[r4 array="date_rimovcli"][r][r2][null_rimovcli][/r2][/r][c mostra_pag_rimovcli!="0"]
<rm:c59 idstruttura="[id_struttura_rimovcli]" data="[data_corr_rimovcli]" xmlns:rm="http://www.regione.liguria.it/turismo/rimovcli" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<mensile numcameredisp="[camere_disponibili_rimovcli]" numlettidisp="[letti_disponibili_rimovcli]" softwaregestionale="HotelDruid"/>
<giornaliero numcamereoccupate="[camere_occupate_rimovcli]">
[/c][r4 array="ripetizioni_tab_rimovcli"][c mostra_naz_rimovcli(pos_rimovcli)!=""]<rigac59 nazione="e" residenza="[naz_pos_rimovcli(pos_rimovcli)]" presenti="[presenze_naz_rimovcli(pos_rimovcli)]" partiti="[partenze_naz_rimovcli(pos_rimovcli)]" arrivati="[arrivi_naz_rimovcli(pos_rimovcli)]"/>
[/c][c mostra_prov_rimovcli(pos_rimovcli)!=""]<rigac59 nazione="i" residenza="[prov_pos_rimovcli(pos_rimovcli)]" presenti="[presenze_prov_rimovcli(pos_rimovcli)]" partiti="[partenze_prov_rimovcli(pos_rimovcli)]" arrivati="[arrivi_prov_rimovcli(pos_rimovcli)]"/>
[/c][/r4][c mostra_pag_rimovcli!="0"]</giornaliero>
</rm:c59>[/c][/r4][r][null_rimovcli][/r]</cmp></riga>
<riga><cmp>21</cmp><cmp>contrtxt</cmp><cmp><messaggio-turiweb xmlns="http://www.w4b.it/turiweb" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.w4b.it/turiweb http://www.w4b.it/turiweb/turiweb.xsd">
<report id-struttura="[id_struttura_turiweb]">
<riepilogo-mensile anno="[anno_sel_turiweb]" mese="[mese_sel_turiweb]">
[r4 array="date_turiweb"][r][r2][null_turiweb][/r2][/r][r4 array="ripetizioni_tab_turiweb"][c naz_pos_turiweb(pos_turiweb)!=""]<riga provenienza="[naz_pos_turiweb(pos_turiweb)]" giorno="[giorno_turiweb]" arrivi="[arrivi_naz_turiweb(pos_turiweb)]" partenze="[partenze_naz_turiweb(pos_turiweb)]"/>
[/c][c prov_pos_turiweb(pos_turiweb)!=""]<riga provenienza="[prov_pos_turiweb(pos_turiweb)]" giorno="[giorno_turiweb]" arrivi="[arrivi_prov_turiweb(pos_turiweb)]" partenze="[partenze_prov_turiweb(pos_turiweb)]"/>
[/c][/r4][/r4]</riepilogo-mensile>
</report>
</messaggio-turiweb>
</cmp></riga>
<riga><cmp>3</cmp><cmp>contrrtf</cmp><cmp>{\rtf1\ansi\deff1\adeflang1025[r][r3][/r3] [/r]
{\fonttbl{\f0\froman\fprq2\fcharset0 Times New Roman;}{\f1\froman\fprq2\fcharset0 Times New Roman;}{\f2\fswiss\fprq2\fcharset0 Arial;}{\f3\fswiss\fprq2\fcharset0 Arial;}{\f4\fswiss\fprq2\fcharset0 Bitstream Vera Sans;}{\f5\fswiss\fprq2\fcharset0 Tahoma;}{\f6\froman\fprq2\fcharset0 Garamond;}{\f7\froman\fprq2\fcharset0 Times New Roman;}{\f8\fnil\fprq2\fcharset0 Bitstream Vera Sans;}}
{\colortbl;\red0\green0\blue0;\red230\green230\blue230;\red255\green255\blue255;\red204\green204\blue204;\red128\green128\blue128;}
{\stylesheet{\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\snext1 Normal;}
{\s2\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af8\afs28\lang255\ltrch\dbch\af8\langfe255\hich\f2\fs28\lang1040\loch\f2\fs28\lang1040\sbasedon1\snext3 Heading;}
{\s3\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af3\langfe255\hich\f1\fs24\lang1033\loch\f1\fs24\lang1033\sbasedon1\snext3 Body Text;}
{\s4{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1033\loch\f1\fs24\lang1033\sbasedon3\snext4 List;}
{\s5\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext5 caption;}
{\s6{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext6 Index;}
{\s7\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 Heading;}
{\s8\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext8 caption;}
{\s9{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext9 Index;}
{\s10\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading;}
{\s11\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext11 WW-caption;}
{\s12{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext12 WW-Index;}
{\s13\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading1;}
{\s14\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext14 WW-caption1;}
{\s15{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext15 WW-Index1;}
{\s16\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading11;}
{\s17\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext17 WW-caption11;}
{\s18{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext18 WW-Index11;}
{\s19\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading111;}
{\s20\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext20 WW-caption111;}
{\s21{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext21 WW-Index111;}
{\s22\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading1111;}
{\s23\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext23 WW-caption1111;}
{\s24{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext24 WW-Index1111;}
{\s25\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading11111;}
{\s26\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext26 WW-caption11111;}
{\s27{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext27 WW-Index11111;}
{\s28\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading111111;}
{\s29\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext29 WW-caption111111;}
{\s30{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext30 WW-Index111111;}
{\s31\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading1111111;}
{\s32\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext32 WW-caption1111111;}
{\s33{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext33 WW-Index1111111;}
{\s34\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af4\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f4\fs28\lang1040\loch\f4\fs28\lang1040\sbasedon1\snext3 WW-Heading11111111;}
{\s35\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext35 WW-caption11111111;}
{\s36{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af3\langfe255\hich\f1\fs24\lang1033\loch\f1\fs24\lang1033\sbasedon1\snext36 WW-Index11111111;}
{\s37\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs20\lang255\ai\ltrch\dbch\af3\langfe255\hich\f1\fs20\lang1033\i\loch\f1\fs20\lang1033\i\sbasedon1\snext37 Dicitura;}
{\s38{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af5\afs16\lang255\ltrch\dbch\af3\langfe255\hich\f5\fs16\lang1033\loch\f5\fs16\lang1033\sbasedon1\snext38 WW-Testo fumetto;}
{\s39{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1033\loch\f1\fs24\lang1033\sbasedon3\snext39 Frame contents;}
{\s40{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1033\loch\f1\fs24\lang1033\sbasedon3\snext40 Table Contents;}
{\s41\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ab\ltrch\dbch\langfe255\hich\f1\fs24\lang1033\i\b\loch\f1\fs24\lang1033\i\b\sbasedon40\snext41 Table Heading;}
{\s42{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext42 WW-Table Contents;}
{\s43\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon42\snext43 WW-Table Heading;}
{\s44{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext44 WW-Table Contents1;}
{\s45\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon44\snext45 WW-Table Heading1;}
{\s46{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext46 WW-Table Contents12;}
{\s47\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon46\snext47 WW-Table Heading12;}
{\s48{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext48 WW-Table Contents123;}
{\s49\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon48\snext49 WW-Table Heading123;}
{\s50{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext50 WW-Table Contents1234;}
{\s51\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon50\snext51 WW-Table Heading1234;}
{\s52{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext52 WW-Table Contents12345;}
{\s53\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon52\snext53 WW-Table Heading12345;}
{\s54{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext54 WW-Table Contents123456;}
{\s55\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon54\snext55 WW-Table Heading123456;}
{\s56{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext56 WW-Table Contents1234567;}
{\s57\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon56\snext57 WW-Table Heading1234567;}
{\s58{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext58 WW-Table Contents12345678;}
{\s59\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon58\snext59 WW-Table Heading12345678;}
{\s60{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext60 Table Contents;}
{\s61\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon60\snext61 Table Heading;}
{\*\cs63\cf0\rtlch\af1\afs24\lang255\ltrch\dbch\af3\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 WW-Car. predefinito paragrafo;}
}
{\info{\creatim\yr2007\mo9\dy28\hr15\min45}{\revtim\yr1601\mo1\dy1\hr0\min0}{\printim\yr1601\mo1\dy1\hr0\min0}{\comment StarWriter}{\vern3000}}\deftab708
{\*\pgdsctbl
{\pgdsc0\pgdscuse195\pgwsxn11905\pghsxn16837\marglsxn1134\margrsxn1134\margtsxn885\margbsxn1012\pgdscnxt0 Standard;}}
{\*\pgdscno0}\paperh16837\paperw11905\margl1134\margr1134\margt885\margb1012\sectd\sbknone\pgwsxn11905\pghsxn16837\marglsxn1134\margrsxn1134\margtsxn885\margbsxn1012\ftnbj\ftnstart1\ftnrstcont\ftnnar\aenddoc\aftnrstcont\aftnstart1\aftnnrlc
\pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af6\afs28\lang255\ab\ltrch\dbch\af1\langfe255\hich\f6\fs28\lang1040\b\loch\f6\fs28\lang1040\b {\rtlch \ltrch\loch\f6\fs28\lang1040\i0\b [tipo_struttura] [nome_struttura]}
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af6\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f6\fs24\lang1040\loch\f6\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 [ragione_sociale_struttura]}
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f6\fs24\lang1040\loch\f6\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 [indirizzo_struttura] - [comune_struttura]}
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 [CAP_struttura] [nazione_struttura]}
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 Partita IVA [partita_iva_struttura] [cod_fisc_strutt_fatt]}
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af6\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f6\fs24\lang1040\loch\f6\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 [telefono_strutt_fatt]}
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\li5370\ri0\lin5370\rin0\fi0\ql\rtlch\af6\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f6\fs24\lang1040\loch\f6\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 Spett.le [nome_fatt] [cognome_fatt] }
[c via_fatt!=""]\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 \tab \tab \tab \tab \tab \tab \tab \tab [via_fatt][numcivico_fatt]}
[/c][c riga_citta_fatt!=""]\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 \tab \tab \tab \tab \tab \tab \tab \tab [riga_citta_fatt]}
[/c][c riga_stato_fatt!=""]\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 \tab \tab \tab \tab \tab \tab \tab \tab [riga_stato_fatt]}
[/c][c codice_fiscale_fatt!=""]\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 \tab \tab \tab \tab \tab \tab \tab \tab Codice fiscale [codice_fiscale_fatt]}
[/c][c partita_iva_fatt!=""]\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 \tab \tab \tab \tab \tab \tab \tab \tab Partita IVA [partita_iva_fatt]}
[/c]\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\brdrb\brdrs\brdrw20\brdrcf1\brsp20{\*\brdrb\brdlncol1\brdlnin0\brdlnout20\brdlndist0}\brsp20\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \pard\plain \ltrpar\s1\tx3540{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 \tab }
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af6\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f6\fs24\lang1040\loch\f6\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 Fattura n. [numero_progressivo_documento] del [oggi]}
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \trowd\trql\trleft276\trrh-119\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrb\brdrs\brdrw1\brdrcf1\cellx7792\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalb\cellx9637
[r4 array="iva_perc_vett_fatt"]
\pard\intbl\pard\plain \intbl\ltrpar\s1\cf0\cbpat3\ql\rtlch\afs12\lang255\ltrch\dbch\langfe255\hich\fs12\lang1040\loch\fs12\lang1040 
\cell\pard\plain \intbl\ltrpar\s1\cf0\ql\rtlch\afs24\lang255\ltrch\dbch\langfe255\hich\fs24\lang1040\loch\fs24\lang1040 
[r]
[c mos_tariffa_fatt="1"]\cell\row\pard \trowd\trql\trleft276\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\cellx7792\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 Pernottamento dal [data_inizio] al [data_fine][frase_persone_fatt]}
\cell\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\qr\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 [nome_valuta] [tariffa_no_iva_fatt_p]}
[/c][c mos_sconto_fatt="1"]\cell\row\pard \trowd\trql\trleft276\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\cellx7792\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 Sconto}
\cell\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\qr\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 [nome_valuta] [sconto_no_iva_fatt_p]}
[/c]
[r3][c mos_costo_agg_fatt="1"]\cell\row\pard \trowd\trql\trleft276\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\cellx7792\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 Extra: \'93[nome_costo_agg]\'94}
\cell\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\qr\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 [nome_valuta] [costo_agg_no_iva_fatt_p]}
[/c][c mos_costo_come_tasse_fatt="1"]\cell\row\pard \trowd\trql\trleft276\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\cellx7792\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 Tassa: \'93[nome_costo_agg]\'94}
\cell\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\qr\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 [nome_valuta] [tasse_costo_agg_p]}
[/c][/r3][/r]
[c mos_subtotale_fatt="1"]\cell\row\pard \trowd\trql\trleft276\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\cellx7792\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 Imponibile al [iva_perc_vett_fatt(num_iva_fatt)]%}
\cell\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\qr\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 [nome_valuta] [tot_parz_no_iva_fatt_p]}
\cell\row\pard \trowd\trql\trleft276\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\cellx7792\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 Iva al [iva_perc_vett_fatt(num_iva_fatt)]%}
\cell\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\qr\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 [nome_valuta] [tot_parz_iva_fatt_p]}
[/c]\cell\row\pard \trowd\trql\trleft276\trrh-119\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat3\cellx7792\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat3\clvertalb\cellx9637
[/r4]
\pard\intbl\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs12\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs12\lang1040\loch\f1\fs12\lang1040 
\cell\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\qr\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\cell\row\pard \trowd\trql\trleft276\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\cellx7792\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 Totale Imponibile}
\cell\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\qr\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 [nome_valuta] [tot_no_iva_fatt_p]}
\cell\row\pard \trowd\trql\trleft276\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\cellx7792\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 Totale Imposte[c num_iva_fatt="1"] al [iva_perc_vett_fatt(num_iva_fatt)]%[/c]}
\cell\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\qr\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 [nome_valuta] [iva_fatt_p]}
[r][r3][c mos_costo_tassa_fatt="1"]
\cell\row\pard \trowd\trql\trleft276\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\cellx7792\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 [nome_costo_agg]}
\cell\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\qr\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 [nome_valuta] [costo_agg_no_iva_fatt_p]}
[/c][/r3][/r]
\cell\row\pard \trowd\trql\trleft276\trrh-119\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat3\cellx7792\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat3\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs12\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs12\lang1040\loch\f1\fs12\lang1040 
\cell\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\qr\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\cell\row\pard \trowd\trql\trleft276\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat4\cellx7792\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat4\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1\cf0\ql\rtlch\afs24\lang255\ltrch\dbch\langfe255\hich\fs24\lang1040\loch\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 Totale Fattura}
\cell\pard\plain \intbl\ltrpar\s1\cf0\qr\rtlch\afs24\lang255\ab\ltrch\dbch\langfe255\hich\fs24\lang1040\b\loch\fs24\lang1040\b {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b [nome_valuta] [costo_tot_fatt_p]}
\cell\row\pard \pard\plain \ltrpar\s1\cf0\ql\rtlch\afs24\lang255\ltrch\dbch\langfe255\hich\fs24\lang1040\loch\fs24\lang1040 
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\brdrb\brdrs\brdrw20\brdrcf1\brsp20{\*\brdrb\brdlncol1\brdlnin0\brdlnout20\brdlndist0}\brsp20\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par }</cmp></riga>
<riga><cmp>6</cmp><cmp>contrrtf</cmp><cmp>{\rtf1\ansi\deff1\adeflang1025
{\fonttbl{\f0\froman\fprq2\fcharset0 Times New Roman;}{\f1\froman\fprq2\fcharset0 Times New Roman;}{\f2\fswiss\fprq2\fcharset0 Arial;}{\f3\fswiss\fprq2\fcharset0 Arial;}{\f4\fswiss\fprq2\fcharset0 Bitstream Vera Sans;}{\f5\fswiss\fprq2\fcharset0 Tahoma;}{\f6\froman\fprq2\fcharset0 Garamond;}{\f7\froman\fprq2\fcharset0 Times New Roman;}{\f8\fnil\fprq2\fcharset0 Bitstream Vera Sans;}}
{\colortbl;\red0\green0\blue0;\red230\green230\blue230;\red255\green255\blue255;\red204\green204\blue204;\red128\green128\blue128;}
{\stylesheet{\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\snext1 Normal;}
{\s2\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af8\afs28\lang255\ltrch\dbch\af8\langfe255\hich\f2\fs28\lang1040\loch\f2\fs28\lang1040\sbasedon1\snext3 Heading;}
{\s3\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af3\langfe255\hich\f1\fs24\lang1033\loch\f1\fs24\lang1033\sbasedon1\snext3 Body Text;}
{\s4{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1033\loch\f1\fs24\lang1033\sbasedon3\snext4 List;}
{\s5\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext5 caption;}
{\s6{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext6 Index;}
{\s7\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 Heading;}
{\s8\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext8 caption;}
{\s9{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext9 Index;}
{\s10\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading;}
{\s11\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext11 WW-caption;}
{\s12{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext12 WW-Index;}
{\s13\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading1;}
{\s14\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext14 WW-caption1;}
{\s15{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext15 WW-Index1;}
{\s16\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading11;}
{\s17\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext17 WW-caption11;}
{\s18{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext18 WW-Index11;}
{\s19\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading111;}
{\s20\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext20 WW-caption111;}
{\s21{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext21 WW-Index111;}
{\s22\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading1111;}
{\s23\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext23 WW-caption1111;}
{\s24{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext24 WW-Index1111;}
{\s25\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading11111;}
{\s26\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext26 WW-caption11111;}
{\s27{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext27 WW-Index11111;}
{\s28\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading111111;}
{\s29\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext29 WW-caption111111;}
{\s30{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext30 WW-Index111111;}
{\s31\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af3\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f3\fs28\lang1040\loch\f3\fs28\lang1040\sbasedon1\snext3 WW-Heading1111111;}
{\s32\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext32 WW-caption1111111;}
{\s33{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext33 WW-Index1111111;}
{\s34\sb240\sa120\keepn{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af4\afs28\lang255\ltrch\dbch\af4\langfe255\hich\f4\fs28\lang1040\loch\f4\fs28\lang1040\sbasedon1\snext3 WW-Heading11111111;}
{\s35\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\i\loch\f1\fs24\lang1040\i\sbasedon1\snext35 WW-caption11111111;}
{\s36{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af3\langfe255\hich\f1\fs24\lang1033\loch\f1\fs24\lang1033\sbasedon1\snext36 WW-Index11111111;}
{\s37\sb120\sa120{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs20\lang255\ai\ltrch\dbch\af3\langfe255\hich\f1\fs20\lang1033\i\loch\f1\fs20\lang1033\i\sbasedon1\snext37 Dicitura;}
{\s38{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af5\afs16\lang255\ltrch\dbch\af3\langfe255\hich\f5\fs16\lang1033\loch\f5\fs16\lang1033\sbasedon1\snext38 WW-Testo fumetto;}
{\s39{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1033\loch\f1\fs24\lang1033\sbasedon3\snext39 Frame contents;}
{\s40{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1033\loch\f1\fs24\lang1033\sbasedon3\snext40 Table Contents;}
{\s41\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ai\ab\ltrch\dbch\langfe255\hich\f1\fs24\lang1033\i\b\loch\f1\fs24\lang1033\i\b\sbasedon40\snext41 Table Heading;}
{\s42{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext42 WW-Table Contents;}
{\s43\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon42\snext43 WW-Table Heading;}
{\s44{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext44 WW-Table Contents1;}
{\s45\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon44\snext45 WW-Table Heading1;}
{\s46{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext46 WW-Table Contents12;}
{\s47\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon46\snext47 WW-Table Heading12;}
{\s48{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext48 WW-Table Contents123;}
{\s49\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon48\snext49 WW-Table Heading123;}
{\s50{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext50 WW-Table Contents1234;}
{\s51\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon50\snext51 WW-Table Heading1234;}
{\s52{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext52 WW-Table Contents12345;}
{\s53\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon52\snext53 WW-Table Heading12345;}
{\s54{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext54 WW-Table Contents123456;}
{\s55\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon54\snext55 WW-Table Heading123456;}
{\s56{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext56 WW-Table Contents1234567;}
{\s57\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon56\snext57 WW-Table Heading1234567;}
{\s58{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext58 WW-Table Contents12345678;}
{\s59\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon58\snext59 WW-Table Heading12345678;}
{\s60{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040\sbasedon1\snext60 Table Contents;}
{\s61\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ab\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\b\loch\f1\fs24\lang1040\b\sbasedon60\snext61 Table Heading;}
{\*\cs63\cf0\rtlch\af1\afs24\lang255\ltrch\dbch\af3\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 WW-Car. predefinito paragrafo;}
}
{\info{\creatim\yr2007\mo9\dy28\hr15\min45}{\revtim\yr1601\mo1\dy1\hr0\min0}{\printim\yr1601\mo1\dy1\hr0\min0}{\comment StarWriter}{\vern3000}}\deftab708
{\*\pgdsctbl
{\pgdsc0\pgdscuse195\pgwsxn11905\pghsxn16837\marglsxn1134\margrsxn1134\margtsxn885\margbsxn1012\pgdscnxt0 Standard;}}
{\*\pgdscno0}\paperh16837\paperw11905\margl1134\margr1134\margt885\margb1012\sectd\sbknone\pgwsxn11905\pghsxn16837\marglsxn1134\margrsxn1134\margtsxn885\margbsxn1012\ftnbj\ftnstart1\ftnrstcont\ftnnar\aenddoc\aftnrstcont\aftnstart1\aftnnrlc
[r][c numero_ripetizione_prenotazioni!="1"]\par \page [/c]\pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af6\afs28\lang255\ab\ltrch\dbch\af1\langfe255\hich\f6\fs28\lang1040\b\loch\f6\fs28\lang1040\b {\rtlch \ltrch\loch\f6\fs28\lang1040\i0\b [tipo_struttura] [nome_struttura]}
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af6\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f6\fs24\lang1040\loch\f6\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 [ragione_sociale_struttura]}
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f6\fs24\lang1040\loch\f6\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 [indirizzo_struttura] - [comune_struttura]}
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 [CAP_struttura] [nazione_struttura]}
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 Partita IVA [partita_iva_struttura] [cod_fisc_strutt_ricev]}
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af6\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f6\fs24\lang1040\loch\f6\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 [telefono_strutt_ricev]}
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\li5370\ri0\lin5370\rin0\fi0\ql\rtlch\af6\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f6\fs24\lang1040\loch\f6\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 [c cognome_ricev!=""]Spett.le [nome_ricev] [cognome_ricev][/c] }
[c via!=""]\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 \tab \tab \tab \tab \tab \tab \tab \tab [via][numcivico_ricev]}
[/c][c riga_citta_ricev!=""]\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 \tab \tab \tab \tab \tab \tab \tab \tab [riga_citta_ricev]}
[/c][c riga_stato_ricev!=""]\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 \tab \tab \tab \tab \tab \tab \tab \tab [riga_stato_ricev]}
[/c][c codice_fiscale!=""]\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 \tab \tab \tab \tab \tab \tab \tab \tab Codice fiscale [codice_fiscale]}
[/c][c partita_iva!=""]\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 \tab \tab \tab \tab \tab \tab \tab \tab Partita IVA [partita_iva]}
[/c]\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\brdrb\brdrs\brdrw20\brdrcf1\brsp20{\*\brdrb\brdlncol1\brdlnin0\brdlnout20\brdlndist0}\brsp20\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \pard\plain \ltrpar\s1\tx3540{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 \tab }
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af6\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f6\fs24\lang1040\loch\f6\fs24\lang1040 {\rtlch \ltrch\loch\f6\fs24\lang1040\i0\b0 Ricevuta[c numero_progressivo_documento!=""] n. [numero_progressivo_documento][/c] del [oggi]}
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \trowd\trql\trleft276\trrh-119\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrb\brdrs\brdrw1\brdrcf1\cellx7792\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1\cf0\cbpat3\ql\rtlch\afs12\lang255\ltrch\dbch\langfe255\hich\fs12\lang1040\loch\fs12\lang1040 
\cell\pard\plain \intbl\ltrpar\s1\cf0\ql\rtlch\afs24\lang255\ltrch\dbch\langfe255\hich\fs24\lang1040\loch\fs24\lang1040 
\cell\row\pard \trowd\trql\trleft276\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\cellx7792\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 [c data_inizio!=""]Prenotazione dal [data_inizio] al [data_fine][/c][c num_persone_tot!=""] per [num_persone_tot] persone[/c][c data_inizio=""][metodo_ultimo_pagamento][/c]}
\cell\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\qr\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 [c mostra_metodo_ricev="1"][nome_valuta] [valore_ultimo_pagamento_p][/c]}
\cell\row\pard \trowd\trql\trleft276\trrh-119\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat3\cellx7792\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat3\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs12\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs12\lang1040\loch\f1\fs12\lang1040 
\cell\pard\plain \intbl\ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\qr\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\cell\row\pard \trowd\trql\trleft276\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat4\cellx7792\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat4\clvertalb\cellx9637
\pard\intbl\pard\plain \intbl\ltrpar\s1\cf0\ql\rtlch\afs24\lang255\ltrch\dbch\langfe255\hich\fs24\lang1040\loch\fs24\lang1040 {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0 Totale Pagamento}
\cell\pard\plain \intbl\ltrpar\s1\cf0\qr\rtlch\afs24\lang255\ab\ltrch\dbch\langfe255\hich\fs24\lang1040\b\loch\fs24\lang1040\b {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b [nome_valuta] [valore_ultimo_pagamento_p]}
\cell\row\pard \pard\plain \ltrpar\s1\cf0\ql\rtlch\afs24\lang255\ltrch\dbch\langfe255\hich\fs24\lang1040\loch\fs24\lang1040 
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\brdrb\brdrs\brdrw20\brdrcf1\brsp20{\*\brdrb\brdlncol1\brdlnin0\brdlnout20\brdlndist0}\brsp20\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\ql\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
\par \pard\plain \ltrpar\s1{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\rtlch\af1\afs24\lang255\ltrch\dbch\af1\langfe255\hich\f1\fs24\lang1040\loch\f1\fs24\lang1040 
[/r]\par }</cmp></riga>
<riga><cmp>12</cmp><cmp>contrrtf</cmp><cmp>{\rtf1\ansi\deff1\adeflang1025[r][r2][null_sa][/r2][r4 array="lista_ospiti_sa"][null_sa][/r4][/r]
{\fonttbl{\f0\froman\fprq2\fcharset0 Times New Roman;}{\f1\froman\fprq2\fcharset0 Times New Roman;}{\f2\fswiss\fprq2\fcharset0 Arial;}{\f3\froman\fprq2\fcharset0 Times New Roman;}{\f4\fswiss\fprq2\fcharset0 Arial;}{\f5\fswiss\fprq2\fcharset0 Albany{\*\falt Arial};}{\f6\froman\fprq2\fcharset0 Thorndale{\*\falt Times New Roman};}{\f7\fswiss\fprq2\fcharset128 Arial;}{\f8\fnil\fprq2\fcharset0 Bitstream Vera Sans;}{\f9\fswiss\fprq2\fcharset0 DejaVu Sans;}{\f10\fswiss\fprq2\fcharset0 Bitstream Vera Sans;}{\f11\fnil\fprq2\fcharset0 HG Mincho Light J{\*\falt msmincho};}}
{\colortbl;\red0\green0\blue0;\red0\green0\blue128;\red128\green128\blue128;}
{\stylesheet{\s1\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\snext1 Normal;}
{\s2\sb240\sa120\keepn\rtlch\af8\afs28\lang255\ltrch\dbch\af8\langfe255\hich\f2\fs28\lang1040\loch\f2\fs28\lang1040\sbasedon1\snext3 Heading;}
{\s3\sa283\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext3 Body Text;}
{\s4\sa283\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon3\snext4 List;}
{\s5\sb120\sa120\rtlch\afs24\lang255\ai\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\i\loch\fs24\lang1040\i\sbasedon1\snext5 caption;}
{\s6\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext6 Index;}
{\s7\sb240\sa120\keepn\rtlch\af4\afs28\lang255\ltrch\dbch\af10\langfe255\hich\f4\fs28\lang1040\loch\f4\fs28\lang1040\sbasedon1\snext3 Heading;}
{\s8\sb120\sa120\rtlch\afs24\lang255\ai\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\i\loch\fs24\lang1040\i\sbasedon1\snext8 caption;}
{\s9\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext9 Index;}
{\s10\sb240\sa120\keepn\rtlch\af4\afs28\lang255\ltrch\dbch\af10\langfe255\hich\f4\fs28\lang1040\loch\f4\fs28\lang1040\sbasedon1\snext3 WW-Heading;}
{\s11\sb120\sa120\rtlch\afs24\lang255\ai\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\i\loch\fs24\lang1040\i\sbasedon1\snext11 WW-caption;}
{\s12\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext12 WW-Index;}
{\s13\sb240\sa120\keepn\rtlch\af4\afs28\lang255\ltrch\dbch\af10\langfe255\hich\f4\fs28\lang1040\loch\f4\fs28\lang1040\sbasedon1\snext3 WW-Heading1;}
{\s14\sb120\sa120\rtlch\afs24\lang255\ai\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\i\loch\fs24\lang1040\i\sbasedon1\snext14 WW-caption1;}
{\s15\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext15 WW-Index1;}
{\s16\sb240\sa120\keepn\rtlch\af4\afs28\lang255\ltrch\dbch\af10\langfe255\hich\f4\fs28\lang1040\loch\f4\fs28\lang1040\sbasedon1\snext3 WW-Heading11;}
{\s17\sb120\sa120\rtlch\afs24\lang255\ai\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\i\loch\fs24\lang1040\i\sbasedon1\snext17 WW-caption11;}
{\s18\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext18 WW-Index11;}
{\s19\sb240\sa120\keepn\rtlch\af4\afs28\lang255\ltrch\dbch\af10\langfe255\hich\f4\fs28\lang1040\loch\f4\fs28\lang1040\sbasedon1\snext3 WW-Heading111;}
{\s20\sb120\sa120\rtlch\afs24\lang255\ai\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\i\loch\fs24\lang1040\i\sbasedon1\snext20 WW-caption111;}
{\s21\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext21 WW-Index111;}
{\s22\sb240\sa120\keepn\rtlch\af4\afs28\lang255\ltrch\dbch\af10\langfe255\hich\f4\fs28\lang1040\loch\f4\fs28\lang1040\sbasedon1\snext3 WW-Heading1111;}
{\s23\sb120\sa120\rtlch\afs24\lang255\ai\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\i\loch\fs24\lang1040\i\sbasedon1\snext23 WW-caption1111;}
{\s24\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext24 WW-Index1111;}
{\s25\sb240\sa120\keepn\rtlch\af4\afs28\lang255\ltrch\dbch\af10\langfe255\hich\f4\fs28\lang1040\loch\f4\fs28\lang1040\sbasedon1\snext3 WW-Heading11111;}
{\s26\sb120\sa120\rtlch\afs24\lang255\ai\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\i\loch\fs24\lang1040\i\sbasedon1\snext26 WW-caption11111;}
{\s27\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext27 WW-Index11111;}
{\s28\sb240\sa120\keepn\rtlch\af4\afs28\lang255\ltrch\dbch\af10\langfe255\hich\f4\fs28\lang1040\loch\f4\fs28\lang1040\sbasedon1\snext3 WW-Heading111111;}
{\s29\sb120\sa120\rtlch\afs24\lang255\ai\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\i\loch\fs24\lang1040\i\sbasedon1\snext29 WW-caption111111;}
{\s30\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext30 WW-Index111111;}
{\s31\sb240\sa120\keepn\rtlch\af4\afs28\lang255\ltrch\dbch\af10\langfe255\hich\f4\fs28\lang1040\loch\f4\fs28\lang1040\sbasedon1\snext3 WW-Heading1111111;}
{\s32\sb120\sa120\rtlch\afs24\lang255\ai\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\i\loch\fs24\lang1040\i\sbasedon1\snext32 WW-caption1111111;}
{\s33\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext33 WW-Index1111111;}
{\s34\sb240\sa120\keepn\rtlch\af4\afs28\lang255\ltrch\dbch\af10\langfe255\hich\f4\fs28\lang1040\loch\f4\fs28\lang1040\sbasedon1\snext3 WW-Heading11111111;}
{\s35\sb120\sa120\rtlch\afs24\lang255\ai\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\i\loch\fs24\lang1040\i\sbasedon1\snext35 WW-caption11111111;}
{\s36\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext36 WW-Index11111111;}
{\s37\sb240\sa120\keepn\rtlch\af4\afs28\lang255\ltrch\dbch\af10\langfe255\hich\f4\fs28\lang1040\loch\f4\fs28\lang1040\sbasedon1\snext3 WW-Heading111111111;}
{\s38\sb120\sa120\rtlch\afs24\lang255\ai\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\i\loch\fs24\lang1040\i\sbasedon1\snext38 WW-caption111111111;}
{\s39\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext39 WW-Index111111111;}
{\s40\sb240\sa120\keepn\rtlch\af4\afs28\lang255\ltrch\dbch\af10\langfe255\hich\f4\fs28\lang1040\loch\f4\fs28\lang1040\sbasedon1\snext3 WW-Heading1111111111;}
{\s41\sb120\sa120\rtlch\afs24\lang255\ai\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\i\loch\fs24\lang1040\i\sbasedon1\snext41 WW-caption1111111111;}
{\s42\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext42 WW-Index1111111111;}
{\s43\sb240\sa120\keepn\rtlch\af4\afs28\lang255\ltrch\dbch\af10\langfe255\hich\f4\fs28\lang1040\loch\f4\fs28\lang1040\sbasedon1\snext3 WW-Heading11111111111;}
{\s44\sb120\sa120\rtlch\afs24\lang255\ai\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\i\loch\fs24\lang1040\i\sbasedon1\snext44 WW-caption11111111111;}
{\s45\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext45 WW-Index11111111111;}
{\s46\sb240\sa120\keepn\rtlch\af4\afs28\lang255\ltrch\dbch\af10\langfe255\hich\f4\fs28\lang1040\loch\f4\fs28\lang1040\sbasedon1\snext3 WW-Heading111111111111;}
{\s47\sb120\sa120\rtlch\afs24\lang255\ai\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\i\loch\fs24\lang1040\i\sbasedon1\snext47 WW-caption111111111111;}
{\s48\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext48 WW-Index111111111111;}
{\s49\sb240\sa283\keepn\rtlch\af5\afs28\lang255\ltrch\dbch\af11\langfe255\hich\f5\fs28\lang1040\loch\f5\fs28\lang1040\sbasedon1\snext3 WW-Heading1111111111111;}
{\s50\sb120\sa120\rtlch\afs24\lang255\ai\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\i\loch\fs24\lang1040\i\sbasedon1\snext50 WW-caption1111111111111;}
{\s51\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext51 WW-Index1111111111111;}
{\s52\sa283\brdrb\brdrdb\brdrw15\brdrcf3\brsp0{\*\brdrb\brdlncol3\brdlnin1\brdlnout1\brdlndist20}\brsp0\rtlch\afs12\lang255\ltrch\dbch\af9\langfe255\hich\fs12\lang1040\loch\fs12\lang1040\sbasedon1\snext3 Horizontal Line;}
{\s53\rtlch\afs24\lang255\ai\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\i\loch\fs24\lang1040\i\sbasedon1\snext53 envelope return;}
{\s54\sa283\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon3\snext54 Table Contents;}
{\s55\tqc\tx4818\tqr\tx9637\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext55 footer;}
{\s56\tqc\tx4818\tqr\tx9637\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext56 header;}
{\s57\sb240\sa283\keepn\rtlch\af6\afs48\lang255\ab\ltrch\dbch\af11\langfe255\hich\f6\fs48\lang1040\b\loch\f6\fs48\lang1040\b\sbasedon49\snext3 heading 1;}
{\s58\sa283\qc\rtlch\afs24\lang255\ab\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\b\loch\fs24\lang1040\b\sbasedon54\snext58 Table Heading;}
{\s59\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext59 WW-Table Contents;}
{\s60\qc\rtlch\afs24\lang255\ab\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\b\loch\fs24\lang1040\b\sbasedon59\snext60 WW-Table Heading;}
{\s61\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext61 WW-Table Contents1;}
{\s62\qc\rtlch\afs24\lang255\ab\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\b\loch\fs24\lang1040\b\sbasedon61\snext62 WW-Table Heading1;}
{\s63\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext63 WW-Table Contents12;}
{\s64\qc\rtlch\afs24\lang255\ab\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\b\loch\fs24\lang1040\b\sbasedon63\snext64 WW-Table Heading12;}
{\s65\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext65 WW-Table Contents123;}
{\s66\qc\rtlch\afs24\lang255\ab\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\b\loch\fs24\lang1040\b\sbasedon65\snext66 WW-Table Heading123;}
{\s67\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext67 WW-Table Contents1234;}
{\s68\qc\rtlch\afs24\lang255\ab\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\b\loch\fs24\lang1040\b\sbasedon67\snext68 WW-Table Heading1234;}
{\s69\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext69 WW-Table Contents12345;}
{\s70\qc\rtlch\afs24\lang255\ab\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\b\loch\fs24\lang1040\b\sbasedon69\snext70 WW-Table Heading12345;}
{\s71\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext71 WW-Table Contents123456;}
{\s72\qc\rtlch\afs24\lang255\ab\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\b\loch\fs24\lang1040\b\sbasedon71\snext72 WW-Table Heading123456;}
{\s73\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext73 WW-Table Contents1234567;}
{\s74\qc\rtlch\afs24\lang255\ab\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\b\loch\fs24\lang1040\b\sbasedon73\snext74 WW-Table Heading1234567;}
{\s75\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext75 WW-Table Contents12345678;}
{\s76\qc\rtlch\afs24\lang255\ab\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\b\loch\fs24\lang1040\b\sbasedon75\snext76 WW-Table Heading12345678;}
{\s77\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext77 WW-Table Contents123456789;}
{\s78\qc\rtlch\afs24\lang255\ab\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\b\loch\fs24\lang1040\b\sbasedon77\snext78 WW-Table Heading123456789;}
{\s79\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext79 WW-Table Contents12345678910;}
{\s80\qc\rtlch\afs24\lang255\ab\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\b\loch\fs24\lang1040\b\sbasedon79\snext80 WW-Table Heading12345678910;}
{\s81\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext81 WW-Table Contents1234567891011;}
{\s82\qc\rtlch\afs24\lang255\ab\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\b\loch\fs24\lang1040\b\sbasedon81\snext82 WW-Table Heading1234567891011;}
{\s83\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext83 WW-Table Contents123456789101112;}
{\s84\qc\rtlch\afs24\lang255\ab\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\b\loch\fs24\lang1040\b\sbasedon83\snext84 WW-Table Heading123456789101112;}
{\s85\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext85 WW-Table Contents12345678910111213;}
{\s86\qc\rtlch\afs24\lang255\ab\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\b\loch\fs24\lang1040\b\sbasedon85\snext86 WW-Table Heading12345678910111213;}
{\s87\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040\sbasedon1\snext87 Table Contents;}
{\s88\qc\rtlch\afs24\lang255\ab\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\b\loch\fs24\lang1040\b\sbasedon87\snext88 Table Heading;}
{\*\cs90\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040 Endnote Symbol;}
{\*\cs91\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040 Footnote Symbol;}
{\*\cs92\cf2\ul\ulc0\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040 Internet link;}
{\*\cs93\rtlch\afs24\lang255\ai\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\i\loch\fs24\lang1040\i Emphasis;}
}
{\info{\title Scheda Notifica Pubblica Sicurezza}{\creatim\yr0\mo0\dy0\hr0\min0}{\revtim\yr0\mo0\dy0\hr0\min0}{\printim\yr0\mo0\dy0\hr0\min0}{\comment StarWriter}{\vern3000}}\deftab709
{\*\pgdsctbl
{\pgdsc0\pgdscuse195\pgwsxn11905\pghsxn16837\marglsxn636\margrsxn567\margtsxn567\margbsxn567\pgdscnxt0 Standard;}
{\pgdsc1\pgdscuse195\pgwsxn11905\pghsxn16837\marglsxn1134\margrsxn1134\margtsxn1134\margbsxn1134\pgdscnxt1 Endnote;}
{\pgdsc2\pgdscuse195\pgwsxn11905\pghsxn16837\marglsxn636\margrsxn567\margtsxn567\margbsxn567\pgdscnxt2 HTML;}}
{\*\pgdscno0}\paperh16837\paperw11905\margl636\margr567\margt567\margb567\sectd\sbknone\pgwsxn11905\pghsxn16837\marglsxn636\margrsxn567\margtsxn567\margbsxn567\ftnbj\ftnstart1\ftnrstcont\ftnnar\aenddoc\aftnrstcont\aftnstart1\aftnnrlc
[r][r2][null_sa][/r2][nuova_pag_sa]\trowd\trql\trleft0\trrh1436\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\cellx3699\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10702
\pard\intbl\pard\plain \intbl\ltrpar\s1\ql\rtlch\afs24\lang255\ab\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\b\loch\fs24\lang1040\b {\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b [tipo_struttura] [nome_struttura]}
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\afs20\lang255\ltrch\dbch\af9\langfe255\hich\fs20\lang1040\loch\fs20\lang1040 {\rtlch \ltrch\loch\f1\fs20\lang1040\i0\b0 [indirizzo_struttura]}
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs20\lang1040\loch\fs20\lang1040 {\rtlch \ltrch\loch\f1\fs20\lang1040\i0\b0 [comune_struttura]}
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\afs20\lang255\ltrch\dbch\af9\langfe255\hich\fs20\lang1040\loch\fs20\lang1040 {\rtlch \ltrch\loch\f1\fs20\lang1040\i0\b0 [c telefono_struttura!=""]Tel. [telefono_struttura][/c]}
\cell\pard\plain \intbl\ltrpar\s54\sl238\slmult0\ql\rtlch\af7\afs24\lang255\ltrch\dbch\af9\langfe255\hich\f7\fs24\lang1040\loch\f7\fs24\lang1040{\rtlch \ltrch\loch\f7\fs24\lang1040\i0\b0{\cf1\rtlch\ltrch\hich\fs16\b\loch\fs16\b Altri Componenti del [nucleo_familiare] :\line [linee_altri_ospiti_sa(numero_sa)] (Cognome, Nome, Luogo e data di nascita)\line }}{\rtlch \ltrch\loch\f7\fs24\lang1040\i0\b0{\cf1\rtlch\ltrch\hich\fs16\lang2057\loch\fs16\lang2057 Other family members (Surname, First Name, place 
and date of birth)\line }{\cf1\rtlch\ltrch\hich\fs16\lang1036\loch\fs16\lang1036 Autres membres de la famille (Nom, Pr\u233\'3fnom, lieu et date de naissance)\line Otros componentes de la familia (Apellidos, Nombre, Lugar y fecha de nacimiento)\line }{\cf1\rtlch\ltrch\hich\fs16\lang1031\loch\fs16\lang1031 Andere Familien mit glieder (Vorname, Name, ort und datum der Geburt)}}
\cell\row\pard \trowd\trql\trleft0\trrh3296\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx5712\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\cellx10702
\pard\intbl\pard\plain \intbl\ltrpar\s1\ql\rtlch\af7\afs24\lang255\ab\ltrch\dbch\af9\langfe255\hich\f7\fs24\lang1040\b\loch\f7\fs24\lang1040\b {\rtlch \ltrch\loch\f7\fs24\lang1040\i0\b Scheda di notificazione n\'81\'8b [numero_sa] del [oggi]}
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\af7\afs16\lang255\ltrch\dbch\af9\langfe255\hich\f7\fs16\lang1040\loch\f7\fs16\lang1040 
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\af7\afs16\lang255\ab\ltrch\dbch\af9\langfe255\hich\f7\fs16\lang1040\b\loch\f7\fs16\lang1040\b {\rtlch \ltrch\loch\f7\fs16\lang1040\i0\b Da Compilare da parte del [capofamiglia_sa] }
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\af7\afs16\lang255\ltrch\dbch\af9\langfe255\hich\f7\fs16\lang1040\loch\f7\fs16\lang1040 {\rtlch \ltrch\loch\f7\fs16\lang1040\i0\b0 To be completed by the guest - La Section ci-dessous doit \u234\'3ftre remplie par l'h\u244\'3fte - Parte que tiene ser rellenada por el huesped - Gef\u252\'3fllte von gast}
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\afs16\lang255\ltrch\dbch\af9\langfe255\hich\fs16\lang1040\loch\fs16\lang1040 
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\af7\afs16\lang255\ab\ltrch\dbch\af9\langfe255\hich\f7\fs16\lang1040\b\loch\f7\fs16\lang1040\b {\rtlch \ltrch\loch\f7\fs16\lang1040\i0\b Cognome : [cognome_sa]}
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\f7\fs16\lang1040\b\loch\f7\fs16\lang1040\b {\rtlch \ltrch\loch\f7\fs16\lang1040\i0\b Nome : [nome_sa]}
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\af7\afs16\lang255\ltrch\dbch\af9\langfe255\hich\f7\fs16\lang1040\loch\f7\fs16\lang1040 {\rtlch \ltrch\loch\f7\fs16\lang1040\i0\b0 Surname and first name - Nom et prenome - Apellidos y nombre - Vorname und name }
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\afs16\lang255\ltrch\dbch\af9\langfe255\hich\fs16\lang1040\loch\fs16\lang1040 
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\af7\afs16\lang255\ab\ltrch\dbch\af9\langfe255\hich\f7\fs16\lang1040\b\loch\f7\fs16\lang1040\b {\rtlch \ltrch\loch\f7\fs16\lang1040\i0\b Nato a : [linea_nato_sa]}
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\f7\fs16\lang1040\b\loch\f7\fs16\lang1040\b {\rtlch \ltrch\loch\f7\fs16\lang1040\i0\b (Citt\u224\'3f, Provincia o Stato) }
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\af7\afs16\lang255\ltrch\dbch\af9\langfe255\hich\f7\fs16\lang1040\loch\f7\fs16\lang1040 {\rtlch \ltrch\loch\f7\fs16\lang1040\i0\b0 Place of birth (City, State) - Lieu de naissance (Ville, Etat) - Lugar de nacimiento (Ciudad, Estado) - Geburstort (Stadt, Staat)}
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\afs16\lang255\ltrch\dbch\af9\langfe255\hich\fs16\lang1040\loch\fs16\lang1040 
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\af7\afs16\lang255\ab\ltrch\dbch\af9\langfe255\hich\f7\fs16\lang1040\b\loch\f7\fs16\lang1040\b {\rtlch \ltrch\loch\f7\fs16\lang1040\i0\b Data di nascita : [data_nascita_sa]}
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\af7\afs16\lang255\ltrch\dbch\af9\langfe255\hich\f7\fs16\lang1040\loch\f7\fs16\lang1040 {\rtlch \ltrch\loch\f7\fs16\lang1040\i0\b0 Birthdate - Date{\cf1\ltrch\hich\lang1036\loch\lang1036  de naissance} \u8211\'3f Fecha de nacimiento \u8211\'3f Datum  {\cf1\ltrch\hich\lang1031\loch\lang1031 der Geburt}}
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\afs16\lang255\ltrch\dbch\af9\langfe255\hich\fs16\lang1040\loch\fs16\lang1040 
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\af7\afs16\lang255\ab\ltrch\dbch\af9\langfe255\hich\f7\fs16\lang1040\b\loch\f7\fs16\lang1040\b {\rtlch \ltrch\loch\f7\fs16\lang1040\i0\b Cittadinanza : [cittadinanza_sa]}
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\af7\afs16\lang255\ltrch\dbch\af9\langfe255\hich\f7\fs16\lang1040\loch\f7\fs16\lang1040 {\rtlch \ltrch\loch\f7\fs16\lang1040\i0\b0 Nationality - Nationalit\u233\'3f - Nacionalidad - Staatsangehoerigkeit }
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\afs16\lang255\ltrch\dbch\af9\langfe255\hich\fs16\lang1040\loch\fs16\lang1040 
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\af7\afs16\lang255\ab\ltrch\dbch\af9\langfe255\hich\f7\fs16\lang1040\b\loch\f7\fs16\lang1040\b {\rtlch \ltrch\loch\f7\fs16\lang1040\i0\b Residente in : [linea_residenza_sa]}
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\f7\fs16\lang1040\b\loch\f7\fs16\lang1040\b {\rtlch \ltrch\loch\f7\fs16\lang1040\i0\b (Via, Citta, Provincia o Stato)}
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\af7\afs16\lang255\ltrch\dbch\af9\langfe255\hich\f7\fs16\lang1040\loch\f7\fs16\lang1040 {\rtlch \ltrch\loch\f7\fs16\lang1040\i0\b0 Address (Street, City, State) - Lieu de Recidence (addresse, ville, Etat) - Lugar de residencia (Calle, Ciudad, Estado) - Wohnsitz (Strasse, Stadt, Staat) }
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\afs16\lang255\ltrch\dbch\af9\langfe255\hich\fs16\lang1040\loch\fs16\lang1040 
\cell\pard\plain \intbl\ltrpar\s1\ql\rtlch\af7\afs16\lang255\ab\ltrch\dbch\af9\langfe255\hich\f7\fs16\lang1040\b\loch\f7\fs16\lang1040\b 
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040 
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\af7\afs16\lang255\ab\ltrch\dbch\af9\langfe255\hich\f7\fs16\lang1040\b\loch\f7\fs16\lang1040\b 
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\f7\fs16\lang1040\b\loch\f7\fs16\lang1040\b {\rtlch \ltrch\loch\f7\fs16\lang1040\i0\b Da compilare da parte del gestore}
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\afs16\lang255\ltrch\dbch\af9\langfe255\hich\fs16\lang1040\loch\fs16\lang1040 
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040 
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\af7\afs16\lang255\ab\ltrch\dbch\af9\langfe255\hich\f7\fs16\lang1040\b\loch\f7\fs16\lang1040\b {\rtlch \ltrch\loch\f7\fs16\lang1040\i0\b Data di arrivo : [data_inizio]}
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\afs16\lang255\ltrch\dbch\af9\langfe255\hich\fs16\lang1040\loch\fs16\lang1040 
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\afs16\lang255\ltrch\dbch\af9\langfe255\hich\fs16\lang1040\loch\fs16\lang1040 
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\af7\afs16\lang255\ab\ltrch\dbch\af9\langfe255\hich\f7\fs16\lang1040\b\loch\f7\fs16\lang1040\b {\rtlch \ltrch\loch\f7\fs16\lang1040\i0\b Documento tipo : [tipo_documento_sa]\line }
\par \pard\plain \intbl\ltrpar\s1\cf1\ql\rtlch\af7\afs16\lang255\ab\ltrch\dbch\af9\langfe255\hich\f7\fs16\lang1040\b\loch\f7\fs16\lang1040\b {\rtlch \ltrch\loch\f7\fs16\lang1040\i0\b Numero : [numero_documento_sa]\line }
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\af7\afs16\lang255\ab\ltrch\dbch\af9\langfe255\hich\f7\fs16\lang1040\b\loch\f7\fs16\lang1040\b {\rtlch \ltrch\loch\f7\fs16\lang1040\i0\b Scadenza il : [scadenza_documento_sa]\line }
\par \pard\plain \intbl\ltrpar\s1\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040 {\rtlch \ltrch\loch\f7\fs16\lang1040\i0\b Luogo di rilasciato: [rilascio_documento_sa]}
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\afs16\lang255\ltrch\dbch\af9\langfe255\hich\fs16\lang1040\loch\fs16\lang1040 
\par \pard\plain \intbl\ltrpar\s1\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040 
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\af7\afs16\lang255\ab\ltrch\dbch\af9\langfe255\hich\f7\fs16\lang1040\b\loch\f7\fs16\lang1040\b {\rtlch \ltrch\loch\f7\fs16\lang1040\i0\b FIRMA DEL DICHIARANTE_____________________________}
\par \pard\plain \intbl\ltrpar\s1\ql\rtlch\af7\afs16\lang255\ltrch\dbch\af9\langfe255\hich\f7\fs16\lang1040\loch\f7\fs16\lang1040 {\rtlch \ltrch\loch\f7\fs16\lang1040\i0\b0 Signature of person making declaration - Signature de l'int\u233\'3fress\u233\'3f - Firma del declarante - Unterschrift des erklaerers }
\cell\row\pard \pard\plain \ltrpar\s1\ql\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040 
\par \pard\plain \ltrpar\s1\ql\rtlch\af7\afs16\lang255\ab\ltrch\dbch\af9\langfe255\hich\f7\fs16\lang1040\b\loch\f7\fs16\lang1040\b {\rtlch \ltrch\loch\f7\fs16\lang1040\i0\b Ai sensi dell'art. 13 D.Lgs. 196/2003 (informativa sul trattamento dei  dati personali) autorizzo [c ragione_sociale_struttura=""]questa struttura[/c][ragione_sociale_struttura] al trattamento dei miei dati personali ai fini dell'espletamento del servizio. }
\par \pard\plain \ltrpar\s1\ql\rtlch\af7\afs16\lang255\ltrch\dbch\af9\langfe255\hich\f7\fs16\lang1040\loch\f7\fs16\lang1040 {\rtlch \ltrch\loch\f7\fs16\lang1040\i0\b0 I Authorize the treatment of my personal data according to the Italian Law  D.lgs. 196/2003 art. 13 - J'autorise le traitement de mes donn\u233\'3fes personnelles aux termes de la loi italienne D.lgs. 196/2003 art. 13 - Autorizo el tratamiento de mis datos persona
les conforme lo establecido por la ley italiana D.lgs. 196/2003 art. 13 - Ich autorisiere die Verarbeitung meiner pers\u246\'3fnlichen Daten gem\u228\'3f\u223\'3f des ital.Gesetzes D.lgs. 196/2003 art. 13}
\par \pard\plain \ltrpar\s1\ql\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040 {\rtlch \ltrch\loch  }
\par \pard\plain \ltrpar\s1\ql {\rtlch \ltrch\loch  }{\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0\rtlch\ltrch\hich\f7\fs16\b\loch\f7\fs16\b FIRMA _______________________________________________________}
\par \pard\plain \ltrpar\s1\ql\rtlch\afs24\lang255\ltrch\dbch\af9\langfe255\hich\fs24\lang1040\loch\fs24\lang1040 {\rtlch \ltrch\loch  }{\rtlch \ltrch\loch\f1\fs24\lang1040\i0\b0\rtlch\ltrch\hich\f7\fs16\loch\f7\fs16 (Signature - Signature - Firma - Unterschrift )}
[/r]\par }</cmp></riga>
<riga><cmp>14</cmp><cmp>contrrtf</cmp><cmp>{\rtf1\ansi\deff0\adeflang1025
{\fonttbl{\f0\froman\fprq2\fcharset0 Times New Roman;}{\f1\froman\fprq2\fcharset2 Symbol;}{\f2\fswiss\fprq2\fcharset0 Arial;}{\f3\fswiss\fprq2\fcharset0 Calibri;}{\f4\fnil\fprq2\fcharset0 Mangal;}{\f5\fnil\fprq0\fcharset128 Mangal;}{\f6\fswiss\fprq2\fcharset128 Arial Unicode MS;}{\f7\fswiss\fprq2\fcharset0 Arial Unicode MS;}}
{\colortbl;\red0\green0\blue0;\red204\green204\blue204;\red128\green128\blue128;}
{\stylesheet{\s0\snext0\sl276\slmult1\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\aspalpha\faauto\li0\ri0\lin0\rin0\fi0\sb0\sa200\nowidctlpar\cf0\kerning1\hich\af3\langfe1040\dbch\af0\afs24\lang1081\loch\f3\fs22\lang1040 Predefinito;}
{\*\cs15\snext15 Default Paragraph Font;}
{\*\cs16\sbasedon15\snext16\hich\af0\langfe255\dbch\af0\lang0 Corpo del testo Carattere;}
{\*\cs17\sbasedon15\snext17\hich\af0\langfe255\dbch\af0\lang0 Body Text Char;}
{\*\cs18\sbasedon15\snext18\hich\af0\dbch\af0 Intestazione Carattere;}
{\*\cs19\sbasedon15\snext19\hich\af0\dbch\af0 Intestazione Carattere1;}
{\*\cs20\sbasedon15\snext20\hich\af0 Intestazione Carattere2;}
{\s21\sbasedon0\snext22\sl276\slmult1\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\aspalpha\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af4\langfe1040\dbch\af7\loch\f2\fs28\lang1040 Intestazione;}
{\s22\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb0\sa120\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Corpo testo;}
{\s23\sbasedon22\snext23\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb0\sa120\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Elenco;}
{\s24\sbasedon0\snext24\sl276\slmult1\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\aspalpha\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af5\langfe1040\dbch\af0\ai\loch\f3\fs24\lang1040 Didascalia;}
{\s25\sbasedon26\snext25\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Indice;}
{\s26\snext26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040 WW-Predefinito1;}
{\s27\snext27\sl276\slmult1\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\aspalpha\faauto\li0\ri0\lin0\rin0\fi0\sb0\sa200\nowidctlpar\cf0\kerning1\hich\af0\langfe1040\dbch\af0\afs24\lang1081\loch\f3\fs22\lang1040 WW-Predefinito;}
{\s28\sbasedon27\snext22\sl200\slmult0\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af6\langfe255\dbch\af0\loch\f2\fs28\lang1040 header;}
{\s29\sbasedon26\snext29\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 caption;}
{\s30\snext30\sl276\slmult1\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\aspalpha\faauto\li0\ri0\lin0\rin0\fi0\sb0\sa200\nowidctlpar\cf0\kerning1\hich\af0\langfe1040\dbch\af0\afs24\lang1081\loch\f3\fs22\lang1040 WW-Predefinito12;}
{\s31\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f2\fs28\lang1040 Heading;}
{\s32\sbasedon26\snext32\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Index;}
{\s33\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f2\fs28\lang1040 Heading5;}
{\s34\sbasedon26\snext34\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Index5;}
{\s35\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f2\fs28\lang1040 WW-Heading;}
{\s36\sbasedon26\snext36\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption;}
{\s37\sbasedon26\snext37\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index;}
{\s38\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f2\fs28\lang1040 WW-Heading1;}
{\s39\sbasedon26\snext39\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption1;}
{\s40\sbasedon26\snext40\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index1;}
{\s41\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading11;}
{\s42\sbasedon26\snext42\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption11;}
{\s43\sbasedon26\snext43\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index11;}
{\s44\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Heading4;}
{\s45\sbasedon26\snext45\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Index4;}
{\s46\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading111;}
{\s47\sbasedon26\snext47\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption111;}
{\s48\sbasedon26\snext48\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index111;}
{\s49\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading1111;}
{\s50\sbasedon26\snext50\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption1111;}
{\s51\sbasedon26\snext51\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index1111;}
{\s52\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading11111;}
{\s53\sbasedon26\snext53\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption11111;}
{\s54\sbasedon26\snext54\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index11111;}
{\s55\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading111111;}
{\s56\sbasedon26\snext56\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption111111;}
{\s57\sbasedon26\snext57\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index111111;}
{\s58\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading1111111;}
{\s59\sbasedon26\snext59\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption1111111;}
{\s60\sbasedon26\snext60\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index1111111;}
{\s61\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading11111111;}
{\s62\sbasedon26\snext62\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption11111111;}
{\s63\sbasedon26\snext63\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index11111111;}
{\s64\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading111111111;}
{\s65\sbasedon26\snext65\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption111111111;}
{\s66\sbasedon26\snext66\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index111111111;}
{\s67\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading1111111111;}
{\s68\sbasedon26\snext68\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption1111111111;}
{\s69\sbasedon26\snext69\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index1111111111;}
{\s70\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading11111111111;}
{\s71\sbasedon26\snext71\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption11111111111;}
{\s72\sbasedon26\snext72\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index11111111111;}
{\s73\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading111111111111;}
{\s74\sbasedon26\snext74\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption111111111111;}
{\s75\sbasedon26\snext75\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index111111111111;}
{\s76\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading1111111111111;}
{\s77\sbasedon26\snext77\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption1111111111111;}
{\s78\sbasedon26\snext78\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index1111111111111;}
{\s79\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Heading3;}
{\s80\sbasedon26\snext80\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Index3;}
{\s81\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Heading2;}
{\s82\sbasedon26\snext82\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Index2;}
{\s83\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Heading1;}
{\s84\sbasedon26\snext84\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Index1;}
{\s85\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading11111111111111;}
{\s86\sbasedon26\snext86\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption11111111111111;}
{\s87\sbasedon26\snext87\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index11111111111111;}
{\s88\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading111111111111111;}
{\s89\sbasedon26\snext89\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption111111111111111;}
{\s90\sbasedon26\snext90\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index111111111111111;}
{\s91\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading1111111111111111;}
{\s92\sbasedon26\snext92\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption1111111111111111;}
{\s93\sbasedon26\snext93\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index1111111111111111;}
{\s94\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading11111111111111111;}
{\s95\sbasedon26\snext95\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption11111111111111111;}
{\s96\sbasedon26\snext96\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index11111111111111111;}
{\s97\sbasedon26\snext97\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Table Contents;}
{\s98\sbasedon97\snext98\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 Table Heading;}
{\s99\sbasedon26\snext99\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents;}
{\s100\sbasedon99\snext100\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading;}
{\s101\sbasedon26\snext101\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents1;}
{\s102\sbasedon101\snext102\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading1;}
{\s103\sbasedon26\snext103\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents12;}
{\s104\sbasedon103\snext104\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading12;}
{\s105\sbasedon26\snext105\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents123;}
{\s106\sbasedon105\snext106\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading123;}
{\s107\sbasedon26\snext107\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Table Contents1;}
{\s108\sbasedon107\snext108\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 Table Heading1;}
{\s109\sbasedon26\snext109\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Table Contents2;}
{\s110\sbasedon109\snext110\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 Table Heading2;}
{\s111\sbasedon26\snext111\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Table Contents3;}
{\s112\sbasedon111\snext112\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 Table Heading3;}
{\s113\sbasedon26\snext113\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents1234;}
{\s114\sbasedon113\snext114\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading1234;}
{\s115\sbasedon26\snext115\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents12345;}
{\s116\sbasedon115\snext116\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading12345;}
{\s117\sbasedon26\snext117\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents123456;}
{\s118\sbasedon117\snext118\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading123456;}
{\s119\sbasedon26\snext119\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents1234567;}
{\s120\sbasedon119\snext120\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading1234567;}
{\s121\sbasedon26\snext121\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents12345678;}
{\s122\sbasedon121\snext122\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading12345678;}
{\s123\sbasedon26\snext123\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents123456789;}
{\s124\sbasedon123\snext124\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading123456789;}
{\s125\sbasedon26\snext125\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents12345678910;}
{\s126\sbasedon125\snext126\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading12345678910;}
{\s127\sbasedon26\snext127\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents1234567891011;}
{\s128\sbasedon127\snext128\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading1234567891011;}
{\s129\sbasedon26\snext129\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents123456789101112;}
{\s130\sbasedon129\snext130\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading123456789101112;}
{\s131\sbasedon26\snext131\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents12345678910111213;}
{\s132\sbasedon131\snext132\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading12345678910111213;}
{\s133\sbasedon26\snext133\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents1234567891011121314;}
{\s134\sbasedon133\snext134\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading1234567891011121314;}
{\s135\sbasedon26\snext135\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Table Contents4;}
{\s136\sbasedon135\snext136\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 Table Heading4;}
{\s137\sbasedon26\snext137\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents123456789101112131415;}
{\s138\sbasedon137\snext138\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading123456789101112131415;}
{\s139\sbasedon26\snext139\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents12345678910111213141516;}
{\s140\sbasedon139\snext140\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading12345678910111213141516;}
{\s141\sbasedon26\snext141\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents1234567891011121314151617;}
{\s142\sbasedon141\snext142\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading1234567891011121314151617;}
{\s143\sbasedon26\snext143\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Table Contents5;}
{\s144\sbasedon143\snext144\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 Table Heading5;}
{\s145\sbasedon26\snext145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Contenuto tabella;}
{\s146\sbasedon145\snext146\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 Intestazione tabella;}
}{\info{\author Marco}{\creatim\yr2012\mo11\dy27\hr19\min32}{\revtim\yr2012\mo11\dy28\hr16\min31}{\printim\yr0\mo0\dy0\hr0\min0}{\comment OpenOffice.org}{\vern3410}}\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709
[r4 array="date_istat"][r][r2][null_istat][/r2][/r][c mostra_pag_istat!="0"][nuova_pag_istat]
{\*\pgdsctbl
{\pgdsc0\pgdscuse195\pgwsxn11905\pghsxn16837\marglsxn705\margrsxn700\margtsxn405\margbsxn382\pgdscnxt0 Predefinito;}}
\formshade{\*\pgdscno0}\paperh16837\paperw11905\margl705\margr700\margt405\margb382\sectd\sbknone\sectunlocked1\pgndec\pgwsxn11905\pghsxn16837\marglsxn705\margrsxn700\margtsxn405\margbsxn382\ftnbj\ftnstart1\ftnrstcont\ftnnar\aenddoc\aftnrstcont\aftnstart1\aftnnrlc
\trowd\trql\trleft0\ltrrow\trrh-420\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx1740\clpadfl3\clpadl6\clpadft3\clpadt6\clpadfb3\clpadb6\clpadfr3\clpadr6\clvertalc\cellx3500\clpadfl3\clpadl6\clpadft3\clpadt6\clpadfb3\clpadb6\clpadfr3\clpadr6\clvertalc\cellx7000\clpadfl3\clpadl6\clpadft3\clpadt6\clpadfb3\clpadb6\clpadfr3\clpadr6\clvertalc\cellx8750\clbrdrt\brdrs\brdrw1\brdrcf1\clpadfl3\clpadl6\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt6\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb6\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr6\clvertalc\cellx10500\pgndec\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs18\ab\rtlch \ltrch\loch\fs18
Mod. ISTAT C/59_G}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs32\ab\rtlch \ltrch\loch\fs32
ISTAT}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs18\ab\rtlch \ltrch\loch\fs18
Num. Progr.}\cell\row\trowd\trql\trleft0\ltrrow\trrh-204\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clvertalc\cellx1740\clvertalc\cellx3500\clvertalc\cellx5250\clvertalc\cellx7000\clvertalc\cellx8750\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10500\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs14\ab\rtlch \ltrch\loch\fs14
[num_prog_istat]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-261\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clvertalc\cellx10500\pard\plain \s27\sl276\slmult1\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\aspalpha\faauto\li0\ri0\lin0\rin0\fi0\sb0\sa200\nowidctlpar\cf0\kerning1\hich\af0\langfe1040\dbch\af0\afs24\lang1081\loch\f3\fs22\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\sb0\sa200\ltrpar{\b\ab\rtlch \ltrch\loch\fs24\loch\f0
RILEVAZIONE DEL MOVIMENTO DEI CLIENTI NEGLI ESERCIZI RICETTIVI}\cell\row\trowd\trql\trleft0\ltrrow\trrh-221\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clvertalc\cellx1740\clvertalc\cellx8750\clvertalc\cellx10500\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs20\ab\rtlch \ltrch\loch\fs20
SEZIONE GIORNALIERA}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\row\trowd\trql\trleft0\ltrrow\trrh-306\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clvertalc\cellx1740\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3500\clvertalc\cellx5250\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx7000\clvertalc\cellx8750\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx10500\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs22\ab\rtlch \ltrch\loch\fs22
Anno}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs22\rtlch \ltrch\loch\fs22
[anno_istat]}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs22\ab\rtlch \ltrch\loch\fs22
Mese}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs22\rtlch \ltrch\loch\fs22
[mese_istat]}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs22\ab\rtlch \ltrch\loch\fs22
Giorno}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs22\rtlch \ltrch\loch\fs22
[giorno_istat]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-57\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clvertalc\cellx1740\clvertalc\cellx3500\clvertalc\cellx5250\clvertalc\cellx7000\clvertalc\cellx8750\clvertalc\cellx10500\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\row\trowd\trql\trleft0\ltrrow\trrh-306\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clvertalc\cellx1740\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx5250\clvertalc\cellx7000\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx10500\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs22\ab\rtlch \ltrch\loch\fs22
Comune}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs22\rtlch \ltrch\loch\fs22
[comune_struttura]}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs22\ab\rtlch \ltrch\loch\fs22
Denominazione}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs22\rtlch \ltrch\loch\fs22
[nome_struttura]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-57\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clvertalc\cellx1740\clvertalc\cellx3500\clvertalc\cellx5250\clvertalc\cellx7000\clvertalc\cellx8750\clvertalc\cellx10500\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\row\trowd\trql\trleft0\ltrrow\trrh-272\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clvertalc\cellx1740\clvertalc\cellx7000\clbrdrt\brdrs\brdrw1\brdrcf1\clpadfl3\clpadl55\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt55\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb55\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr55\clvertalc\cellx8750\clvertalc\cellx10500\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qr\ltrpar{\b\afs18\ab\rtlch \ltrch\loch\fs18
N. di camere }{\b\afs16\ab\rtlch \ltrch\loch\fs16
(unit\'e0 abitative)}{\b\afs18\ab\rtlch \ltrch\loch\fs18
 occupate    }\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[camere_occupate_istat]}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\row\trowd\trql\trleft0\ltrrow\trrh-79\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clvertalc\cellx1740\clvertalc\cellx7000\clvertalc\cellx8750\clvertalc\cellx10500\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qr\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\row\trowd\trql\trleft0\ltrrow\trrh-227\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clvertalc\cellx1570\clvertalc\cellx2477\clvertalc\cellx3384\clvertalc\cellx4291\clvertalc\cellx5198\clvertalc\cellx5328\clvertalc\cellx6893\clvertalc\cellx7800\clvertalc\cellx8707\clvertalc\cellx9614\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\i\afs14\ai\rtlch \ltrch\loch\fs14
colonna A}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\i\afs14\ai\rtlch \ltrch\loch\fs14
colonna B}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\i\afs14\ai\rtlch \ltrch\loch\fs14
colonna C}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\i\afs14\ai\rtlch \ltrch\loch\fs14
colonna D}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\i\afs14\ai\rtlch \ltrch\loch\fs14
colonna A}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\i\afs14\ai\rtlch \ltrch\loch\fs14
colonna B}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\i\afs14\ai\rtlch \ltrch\loch\fs14
colonna C}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\i\afs14\ai\rtlch \ltrch\loch\fs14
colonna D}\cell\row\trowd\trql\trleft0\ltrrow\trrh-998\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx5198\clvertalc\cellx5328\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs20\rtlch \ltrch\loch\fs20
PAESE }{\b\afs20\ab\rtlch \ltrch\loch\fs20
ESTERO}{\afs20\rtlch \ltrch\loch\fs20
 DI RESIDENZA}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs14\rtlch \ltrch\loch\fs14
PRESENTI LA NOTTE PRECEDENTE (colonna D del giorno precedente)}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
ARRIVATI}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
PARTITI}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{{\*\bkmkstart __DdeLink__5_1545293638}\afs18\rtlch \ltrch\loch\fs18
PRESENTI }{{\*\bkmkend __DdeLink__5_1545293638}\afs16\rtlch \ltrch\loch\fs16
(col. A + col.B \'96 col.C)}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs20\rtlch \ltrch\loch\fs20
PAESE }{\b\afs20\ab\rtlch \ltrch\loch\fs20
ESTERO}{\afs20\rtlch \ltrch\loch\fs20
 DI RESIDENZA}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs14\rtlch \ltrch\loch\fs14
PRESENTI LA NOTTE PRECEDENTE (colonna D del giorno precedente)}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
ARRIVATI}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
PARTITI}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{{\*\bkmkstart __DdeLink__20_1545293638}\afs18\rtlch \ltrch\loch\fs18
PRESENTI}{{\*\bkmkend __DdeLink__20_1545293638}\afs18\rtlch \ltrch\loch\fs18
 }{\afs16\rtlch \ltrch\loch\fs16
(col. A + col.B \'96 col.C)}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs20\ab\rtlch \ltrch\loch\fs20
Unione Europea (27)}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs20\ab\rtlch \ltrch\loch\fs20
Asia}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Austria}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('AT')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('AT')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('AT')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('AT')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Cina}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('CN')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('CN')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('CN')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('CN')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Belgio}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('BE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('BE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('BE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('BE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Corea del Sud}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('KR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('KR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('KR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('KR')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Bulgaria}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('BG')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('BG')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('BG')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('BG')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Giappone}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('JP')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('JP')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('JP')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('JP')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Cipro}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('CY')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('CY')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('CY')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('CY')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
India}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('IN')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('IN')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('IN')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('IN')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Danimarca}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('DK')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('DK')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('DK')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('DK')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Israele}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('IL')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('IL')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('IL')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('IL')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Estonia}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('EE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('EE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('EE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('EE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs14\rtlch \ltrch\loch\fs14
Altri paesi Asia Occident.}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('750')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('750')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('750')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('750')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Finlandia}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('FI')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('FI')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('FI')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('FI')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Altri paesi}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('760')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('760')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('760')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('760')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Francia}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('FR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('FR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('FR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('FR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs18\ab\rtlch \ltrch\loch\fs18
Africa}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Germania}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('DE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('DE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('DE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('DE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Sud Africa}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('ZA')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('ZA')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('ZA')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('ZA')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Grecia}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('GR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('GR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('GR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('GR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Egitto}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('EG')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('EG')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('EG')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('EG')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Irlanda}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('IE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('IE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('IE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('IE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs14\rtlch \ltrch\loch\fs14
Altri paesi Africa Mediter.}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('230')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('230')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('230')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('230')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Lettonia}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('LV')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('LV')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('LV')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('LV')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Altri paesi}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('300')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('300')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('300')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('300')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Lituania}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('LT')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('LT')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('LT')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('LT')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs18\ab\rtlch \ltrch\loch\fs18
Oceania}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Lussemburgo}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('LU')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('LU')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('LU')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('LU')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Australia}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('AU')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('AU')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('AU')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('AU')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Malta}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('MT')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('MT')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('MT')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('MT')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Nuova Zelanda}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('NZ')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('NZ')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('NZ')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('NZ')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Paesi Bassi}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('NL')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('NL')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('NL')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('NL')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs16\rtlch \ltrch\loch\fs16
Altri paesi o territori}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('810')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('810')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('810')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('810')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clpadfl3\clpadl55\clpadft3\clpadt55\clpadfb3\clpadb55\clpadfr3\clpadr55\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Polonia}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('PL')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('PL')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('PL')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('PL')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrt\brdrs\brdrw1\brdrcf1\clpadfl3\clpadl55\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt55\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb55\clpadfr3\clpadr55\clvertalc\cellx6893\clbrdrt\brdrs\brdrw1\brdrcf1\clpadfl3\clpadl55\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt55\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb55\clpadfr3\clpadr55\clcbpat2\clvertalc\cellx7800\clbrdrt\brdrs\brdrw1\brdrcf1\clpadfl3\clpadl55\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt55\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb55\clpadfr3\clpadr55\clvertalc\cellx8707\clbrdrt\brdrs\brdrw1\brdrcf1\clpadfl3\clpadl55\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt55\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb55\clpadfr3\clpadr55\clvertalc\cellx9614\clbrdrt\brdrs\brdrw1\brdrcf1\clpadfl3\clpadl55\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt55\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb55\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr55\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Portogallo}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('PT')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('PT')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('PT')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('PT')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\b\afs14\ab\rtlch \ltrch\loch\fs14
Non specificato/apolide}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('777')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('777')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('777')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('777')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Regno Unito}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('GB')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('GB')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('GB')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('GB')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\b\afs14\ab\rtlch \ltrch\loch\fs14
Totale residenti all'estero}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[tot_pres_notte_prec_naz_istat]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[tot_arr_naz_istat]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[tot_part_naz_istat]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[tot_pres_naz_istat]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Slovacchia}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('SK')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('SK')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('SK')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('SK')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Rep. Ceca}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('CZ')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('CZ')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('CZ')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('CZ')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs20\rtlch \ltrch\loch\fs20
PROVINCIA}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs14\rtlch \ltrch\loch\fs14
PRESENTI LA}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Romania}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('RO')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('RO')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('RO')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('RO')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs20\ab\rtlch \ltrch\loch\fs20
ITALIANA}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs14\rtlch \ltrch\loch\fs14
NOTTE}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
ARRIVATI}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
PARTITI}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
PRESENTI}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Slovenia}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('SI')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('SI')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('SI')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('SI')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs20\rtlch \ltrch\loch\fs20
DI RESIDENZA}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs14\rtlch \ltrch\loch\fs14
PRECEDENTE}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Spagna}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('ES')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('ES')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('ES')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('ES')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_istat('1')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_prov_istat('1')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_istat('1')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_istat('1')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_istat('1')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Svezia}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('SE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('SE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('SE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('SE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_istat('2')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_prov_istat('2')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_istat('2')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_istat('2')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_istat('2')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Ungheria}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('HU')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('HU')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('HU')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('HU')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_istat('3')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_prov_istat('3')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_istat('3')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_istat('3')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_istat('3')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs18\ab\rtlch \ltrch\loch\fs18
EFTA}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_istat('4')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_prov_istat('4')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_istat('4')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_istat('4')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_istat('4')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Islanda}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('IS')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('IS')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('IS')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('IS')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_istat('5')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_prov_istat('5')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_istat('5')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_istat('5')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_istat('5')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Norvegia}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('NO')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('NO')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('NO')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('NO')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_istat('6')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_prov_istat('6')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_istat('6')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_istat('6')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_istat('6')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Svizzera }{\afs14\rtlch \ltrch\loch\fs14
e Liechtenstein}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('036')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('036')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('036')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('036')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_istat('7')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_prov_istat('7')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_istat('7')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_istat('7')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_istat('7')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs18\ab\rtlch \ltrch\loch\fs18
Altri Paesi Europei}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_istat('8')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_prov_istat('8')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_istat('8')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_istat('8')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_istat('8')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Croazia}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('HR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('HR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('HR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('HR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_istat('9')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_prov_istat('9')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_istat('9')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_istat('9')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_istat('9')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Russia}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('RU')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('RU')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('RU')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('RU')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_istat('10')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_prov_istat('10')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_istat('10')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_istat('10')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_istat('10')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Turchia}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('TR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('TR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('TR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('TR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_istat('11')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_prov_istat('11')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_istat('11')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_istat('11')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_istat('11')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Ucraina}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('UA')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('UA')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('UA')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('UA')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_istat('12')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_prov_istat('12')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_istat('12')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_istat('12')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_istat('12')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Altri paesi}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('100')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('100')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('100')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('100')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_istat('13')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_prov_istat('13')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_istat('13')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_istat('13')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_istat('13')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs18\ab\rtlch \ltrch\loch\fs18
Nord America}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_istat('14')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_prov_istat('14')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_istat('14')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_istat('14')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_istat('14')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Canada}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('CA')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('CA')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('CA')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('CA')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_istat('15')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_prov_istat('15')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_istat('15')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_istat('15')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_istat('15')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Stati Uniti d'America}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('US')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('US')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('US')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('US')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_istat('16')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_prov_istat('16')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_istat('16')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_istat('16')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_istat('16')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs16\rtlch \ltrch\loch\fs16
Altri paesi o territori}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('410')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('410')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('410')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('410')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_istat('17')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_prov_istat('17')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_istat('17')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_istat('17')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_istat('17')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs18\ab\rtlch \ltrch\loch\fs18
Centro e Sud America}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_istat('18')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_prov_istat('18')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_istat('18')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_istat('18')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_istat('18')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Argentina}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('AR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('AR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('AR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('AR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_istat('19')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_prov_istat('19')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_istat('19')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_istat('19')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_istat('19')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Brasile}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('BR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('BR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('BR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('BR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_istat('20')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_prov_istat('20')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_istat('20')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_istat('20')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_istat('20')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Messico}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('MX')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('MX')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('MX')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('MX')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\b\afs14\ab\rtlch \ltrch\loch\fs14
Totale residenti italiani}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[tot_pres_notte_prec_prov_istat]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[tot_arr_prov_istat]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[tot_part_prov_istat]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[tot_pres_prov_istat]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Venezuela}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('VE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('VE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('VE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('VE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Altri paesi}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[pres_notte_prec_naz_istat('530')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_istat('530')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_istat('530')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_istat('530')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\b\afs14\ab\rtlch \ltrch\loch\fs14
TOTALE GENERALE}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[cli_giorno_prec_istat]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[cli_arrivati_istat]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[cli_partiti_istat]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[cli_presenti_notte_istat]}\cell\row\pard\plain \s22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb0\sa120\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\li0\ri0\lin0\rin0\fi0\sb0\sa120\ltrpar{\rtlch \ltrch\loch
}
[/c][/r4]\par }</cmp></riga>
<riga><cmp>15</cmp><cmp>contrrtf</cmp><cmp>{\rtf1\ansi\deff0\adeflang1025
{\fonttbl{\f0\froman\fprq2\fcharset0 Times New Roman;}{\f1\froman\fprq2\fcharset2 Symbol;}{\f2\fswiss\fprq2\fcharset0 Arial;}{\f3\fswiss\fprq2\fcharset0 Calibri;}{\f4\fnil\fprq2\fcharset0 Mangal;}{\f5\fnil\fprq0\fcharset128 Mangal;}{\f6\fswiss\fprq2\fcharset128 Arial Unicode MS;}{\f7\fswiss\fprq2\fcharset0 Arial Unicode MS;}}
{\colortbl;\red0\green0\blue0;\red204\green204\blue204;\red128\green128\blue128;}
{\stylesheet{\s0\snext0\sl276\slmult1\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\aspalpha\faauto\li0\ri0\lin0\rin0\fi0\sb0\sa200\nowidctlpar\cf0\kerning1\hich\af3\langfe1040\dbch\af0\afs24\lang1081\loch\f3\fs22\lang1040 Predefinito;}
{\*\cs15\snext15 Default Paragraph Font;}
{\*\cs16\sbasedon15\snext16\hich\af0\langfe255\dbch\af0\lang0 Corpo del testo Carattere;}
{\*\cs17\sbasedon15\snext17\hich\af0\langfe255\dbch\af0\lang0 Body Text Char;}
{\*\cs18\sbasedon15\snext18\hich\af0\dbch\af0 Intestazione Carattere;}
{\*\cs19\sbasedon15\snext19\hich\af0\dbch\af0 Intestazione Carattere1;}
{\*\cs20\sbasedon15\snext20\hich\af0 Intestazione Carattere2;}
{\s21\sbasedon0\snext22\sl276\slmult1\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\aspalpha\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af4\langfe1040\dbch\af7\loch\f2\fs28\lang1040 Intestazione;}
{\s22\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb0\sa120\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Corpo testo;}
{\s23\sbasedon22\snext23\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb0\sa120\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Elenco;}
{\s24\sbasedon0\snext24\sl276\slmult1\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\aspalpha\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af5\langfe1040\dbch\af0\ai\loch\f3\fs24\lang1040 Didascalia;}
{\s25\sbasedon26\snext25\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Indice;}
{\s26\snext26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040 WW-Predefinito1;}
{\s27\snext27\sl276\slmult1\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\aspalpha\faauto\li0\ri0\lin0\rin0\fi0\sb0\sa200\nowidctlpar\cf0\kerning1\hich\af0\langfe1040\dbch\af0\afs24\lang1081\loch\f3\fs22\lang1040 WW-Predefinito;}
{\s28\sbasedon27\snext22\sl200\slmult0\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af6\langfe255\dbch\af0\loch\f2\fs28\lang1040 header;}
{\s29\sbasedon26\snext29\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 caption;}
{\s30\snext30\sl276\slmult1\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\aspalpha\faauto\li0\ri0\lin0\rin0\fi0\sb0\sa200\nowidctlpar\cf0\kerning1\hich\af0\langfe1040\dbch\af0\afs24\lang1081\loch\f3\fs22\lang1040 WW-Predefinito12;}
{\s31\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f2\fs28\lang1040 Heading;}
{\s32\sbasedon26\snext32\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Index;}
{\s33\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f2\fs28\lang1040 Heading5;}
{\s34\sbasedon26\snext34\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Index5;}
{\s35\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f2\fs28\lang1040 WW-Heading;}
{\s36\sbasedon26\snext36\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption;}
{\s37\sbasedon26\snext37\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index;}
{\s38\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f2\fs28\lang1040 WW-Heading1;}
{\s39\sbasedon26\snext39\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption1;}
{\s40\sbasedon26\snext40\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index1;}
{\s41\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading11;}
{\s42\sbasedon26\snext42\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption11;}
{\s43\sbasedon26\snext43\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index11;}
{\s44\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Heading4;}
{\s45\sbasedon26\snext45\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Index4;}
{\s46\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading111;}
{\s47\sbasedon26\snext47\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption111;}
{\s48\sbasedon26\snext48\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index111;}
{\s49\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading1111;}
{\s50\sbasedon26\snext50\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption1111;}
{\s51\sbasedon26\snext51\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index1111;}
{\s52\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading11111;}
{\s53\sbasedon26\snext53\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption11111;}
{\s54\sbasedon26\snext54\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index11111;}
{\s55\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading111111;}
{\s56\sbasedon26\snext56\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption111111;}
{\s57\sbasedon26\snext57\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index111111;}
{\s58\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading1111111;}
{\s59\sbasedon26\snext59\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption1111111;}
{\s60\sbasedon26\snext60\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index1111111;}
{\s61\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading11111111;}
{\s62\sbasedon26\snext62\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption11111111;}
{\s63\sbasedon26\snext63\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index11111111;}
{\s64\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading111111111;}
{\s65\sbasedon26\snext65\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption111111111;}
{\s66\sbasedon26\snext66\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index111111111;}
{\s67\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading1111111111;}
{\s68\sbasedon26\snext68\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption1111111111;}
{\s69\sbasedon26\snext69\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index1111111111;}
{\s70\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading11111111111;}
{\s71\sbasedon26\snext71\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption11111111111;}
{\s72\sbasedon26\snext72\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index11111111111;}
{\s73\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading111111111111;}
{\s74\sbasedon26\snext74\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption111111111111;}
{\s75\sbasedon26\snext75\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index111111111111;}
{\s76\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading1111111111111;}
{\s77\sbasedon26\snext77\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption1111111111111;}
{\s78\sbasedon26\snext78\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index1111111111111;}
{\s79\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Heading3;}
{\s80\sbasedon26\snext80\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Index3;}
{\s81\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Heading2;}
{\s82\sbasedon26\snext82\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Index2;}
{\s83\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Heading1;}
{\s84\sbasedon26\snext84\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Index1;}
{\s85\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading11111111111111;}
{\s86\sbasedon26\snext86\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption11111111111111;}
{\s87\sbasedon26\snext87\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index11111111111111;}
{\s88\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading111111111111111;}
{\s89\sbasedon26\snext89\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption111111111111111;}
{\s90\sbasedon26\snext90\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index111111111111111;}
{\s91\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading1111111111111111;}
{\s92\sbasedon26\snext92\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption1111111111111111;}
{\s93\sbasedon26\snext93\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index1111111111111111;}
{\s94\sbasedon26\snext22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb240\sa120\keepn\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Heading11111111111111111;}
{\s95\sbasedon26\snext95\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb120\sa120\cf0\i\kerning1\hich\af0\langfe255\dbch\af0\ai\loch\f0\fs24\lang1040 WW-caption11111111111111111;}
{\s96\sbasedon26\snext96\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Index11111111111111111;}
{\s97\sbasedon26\snext97\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Table Contents;}
{\s98\sbasedon97\snext98\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 Table Heading;}
{\s99\sbasedon26\snext99\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents;}
{\s100\sbasedon99\snext100\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading;}
{\s101\sbasedon26\snext101\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents1;}
{\s102\sbasedon101\snext102\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading1;}
{\s103\sbasedon26\snext103\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents12;}
{\s104\sbasedon103\snext104\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading12;}
{\s105\sbasedon26\snext105\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents123;}
{\s106\sbasedon105\snext106\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading123;}
{\s107\sbasedon26\snext107\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Table Contents1;}
{\s108\sbasedon107\snext108\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 Table Heading1;}
{\s109\sbasedon26\snext109\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Table Contents2;}
{\s110\sbasedon109\snext110\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 Table Heading2;}
{\s111\sbasedon26\snext111\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Table Contents3;}
{\s112\sbasedon111\snext112\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 Table Heading3;}
{\s113\sbasedon26\snext113\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents1234;}
{\s114\sbasedon113\snext114\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading1234;}
{\s115\sbasedon26\snext115\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents12345;}
{\s116\sbasedon115\snext116\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading12345;}
{\s117\sbasedon26\snext117\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents123456;}
{\s118\sbasedon117\snext118\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading123456;}
{\s119\sbasedon26\snext119\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents1234567;}
{\s120\sbasedon119\snext120\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading1234567;}
{\s121\sbasedon26\snext121\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents12345678;}
{\s122\sbasedon121\snext122\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading12345678;}
{\s123\sbasedon26\snext123\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents123456789;}
{\s124\sbasedon123\snext124\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading123456789;}
{\s125\sbasedon26\snext125\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents12345678910;}
{\s126\sbasedon125\snext126\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading12345678910;}
{\s127\sbasedon26\snext127\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents1234567891011;}
{\s128\sbasedon127\snext128\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading1234567891011;}
{\s129\sbasedon26\snext129\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents123456789101112;}
{\s130\sbasedon129\snext130\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading123456789101112;}
{\s131\sbasedon26\snext131\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents12345678910111213;}
{\s132\sbasedon131\snext132\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading12345678910111213;}
{\s133\sbasedon26\snext133\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents1234567891011121314;}
{\s134\sbasedon133\snext134\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading1234567891011121314;}
{\s135\sbasedon26\snext135\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Table Contents4;}
{\s136\sbasedon135\snext136\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 Table Heading4;}
{\s137\sbasedon26\snext137\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents123456789101112131415;}
{\s138\sbasedon137\snext138\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading123456789101112131415;}
{\s139\sbasedon26\snext139\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents12345678910111213141516;}
{\s140\sbasedon139\snext140\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading12345678910111213141516;}
{\s141\sbasedon26\snext141\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 WW-Table Contents1234567891011121314151617;}
{\s142\sbasedon141\snext142\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 WW-Table Heading1234567891011121314151617;}
{\s143\sbasedon26\snext143\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Table Contents5;}
{\s144\sbasedon143\snext144\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 Table Heading5;}
{\s145\sbasedon26\snext145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040 Contenuto tabella;}
{\s146\sbasedon145\snext146\qc{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\b\kerning1\hich\af0\langfe255\dbch\af0\ab\loch\f0\fs24\lang1040 Intestazione tabella;}
}{\info{\author Marco}{\creatim\yr2012\mo11\dy27\hr19\min32}{\revtim\yr2012\mo11\dy28\hr16\min31}{\printim\yr0\mo0\dy0\hr0\min0}{\comment OpenOffice.org}{\vern3410}}\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709\deftab709
[r4 array="date_c59m"][r][r2][null_c59m][/r2][/r][null_c59m][/r4][r][r6][null_c59m][/r6][/r]
{\*\pgdsctbl
{\pgdsc0\pgdscuse451\pgwsxn11906\pghsxn16838\marglsxn780\margrsxn1121\margtsxn615\margbsxn803\pgdscnxt0 Stile predefinito;}}
\formshade{\*\pgdscno0}\paperh16838\paperw11906\margl780\margr1121\margt615\margb803\sectd\sbknone\sectunlocked1\pgndec\pgwsxn11906\pghsxn16838\marglsxn780\margrsxn1121\margtsxn615\margbsxn803\ftnbj\ftnstart1\ftnrstcont\ftnnar\aenddoc\aftnrstcont\aftnstart1\aftnnrlc
\pgndec\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\li0\ri0\lin0\rin0\fi0\qc{\b\hich\af0\ab\rtlch \ltrch\loch\fs32
ISTAT}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\li0\ri0\lin0\rin0\fi0\qc\tx10005{\b\hich\af0\ab\rtlch \ltrch\loch
RILEVAZIONE DEL MOVIMENTO DEI CLIENTI NEGLI ESERCIZI RICETTIVI}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\li0\ri0\lin0\rin0\fi0\qc{\b\hich\af0\ab\rtlch \ltrch\loch\fs20
SEZIONE MENSILE}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\li0\ri0\lin0\rin0\fi0\qc{\afs20\rtlch \ltrch\fs20
 }
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\li0\ri0\lin0\rin0\fi0\qc{\b\hich\af0\ab\rtlch \ltrch\loch\fs20
Comune [comune_c59m]   Anno [anno_c59m]   Mese [mese_c59m]}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\li0\ri0\lin0\rin0\fi0{\i\b\hich\af0\ai\ab\rtlch \ltrch\loch\fs20
Apertura nel mese}{\i\hich\af0\ai\rtlch \ltrch\loch\fs20
 (1)}
\par \trowd\trql\trleft0\ltrrow\trrh1185\trpaddft3\trpaddt0\trpaddfl3\trpaddl0\trpaddfb3\trpaddb0\trpaddfr3\trpaddr0\clbrdrt\brdrs\brdrw1\brdrcf5\clbrdrl\brdrs\brdrw1\brdrcf5\clbrdrb\brdrs\brdrw1\brdrcf5\cellx4865\clbrdrt\brdrs\brdrw1\brdrcf5\clbrdrl\brdrs\brdrw1\brdrcf5\clbrdrb\brdrs\brdrw1\brdrcf5\clbrdrr\brdrs\brdrw1\brdrcf5\cellx10004\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\b\hich\af0\ab\rtlch \ltrch\loch\fs20
STRUTTURA APERTA almeno un giorno nel mese  }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20\loch\f5
[struttura_aperta_c59m]}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\hich\af0\rtlch \ltrch\loch
N. giornate totali di apertura nel mese [giorni_apertura_c59m]}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\hich\af0\rtlch \ltrch
 }{\hich\af0\rtlch \ltrch\loch\fs18
(comprensivo dei giorni di apertura senza arrivi,}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\hich\af0\rtlch \ltrch\loch\fs18
partenze e presenze di clienti)}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\b\hich\af0\ab\rtlch \ltrch\loch\fs20
STRUTTURA CHIUSA per tutto il mese     }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20\loch\f5
[struttura_chiusa_c59m]}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\hich\af0\rtlch \ltrch
 }{\hich\af0\rtlch \ltrch\loch
Periodo di chiusura}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\hich\af0\rtlch \ltrch
 }
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\hich\af0\rtlch \ltrch\loch
dal [inizio_chiusura_c59m] al [fine_chiusura_c59m]}\cell\row\trowd\trql\trleft0\ltrrow\trrh686\trpaddft3\trpaddt0\trpaddfl3\trpaddl0\trpaddfb3\trpaddb0\trpaddfr3\trpaddr0\clbrdrl\brdrs\brdrw1\brdrcf5\clbrdrb\brdrs\brdrw1\brdrcf5\clbrdrr\brdrs\brdrw1\brdrcf5\clcbpat3\cellx10004\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qj\tx9750\tx10155{\hich\af0\rtlch \ltrch\loch\fs18
(1) Nel caso di struttura APERTA proseguire nella compilazione del modello e procedere poi con le sezioni giornaliere (Mod. ISTAT C/59_G). Nel caso di struttura CHIUSA \'e8 sufficiente la compilazione delle "Caratteristiche generali dell'esercizio" di questo modello mensile(Mod. ISTAT C/59_M).}\cell\row\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\li0\ri0\lin0\rin0\fi0{\afs16\rtlch \ltrch\fs16
 }
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\li0\ri0\lin0\rin0\fi0\tx630{\i\b\hich\af0\ai\ab\rtlch \ltrch\loch\fs20
1. Caratteristiche generali dell'esercizio}
\par \trowd\trql\trleft0\ltrrow\trpaddft3\trpaddt0\trpaddfl3\trpaddl0\trpaddfb3\trpaddb0\trpaddfr3\trpaddr0\clbrdrt\brdrs\brdrw1\brdrcf5\clbrdrl\brdrs\brdrw1\brdrcf5\clbrdrb\brdrs\brdrw1\brdrcf5\clbrdrr\brdrs\brdrw1\brdrcf5\cellx10004\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\b\hich\af0\ab\rtlch \ltrch\loch
Denominazione esercizio ricettivo ___________________________________}\cell\row\trowd\trql\trleft0\ltrrow\trrh1308\trpaddft3\trpaddt0\trpaddfl3\trpaddl0\trpaddfb3\trpaddb0\trpaddfr3\trpaddr0\clbrdrl\brdrs\brdrw1\brdrcf5\clbrdrb\brdrs\brdrw1\brdrcf5\clvertalc\cellx1709\clbrdrl\brdrs\brdrw1\brdrcf5\clbrdrb\brdrs\brdrw1\brdrcf5\clbrdrr\brdrs\brdrw1\brdrcf5\cellx10004\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc{\b\hich\af0\ab\rtlch \ltrch\loch
Tipo esercizio*}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\b\hich\af0\ab\rtlch \ltrch\loch\fs20
ALBERGHI E STRUTTURE SIMILI}{\hich\af0\rtlch \ltrch\loch\fs20
 (cod. ATECO 2007: }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20
55.10}{\hich\af0\rtlch \ltrch\loch\fs20
):}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\b\hich\af0\ab\rtlch \ltrch
                                               }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20
Albergo                                                  }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20\loch\f5
\u58748\'3f}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\b\hich\af0\ab\rtlch \ltrch
                                               }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20
Residenza turistico-alberghiera          }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20\loch\f5
\u58748\'3f}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\b\hich\af0\ab\rtlch \ltrch\loch\fs20
Categoria esercizio}{\hich\af0\rtlch \ltrch\loch\fs20
 5 stelle lusso }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20\loch\f5
\u58748\'3f}{\hich\af0\rtlch \ltrch\loch\fs20
  5 stelle }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20\loch\f5
\u58748\'3f}{\hich\af0\rtlch \ltrch\loch\fs20
  4 stelle }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20\loch\f5
\u58748\'3f}{\hich\af0\rtlch \ltrch\loch\fs20
  3 stelle }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20\loch\f5
\u58748\'3f}{\hich\af0\rtlch \ltrch\loch\fs20
  2 stelle }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20\loch\f5
\u58748\'3f}{\hich\af0\rtlch \ltrch\loch\fs20
  1 stella }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20\loch\f5
\u58748\'3f}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\b\hich\af0\ab\rtlch \ltrch\loch\fs20
Eventuale catena alberghiera di appartenenza _________________________________}\cell\row\trowd\trql\trleft0\ltrrow\trrh2856\trpaddft3\trpaddt0\trpaddfl3\trpaddl0\trpaddfb3\trpaddb0\trpaddfr3\trpaddr0\clbrdrl\brdrs\brdrw1\brdrcf5\clbrdrb\brdrs\brdrw1\brdrcf5\cellx1709\clbrdrl\brdrs\brdrw1\brdrcf5\clbrdrb\brdrs\brdrw1\brdrcf5\clbrdrr\brdrs\brdrw1\brdrcf5\cellx10004\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\b\hich\af0\ab\rtlch \ltrch\loch\fs20
EXTRA ALBERGHIERO}{\hich\af0\rtlch \ltrch\loch\fs20
 (cod. ATECO 2007: }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20
55.20}{\hich\af0\rtlch \ltrch\loch\fs20
 e }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20
55.30}{\hich\af0\rtlch \ltrch\loch\fs20
):}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\afs16\rtlch \ltrch\fs16
 }
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\b\hich\af0\ab\rtlch \ltrch\loch\fs18
1}{\hich\af0\rtlch \ltrch\loch\fs18
 ALLOGGI PER VACANZE E ALTRE STRUTTURE PER BREVI SOGGIORNI (cod. ATECO 2007: }{\b\hich\af0\ab\rtlch \ltrch\loch\fs18
55.20}{\hich\af0\rtlch \ltrch\loch\fs18
)}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\hich\af0\rtlch \ltrch
                                }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20
Villaggio turistico                                                                         }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20\loch\f5
\u58748\'3f}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\b\hich\af0\ab\rtlch \ltrch
                                }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20
Alloggio in affitto gestito in forma imprenditoriale                  }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20\loch\f5
\u58748\'3f}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\b\hich\af0\ab\rtlch \ltrch
                                }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20
Alloggio agrituristico                                                                   }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20\loch\f5
\u58748\'3f}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\b\hich\af0\ab\rtlch \ltrch
                                }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20
Ostello per la giovent\'f9                                                                 }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20\loch\f5
\u58748\'3f}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\b\hich\af0\ab\rtlch \ltrch
                                }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20
Casa per ferie                                                                               }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20\loch\f5
\u58748\'3f}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\b\hich\af0\ab\rtlch \ltrch
                                }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20
Rifugio di montagna                                                                    }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20\loch\f5
\u58748\'3f}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\b\hich\af0\ab\rtlch \ltrch
                                }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20
Bed and breakfast                                                                        }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20\loch\f5
\u58748\'3f}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\hich\af0\rtlch \ltrch
                                }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20
Altro  ___________________________________}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\afs16\rtlch \ltrch\fs16
 }
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\b\hich\af0\ab\rtlch \ltrch\loch\fs18
2 }{\hich\af0\rtlch \ltrch\loch\fs18
AREE DI CAMPEGGIO E AREE ATTREZZATE PER CAMPER E ROULOTTE (cod. ATECO 2007: }{\b\hich\af0\ab\rtlch \ltrch\loch\fs18
55.30}{\hich\af0\rtlch \ltrch\loch\fs18
)}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\b\hich\af0\ab\rtlch \ltrch
                               }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20
Campeggio/ area attrezzata                                                         \u58748\'3f}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\b\hich\af0\ab\rtlch \ltrch
                               }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20
Campeggio e villaggio turistico in forma mista                         \u58748\'3f}\cell\row\trowd\trql\trleft0\ltrrow\trrh273\trpaddft3\trpaddt0\trpaddfl3\trpaddl0\trpaddfb3\trpaddb0\trpaddfr3\trpaddr0\clbrdrl\brdrs\brdrw1\brdrcf5\clbrdrb\brdrs\brdrw1\brdrcf5\cellx1709\clbrdrl\brdrs\brdrw1\brdrcf5\clbrdrb\brdrs\brdrw1\brdrcf5\clbrdrr\brdrs\brdrw1\brdrcf5\cellx10004\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\b\hich\af0\ab\rtlch \ltrch\loch\fs20
ALLOGGIO PRIVATO IN AFFITTO                                                                      \u58748\'3f}\cell\row\trowd\trql\trleft0\ltrrow\trrh1296\trpaddft3\trpaddt0\trpaddfl3\trpaddl0\trpaddfb3\trpaddb0\trpaddfr3\trpaddr0\clbrdrl\brdrs\brdrw1\brdrcf5\clbrdrb\brdrs\brdrw1\brdrcf5\clbrdrr\brdrs\brdrw1\brdrcf5\cellx10004\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\i\hich\af0\ai\rtlch \ltrch\loch\fs20
Compilare le seguenti informazioni solo se variate rispetto ai documenti autorizzativi}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\hich\af0\rtlch \ltrch\loch\fs20
Indirizzo (piazza, via, ....)__________________________________________________________ CAP ____________}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\hich\af0\rtlch \ltrch\loch\fs20
Comune ________________________________ Provincia _______________________  Telefono________________}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\hich\af0\rtlch \ltrch\loch\fs20
Email }{{\field{\*\fldinst HYPERLINK "mailto:________________@__________________" }\cf2\ul\ulc1\kerning1\hich\af0\langfe255{\fldrslt \cf2\ul\ulc1\langfe255\lang255\rtlch \ltrch\loch\fs20\lang255
_____________________@_____________________________________}{\rtlch \ltrch\loch
}}  Fax _______________________}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\hich\af0\rtlch \ltrch\loch\fs20
Sito web www.______________________________________  Eventuale software gestionale in uso _______________}\cell\row\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\li0\ri0\lin0\rin0\fi0\qj{\hich\af0\rtlch \ltrch\loch\fs18
*le varie specificazioni tipologiche (ad es. i villaggi-albergo, le pensioni, i motel, le residenze d\'92epoca/dimora storica, i meubl\'e9 o garn\'ec, l'albergo diffuso, le country house-residenza di campagna e ogni altra specificazione) vanno classificate a seconda di quanto previsto dalle Leggi Regionali vigenti.}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\li0\ri0\lin0\rin0\fi0\qj{\afs16\rtlch \ltrch\fs16
 }
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\li0\ri0\lin0\rin0\fi0\qj{\i\b\hich\af0\ai\ab\rtlch \ltrch\loch\fs20
2. Capacit\'e0 dell'esercizio }{\i\hich\af0\ai\rtlch \ltrch\loch\fs20
(2)}
\par \trowd\trql\trleft0\ltrrow\trpaddft3\trpaddt0\trpaddfl3\trpaddl0\trpaddfb3\trpaddb0\trpaddfr3\trpaddr0\clbrdrt\brdrs\brdrw1\brdrcf5\clbrdrl\brdrs\brdrw1\brdrcf5\clbrdrb\brdrs\brdrw1\brdrcf5\clvertalc\cellx5002\clbrdrt\brdrs\brdrw1\brdrcf5\clbrdrl\brdrs\brdrw1\brdrcf5\clbrdrb\brdrs\brdrw1\brdrcf5\clbrdrr\brdrs\brdrw1\brdrcf5\clvertalc\cellx10004\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\b\hich\af0\ab\rtlch \ltrch\loch\fs20
N. Camere disponibili (*) }{\hich\af0\rtlch \ltrch\loch\fs20
[camere_disponibili_c59m]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\hich\af0\rtlch \ltrch
 }{\b\hich\af0\ab\rtlch \ltrch\loch\fs20
N. Posti - letto disponibili(**) [letti_disponibili_c59m]}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\hich\af0\rtlch \ltrch
      }{\hich\af0\rtlch \ltrch\loch\fs20
(al netto degli aggiunti)}\cell\row\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\li0\ri0\lin0\rin0\fi0\qj{\i\hich\af0\ai\rtlch \ltrch\loch\fs18
(2) riportare il numero di camere e di posti-letto effettivamente disponibili alla vendita nel mese; tale numero pu\'f2 essere diverso da quello dichiarato ufficialmente (ad es. nel caso di ristrutturazione di parte dell'esercizio). Qualora tale numero variasse nel corso del mese, indicare la media mensile (somma delle camere disponibili ogni giorno diviso il numero di giorni di apertura e somma dei posti-letto disponibili ogni giorno diviso il numero di giorni di apertura)}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\li0\ri0\lin0\rin0\fi0\qj{\i\hich\af0\ai\rtlch \ltrch\loch\fs18
* per le residenze turistico-alberghiere, se non \'e8 noto il numero effettivo delle camere, indicare il numero di unit\'e0 abitative; per i campeggi e le aree attrezzate indicare il numero di piazzole; per i villaggi turistici indicare il numero degli alloggiamenti.}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\li0\ri0\lin0\rin0\fi0\qj{\i\hich\af0\ai\rtlch \ltrch\loch\fs18
** un letto matrimoniale deve essere conteggiato come due posti-letto. Per i campeggi e le aree attrezzate, se non \'e8 noto il numero effettivo dei posti, considerare 4 posti-letto per piazzola}
\par \trowd\trql\trleft0\ltrrow\trpaddft3\trpaddt0\trpaddfl3\trpaddl0\trpaddfb3\trpaddb0\trpaddfr3\trpaddr0\clbrdrt\brdrs\brdrw1\brdrcf5\clbrdrl\brdrs\brdrw1\brdrcf5\clbrdrb\brdrs\brdrw1\brdrcf5\clbrdrr\brdrs\brdrw1\brdrcf5\cellx10005\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\b\hich\af0\ab\rtlch \ltrch\loch\fs20
Referente per chiarimenti sul questionario}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\hich\af0\rtlch \ltrch\loch\fs20
Sig./Sig.ra [nome_contatto_c59m]}
\par \pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0{\hich\af0\rtlch \ltrch\loch\fs20
Telefono [telefono_contatto_c59m] email [email_contatto_c59m]}\cell\row\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\ltrpar\cf1\kerning1\hich\af3\langfe255\dbch\af3\loch\f0\fs24\lang1040\li0\ri0\lin0\rin0\fi0\qj{\afs16\rtlch \ltrch\fs16
 }
\par \page
{\*\pgdsctbl
{\pgdsc0\pgdscuse195\pgwsxn11905\pghsxn16837\marglsxn705\margrsxn700\margtsxn405\margbsxn382\pgdscnxt0 Predefinito;}}
\formshade{\*\pgdscno0}\paperh16837\paperw11905\margl705\margr700\margt405\margb382\sectd\sbknone\sectunlocked1\pgndec\pgwsxn11905\pghsxn16837\marglsxn705\margrsxn700\margtsxn405\margbsxn382\ftnbj\ftnstart1\ftnrstcont\ftnnar\aenddoc\aftnrstcont\aftnstart1\aftnnrlc
\trowd\trql\trleft0\ltrrow\trrh-420\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx1740\clpadfl3\clpadl6\clpadft3\clpadt6\clpadfb3\clpadb6\clpadfr3\clpadr6\clvertalc\cellx3500\clpadfl3\clpadl6\clpadft3\clpadt6\clpadfb3\clpadb6\clpadfr3\clpadr6\clvertalc\cellx7000\clpadfl3\clpadl6\clpadft3\clpadt6\clpadfb3\clpadb6\clpadfr3\clpadr6\clvertalc\cellx8750\clbrdrt\brdrs\brdrw1\brdrcf1\clpadfl3\clpadl6\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt6\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb6\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr6\clvertalc\cellx10500\pgndec\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs18\ab\rtlch \ltrch\loch\fs18
Mod. ISTAT C/59_M}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs32\ab\rtlch \ltrch\loch\fs32
ISTAT}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs18\ab\rtlch \ltrch\loch\fs18
 }\cell\row\trowd\trql\trleft0\ltrrow\trrh-204\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clvertalc\cellx1740\clvertalc\cellx3500\clvertalc\cellx5250\clvertalc\cellx7000\clvertalc\cellx8750\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10500\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs14\ab\rtlch \ltrch\loch\fs14
 }\cell\row\trowd\trql\trleft0\ltrrow\trrh-261\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clvertalc\cellx10500\pard\plain \s27\sl276\slmult1\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\aspalpha\faauto\li0\ri0\lin0\rin0\fi0\sb0\sa200\nowidctlpar\cf0\kerning1\hich\af0\langfe1040\dbch\af0\afs24\lang1081\loch\f3\fs22\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\sb0\sa200\ltrpar{\b\ab\rtlch \ltrch\loch\fs24\loch\f0
RILEVAZIONE DEL MOVIMENTO DEI CLIENTI NEGLI ESERCIZI RICETTIVI}\cell\row\trowd\trql\trleft0\ltrrow\trrh-221\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clvertalc\cellx1740\clvertalc\cellx8750\clvertalc\cellx10500\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs20\ab\rtlch \ltrch\loch\fs20
TOTALE MENSILE}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\row\trowd\trql\trleft0\ltrrow\trrh-306\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clvertalc\cellx1740\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3500\clvertalc\cellx5250\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx7000\clvertalc\cellx8750\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx10500\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs22\ab\rtlch \ltrch\loch\fs22
Anno}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs22\rtlch \ltrch\loch\fs22
[anno_c59m]}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs22\ab\rtlch \ltrch\loch\fs22
Mese}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs22\rtlch \ltrch\loch\fs22
[mese_c59m]}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs22\ab\rtlch \ltrch\loch\fs22
 }\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs22\rtlch \ltrch\loch\fs22
 }\cell\row\trowd\trql\trleft0\ltrrow\trrh-57\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clvertalc\cellx1740\clvertalc\cellx3500\clvertalc\cellx5250\clvertalc\cellx7000\clvertalc\cellx8750\clvertalc\cellx10500\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\row\trowd\trql\trleft0\ltrrow\trrh-306\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clvertalc\cellx1740\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx5250\clvertalc\cellx7000\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx10500\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs22\ab\rtlch \ltrch\loch\fs22
Comune}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs22\rtlch \ltrch\loch\fs22
[comune_struttura]}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs22\ab\rtlch \ltrch\loch\fs22
Denominazione}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs22\rtlch \ltrch\loch\fs22
[nome_struttura]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-57\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clvertalc\cellx1740\clvertalc\cellx3500\clvertalc\cellx5250\clvertalc\cellx7000\clvertalc\cellx8750\clvertalc\cellx10500\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\row\trowd\trql\trleft0\ltrrow\trrh-272\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clvertalc\cellx1740\clvertalc\cellx7000\clbrdrt\brdrs\brdrw1\brdrcf1\clpadfl3\clpadl55\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt55\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb55\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr55\clvertalc\cellx8750\clvertalc\cellx10500\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qr\ltrpar{\b\afs18\ab\rtlch \ltrch\loch\fs18
Totale camere }{\b\afs16\ab\rtlch \ltrch\loch\fs16
}{\b\afs18\ab\rtlch \ltrch\loch\fs18
 occupate per giornata }\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[camere_occupate_c59m]}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\row\trowd\trql\trleft0\ltrrow\trrh-79\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clvertalc\cellx1740\clvertalc\cellx7000\clvertalc\cellx8750\clvertalc\cellx10500\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qr\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s145\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\row\trowd\trql\trleft0\ltrrow\trrh-227\trpaddft3\trpaddt55\trpaddfl3\trpaddl55\trpaddfb3\trpaddb55\trpaddfr3\trpaddr55\clvertalc\cellx1570\clvertalc\cellx2477\clvertalc\cellx3384\clvertalc\cellx4291\clvertalc\cellx5198\clvertalc\cellx5328\clvertalc\cellx6893\clvertalc\cellx7800\clvertalc\cellx8707\clvertalc\cellx9614\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\i\afs14\ai\rtlch \ltrch\loch\fs14
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\i\afs14\ai\rtlch \ltrch\loch\fs14
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\i\afs14\ai\rtlch \ltrch\loch\fs14
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\i\afs14\ai\rtlch \ltrch\loch\fs14
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\i\afs14\ai\rtlch \ltrch\loch\fs14
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\i\afs14\ai\rtlch \ltrch\loch\fs14
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\i\afs14\ai\rtlch \ltrch\loch\fs14
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\i\afs14\ai\rtlch \ltrch\loch\fs14
 }\cell\row\trowd\trql\trleft0\ltrrow\trrh-998\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx5198\clvertalc\cellx5328\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs20\rtlch \ltrch\loch\fs20
PAESE }{\b\afs20\ab\rtlch \ltrch\loch\fs20
ESTERO}{\afs20\rtlch \ltrch\loch\fs20
 DI RESIDENZA}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs14\rtlch \ltrch\loch\fs14
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
ARRIVATI}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
PARTITI}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{{\*\bkmkstart __DdeLink__5_1545293638}\afs18\rtlch \ltrch\loch\fs18
PRESENTI }{{\*\bkmkend __DdeLink__5_1545293638}\afs16\rtlch \ltrch\loch\fs16
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs20\rtlch \ltrch\loch\fs20
PAESE }{\b\afs20\ab\rtlch \ltrch\loch\fs20
ESTERO}{\afs20\rtlch \ltrch\loch\fs20
 DI RESIDENZA}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs14\rtlch \ltrch\loch\fs14
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
ARRIVATI}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
PARTITI}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{{\*\bkmkstart __DdeLink__20_1545293638}\afs18\rtlch \ltrch\loch\fs18
PRESENTI}{{\*\bkmkend __DdeLink__20_1545293638}\afs18\rtlch \ltrch\loch\fs18
 }{\afs16\rtlch \ltrch\loch\fs16
 }\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs20\ab\rtlch \ltrch\loch\fs20
Unione Europea (27)}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs20\ab\rtlch \ltrch\loch\fs20
Asia}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Austria}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('AT')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('AT')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('AT')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Cina}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('CN')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('CN')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('CN')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Belgio}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('BE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('BE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('BE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Corea del Sud}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('KR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('KR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('KR')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Bulgaria}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('BG')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('BG')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('BG')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Giappone}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('JP')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('JP')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('JP')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Cipro}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('CY')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('CY')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('CY')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
India}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('IN')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('IN')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('IN')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Danimarca}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('DK')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('DK')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('DK')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Israele}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('IL')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('IL')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('IL')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Estonia}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('EE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('EE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('EE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs14\rtlch \ltrch\loch\fs14
Altri paesi Asia Occident.}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('750')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('750')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('750')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Finlandia}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('FI')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('FI')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('FI')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Altri paesi}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('760')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('760')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('760')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Francia}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('FR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('FR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('FR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs18\ab\rtlch \ltrch\loch\fs18
Africa}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Germania}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('DE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('DE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('DE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Sud Africa}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('ZA')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('ZA')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('ZA')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Grecia}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('GR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('GR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('GR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Egitto}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('EG')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('EG')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('EG')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Irlanda}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('IE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('IE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('IE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs14\rtlch \ltrch\loch\fs14
Altri paesi Africa Mediter.}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('230')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('230')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('230')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Lettonia}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('LV')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('LV')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('LV')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Altri paesi}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('300')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('300')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('300')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Lituania}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('LT')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('LT')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('LT')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs18\ab\rtlch \ltrch\loch\fs18
Oceania}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Lussemburgo}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('LU')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('LU')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('LU')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Australia}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('AU')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('AU')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('AU')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Malta}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('MT')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('MT')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('MT')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Nuova Zelanda}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('NZ')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('NZ')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('NZ')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Paesi Bassi}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('NL')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('NL')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('NL')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs16\rtlch \ltrch\loch\fs16
Altri paesi o territori}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('810')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('810')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('810')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clpadfl3\clpadl55\clpadft3\clpadt55\clpadfb3\clpadb55\clpadfr3\clpadr55\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Polonia}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('PL')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('PL')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('PL')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrt\brdrs\brdrw1\brdrcf1\clpadfl3\clpadl55\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt55\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb55\clpadfr3\clpadr55\clvertalc\cellx6893\clbrdrt\brdrs\brdrw1\brdrcf1\clpadfl3\clpadl55\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt55\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb55\clpadfr3\clpadr55\clcbpat2\clvertalc\cellx7800\clbrdrt\brdrs\brdrw1\brdrcf1\clpadfl3\clpadl55\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt55\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb55\clpadfr3\clpadr55\clvertalc\cellx8707\clbrdrt\brdrs\brdrw1\brdrcf1\clpadfl3\clpadl55\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt55\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb55\clpadfr3\clpadr55\clvertalc\cellx9614\clbrdrt\brdrs\brdrw1\brdrcf1\clpadfl3\clpadl55\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt55\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb55\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr55\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Portogallo}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('PT')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('PT')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('PT')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\b\afs14\ab\rtlch \ltrch\loch\fs14
Non specificato/apolide}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('777')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('777')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('777')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Regno Unito}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('GB')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('GB')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('GB')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\b\afs14\ab\rtlch \ltrch\loch\fs14
Totale residenti all'estero}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[tot_arr_naz_c59m]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[tot_part_naz_c59m]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[tot_pres_naz_c59m]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Slovacchia}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('SK')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('SK')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('SK')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Rep. Ceca}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('CZ')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('CZ')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('CZ')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs20\rtlch \ltrch\loch\fs20
PROVINCIA}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs14\rtlch \ltrch\loch\fs14
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Romania}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('RO')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('RO')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('RO')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs20\ab\rtlch \ltrch\loch\fs20
ITALIANA}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs14\rtlch \ltrch\loch\fs14
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
ARRIVATI}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
PARTITI}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
PRESENTI}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Slovenia}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('SI')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('SI')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('SI')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs20\rtlch \ltrch\loch\fs20
DI RESIDENZA}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs14\rtlch \ltrch\loch\fs14
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Spagna}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('ES')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('ES')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('ES')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_c59m('1')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_c59m('1')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_c59m('1')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_c59m('1')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Svezia}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('SE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('SE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('SE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_c59m('2')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_c59m('2')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_c59m('2')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_c59m('2')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Ungheria}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('HU')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('HU')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('HU')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_c59m('3')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_c59m('3')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_c59m('3')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_c59m('3')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs18\ab\rtlch \ltrch\loch\fs18
EFTA}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_c59m('4')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_c59m('4')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_c59m('4')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_c59m('4')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Islanda}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('IS')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('IS')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('IS')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_c59m('5')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_c59m('5')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_c59m('5')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_c59m('5')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Norvegia}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('NO')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('NO')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('NO')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_c59m('6')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_c59m('6')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_c59m('6')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_c59m('6')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Svizzera }{\afs14\rtlch \ltrch\loch\fs14
e Liechtenstein}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('036')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('036')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('036')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_c59m('7')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_c59m('7')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_c59m('7')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_c59m('7')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs18\ab\rtlch \ltrch\loch\fs18
Altri Paesi Europei}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_c59m('8')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_c59m('8')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_c59m('8')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_c59m('8')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Croazia}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('HR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('HR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('HR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_c59m('9')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_c59m('9')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_c59m('9')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_c59m('9')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Russia}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('RU')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('RU')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('RU')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_c59m('10')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_c59m('10')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_c59m('10')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_c59m('10')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Turchia}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('TR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('TR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('TR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_c59m('11')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_c59m('11')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_c59m('11')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_c59m('11')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Ucraina}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('UA')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('UA')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('UA')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_c59m('12')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_c59m('12')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_c59m('12')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_c59m('12')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Altri paesi}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('100')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('100')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('100')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_c59m('13')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_c59m('13')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_c59m('13')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_c59m('13')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs18\ab\rtlch \ltrch\loch\fs18
Nord America}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_c59m('14')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_c59m('14')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_c59m('14')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_c59m('14')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Canada}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('CA')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('CA')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('CA')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_c59m('15')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_c59m('15')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_c59m('15')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_c59m('15')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Stati Uniti d'America}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('US')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('US')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('US')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_c59m('16')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_c59m('16')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_c59m('16')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_c59m('16')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs16\rtlch \ltrch\loch\fs16
Altri paesi o territori}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('410')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('410')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('410')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_c59m('17')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_c59m('17')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_c59m('17')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_c59m('17')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\b\afs18\ab\rtlch \ltrch\loch\fs18
Centro e Sud America}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_c59m('18')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_c59m('18')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_c59m('18')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_c59m('18')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Argentina}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('AR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('AR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('AR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_c59m('19')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_c59m('19')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_c59m('19')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_c59m('19')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Brasile}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('BR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('BR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('BR')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[prov_pos_c59m('20')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_prov_c59m('20')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_prov_c59m('20')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_prov_c59m('20')]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Messico}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('MX')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('MX')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('MX')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\b\afs14\ab\rtlch \ltrch\loch\fs14
Totale residenti italiani}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[tot_arr_prov_c59m]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[tot_part_prov_c59m]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[tot_pres_prov_c59m]}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Venezuela}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('VE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('VE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('VE')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\row\trowd\trql\trleft0\ltrrow\trrh-249\trpaddft3\trpaddt6\trpaddfl3\trpaddl6\trpaddfb3\trpaddb6\trpaddfr3\trpaddr6\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx1570\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx2477\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx3384\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clvertalc\cellx4291\clpadfl3\clpadl0\clbrdrl\brdrs\brdrw1\brdrcf1\clpadft3\clpadt0\clbrdrb\brdrs\brdrw1\brdrcf1\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5198\clpadfl3\clpadl0\clpadft3\clpadt0\clpadfb3\clpadb0\clbrdrr\brdrs\brdrw1\brdrcf1\clpadfr3\clpadr0\clvertalc\cellx5328\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx6893\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clcbpat2\clvertalc\cellx7800\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx8707\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx9614\clbrdrt\brdrs\brdrw1\brdrcf1\clbrdrl\brdrs\brdrw1\brdrcf1\clbrdrb\brdrs\brdrw1\brdrcf1\clbrdrr\brdrs\brdrw1\brdrcf1\clvertalc\cellx10519\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\afs18\rtlch \ltrch\loch\fs18
Altri paesi}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[arrivi_naz_c59m('530')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[partenze_naz_c59m('530')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[presenze_naz_c59m('530')]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\rtlch \ltrch\loch
}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\ltrpar{\b\afs14\ab\rtlch \ltrch\loch\fs14
TOTALE GENERALE}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
 }\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[cli_arrivati_c59m]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[cli_partiti_c59m]}\cell\pard\plain \s26\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\nowidctlpar\cf0\kerning1\hich\af0\langfe255\dbch\af0\afs24\lang1081\loch\f0\fs24\lang1040\intbl\li0\ri0\lin0\rin0\fi0\qc\ltrpar{\afs18\rtlch \ltrch\loch\fs18
[cli_presenti_notte_c59m]}\cell\row\pard\plain \s22\ql{\*\hyphen2\hyphlead2\hyphtrail2\hyphmax0}\faauto\li0\ri0\lin0\rin0\fi0\sb0\sa120\cf0\kerning1\hich\af0\langfe255\dbch\af0\loch\f0\fs24\lang1040\li0\ri0\lin0\rin0\fi0\sb0\sa120\ltrpar{\rtlch \ltrch\loch
}
\par }</cmp></riga>
<riga><cmp>1</cmp><cmp>contrhtm</cmp><cmp><B><U><FONT FACE="Times" SIZE=4><P ALIGN="CENTER">ESEMPIO DI CONTRATTO PER HOTELDRUID</P>
</U></B></FONT><FONT FACE="Times"><P ALIGN="JUSTIFY"></P>
<P ALIGN="JUSTIFY">&nbsp;</P>
<P ALIGN="JUSTIFY">
Con la presente scrittura privata, in duplice copia, tra i signori Pinco Pallino
 nato il 1.1.1954, residente in Vattelapesca via Vattelapesca 33 tel. 00000000 e
</P>
<P ALIGN="JUSTIFY">
[il] signor[e] [nome] [cognome] nat[o] il [datanascita] residente in [citta] [via2] n 
[numcivico] tel [telefono] di seguito denominat[o] "conduttore"
</P>
<P ALIGN="JUSTIFY"></P>
<P ALIGN="CENTER">
PREMESSO
</P>
<P ALIGN="JUSTIFY"></P>
<P ALIGN="JUSTIFY">
che il signor Pinco Pallino è proprietario di alcune unità immobiliari 
del Parco hoteldruid sito in Vattelapesca;
</P>
<P ALIGN="JUSTIFY">
che il conduttore intende prendere in locazione un appartamento del Parco 
hoteldruid come seconda casa per adibirlo all'uso di vacanza e soddisfare 
esigenze abitative di natura transitoria e voluttuaria,
</P>
<P ALIGN="JUSTIFY"></P>
<P ALIGN="CENTER">
SI CONVIENE
</P>
<P ALIGN="JUSTIFY"></P>
<P ALIGN="JUSTIFY">
1) Il signor Pinco Pallino concede in locazione [al] signor[e] [nome] [cognome] ed 
alla sua famiglia composta da [num_persone_tot] persone un appartamento del Parco 
hoteldruid per l'uso esclusivo di abitazione.
</P>
<P ALIGN="JUSTIFY"></P>
<P ALIGN="JUSTIFY">
2) La locazione avrà la durata dal [data_inizio] al [data_fine]. Il conduttore 
è obbligato a tenere la cosa locata in perfetto 
stato e a non occupare l'appartamento con un numero di persone superiore a 
quello indicato al punto 1). L'occupazione dell'appartamento da parte di 
un numero di persone superiore a [num_persone_tot]  
comporta il pagamento, per il periodo della permanenza, di una penale di Euro 50 
al giorno ed a persona. La violazione della temporaneità, 
saltuarietà e transitorietà della locazione comporta la risoluzione di 
diritto del contratto.
</P>
<P ALIGN="JUSTIFY"></P>
<P ALIGN="JUSTIFY">
3) Sono a carico del conduttore le spese riguardanti le utenze luce, acqua e gas. 
Tali spese sono calcolate nella somma forfettaria di Euro 15 a settimana 
(esempio di costo aggiuntivo finale).
</P>
<P ALIGN="JUSTIFY"></P>
<P ALIGN="JUSTIFY">
4) Il prezzo della locazione per il periodo di cui al punto 2) e delle spese per le 
utenze acqua, luce e gas di cui al punto 3) è stabilito in lire 
[costo_tot_p].
</P>
<P ALIGN="JUSTIFY">
Il conduttore versa al locatore, al momento della prenotazione, quale caparra 
confirmatoria, il 30%, pari a Euro <b>[caparra_p]</b>, del prezzo della locazione
 mentre il rimanente 70%, pari a Euro <b>[resto_caparra_p]</b>, sarà 
versato al locatore, in unica soluzione anticipata, prima di prendere possesso 
dell'appartamento.
</P><P ALIGN="JUSTIFY"></P><P ALIGN="JUSTIFY">
Vattelapesca, lì [oggi].
</P><P ALIGN="JUSTIFY"></P><P ALIGN="JUSTIFY">
Versato caparra di Euro [caparra]
</P><P ALIGN="JUSTIFY"></P>
<P ALIGN="JUSTIFY">Il 
locatore&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Il 
conduttore</P>
<P ALIGN="JUSTIFY"></P>
<P ALIGN="JUSTIFY"> 
__________&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;____________</P>
</FONT></cmp></riga>
<riga><cmp>2</cmp><cmp>contrhtm</cmp><cmp><div class="riquadro_fattura" style="width: 780px; margin: 10px; border: solid 1px black; padding: 30px; font-size: 12px; page-break-after: always">
[r][r3][/r3] [/r]

<div class="dati_struttura">
[logo_fatt]
<div class="nome_struttura" style="font-size: large;">[tipo_struttura] [nome_struttura]</div>
[ragione_sociale_struttura]<br>
[indirizzo_struttura] - [comune_struttura]<br>
[CAP_struttura] [nazione_struttura]<br>
Partita IVA [partita_iva_struttura] [cod_fisc_strutt_fatt]<br>
[telefono_strutt_fatt]<br>
</div>

<div class="dati_cliente" style="padding: 18px 0 8px 440px;">
Spett.le [nome_fatt] [cognome_fatt]<br>
[c via_fatt!=""][via_fatt][numcivico_fatt]<br>
[/c][c riga_citta_fatt!=""][riga_citta_fatt]<br>
[/c][c riga_stato_fatt!=""][riga_stato_fatt]<br>
[/c][c codice_fiscale_fatt!=""]Codice fiscale [codice_fiscale_fatt]<br>
[/c][c partita_iva_fatt!=""]Partita IVA [partita_iva_fatt]<br>
[/c]
</div>

<hr style="width: 100%; border: 1px solid black;">

<div class="numero_fattura" style="padding: 24px 0 8px 0">
Fattura n. [numero_progressivo_documento] del [oggi]
</div>


[r4 array="iva_perc_vett_fatt"]
<table class="voci_fattura" border="1" cellpadding="5" style="border: 1px black solid; width: 740px; margin-left: auto; margin-right: 5px; margin-top: 8px; border-collapse: collapse; background-color: #e6e6e6;">
[r]
[c mos_tariffa_fatt="1"]<tr><td style="border-color: black;">Pernottamento dal [data_inizio] al [data_fine][frase_persone_fatt]</td>
<td style="width: 120px; text-align: right; border-color: black;">[nome_valuta] [tariffa_no_iva_fatt_p]</td></tr>
[/c][c mos_sconto_fatt="1"]<tr><td style="border-color: black;">Sconto</td>
<td style="width: 120px; text-align: right; border-color: black;">[nome_valuta] [sconto_no_iva_fatt_p]</td></tr>
[/c]
[r3][c mos_costo_agg_fatt="1"]<tr><td style="border-color: black;">Extra: "[nome_costo_agg]"</td>
<td style="width: 120px; text-align: right; border-color: black;">[nome_valuta] [costo_agg_no_iva_fatt_p]</td></tr>
[/c][c mos_costo_come_tasse_fatt="1"]<tr><td style="border-color: black;">Tassa: "[nome_costo_agg]"</td>
<td style="width: 120px; text-align: right; border-color: black;">[nome_valuta] [tasse_costo_agg_p]</td></tr>
[/c][/r3][/r]
[c iva_perc_vett_fatt(num_iva_fatt)="-1"]<!--[/c]
[c mos_subtotale_fatt="1"]<tr><td style="border-color: black;">Imponibile al [iva_perc_vett_fatt(num_iva_fatt)]%</td>
<td style="width: 120px; text-align: right; border-color: black;">[nome_valuta] [tot_parz_no_iva_fatt_p]</td></tr>
<tr><td style="border-color: black;">Iva al [iva_perc_vett_fatt(num_iva_fatt)]%</td>
<td style="width: 120px; text-align: right; border-color: black;">[nome_valuta] [tot_parz_iva_fatt_p]</td></tr>
[/c]
[c iva_perc_vett_fatt(num_iva_fatt)="-1"]-->[/c]
</table>
[/r4]

<table class="imponibile_fattura" border="1" cellpadding="5" style="border: 1px black solid; width: 740px; margin-left: auto; margin-right: 5px; margin-top: 8px; border-collapse: collapse; background-color: #e6e6e6;">
<tr><td style="border-color: black;">Totale Imponibile</td>
<td style="width: 120px; text-align: right; border-color: black;">[nome_valuta] [tot_no_iva_fatt_p]</td></tr>
<tr><td style="border-color: black;">Totale Imposte[c num_iva_fatt="1"] al [iva_perc_vett_fatt(num_iva_fatt)]%[/c]</td>
<td style="width: 120px; text-align: right; border-color: black;">[nome_valuta] [iva_fatt_p]</td></tr>
[r][r3][c mos_costo_tassa_fatt="1"]
<tr><td style="border-color: black;">[nome_costo_agg]</td>
<td style="width: 120px; text-align: right; border-color: black;">[nome_valuta] [costo_agg_no_iva_fatt_p]</td></tr>
[/c][/r3][/r]
</table>


<table class="totale_fattura" border="1" cellpadding="5" style="border: 1px black solid; width: 740px; margin-left: auto; margin-right: 5px; margin-top: 8px; border-collapse: collapse; background-color: #cccccc;">
<tr><td style="border-color: black;">Totale Fattura</td>
<td style="width: 120px; text-align: right; border-color: black;">[nome_valuta] [costo_tot_fatt_p]</td></tr>
</table>


<br>
<hr style="width: 100%; border: 1px solid black;">
<br>


</div></cmp></riga>
<riga><cmp>5</cmp><cmp>contrhtm</cmp><cmp><div class="riquadro_fattura" style="width: 780px; margin: 10px; border: solid 1px black; padding: 30px; font-size: 12px; page-break-after: always">

<div class="dati_struttura">
[logo_ricev]
<div class="nome_struttura" style="font-size: large;">[tipo_struttura] [nome_struttura]</div>
[ragione_sociale_struttura]<br>
[indirizzo_struttura] - [comune_struttura]<br>
[CAP_struttura] [nazione_struttura]<br>
Partita IVA [partita_iva_struttura] [cod_fisc_strutt_ricev]<br>
[telefono_strutt_ricev]<br>
</div>

<div class="dati_cliente" style="padding: 18px 0 8px 440px;">
Spett.le [nome_ricev] [cognome_ricev]<br>
[c via_ricev!=""][via_ricev][numcivico_ricev]<br>
[/c][c riga_citta_ricev!=""][riga_citta_ricev]<br>
[/c][c riga_stato_ricev!=""][riga_stato_ricev]<br>
[/c][c codice_fiscale!=""]Codice fiscale [codice_fiscale]<br>
[/c][c partita_iva!=""]Partita IVA [partita_iva]<br>
[/c]
</div>

<hr style="width: 100%; border: 1px solid black;">

<div class="numero_fattura" style="padding: 24px 0 8px 0">
Ricevuta[c numero_progressivo_documento!=""] n. [numero_progressivo_documento][/c] del [oggi]
</div>


<table class="voci_fattura" border="1" cellpadding="5" style="border: 1px black solid; width: 740px; margin-left: auto; margin-right: 5px; margin-top: 8px; border-collapse: collapse; background-color: #e6e6e6;">
<tr><td style="border-color: black;">[c data_inizio!=""]Prenotazione dal [data_inizio] al [data_fine][/c][c num_persone_tot!=""] per [num_persone_tot] persone[/c][c data_inizio=""][metodo_ultimo_pagamento][/c]</td>
<td style="width: 120px; text-align: right; border-color: black;">[c mostra_metodo_ricev="1"][nome_valuta] [valore_ultimo_pagamento_p][/c]</td></tr>
</table>

<table class="totale_fattura" border="1" cellpadding="5" style="border: 1px black solid; width: 740px; margin-left: auto; margin-right: 5px; margin-top: 8px; border-collapse: collapse; background-color: #cccccc;">
<tr><td style="border-color: black;">Totale Pagamento</td>
<td style="width: 120px; text-align: right; border-color: black;">[nome_valuta] [valore_ultimo_pagamento_p]</td></tr>
</table>


<br>
<hr style="width: 100%; border: 1px solid black;">
<br>


</div></cmp></riga>
<riga><cmp>11</cmp><cmp>contrhtm</cmp><cmp>[r][valore_nullo][r3][valore_nullo][/r3][/r][r4 array="costi_aggiuntivi_pulizie"][valore_nullo][/r4][r4 array="array_date_pulizie"][r][r3][valore_nullo][/r3][/r][/r4]
<h1>Riepilogo pulizie del <em>[f_data_riepilogo_pulizie]</em></h1>
<table class="clrep">
<tr class="headrow"><td>Camera</td><td>Persone</td><td>Situazione</td><td><small><small>Persone in<br>partenza</small></small></td><td><small><small>Orario di<br>arrivo</small></small></td>[intestazione_ca_tabella_pulizie]</tr>
[r6]
<tr[classe_riga_pulizie]><td>[unita_pulizie]</td><td>[persone_pulizie(unita_pulizie)]</td><td>[situazione_pulizie(unita_pulizie)]</td><td>[persone_part_pulizie(unita_pulizie)]</td><td>[orario_arrivo_pulizie(unita_pulizie)]</td>[riga_unita_ca_pulizie(unita_pulizie)]</tr>
[ripetizione_riga_intestazione_pulizie]
[/r6]
<tr class="headrow"><td>Totale</td><td>[tot_persone_pulizie]</td><td><small>([tot_persone_arr_pulizie] arrivi)</small></td><td>[tot_persone_part_pulizie]</td><td></td>
[r4 array="totale_ca_pulizie"]
<td>[totale_ca_pulizie(num_ca_pulizie)]</td>
[/r4]</tr>
</table></cmp></riga>
<riga><cmp>22</cmp><cmp>contrhtm</cmp><cmp>[r4 array="date_isa"][r][valore_nullo][/r][/r4]<div style="text-align: center;">
<h2>Dati per gli Indici Sintetici di Affidabilità Fiscale (ISA)</h2>
Periodo dal <b>[data_inizio_selezione]</b> al <b>[data_fine_selezione]</b></div>
<br><br>
Presenze totali nel periodo: [presenze_isa]<br>
</cmp></riga>
<riga><cmp>23</cmp><cmp>contrhtm</cmp><cmp></cmp></riga>
<riga><cmp>24</cmp><cmp>contrhtm</cmp><cmp></cmp></riga>
<riga><cmp>25</cmp><cmp>contrhtm</cmp><cmp></cmp></riga>
<riga><cmp>8</cmp><cmp>contreml</cmp><cmp>#!mln!#ita</cmp></riga>
<riga><cmp>9</cmp><cmp>contreml</cmp><cmp>#!mln!#ita</cmp></riga>
<riga><cmp>10</cmp><cmp>contreml</cmp><cmp>#!mln!#ita</cmp></riga>
<riga><cmp>1</cmp><cmp>cond9</cmp><cmp>rpt#@?#@?set#%?38#%?=#%?var#%?cognome#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>2</cmp><cmp>cond9</cmp><cmp>rpt#@?#@?set#%?39#%?=#%?var#%?cognome#%?txt#%? #%?txt#%?#%?</cmp></riga>
<riga><cmp>3</cmp><cmp>cond9</cmp><cmp>rpt#@?#@?trunc#%?39#%?6#%?#%?ini</cmp></riga>
<riga><cmp>4</cmp><cmp>cond9</cmp><cmp>rpt#@?#@?set#%?39#%?=#%?var#%?cogn_no_sp_ec#%?txt#%?#%?txt#%?#%?url</cmp></riga>
<riga><cmp>1</cmp><cmp>cond8</cmp><cmp>rpt#@?#@?set#%?19#%?=#%?var#%?cognome#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>25</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?419#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>26</cmp><cmp>cond7</cmp><cmp>rpt#@?and#$?iva_perc_vett_rfel(num_iva_rfel)#%?=#%?var#%?percentuale_tasse_tariffa#$?num_ripetizione_rfel#%?>#%?txt#%?1#@?set#%?419#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>27</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?420#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>30</cmp><cmp>cond7</cmp><cmp>rpt#@?and#$?mos_tariffa_rfel#%?=#%?txt#%?1#$?sconto#%?!=#%?txt#%?0#@?set#%?420#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>31</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?421#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>36</cmp><cmp>cond7</cmp><cmp>ind#@?#@?set#%?432#%?=#%?txt#%?N4#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>40</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?428#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>42</cmp><cmp>cond7</cmp><cmp>rpt#@?#$?nome_costo_agg#%?=#%?var#%?nome_costo_tassa_rfel#@?set#%?428#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>43</cmp><cmp>cond7</cmp><cmp>rpt#@?and#$?iva_perc_vett_rfel(num_iva_rfel)#%?=#%?var#%?percentuale_tasse_costo_agg#$?valore_costo_agg#%?!=#%?txt#%?0#$?num_ripetizione_rfel#%?>#%?txt#%?1#$?mos_costo_tassa_rfel#%?!=#%?txt#%?1#@?set#%?421#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>44</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?407#%?=#%?var#%?percentuale_tasse_tariffa#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>46</cmp><cmp>cond7</cmp><cmp>rpt#@?#$?var_tmp_rfel#%?=#%?txt#%?#@?set#%?407#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>48</cmp><cmp>cond7</cmp><cmp>rpt#@?#$?iva_perc_esist_rfel(var_tmp_rfel)#%?=#%?txt#%?1#@?break#%?cont</cmp></riga>
<riga><cmp>52</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?oper#%?418#%?num_iva_rfel#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>60</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?425#%?=#%?var#%?num_iva_rfel#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>61</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?a18675#%?=#%?var#%?var_tmp_rfel#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>65</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?oper#%?a18678#%?var_tmp_rfel#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>75</cmp><cmp>cond7</cmp><cmp>rpt#@?#$?var_tmp_rfel#%?=#%?txt#%?0#@?set#%?a18677#%?=#%?txt#%?<Natura>NN</Natura>#%?txt#%?NN#%?var#%?codice_natura_rfel#%?</cmp></riga>
<riga><cmp>76</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?a18676#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>81</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?cont</cmp></riga>
<riga><cmp>83</cmp><cmp>cond7</cmp><cmp>rpt#@?or#$?valore_costo_agg#%?=#%?txt#%?0#$?valore_costo_agg#%?=#%?txt#%?#$?mos_costo_tassa_rfel#%?=#%?txt#%?1#@?break#%?cont</cmp></riga>
<riga><cmp>84</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?407#%?=#%?var#%?percentuale_tasse_costo_agg#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>86</cmp><cmp>cond7</cmp><cmp>rpt#@?#$?var_tmp_rfel#%?=#%?txt#%?#@?set#%?407#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>87</cmp><cmp>cond7</cmp><cmp>rpt#@?#$?iva_perc_esist_rfel(var_tmp_rfel)#%?=#%?txt#%?1#@?break#%?cont</cmp></riga>
<riga><cmp>88</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?oper#%?418#%?num_iva_rfel#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>89</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?425#%?=#%?var#%?num_iva_rfel#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>90</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?a18675#%?=#%?var#%?var_tmp_rfel#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>91</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?oper#%?a18678#%?var_tmp_rfel#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>95</cmp><cmp>cond7</cmp><cmp>rpt#@?#$?var_tmp_rfel#%?=#%?txt#%?0#@?set#%?a18677#%?=#%?txt#%?<Natura>NN</Natura>#%?txt#%?NN#%?var#%?codice_natura_rfel#%?</cmp></riga>
<riga><cmp>100</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?a18676#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>103</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?cont</cmp></riga>
<riga><cmp>105</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?oper#%?416#%?valore_costo_agg_senza_tasse#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>106</cmp><cmp>cond7</cmp><cmp>rpt#@?#$?mos_costo_tassa_rfel#%?=#%?txt#%?1#@?oper#%?416#%?valore_costo_agg#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>108</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?oper#%?434#%?costo_agg_no_iva_rfel#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>110</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?434#%?=#%?var#%?costo_agg_no_iva_rfel_p#%?txt#%?,#%?txt#%?#%?</cmp></riga>
<riga><cmp>111</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?410#%?=#%?var#%?nome_costo_agg#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>112</cmp><cmp>cond7</cmp><cmp>rpt#@?#$?mos_costo_agg_rfel#%?=#%?txt#%?1#@?oper#%?411#%?tot_no_iva_rfel#%?+#%?var#%?valore_costo_agg_senza_tasse#%?</cmp></riga>
<riga><cmp>113</cmp><cmp>cond7</cmp><cmp>rpt#@?#$?mos_costo_agg_rfel#%?=#%?txt#%?1#@?oper#%?423#%?tot_parz_no_iva_rfel#%?+#%?var#%?valore_costo_agg_senza_tasse#%?</cmp></riga>
<riga><cmp>114</cmp><cmp>cond7</cmp><cmp>rpt#@?#$?mos_costo_agg_rfel#%?=#%?txt#%?1#@?oper#%?424#%?tot_parz_iva_rfel#%?+#%?var#%?tasse_costo_agg#%?</cmp></riga>
<riga><cmp>116</cmp><cmp>cond7</cmp><cmp>rpt#@?#$?mos_costo_tassa_rfel#%?=#%?txt#%?1#@?oper#%?429#%?tot_costi_tassa_rfel#%?+#%?var#%?valore_costo_agg#%?</cmp></riga>
<riga><cmp>117</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?oper#%?415#%?tot_no_iva_rfel#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>118</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?oper#%?a18680#%?tot_parz_no_iva_rfel#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>121</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?a18680#%?=#%?var#%?tot_no_iva_vett_rfel_p(num_iva_rfel)#%?txt#%?,#%?txt#%?#%?</cmp></riga>
<riga><cmp>122</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?oper#%?a18679#%?tot_parz_iva_rfel#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>123</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?a18679#%?=#%?var#%?tot_iva_vett_rfel_p(num_iva_rfel)#%?txt#%?,#%?txt#%?#%?</cmp></riga>
<riga><cmp>124</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?oper#%?430#%?costo_tot_rfel#%?-#%?var#%?tot_no_iva_rfel#%?</cmp></riga>
<riga><cmp>125</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?oper#%?430#%?iva_rfel#%?-#%?var#%?tot_costi_tassa_rfel#%?</cmp></riga>
<riga><cmp>126</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?oper#%?414#%?iva_rfel#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>128</cmp><cmp>cond7</cmp><cmp>rpt#@?or#$?mos_costo_agg_rfel#%?!=#%?txt#%?1#$?percentuale_tasse_costo_agg#%?!=#%?txt#%?-1#@?break#%?cont</cmp></riga>
<riga><cmp>130</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?421#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>131</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?cont</cmp></riga>
<riga><cmp>133</cmp><cmp>cond7</cmp><cmp>rpt#@?#$?ultima_prenota_rfel#%?=#%?var#%?numero_prenotazione#@?break#%?</cmp></riga>
<riga><cmp>134</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?409#%?=#%?var#%?numero_prenotazione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>135</cmp><cmp>cond7</cmp><cmp>rpt#@?#$?mos_tariffa_rfel#%?=#%?txt#%?1#@?oper#%?411#%?tot_no_iva_rfel#%?+#%?var#%?costo_tariffa_senza_tasse#%?</cmp></riga>
<riga><cmp>136</cmp><cmp>cond7</cmp><cmp>rpt#@?#$?mos_tariffa_rfel#%?=#%?txt#%?1#@?oper#%?423#%?tot_parz_no_iva_rfel#%?+#%?var#%?costo_tariffa_senza_tasse#%?</cmp></riga>
<riga><cmp>137</cmp><cmp>cond7</cmp><cmp>rpt#@?#$?mos_tariffa_rfel#%?=#%?txt#%?1#@?oper#%?424#%?tot_parz_iva_rfel#%?+#%?var#%?tasse_tariffa#%?</cmp></riga>
<riga><cmp>139</cmp><cmp>cond7</cmp><cmp>rpt#@?#$?mos_sconto_rfel#%?=#%?txt#%?1#@?oper#%?411#%?tot_no_iva_rfel#%?-#%?var#%?sconto_senza_tasse#%?</cmp></riga>
<riga><cmp>140</cmp><cmp>cond7</cmp><cmp>rpt#@?#$?mos_sconto_rfel#%?=#%?txt#%?1#@?oper#%?423#%?tot_parz_no_iva_rfel#%?-#%?var#%?sconto_senza_tasse#%?</cmp></riga>
<riga><cmp>141</cmp><cmp>cond7</cmp><cmp>rpt#@?#$?mos_sconto_rfel#%?=#%?txt#%?1#@?oper#%?424#%?tot_parz_iva_rfel#%?-#%?var#%?tasse_sconto#%?</cmp></riga>
<riga><cmp>142</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?oper#%?408#%?costo_tariffa_senza_tasse#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>143</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?oper#%?417#%?sconto_senza_tasse#%?*#%?txt#%?-1#%?</cmp></riga>
<riga><cmp>146</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?oper#%?415#%?tot_no_iva_rfel#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>147</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?oper#%?a18680#%?tot_parz_no_iva_rfel#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>148</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?a18680#%?=#%?var#%?tot_no_iva_vett_rfel_p(num_iva_rfel)#%?txt#%?,#%?txt#%?#%?</cmp></riga>
<riga><cmp>149</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?oper#%?a18679#%?tot_parz_iva_rfel#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>150</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?a18679#%?=#%?var#%?tot_iva_vett_rfel_p(num_iva_rfel)#%?txt#%?,#%?txt#%?#%?</cmp></riga>
<riga><cmp>151</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?oper#%?430#%?costo_tot_rfel#%?-#%?var#%?tot_no_iva_rfel#%?</cmp></riga>
<riga><cmp>152</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?oper#%?430#%?iva_rfel#%?-#%?var#%?tot_costi_tassa_rfel#%?</cmp></riga>
<riga><cmp>153</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?oper#%?414#%?iva_rfel#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>154</cmp><cmp>cond7</cmp><cmp>rpt#@?#$?accorpa_sconto_e_tariffa_rfel#%?=#%?txt#%?SI#@?oper#%?408#%?costo_tariffa_senza_tasse#%?-#%?var#%?sconto_senza_tasse#%?</cmp></riga>
<riga><cmp>155</cmp><cmp>cond7</cmp><cmp>rpt#@?#$?accorpa_sconto_e_tariffa_rfel#%?=#%?txt#%?SI#@?set#%?420#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>156</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?oper#%?433#%?tariffa_no_iva_rfel#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>157</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?433#%?=#%?var#%?tariffa_no_iva_rfel_p#%?txt#%?,#%?txt#%?#%?</cmp></riga>
<riga><cmp>160</cmp><cmp>cond7</cmp><cmp>rpt#@?#$?num_ripetizione_rfel#%?>#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>161</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?oper#%?412#%?costo_tot_rfel#%?+#%?var#%?costo_tot#%?</cmp></riga>
<riga><cmp>162</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?oper#%?413#%?costo_tot_rfel#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>163</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?413#%?=#%?var#%?costo_tot_rfel_p#%?txt#%?,#%?txt#%?#%?</cmp></riga>
<riga><cmp>165</cmp><cmp>cond7</cmp><cmp>rpt#@?#$?codice_fiscale_struttura#%?!=#%?txt#%?#@?set#%?406#%?.=#%?var#%?codice_fiscale_struttura#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>166</cmp><cmp>cond7</cmp><cmp>rpt#@?#$?cod_fisc_strutt_rfel#%?=#%?txt#%?#@?set#%?406#%?=#%?var#%?partita_iva_struttura#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>169</cmp><cmp>cond7</cmp><cmp>inr#@?#@?set#%?409#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>170</cmp><cmp>cond7</cmp><cmp>inr#@?#@?oper#%?422#%?num_ripetizione_rfel#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>171</cmp><cmp>cond7</cmp><cmp>ind#@?#@?set#%?426#%?=#%?txt#%?SI#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>172</cmp><cmp>cond7</cmp><cmp>ind#@?#@?set#%?427#%?=#%?txt#%?nome del costo da considerare come tassa#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>173</cmp><cmp>cond7</cmp><cmp>ind#@?#@?set#%?412#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>176</cmp><cmp>cond7</cmp><cmp>ind#@?#@?set#%?411#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>198</cmp><cmp>cond7</cmp><cmp>rpt#@?#@?set#%?435#%?=#%?var#%?email_certificata#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>200</cmp><cmp>cond7</cmp><cmp>ind#@?#@?set#%?418#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>201</cmp><cmp>cond7</cmp><cmp>ind#@?#@?set#%?422#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>202</cmp><cmp>cond7</cmp><cmp>inr#@?#@?set#%?423#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>203</cmp><cmp>cond7</cmp><cmp>inr#@?#@?set#%?424#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>204</cmp><cmp>cond7</cmp><cmp>inr#@?#@?set#%?429#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>215</cmp><cmp>cond7</cmp><cmp>rpt#@?#$?partita_iva_struttura#%?=#%?txt#%?#@?set#%?-1#%?.=#%?txt#%?Si deve inserire la partita iva della struttura in "configura e personalizza".<br>#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>219</cmp><cmp>cond7</cmp><cmp>ind#@?#@?date#%?431#%?oggi#%?is#%?0#%?g</cmp></riga>
<riga><cmp>242</cmp><cmp>cond7</cmp><cmp>ind#@?#@?cont</cmp></riga>
<riga><cmp>87</cmp><cmp>cond5</cmp><cmp>rpt#@?#$?codice_fiscale_struttura#%?!=#%?txt#%?#@?set#%?14#%?=#%?txt#%?- Codice Fiscale  #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>88</cmp><cmp>cond5</cmp><cmp>rpt#@?#$?codice_fiscale_struttura#%?!=#%?txt#%?#@?set#%?14#%?.=#%?var#%?codice_fiscale_struttura#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>89</cmp><cmp>cond5</cmp><cmp>rpt#@?#@?set#%?17#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>92</cmp><cmp>cond5</cmp><cmp>rpt#@?#$?telefono_struttura#%?!=#%?txt#%?#@?set#%?17#%?=#%?txt#%?Tel. #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>94</cmp><cmp>cond5</cmp><cmp>rpt#@?#$?telefono_struttura#%?!=#%?txt#%?#@?set#%?17#%?.=#%?var#%?telefono_struttura#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>97</cmp><cmp>cond5</cmp><cmp>rpt#@?and#$?telefono_struttura#%?!=#%?txt#%?#$?sito_web_struttura#%?!=#%?txt#%?#@?set#%?17#%?.=#%?txt#%? - #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>98</cmp><cmp>cond5</cmp><cmp>rpt#@?#$?sito_web_struttura#%?!=#%?txt#%?#@?set#%?17#%?.=#%?var#%?sito_web_struttura#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>99</cmp><cmp>cond5</cmp><cmp>rpt#@?#@?set#%?15#%?=#%?var#%?nome#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>100</cmp><cmp>cond5</cmp><cmp>rpt#@?#@?set#%?16#%?=#%?var#%?cognome#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>101</cmp><cmp>cond5</cmp><cmp>rpt#@?#@?set#%?18#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>102</cmp><cmp>cond5</cmp><cmp>rpt#@?#$?numcivico#%?!=#%?txt#%?#@?set#%?18#%?=#%?txt#%?, #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>103</cmp><cmp>cond5</cmp><cmp>rpt#@?#$?numcivico#%?!=#%?txt#%?#@?set#%?18#%?.=#%?var#%?numcivico#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>104</cmp><cmp>cond5</cmp><cmp>rpt#@?#@?set#%?12#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>105</cmp><cmp>cond5</cmp><cmp>rpt#@?#$?citta#%?!=#%?txt#%?#@?set#%?12#%?.=#%?var#%?citta#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>107</cmp><cmp>cond5</cmp><cmp>rpt#@?#$?regione#%?!=#%?txt#%?#@?set#%?12#%?.=#%?txt#%? (#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>108</cmp><cmp>cond5</cmp><cmp>rpt#@?#$?regione#%?!=#%?txt#%?#@?set#%?12#%?.=#%?var#%?regione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>109</cmp><cmp>cond5</cmp><cmp>rpt#@?#$?regione#%?!=#%?txt#%?#@?set#%?12#%?.=#%?txt#%?)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>110</cmp><cmp>cond5</cmp><cmp>rpt#@?#@?set#%?13#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>111</cmp><cmp>cond5</cmp><cmp>rpt#@?#$?cap#%?!=#%?txt#%?#@?set#%?13#%?.=#%?var#%?cap#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>112</cmp><cmp>cond5</cmp><cmp>rpt#@?and#$?cap#%?!=#%?txt#%?#$?nazione#%?!=#%?txt#%?#@?set#%?13#%?.=#%?txt#%? #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>113</cmp><cmp>cond5</cmp><cmp>rpt#@?#$?nazione#%?!=#%?txt#%?#@?set#%?13#%?.=#%?var#%?nazione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>114</cmp><cmp>cond5</cmp><cmp>rpt#@?#@?set#%?152#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>115</cmp><cmp>cond5</cmp><cmp>rpt#@?and#$?data_inizio#%?=#%?txt#%?#$?metodo_ultimo_pagamento#%?!=#%?txt#%?#@?set#%?152#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>116</cmp><cmp>cond5</cmp><cmp>rpt#@?#$?logo_struttura#%?!=#%?txt#%?#@?set#%?351#%?=#%?txt#%?<img src="#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>117</cmp><cmp>cond5</cmp><cmp>rpt#@?#$?logo_struttura#%?!=#%?txt#%?#@?set#%?351#%?.=#%?var#%?logo_struttura#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>118</cmp><cmp>cond5</cmp><cmp>rpt#@?#$?logo_struttura#%?!=#%?txt#%?#@?set#%?351#%?.=#%?txt#%?" alt="Logo" style="float: right;">#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>25</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?374#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>26</cmp><cmp>cond4</cmp><cmp>rpt#@?and#$?iva_perc_vett_fael(num_iva_fael)#%?=#%?var#%?percentuale_tasse_tariffa#$?num_ripetizione_fael#%?>#%?txt#%?1#@?set#%?374#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>27</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?375#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>30</cmp><cmp>cond4</cmp><cmp>rpt#@?and#$?mos_tariffa_fael#%?=#%?txt#%?1#$?sconto#%?!=#%?txt#%?0#@?set#%?375#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>31</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?376#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>32</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?387#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>36</cmp><cmp>cond4</cmp><cmp>ind#@?#@?set#%?394#%?=#%?txt#%?N4#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>39</cmp><cmp>cond4</cmp><cmp>ind#@?#@?set#%?388#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>40</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?384#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>42</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?nome_costo_agg#%?=#%?var#%?nome_costo_tassa_fael#@?set#%?384#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>43</cmp><cmp>cond4</cmp><cmp>rpt#@?and#$?iva_perc_vett_fael(num_iva_fael)#%?=#%?var#%?percentuale_tasse_costo_agg#$?valore_costo_agg#%?!=#%?txt#%?0#$?num_ripetizione_fael#%?>#%?txt#%?1#$?mos_costo_tassa_fael#%?!=#%?txt#%?1#@?set#%?376#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>44</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?358#%?=#%?var#%?percentuale_tasse_tariffa#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>46</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?var_tmp_fael#%?=#%?txt#%?#@?set#%?358#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>48</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?iva_perc_esist_fael(var_tmp_fael)#%?=#%?txt#%?1#@?break#%?cont</cmp></riga>
<riga><cmp>52</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?oper#%?373#%?num_iva_fael#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>60</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?380#%?=#%?var#%?num_iva_fael#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>61</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?a9335#%?=#%?var#%?var_tmp_fael#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>65</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?oper#%?a9338#%?var_tmp_fael#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>75</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?var_tmp_fael#%?=#%?txt#%?0#@?set#%?a9337#%?=#%?txt#%?<Natura>NN</Natura>#%?txt#%?NN#%?var#%?codice_natura_fael#%?</cmp></riga>
<riga><cmp>76</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?a9336#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>81</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?cont</cmp></riga>
<riga><cmp>83</cmp><cmp>cond4</cmp><cmp>rpt#@?or#$?valore_costo_agg#%?=#%?txt#%?0#$?valore_costo_agg#%?=#%?txt#%?#$?mos_costo_tassa_fael#%?=#%?txt#%?1#@?break#%?cont</cmp></riga>
<riga><cmp>84</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?358#%?=#%?var#%?percentuale_tasse_costo_agg#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>86</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?var_tmp_fael#%?=#%?txt#%?#@?set#%?358#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>87</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?iva_perc_esist_fael(var_tmp_fael)#%?=#%?txt#%?1#@?break#%?cont</cmp></riga>
<riga><cmp>88</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?oper#%?373#%?num_iva_fael#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>89</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?380#%?=#%?var#%?num_iva_fael#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>90</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?a9335#%?=#%?var#%?var_tmp_fael#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>91</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?oper#%?a9338#%?var_tmp_fael#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>95</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?var_tmp_fael#%?=#%?txt#%?0#@?set#%?a9337#%?=#%?txt#%?<Natura>NN</Natura>#%?txt#%?NN#%?var#%?codice_natura_fael#%?</cmp></riga>
<riga><cmp>100</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?a9336#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>103</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?cont</cmp></riga>
<riga><cmp>105</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?oper#%?367#%?valore_costo_agg_senza_tasse#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>106</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?mos_costo_tassa_fael#%?=#%?txt#%?1#@?oper#%?367#%?valore_costo_agg#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>108</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?oper#%?396#%?costo_agg_no_iva_fael#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>110</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?396#%?=#%?var#%?costo_agg_no_iva_fael_p#%?txt#%?,#%?txt#%?#%?</cmp></riga>
<riga><cmp>111</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?361#%?=#%?var#%?nome_costo_agg#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>112</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?mos_costo_agg_fael#%?=#%?txt#%?1#@?oper#%?362#%?tot_no_iva_fael#%?+#%?var#%?valore_costo_agg_senza_tasse#%?</cmp></riga>
<riga><cmp>113</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?mos_costo_agg_fael#%?=#%?txt#%?1#@?oper#%?378#%?tot_parz_no_iva_fael#%?+#%?var#%?valore_costo_agg_senza_tasse#%?</cmp></riga>
<riga><cmp>114</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?mos_costo_agg_fael#%?=#%?txt#%?1#@?oper#%?379#%?tot_parz_iva_fael#%?+#%?var#%?tasse_costo_agg#%?</cmp></riga>
<riga><cmp>115</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?mos_costo_agg_fael#%?=#%?txt#%?1#@?oper#%?393#%?num_linea_fael#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>116</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?mos_costo_tassa_fael#%?=#%?txt#%?1#@?oper#%?385#%?tot_costi_tassa_fael#%?+#%?var#%?valore_costo_agg#%?</cmp></riga>
<riga><cmp>117</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?oper#%?366#%?tot_no_iva_fael#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>118</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?oper#%?a9340#%?tot_parz_no_iva_fael#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>121</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?a9340#%?=#%?var#%?tot_no_iva_vett_fael_p(num_iva_fael)#%?txt#%?,#%?txt#%?#%?</cmp></riga>
<riga><cmp>122</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?oper#%?a9339#%?tot_parz_iva_fael#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>123</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?a9339#%?=#%?var#%?tot_iva_vett_fael_p(num_iva_fael)#%?txt#%?,#%?txt#%?#%?</cmp></riga>
<riga><cmp>124</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?oper#%?386#%?costo_tot_fael#%?-#%?var#%?tot_no_iva_fael#%?</cmp></riga>
<riga><cmp>125</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?oper#%?386#%?iva_fael#%?-#%?var#%?tot_costi_tassa_fael#%?</cmp></riga>
<riga><cmp>126</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?oper#%?365#%?iva_fael#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>128</cmp><cmp>cond4</cmp><cmp>rpt#@?or#$?mos_costo_agg_fael#%?!=#%?txt#%?1#$?percentuale_tasse_costo_agg#%?!=#%?txt#%?-1#@?break#%?cont</cmp></riga>
<riga><cmp>129</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?387#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>130</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?376#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>131</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?cont</cmp></riga>
<riga><cmp>132</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?max_num_iva_fael#%?>#%?txt#%?1#@?set#%?388#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>133</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?ultima_prenota_fael#%?=#%?var#%?numero_prenotazione#@?break#%?</cmp></riga>
<riga><cmp>134</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?360#%?=#%?var#%?numero_prenotazione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>135</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?mos_tariffa_fael#%?=#%?txt#%?1#@?oper#%?362#%?tot_no_iva_fael#%?+#%?var#%?costo_tariffa_senza_tasse#%?</cmp></riga>
<riga><cmp>136</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?mos_tariffa_fael#%?=#%?txt#%?1#@?oper#%?378#%?tot_parz_no_iva_fael#%?+#%?var#%?costo_tariffa_senza_tasse#%?</cmp></riga>
<riga><cmp>137</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?mos_tariffa_fael#%?=#%?txt#%?1#@?oper#%?379#%?tot_parz_iva_fael#%?+#%?var#%?tasse_tariffa#%?</cmp></riga>
<riga><cmp>138</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?mos_tariffa_fael#%?=#%?txt#%?1#@?oper#%?393#%?num_linea_fael#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>139</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?mos_sconto_fael#%?=#%?txt#%?1#@?oper#%?362#%?tot_no_iva_fael#%?-#%?var#%?sconto_senza_tasse#%?</cmp></riga>
<riga><cmp>140</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?mos_sconto_fael#%?=#%?txt#%?1#@?oper#%?378#%?tot_parz_no_iva_fael#%?-#%?var#%?sconto_senza_tasse#%?</cmp></riga>
<riga><cmp>141</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?mos_sconto_fael#%?=#%?txt#%?1#@?oper#%?379#%?tot_parz_iva_fael#%?-#%?var#%?tasse_sconto#%?</cmp></riga>
<riga><cmp>142</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?oper#%?359#%?costo_tariffa_senza_tasse#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>143</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?oper#%?368#%?sconto_senza_tasse#%?*#%?txt#%?-1#%?</cmp></riga>
<riga><cmp>146</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?oper#%?366#%?tot_no_iva_fael#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>147</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?oper#%?a9340#%?tot_parz_no_iva_fael#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>148</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?a9340#%?=#%?var#%?tot_no_iva_vett_fael_p(num_iva_fael)#%?txt#%?,#%?txt#%?#%?</cmp></riga>
<riga><cmp>149</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?oper#%?a9339#%?tot_parz_iva_fael#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>150</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?a9339#%?=#%?var#%?tot_iva_vett_fael_p(num_iva_fael)#%?txt#%?,#%?txt#%?#%?</cmp></riga>
<riga><cmp>151</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?oper#%?386#%?costo_tot_fael#%?-#%?var#%?tot_no_iva_fael#%?</cmp></riga>
<riga><cmp>152</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?oper#%?386#%?iva_fael#%?-#%?var#%?tot_costi_tassa_fael#%?</cmp></riga>
<riga><cmp>153</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?oper#%?365#%?iva_fael#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>154</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?accorpa_sconto_e_tariffa_fael#%?=#%?txt#%?SI#@?oper#%?359#%?costo_tariffa_senza_tasse#%?-#%?var#%?sconto_senza_tasse#%?</cmp></riga>
<riga><cmp>155</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?accorpa_sconto_e_tariffa_fael#%?=#%?txt#%?SI#@?set#%?375#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>156</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?oper#%?395#%?tariffa_no_iva_fael#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>157</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?395#%?=#%?var#%?tariffa_no_iva_fael_p#%?txt#%?,#%?txt#%?#%?</cmp></riga>
<riga><cmp>158</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?381#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>159</cmp><cmp>cond4</cmp><cmp>rpt#@?and#$?num_persone_tot#%?!=#%?txt#%?#$?num_persone_tot#%?!=#%?txt#%?0#@?set#%?381#%?=#%?txt#%? per x persone#%?txt#%?x#%?var#%?num_persone_tot#%?</cmp></riga>
<riga><cmp>160</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?num_ripetizione_fael#%?>#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>161</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?oper#%?363#%?costo_tot_fael#%?+#%?var#%?costo_tot#%?</cmp></riga>
<riga><cmp>162</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?oper#%?364#%?costo_tot_fael#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>163</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?364#%?=#%?var#%?costo_tot_fael_p#%?txt#%?,#%?txt#%?#%?</cmp></riga>
<riga><cmp>164</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?codice_fiscale_struttura#%?!=#%?txt#%?#@?set#%?354#%?=#%?txt#%?- Codice Fiscale  #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>165</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?codice_fiscale_struttura#%?!=#%?txt#%?#@?set#%?354#%?.=#%?var#%?codice_fiscale_struttura#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>166</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?telefono_struttura#%?!=#%?txt#%?#@?set#%?357#%?=#%?txt#%?Tel. #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>167</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?telefono_struttura#%?!=#%?txt#%?#@?set#%?357#%?.=#%?var#%?telefono_struttura#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>168</cmp><cmp>cond4</cmp><cmp>inr#@?#@?set#%?360#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>169</cmp><cmp>cond4</cmp><cmp>inr#@?#@?oper#%?377#%?num_ripetizione_fael#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>170</cmp><cmp>cond4</cmp><cmp>ind#@?#@?set#%?382#%?=#%?txt#%?SI#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>171</cmp><cmp>cond4</cmp><cmp>ind#@?#@?set#%?383#%?=#%?txt#%?nome del costo da considerare come tassa#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>172</cmp><cmp>cond4</cmp><cmp>ind#@?#@?set#%?363#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>173</cmp><cmp>cond4</cmp><cmp>rpt#@?and#$?telefono_struttura#%?!=#%?txt#%?#$?sito_web_struttura#%?!=#%?txt#%?#@?set#%?357#%?.=#%?txt#%? - #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>174</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?sito_web_struttura#%?!=#%?txt#%?#@?set#%?357#%?.=#%?var#%?sito_web_struttura#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>175</cmp><cmp>cond4</cmp><cmp>ind#@?#@?set#%?362#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>176</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?355#%?=#%?var#%?nome#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>180</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?356#%?=#%?var#%?cognome#%?txt#%?&#%?txt#%?&amp;#%?</cmp></riga>
<riga><cmp>181</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?356#%?=#%?var#%?cognome_fael#%?txt#%?<#%?txt#%?&lt;#%?</cmp></riga>
<riga><cmp>183</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?369#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>184</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?numcivico#%?!=#%?txt#%?#@?set#%?369#%?=#%?txt#%?, #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>185</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?numcivico#%?!=#%?txt#%?#@?set#%?369#%?.=#%?var#%?numcivico#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>186</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?352#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>187</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?citta#%?!=#%?txt#%?#@?set#%?352#%?.=#%?var#%?citta#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>188</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?regione#%?!=#%?txt#%?#@?set#%?352#%?.=#%?txt#%? (#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>189</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?regione#%?!=#%?txt#%?#@?set#%?352#%?.=#%?var#%?regione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>190</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?regione#%?!=#%?txt#%?#@?set#%?352#%?.=#%?txt#%?)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>191</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?353#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>192</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?cap#%?!=#%?txt#%?#@?set#%?353#%?.=#%?var#%?cap#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>193</cmp><cmp>cond4</cmp><cmp>rpt#@?and#$?cap#%?!=#%?txt#%?#$?nazione#%?!=#%?txt#%?#@?set#%?353#%?.=#%?txt#%? #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>194</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?nazione#%?!=#%?txt#%?#@?set#%?353#%?.=#%?var#%?nazione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>195</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?370#%?=#%?var#%?codice_fiscale#%?txt#%?#%?txt#%?#%?upp</cmp></riga>
<riga><cmp>196</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?371#%?=#%?var#%?partita_iva#%?txt#%?#%?txt#%?#%?upp</cmp></riga>
<riga><cmp>197</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?400#%?=#%?var#%?email_certificata#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>198</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?372#%?=#%?var#%?via#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>199</cmp><cmp>cond4</cmp><cmp>ind#@?#@?set#%?373#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>200</cmp><cmp>cond4</cmp><cmp>ind#@?#@?set#%?377#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>201</cmp><cmp>cond4</cmp><cmp>inr#@?#@?set#%?378#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>202</cmp><cmp>cond4</cmp><cmp>inr#@?#@?set#%?379#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>203</cmp><cmp>cond4</cmp><cmp>inr#@?#@?set#%?385#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>204</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?trunc#%?372#%?60#%?#%?ini</cmp></riga>
<riga><cmp>205</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?389#%?=#%?var#%?codice_nazione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>206</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?389#%?=#%?var#%?codice_nazione_fael#%?txt#%?1#%?txt#%?#%?</cmp></riga>
<riga><cmp>207</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?codice_nazione_fael#%?!=#%?var#%?codice_nazione#@?set#%?389#%?=#%?var#%?codice2_nazione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>208</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?trunc#%?389#%?2#%?#%?ini</cmp></riga>
<riga><cmp>209</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?codice_nazione_fael#%?=#%?txt#%?#@?set#%?371#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>210</cmp><cmp>cond4</cmp><cmp>rpt#@?and#$?codice_nazione_fael#%?!=#%?txt#%?IT#$?partita_iva_fael#%?=#%?txt#%?#@?set#%?371#%?=#%?var#%?codice_fiscale_fael#%?txt#%?#%?txt#%?#%?upp</cmp></riga>
<riga><cmp>211</cmp><cmp>cond4</cmp><cmp>rpt#@?and#$?codice_nazione_fael#%?!=#%?txt#%?IT#$?partita_iva_fael#%?=#%?txt#%?#@?set#%?371#%?=#%?var#%?documento#%?txt#%?#%?txt#%?#%?upp</cmp></riga>
<riga><cmp>212</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?partita_iva_fael#%?=#%?var#%?codice_fiscale_fael#@?set#%?370#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>213</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?provincia_struttura_fael#%?=#%?txt#%?#@?set#%?-1#%?.=#%?txt#%?Si deve inserire una provincia italiana esistente (o la sua sigla) in "configura e personalizza" nella sezione "dati della struttura".<br>#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>214</cmp><cmp>cond4</cmp><cmp>rpt#@?or#$?partita_iva_struttura#%?=#%?txt#%?#$?email_struttura#%?=#%?txt#%?#$?indirizzo_struttura#%?=#%?txt#%?#$?CAP_struttura#%?=#%?txt#%?#$?comune_struttura#%?=#%?txt#%?#$?ragione_sociale_struttura#%?=#%?txt#%?#@?set#%?-1#%?.=#%?txt#%?Si deve inserire la ragione sociale, l'indirizzo, il CAP, il comune, la partita iva e l'email (PEC) della struttura in "configura e personalizza".<br>#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>215</cmp><cmp>cond4</cmp><cmp>rpt#@?and#$?codice_fiscale_fael#%?=#%?txt#%?#$?partita_iva_fael#%?=#%?txt#%?#@?set#%?-1#%?.=#%?txt#%?Si deve inserire la nazione di residenza e il numero di partita iva del cliente oppure il suo codice fiscale.<br>#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>216</cmp><cmp>cond4</cmp><cmp>rpt#@?or#$?via#%?=#%?txt#%?#$?codice_nazione_fael#%?=#%?txt#%?#$?citta#%?=#%?txt#%?#$?cap#%?=#%?txt#%?#@?set#%?-1#%?.=#%?txt#%?Si deve inserire la residenza del cliente (indirizzo, CAP, città e nazione).<br>#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>217</cmp><cmp>cond4</cmp><cmp>rpt#@?and#$?codice_nazione_fael#%?=#%?txt#%?IT#$?codice_regione#%?=#%?txt#%?#@?set#%?-1#%?.=#%?txt#%?Se il cliente risiede in Italia si deve inserire anche la provincia di residenza.<br>#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>218</cmp><cmp>cond4</cmp><cmp>ind#@?#@?date#%?391#%?oggi#%?is#%?0#%?g</cmp></riga>
<riga><cmp>219</cmp><cmp>cond4</cmp><cmp>rpt#@?and#$?codice_nazione_fael#%?=#%?txt#%?IT#$?partita_iva_fael#%?!=#%?txt#%?#$?pec_fael#%?=#%?txt#%?#@?set#%?-1#%?.=#%?txt#%?Per le partite iva italiane si deve inserire l'email certificata (PEC) o il codice destinatario.<br>#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>220</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?392#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>221</cmp><cmp>cond4</cmp><cmp>rpt#@?or#$?tipo_struttura#%?!=#%?txt#%?#$?nome_struttura#%?!=#%?txt#%?#@?set#%?392#%?=#%?txt#%? presso #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>222</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?tipo_struttura#%?!=#%?txt#%?#@?set#%?392#%?.=#%?var#%?tipo_struttura#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>223</cmp><cmp>cond4</cmp><cmp>rpt#@?and#$?tipo_struttura#%?!=#%?txt#%?#$?nome_struttura#%?!=#%?txt#%?#@?set#%?392#%?.=#%?txt#%? #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>224</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?nome_struttura#%?!=#%?txt#%?#@?set#%?392#%?.=#%?var#%?nome_struttura#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>225</cmp><cmp>cond4</cmp><cmp>ind#@?or#$?email_struttura#%?!=#%?txt#%?#$?telefono_struttura#%?!=#%?txt#%?#@?set#%?397#%?=#%?txt#%?<ContattiTrasmittente>#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>226</cmp><cmp>cond4</cmp><cmp>ind#@?#$?telefono_struttura#%?!=#%?txt#%?#@?set#%?397#%?.=#%?txt#%?<Telefono>numtel</Telefono>#%?txt#%?numtel#%?var#%?telefono_struttura#%?</cmp></riga>
<riga><cmp>227</cmp><cmp>cond4</cmp><cmp>ind#@?#$?email_struttura#%?!=#%?txt#%?#@?set#%?397#%?.=#%?txt#%?<Email>indem</Email>#%?txt#%?indem#%?var#%?email_struttura#%?</cmp></riga>
<riga><cmp>228</cmp><cmp>cond4</cmp><cmp>ind#@?or#$?email_struttura#%?!=#%?txt#%?#$?telefono_struttura#%?!=#%?txt#%?#@?set#%?397#%?.=#%?txt#%?</ContattiTrasmittente>#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>229</cmp><cmp>cond4</cmp><cmp>ind#@?#@?set#%?390#%?=#%?var#%?codice_regione_struttura#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>230</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?398#%?=#%?txt#%?0000000#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>231</cmp><cmp>cond4</cmp><cmp>rpt#@?#$?codice_nazione_fael#%?!=#%?txt#%?IT#@?set#%?398#%?=#%?txt#%?XXXXXXX#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>232</cmp><cmp>cond4</cmp><cmp>rpt#@?#@?set#%?399#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>233</cmp><cmp>cond4</cmp><cmp>rpt#@?and#$?pec_fael#%?{}#%?txt#%?@#$?cod_destinatario_fael#%?=#%?txt#%?0000000#@?set#%?399#%?=#%?txt#%?<PECDestinatario>pec_fael</PECDestinatario>#%?txt#%?pec_fael#%?var#%?pec_fael#%?</cmp></riga>
<riga><cmp>234</cmp><cmp>cond4</cmp><cmp>rpt#@?and#$?linea_pecdestinatario_fael#%?=#%?txt#%?#$?cod_destinatario_fael#%?=#%?txt#%?0000000#@?set#%?398#%?=#%?var#%?pec_fael#%?txt#%?#%?txt#%?#%?upp</cmp></riga>
<riga><cmp>235</cmp><cmp>cond4</cmp><cmp>ind#@?#@?trunc#%?390#%?2#%?0#%?ini</cmp></riga>
<riga><cmp>236</cmp><cmp>cond4</cmp><cmp>ind#@?#$?provincia_struttura_fael#%?!=#%?var#%?codice_regione_struttura#@?set#%?390#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>237</cmp><cmp>cond4</cmp><cmp>ind#@?#$?provincia_struttura_fael#%?!=#%?txt#%?#@?break#%?cont</cmp></riga>
<riga><cmp>238</cmp><cmp>cond4</cmp><cmp>ind#@?#@?set#%?390#%?=#%?var#%?regione_struttura#%?txt#%?#%?txt#%?#%?upp</cmp></riga>
<riga><cmp>239</cmp><cmp>cond4</cmp><cmp>ind#@?#@?trunc#%?390#%?2#%?0#%?ini</cmp></riga>
<riga><cmp>240</cmp><cmp>cond4</cmp><cmp>ind#@?#$?provincia_struttura_fael#%?!=#%?var#%?regione_struttura#@?set#%?390#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>241</cmp><cmp>cond4</cmp><cmp>ind#@?#@?cont</cmp></riga>
<riga><cmp>1</cmp><cmp>cond22</cmp><cmp>ind#@?#@?array#%?a65485#%?dat#%?</cmp></riga>
<riga><cmp>2</cmp><cmp>cond22</cmp><cmp>ind#@?#@?set#%?489#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>4</cmp><cmp>cond22</cmp><cmp>rpt#@?#$?date_isa(data_isa)#%?!=#%?var#%?data_fine#@?oper#%?489#%?presenze_isa#%?+#%?var#%?num_persone_tot#%?</cmp></riga>
<riga><cmp>3</cmp><cmp>cond21</cmp><cmp>ind#@?#@?set#%?207#%?=#%?txt#%?00000ALB0000#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>4</cmp><cmp>cond21</cmp><cmp>ind#@?#@?set#%?203#%?=#%?var#%?data_inizio_selezione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>5</cmp><cmp>cond21</cmp><cmp>ind#@?#@?trunc#%?203#%?5#%?#%?ini</cmp></riga>
<riga><cmp>6</cmp><cmp>cond21</cmp><cmp>ind#@?#@?set#%?202#%?=#%?var#%?data_inizio_selezione#%?var#%?anno_sel_turiweb#%?txt#%?#%?</cmp></riga>
<riga><cmp>7</cmp><cmp>cond21</cmp><cmp>ind#@?#@?trunc#%?202#%?2#%?#%?ini</cmp></riga>
<riga><cmp>8</cmp><cmp>cond21</cmp><cmp>ind#@?#@?trunc#%?203#%?4#%?#%?ini</cmp></riga>
<riga><cmp>9</cmp><cmp>cond21</cmp><cmp>ind#@?#@?set#%?204#%?=#%?var#%?data_fine_selezione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>10</cmp><cmp>cond21</cmp><cmp>ind#@?#@?trunc#%?204#%?5#%?#%?ini</cmp></riga>
<riga><cmp>11</cmp><cmp>cond21</cmp><cmp>ind#@?#@?set#%?204#%?=#%?var#%?data_fine_selezione#%?var#%?var_aux_turiweb#%?txt#%?#%?</cmp></riga>
<riga><cmp>12</cmp><cmp>cond21</cmp><cmp>ind#@?#@?trunc#%?204#%?2#%?#%?ini</cmp></riga>
<riga><cmp>13</cmp><cmp>cond21</cmp><cmp>ind#@?#@?oper#%?205#%?mese_sel_turiweb#%?+#%?txt#%?2#%?</cmp></riga>
<riga><cmp>14</cmp><cmp>cond21</cmp><cmp>ind#@?or#$?mese_sel_turiweb#%?>#%?var#%?var_aux_turiweb#$?var_turiweb#%?=#%?var#%?var_aux_turiweb#@?oper#%?202#%?mese_sel_turiweb#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>15</cmp><cmp>cond21</cmp><cmp>ind#@?#$?mese_sel_turiweb#%?>#%?txt#%?12#@?oper#%?203#%?anno_sel_turiweb#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>16</cmp><cmp>cond21</cmp><cmp>ind#@?#$?mese_sel_turiweb#%?>#%?txt#%?12#@?oper#%?202#%?mese_sel_turiweb#%?-#%?txt#%?12#%?</cmp></riga>
<riga><cmp>17</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?prox_num_turiweb#%?=#%?txt#%?0#@?unset#%?a1033</cmp></riga>
<riga><cmp>18</cmp><cmp>cond21</cmp><cmp>inr#@?#@?unset#%?a1034</cmp></riga>
<riga><cmp>19</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?prox_num_turiweb#%?=#%?txt#%?0#@?unset#%?a1035</cmp></riga>
<riga><cmp>20</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?prox_num_turiweb#%?=#%?txt#%?0#@?unset#%?a1036</cmp></riga>
<riga><cmp>21</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?prox_num_turiweb#%?=#%?txt#%?0#@?unset#%?a1038</cmp></riga>
<riga><cmp>22</cmp><cmp>cond21</cmp><cmp>inr#@?#@?unset#%?a1039</cmp></riga>
<riga><cmp>23</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?prox_num_turiweb#%?=#%?txt#%?0#@?unset#%?a1040</cmp></riga>
<riga><cmp>24</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?prox_num_turiweb#%?=#%?txt#%?0#@?unset#%?a1041</cmp></riga>
<riga><cmp>25</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?oper#%?166#%?num_turiweb#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>27</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?181#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>28</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?175#%?=#%?var#%?date_turiweb(data_turiweb)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>29</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?trunc#%?175#%?5#%?#%?ini</cmp></riga>
<riga><cmp>30</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?177#%?=#%?var#%?date_turiweb(data_turiweb)#%?var#%?anno_turiweb#%?var#%?null_turiweb#%?</cmp></riga>
<riga><cmp>31</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?trunc#%?175#%?4#%?#%?ini</cmp></riga>
<riga><cmp>35</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?176#%?=#%?var#%?giorno_turiweb#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>36</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?trunc#%?176#%?3#%?#%?ini</cmp></riga>
<riga><cmp>37</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?177#%?=#%?var#%?giorno_turiweb#%?var#%?mese_turiweb#%?var#%?null_turiweb#%?</cmp></riga>
<riga><cmp>40</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?trunc#%?176#%?2#%?#%?ini</cmp></riga>
<riga><cmp>41</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?mese_sel_turiweb#%?!=#%?var#%?mese_turiweb#@?break#%?</cmp></riga>
<riga><cmp>42</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?180#%?=#%?var#%?codice_nazione_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>44</cmp><cmp>cond21</cmp><cmp>rpt#@?and#$?nazione_ospite#%?!=#%?txt#%?#$?nazione_turiweb#%?=#%?txt#%?#@?set#%?180#%?=#%?txt#%?APX#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>45</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?#@?set#%?180#%?=#%?var#%?codice_cittadinanza_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>46</cmp><cmp>cond21</cmp><cmp>rpt#@?and#$?cittadinanza_ospite#%?!=#%?txt#%?#$?nazione_turiweb#%?=#%?txt#%?#@?set#%?180#%?=#%?txt#%?APX#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>48</cmp><cmp>cond21</cmp><cmp>rpt#@?and#$?nazione_turiweb#%?=#%?txt#%?#$?numero_ospite#%?=#%?txt#%?1#@?set#%?180#%?=#%?txt#%?APX#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>49</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?!=#%?txt#%?APX#@?trunc#%?180#%?2#%?#%?ini</cmp></riga>
<riga><cmp>55</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?FR#@?set#%?180#%?=#%?txt#%?F#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>59</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?DE#@?set#%?180#%?=#%?txt#%?D#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>60</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?IE#@?set#%?180#%?=#%?txt#%?IRL#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>61</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?PT#@?set#%?180#%?=#%?txt#%?P#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>63</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?ES#@?set#%?180#%?=#%?txt#%?E#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>64</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?LU#@?set#%?180#%?=#%?txt#%?L#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>65</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?IS#@?set#%?180#%?=#%?txt#%?ISL#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>66</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?BE#@?set#%?180#%?=#%?txt#%?B#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>67</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?NO#@?set#%?180#%?=#%?txt#%?N#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>68</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?SV#@?set#%?180#%?=#%?txt#%?S#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>74</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?FI#@?set#%?180#%?=#%?txt#%?SF#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>77</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?AT#@?set#%?180#%?=#%?txt#%?A#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>78</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?PL#@?set#%?180#%?=#%?txt#%?PLN#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>79</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?CZ#@?set#%?180#%?=#%?txt#%?CSV#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>86</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?SK#@?set#%?180#%?=#%?txt#%?SKV#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>88</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?HU#@?set#%?180#%?=#%?txt#%?H#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>89</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?RU#@?set#%?180#%?=#%?txt#%?SU#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>90</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?SI#@?set#%?180#%?=#%?txt#%?SLO#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>92</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?HR#@?set#%?180#%?=#%?txt#%?HRV#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>93</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?EG#@?set#%?180#%?=#%?txt#%?ET#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>94</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?US#@?set#%?180#%?=#%?txt#%?USA#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>95</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?CA#@?set#%?180#%?=#%?txt#%?CDN#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>97</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?MX#@?set#%?180#%?=#%?txt#%?MEX#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>98</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?VE#@?set#%?180#%?=#%?txt#%?YV#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>99</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?AR#@?set#%?180#%?=#%?txt#%?RA#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>100</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?CN#@?set#%?180#%?=#%?txt#%?RPC#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>101</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?KR#@?set#%?180#%?=#%?txt#%?ROK#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>102</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?JP#@?set#%?180#%?=#%?txt#%?J#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>106</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?AU#@?set#%?180#%?=#%?txt#%?AUS#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>108</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?NZ#@?set#%?180#%?=#%?txt#%?NZL#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>109</cmp><cmp>cond21</cmp><cmp>rpt#@?or#$?nazione_turiweb#%?=#%?txt#%?ME#$?nazione_turiweb#%?=#%?txt#%?XK#$?nazione_turiweb#%?=#%?txt#%?MC#$?nazione_turiweb#%?=#%?txt#%?AD#$?nazione_turiweb#%?=#%?txt#%?AM#$?nazione_turiweb#%?=#%?txt#%?AZ#$?nazione_turiweb#%?=#%?txt#%?VA#$?nazione_turiweb#%?=#%?txt#%?FO#$?nazione_turiweb#%?=#%?txt#%?GE#$?nazione_turiweb#%?=#%?txt#%?GI#$?nazione_turiweb#%?=#%?txt#%?IS#$?nazione_turiweb#%?=#%?txt#%?LI#$?nazione_turiweb#%?=#%?txt#%?SK#$?nazione_turiweb#%?=#%?txt#%?SM#@?set#%?180#%?=#%?txt#%?APE#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>110</cmp><cmp>cond21</cmp><cmp>rpt#@?or#$?nazione_turiweb#%?=#%?txt#%?PM#$?nazione_turiweb#%?=#%?txt#%?BM#$?nazione_turiweb#%?=#%?txt#%?BS#$?nazione_turiweb#%?=#%?txt#%?GL#@?set#%?180#%?=#%?txt#%?AMS#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>111</cmp><cmp>cond21</cmp><cmp>rpt#@?or#$?nazione_turiweb#%?=#%?txt#%?BO#$?nazione_turiweb#%?=#%?txt#%?PE#$?nazione_turiweb#%?=#%?txt#%?CO#$?nazione_turiweb#%?=#%?txt#%?AI#$?nazione_turiweb#%?=#%?txt#%?AG#$?nazione_turiweb#%?=#%?txt#%?AN#$?nazione_turiweb#%?=#%?txt#%?BB#$?nazione_turiweb#%?=#%?txt#%?BZ#$?nazione_turiweb#%?=#%?txt#%?KY#$?nazione_turiweb#%?=#%?txt#%?CL#$?nazione_turiweb#%?=#%?txt#%?CR#$?nazione_turiweb#%?=#%?txt#%?CU#$?nazione_turiweb#%?=#%?txt#%?DM#$?nazione_turiweb#%?=#%?txt#%?EC#$?nazione_turiweb#%?=#%?txt#%?SV#$?nazione_turiweb#%?=#%?txt#%?JM#$?nazione_turiweb#%?=#%?txt#%?GD#$?nazione_turiweb#%?=#%?txt#%?GT#$?nazione_turiweb#%?=#%?txt#%?GY#$?nazione_turiweb#%?=#%?txt#%?HT#$?nazione_turiweb#%?=#%?txt#%?HN#$?nazione_turiweb#%?=#%?txt#%?VI#$?nazione_turiweb#%?=#%?txt#%?FK#$?nazione_turiweb#%?=#%?txt#%?MS#$?nazione_turiweb#%?=#%?txt#%?NI#$?nazione_turiweb#%?=#%?txt#%?PA#$?nazione_turiweb#%?=#%?txt#%?PY#$?nazione_turiweb#%?=#%?txt#%?DO#$?nazione_turiweb#%?=#%?txt#%?VC#$?nazione_turiweb#%?=#%?txt#%?KN#$?nazione_turiweb#%?=#%?txt#%?LC#$?nazione_turiweb#%?=#%?txt#%?SR#$?nazione_turiweb#%?=#%?txt#%?TC#$?nazione_turiweb#%?=#%?txt#%?VG#$?nazione_turiweb#%?=#%?txt#%?TT#$?nazione_turiweb#%?=#%?txt#%?UY#@?set#%?180#%?=#%?txt#%?APA#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>112</cmp><cmp>cond21</cmp><cmp>rpt#@?or#$?nazione_turiweb#%?=#%?txt#%?LB#$?nazione_turiweb#%?=#%?txt#%?SY#$?nazione_turiweb#%?=#%?txt#%?JO#$?nazione_turiweb#%?=#%?txt#%?SA#$?nazione_turiweb#%?=#%?txt#%?BH#$?nazione_turiweb#%?=#%?txt#%?AE#$?nazione_turiweb#%?=#%?txt#%?IR#$?nazione_turiweb#%?=#%?txt#%?IQ#$?nazione_turiweb#%?=#%?txt#%?KW#$?nazione_turiweb#%?=#%?txt#%?OM#$?nazione_turiweb#%?=#%?txt#%?PS#$?nazione_turiweb#%?=#%?txt#%?QA#$?nazione_turiweb#%?=#%?txt#%?YE#@?set#%?180#%?=#%?txt#%?AMO#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>113</cmp><cmp>cond21</cmp><cmp>rpt#@?or#$?nazione_turiweb#%?=#%?txt#%?PK#$?nazione_turiweb#%?=#%?txt#%?MM#$?nazione_turiweb#%?=#%?txt#%?BD#$?nazione_turiweb#%?=#%?txt#%?AF#$?nazione_turiweb#%?=#%?txt#%?BT#$?nazione_turiweb#%?=#%?txt#%?BN#$?nazione_turiweb#%?=#%?txt#%?KH#$?nazione_turiweb#%?=#%?txt#%?CN#$?nazione_turiweb#%?=#%?txt#%?TW#$?nazione_turiweb#%?=#%?txt#%?KP#$?nazione_turiweb#%?=#%?txt#%?PH#$?nazione_turiweb#%?=#%?txt#%?HK#$?nazione_turiweb#%?=#%?txt#%?ID#$?nazione_turiweb#%?=#%?txt#%?KZ#$?nazione_turiweb#%?=#%?txt#%?KG#$?nazione_turiweb#%?=#%?txt#%?LA#$?nazione_turiweb#%?=#%?txt#%?MO#$?nazione_turiweb#%?=#%?txt#%?MY#$?nazione_turiweb#%?=#%?txt#%?MV#$?nazione_turiweb#%?=#%?txt#%?MN#$?nazione_turiweb#%?=#%?txt#%?NP#$?nazione_turiweb#%?=#%?txt#%?SG#$?nazione_turiweb#%?=#%?txt#%?TJ#$?nazione_turiweb#%?=#%?txt#%?LK#$?nazione_turiweb#%?=#%?txt#%?UZ#$?nazione_turiweb#%?=#%?txt#%?TH#$?nazione_turiweb#%?=#%?txt#%?TM#$?nazione_turiweb#%?=#%?txt#%?TL#$?nazione_turiweb#%?=#%?txt#%?VN#@?set#%?180#%?=#%?txt#%?ASI#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>114</cmp><cmp>cond21</cmp><cmp>rpt#@?or#$?nazione_turiweb#%?=#%?txt#%?MA#$?nazione_turiweb#%?=#%?txt#%?DZ#$?nazione_turiweb#%?=#%?txt#%?TN#$?nazione_turiweb#%?=#%?txt#%?LY#@?set#%?180#%?=#%?txt#%?AFM#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>115</cmp><cmp>cond21</cmp><cmp>rpt#@?or#$?nazione_turiweb#%?=#%?txt#%?KE#$?nazione_turiweb#%?=#%?txt#%?SS#$?nazione_turiweb#%?=#%?txt#%?LR#$?nazione_turiweb#%?=#%?txt#%?AO#$?nazione_turiweb#%?=#%?txt#%?BJ#$?nazione_turiweb#%?=#%?txt#%?BW#$?nazione_turiweb#%?=#%?txt#%?BF#$?nazione_turiweb#%?=#%?txt#%?BI#$?nazione_turiweb#%?=#%?txt#%?CM#$?nazione_turiweb#%?=#%?txt#%?CV#$?nazione_turiweb#%?=#%?txt#%?CF#$?nazione_turiweb#%?=#%?txt#%?TD#$?nazione_turiweb#%?=#%?txt#%?KM#$?nazione_turiweb#%?=#%?txt#%?CG#$?nazione_turiweb#%?=#%?txt#%?CI#$?nazione_turiweb#%?=#%?txt#%?ER#$?nazione_turiweb#%?=#%?txt#%?ET#$?nazione_turiweb#%?=#%?txt#%?GA#$?nazione_turiweb#%?=#%?txt#%?GM#$?nazione_turiweb#%?=#%?txt#%?GH#$?nazione_turiweb#%?=#%?txt#%?DJ#$?nazione_turiweb#%?=#%?txt#%?GN#$?nazione_turiweb#%?=#%?txt#%?GW#$?nazione_turiweb#%?=#%?txt#%?GQ#$?nazione_turiweb#%?=#%?txt#%?LS#$?nazione_turiweb#%?=#%?txt#%?MG#$?nazione_turiweb#%?=#%?txt#%?ML#$?nazione_turiweb#%?=#%?txt#%?MW#$?nazione_turiweb#%?=#%?txt#%?MU#$?nazione_turiweb#%?=#%?txt#%?MR#$?nazione_turiweb#%?=#%?txt#%?YT#$?nazione_turiweb#%?=#%?txt#%?MZ#$?nazione_turiweb#%?=#%?txt#%?NA#$?nazione_turiweb#%?=#%?txt#%?NE#$?nazione_turiweb#%?=#%?txt#%?NG#$?nazione_turiweb#%?=#%?txt#%?CD#$?nazione_turiweb#%?=#%?txt#%?RW#$?nazione_turiweb#%?=#%?txt#%?SC#$?nazione_turiweb#%?=#%?txt#%?SN#$?nazione_turiweb#%?=#%?txt#%?ST#$?nazione_turiweb#%?=#%?txt#%?SL#$?nazione_turiweb#%?=#%?txt#%?TG#$?nazione_turiweb#%?=#%?txt#%?SD#$?nazione_turiweb#%?=#%?txt#%?SO#$?nazione_turiweb#%?=#%?txt#%?SZ#$?nazione_turiweb#%?=#%?txt#%?TZ#$?nazione_turiweb#%?=#%?txt#%?UG#$?nazione_turiweb#%?=#%?txt#%?ZM#$?nazione_turiweb#%?=#%?txt#%?ZW#$?nazione_turiweb#%?=#%?txt#%?CD#@?set#%?180#%?=#%?txt#%?AAF#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>116</cmp><cmp>cond21</cmp><cmp>rpt#@?or#$?nazione_turiweb#%?=#%?txt#%?NC#$?nazione_turiweb#%?=#%?txt#%?VU#$?nazione_turiweb#%?=#%?txt#%?FJ#$?nazione_turiweb#%?=#%?txt#%?CX#$?nazione_turiweb#%?=#%?txt#%?CC#$?nazione_turiweb#%?=#%?txt#%?GU#$?nazione_turiweb#%?=#%?txt#%?KI#$?nazione_turiweb#%?=#%?txt#%?MP#$?nazione_turiweb#%?=#%?txt#%?MH#$?nazione_turiweb#%?=#%?txt#%?FM#$?nazione_turiweb#%?=#%?txt#%?NF#$?nazione_turiweb#%?=#%?txt#%?NR#$?nazione_turiweb#%?=#%?txt#%?PG#$?nazione_turiweb#%?=#%?txt#%?PW#$?nazione_turiweb#%?=#%?txt#%?PN#$?nazione_turiweb#%?=#%?txt#%?PF#$?nazione_turiweb#%?=#%?txt#%?SB#$?nazione_turiweb#%?=#%?txt#%?AS#$?nazione_turiweb#%?=#%?txt#%?WS#$?nazione_turiweb#%?=#%?txt#%?TK#$?nazione_turiweb#%?=#%?txt#%?TO#$?nazione_turiweb#%?=#%?txt#%?TV#$?nazione_turiweb#%?=#%?txt#%?WF#@?set#%?180#%?=#%?txt#%?OCE#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>117</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?#@?break#%?</cmp></riga>
<riga><cmp>118</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?183#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>119</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?codice_regione_ospite#%?!=#%?txt#%?#@?set#%?183#%?=#%?txt#%?_#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>120</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?183#%?.=#%?var#%?codice_regione_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>122</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?provincia_turiweb#%?=#%?txt#%?_FO#@?set#%?183#%?=#%?txt#%?_FC#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>123</cmp><cmp>cond21</cmp><cmp>rpt#@?and#$?provincia_turiweb#%?=#%?txt#%?#$?numero_ospite#%?=#%?txt#%?1#@?set#%?183#%?=#%?txt#%?_00#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>124</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?170#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>125</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?IT#@?set#%?170#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>126</cmp><cmp>cond21</cmp><cmp>rpt#@?and#$?provincia_turiweb#%?=#%?txt#%?#$?italiano_turiweb#%?=#%?txt#%?1#@?set#%?181#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>127</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?break_turiweb#%?=#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>128</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?174#%?=#%?var#%?num_persone_tot#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>129</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?num_persone_turiweb#%?<#%?var#%?num_ospiti_tot#@?set#%?174#%?=#%?var#%?num_ospiti_tot#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>130</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?num_persone_turiweb#%?=#%?txt#%?#@?break#%?</cmp></riga>
<riga><cmp>131</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?167#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>132</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?168#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>133</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?169#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>134</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?data_inizio#%?=#%?var#%?date_turiweb(data_turiweb)#@?set#%?168#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>135</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?data_fine#%?=#%?var#%?date_turiweb(data_turiweb)#@?set#%?169#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>136</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?190#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>137</cmp><cmp>cond21</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?arrivo_turiweb#%?!=#%?txt#%?1#@?set#%?190#%?=#%?var#%?num_persone_turiweb#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>138</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?oper#%?185#%?cli_giorno_prec_turiweb#%?+#%?var#%?agg_turiweb#%?</cmp></riga>
<riga><cmp>139</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?190#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>140</cmp><cmp>cond21</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?arrivo_turiweb#%?=#%?txt#%?1#@?set#%?190#%?=#%?var#%?num_persone_turiweb#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>141</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?oper#%?186#%?cli_arrivati_turiweb#%?+#%?var#%?agg_turiweb#%?</cmp></riga>
<riga><cmp>142</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?190#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>143</cmp><cmp>cond21</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?partenza_turiweb#%?=#%?txt#%?1#@?set#%?190#%?=#%?var#%?num_persone_turiweb#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>144</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?oper#%?188#%?cli_partiti_turiweb#%?+#%?var#%?agg_turiweb#%?</cmp></riga>
<riga><cmp>145</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?oper#%?187#%?cli_giorno_prec_turiweb#%?+#%?var#%?cli_arrivati_turiweb#%?</cmp></riga>
<riga><cmp>146</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?oper#%?189#%?cli_totale_turiweb#%?-#%?var#%?cli_partiti_turiweb#%?</cmp></riga>
<riga><cmp>147</cmp><cmp>cond21</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?partenza_turiweb#%?!=#%?txt#%?1#@?oper#%?206#%?camere_occupate_turiweb#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>148</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?camere_occupate_turiweb#%?>#%?txt#%?0#@?set#%?199#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>149</cmp><cmp>cond21</cmp><cmp>rpt#@?or#$?arrivo_turiweb#%?=#%?txt#%?1#$?partenza_turiweb#%?=#%?txt#%?1#@?set#%?167#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>150</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?arr_part_turiweb#%?!=#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>151</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?199#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>152</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?190#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>153</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?ultima_data_turiweb#%?=#%?txt#%?#@?set#%?179#%?=#%?txt#%?-1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>154</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?ultima_data_turiweb#%?!=#%?var#%?data_turiweb#@?set#%?190#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>155</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?oper#%?179#%?num_prog_turiweb#%?+#%?var#%?agg_turiweb#%?</cmp></riga>
<riga><cmp>156</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?200#%?=#%?var#%?data_turiweb#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>157</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?num_prog_turiweb#%?>#%?txt#%?0#@?set#%?201#%?=#%?txt#%?\par \page#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>158</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?numero_ospite#%?=#%?txt#%?1#@?set#%?182#%?=#%?var#%?nazione_turiweb#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>159</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?numero_ospite#%?=#%?txt#%?1#@?set#%?184#%?=#%?var#%?provincia_turiweb#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>160</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?191#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>161</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione1_turiweb#%?!=#%?var#%?nazione_turiweb#@?set#%?191#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>162</cmp><cmp>cond21</cmp><cmp>rpt#@?or#$?numero_ospite#%?=#%?txt#%?1#$?italiano_turiweb#%?=#%?txt#%?1#@?set#%?191#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>163</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?ospite_altra_naz_turiweb#%?!=#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>164</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?192#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>165</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?provincia1_turiweb#%?!=#%?var#%?provincia_turiweb#@?set#%?192#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>166</cmp><cmp>cond21</cmp><cmp>rpt#@?or#$?numero_ospite#%?=#%?txt#%?1#$?italiano_turiweb#%?!=#%?txt#%?1#@?set#%?192#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>167</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?ospite_altra_prov_turiweb#%?!=#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>168</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?pos_naz_turiweb(nazione_turiweb)#%?!=#%?txt#%?#@?set#%?165#%?=#%?var#%?pos_naz_turiweb(nazione_turiweb)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>169</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?italiano_turiweb#%?=#%?txt#%?1#@?set#%?165#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>170</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?171#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>171</cmp><cmp>cond21</cmp><cmp>rpt#@?and#$?pos_naz_turiweb(nazione_turiweb)#%?=#%?txt#%?#$?italiano_turiweb#%?!=#%?txt#%?1#@?set#%?171#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>172</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?ins_nuovo_num_turiweb#%?=#%?txt#%?1#@?set#%?165#%?=#%?var#%?prox_num_turiweb#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>173</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?ins_nuovo_num_turiweb#%?=#%?txt#%?1#@?set#%?a1033#%?=#%?var#%?pos_turiweb#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>174</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?ins_nuovo_num_turiweb#%?=#%?txt#%?1#@?set#%?a1034#%?=#%?var#%?nazione_turiweb#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>175</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?ins_nuovo_num_turiweb#%?=#%?txt#%?1#@?set#%?163#%?=#%?var#%?prox_num_turiweb#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>176</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?172#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>177</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?173#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>178</cmp><cmp>cond21</cmp><cmp>rpt#@?and#$?italiano_turiweb#%?!=#%?txt#%?1#$?arrivo_turiweb#%?=#%?txt#%?1#@?set#%?172#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>179</cmp><cmp>cond21</cmp><cmp>rpt#@?and#$?italiano_turiweb#%?!=#%?txt#%?1#$?partenza_turiweb#%?=#%?txt#%?1#@?set#%?173#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>180</cmp><cmp>cond21</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?agg_arr_turiweb#%?=#%?txt#%?1#@?set#%?172#%?=#%?var#%?num_persone_turiweb#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>181</cmp><cmp>cond21</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?agg_part_turiweb#%?=#%?txt#%?1#@?set#%?173#%?=#%?var#%?num_persone_turiweb#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>182</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?oper#%?a1035#%?arrivi_naz_turiweb(pos_turiweb)#%?+#%?var#%?agg_arr_turiweb#%?</cmp></riga>
<riga><cmp>183</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?oper#%?a1036#%?partenze_naz_turiweb(pos_turiweb)#%?+#%?var#%?agg_part_turiweb#%?</cmp></riga>
<riga><cmp>184</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?oper#%?195#%?tot_arr_naz_turiweb#%?+#%?var#%?agg_arr_turiweb#%?</cmp></riga>
<riga><cmp>185</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?oper#%?196#%?tot_part_naz_turiweb#%?+#%?var#%?agg_part_turiweb#%?</cmp></riga>
<riga><cmp>186</cmp><cmp>cond21</cmp><cmp>rpt#@?and#$?italiano_turiweb#%?!=#%?txt#%?1#$?numero_ospite#%?=#%?txt#%?1#@?set#%?181#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>187</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?break_turiweb#%?=#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>188</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?oper#%?194#%?num_prov_turiweb#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>189</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?pos_prov_turiweb(provincia_turiweb)#%?!=#%?txt#%?#@?set#%?165#%?=#%?var#%?pos_prov_turiweb(provincia_turiweb)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>190</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?171#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>191</cmp><cmp>cond21</cmp><cmp>rpt#@?and#$?pos_prov_turiweb(provincia_turiweb)#%?=#%?txt#%?#$?italiano_turiweb#%?=#%?txt#%?1#@?set#%?171#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>192</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?ins_nuovo_num_turiweb#%?=#%?txt#%?1#@?set#%?165#%?=#%?var#%?prox_num_prov_turiweb#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>193</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?ins_nuovo_num_turiweb#%?=#%?txt#%?1#@?set#%?a1038#%?=#%?var#%?pos_turiweb#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>194</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?ins_nuovo_num_turiweb#%?=#%?txt#%?1#@?set#%?a1039#%?=#%?var#%?provincia_turiweb#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>195</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?ins_nuovo_num_turiweb#%?=#%?txt#%?1#@?set#%?193#%?=#%?var#%?prox_num_prov_turiweb#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>196</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?172#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>197</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?173#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>198</cmp><cmp>cond21</cmp><cmp>rpt#@?and#$?italiano_turiweb#%?=#%?txt#%?1#$?arrivo_turiweb#%?=#%?txt#%?1#@?set#%?172#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>199</cmp><cmp>cond21</cmp><cmp>rpt#@?and#$?italiano_turiweb#%?=#%?txt#%?1#$?partenza_turiweb#%?=#%?txt#%?1#@?set#%?173#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>200</cmp><cmp>cond21</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?agg_arr_turiweb#%?=#%?txt#%?1#@?set#%?172#%?=#%?var#%?num_persone_turiweb#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>201</cmp><cmp>cond21</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?agg_part_turiweb#%?=#%?txt#%?1#@?set#%?173#%?=#%?var#%?num_persone_turiweb#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>202</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?oper#%?a1040#%?arrivi_prov_turiweb(pos_turiweb)#%?+#%?var#%?agg_arr_turiweb#%?</cmp></riga>
<riga><cmp>203</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?oper#%?a1041#%?partenze_prov_turiweb(pos_turiweb)#%?+#%?var#%?agg_part_turiweb#%?</cmp></riga>
<riga><cmp>204</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?oper#%?197#%?tot_arr_prov_turiweb#%?+#%?var#%?agg_arr_turiweb#%?</cmp></riga>
<riga><cmp>205</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?oper#%?198#%?tot_part_prov_turiweb#%?+#%?var#%?agg_part_turiweb#%?</cmp></riga>
<riga><cmp>206</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?numero_ospite#%?=#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>207</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione1_turiweb#%?=#%?txt#%?#@?break#%?</cmp></riga>
<riga><cmp>208</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?180#%?=#%?var#%?nazione1_turiweb#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>209</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?170#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>210</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?nazione_turiweb#%?=#%?txt#%?IT#@?set#%?170#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>211</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?165#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>212</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?italiano_turiweb#%?!=#%?txt#%?1#@?set#%?165#%?=#%?var#%?pos_naz_turiweb(nazione_turiweb)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>213</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?172#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>214</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?173#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>215</cmp><cmp>cond21</cmp><cmp>rpt#@?and#$?italiano_turiweb#%?!=#%?txt#%?1#$?arrivo_turiweb#%?=#%?txt#%?1#@?set#%?172#%?=#%?txt#%?-1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>216</cmp><cmp>cond21</cmp><cmp>rpt#@?and#$?italiano_turiweb#%?!=#%?txt#%?1#$?partenza_turiweb#%?=#%?txt#%?1#@?set#%?173#%?=#%?txt#%?-1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>217</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?oper#%?a1035#%?arrivi_naz_turiweb(pos_turiweb)#%?+#%?var#%?agg_arr_turiweb#%?</cmp></riga>
<riga><cmp>218</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?oper#%?a1036#%?partenze_naz_turiweb(pos_turiweb)#%?+#%?var#%?agg_part_turiweb#%?</cmp></riga>
<riga><cmp>219</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?oper#%?195#%?tot_arr_naz_turiweb#%?+#%?var#%?agg_arr_turiweb#%?</cmp></riga>
<riga><cmp>220</cmp><cmp>cond21</cmp><cmp>inr#@?#@?set#%?163#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>221</cmp><cmp>cond21</cmp><cmp>inr#@?#@?set#%?166#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>222</cmp><cmp>cond21</cmp><cmp>inr#@?#@?set#%?193#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>223</cmp><cmp>cond21</cmp><cmp>inr#@?#@?set#%?185#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>224</cmp><cmp>cond21</cmp><cmp>inr#@?#@?set#%?186#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>225</cmp><cmp>cond21</cmp><cmp>inr#@?#@?set#%?188#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>226</cmp><cmp>cond21</cmp><cmp>inr#@?#@?set#%?195#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>227</cmp><cmp>cond21</cmp><cmp>inr#@?#@?set#%?196#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>228</cmp><cmp>cond21</cmp><cmp>inr#@?#@?set#%?197#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>229</cmp><cmp>cond21</cmp><cmp>inr#@?#@?set#%?198#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>230</cmp><cmp>cond21</cmp><cmp>inr#@?#@?set#%?178#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>231</cmp><cmp>cond21</cmp><cmp>inr#@?#@?set#%?199#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>232</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?oper#%?196#%?tot_part_naz_turiweb#%?+#%?var#%?agg_part_turiweb#%?</cmp></riga>
<riga><cmp>233</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?italiano_turiweb#%?!=#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>234</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?183#%?=#%?var#%?provincia1_turiweb#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>235</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?set#%?165#%?=#%?var#%?pos_prov_turiweb(provincia_turiweb)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>236</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?arrivo_turiweb#%?=#%?txt#%?1#@?set#%?172#%?=#%?txt#%?-1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>237</cmp><cmp>cond21</cmp><cmp>rpt#@?#$?partenza_turiweb#%?=#%?txt#%?1#@?set#%?173#%?=#%?txt#%?-1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>238</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?oper#%?a1040#%?arrivi_prov_turiweb(pos_turiweb)#%?+#%?var#%?agg_arr_turiweb#%?</cmp></riga>
<riga><cmp>239</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?oper#%?a1041#%?partenze_prov_turiweb(pos_turiweb)#%?+#%?var#%?agg_part_turiweb#%?</cmp></riga>
<riga><cmp>240</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?oper#%?197#%?tot_arr_prov_turiweb#%?+#%?var#%?agg_arr_turiweb#%?</cmp></riga>
<riga><cmp>241</cmp><cmp>cond21</cmp><cmp>rpt#@?#@?oper#%?198#%?tot_part_prov_turiweb#%?+#%?var#%?agg_part_turiweb#%?</cmp></riga>
<riga><cmp>242</cmp><cmp>cond21</cmp><cmp>ind#@?#@?array#%?a1032#%?dat#%?</cmp></riga>
<riga><cmp>243</cmp><cmp>cond21</cmp><cmp>ind#@?#@?array#%?a1042#%?val#%?1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30</cmp></riga>
<riga><cmp>244</cmp><cmp>cond21</cmp><cmp>inr#@?#@?set#%?206#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>245</cmp><cmp>cond21</cmp><cmp>ind#@?#$?id_struttura_turiweb#%?=#%?txt#%?00000ALB0000#@?set#%?-1#%?=#%?txt#%?Per usare questo documento si deve inserire il proprio "id struttura", fornito da ricestat (raccolta dati ISTAT in alcune provincie della Toscana). Lo si può inserire modificando la prima condizione applicata al documento (cliccare sul numero del documento da "configura e personalizza" e poi premere il bottone in basso "variabili personalizzate e condizioni"). In seguito il documento potrà essere selezionato dalla pagina con la tabella del mese per generare il file del mese corrispondente.#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>3</cmp><cmp>cond20</cmp><cmp>ind#@?#@?set#%?255#%?=#%?txt#%?COD1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>4</cmp><cmp>cond20</cmp><cmp>ind#@?#@?set#%?256#%?=#%?txt#%?5#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>5</cmp><cmp>cond20</cmp><cmp>ind#@?#@?set#%?257#%?=#%?txt#%?15#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>6</cmp><cmp>cond20</cmp><cmp>ind#@?#@?set#%?248#%?=#%?var#%?data_inizio_selezione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>7</cmp><cmp>cond20</cmp><cmp>ind#@?#@?trunc#%?248#%?5#%?#%?ini</cmp></riga>
<riga><cmp>8</cmp><cmp>cond20</cmp><cmp>ind#@?#@?set#%?247#%?=#%?var#%?data_inizio_selezione#%?var#%?anno_sel_rimovcli#%?txt#%?#%?</cmp></riga>
<riga><cmp>9</cmp><cmp>cond20</cmp><cmp>ind#@?#@?trunc#%?247#%?2#%?#%?ini</cmp></riga>
<riga><cmp>10</cmp><cmp>cond20</cmp><cmp>ind#@?#@?trunc#%?248#%?4#%?#%?ini</cmp></riga>
<riga><cmp>11</cmp><cmp>cond20</cmp><cmp>ind#@?#@?set#%?249#%?=#%?var#%?data_fine_selezione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>12</cmp><cmp>cond20</cmp><cmp>ind#@?#@?trunc#%?249#%?5#%?#%?ini</cmp></riga>
<riga><cmp>13</cmp><cmp>cond20</cmp><cmp>ind#@?#@?set#%?249#%?=#%?var#%?data_fine_selezione#%?var#%?var_aux_rimovcli#%?txt#%?#%?</cmp></riga>
<riga><cmp>14</cmp><cmp>cond20</cmp><cmp>ind#@?#@?trunc#%?249#%?2#%?#%?ini</cmp></riga>
<riga><cmp>15</cmp><cmp>cond20</cmp><cmp>ind#@?#@?oper#%?250#%?mese_sel_rimovcli#%?+#%?txt#%?2#%?</cmp></riga>
<riga><cmp>16</cmp><cmp>cond20</cmp><cmp>ind#@?or#$?mese_sel_rimovcli#%?>#%?var#%?var_aux_rimovcli#$?var_rimovcli#%?=#%?var#%?var_aux_rimovcli#@?oper#%?247#%?mese_sel_rimovcli#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>17</cmp><cmp>cond20</cmp><cmp>ind#@?#$?mese_sel_rimovcli#%?>#%?txt#%?12#@?oper#%?248#%?anno_sel_rimovcli#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>18</cmp><cmp>cond20</cmp><cmp>ind#@?#$?mese_sel_rimovcli#%?>#%?txt#%?12#@?oper#%?247#%?mese_sel_rimovcli#%?-#%?txt#%?12#%?</cmp></riga>
<riga><cmp>19</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?prox_num_rimovcli#%?=#%?txt#%?0#@?unset#%?a2077</cmp></riga>
<riga><cmp>20</cmp><cmp>cond20</cmp><cmp>inr#@?#@?unset#%?a2078</cmp></riga>
<riga><cmp>21</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?prox_num_rimovcli#%?=#%?txt#%?0#@?unset#%?a2079</cmp></riga>
<riga><cmp>22</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?prox_num_rimovcli#%?=#%?txt#%?0#@?unset#%?a2080</cmp></riga>
<riga><cmp>23</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?prox_num_rimovcli#%?=#%?txt#%?0#@?unset#%?a2082</cmp></riga>
<riga><cmp>24</cmp><cmp>cond20</cmp><cmp>inr#@?#@?unset#%?a2083</cmp></riga>
<riga><cmp>25</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?prox_num_rimovcli#%?=#%?txt#%?0#@?unset#%?a2084</cmp></riga>
<riga><cmp>27</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?prox_num_rimovcli#%?=#%?txt#%?0#@?unset#%?a2085</cmp></riga>
<riga><cmp>28</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?prox_num_rimovcli#%?=#%?txt#%?0#@?unset#%?a2087</cmp></riga>
<riga><cmp>29</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?prox_num_rimovcli#%?=#%?txt#%?0#@?unset#%?a2088</cmp></riga>
<riga><cmp>30</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?oper#%?211#%?num_rimovcli#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>31</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?data_rimovcli#%?!=#%?txt#%?2#@?break#%?</cmp></riga>
<riga><cmp>36</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?226#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>37</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?252#%?=#%?var#%?date_rimovcli(data_rimovcli)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>40</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?220#%?=#%?var#%?date_rimovcli(data_rimovcli)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>41</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?trunc#%?220#%?5#%?#%?ini</cmp></riga>
<riga><cmp>42</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?222#%?=#%?var#%?date_rimovcli(data_rimovcli)#%?var#%?anno_rimovcli#%?var#%?null_rimovcli#%?</cmp></riga>
<riga><cmp>44</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?trunc#%?220#%?4#%?#%?ini</cmp></riga>
<riga><cmp>45</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?221#%?=#%?var#%?giorno_rimovcli#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>46</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?trunc#%?221#%?3#%?#%?ini</cmp></riga>
<riga><cmp>48</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?222#%?=#%?var#%?giorno_rimovcli#%?var#%?mese_rimovcli#%?var#%?null_rimovcli#%?</cmp></riga>
<riga><cmp>49</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?trunc#%?221#%?2#%?#%?ini</cmp></riga>
<riga><cmp>51</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?mese_sel_rimovcli#%?!=#%?var#%?mese_rimovcli#@?cont</cmp></riga>
<riga><cmp>52</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?225#%?=#%?var#%?codice_nazione_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>53</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?trunc#%?225#%?2#%?#%?ini</cmp></riga>
<riga><cmp>54</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?nazione_ospite#%?!=#%?txt#%?#$?nazione_rimovcli#%?=#%?txt#%?#@?set#%?225#%?=#%?txt#%?777#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>55</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?#@?set#%?225#%?=#%?var#%?codice_cittadinanza_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>56</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?var#%?codice_cittadinanza_ospite#@?trunc#%?225#%?2#%?#%?ini</cmp></riga>
<riga><cmp>57</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?cittadinanza_ospite#%?!=#%?txt#%?#$?nazione_rimovcli#%?=#%?txt#%?#@?set#%?225#%?=#%?txt#%?777#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>59</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?nazione_rimovcli#%?=#%?txt#%?#$?numero_ospite#%?=#%?txt#%?1#@?set#%?225#%?=#%?txt#%?777#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>61</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?FR#@?set#%?225#%?=#%?txt#%?001#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>63</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?NL#@?set#%?225#%?=#%?txt#%?003#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>64</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?DE#@?set#%?225#%?=#%?txt#%?004#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>65</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?GB#@?set#%?225#%?=#%?txt#%?006#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>66</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?IE#@?set#%?225#%?=#%?txt#%?007#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>67</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?DK#@?set#%?225#%?=#%?txt#%?008#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>68</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?GR#@?set#%?225#%?=#%?txt#%?009#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>69</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?PT#@?set#%?225#%?=#%?txt#%?010#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>70</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?ES#@?set#%?225#%?=#%?txt#%?011#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>71</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?LU#@?set#%?225#%?=#%?txt#%?018#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>72</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?IS#@?set#%?225#%?=#%?txt#%?024#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>73</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?BE#@?set#%?225#%?=#%?txt#%?017#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>74</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?NO#@?set#%?225#%?=#%?txt#%?028#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>78</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?SE#@?set#%?225#%?=#%?txt#%?030#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>79</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?FI#@?set#%?225#%?=#%?txt#%?032#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>80</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?AT#@?set#%?225#%?=#%?txt#%?038#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>81</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?MT#@?set#%?225#%?=#%?txt#%?046#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>82</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?TR#@?set#%?225#%?=#%?txt#%?052#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>86</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?EE#@?set#%?225#%?=#%?txt#%?053#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>88</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?LV#@?set#%?225#%?=#%?txt#%?054#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>89</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?LT#@?set#%?225#%?=#%?txt#%?055#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>90</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?PL#@?set#%?225#%?=#%?txt#%?060#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>91</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?CZ#@?set#%?225#%?=#%?txt#%?061#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>92</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?SK#@?set#%?225#%?=#%?txt#%?063#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>93</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?HU#@?set#%?225#%?=#%?txt#%?064#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>94</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?RO#@?set#%?225#%?=#%?txt#%?066#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>95</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?BG#@?set#%?225#%?=#%?txt#%?068#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>96</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?UA#@?set#%?225#%?=#%?txt#%?072#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>97</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?RU#@?set#%?225#%?=#%?txt#%?075#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>98</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?SI#@?set#%?225#%?=#%?txt#%?091#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>99</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?HR#@?set#%?225#%?=#%?txt#%?092#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>100</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?EG#@?set#%?225#%?=#%?txt#%?220#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>101</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?ZA#@?set#%?225#%?=#%?txt#%?388#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>102</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?US#@?set#%?225#%?=#%?txt#%?400#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>103</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?CA#@?set#%?225#%?=#%?txt#%?404#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>104</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?MX#@?set#%?225#%?=#%?txt#%?412#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>105</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?VE#@?set#%?225#%?=#%?txt#%?484#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>106</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?BR#@?set#%?225#%?=#%?txt#%?508#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>107</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?AR#@?set#%?225#%?=#%?txt#%?528#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>108</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?CY#@?set#%?225#%?=#%?txt#%?600#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>109</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?IL#@?set#%?225#%?=#%?txt#%?624#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>110</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?IN#@?set#%?225#%?=#%?txt#%?664#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>111</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?CN#@?set#%?225#%?=#%?txt#%?720#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>112</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?KR#@?set#%?225#%?=#%?txt#%?728#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>113</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?JP#@?set#%?225#%?=#%?txt#%?732#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>114</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?AU#@?set#%?225#%?=#%?txt#%?800#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>115</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?NZ#@?set#%?225#%?=#%?txt#%?804#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>116</cmp><cmp>cond20</cmp><cmp>rpt#@?or#$?nazione_rimovcli#%?=#%?txt#%?AL#$?nazione_rimovcli#%?=#%?txt#%?ME#$?nazione_rimovcli#%?=#%?txt#%?XK#$?nazione_rimovcli#%?=#%?txt#%?MC#$?nazione_rimovcli#%?=#%?txt#%?AD#$?nazione_rimovcli#%?=#%?txt#%?AM#$?nazione_rimovcli#%?=#%?txt#%?AZ#$?nazione_rimovcli#%?=#%?txt#%?BY#$?nazione_rimovcli#%?=#%?txt#%?BA#$?nazione_rimovcli#%?=#%?txt#%?VA#$?nazione_rimovcli#%?=#%?txt#%?FO#$?nazione_rimovcli#%?=#%?txt#%?GE#$?nazione_rimovcli#%?=#%?txt#%?GI#$?nazione_rimovcli#%?=#%?txt#%?IS#$?nazione_rimovcli#%?=#%?txt#%?YU#$?nazione_rimovcli#%?=#%?txt#%?MK#$?nazione_rimovcli#%?=#%?txt#%?MD#$?nazione_rimovcli#%?=#%?txt#%?SK#$?nazione_rimovcli#%?=#%?txt#%?SM#@?set#%?225#%?=#%?txt#%?100#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>117</cmp><cmp>cond20</cmp><cmp>rpt#@?or#$?nazione_rimovcli#%?=#%?txt#%?CH#$?nazione_rimovcli#%?=#%?txt#%?LI#@?set#%?225#%?=#%?txt#%?036#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>118</cmp><cmp>cond20</cmp><cmp>rpt#@?or#$?nazione_rimovcli#%?=#%?txt#%?PM#$?nazione_rimovcli#%?=#%?txt#%?BM#$?nazione_rimovcli#%?=#%?txt#%?BS#$?nazione_rimovcli#%?=#%?txt#%?GL#@?set#%?225#%?=#%?txt#%?410#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>119</cmp><cmp>cond20</cmp><cmp>rpt#@?or#$?nazione_rimovcli#%?=#%?txt#%?BO#$?nazione_rimovcli#%?=#%?txt#%?PE#$?nazione_rimovcli#%?=#%?txt#%?CO#$?nazione_rimovcli#%?=#%?txt#%?AI#$?nazione_rimovcli#%?=#%?txt#%?AG#$?nazione_rimovcli#%?=#%?txt#%?AN#$?nazione_rimovcli#%?=#%?txt#%?BB#$?nazione_rimovcli#%?=#%?txt#%?BZ#$?nazione_rimovcli#%?=#%?txt#%?KY#$?nazione_rimovcli#%?=#%?txt#%?CL#$?nazione_rimovcli#%?=#%?txt#%?CR#$?nazione_rimovcli#%?=#%?txt#%?CU#$?nazione_rimovcli#%?=#%?txt#%?DM#$?nazione_rimovcli#%?=#%?txt#%?EC#$?nazione_rimovcli#%?=#%?txt#%?SV#$?nazione_rimovcli#%?=#%?txt#%?JM#$?nazione_rimovcli#%?=#%?txt#%?GD#$?nazione_rimovcli#%?=#%?txt#%?GT#$?nazione_rimovcli#%?=#%?txt#%?GY#$?nazione_rimovcli#%?=#%?txt#%?HT#$?nazione_rimovcli#%?=#%?txt#%?HN#$?nazione_rimovcli#%?=#%?txt#%?VI#$?nazione_rimovcli#%?=#%?txt#%?FK#$?nazione_rimovcli#%?=#%?txt#%?MS#$?nazione_rimovcli#%?=#%?txt#%?NI#$?nazione_rimovcli#%?=#%?txt#%?PA#$?nazione_rimovcli#%?=#%?txt#%?PY#$?nazione_rimovcli#%?=#%?txt#%?DO#$?nazione_rimovcli#%?=#%?txt#%?VC#$?nazione_rimovcli#%?=#%?txt#%?KN#$?nazione_rimovcli#%?=#%?txt#%?LC#$?nazione_rimovcli#%?=#%?txt#%?SR#$?nazione_rimovcli#%?=#%?txt#%?TC#$?nazione_rimovcli#%?=#%?txt#%?VG#$?nazione_rimovcli#%?=#%?txt#%?TT#$?nazione_rimovcli#%?=#%?txt#%?UY#@?set#%?225#%?=#%?txt#%?530#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>120</cmp><cmp>cond20</cmp><cmp>rpt#@?or#$?nazione_rimovcli#%?=#%?txt#%?LB#$?nazione_rimovcli#%?=#%?txt#%?SY#$?nazione_rimovcli#%?=#%?txt#%?JO#$?nazione_rimovcli#%?=#%?txt#%?SA#$?nazione_rimovcli#%?=#%?txt#%?BH#$?nazione_rimovcli#%?=#%?txt#%?AE#$?nazione_rimovcli#%?=#%?txt#%?IR#$?nazione_rimovcli#%?=#%?txt#%?IQ#$?nazione_rimovcli#%?=#%?txt#%?KW#$?nazione_rimovcli#%?=#%?txt#%?OM#$?nazione_rimovcli#%?=#%?txt#%?PS#$?nazione_rimovcli#%?=#%?txt#%?QA#$?nazione_rimovcli#%?=#%?txt#%?YE#@?set#%?225#%?=#%?txt#%?750#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>122</cmp><cmp>cond20</cmp><cmp>rpt#@?or#$?nazione_rimovcli#%?=#%?txt#%?PK#$?nazione_rimovcli#%?=#%?txt#%?MM#$?nazione_rimovcli#%?=#%?txt#%?BD#$?nazione_rimovcli#%?=#%?txt#%?AF#$?nazione_rimovcli#%?=#%?txt#%?BT#$?nazione_rimovcli#%?=#%?txt#%?BN#$?nazione_rimovcli#%?=#%?txt#%?KH#$?nazione_rimovcli#%?=#%?txt#%?CN#$?nazione_rimovcli#%?=#%?txt#%?TW#$?nazione_rimovcli#%?=#%?txt#%?KP#$?nazione_rimovcli#%?=#%?txt#%?PH#$?nazione_rimovcli#%?=#%?txt#%?HK#$?nazione_rimovcli#%?=#%?txt#%?ID#$?nazione_rimovcli#%?=#%?txt#%?KZ#$?nazione_rimovcli#%?=#%?txt#%?KG#$?nazione_rimovcli#%?=#%?txt#%?LA#$?nazione_rimovcli#%?=#%?txt#%?MO#$?nazione_rimovcli#%?=#%?txt#%?MY#$?nazione_rimovcli#%?=#%?txt#%?MV#$?nazione_rimovcli#%?=#%?txt#%?MN#$?nazione_rimovcli#%?=#%?txt#%?NP#$?nazione_rimovcli#%?=#%?txt#%?SG#$?nazione_rimovcli#%?=#%?txt#%?TJ#$?nazione_rimovcli#%?=#%?txt#%?LK#$?nazione_rimovcli#%?=#%?txt#%?UZ#$?nazione_rimovcli#%?=#%?txt#%?TH#$?nazione_rimovcli#%?=#%?txt#%?TM#$?nazione_rimovcli#%?=#%?txt#%?TL#$?nazione_rimovcli#%?=#%?txt#%?VN#@?set#%?225#%?=#%?txt#%?760#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>123</cmp><cmp>cond20</cmp><cmp>rpt#@?or#$?nazione_rimovcli#%?=#%?txt#%?MA#$?nazione_rimovcli#%?=#%?txt#%?DZ#$?nazione_rimovcli#%?=#%?txt#%?TN#$?nazione_rimovcli#%?=#%?txt#%?LY#@?set#%?225#%?=#%?txt#%?230#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>124</cmp><cmp>cond20</cmp><cmp>rpt#@?or#$?nazione_rimovcli#%?=#%?txt#%?KE#$?nazione_rimovcli#%?=#%?txt#%?SS#$?nazione_rimovcli#%?=#%?txt#%?LR#$?nazione_rimovcli#%?=#%?txt#%?AO#$?nazione_rimovcli#%?=#%?txt#%?BJ#$?nazione_rimovcli#%?=#%?txt#%?BW#$?nazione_rimovcli#%?=#%?txt#%?BF#$?nazione_rimovcli#%?=#%?txt#%?BI#$?nazione_rimovcli#%?=#%?txt#%?CM#$?nazione_rimovcli#%?=#%?txt#%?CV#$?nazione_rimovcli#%?=#%?txt#%?CF#$?nazione_rimovcli#%?=#%?txt#%?TD#$?nazione_rimovcli#%?=#%?txt#%?KM#$?nazione_rimovcli#%?=#%?txt#%?CG#$?nazione_rimovcli#%?=#%?txt#%?CI#$?nazione_rimovcli#%?=#%?txt#%?ER#$?nazione_rimovcli#%?=#%?txt#%?ET#$?nazione_rimovcli#%?=#%?txt#%?GA#$?nazione_rimovcli#%?=#%?txt#%?GM#$?nazione_rimovcli#%?=#%?txt#%?GH#$?nazione_rimovcli#%?=#%?txt#%?DJ#$?nazione_rimovcli#%?=#%?txt#%?GN#$?nazione_rimovcli#%?=#%?txt#%?GW#$?nazione_rimovcli#%?=#%?txt#%?GQ#$?nazione_rimovcli#%?=#%?txt#%?LS#$?nazione_rimovcli#%?=#%?txt#%?MG#$?nazione_rimovcli#%?=#%?txt#%?ML#$?nazione_rimovcli#%?=#%?txt#%?MW#$?nazione_rimovcli#%?=#%?txt#%?MU#$?nazione_rimovcli#%?=#%?txt#%?MR#$?nazione_rimovcli#%?=#%?txt#%?YT#$?nazione_rimovcli#%?=#%?txt#%?MZ#$?nazione_rimovcli#%?=#%?txt#%?NA#$?nazione_rimovcli#%?=#%?txt#%?NE#$?nazione_rimovcli#%?=#%?txt#%?NG#$?nazione_rimovcli#%?=#%?txt#%?CD#$?nazione_rimovcli#%?=#%?txt#%?RW#$?nazione_rimovcli#%?=#%?txt#%?SC#$?nazione_rimovcli#%?=#%?txt#%?SN#$?nazione_rimovcli#%?=#%?txt#%?ST#$?nazione_rimovcli#%?=#%?txt#%?SL#$?nazione_rimovcli#%?=#%?txt#%?TG#$?nazione_rimovcli#%?=#%?txt#%?SD#$?nazione_rimovcli#%?=#%?txt#%?SO#$?nazione_rimovcli#%?=#%?txt#%?SZ#$?nazione_rimovcli#%?=#%?txt#%?TZ#$?nazione_rimovcli#%?=#%?txt#%?UG#$?nazione_rimovcli#%?=#%?txt#%?ZM#$?nazione_rimovcli#%?=#%?txt#%?ZW#$?nazione_rimovcli#%?=#%?txt#%?CD#@?set#%?225#%?=#%?txt#%?300#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>125</cmp><cmp>cond20</cmp><cmp>rpt#@?or#$?nazione_rimovcli#%?=#%?txt#%?NC#$?nazione_rimovcli#%?=#%?txt#%?VU#$?nazione_rimovcli#%?=#%?txt#%?FJ#$?nazione_rimovcli#%?=#%?txt#%?CX#$?nazione_rimovcli#%?=#%?txt#%?CC#$?nazione_rimovcli#%?=#%?txt#%?GU#$?nazione_rimovcli#%?=#%?txt#%?KI#$?nazione_rimovcli#%?=#%?txt#%?MP#$?nazione_rimovcli#%?=#%?txt#%?MH#$?nazione_rimovcli#%?=#%?txt#%?FM#$?nazione_rimovcli#%?=#%?txt#%?NF#$?nazione_rimovcli#%?=#%?txt#%?NR#$?nazione_rimovcli#%?=#%?txt#%?PG#$?nazione_rimovcli#%?=#%?txt#%?PW#$?nazione_rimovcli#%?=#%?txt#%?PN#$?nazione_rimovcli#%?=#%?txt#%?PF#$?nazione_rimovcli#%?=#%?txt#%?SB#$?nazione_rimovcli#%?=#%?txt#%?AS#$?nazione_rimovcli#%?=#%?txt#%?WS#$?nazione_rimovcli#%?=#%?txt#%?TK#$?nazione_rimovcli#%?=#%?txt#%?TO#$?nazione_rimovcli#%?=#%?txt#%?TV#$?nazione_rimovcli#%?=#%?txt#%?WF#@?set#%?225#%?=#%?txt#%?810#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>126</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?#@?break#%?</cmp></riga>
<riga><cmp>127</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?228#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>128</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?228#%?=#%?var#%?codice2_regione_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>129</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?provincia_rimovcli#%?=#%?txt#%?#$?numero_ospite#%?=#%?txt#%?1#@?set#%?228#%?=#%?txt#%?900#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>130</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?numero_ospite#%?=#%?txt#%?1#@?set#%?259#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>131</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?nazione_rimovcli#%?=#%?txt#%?777#@?set#%?259#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>133</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?nazione_rimovcli#%?=#%?txt#%?IT#$?provincia_rimovcli#%?=#%?txt#%?900#@?set#%?259#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>134</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?break_prenota_rimovcli#%?=#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>135</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?215#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>136</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?IT#@?set#%?215#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>137</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?provincia_rimovcli#%?=#%?txt#%?#$?italiano_rimovcli#%?=#%?txt#%?1#@?set#%?226#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>138</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?break_rimovcli#%?=#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>139</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?219#%?=#%?var#%?num_persone_tot#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>140</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?num_persone_rimovcli#%?<#%?var#%?num_ospiti_tot#@?set#%?219#%?=#%?var#%?num_ospiti_tot#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>141</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?num_persone_rimovcli#%?=#%?txt#%?#@?break#%?</cmp></riga>
<riga><cmp>142</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?212#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>143</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?213#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>144</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?214#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>145</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?data_inizio#%?=#%?var#%?date_rimovcli(data_rimovcli)#@?set#%?213#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>146</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?data_fine#%?=#%?var#%?date_rimovcli(data_rimovcli)#@?set#%?214#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>147</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?235#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>148</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?arrivo_rimovcli#%?!=#%?txt#%?1#@?set#%?235#%?=#%?var#%?num_persone_rimovcli#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>149</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?oper#%?230#%?cli_giorno_prec_rimovcli#%?+#%?var#%?agg_rimovcli#%?</cmp></riga>
<riga><cmp>150</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?235#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>151</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?arrivo_rimovcli#%?=#%?txt#%?1#@?set#%?235#%?=#%?var#%?num_persone_rimovcli#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>152</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?oper#%?231#%?cli_arrivati_rimovcli#%?+#%?var#%?agg_rimovcli#%?</cmp></riga>
<riga><cmp>153</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?235#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>154</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?partenza_rimovcli#%?=#%?txt#%?1#@?set#%?235#%?=#%?var#%?num_persone_rimovcli#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>155</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?oper#%?233#%?cli_partiti_rimovcli#%?+#%?var#%?agg_rimovcli#%?</cmp></riga>
<riga><cmp>156</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?oper#%?232#%?cli_giorno_prec_rimovcli#%?+#%?var#%?cli_arrivati_rimovcli#%?</cmp></riga>
<riga><cmp>158</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?oper#%?234#%?cli_totale_rimovcli#%?-#%?var#%?cli_partiti_rimovcli#%?</cmp></riga>
<riga><cmp>159</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?partenza_rimovcli#%?!=#%?txt#%?1#@?oper#%?251#%?camere_occupate_rimovcli#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>160</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?camere_occupate_rimovcli#%?>#%?txt#%?0#@?set#%?244#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>161</cmp><cmp>cond20</cmp><cmp>rpt#@?or#$?arrivo_rimovcli#%?=#%?txt#%?1#$?partenza_rimovcli#%?=#%?txt#%?1#@?set#%?212#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>162</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?arr_part_rimovcli#%?=#%?txt#%?1000#@?break#%?</cmp></riga>
<riga><cmp>163</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?244#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>164</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?258#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>165</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?235#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>166</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?ultima_data_rimovcli#%?=#%?txt#%?#@?set#%?224#%?=#%?txt#%?-1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>167</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?ultima_data_rimovcli#%?!=#%?var#%?data_rimovcli#@?set#%?235#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>168</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?oper#%?224#%?num_prog_rimovcli#%?+#%?var#%?agg_rimovcli#%?</cmp></riga>
<riga><cmp>169</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?245#%?=#%?var#%?data_rimovcli#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>170</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?num_prog_rimovcli#%?>#%?txt#%?0#@?set#%?246#%?=#%?txt#%?\par \page#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>171</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?numero_ospite#%?=#%?txt#%?1#@?set#%?227#%?=#%?var#%?nazione_rimovcli#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>172</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?numero_ospite#%?=#%?txt#%?1#@?set#%?229#%?=#%?var#%?provincia_rimovcli#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>173</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?236#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>174</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione1_rimovcli#%?!=#%?var#%?nazione_rimovcli#@?set#%?236#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>175</cmp><cmp>cond20</cmp><cmp>rpt#@?or#$?numero_ospite#%?=#%?txt#%?1#$?italiano_rimovcli#%?=#%?txt#%?1#@?set#%?236#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>177</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?ospite_altra_naz_rimovcli#%?!=#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>178</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?237#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>179</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?provincia1_rimovcli#%?!=#%?var#%?provincia_rimovcli#@?set#%?237#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>180</cmp><cmp>cond20</cmp><cmp>rpt#@?or#$?numero_ospite#%?=#%?txt#%?1#$?italiano_rimovcli#%?!=#%?txt#%?1#@?set#%?237#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>181</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?ospite_altra_prov_rimovcli#%?!=#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>182</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?pos_naz_rimovcli(nazione_rimovcli)#%?!=#%?txt#%?#@?set#%?210#%?=#%?var#%?pos_naz_rimovcli(nazione_rimovcli)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>183</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?italiano_rimovcli#%?=#%?txt#%?1#@?set#%?210#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>184</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?216#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>185</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?pos_naz_rimovcli(nazione_rimovcli)#%?=#%?txt#%?#$?italiano_rimovcli#%?!=#%?txt#%?1#@?set#%?216#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>186</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?ins_nuovo_num_rimovcli#%?=#%?txt#%?1#@?set#%?210#%?=#%?var#%?prox_num_rimovcli#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>187</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?ins_nuovo_num_rimovcli#%?=#%?txt#%?1#@?set#%?a2077#%?=#%?var#%?pos_rimovcli#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>188</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?ins_nuovo_num_rimovcli#%?=#%?txt#%?1#@?set#%?a2078#%?=#%?var#%?nazione_rimovcli#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>189</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?ins_nuovo_num_rimovcli#%?=#%?txt#%?1#@?set#%?208#%?=#%?var#%?prox_num_rimovcli#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>190</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?217#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>191</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?218#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>192</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?254#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>193</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?italiano_rimovcli#%?!=#%?txt#%?1#$?arrivo_rimovcli#%?=#%?txt#%?1#@?set#%?217#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>194</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?italiano_rimovcli#%?!=#%?txt#%?1#$?partenza_rimovcli#%?=#%?txt#%?1#@?set#%?218#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>195</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?italiano_rimovcli#%?!=#%?txt#%?1#$?partenza_rimovcli#%?!=#%?txt#%?1#@?set#%?254#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>196</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?agg_arr_rimovcli#%?=#%?txt#%?1#@?set#%?217#%?=#%?var#%?num_persone_rimovcli#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>197</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?agg_part_rimovcli#%?=#%?txt#%?1#@?set#%?218#%?=#%?var#%?num_persone_rimovcli#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>198</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?agg_pres_rimovcli#%?=#%?txt#%?1#@?set#%?254#%?=#%?var#%?num_persone_rimovcli#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>199</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?oper#%?a2079#%?arrivi_naz_rimovcli(pos_rimovcli)#%?+#%?var#%?agg_arr_rimovcli#%?</cmp></riga>
<riga><cmp>200</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?oper#%?a2080#%?partenze_naz_rimovcli(pos_rimovcli)#%?+#%?var#%?agg_part_rimovcli#%?</cmp></riga>
<riga><cmp>201</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?oper#%?a2087#%?presenze_naz_rimovcli(pos_rimovcli)#%?+#%?var#%?agg_pres_rimovcli#%?</cmp></riga>
<riga><cmp>203</cmp><cmp>cond20</cmp><cmp>rpt#@?or#$?presenze_naz_rimovcli(pos_rimovcli)#%?>#%?txt#%?0#$?partenze_naz_rimovcli(pos_rimovcli)#%?>#%?txt#%?0#@?set#%?a2089#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>204</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?oper#%?240#%?tot_arr_naz_rimovcli#%?+#%?var#%?agg_arr_rimovcli#%?</cmp></riga>
<riga><cmp>205</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?oper#%?241#%?tot_part_naz_rimovcli#%?+#%?var#%?agg_part_rimovcli#%?</cmp></riga>
<riga><cmp>206</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?italiano_rimovcli#%?!=#%?txt#%?1#$?numero_ospite#%?=#%?txt#%?1#@?set#%?226#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>207</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?break_rimovcli#%?=#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>208</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?oper#%?239#%?num_prov_rimovcli#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>209</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?pos_prov_rimovcli(provincia_rimovcli)#%?!=#%?txt#%?#@?set#%?210#%?=#%?var#%?pos_prov_rimovcli(provincia_rimovcli)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>210</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?216#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>211</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?pos_prov_rimovcli(provincia_rimovcli)#%?=#%?txt#%?#$?italiano_rimovcli#%?=#%?txt#%?1#@?set#%?216#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>212</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?ins_nuovo_num_rimovcli#%?=#%?txt#%?1#@?set#%?210#%?=#%?var#%?prox_num_prov_rimovcli#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>213</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?ins_nuovo_num_rimovcli#%?=#%?txt#%?1#@?set#%?a2082#%?=#%?var#%?pos_rimovcli#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>214</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?ins_nuovo_num_rimovcli#%?=#%?txt#%?1#@?set#%?a2083#%?=#%?var#%?provincia_rimovcli#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>215</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?ins_nuovo_num_rimovcli#%?=#%?txt#%?1#@?set#%?238#%?=#%?var#%?prox_num_prov_rimovcli#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>216</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?217#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>217</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?218#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>218</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?254#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>219</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?italiano_rimovcli#%?=#%?txt#%?1#$?arrivo_rimovcli#%?=#%?txt#%?1#@?set#%?217#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>220</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?italiano_rimovcli#%?=#%?txt#%?1#$?partenza_rimovcli#%?=#%?txt#%?1#@?set#%?218#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>221</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?italiano_rimovcli#%?=#%?txt#%?1#$?partenza_rimovcli#%?!=#%?txt#%?1#@?set#%?254#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>222</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?agg_arr_rimovcli#%?=#%?txt#%?1#@?set#%?217#%?=#%?var#%?num_persone_rimovcli#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>223</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?agg_part_rimovcli#%?=#%?txt#%?1#@?set#%?218#%?=#%?var#%?num_persone_rimovcli#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>224</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?agg_pres_rimovcli#%?=#%?txt#%?1#@?set#%?254#%?=#%?var#%?num_persone_rimovcli#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>225</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?oper#%?a2084#%?arrivi_prov_rimovcli(pos_rimovcli)#%?+#%?var#%?agg_arr_rimovcli#%?</cmp></riga>
<riga><cmp>226</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?oper#%?a2085#%?partenze_prov_rimovcli(pos_rimovcli)#%?+#%?var#%?agg_part_rimovcli#%?</cmp></riga>
<riga><cmp>227</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?oper#%?a2088#%?presenze_prov_rimovcli(pos_rimovcli)#%?+#%?var#%?agg_pres_rimovcli#%?</cmp></riga>
<riga><cmp>228</cmp><cmp>cond20</cmp><cmp>rpt#@?or#$?presenze_prov_rimovcli(pos_rimovcli)#%?>#%?txt#%?0#$?partenze_prov_rimovcli(pos_rimovcli)#%?>#%?txt#%?0#@?set#%?a2090#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>229</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?oper#%?242#%?tot_arr_prov_rimovcli#%?+#%?var#%?agg_arr_rimovcli#%?</cmp></riga>
<riga><cmp>230</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?oper#%?243#%?tot_part_prov_rimovcli#%?+#%?var#%?agg_part_rimovcli#%?</cmp></riga>
<riga><cmp>231</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?numero_ospite#%?=#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>232</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione1_rimovcli#%?=#%?txt#%?#@?break#%?</cmp></riga>
<riga><cmp>233</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?225#%?=#%?var#%?nazione1_rimovcli#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>234</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?215#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>235</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?nazione_rimovcli#%?=#%?txt#%?IT#@?set#%?215#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>236</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?210#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>237</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?italiano_rimovcli#%?!=#%?txt#%?1#@?set#%?210#%?=#%?var#%?pos_naz_rimovcli(nazione_rimovcli)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>238</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?217#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>239</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?218#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>240</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?254#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>241</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?italiano_rimovcli#%?!=#%?txt#%?1#$?arrivo_rimovcli#%?=#%?txt#%?1#@?set#%?217#%?=#%?txt#%?-1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>242</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?italiano_rimovcli#%?!=#%?txt#%?1#$?partenza_rimovcli#%?=#%?txt#%?1#@?set#%?218#%?=#%?txt#%?-1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>243</cmp><cmp>cond20</cmp><cmp>rpt#@?and#$?italiano_rimovcli#%?!=#%?txt#%?1#$?partenza_rimovcli#%?!=#%?txt#%?1#@?set#%?254#%?=#%?txt#%?-1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>244</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?oper#%?a2079#%?arrivi_naz_rimovcli(pos_rimovcli)#%?+#%?var#%?agg_arr_rimovcli#%?</cmp></riga>
<riga><cmp>245</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?oper#%?a2080#%?partenze_naz_rimovcli(pos_rimovcli)#%?+#%?var#%?agg_part_rimovcli#%?</cmp></riga>
<riga><cmp>246</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?oper#%?a2087#%?presenze_naz_rimovcli(pos_rimovcli)#%?+#%?var#%?agg_pres_rimovcli#%?</cmp></riga>
<riga><cmp>247</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?oper#%?240#%?tot_arr_naz_rimovcli#%?+#%?var#%?agg_arr_rimovcli#%?</cmp></riga>
<riga><cmp>248</cmp><cmp>cond20</cmp><cmp>inr#@?#@?unset#%?a2087</cmp></riga>
<riga><cmp>249</cmp><cmp>cond20</cmp><cmp>inr#@?#@?unset#%?a2088</cmp></riga>
<riga><cmp>250</cmp><cmp>cond20</cmp><cmp>inr#@?#@?set#%?208#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>251</cmp><cmp>cond20</cmp><cmp>inr#@?#@?set#%?211#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>252</cmp><cmp>cond20</cmp><cmp>inr#@?#@?set#%?238#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>253</cmp><cmp>cond20</cmp><cmp>inr#@?#@?set#%?230#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>254</cmp><cmp>cond20</cmp><cmp>inr#@?#@?set#%?231#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>255</cmp><cmp>cond20</cmp><cmp>inr#@?#@?set#%?233#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>256</cmp><cmp>cond20</cmp><cmp>inr#@?#@?set#%?240#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>257</cmp><cmp>cond20</cmp><cmp>inr#@?#@?set#%?241#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>258</cmp><cmp>cond20</cmp><cmp>inr#@?#@?set#%?242#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>259</cmp><cmp>cond20</cmp><cmp>inr#@?#@?set#%?243#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>260</cmp><cmp>cond20</cmp><cmp>inr#@?#@?set#%?223#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>261</cmp><cmp>cond20</cmp><cmp>inr#@?#@?set#%?244#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>262</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?oper#%?241#%?tot_part_naz_rimovcli#%?+#%?var#%?agg_part_rimovcli#%?</cmp></riga>
<riga><cmp>263</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?italiano_rimovcli#%?!=#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>264</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?228#%?=#%?var#%?provincia1_rimovcli#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>265</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?set#%?210#%?=#%?var#%?pos_prov_rimovcli(provincia_rimovcli)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>266</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?arrivo_rimovcli#%?=#%?txt#%?1#@?set#%?217#%?=#%?txt#%?-1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>267</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?partenza_rimovcli#%?=#%?txt#%?1#@?set#%?218#%?=#%?txt#%?-1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>268</cmp><cmp>cond20</cmp><cmp>rpt#@?#$?partenza_rimovcli#%?!=#%?txt#%?1#@?set#%?254#%?=#%?txt#%?-1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>269</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?oper#%?a2084#%?arrivi_prov_rimovcli(pos_rimovcli)#%?+#%?var#%?agg_arr_rimovcli#%?</cmp></riga>
<riga><cmp>270</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?oper#%?a2085#%?partenze_prov_rimovcli(pos_rimovcli)#%?+#%?var#%?agg_part_rimovcli#%?</cmp></riga>
<riga><cmp>271</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?oper#%?a2088#%?presenze_prov_rimovcli(pos_rimovcli)#%?+#%?var#%?agg_pres_rimovcli#%?</cmp></riga>
<riga><cmp>272</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?oper#%?242#%?tot_arr_prov_rimovcli#%?+#%?var#%?agg_arr_rimovcli#%?</cmp></riga>
<riga><cmp>273</cmp><cmp>cond20</cmp><cmp>rpt#@?#@?oper#%?243#%?tot_part_prov_rimovcli#%?+#%?var#%?agg_part_rimovcli#%?</cmp></riga>
<riga><cmp>274</cmp><cmp>cond20</cmp><cmp>ind#@?#@?array#%?a2076#%?dat#%?</cmp></riga>
<riga><cmp>275</cmp><cmp>cond20</cmp><cmp>ind#@?#@?array#%?a2086#%?val#%?1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30</cmp></riga>
<riga><cmp>276</cmp><cmp>cond20</cmp><cmp>inr#@?#@?set#%?251#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>277</cmp><cmp>cond20</cmp><cmp>inr#@?#@?unset#%?a2089</cmp></riga>
<riga><cmp>278</cmp><cmp>cond20</cmp><cmp>inr#@?#@?unset#%?a2090</cmp></riga>
<riga><cmp>279</cmp><cmp>cond20</cmp><cmp>ind#@?#@?date#%?226#%?data_inizio_selezione#%?is#%?1#%?g</cmp></riga>
<riga><cmp>280</cmp><cmp>cond20</cmp><cmp>ind#@?or#$?break_rimovcli#%?=#%?var#%?data_fine_selezione#$?data_inizio_selezione#%?=#%?txt#%?#@?set#%?-1#%?=#%?txt#%?Questo documento viene generato solo per la seconda data selezionata, vanno selezionati almeno 2 giorni dalla tabella prenotazioni#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>281</cmp><cmp>cond20</cmp><cmp>ind#@?#@?set#%?249#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>282</cmp><cmp>cond20</cmp><cmp>inr#@?and#$?var_aux_rimovcli#%?=#%?txt#%?1#$?mostra_pag_tot_rimovcli#%?=#%?txt#%?0#$?messaggio_di_errore#%?=#%?txt#%?#@?set#%?-1#%?=#%?txt#%?File RIMOCLI vuoto per questa giornata#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>283</cmp><cmp>cond20</cmp><cmp>inr#@?#$?date_rimovcli(data_rimovcli)#%?=#%?var#%?data_fine_selezione#@?set#%?249#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>284</cmp><cmp>cond20</cmp><cmp>ind#@?#@?set#%?258#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>285</cmp><cmp>cond20</cmp><cmp>ind#@?#$?id_struttura_rimovcli#%?=#%?txt#%?COD1#@?set#%?-1#%?=#%?txt#%?Per usare questo documento si deve inserire il proprio "id struttura", fornito dalla regione Liguria (raccolta dati ISTAT con specifiche RIMOVCLI). Lo si può inserire modificando la prima condizione applicata al documento (cliccare sul numero del documento da "configura e personalizza" e poi premere il bottone in basso "variabili personalizzate e condizioni"). In seguito il documento potrà essere selezionato dalla pagina della tabella con tutte le prenotazioni: selezionare di vedere le prenotazioni dal giorno prima a quello successivo al giorno per cui si vuole generare il file e poi visualizzare il documento.#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>25</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?88#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>26</cmp><cmp>cond2</cmp><cmp>rpt#@?and#$?iva_perc_vett_fatt(num_iva_fatt)#%?=#%?var#%?percentuale_tasse_tariffa#$?num_ripetizione_fatt#%?>#%?txt#%?1#@?set#%?88#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>27</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?89#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>30</cmp><cmp>cond2</cmp><cmp>rpt#@?and#$?mos_tariffa_fatt#%?=#%?txt#%?1#$?sconto#%?!=#%?txt#%?0#@?set#%?89#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>31</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?90#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>32</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?160#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>36</cmp><cmp>cond2</cmp><cmp>ind#@?#@?set#%?161#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>39</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?156#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>40</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?nome_costo_agg#%?=#%?var#%?nome_costo_tassa_fatt#@?set#%?156#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>42</cmp><cmp>cond2</cmp><cmp>rpt#@?and#$?iva_perc_vett_fatt(num_iva_fatt)#%?=#%?var#%?percentuale_tasse_costo_agg#$?valore_costo_agg#%?!=#%?txt#%?0#$?num_ripetizione_fatt#%?>#%?txt#%?1#$?mos_costo_tassa_fatt#%?!=#%?txt#%?1#@?set#%?90#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>43</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?71#%?=#%?var#%?percentuale_tasse_tariffa#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>44</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?var_tmp_fatt#%?=#%?txt#%?#@?set#%?71#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>46</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?iva_perc_esist_fatt(var_tmp_fatt)#%?=#%?txt#%?1#@?break#%?cont</cmp></riga>
<riga><cmp>48</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?87#%?num_iva_fatt#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>52</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?96#%?=#%?var#%?num_iva_fatt#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>60</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?a35#%?=#%?var#%?var_tmp_fatt#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>61</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?a36#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>65</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?cont</cmp></riga>
<riga><cmp>75</cmp><cmp>cond2</cmp><cmp>rpt#@?or#$?valore_costo_agg#%?=#%?txt#%?0#$?valore_costo_agg#%?=#%?txt#%?#$?mos_costo_tassa_fatt#%?=#%?txt#%?1#@?break#%?cont</cmp></riga>
<riga><cmp>76</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?71#%?=#%?var#%?percentuale_tasse_costo_agg#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>81</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?var_tmp_fatt#%?=#%?txt#%?#@?set#%?71#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>83</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?iva_perc_esist_fatt(var_tmp_fatt)#%?=#%?txt#%?1#@?break#%?cont</cmp></riga>
<riga><cmp>84</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?87#%?num_iva_fatt#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>86</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?96#%?=#%?var#%?num_iva_fatt#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>87</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?a35#%?=#%?var#%?var_tmp_fatt#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>88</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?a36#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>89</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?cont</cmp></riga>
<riga><cmp>90</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?80#%?valore_costo_agg_senza_tasse#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>91</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?mos_costo_tassa_fatt#%?=#%?txt#%?1#@?oper#%?80#%?valore_costo_agg#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>95</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?74#%?=#%?var#%?nome_costo_agg#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>100</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?mos_costo_agg_fatt#%?=#%?txt#%?1#@?oper#%?75#%?tot_no_iva_fatt#%?+#%?var#%?valore_costo_agg_senza_tasse#%?</cmp></riga>
<riga><cmp>103</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?mos_costo_agg_fatt#%?=#%?txt#%?1#@?oper#%?92#%?tot_parz_no_iva_fatt#%?+#%?var#%?valore_costo_agg_senza_tasse#%?</cmp></riga>
<riga><cmp>105</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?mos_costo_agg_fatt#%?=#%?txt#%?1#@?oper#%?93#%?tot_parz_iva_fatt#%?+#%?var#%?tasse_costo_agg#%?</cmp></riga>
<riga><cmp>106</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?mos_costo_tassa_fatt#%?=#%?txt#%?1#@?oper#%?157#%?tot_costi_tassa_fatt#%?+#%?var#%?valore_costo_agg#%?</cmp></riga>
<riga><cmp>108</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?79#%?tot_no_iva_fatt#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>110</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?94#%?tot_parz_no_iva_fatt#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>111</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?95#%?tot_parz_iva_fatt#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>112</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?158#%?costo_tot_fatt#%?-#%?var#%?tot_no_iva_fatt#%?</cmp></riga>
<riga><cmp>113</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?158#%?iva_fatt#%?-#%?var#%?tot_costi_tassa_fatt#%?</cmp></riga>
<riga><cmp>114</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?78#%?iva_fatt#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>115</cmp><cmp>cond2</cmp><cmp>rpt#@?or#$?mos_costo_agg_fatt#%?!=#%?txt#%?1#$?percentuale_tasse_costo_agg#%?!=#%?txt#%?-1#@?break#%?cont</cmp></riga>
<riga><cmp>116</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?160#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>117</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?90#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>118</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?cont</cmp></riga>
<riga><cmp>119</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?max_num_iva_fatt#%?>#%?txt#%?1#@?set#%?161#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>120</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?ultima_prenota_fatt#%?=#%?var#%?numero_prenotazione#@?break#%?</cmp></riga>
<riga><cmp>121</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?73#%?=#%?var#%?numero_prenotazione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>122</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?mos_tariffa_fatt#%?=#%?txt#%?1#@?oper#%?75#%?tot_no_iva_fatt#%?+#%?var#%?costo_tariffa_senza_tasse#%?</cmp></riga>
<riga><cmp>123</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?mos_tariffa_fatt#%?=#%?txt#%?1#@?oper#%?92#%?tot_parz_no_iva_fatt#%?+#%?var#%?costo_tariffa_senza_tasse#%?</cmp></riga>
<riga><cmp>124</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?mos_tariffa_fatt#%?=#%?txt#%?1#@?oper#%?93#%?tot_parz_iva_fatt#%?+#%?var#%?tasse_tariffa#%?</cmp></riga>
<riga><cmp>125</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?mos_sconto_fatt#%?=#%?txt#%?1#@?oper#%?75#%?tot_no_iva_fatt#%?-#%?var#%?sconto_senza_tasse#%?</cmp></riga>
<riga><cmp>126</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?mos_sconto_fatt#%?=#%?txt#%?1#@?oper#%?92#%?tot_parz_no_iva_fatt#%?-#%?var#%?sconto_senza_tasse#%?</cmp></riga>
<riga><cmp>128</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?mos_sconto_fatt#%?=#%?txt#%?1#@?oper#%?93#%?tot_parz_iva_fatt#%?-#%?var#%?tasse_sconto#%?</cmp></riga>
<riga><cmp>129</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?82#%?costo_tariffa_senza_tasse#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>130</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?81#%?sconto_senza_tasse#%?*#%?txt#%?-1#%?</cmp></riga>
<riga><cmp>131</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?79#%?tot_no_iva_fatt#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>132</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?94#%?tot_parz_no_iva_fatt#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>133</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?95#%?tot_parz_iva_fatt#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>134</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?158#%?costo_tot_fatt#%?-#%?var#%?tot_no_iva_fatt#%?</cmp></riga>
<riga><cmp>135</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?158#%?iva_fatt#%?-#%?var#%?tot_costi_tassa_fatt#%?</cmp></riga>
<riga><cmp>136</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?78#%?iva_fatt#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>137</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?accorpa_sconto_e_tariffa#%?=#%?txt#%?SI#@?oper#%?82#%?costo_tariffa_senza_tasse#%?-#%?var#%?sconto_senza_tasse#%?</cmp></riga>
<riga><cmp>138</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?accorpa_sconto_e_tariffa#%?=#%?txt#%?SI#@?set#%?89#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>139</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?97#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>140</cmp><cmp>cond2</cmp><cmp>rpt#@?and#$?num_persone_tot#%?!=#%?txt#%?#$?num_persone_tot#%?!=#%?txt#%?0#@?set#%?97#%?=#%?txt#%? per x persone#%?txt#%?x#%?var#%?num_persone_tot#%?</cmp></riga>
<riga><cmp>141</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?num_ripetizione_fatt#%?>#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>142</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?76#%?costo_tot_fatt#%?+#%?var#%?costo_tot#%?</cmp></riga>
<riga><cmp>143</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?oper#%?77#%?costo_tot_fatt#%?+#%?txt#%?0#%?</cmp></riga>
<riga><cmp>144</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?codice_fiscale_struttura#%?!=#%?txt#%?#@?set#%?67#%?=#%?txt#%?- Codice Fiscale  #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>145</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?codice_fiscale_struttura#%?!=#%?txt#%?#@?set#%?67#%?.=#%?var#%?codice_fiscale_struttura#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>146</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?telefono_struttura#%?!=#%?txt#%?#@?set#%?70#%?=#%?txt#%?Tel. #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>147</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?telefono_struttura#%?!=#%?txt#%?#@?set#%?70#%?.=#%?var#%?telefono_struttura#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>148</cmp><cmp>cond2</cmp><cmp>inr#@?#@?set#%?73#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>149</cmp><cmp>cond2</cmp><cmp>inr#@?#@?oper#%?91#%?num_ripetizione_fatt#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>150</cmp><cmp>cond2</cmp><cmp>ind#@?#@?set#%?98#%?=#%?txt#%?SI#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>151</cmp><cmp>cond2</cmp><cmp>ind#@?#@?set#%?155#%?=#%?txt#%?nome del costo da considerare come tassa#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>152</cmp><cmp>cond2</cmp><cmp>ind#@?#@?set#%?76#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>153</cmp><cmp>cond2</cmp><cmp>rpt#@?and#$?telefono_struttura#%?!=#%?txt#%?#$?sito_web_struttura#%?!=#%?txt#%?#@?set#%?70#%?.=#%?txt#%? - #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>154</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?sito_web_struttura#%?!=#%?txt#%?#@?set#%?70#%?.=#%?var#%?sito_web_struttura#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>155</cmp><cmp>cond2</cmp><cmp>ind#@?#@?set#%?75#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>156</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?68#%?=#%?var#%?nome#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>157</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?69#%?=#%?var#%?cognome#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>158</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?83#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>159</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?numcivico#%?!=#%?txt#%?#@?set#%?83#%?=#%?txt#%?, #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>160</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?numcivico#%?!=#%?txt#%?#@?set#%?83#%?.=#%?var#%?numcivico#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>161</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?65#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>162</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?citta#%?!=#%?txt#%?#@?set#%?65#%?.=#%?var#%?citta#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>163</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?regione#%?!=#%?txt#%?#@?set#%?65#%?.=#%?txt#%? (#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>164</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?regione#%?!=#%?txt#%?#@?set#%?65#%?.=#%?var#%?regione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>165</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?regione#%?!=#%?txt#%?#@?set#%?65#%?.=#%?txt#%?)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>166</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?66#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>167</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?cap#%?!=#%?txt#%?#@?set#%?66#%?.=#%?var#%?cap#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>168</cmp><cmp>cond2</cmp><cmp>rpt#@?and#$?cap#%?!=#%?txt#%?#$?nazione#%?!=#%?txt#%?#@?set#%?66#%?.=#%?txt#%? #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>169</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?nazione#%?!=#%?txt#%?#@?set#%?66#%?.=#%?var#%?nazione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>170</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?84#%?=#%?var#%?codice_fiscale#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>171</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?85#%?=#%?var#%?partita_iva#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>172</cmp><cmp>cond2</cmp><cmp>rpt#@?#@?set#%?86#%?=#%?var#%?via#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>173</cmp><cmp>cond2</cmp><cmp>ind#@?#@?set#%?87#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>174</cmp><cmp>cond2</cmp><cmp>ind#@?#@?set#%?91#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>175</cmp><cmp>cond2</cmp><cmp>inr#@?#@?set#%?92#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>176</cmp><cmp>cond2</cmp><cmp>inr#@?#@?set#%?93#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>177</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?logo_struttura#%?!=#%?txt#%?#@?set#%?151#%?=#%?txt#%?<img src="#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>178</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?logo_struttura#%?!=#%?txt#%?#@?set#%?151#%?.=#%?var#%?logo_struttura#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>179</cmp><cmp>cond2</cmp><cmp>rpt#@?#$?logo_struttura#%?!=#%?txt#%?#@?set#%?151#%?.=#%?txt#%?" alt="Logo" style="float: right;">#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>180</cmp><cmp>cond2</cmp><cmp>inr#@?#@?set#%?157#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>1</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?474#%?=#%?var#%?numero_prenotazione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>2</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?486#%?=#%?var#%?numero_prenotazione#%?txt#%?#%?txt#%?#%?asc</cmp></riga>
<riga><cmp>3</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?trunc#%?486#%?9#%?0#%?fin</cmp></riga>
<riga><cmp>4</cmp><cmp>cond19</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?cod_capo_prenota_ross(numero_prenotazione)#%?=#%?txt#%?#@?set#%?a65484#%?=#%?txt#%?16#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>6</cmp><cmp>cond19</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?2#$?cod_capo_prenota_ross(numero_prenotazione)#%?=#%?txt#%?16#@?set#%?a65484#%?=#%?txt#%?17#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>7</cmp><cmp>cond19</cmp><cmp>rpt#@?and#$?codice_parentela_ospite#%?!=#%?txt#%?19#$?numero_ospite#%?!=#%?txt#%?1#@?set#%?a65484#%?=#%?txt#%?18#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>8</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?prenota_capo_gruppo_ross(num_prenota_tmp_ross)#%?=#%?txt#%?1#@?set#%?a65484#%?=#%?txt#%?18#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>9</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?numero_ospite#%?=#%?txt#%?1#@?set#%?453#%?=#%?var#%?cod_capo_prenota_ross(numero_prenotazione)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>11</cmp><cmp>cond19</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?prenota_in_gruppo_ross(num_prenota_tmp_ross)#%?=#%?txt#%?1#@?set#%?453#%?=#%?txt#%?20#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>12</cmp><cmp>cond19</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?prenota_in_gruppo_ross(num_prenota_tmp_ross)#%?=#%?txt#%?1#@?set#%?a65484#%?=#%?txt#%?20#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>13</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?numero_ospite#%?!=#%?txt#%?1#@?set#%?453#%?=#%?var#%?codice_parentela_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>14</cmp><cmp>cond19</cmp><cmp>rpt#@?and#$?numero_ospite#%?!=#%?txt#%?1#$?cod_capo_prenota_ross(numero_prenotazione)#%?=#%?txt#%?18#@?set#%?453#%?=#%?txt#%?20#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>15</cmp><cmp>cond19</cmp><cmp>rpt#@?and#$?numero_ospite#%?!=#%?txt#%?1#$?cod_capo_prenota_ross(numero_prenotazione)#%?=#%?txt#%?20#@?set#%?453#%?=#%?txt#%?20#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>16</cmp><cmp>cond19</cmp><cmp>rpt#@?and#$?numero_ospite#%?!=#%?txt#%?1#$?codice_parentela_ospite#%?!=#%?txt#%?19#@?set#%?453#%?=#%?txt#%?20#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>17</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?codice_ospite_ross#%?=#%?txt#%?16#@?set#%?487#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>18</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?codice_ospite_ross#%?=#%?txt#%?17#@?set#%?487#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>19</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?codice_ospite_ross#%?=#%?txt#%?18#@?set#%?487#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>20</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?codice_ospite_ross#%?=#%?txt#%?19#@?oper#%?487#%?num_prenota2_ross#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>21</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?codice_ospite_ross#%?=#%?txt#%?20#@?oper#%?487#%?num_prenota2_ross#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>22</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?454#%?=#%?var#%?data_inizio#%?txt#%?-#%?txt#%?/#%?</cmp></riga>
<riga><cmp>23</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?485#%?=#%?var#%?data_fine#%?txt#%?-#%?txt#%?/#%?</cmp></riga>
<riga><cmp>24</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?479#%?=#%?var#%?num_periodi#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>25</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?trunc#%?479#%?2#%?0#%?ini</cmp></riga>
<riga><cmp>26</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?455#%?=#%?var#%?cognome_ospite#%?txt#%?#%?txt#%?#%?asc</cmp></riga>
<riga><cmp>27</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?trunc#%?455#%?50#%? #%?fin</cmp></riga>
<riga><cmp>28</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?456#%?=#%?var#%?nome_ospite#%?txt#%?#%?txt#%?#%?asc</cmp></riga>
<riga><cmp>29</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?trunc#%?456#%?30#%? #%?fin</cmp></riga>
<riga><cmp>30</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?sesso_ospite#%?!=#%?txt#%?f#@?set#%?457#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>31</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?sesso_ospite#%?=#%?txt#%?f#@?set#%?457#%?=#%?txt#%?2#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>32</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?458#%?=#%?var#%?data_nascita_ospite#%?txt#%?-#%?txt#%?/#%?</cmp></riga>
<riga><cmp>33</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?481#%?=#%?var#%?codice2_nazione_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>34</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?480#%?=#%?var#%?codice_nazione_ross#%?txt#%?1#%?txt#%?#%?</cmp></riga>
<riga><cmp>35</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?tmp_ross#%?=#%?var#%?codice_nazione_ross#@?set#%?481#%?=#%?var#%?codice_nazione_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>36</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?482#%?=#%?var#%?codice2_nazione_nascita_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>37</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?480#%?=#%?var#%?codice_nazione_nascita_ross#%?txt#%?1#%?txt#%?#%?</cmp></riga>
<riga><cmp>38</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?tmp_ross#%?=#%?var#%?codice_nazione_nascita_ross#@?set#%?482#%?=#%?var#%?codice_nazione_nascita_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>39</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?483#%?=#%?var#%?codice2_nazione_documento_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>40</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?480#%?=#%?var#%?codice_nazione_documento_ross#%?txt#%?1#%?txt#%?#%?</cmp></riga>
<riga><cmp>41</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?tmp_ross#%?=#%?var#%?codice_nazione_documento_ross#@?set#%?483#%?=#%?var#%?codice_nazione_documento_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>42</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?484#%?=#%?var#%?codice2_cittadinanza_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>43</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?codice_cittadinanza_ospite#%?{}#%?txt#%?1#@?set#%?484#%?=#%?var#%?codice_cittadinanza_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>44</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?codice_nazione_nascita_ross#%?!=#%?txt#%?100000100#@?set#%?459#%?=#%?txt#%?         #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>46</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?codice_nazione_nascita_ross#%?=#%?txt#%?100000100#@?set#%?459#%?=#%?var#%?codice_citta_nascita_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>48</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?codice_nazione_nascita_ross#%?!=#%?txt#%?100000100#@?set#%?460#%?=#%?txt#%?  #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>49</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?codice_nazione_nascita_ross#%?=#%?txt#%?100000100#@?set#%?460#%?=#%?var#%?codice_regione_nascita_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>50</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?codice_nazione_ross#%?!=#%?txt#%?100000100#@?set#%?461#%?=#%?txt#%?         #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>51</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?codice_nazione_ross#%?=#%?txt#%?100000100#@?set#%?461#%?=#%?var#%?codice_citta_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>53</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?codice_nazione_ross#%?!=#%?txt#%?100000100#@?set#%?462#%?=#%?txt#%?  #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>54</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?codice_nazione_ross#%?=#%?txt#%?100000100#@?set#%?462#%?=#%?var#%?codice_regione_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>56</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?463#%?=#%?var#%?codice_nazione_ross#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>57</cmp><cmp>cond19</cmp><cmp>rpt#@?or#$?numero_ospite#%?!=#%?txt#%?1#$?prenota_in_gruppo_ross(num_prenota_tmp_ross)#%?=#%?txt#%?1#@?set#%?463#%?=#%?txt#%?         #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>58</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?464#%?=#%?var#%?via_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>59</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?numcivico_ospite#%?!=#%?txt#%?#@?set#%?464#%?.=#%?txt#%? #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>60</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?numcivico_ospite#%?!=#%?txt#%?#@?set#%?464#%?.=#%?var#%?numcivico_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>62</cmp><cmp>cond19</cmp><cmp>rpt#@?or#$?numero_ospite#%?!=#%?txt#%?1#$?prenota_in_gruppo_ross(num_prenota_tmp_ross)#%?=#%?txt#%?1#@?set#%?464#%?=#%?txt#%? #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>63</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?trunc#%?464#%?50#%? #%?fin</cmp></riga>
<riga><cmp>64</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?465#%?=#%?var#%?codice_tipo_documento_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>65</cmp><cmp>cond19</cmp><cmp>rpt#@?or#$?numero_ospite#%?!=#%?txt#%?1#$?prenota_in_gruppo_ross(num_prenota_tmp_ross)#%?=#%?txt#%?1#@?set#%?465#%?=#%?txt#%?     #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>66</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?466#%?=#%?var#%?documento_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>67</cmp><cmp>cond19</cmp><cmp>rpt#@?or#$?numero_ospite#%?!=#%?txt#%?1#$?prenota_in_gruppo_ross(num_prenota_tmp_ross)#%?=#%?txt#%?1#@?set#%?466#%?=#%?txt#%? #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>68</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?trunc#%?466#%?20#%? #%?fin</cmp></riga>
<riga><cmp>69</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?codice_nazione_documento_ross#%?!=#%?txt#%?100000100#@?set#%?467#%?=#%?var#%?codice_nazione_documento_ross#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>70</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?codice_nazione_documento_ross#%?=#%?txt#%?100000100#@?set#%?467#%?=#%?var#%?codice_citta_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>71</cmp><cmp>cond19</cmp><cmp>rpt#@?and#$?codice_nazione_documento_ross#%?=#%?txt#%?100000100#$?codice_citta_documento_ospite#%?!=#%?txt#%?#@?set#%?467#%?=#%?var#%?codice_citta_documento_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>72</cmp><cmp>cond19</cmp><cmp>rpt#@?or#$?numero_ospite#%?!=#%?txt#%?1#$?prenota_in_gruppo_ross(num_prenota_tmp_ross)#%?=#%?txt#%?1#@?set#%?467#%?=#%?txt#%?         #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>73</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?468#%?=#%?var#%?ritorno_a_capo#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>74</cmp><cmp>cond19</cmp><cmp>rpt#@?and#$?numero_ripetizione_prenotazioni#%?=#%?txt#%?1#$?numero_ospite#%?=#%?txt#%?1#@?set#%?468#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>75</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?acapo_ross#%?!=#%?txt#%?#@?set#%?468#%?.=#%?var#%?avanzamento_riga#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>76</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?475#%?=#%?var#%?data_inizio#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>77</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?476#%?=#%?var#%?data_fine#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>78</cmp><cmp>cond19</cmp><cmp>rpt#@?and#$?cognome_prec_ross#%?=#%?var#%?cognome#$?nome_prec_ross#%?=#%?var#%?nome#$?dataini_prec_ross#%?=#%?var#%?dataini_corr_ross#$?datafine_prec_ross#%?=#%?var#%?datafine_corr_ross#$?numero_ospite#%?=#%?txt#%?1#$?commento#%?=#%?txt#%?togliere questo se per  raggruppare più prenotazioni#@?set#%?a65483#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>79</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?474#%?=#%?var#%?num_prenota_prec_ross#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>82</cmp><cmp>cond19</cmp><cmp>rpt#@?and#$?cognome_prec_ross#%?=#%?var#%?cognome#$?nome_prec_ross#%?=#%?var#%?nome#$?dataini_prec_ross#%?=#%?var#%?dataini_corr_ross#$?datafine_prec_ross#%?=#%?var#%?datafine_corr_ross#$?prenota_in_gruppo_ross(num_prenota_tmp_ross)#%?!=#%?txt#%?1#$?numero_ospite#%?=#%?txt#%?1#@?set#%?a65482#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>83</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?469#%?=#%?var#%?cognome#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>84</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?470#%?=#%?var#%?nome#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>85</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?471#%?=#%?var#%?data_inizio#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>86</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?472#%?=#%?var#%?data_fine#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>87</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?473#%?=#%?var#%?numero_prenotazione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>88</cmp><cmp>cond19</cmp><cmp>inr#@?#@?set#%?469#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>89</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?num_ripetizione_ross#%?>#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>90</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?474#%?=#%?var#%?numero_prenotazione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>91</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?486#%?=#%?var#%?numero_prenotazione#%?txt#%?#%?txt#%?#%?asc</cmp></riga>
<riga><cmp>92</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?trunc#%?486#%?9#%?0#%?fin</cmp></riga>
<riga><cmp>93</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?478#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>94</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?nome_ospite#%?=#%?txt#%?#@?set#%?478#%?.=#%?txt#%?nome mancante,#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>95</cmp><cmp>cond19</cmp><cmp>rpt#@?or#$?data_nascita_ross#%?=#%?txt#%?#$?data_nascita_ross#%?=#%?txt#%?//#@?set#%?478#%?.=#%?txt#%?data nascita mancante, #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>96</cmp><cmp>cond19</cmp><cmp>ind#@?#@?set#%?477#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>97</cmp><cmp>cond19</cmp><cmp>inr#@?#@?oper#%?477#%?num_ripetizione_ross#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>98</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?codice_cittadinanza_ross#%?=#%?txt#%?#@?set#%?478#%?.=#%?txt#%?nazione di cittadinanza mancante, #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>99</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?codice_nazione_nascita_ross#%?=#%?txt#%?#@?set#%?478#%?.=#%?txt#%?nazione di nascita mancante, #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>100</cmp><cmp>cond19</cmp><cmp>rpt#@?and#$?codice_nazione_nascita_ross#%?=#%?txt#%?100000100#$?codice_regione_nascita_ospite#%?=#%?txt#%?#@?set#%?478#%?.=#%?txt#%?provincia di nascita mancante, #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>101</cmp><cmp>cond19</cmp><cmp>rpt#@?and#$?codice_nazione_nascita_ross#%?=#%?txt#%?100000100#$?codice_citta_nascita_ospite#%?=#%?txt#%?#@?set#%?478#%?.=#%?txt#%?città di nascita mancante, #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>103</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?codice_nazione_ross#%?=#%?txt#%?#@?set#%?478#%?.=#%?txt#%?nazione di residenza mancante, #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>104</cmp><cmp>cond19</cmp><cmp>rpt#@?and#$?codice_regione_ospite#%?=#%?txt#%?#$?codice_nazione_ross#%?=#%?txt#%?100000100#@?set#%?478#%?.=#%?txt#%?provincia di residenza mancante, #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>105</cmp><cmp>cond19</cmp><cmp>rpt#@?and#$?codice_citta_ospite#%?=#%?txt#%?#$?codice_nazione_ross#%?=#%?txt#%?100000100#@?set#%?478#%?.=#%?txt#%?città di residenza mancante, #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>111</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?mess_errore_ross#%?=#%?txt#%?#@?break#%?</cmp></riga>
<riga><cmp>112</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?-1#%?.=#%?txt#%?Prenotazione <b>#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>113</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?-1#%?.=#%?var#%?numero_prenotazione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>114</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?-1#%?.=#%?txt#%?</b> ospite <b>#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>115</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?-1#%?.=#%?var#%?numero_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>116</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?-1#%?.=#%?txt#%?</b>: #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>117</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?-1#%?.=#%?var#%?mess_errore_ross#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>118</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?-1#%?.=#%?txt#%?<br>#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>119</cmp><cmp>cond19</cmp><cmp>rpt#@?#@?set#%?480#%?=#%?var#%?mess_errore_ross#%?txt#%?città#%?txt#%?#%?</cmp></riga>
<riga><cmp>120</cmp><cmp>cond19</cmp><cmp>rpt#@?#$?tmp_ross#%?!=#%?var#%?mess_errore_ross#@?set#%?-1#%?.=#%?txt#%?<br>Si ricorda che per usare questo documento vanno prima ripristinate le <b>città predefinite</b> in "<em>configura e personalizza</em>", selezionando poi la città dal menù a tendina per ogni ospite italiano.<br>#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>1</cmp><cmp>cond18</cmp><cmp>rpt#@?#@?set#%?439#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>2</cmp><cmp>cond18</cmp><cmp>rpt#@?or#$?cognome#%?{}#%?txt#%?&quot;#$?cognome#%?{}#%?txt#%?,#@?set#%?439#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>3</cmp><cmp>cond18</cmp><cmp>rpt#@?#@?set#%?439#%?.=#%?var#%?cognome#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>4</cmp><cmp>cond18</cmp><cmp>rpt#@?or#$?cognome#%?{}#%?txt#%?&quot;#$?cognome#%?{}#%?txt#%?,#@?set#%?439#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>5</cmp><cmp>cond18</cmp><cmp>rpt#@?#@?set#%?440#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>6</cmp><cmp>cond18</cmp><cmp>rpt#@?or#$?nome#%?{}#%?txt#%?&quot;#$?nome#%?{}#%?txt#%?,#@?set#%?440#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>7</cmp><cmp>cond18</cmp><cmp>rpt#@?#@?set#%?440#%?.=#%?var#%?nome#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>8</cmp><cmp>cond18</cmp><cmp>rpt#@?or#$?nome#%?{}#%?txt#%?&quot;#$?nome#%?{}#%?txt#%?,#@?set#%?440#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>9</cmp><cmp>cond18</cmp><cmp>rpt#@?#@?set#%?441#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>10</cmp><cmp>cond18</cmp><cmp>rpt#@?or#$?unita_occupata#%?{}#%?txt#%?&quot;#$?unita_occupata#%?{}#%?txt#%?,#@?set#%?441#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>11</cmp><cmp>cond18</cmp><cmp>rpt#@?#@?set#%?441#%?.=#%?var#%?unita_occupata#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>12</cmp><cmp>cond18</cmp><cmp>rpt#@?or#$?unita_occupata#%?{}#%?txt#%?&quot;#$?unita_occupata#%?{}#%?txt#%?,#@?set#%?441#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>13</cmp><cmp>cond18</cmp><cmp>rpt#@?#@?set#%?442#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>14</cmp><cmp>cond18</cmp><cmp>rpt#@?or#$?nome_tariffa#%?{}#%?txt#%?&quot;#$?nome_tariffa#%?{}#%?txt#%?,#@?set#%?442#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>15</cmp><cmp>cond18</cmp><cmp>rpt#@?#@?set#%?442#%?.=#%?var#%?nome_tariffa#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>16</cmp><cmp>cond18</cmp><cmp>rpt#@?or#$?nome_tariffa#%?{}#%?txt#%?&quot;#$?nome_tariffa#%?{}#%?txt#%?,#@?set#%?442#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>17</cmp><cmp>cond18</cmp><cmp>rpt#@?#@?set#%?443#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>18</cmp><cmp>cond18</cmp><cmp>rpt#@?or#$?email#%?{}#%?txt#%?&quot;#$?email#%?{}#%?txt#%?,#@?set#%?443#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>19</cmp><cmp>cond18</cmp><cmp>rpt#@?#@?set#%?443#%?.=#%?var#%?email#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>20</cmp><cmp>cond18</cmp><cmp>rpt#@?or#$?email#%?{}#%?txt#%?&quot;#$?email#%?{}#%?txt#%?,#@?set#%?443#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>21</cmp><cmp>cond18</cmp><cmp>rpt#@?#@?set#%?444#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>22</cmp><cmp>cond18</cmp><cmp>rpt#@?or#$?telefono#%?{}#%?txt#%?&quot;#$?telefono#%?{}#%?txt#%?,#@?set#%?444#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>23</cmp><cmp>cond18</cmp><cmp>rpt#@?#@?set#%?444#%?.=#%?var#%?telefono#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>24</cmp><cmp>cond18</cmp><cmp>rpt#@?or#$?telefono#%?{}#%?txt#%?&quot;#$?telefono#%?{}#%?txt#%?,#@?set#%?444#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>25</cmp><cmp>cond18</cmp><cmp>rpt#@?#@?set#%?445#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>26</cmp><cmp>cond18</cmp><cmp>rpt#@?or#$?costo_tariffa#%?{}#%?txt#%?&quot;#$?costo_tariffa#%?{}#%?txt#%?,#@?set#%?445#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>27</cmp><cmp>cond18</cmp><cmp>rpt#@?#@?set#%?445#%?.=#%?var#%?costo_tariffa#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>28</cmp><cmp>cond18</cmp><cmp>rpt#@?or#$?costo_tariffa#%?{}#%?txt#%?&quot;#$?costo_tariffa#%?{}#%?txt#%?,#@?set#%?445#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>29</cmp><cmp>cond18</cmp><cmp>rpt#@?#@?set#%?446#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>30</cmp><cmp>cond18</cmp><cmp>rpt#@?or#$?costo_tot#%?{}#%?txt#%?&quot;#$?costo_tot#%?{}#%?txt#%?,#@?set#%?446#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>31</cmp><cmp>cond18</cmp><cmp>rpt#@?#@?set#%?446#%?.=#%?var#%?costo_tot#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>32</cmp><cmp>cond18</cmp><cmp>rpt#@?or#$?costo_tot#%?{}#%?txt#%?&quot;#$?costo_tot#%?{}#%?txt#%?,#@?set#%?446#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>33</cmp><cmp>cond18</cmp><cmp>rpt#@?#@?set#%?447#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>34</cmp><cmp>cond18</cmp><cmp>rpt#@?or#$?pagato#%?{}#%?txt#%?&quot;#$?pagato#%?{}#%?txt#%?,#@?set#%?447#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>35</cmp><cmp>cond18</cmp><cmp>rpt#@?#@?set#%?447#%?.=#%?var#%?pagato#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>36</cmp><cmp>cond18</cmp><cmp>rpt#@?or#$?pagato#%?{}#%?txt#%?&quot;#$?pagato#%?{}#%?txt#%?,#@?set#%?447#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>37</cmp><cmp>cond18</cmp><cmp>rpt#@?#@?set#%?448#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>38</cmp><cmp>cond18</cmp><cmp>rpt#@?or#$?num_persone_tot#%?{}#%?txt#%?&quot;#$?num_persone_tot#%?{}#%?txt#%?,#@?set#%?448#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>39</cmp><cmp>cond18</cmp><cmp>rpt#@?#@?set#%?448#%?.=#%?var#%?num_persone_tot#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>40</cmp><cmp>cond18</cmp><cmp>rpt#@?or#$?num_persone_tot#%?{}#%?txt#%?&quot;#$?num_persone_tot#%?{}#%?txt#%?,#@?set#%?448#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>48</cmp><cmp>cond18</cmp><cmp>rpt#@?#@?set#%?449#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>49</cmp><cmp>cond18</cmp><cmp>rpt#@?or#$?commento#%?{}#%?txt#%?&quot;#$?commento#%?{}#%?txt#%?,#@?set#%?449#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>50</cmp><cmp>cond18</cmp><cmp>rpt#@?#@?set#%?449#%?.=#%?var#%?commento#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>51</cmp><cmp>cond18</cmp><cmp>rpt#@?#@?set#%?449#%?=#%?var#%?commento_rcsv#%?var#%?avanzamento_riga#%?txt#%?#%?</cmp></riga>
<riga><cmp>56</cmp><cmp>cond18</cmp><cmp>rpt#@?or#$?commento#%?{}#%?txt#%?&quot;#$?commento#%?{}#%?txt#%?,#@?set#%?449#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>79</cmp><cmp>cond18</cmp><cmp>rpt#@?#@?date#%?450#%?data_inizio#%?is#%?0#%?g</cmp></riga>
<riga><cmp>80</cmp><cmp>cond18</cmp><cmp>rpt#@?#@?date#%?451#%?data_fine#%?is#%?0#%?g</cmp></riga>
<riga><cmp>1</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?312#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>2</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?cognome#%?{}#%?txt#%?&quot;#$?cognome#%?{}#%?txt#%?,#@?set#%?312#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>3</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?312#%?.=#%?var#%?cognome#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>4</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?cognome#%?{}#%?txt#%?&quot;#$?cognome#%?{}#%?txt#%?,#@?set#%?312#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>5</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?313#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>6</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?nome#%?{}#%?txt#%?&quot;#$?nome#%?{}#%?txt#%?,#@?set#%?313#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>7</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?313#%?.=#%?var#%?nome#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>8</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?nome#%?{}#%?txt#%?&quot;#$?nome#%?{}#%?txt#%?,#@?set#%?313#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>9</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?314#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>10</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?soprannome#%?{}#%?txt#%?&quot;#$?soprannome#%?{}#%?txt#%?,#@?set#%?314#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>11</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?314#%?.=#%?var#%?soprannome#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>12</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?soprannome#%?{}#%?txt#%?&quot;#$?soprannome#%?{}#%?txt#%?,#@?set#%?314#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>13</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?315#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>14</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?titolo#%?{}#%?txt#%?&quot;#$?titolo#%?{}#%?txt#%?,#@?set#%?315#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>15</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?315#%?.=#%?var#%?titolo#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>16</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?titolo#%?{}#%?txt#%?&quot;#$?titolo#%?{}#%?txt#%?,#@?set#%?315#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>17</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?316#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>18</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?email#%?{}#%?txt#%?&quot;#$?email#%?{}#%?txt#%?,#@?set#%?316#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>19</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?316#%?.=#%?var#%?email#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>20</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?email#%?{}#%?txt#%?&quot;#$?email#%?{}#%?txt#%?,#@?set#%?316#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>21</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?317#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>22</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?telefono#%?{}#%?txt#%?&quot;#$?telefono#%?{}#%?txt#%?,#@?set#%?317#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>23</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?317#%?.=#%?var#%?telefono#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>24</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?telefono#%?{}#%?txt#%?&quot;#$?telefono#%?{}#%?txt#%?,#@?set#%?317#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>25</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?318#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>26</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?fax#%?{}#%?txt#%?&quot;#$?fax#%?{}#%?txt#%?,#@?set#%?318#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>27</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?318#%?.=#%?var#%?fax#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>28</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?fax#%?{}#%?txt#%?&quot;#$?fax#%?{}#%?txt#%?,#@?set#%?318#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>29</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?319#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>30</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?nazione#%?{}#%?txt#%?&quot;#$?nazione#%?{}#%?txt#%?,#@?set#%?319#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>31</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?319#%?.=#%?var#%?nazione#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>32</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?nazione#%?{}#%?txt#%?&quot;#$?nazione#%?{}#%?txt#%?,#@?set#%?319#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>33</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?320#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>34</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?regione#%?{}#%?txt#%?&quot;#$?regione#%?{}#%?txt#%?,#@?set#%?320#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>35</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?320#%?.=#%?var#%?regione#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>36</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?regione#%?{}#%?txt#%?&quot;#$?regione#%?{}#%?txt#%?,#@?set#%?320#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>37</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?321#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>38</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?citta#%?{}#%?txt#%?&quot;#$?citta#%?{}#%?txt#%?,#@?set#%?321#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>39</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?321#%?.=#%?var#%?citta#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>40</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?citta#%?{}#%?txt#%?&quot;#$?citta#%?{}#%?txt#%?,#@?set#%?321#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>41</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?327#%?=#%?var#%?via#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>42</cmp><cmp>cond17</cmp><cmp>rpt#@?#$?numcivico#%?!=#%?txt#%?#@?set#%?327#%?.=#%?txt#%? #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>43</cmp><cmp>cond17</cmp><cmp>rpt#@?#$?numcivico#%?!=#%?txt#%?#@?set#%?327#%?.=#%?var#%?numcivico#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>44</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?322#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>45</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?tmp_csv#%?{}#%?txt#%?&quot;#$?tmp_csv#%?{}#%?txt#%?,#@?set#%?322#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>46</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?322#%?.=#%?var#%?tmp_csv#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>47</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?tmp_csv#%?{}#%?txt#%?&quot;#$?tmp_csv#%?{}#%?txt#%?,#@?set#%?322#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>48</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?323#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>49</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?cap#%?{}#%?txt#%?&quot;#$?cap#%?{}#%?txt#%?,#@?set#%?323#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>50</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?323#%?.=#%?var#%?cap#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>51</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?cap#%?{}#%?txt#%?&quot;#$?cap#%?{}#%?txt#%?,#@?set#%?323#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>52</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?324#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>53</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?cittadinanza#%?{}#%?txt#%?&quot;#$?cittadinanza#%?{}#%?txt#%?,#@?set#%?324#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>54</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?324#%?.=#%?var#%?cittadinanza#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>55</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?cittadinanza#%?{}#%?txt#%?&quot;#$?cittadinanza#%?{}#%?txt#%?,#@?set#%?324#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>56</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?325#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>57</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?date#%?325#%?data_nascita#%?da#%?0#%?g</cmp></riga>
<riga><cmp>58</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?326#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>59</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?partita_iva#%?{}#%?txt#%?&quot;#$?partita_iva#%?{}#%?txt#%?,#@?set#%?326#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>60</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?326#%?.=#%?var#%?partita_iva#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>61</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?partita_iva#%?{}#%?txt#%?&quot;#$?partita_iva#%?{}#%?txt#%?,#@?set#%?326#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>62</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?328#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>63</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?email2#%?{}#%?txt#%?&quot;#$?email2#%?{}#%?txt#%?,#@?set#%?328#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>64</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?328#%?.=#%?var#%?email2#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>65</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?email2#%?{}#%?txt#%?&quot;#$?email2#%?{}#%?txt#%?,#@?set#%?328#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>66</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?329#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>67</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?email_certificata#%?{}#%?txt#%?&quot;#$?email_certificata#%?{}#%?txt#%?,#@?set#%?329#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>68</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?329#%?.=#%?var#%?email_certificata#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>69</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?email_certificata#%?{}#%?txt#%?&quot;#$?email_certificata#%?{}#%?txt#%?,#@?set#%?329#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>70</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?330#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>71</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?telefono2#%?{}#%?txt#%?&quot;#$?telefono2#%?{}#%?txt#%?,#@?set#%?330#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>72</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?330#%?.=#%?var#%?telefono2#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>73</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?telefono2#%?{}#%?txt#%?&quot;#$?telefono2#%?{}#%?txt#%?,#@?set#%?330#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>74</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?331#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>75</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?telefono3#%?{}#%?txt#%?&quot;#$?telefono3#%?{}#%?txt#%?,#@?set#%?331#%?=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>76</cmp><cmp>cond17</cmp><cmp>rpt#@?#@?set#%?331#%?.=#%?var#%?telefono3#%?txt#%?&quot;#%?txt#%?""#%?</cmp></riga>
<riga><cmp>77</cmp><cmp>cond17</cmp><cmp>rpt#@?or#$?telefono3#%?{}#%?txt#%?&quot;#$?telefono3#%?{}#%?txt#%?,#@?set#%?331#%?.=#%?txt#%?"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>5</cmp><cmp>cond15</cmp><cmp>ind#@?#@?array#%?a2305#%?dat#%?</cmp></riga>
<riga><cmp>6</cmp><cmp>cond15</cmp><cmp>ind#@?#@?unset#%?a2308</cmp></riga>
<riga><cmp>7</cmp><cmp>cond15</cmp><cmp>ind#@?#@?unset#%?a2309</cmp></riga>
<riga><cmp>8</cmp><cmp>cond15</cmp><cmp>ind#@?#@?unset#%?a2311</cmp></riga>
<riga><cmp>9</cmp><cmp>cond15</cmp><cmp>ind#@?#@?unset#%?a2312</cmp></riga>
<riga><cmp>10</cmp><cmp>cond15</cmp><cmp>ind#@?#@?unset#%?a2313</cmp></riga>
<riga><cmp>27</cmp><cmp>cond15</cmp><cmp>ind#@?#@?unset#%?a2314</cmp></riga>
<riga><cmp>29</cmp><cmp>cond15</cmp><cmp>rpt#@?or#$?nome_unita#%?=#%?txt#%?#$?struttura_chiusa_c59m#%?=#%?txt#%?X#$?numero_ripetizione_prenotazioni#%?!=#%?txt#%?1#@?break#%?cont</cmp></riga>
<riga><cmp>40</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?camere_disponibili_c59m#%?=#%?txt#%?__________________________#@?set#%?307#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>41</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?letti_disponibili_c59m#%?=#%?txt#%?______________________#@?set#%?308#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>42</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?307#%?camere_disponibili_c59m#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>44</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?308#%?letti_disponibili_c59m#%?+#%?var#%?capacita_unita#%?</cmp></riga>
<riga><cmp>45</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?cont</cmp></riga>
<riga><cmp>46</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?date#%?272#%?date_c59m(data_c59m)#%?gi#%?0#%?g</cmp></riga>
<riga><cmp>48</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?date#%?306#%?date_c59m(data_c59m)#%?me#%?0#%?g</cmp></riga>
<riga><cmp>49</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?mese_attuale_c59m#%?!=#%?var#%?mese_c59m#@?break#%?</cmp></riga>
<riga><cmp>51</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?275#%?=#%?var#%?codice_nazione_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>53</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?nazione_c59m#%?=#%?txt#%?#@?set#%?275#%?=#%?var#%?codice_cittadinanza_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>54</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?405#%?=#%?var#%?nazione_c59m#%?txt#%?1#%?txt#%?#%?</cmp></riga>
<riga><cmp>55</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?var_tmp_c59m#%?=#%?var#%?nazione_c59m#@?break#%?cont</cmp></riga>
<riga><cmp>56</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?275#%?=#%?var#%?codice2_nazione_ospite#%?txt#%?.#%?txt#%?#%?</cmp></riga>
<riga><cmp>57</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?nazione_c59m#%?=#%?txt#%?#@?set#%?275#%?=#%?var#%?codice2_cittadinanza_ospite#%?txt#%?.#%?txt#%?#%?</cmp></riga>
<riga><cmp>59</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?cont</cmp></riga>
<riga><cmp>60</cmp><cmp>cond15</cmp><cmp>rpt#@?or#$?nazione_c59m#%?=#%?txt#%?AL#$?nazione_c59m#%?=#%?txt#%?ME#$?nazione_c59m#%?=#%?txt#%?XK#$?nazione_c59m#%?=#%?txt#%?MC#$?nazione_c59m#%?=#%?txt#%?AD#$?nazione_c59m#%?=#%?txt#%?AM#$?nazione_c59m#%?=#%?txt#%?AZ#$?nazione_c59m#%?=#%?txt#%?BY#$?nazione_c59m#%?=#%?txt#%?BA#$?nazione_c59m#%?=#%?txt#%?VA#$?nazione_c59m#%?=#%?txt#%?FO#$?nazione_c59m#%?=#%?txt#%?GE#$?nazione_c59m#%?=#%?txt#%?GI#$?nazione_c59m#%?=#%?txt#%?IS#$?nazione_c59m#%?=#%?txt#%?YU#$?nazione_c59m#%?=#%?txt#%?MK#$?nazione_c59m#%?=#%?txt#%?MD#$?nazione_c59m#%?=#%?txt#%?SK#$?nazione_c59m#%?=#%?txt#%?SM#@?set#%?275#%?=#%?txt#%?100#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>61</cmp><cmp>cond15</cmp><cmp>rpt#@?or#$?nazione_c59m#%?=#%?txt#%?CH#$?nazione_c59m#%?=#%?txt#%?LI#@?set#%?275#%?=#%?txt#%?036#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>63</cmp><cmp>cond15</cmp><cmp>rpt#@?or#$?nazione_c59m#%?=#%?txt#%?PM#$?nazione_c59m#%?=#%?txt#%?BM#$?nazione_c59m#%?=#%?txt#%?BS#$?nazione_c59m#%?=#%?txt#%?GL#@?set#%?275#%?=#%?txt#%?410#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>64</cmp><cmp>cond15</cmp><cmp>rpt#@?or#$?nazione_c59m#%?=#%?txt#%?BO#$?nazione_c59m#%?=#%?txt#%?PE#$?nazione_c59m#%?=#%?txt#%?CO#$?nazione_c59m#%?=#%?txt#%?AI#$?nazione_c59m#%?=#%?txt#%?AG#$?nazione_c59m#%?=#%?txt#%?AN#$?nazione_c59m#%?=#%?txt#%?BB#$?nazione_c59m#%?=#%?txt#%?BZ#$?nazione_c59m#%?=#%?txt#%?KY#$?nazione_c59m#%?=#%?txt#%?CL#$?nazione_c59m#%?=#%?txt#%?CR#$?nazione_c59m#%?=#%?txt#%?CU#$?nazione_c59m#%?=#%?txt#%?DM#$?nazione_c59m#%?=#%?txt#%?EC#$?nazione_c59m#%?=#%?txt#%?SV#$?nazione_c59m#%?=#%?txt#%?JM#$?nazione_c59m#%?=#%?txt#%?GD#$?nazione_c59m#%?=#%?txt#%?GT#$?nazione_c59m#%?=#%?txt#%?GY#$?nazione_c59m#%?=#%?txt#%?HT#$?nazione_c59m#%?=#%?txt#%?HN#$?nazione_c59m#%?=#%?txt#%?VI#$?nazione_c59m#%?=#%?txt#%?FK#$?nazione_c59m#%?=#%?txt#%?MS#$?nazione_c59m#%?=#%?txt#%?NI#$?nazione_c59m#%?=#%?txt#%?PA#$?nazione_c59m#%?=#%?txt#%?PY#$?nazione_c59m#%?=#%?txt#%?DO#$?nazione_c59m#%?=#%?txt#%?VC#$?nazione_c59m#%?=#%?txt#%?KN#$?nazione_c59m#%?=#%?txt#%?LC#$?nazione_c59m#%?=#%?txt#%?SR#$?nazione_c59m#%?=#%?txt#%?TC#$?nazione_c59m#%?=#%?txt#%?VG#$?nazione_c59m#%?=#%?txt#%?TT#$?nazione_c59m#%?=#%?txt#%?UY#@?set#%?275#%?=#%?txt#%?530#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>65</cmp><cmp>cond15</cmp><cmp>rpt#@?or#$?nazione_c59m#%?=#%?txt#%?LB#$?nazione_c59m#%?=#%?txt#%?SY#$?nazione_c59m#%?=#%?txt#%?JO#$?nazione_c59m#%?=#%?txt#%?SA#$?nazione_c59m#%?=#%?txt#%?BH#$?nazione_c59m#%?=#%?txt#%?AE#$?nazione_c59m#%?=#%?txt#%?IR#$?nazione_c59m#%?=#%?txt#%?IQ#$?nazione_c59m#%?=#%?txt#%?KW#$?nazione_c59m#%?=#%?txt#%?OM#$?nazione_c59m#%?=#%?txt#%?PS#$?nazione_c59m#%?=#%?txt#%?QA#$?nazione_c59m#%?=#%?txt#%?YE#@?set#%?275#%?=#%?txt#%?750#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>66</cmp><cmp>cond15</cmp><cmp>rpt#@?or#$?nazione_c59m#%?=#%?txt#%?PK#$?nazione_c59m#%?=#%?txt#%?MM#$?nazione_c59m#%?=#%?txt#%?BD#$?nazione_c59m#%?=#%?txt#%?AF#$?nazione_c59m#%?=#%?txt#%?BT#$?nazione_c59m#%?=#%?txt#%?BN#$?nazione_c59m#%?=#%?txt#%?KH#$?nazione_c59m#%?=#%?txt#%?CN#$?nazione_c59m#%?=#%?txt#%?TW#$?nazione_c59m#%?=#%?txt#%?KP#$?nazione_c59m#%?=#%?txt#%?PH#$?nazione_c59m#%?=#%?txt#%?HK#$?nazione_c59m#%?=#%?txt#%?ID#$?nazione_c59m#%?=#%?txt#%?KZ#$?nazione_c59m#%?=#%?txt#%?KG#$?nazione_c59m#%?=#%?txt#%?LA#$?nazione_c59m#%?=#%?txt#%?MO#$?nazione_c59m#%?=#%?txt#%?MY#$?nazione_c59m#%?=#%?txt#%?MV#$?nazione_c59m#%?=#%?txt#%?MN#$?nazione_c59m#%?=#%?txt#%?NP#$?nazione_c59m#%?=#%?txt#%?SG#$?nazione_c59m#%?=#%?txt#%?TJ#$?nazione_c59m#%?=#%?txt#%?LK#$?nazione_c59m#%?=#%?txt#%?UZ#$?nazione_c59m#%?=#%?txt#%?TH#$?nazione_c59m#%?=#%?txt#%?TM#$?nazione_c59m#%?=#%?txt#%?TL#$?nazione_c59m#%?=#%?txt#%?VN#@?set#%?275#%?=#%?txt#%?760#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>67</cmp><cmp>cond15</cmp><cmp>rpt#@?or#$?nazione_c59m#%?=#%?txt#%?MA#$?nazione_c59m#%?=#%?txt#%?DZ#$?nazione_c59m#%?=#%?txt#%?TN#$?nazione_c59m#%?=#%?txt#%?LY#@?set#%?275#%?=#%?txt#%?230#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>68</cmp><cmp>cond15</cmp><cmp>rpt#@?or#$?nazione_c59m#%?=#%?txt#%?KE#$?nazione_c59m#%?=#%?txt#%?SS#$?nazione_c59m#%?=#%?txt#%?LR#$?nazione_c59m#%?=#%?txt#%?AO#$?nazione_c59m#%?=#%?txt#%?BJ#$?nazione_c59m#%?=#%?txt#%?BW#$?nazione_c59m#%?=#%?txt#%?BF#$?nazione_c59m#%?=#%?txt#%?BI#$?nazione_c59m#%?=#%?txt#%?CM#$?nazione_c59m#%?=#%?txt#%?CV#$?nazione_c59m#%?=#%?txt#%?CF#$?nazione_c59m#%?=#%?txt#%?TD#$?nazione_c59m#%?=#%?txt#%?KM#$?nazione_c59m#%?=#%?txt#%?CG#$?nazione_c59m#%?=#%?txt#%?CI#$?nazione_c59m#%?=#%?txt#%?ER#$?nazione_c59m#%?=#%?txt#%?ET#$?nazione_c59m#%?=#%?txt#%?GA#$?nazione_c59m#%?=#%?txt#%?GM#$?nazione_c59m#%?=#%?txt#%?GH#$?nazione_c59m#%?=#%?txt#%?DJ#$?nazione_c59m#%?=#%?txt#%?GN#$?nazione_c59m#%?=#%?txt#%?GW#$?nazione_c59m#%?=#%?txt#%?GQ#$?nazione_c59m#%?=#%?txt#%?LS#$?nazione_c59m#%?=#%?txt#%?MG#$?nazione_c59m#%?=#%?txt#%?ML#$?nazione_c59m#%?=#%?txt#%?MW#$?nazione_c59m#%?=#%?txt#%?MU#$?nazione_c59m#%?=#%?txt#%?MR#$?nazione_c59m#%?=#%?txt#%?YT#$?nazione_c59m#%?=#%?txt#%?MZ#$?nazione_c59m#%?=#%?txt#%?NA#$?nazione_c59m#%?=#%?txt#%?NE#$?nazione_c59m#%?=#%?txt#%?NG#$?nazione_c59m#%?=#%?txt#%?CD#$?nazione_c59m#%?=#%?txt#%?RW#$?nazione_c59m#%?=#%?txt#%?SC#$?nazione_c59m#%?=#%?txt#%?SN#$?nazione_c59m#%?=#%?txt#%?ST#$?nazione_c59m#%?=#%?txt#%?SL#$?nazione_c59m#%?=#%?txt#%?TG#$?nazione_c59m#%?=#%?txt#%?SD#$?nazione_c59m#%?=#%?txt#%?SO#$?nazione_c59m#%?=#%?txt#%?SZ#$?nazione_c59m#%?=#%?txt#%?TZ#$?nazione_c59m#%?=#%?txt#%?UG#$?nazione_c59m#%?=#%?txt#%?ZM#$?nazione_c59m#%?=#%?txt#%?ZW#$?nazione_c59m#%?=#%?txt#%?CD#@?set#%?275#%?=#%?txt#%?300#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>69</cmp><cmp>cond15</cmp><cmp>rpt#@?or#$?nazione_c59m#%?=#%?txt#%?NC#$?nazione_c59m#%?=#%?txt#%?VU#$?nazione_c59m#%?=#%?txt#%?FJ#$?nazione_c59m#%?=#%?txt#%?CX#$?nazione_c59m#%?=#%?txt#%?CC#$?nazione_c59m#%?=#%?txt#%?GU#$?nazione_c59m#%?=#%?txt#%?KI#$?nazione_c59m#%?=#%?txt#%?MP#$?nazione_c59m#%?=#%?txt#%?MH#$?nazione_c59m#%?=#%?txt#%?FM#$?nazione_c59m#%?=#%?txt#%?NF#$?nazione_c59m#%?=#%?txt#%?NR#$?nazione_c59m#%?=#%?txt#%?PG#$?nazione_c59m#%?=#%?txt#%?PW#$?nazione_c59m#%?=#%?txt#%?PN#$?nazione_c59m#%?=#%?txt#%?PF#$?nazione_c59m#%?=#%?txt#%?SB#$?nazione_c59m#%?=#%?txt#%?AS#$?nazione_c59m#%?=#%?txt#%?WS#$?nazione_c59m#%?=#%?txt#%?TK#$?nazione_c59m#%?=#%?txt#%?TO#$?nazione_c59m#%?=#%?txt#%?TV#$?nazione_c59m#%?=#%?txt#%?WF#@?set#%?275#%?=#%?txt#%?810#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>70</cmp><cmp>cond15</cmp><cmp>rpt#@?and#$?nazione_c59m#%?=#%?txt#%?#$?numero_ospite#%?=#%?txt#%?1#@?set#%?275#%?=#%?txt#%?777#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>71</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?nazione_c59m#%?=#%?txt#%?#@?break#%?</cmp></riga>
<riga><cmp>72</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?277#%?=#%?var#%?regione_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>73</cmp><cmp>cond15</cmp><cmp>rpt#@?and#$?provincia_c59m#%?=#%?txt#%?#$?numero_ospite#%?=#%?txt#%?1#@?set#%?277#%?=#%?txt#%?non dichiarata#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>74</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?265#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>77</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?nazione_c59m#%?=#%?txt#%?IT#@?set#%?265#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>78</cmp><cmp>cond15</cmp><cmp>rpt#@?and#$?provincia_c59m#%?=#%?txt#%?#$?italiano_c59m#%?=#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>79</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?269#%?=#%?var#%?num_persone_tot#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>80</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?num_persone_c59m#%?<#%?var#%?num_ospiti_tot#@?set#%?269#%?=#%?var#%?num_ospiti_tot#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>81</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?num_persone_c59m#%?=#%?txt#%?#@?break#%?</cmp></riga>
<riga><cmp>82</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?262#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>86</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?263#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>88</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?264#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>90</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?data_inizio#%?=#%?var#%?date_c59m(data_c59m)#@?set#%?263#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>91</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?data_fine#%?=#%?var#%?date_c59m(data_c59m)#@?set#%?264#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>92</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?284#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>93</cmp><cmp>cond15</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?arrivo_c59m#%?!=#%?txt#%?1#@?set#%?284#%?=#%?var#%?num_persone_c59m#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>94</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?279#%?cli_giorno_prec_c59m#%?+#%?var#%?agg_c59m#%?</cmp></riga>
<riga><cmp>95</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?284#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>96</cmp><cmp>cond15</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?arrivo_c59m#%?=#%?txt#%?1#@?set#%?284#%?=#%?var#%?num_persone_c59m#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>97</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?280#%?cli_arrivati_c59m#%?+#%?var#%?agg_c59m#%?</cmp></riga>
<riga><cmp>98</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?284#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>99</cmp><cmp>cond15</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?partenza_c59m#%?=#%?txt#%?1#@?set#%?284#%?=#%?var#%?num_persone_c59m#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>100</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?282#%?cli_partiti_c59m#%?+#%?var#%?agg_c59m#%?</cmp></riga>
<riga><cmp>101</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?281#%?cli_giorno_prec_c59m#%?+#%?var#%?cli_arrivati_c59m#%?</cmp></riga>
<riga><cmp>107</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?283#%?cli_totale_c59m#%?-#%?var#%?cli_partiti_c59m#%?</cmp></riga>
<riga><cmp>108</cmp><cmp>cond15</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?partenza_c59m#%?!=#%?txt#%?1#@?oper#%?299#%?camere_occupate_c59m#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>109</cmp><cmp>cond15</cmp><cmp>rpt#@?or#$?arrivo_c59m#%?=#%?txt#%?1#$?partenza_c59m#%?=#%?txt#%?1#@?set#%?262#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>110</cmp><cmp>cond15</cmp><cmp>rpt#@?and#$?arr_part_c59m#%?!=#%?txt#%?1#$?arr_part_c59m#%?=#%?txt#%?nascondi presenti#@?break#%?</cmp></riga>
<riga><cmp>111</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?301#%?=#%?txt#%?\u58748\'3f#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>112</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?302#%?=#%?txt#%?X#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>113</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?303#%?=#%?txt#%?___________#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>114</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?304#%?=#%?txt#%?___________#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>115</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?giorni_apertura_c59m#%?=#%?txt#%?_______#@?set#%?305#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>119</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?mostra_pag_c59m#%?!=#%?txt#%?1#@?oper#%?305#%?giorni_apertura_c59m#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>120</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?293#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>122</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?284#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>123</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?ultima_data_c59m#%?=#%?txt#%?#@?set#%?274#%?=#%?txt#%?-1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>124</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?ultima_data_c59m#%?!=#%?var#%?data_c59m#@?set#%?284#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>125</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?274#%?num_prog_c59m#%?+#%?var#%?agg_c59m#%?</cmp></riga>
<riga><cmp>127</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?294#%?=#%?var#%?data_c59m#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>128</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?num_prog_c59m#%?>#%?txt#%?0#@?set#%?295#%?=#%?txt#%?\par \page#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>129</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?numero_ospite#%?=#%?txt#%?1#@?set#%?276#%?=#%?var#%?nazione_c59m#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>130</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?numero_ospite#%?=#%?txt#%?1#@?set#%?278#%?=#%?var#%?provincia_c59m#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>131</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?285#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>133</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?nazione1_c59m#%?!=#%?var#%?nazione_c59m#@?set#%?285#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>134</cmp><cmp>cond15</cmp><cmp>rpt#@?or#$?numero_ospite#%?=#%?txt#%?1#$?italiano_c59m#%?=#%?txt#%?1#@?set#%?285#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>135</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?ospite_altra_naz_c59m#%?!=#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>137</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?286#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>138</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?provincia1_c59m#%?!=#%?var#%?provincia_c59m#@?set#%?286#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>139</cmp><cmp>cond15</cmp><cmp>rpt#@?or#$?numero_ospite#%?=#%?txt#%?1#$?italiano_c59m#%?!=#%?txt#%?1#@?set#%?286#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>141</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?ospite_altra_prov_c59m#%?!=#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>142</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?261#%?=#%?var#%?nazione_c59m#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>143</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?italiano_c59m#%?=#%?txt#%?1#@?set#%?261#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>144</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?266#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>147</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?267#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>148</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?268#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>149</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?296#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>150</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?284#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>151</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?numero_ospite#%?=#%?txt#%?1#@?set#%?284#%?=#%?var#%?num_persone_c59m#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>154</cmp><cmp>cond15</cmp><cmp>rpt#@?and#$?italiano_c59m#%?!=#%?txt#%?1#$?arrivo_c59m#%?=#%?txt#%?1#@?set#%?267#%?=#%?var#%?agg_c59m#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>155</cmp><cmp>cond15</cmp><cmp>rpt#@?and#$?italiano_c59m#%?!=#%?txt#%?1#$?partenza_c59m#%?=#%?txt#%?1#@?set#%?268#%?=#%?var#%?agg_c59m#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>156</cmp><cmp>cond15</cmp><cmp>rpt#@?and#$?italiano_c59m#%?!=#%?txt#%?1#$?partenza_c59m#%?!=#%?txt#%?1#@?set#%?296#%?=#%?var#%?agg_c59m#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>158</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?a2308#%?arrivi_naz_c59m(pos_c59m)#%?+#%?var#%?agg_arr_c59m#%?</cmp></riga>
<riga><cmp>159</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?a2309#%?partenze_naz_c59m(pos_c59m)#%?+#%?var#%?agg_part_c59m#%?</cmp></riga>
<riga><cmp>160</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?a2316#%?presenze_naz_c59m(pos_c59m)#%?+#%?var#%?agg_pres_c59m#%?</cmp></riga>
<riga><cmp>162</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?289#%?tot_arr_naz_c59m#%?+#%?var#%?agg_arr_c59m#%?</cmp></riga>
<riga><cmp>163</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?290#%?tot_part_naz_c59m#%?+#%?var#%?agg_part_c59m#%?</cmp></riga>
<riga><cmp>164</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?297#%?tot_pres_naz_c59m#%?+#%?var#%?agg_pres_c59m#%?</cmp></riga>
<riga><cmp>166</cmp><cmp>cond15</cmp><cmp>rpt#@?and#$?italiano_c59m#%?!=#%?txt#%?1#$?numero_ospite#%?=#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>167</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?288#%?num_prov_c59m#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>168</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?pos_prov_c59m(provincia_c59m)#%?!=#%?txt#%?#@?set#%?261#%?=#%?var#%?pos_prov_c59m(provincia_c59m)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>170</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?266#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>171</cmp><cmp>cond15</cmp><cmp>rpt#@?and#$?pos_prov_c59m(provincia_c59m)#%?=#%?txt#%?#$?italiano_c59m#%?=#%?txt#%?1#@?set#%?266#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>172</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?ins_nuovo_num_c59m#%?=#%?txt#%?1#@?set#%?261#%?=#%?var#%?prox_num_prov_c59m#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>173</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?ins_nuovo_num_c59m#%?=#%?txt#%?1#@?set#%?a2311#%?=#%?var#%?pos_c59m#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>174</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?ins_nuovo_num_c59m#%?=#%?txt#%?1#@?set#%?a2312#%?=#%?var#%?provincia_c59m#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>175</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?ins_nuovo_num_c59m#%?=#%?txt#%?1#@?set#%?287#%?=#%?var#%?prox_num_prov_c59m#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>176</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?267#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>177</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?268#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>179</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?296#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>181</cmp><cmp>cond15</cmp><cmp>rpt#@?and#$?italiano_c59m#%?=#%?txt#%?1#$?arrivo_c59m#%?=#%?txt#%?1#@?set#%?267#%?=#%?var#%?agg_c59m#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>183</cmp><cmp>cond15</cmp><cmp>rpt#@?and#$?italiano_c59m#%?=#%?txt#%?1#$?partenza_c59m#%?=#%?txt#%?1#@?set#%?268#%?=#%?var#%?agg_c59m#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>184</cmp><cmp>cond15</cmp><cmp>rpt#@?and#$?italiano_c59m#%?=#%?txt#%?1#$?partenza_c59m#%?!=#%?txt#%?1#@?set#%?296#%?=#%?var#%?agg_c59m#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>185</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?a2313#%?arrivi_prov_c59m(pos_c59m)#%?+#%?var#%?agg_arr_c59m#%?</cmp></riga>
<riga><cmp>187</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?a2314#%?partenze_prov_c59m(pos_c59m)#%?+#%?var#%?agg_part_c59m#%?</cmp></riga>
<riga><cmp>188</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?a2318#%?presenze_prov_c59m(pos_c59m)#%?+#%?var#%?agg_pres_c59m#%?</cmp></riga>
<riga><cmp>189</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?291#%?tot_arr_prov_c59m#%?+#%?var#%?agg_arr_c59m#%?</cmp></riga>
<riga><cmp>191</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?292#%?tot_part_prov_c59m#%?+#%?var#%?agg_part_c59m#%?</cmp></riga>
<riga><cmp>192</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?298#%?tot_pres_prov_c59m#%?+#%?var#%?agg_pres_c59m#%?</cmp></riga>
<riga><cmp>193</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?numero_ospite#%?=#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>194</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?nazione1_c59m#%?=#%?txt#%?#@?break#%?</cmp></riga>
<riga><cmp>195</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?275#%?=#%?var#%?nazione1_c59m#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>196</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?265#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>197</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?nazione_c59m#%?=#%?txt#%?IT#@?set#%?265#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>198</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?261#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>199</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?italiano_c59m#%?!=#%?txt#%?1#@?set#%?261#%?=#%?var#%?nazione_c59m#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>200</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?267#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>201</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?268#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>202</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?296#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>203</cmp><cmp>cond15</cmp><cmp>rpt#@?and#$?italiano_c59m#%?!=#%?txt#%?1#$?arrivo_c59m#%?=#%?txt#%?1#@?set#%?267#%?=#%?txt#%?-1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>205</cmp><cmp>cond15</cmp><cmp>rpt#@?and#$?italiano_c59m#%?!=#%?txt#%?1#$?partenza_c59m#%?=#%?txt#%?1#@?set#%?268#%?=#%?txt#%?-1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>206</cmp><cmp>cond15</cmp><cmp>rpt#@?and#$?italiano_c59m#%?!=#%?txt#%?1#$?partenza_c59m#%?!=#%?txt#%?1#@?set#%?296#%?=#%?txt#%?-1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>207</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?a2308#%?arrivi_naz_c59m(pos_c59m)#%?+#%?var#%?agg_arr_c59m#%?</cmp></riga>
<riga><cmp>208</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?a2309#%?partenze_naz_c59m(pos_c59m)#%?+#%?var#%?agg_part_c59m#%?</cmp></riga>
<riga><cmp>209</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?a2316#%?presenze_naz_c59m(pos_c59m)#%?+#%?var#%?agg_pres_c59m#%?</cmp></riga>
<riga><cmp>210</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?289#%?tot_arr_naz_c59m#%?+#%?var#%?agg_arr_c59m#%?</cmp></riga>
<riga><cmp>212</cmp><cmp>cond15</cmp><cmp>ind#@?#@?set#%?287#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>213</cmp><cmp>cond15</cmp><cmp>ind#@?#@?set#%?279#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>214</cmp><cmp>cond15</cmp><cmp>ind#@?#@?set#%?280#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>216</cmp><cmp>cond15</cmp><cmp>ind#@?#@?set#%?282#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>217</cmp><cmp>cond15</cmp><cmp>ind#@?#@?set#%?289#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>218</cmp><cmp>cond15</cmp><cmp>ind#@?#@?set#%?290#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>219</cmp><cmp>cond15</cmp><cmp>ind#@?#@?set#%?291#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>220</cmp><cmp>cond15</cmp><cmp>ind#@?#@?set#%?292#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>221</cmp><cmp>cond15</cmp><cmp>ind#@?#@?set#%?273#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>224</cmp><cmp>cond15</cmp><cmp>inr#@?#@?set#%?293#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>226</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?290#%?tot_part_naz_c59m#%?+#%?var#%?agg_part_c59m#%?</cmp></riga>
<riga><cmp>228</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?297#%?tot_pres_naz_c59m#%?+#%?var#%?agg_pres_c59m#%?</cmp></riga>
<riga><cmp>230</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?italiano_c59m#%?!=#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>231</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?277#%?=#%?var#%?provincia1_c59m#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>232</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?set#%?261#%?=#%?var#%?pos_prov_c59m(provincia_c59m)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>233</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?arrivo_c59m#%?=#%?txt#%?1#@?set#%?267#%?=#%?txt#%?-1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>234</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?partenza_c59m#%?=#%?txt#%?1#@?set#%?268#%?=#%?txt#%?-1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>235</cmp><cmp>cond15</cmp><cmp>rpt#@?#$?partenza_c59m#%?!=#%?txt#%?1#@?set#%?296#%?=#%?txt#%?-1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>236</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?a2313#%?arrivi_prov_c59m(pos_c59m)#%?+#%?var#%?agg_arr_c59m#%?</cmp></riga>
<riga><cmp>237</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?a2314#%?partenze_prov_c59m(pos_c59m)#%?+#%?var#%?agg_part_c59m#%?</cmp></riga>
<riga><cmp>238</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?a2318#%?presenze_prov_c59m(pos_c59m)#%?+#%?var#%?agg_pres_c59m#%?</cmp></riga>
<riga><cmp>239</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?291#%?tot_arr_prov_c59m#%?+#%?var#%?agg_arr_c59m#%?</cmp></riga>
<riga><cmp>240</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?292#%?tot_part_prov_c59m#%?+#%?var#%?agg_part_c59m#%?</cmp></riga>
<riga><cmp>241</cmp><cmp>cond15</cmp><cmp>ind#@?#@?unset#%?a2316</cmp></riga>
<riga><cmp>242</cmp><cmp>cond15</cmp><cmp>ind#@?#@?unset#%?a2318</cmp></riga>
<riga><cmp>243</cmp><cmp>cond15</cmp><cmp>ind#@?#@?unset#%?a2316</cmp></riga>
<riga><cmp>244</cmp><cmp>cond15</cmp><cmp>ind#@?#@?unset#%?a2318</cmp></riga>
<riga><cmp>245</cmp><cmp>cond15</cmp><cmp>ind#@?#@?set#%?298#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>246</cmp><cmp>cond15</cmp><cmp>ind#@?#@?set#%?297#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>247</cmp><cmp>cond15</cmp><cmp>rpt#@?#@?oper#%?298#%?tot_pres_prov_c59m#%?+#%?var#%?agg_pres_c59m#%?</cmp></riga>
<riga><cmp>248</cmp><cmp>cond15</cmp><cmp>ind#@?#@?set#%?299#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>249</cmp><cmp>cond15</cmp><cmp>ind#@?#@?date#%?271#%?data_inizio_selezione#%?me#%?1#%?g</cmp></riga>
<riga><cmp>250</cmp><cmp>cond15</cmp><cmp>ind#@?#@?date#%?270#%?data_inizio_selezione#%?an#%?1#%?g</cmp></riga>
<riga><cmp>251</cmp><cmp>cond15</cmp><cmp>ind#@?#@?date#%?296#%?data_inizio_selezione#%?me#%?0#%?g</cmp></riga>
<riga><cmp>252</cmp><cmp>cond15</cmp><cmp>ind#@?#$?mese_c59m#%?=#%?var#%?agg_pres_c59m#@?set#%?-1#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>253</cmp><cmp>cond15</cmp><cmp>ind#@?#@?date#%?296#%?data_fine_selezione#%?me#%?-1#%?g</cmp></riga>
<riga><cmp>254</cmp><cmp>cond15</cmp><cmp>ind#@?#$?mese_c59m#%?!=#%?var#%?agg_pres_c59m#@?set#%?-1#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>255</cmp><cmp>cond15</cmp><cmp>ind#@?#@?date#%?296#%?data_fine_selezione#%?me#%?0#%?g</cmp></riga>
<riga><cmp>256</cmp><cmp>cond15</cmp><cmp>ind#@?#$?mese_c59m#%?=#%?var#%?agg_pres_c59m#@?set#%?-1#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>257</cmp><cmp>cond15</cmp><cmp>ind#@?#$?messaggio_di_errore#%?=#%?txt#%?1#@?set#%?-1#%?=#%?txt#%?Questo documento deve essere selezionato da sotto allla tabella del mese per cui deve essere generato#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>258</cmp><cmp>cond15</cmp><cmp>ind#@?#@?set#%?300#%?=#%?var#%?comune_struttura#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>259</cmp><cmp>cond15</cmp><cmp>ind#@?#$?comune_c59m#%?=#%?txt#%?#@?set#%?300#%?=#%?txt#%?_________________________#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>260</cmp><cmp>cond15</cmp><cmp>ind#@?#@?set#%?301#%?=#%?txt#%?X#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>261</cmp><cmp>cond15</cmp><cmp>ind#@?#@?set#%?302#%?=#%?txt#%?\u58748\'3f#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>262</cmp><cmp>cond15</cmp><cmp>ind#@?#@?date#%?303#%?data_inizio_selezione#%?da#%?1#%?g</cmp></riga>
<riga><cmp>263</cmp><cmp>cond15</cmp><cmp>ind#@?#@?date#%?304#%?data_fine_selezione#%?da#%?-1#%?g</cmp></riga>
<riga><cmp>264</cmp><cmp>cond15</cmp><cmp>ind#@?#@?set#%?305#%?=#%?txt#%?_______#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>265</cmp><cmp>cond15</cmp><cmp>ind#@?#@?set#%?307#%?=#%?txt#%?__________________________#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>266</cmp><cmp>cond15</cmp><cmp>ind#@?#@?set#%?308#%?=#%?txt#%?______________________#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>267</cmp><cmp>cond15</cmp><cmp>ind#@?#@?set#%?309#%?=#%?var#%?nome_contatto_struttura#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>268</cmp><cmp>cond15</cmp><cmp>ind#@?#@?set#%?310#%?=#%?var#%?email_struttura#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>269</cmp><cmp>cond15</cmp><cmp>ind#@?#@?set#%?311#%?=#%?var#%?telefono_struttura#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>270</cmp><cmp>cond15</cmp><cmp>ind#@?#$?nome_contatto_c59m#%?=#%?txt#%?#@?set#%?309#%?=#%?txt#%?________________________________________________________________________________________#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>271</cmp><cmp>cond15</cmp><cmp>ind#@?#$?email_contatto_c59m#%?=#%?txt#%?#@?set#%?310#%?=#%?txt#%?___________________________________________________________#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>272</cmp><cmp>cond15</cmp><cmp>ind#@?#$?telefono_contatto_c59m#%?=#%?txt#%?#@?set#%?311#%?=#%?txt#%?________________________#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>5</cmp><cmp>cond14</cmp><cmp>inr#@?#@?unset#%?a218</cmp></riga>
<riga><cmp>6</cmp><cmp>cond14</cmp><cmp>inr#@?#@?unset#%?a219</cmp></riga>
<riga><cmp>7</cmp><cmp>cond14</cmp><cmp>inr#@?#@?unset#%?a221</cmp></riga>
<riga><cmp>8</cmp><cmp>cond14</cmp><cmp>inr#@?#@?unset#%?a222</cmp></riga>
<riga><cmp>9</cmp><cmp>cond14</cmp><cmp>inr#@?#@?unset#%?a223</cmp></riga>
<riga><cmp>10</cmp><cmp>cond14</cmp><cmp>inr#@?#@?unset#%?a224</cmp></riga>
<riga><cmp>27</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?date#%?118#%?date_istat(data_istat)#%?an#%?0#%?g</cmp></riga>
<riga><cmp>29</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?date#%?119#%?date_istat(data_istat)#%?me#%?0#%?g</cmp></riga>
<riga><cmp>31</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?date#%?120#%?date_istat(data_istat)#%?gi#%?0#%?g</cmp></riga>
<riga><cmp>40</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?123#%?=#%?var#%?codice_nazione_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>41</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?nazione_istat#%?=#%?txt#%?#@?set#%?123#%?=#%?var#%?codice_cittadinanza_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>42</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?404#%?=#%?var#%?nazione_istat#%?txt#%?1#%?txt#%?#%?</cmp></riga>
<riga><cmp>44</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?var_tmp_istat#%?=#%?var#%?nazione_istat#@?break#%?cont</cmp></riga>
<riga><cmp>45</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?123#%?=#%?var#%?codice2_nazione_ospite#%?txt#%?.#%?txt#%?#%?</cmp></riga>
<riga><cmp>46</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?nazione_istat#%?=#%?txt#%?#@?set#%?123#%?=#%?var#%?codice2_cittadinanza_ospite#%?txt#%?.#%?txt#%?#%?</cmp></riga>
<riga><cmp>48</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?cont</cmp></riga>
<riga><cmp>49</cmp><cmp>cond14</cmp><cmp>rpt#@?or#$?nazione_istat#%?=#%?txt#%?AL#$?nazione_istat#%?=#%?txt#%?ME#$?nazione_istat#%?=#%?txt#%?XK#$?nazione_istat#%?=#%?txt#%?MC#$?nazione_istat#%?=#%?txt#%?AD#$?nazione_istat#%?=#%?txt#%?AM#$?nazione_istat#%?=#%?txt#%?AZ#$?nazione_istat#%?=#%?txt#%?BY#$?nazione_istat#%?=#%?txt#%?BA#$?nazione_istat#%?=#%?txt#%?VA#$?nazione_istat#%?=#%?txt#%?FO#$?nazione_istat#%?=#%?txt#%?GE#$?nazione_istat#%?=#%?txt#%?GI#$?nazione_istat#%?=#%?txt#%?IS#$?nazione_istat#%?=#%?txt#%?YU#$?nazione_istat#%?=#%?txt#%?MK#$?nazione_istat#%?=#%?txt#%?MD#$?nazione_istat#%?=#%?txt#%?SK#$?nazione_istat#%?=#%?txt#%?SM#@?set#%?123#%?=#%?txt#%?100#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>51</cmp><cmp>cond14</cmp><cmp>rpt#@?or#$?nazione_istat#%?=#%?txt#%?CH#$?nazione_istat#%?=#%?txt#%?LI#@?set#%?123#%?=#%?txt#%?036#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>53</cmp><cmp>cond14</cmp><cmp>rpt#@?or#$?nazione_istat#%?=#%?txt#%?PM#$?nazione_istat#%?=#%?txt#%?BM#$?nazione_istat#%?=#%?txt#%?BS#$?nazione_istat#%?=#%?txt#%?GL#@?set#%?123#%?=#%?txt#%?410#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>54</cmp><cmp>cond14</cmp><cmp>rpt#@?or#$?nazione_istat#%?=#%?txt#%?BO#$?nazione_istat#%?=#%?txt#%?PE#$?nazione_istat#%?=#%?txt#%?CO#$?nazione_istat#%?=#%?txt#%?AI#$?nazione_istat#%?=#%?txt#%?AG#$?nazione_istat#%?=#%?txt#%?AN#$?nazione_istat#%?=#%?txt#%?BB#$?nazione_istat#%?=#%?txt#%?BZ#$?nazione_istat#%?=#%?txt#%?KY#$?nazione_istat#%?=#%?txt#%?CL#$?nazione_istat#%?=#%?txt#%?CR#$?nazione_istat#%?=#%?txt#%?CU#$?nazione_istat#%?=#%?txt#%?DM#$?nazione_istat#%?=#%?txt#%?EC#$?nazione_istat#%?=#%?txt#%?SV#$?nazione_istat#%?=#%?txt#%?JM#$?nazione_istat#%?=#%?txt#%?GD#$?nazione_istat#%?=#%?txt#%?GT#$?nazione_istat#%?=#%?txt#%?GY#$?nazione_istat#%?=#%?txt#%?HT#$?nazione_istat#%?=#%?txt#%?HN#$?nazione_istat#%?=#%?txt#%?VI#$?nazione_istat#%?=#%?txt#%?FK#$?nazione_istat#%?=#%?txt#%?MS#$?nazione_istat#%?=#%?txt#%?NI#$?nazione_istat#%?=#%?txt#%?PA#$?nazione_istat#%?=#%?txt#%?PY#$?nazione_istat#%?=#%?txt#%?DO#$?nazione_istat#%?=#%?txt#%?VC#$?nazione_istat#%?=#%?txt#%?KN#$?nazione_istat#%?=#%?txt#%?LC#$?nazione_istat#%?=#%?txt#%?SR#$?nazione_istat#%?=#%?txt#%?TC#$?nazione_istat#%?=#%?txt#%?VG#$?nazione_istat#%?=#%?txt#%?TT#$?nazione_istat#%?=#%?txt#%?UY#@?set#%?123#%?=#%?txt#%?530#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>55</cmp><cmp>cond14</cmp><cmp>rpt#@?or#$?nazione_istat#%?=#%?txt#%?LB#$?nazione_istat#%?=#%?txt#%?SY#$?nazione_istat#%?=#%?txt#%?JO#$?nazione_istat#%?=#%?txt#%?SA#$?nazione_istat#%?=#%?txt#%?BH#$?nazione_istat#%?=#%?txt#%?AE#$?nazione_istat#%?=#%?txt#%?IR#$?nazione_istat#%?=#%?txt#%?IQ#$?nazione_istat#%?=#%?txt#%?KW#$?nazione_istat#%?=#%?txt#%?OM#$?nazione_istat#%?=#%?txt#%?PS#$?nazione_istat#%?=#%?txt#%?QA#$?nazione_istat#%?=#%?txt#%?YE#@?set#%?123#%?=#%?txt#%?750#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>56</cmp><cmp>cond14</cmp><cmp>rpt#@?or#$?nazione_istat#%?=#%?txt#%?PK#$?nazione_istat#%?=#%?txt#%?MM#$?nazione_istat#%?=#%?txt#%?BD#$?nazione_istat#%?=#%?txt#%?AF#$?nazione_istat#%?=#%?txt#%?BT#$?nazione_istat#%?=#%?txt#%?BN#$?nazione_istat#%?=#%?txt#%?KH#$?nazione_istat#%?=#%?txt#%?CN#$?nazione_istat#%?=#%?txt#%?TW#$?nazione_istat#%?=#%?txt#%?KP#$?nazione_istat#%?=#%?txt#%?PH#$?nazione_istat#%?=#%?txt#%?HK#$?nazione_istat#%?=#%?txt#%?ID#$?nazione_istat#%?=#%?txt#%?KZ#$?nazione_istat#%?=#%?txt#%?KG#$?nazione_istat#%?=#%?txt#%?LA#$?nazione_istat#%?=#%?txt#%?MO#$?nazione_istat#%?=#%?txt#%?MY#$?nazione_istat#%?=#%?txt#%?MV#$?nazione_istat#%?=#%?txt#%?MN#$?nazione_istat#%?=#%?txt#%?NP#$?nazione_istat#%?=#%?txt#%?SG#$?nazione_istat#%?=#%?txt#%?TJ#$?nazione_istat#%?=#%?txt#%?LK#$?nazione_istat#%?=#%?txt#%?UZ#$?nazione_istat#%?=#%?txt#%?TH#$?nazione_istat#%?=#%?txt#%?TM#$?nazione_istat#%?=#%?txt#%?TL#$?nazione_istat#%?=#%?txt#%?VN#@?set#%?123#%?=#%?txt#%?760#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>57</cmp><cmp>cond14</cmp><cmp>rpt#@?or#$?nazione_istat#%?=#%?txt#%?MA#$?nazione_istat#%?=#%?txt#%?DZ#$?nazione_istat#%?=#%?txt#%?TN#$?nazione_istat#%?=#%?txt#%?LY#@?set#%?123#%?=#%?txt#%?230#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>59</cmp><cmp>cond14</cmp><cmp>rpt#@?or#$?nazione_istat#%?=#%?txt#%?KE#$?nazione_istat#%?=#%?txt#%?SS#$?nazione_istat#%?=#%?txt#%?LR#$?nazione_istat#%?=#%?txt#%?AO#$?nazione_istat#%?=#%?txt#%?BJ#$?nazione_istat#%?=#%?txt#%?BW#$?nazione_istat#%?=#%?txt#%?BF#$?nazione_istat#%?=#%?txt#%?BI#$?nazione_istat#%?=#%?txt#%?CM#$?nazione_istat#%?=#%?txt#%?CV#$?nazione_istat#%?=#%?txt#%?CF#$?nazione_istat#%?=#%?txt#%?TD#$?nazione_istat#%?=#%?txt#%?KM#$?nazione_istat#%?=#%?txt#%?CG#$?nazione_istat#%?=#%?txt#%?CI#$?nazione_istat#%?=#%?txt#%?ER#$?nazione_istat#%?=#%?txt#%?ET#$?nazione_istat#%?=#%?txt#%?GA#$?nazione_istat#%?=#%?txt#%?GM#$?nazione_istat#%?=#%?txt#%?GH#$?nazione_istat#%?=#%?txt#%?DJ#$?nazione_istat#%?=#%?txt#%?GN#$?nazione_istat#%?=#%?txt#%?GW#$?nazione_istat#%?=#%?txt#%?GQ#$?nazione_istat#%?=#%?txt#%?LS#$?nazione_istat#%?=#%?txt#%?MG#$?nazione_istat#%?=#%?txt#%?ML#$?nazione_istat#%?=#%?txt#%?MW#$?nazione_istat#%?=#%?txt#%?MU#$?nazione_istat#%?=#%?txt#%?MR#$?nazione_istat#%?=#%?txt#%?YT#$?nazione_istat#%?=#%?txt#%?MZ#$?nazione_istat#%?=#%?txt#%?NA#$?nazione_istat#%?=#%?txt#%?NE#$?nazione_istat#%?=#%?txt#%?NG#$?nazione_istat#%?=#%?txt#%?CD#$?nazione_istat#%?=#%?txt#%?RW#$?nazione_istat#%?=#%?txt#%?SC#$?nazione_istat#%?=#%?txt#%?SN#$?nazione_istat#%?=#%?txt#%?ST#$?nazione_istat#%?=#%?txt#%?SL#$?nazione_istat#%?=#%?txt#%?TG#$?nazione_istat#%?=#%?txt#%?SD#$?nazione_istat#%?=#%?txt#%?SO#$?nazione_istat#%?=#%?txt#%?SZ#$?nazione_istat#%?=#%?txt#%?TZ#$?nazione_istat#%?=#%?txt#%?UG#$?nazione_istat#%?=#%?txt#%?ZM#$?nazione_istat#%?=#%?txt#%?ZW#$?nazione_istat#%?=#%?txt#%?CD#@?set#%?123#%?=#%?txt#%?300#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>60</cmp><cmp>cond14</cmp><cmp>rpt#@?or#$?nazione_istat#%?=#%?txt#%?NC#$?nazione_istat#%?=#%?txt#%?VU#$?nazione_istat#%?=#%?txt#%?FJ#$?nazione_istat#%?=#%?txt#%?CX#$?nazione_istat#%?=#%?txt#%?CC#$?nazione_istat#%?=#%?txt#%?GU#$?nazione_istat#%?=#%?txt#%?KI#$?nazione_istat#%?=#%?txt#%?MP#$?nazione_istat#%?=#%?txt#%?MH#$?nazione_istat#%?=#%?txt#%?FM#$?nazione_istat#%?=#%?txt#%?NF#$?nazione_istat#%?=#%?txt#%?NR#$?nazione_istat#%?=#%?txt#%?PG#$?nazione_istat#%?=#%?txt#%?PW#$?nazione_istat#%?=#%?txt#%?PN#$?nazione_istat#%?=#%?txt#%?PF#$?nazione_istat#%?=#%?txt#%?SB#$?nazione_istat#%?=#%?txt#%?AS#$?nazione_istat#%?=#%?txt#%?WS#$?nazione_istat#%?=#%?txt#%?TK#$?nazione_istat#%?=#%?txt#%?TO#$?nazione_istat#%?=#%?txt#%?TV#$?nazione_istat#%?=#%?txt#%?WF#@?set#%?123#%?=#%?txt#%?810#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>61</cmp><cmp>cond14</cmp><cmp>rpt#@?and#$?nazione_istat#%?=#%?txt#%?#$?numero_ospite#%?=#%?txt#%?1#@?set#%?123#%?=#%?txt#%?777#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>63</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?nazione_istat#%?=#%?txt#%?#@?break#%?</cmp></riga>
<riga><cmp>64</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?125#%?=#%?var#%?regione_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>65</cmp><cmp>cond14</cmp><cmp>rpt#@?and#$?provincia_istat#%?=#%?txt#%?#$?numero_ospite#%?=#%?txt#%?1#@?set#%?125#%?=#%?txt#%?non dichiarata#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>66</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?113#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>67</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?nazione_istat#%?=#%?txt#%?IT#@?set#%?113#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>68</cmp><cmp>cond14</cmp><cmp>rpt#@?and#$?provincia_istat#%?=#%?txt#%?#$?italiano_istat#%?=#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>69</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?117#%?=#%?var#%?num_persone_tot#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>70</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?num_persone_istat#%?<#%?var#%?num_ospiti_tot#@?set#%?117#%?=#%?var#%?num_ospiti_tot#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>71</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?num_persone_istat#%?=#%?txt#%?#@?break#%?</cmp></riga>
<riga><cmp>72</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?110#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>73</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?111#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>74</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?112#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>77</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?data_inizio#%?=#%?var#%?date_istat(data_istat)#@?set#%?111#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>78</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?data_fine#%?=#%?var#%?date_istat(data_istat)#@?set#%?112#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>79</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?132#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>80</cmp><cmp>cond14</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?arrivo_istat#%?!=#%?txt#%?1#@?set#%?132#%?=#%?var#%?num_persone_istat#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>81</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?127#%?cli_giorno_prec_istat#%?+#%?var#%?agg_istat#%?</cmp></riga>
<riga><cmp>82</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?132#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>86</cmp><cmp>cond14</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?arrivo_istat#%?=#%?txt#%?1#@?set#%?132#%?=#%?var#%?num_persone_istat#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>88</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?128#%?cli_arrivati_istat#%?+#%?var#%?agg_istat#%?</cmp></riga>
<riga><cmp>90</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?132#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>91</cmp><cmp>cond14</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?partenza_istat#%?=#%?txt#%?1#@?set#%?132#%?=#%?var#%?num_persone_istat#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>92</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?130#%?cli_partiti_istat#%?+#%?var#%?agg_istat#%?</cmp></riga>
<riga><cmp>93</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?129#%?cli_giorno_prec_istat#%?+#%?var#%?cli_arrivati_istat#%?</cmp></riga>
<riga><cmp>94</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?131#%?cli_totale_istat#%?-#%?var#%?cli_partiti_istat#%?</cmp></riga>
<riga><cmp>95</cmp><cmp>cond14</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?partenza_istat#%?!=#%?txt#%?1#@?oper#%?150#%?camere_occupate_istat#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>96</cmp><cmp>cond14</cmp><cmp>rpt#@?or#$?arrivo_istat#%?=#%?txt#%?1#$?partenza_istat#%?=#%?txt#%?1#@?set#%?110#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>97</cmp><cmp>cond14</cmp><cmp>rpt#@?and#$?arr_part_istat#%?!=#%?txt#%?1#$?arr_part_istat#%?=#%?txt#%?nascondi presenti#@?break#%?</cmp></riga>
<riga><cmp>98</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?141#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>99</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?132#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>100</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?ultima_data_istat#%?=#%?txt#%?#@?set#%?122#%?=#%?txt#%?-1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>101</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?ultima_data_istat#%?!=#%?var#%?data_istat#@?set#%?132#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>107</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?122#%?num_prog_istat#%?+#%?var#%?agg_istat#%?</cmp></riga>
<riga><cmp>108</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?142#%?=#%?var#%?data_istat#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>109</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?num_prog_istat#%?>#%?txt#%?0#@?set#%?143#%?=#%?txt#%?\par \page#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>110</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?numero_ospite#%?=#%?txt#%?1#@?set#%?124#%?=#%?var#%?nazione_istat#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>111</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?numero_ospite#%?=#%?txt#%?1#@?set#%?126#%?=#%?var#%?provincia_istat#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>112</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?133#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>113</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?nazione1_istat#%?!=#%?var#%?nazione_istat#@?set#%?133#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>114</cmp><cmp>cond14</cmp><cmp>rpt#@?or#$?numero_ospite#%?=#%?txt#%?1#$?italiano_istat#%?=#%?txt#%?1#@?set#%?133#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>115</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?ospite_altra_naz_istat#%?!=#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>119</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?134#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>120</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?provincia1_istat#%?!=#%?var#%?provincia_istat#@?set#%?134#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>122</cmp><cmp>cond14</cmp><cmp>rpt#@?or#$?numero_ospite#%?=#%?txt#%?1#$?italiano_istat#%?!=#%?txt#%?1#@?set#%?134#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>123</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?ospite_altra_prov_istat#%?!=#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>124</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?109#%?=#%?var#%?nazione_istat#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>125</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?italiano_istat#%?=#%?txt#%?1#@?set#%?109#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>126</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?114#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>127</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?115#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>128</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?116#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>129</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?144#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>130</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?145#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>131</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?132#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>132</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?numero_ospite#%?=#%?txt#%?1#@?set#%?132#%?=#%?var#%?num_persone_istat#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>133</cmp><cmp>cond14</cmp><cmp>rpt#@?and#$?italiano_istat#%?!=#%?txt#%?1#$?arrivo_istat#%?=#%?txt#%?1#@?set#%?115#%?=#%?var#%?agg_istat#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>134</cmp><cmp>cond14</cmp><cmp>rpt#@?and#$?italiano_istat#%?!=#%?txt#%?1#$?partenza_istat#%?=#%?txt#%?1#@?set#%?116#%?=#%?var#%?agg_istat#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>135</cmp><cmp>cond14</cmp><cmp>rpt#@?and#$?italiano_istat#%?!=#%?txt#%?1#$?partenza_istat#%?!=#%?txt#%?1#@?set#%?144#%?=#%?var#%?agg_istat#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>136</cmp><cmp>cond14</cmp><cmp>rpt#@?and#$?italiano_istat#%?!=#%?txt#%?1#$?arrivo_istat#%?!=#%?txt#%?1#@?set#%?145#%?=#%?var#%?agg_istat#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>137</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?a218#%?arrivi_naz_istat(pos_istat)#%?+#%?var#%?agg_arr_istat#%?</cmp></riga>
<riga><cmp>138</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?a219#%?partenze_naz_istat(pos_istat)#%?+#%?var#%?agg_part_istat#%?</cmp></riga>
<riga><cmp>139</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?a226#%?presenze_naz_istat(pos_istat)#%?+#%?var#%?agg_pres_istat#%?</cmp></riga>
<riga><cmp>140</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?a232#%?pres_notte_prec_naz_istat(pos_istat)#%?+#%?var#%?agg_pres_notte_prec_istat#%?</cmp></riga>
<riga><cmp>141</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?137#%?tot_arr_naz_istat#%?+#%?var#%?agg_arr_istat#%?</cmp></riga>
<riga><cmp>142</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?138#%?tot_part_naz_istat#%?+#%?var#%?agg_part_istat#%?</cmp></riga>
<riga><cmp>143</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?146#%?tot_pres_naz_istat#%?+#%?var#%?agg_pres_istat#%?</cmp></riga>
<riga><cmp>144</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?147#%?tot_pres_notte_prec_naz_istat#%?+#%?var#%?agg_pres_notte_prec_istat#%?</cmp></riga>
<riga><cmp>147</cmp><cmp>cond14</cmp><cmp>rpt#@?and#$?italiano_istat#%?!=#%?txt#%?1#$?numero_ospite#%?=#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>148</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?136#%?num_prov_istat#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>149</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?pos_prov_istat(provincia_istat)#%?!=#%?txt#%?#@?set#%?109#%?=#%?var#%?pos_prov_istat(provincia_istat)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>150</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?114#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>151</cmp><cmp>cond14</cmp><cmp>rpt#@?and#$?pos_prov_istat(provincia_istat)#%?=#%?txt#%?#$?italiano_istat#%?=#%?txt#%?1#@?set#%?114#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>154</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?ins_nuovo_num_istat#%?=#%?txt#%?1#@?set#%?109#%?=#%?var#%?prox_num_prov_istat#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>155</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?ins_nuovo_num_istat#%?=#%?txt#%?1#@?set#%?a221#%?=#%?var#%?pos_istat#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>156</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?ins_nuovo_num_istat#%?=#%?txt#%?1#@?set#%?a222#%?=#%?var#%?provincia_istat#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>157</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?ins_nuovo_num_istat#%?=#%?txt#%?1#@?set#%?135#%?=#%?var#%?prox_num_prov_istat#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>158</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?115#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>159</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?116#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>160</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?144#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>161</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?145#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>162</cmp><cmp>cond14</cmp><cmp>rpt#@?and#$?italiano_istat#%?=#%?txt#%?1#$?arrivo_istat#%?=#%?txt#%?1#@?set#%?115#%?=#%?var#%?agg_istat#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>163</cmp><cmp>cond14</cmp><cmp>rpt#@?and#$?italiano_istat#%?=#%?txt#%?1#$?partenza_istat#%?=#%?txt#%?1#@?set#%?116#%?=#%?var#%?agg_istat#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>164</cmp><cmp>cond14</cmp><cmp>rpt#@?and#$?italiano_istat#%?=#%?txt#%?1#$?partenza_istat#%?!=#%?txt#%?1#@?set#%?144#%?=#%?var#%?agg_istat#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>165</cmp><cmp>cond14</cmp><cmp>rpt#@?and#$?italiano_istat#%?=#%?txt#%?1#$?arrivo_istat#%?!=#%?txt#%?1#@?set#%?145#%?=#%?var#%?agg_istat#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>166</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?a223#%?arrivi_prov_istat(pos_istat)#%?+#%?var#%?agg_arr_istat#%?</cmp></riga>
<riga><cmp>167</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?a224#%?partenze_prov_istat(pos_istat)#%?+#%?var#%?agg_part_istat#%?</cmp></riga>
<riga><cmp>168</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?a228#%?presenze_prov_istat(pos_istat)#%?+#%?var#%?agg_pres_istat#%?</cmp></riga>
<riga><cmp>169</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?a233#%?pres_notte_prec_prov_istat(pos_istat)#%?+#%?var#%?agg_pres_notte_prec_istat#%?</cmp></riga>
<riga><cmp>170</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?139#%?tot_arr_prov_istat#%?+#%?var#%?agg_arr_istat#%?</cmp></riga>
<riga><cmp>171</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?140#%?tot_part_prov_istat#%?+#%?var#%?agg_part_istat#%?</cmp></riga>
<riga><cmp>172</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?148#%?tot_pres_prov_istat#%?+#%?var#%?agg_pres_istat#%?</cmp></riga>
<riga><cmp>173</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?149#%?tot_pres_notte_prec_prov_istat#%?+#%?var#%?agg_pres_notte_prec_istat#%?</cmp></riga>
<riga><cmp>174</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?numero_ospite#%?=#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>175</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?nazione1_istat#%?=#%?txt#%?#@?break#%?</cmp></riga>
<riga><cmp>176</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?123#%?=#%?var#%?nazione1_istat#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>177</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?113#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>179</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?nazione_istat#%?=#%?txt#%?IT#@?set#%?113#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>181</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?109#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>182</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?italiano_istat#%?!=#%?txt#%?1#@?set#%?109#%?=#%?var#%?nazione_istat#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>183</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?115#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>184</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?116#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>185</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?144#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>186</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?145#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>187</cmp><cmp>cond14</cmp><cmp>rpt#@?and#$?italiano_istat#%?!=#%?txt#%?1#$?arrivo_istat#%?=#%?txt#%?1#@?set#%?115#%?=#%?txt#%?-1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>188</cmp><cmp>cond14</cmp><cmp>rpt#@?and#$?italiano_istat#%?!=#%?txt#%?1#$?partenza_istat#%?=#%?txt#%?1#@?set#%?116#%?=#%?txt#%?-1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>189</cmp><cmp>cond14</cmp><cmp>rpt#@?and#$?italiano_istat#%?!=#%?txt#%?1#$?partenza_istat#%?!=#%?txt#%?1#@?set#%?144#%?=#%?txt#%?-1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>190</cmp><cmp>cond14</cmp><cmp>rpt#@?and#$?italiano_istat#%?!=#%?txt#%?1#$?arrivo_istat#%?!=#%?txt#%?1#@?set#%?145#%?=#%?txt#%?-1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>191</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?a218#%?arrivi_naz_istat(pos_istat)#%?+#%?var#%?agg_arr_istat#%?</cmp></riga>
<riga><cmp>192</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?a219#%?partenze_naz_istat(pos_istat)#%?+#%?var#%?agg_part_istat#%?</cmp></riga>
<riga><cmp>193</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?a226#%?presenze_naz_istat(pos_istat)#%?+#%?var#%?agg_pres_istat#%?</cmp></riga>
<riga><cmp>194</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?a232#%?pres_notte_prec_naz_istat(pos_istat)#%?+#%?var#%?agg_pres_notte_prec_istat#%?</cmp></riga>
<riga><cmp>195</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?137#%?tot_arr_naz_istat#%?+#%?var#%?agg_arr_istat#%?</cmp></riga>
<riga><cmp>196</cmp><cmp>cond14</cmp><cmp>inr#@?#@?set#%?135#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>197</cmp><cmp>cond14</cmp><cmp>inr#@?#@?set#%?127#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>198</cmp><cmp>cond14</cmp><cmp>inr#@?#@?set#%?128#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>199</cmp><cmp>cond14</cmp><cmp>inr#@?#@?set#%?130#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>200</cmp><cmp>cond14</cmp><cmp>inr#@?#@?set#%?137#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>201</cmp><cmp>cond14</cmp><cmp>inr#@?#@?set#%?138#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>202</cmp><cmp>cond14</cmp><cmp>inr#@?#@?set#%?139#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>203</cmp><cmp>cond14</cmp><cmp>inr#@?#@?set#%?140#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>204</cmp><cmp>cond14</cmp><cmp>inr#@?#@?set#%?121#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>205</cmp><cmp>cond14</cmp><cmp>inr#@?#@?set#%?141#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>206</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?138#%?tot_part_naz_istat#%?+#%?var#%?agg_part_istat#%?</cmp></riga>
<riga><cmp>207</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?146#%?tot_pres_naz_istat#%?+#%?var#%?agg_pres_istat#%?</cmp></riga>
<riga><cmp>208</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?147#%?tot_pres_notte_prec_naz_istat#%?+#%?var#%?agg_pres_notte_prec_istat#%?</cmp></riga>
<riga><cmp>209</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?italiano_istat#%?!=#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>210</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?125#%?=#%?var#%?provincia1_istat#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>211</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?set#%?109#%?=#%?var#%?pos_prov_istat(provincia_istat)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>212</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?arrivo_istat#%?=#%?txt#%?1#@?set#%?115#%?=#%?txt#%?-1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>213</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?partenza_istat#%?=#%?txt#%?1#@?set#%?116#%?=#%?txt#%?-1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>214</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?partenza_istat#%?!=#%?txt#%?1#@?set#%?144#%?=#%?txt#%?-1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>215</cmp><cmp>cond14</cmp><cmp>rpt#@?#$?arrivo_istat#%?!=#%?txt#%?1#@?set#%?145#%?=#%?txt#%?-1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>216</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?a223#%?arrivi_prov_istat(pos_istat)#%?+#%?var#%?agg_arr_istat#%?</cmp></riga>
<riga><cmp>217</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?a224#%?partenze_prov_istat(pos_istat)#%?+#%?var#%?agg_part_istat#%?</cmp></riga>
<riga><cmp>218</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?a228#%?presenze_prov_istat(pos_istat)#%?+#%?var#%?agg_pres_istat#%?</cmp></riga>
<riga><cmp>219</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?a233#%?pres_notte_prec_prov_istat(pos_istat)#%?+#%?var#%?agg_pres_notte_prec_istat#%?</cmp></riga>
<riga><cmp>220</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?139#%?tot_arr_prov_istat#%?+#%?var#%?agg_arr_istat#%?</cmp></riga>
<riga><cmp>221</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?140#%?tot_part_prov_istat#%?+#%?var#%?agg_part_istat#%?</cmp></riga>
<riga><cmp>222</cmp><cmp>cond14</cmp><cmp>ind#@?#@?array#%?a215#%?dat#%?</cmp></riga>
<riga><cmp>223</cmp><cmp>cond14</cmp><cmp>inr#@?#@?unset#%?a226</cmp></riga>
<riga><cmp>224</cmp><cmp>cond14</cmp><cmp>inr#@?#@?unset#%?a228</cmp></riga>
<riga><cmp>225</cmp><cmp>cond14</cmp><cmp>inr#@?#@?unset#%?a226</cmp></riga>
<riga><cmp>226</cmp><cmp>cond14</cmp><cmp>inr#@?#@?unset#%?a228</cmp></riga>
<riga><cmp>227</cmp><cmp>cond14</cmp><cmp>inr#@?#@?unset#%?a232</cmp></riga>
<riga><cmp>228</cmp><cmp>cond14</cmp><cmp>inr#@?#@?unset#%?a233</cmp></riga>
<riga><cmp>229</cmp><cmp>cond14</cmp><cmp>inr#@?#@?set#%?148#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>230</cmp><cmp>cond14</cmp><cmp>inr#@?#@?set#%?149#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>231</cmp><cmp>cond14</cmp><cmp>inr#@?#@?set#%?146#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>232</cmp><cmp>cond14</cmp><cmp>inr#@?#@?set#%?147#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>233</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?148#%?tot_pres_prov_istat#%?+#%?var#%?agg_pres_istat#%?</cmp></riga>
<riga><cmp>234</cmp><cmp>cond14</cmp><cmp>rpt#@?#@?oper#%?149#%?tot_pres_notte_prec_prov_istat#%?+#%?var#%?agg_pres_notte_prec_istat#%?</cmp></riga>
<riga><cmp>235</cmp><cmp>cond14</cmp><cmp>inr#@?#@?set#%?150#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>1</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?62#%?=#%?var#%?numero_prenotazione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>2</cmp><cmp>cond13</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?cod_capo_prenota_ps(numero_prenotazione)#%?=#%?txt#%?#@?set#%?a34#%?=#%?txt#%?16#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>3</cmp><cmp>cond13</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?2#$?cod_capo_prenota_ps(numero_prenotazione)#%?=#%?txt#%?16#@?set#%?a34#%?=#%?txt#%?17#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>4</cmp><cmp>cond13</cmp><cmp>rpt#@?and#$?codice_parentela_ospite#%?!=#%?txt#%?19#$?numero_ospite#%?!=#%?txt#%?1#@?set#%?a34#%?=#%?txt#%?18#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>6</cmp><cmp>cond13</cmp><cmp>rpt#@?#$?prenota_capo_gruppo_ps(num_prenota_tmp_ps)#%?=#%?txt#%?1#@?set#%?a34#%?=#%?txt#%?18#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>7</cmp><cmp>cond13</cmp><cmp>rpt#@?#$?numero_ospite#%?=#%?txt#%?1#@?set#%?41#%?=#%?var#%?cod_capo_prenota_ps(numero_prenotazione)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>8</cmp><cmp>cond13</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?prenota_in_gruppo_ps(num_prenota_tmp_ps)#%?=#%?txt#%?1#@?set#%?41#%?=#%?txt#%?20#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>9</cmp><cmp>cond13</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?prenota_in_gruppo_ps(num_prenota_tmp_ps)#%?=#%?txt#%?1#@?set#%?a34#%?=#%?txt#%?20#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>11</cmp><cmp>cond13</cmp><cmp>rpt#@?#$?numero_ospite#%?!=#%?txt#%?1#@?set#%?41#%?=#%?var#%?codice_parentela_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>12</cmp><cmp>cond13</cmp><cmp>rpt#@?and#$?numero_ospite#%?!=#%?txt#%?1#$?cod_capo_prenota_ps(numero_prenotazione)#%?=#%?txt#%?18#@?set#%?41#%?=#%?txt#%?20#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>13</cmp><cmp>cond13</cmp><cmp>rpt#@?and#$?numero_ospite#%?!=#%?txt#%?1#$?cod_capo_prenota_ps(numero_prenotazione)#%?=#%?txt#%?20#@?set#%?41#%?=#%?txt#%?20#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>14</cmp><cmp>cond13</cmp><cmp>rpt#@?and#$?numero_ospite#%?!=#%?txt#%?1#$?codice_parentela_ospite#%?!=#%?txt#%?19#@?set#%?41#%?=#%?txt#%?20#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>15</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?42#%?=#%?var#%?data_inizio#%?txt#%?-#%?txt#%?/#%?</cmp></riga>
<riga><cmp>16</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?159#%?=#%?var#%?num_periodi#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>17</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?trunc#%?159#%?2#%?0#%?ini</cmp></riga>
<riga><cmp>18</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?43#%?=#%?var#%?cognome_ospite#%?txt#%?#%?txt#%?#%?asc</cmp></riga>
<riga><cmp>19</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?trunc#%?43#%?50#%? #%?fin</cmp></riga>
<riga><cmp>20</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?44#%?=#%?var#%?nome_ospite#%?txt#%?#%?txt#%?#%?asc</cmp></riga>
<riga><cmp>21</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?trunc#%?44#%?30#%? #%?fin</cmp></riga>
<riga><cmp>22</cmp><cmp>cond13</cmp><cmp>rpt#@?#$?sesso_ospite#%?!=#%?txt#%?f#@?set#%?45#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>23</cmp><cmp>cond13</cmp><cmp>rpt#@?#$?sesso_ospite#%?=#%?txt#%?f#@?set#%?45#%?=#%?txt#%?2#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>24</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?46#%?=#%?var#%?data_nascita_ospite#%?txt#%?-#%?txt#%?/#%?</cmp></riga>
<riga><cmp>25</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?401#%?=#%?var#%?codice2_nazione_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>26</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?162#%?=#%?var#%?codice_nazione_ps#%?txt#%?1#%?txt#%?#%?</cmp></riga>
<riga><cmp>27</cmp><cmp>cond13</cmp><cmp>rpt#@?#$?tmp_ps#%?=#%?var#%?codice_nazione_ps#@?set#%?401#%?=#%?var#%?codice_nazione_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>28</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?402#%?=#%?var#%?codice2_nazione_nascita_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>29</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?162#%?=#%?var#%?codice_nazione_nascita_ps#%?txt#%?1#%?txt#%?#%?</cmp></riga>
<riga><cmp>30</cmp><cmp>cond13</cmp><cmp>rpt#@?#$?tmp_ps#%?=#%?var#%?codice_nazione_nascita_ps#@?set#%?402#%?=#%?var#%?codice_nazione_nascita_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>31</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?403#%?=#%?var#%?codice2_nazione_documento_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>32</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?162#%?=#%?var#%?codice_nazione_documento_ps#%?txt#%?1#%?txt#%?#%?</cmp></riga>
<riga><cmp>33</cmp><cmp>cond13</cmp><cmp>rpt#@?#$?tmp_ps#%?=#%?var#%?codice_nazione_documento_ps#@?set#%?403#%?=#%?var#%?codice_nazione_documento_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>34</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?438#%?=#%?var#%?codice2_cittadinanza_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>35</cmp><cmp>cond13</cmp><cmp>rpt#@?#$?codice_cittadinanza_ospite#%?{}#%?txt#%?1#@?set#%?438#%?=#%?var#%?codice_cittadinanza_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>36</cmp><cmp>cond13</cmp><cmp>rpt#@?#$?codice_nazione_nascita_ps#%?!=#%?txt#%?100000100#@?set#%?47#%?=#%?txt#%?         #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>37</cmp><cmp>cond13</cmp><cmp>rpt#@?#$?codice_nazione_nascita_ps#%?=#%?txt#%?100000100#@?set#%?47#%?=#%?var#%?codice_citta_nascita_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>38</cmp><cmp>cond13</cmp><cmp>rpt#@?#$?codice_nazione_nascita_ps#%?!=#%?txt#%?100000100#@?set#%?48#%?=#%?txt#%?  #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>39</cmp><cmp>cond13</cmp><cmp>rpt#@?#$?codice_nazione_nascita_ps#%?=#%?txt#%?100000100#@?set#%?48#%?=#%?var#%?codice_regione_nascita_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>40</cmp><cmp>cond13</cmp><cmp>rpt#@?#$?codice_nazione_ps#%?!=#%?txt#%?100000100#@?set#%?49#%?=#%?txt#%?         #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>41</cmp><cmp>cond13</cmp><cmp>rpt#@?#$?codice_nazione_ps#%?=#%?txt#%?100000100#@?set#%?49#%?=#%?var#%?codice_citta_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>42</cmp><cmp>cond13</cmp><cmp>rpt#@?or#$?numero_ospite#%?!=#%?txt#%?1#$?prenota_in_gruppo_ps(num_prenota_tmp_ps)#%?=#%?txt#%?1#@?set#%?49#%?=#%?txt#%?         #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>43</cmp><cmp>cond13</cmp><cmp>rpt#@?#$?codice_nazione_ps#%?!=#%?txt#%?100000100#@?set#%?50#%?=#%?txt#%?  #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>44</cmp><cmp>cond13</cmp><cmp>rpt#@?#$?codice_nazione_ps#%?=#%?txt#%?100000100#@?set#%?50#%?=#%?var#%?codice_regione_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>46</cmp><cmp>cond13</cmp><cmp>rpt#@?or#$?numero_ospite#%?!=#%?txt#%?1#$?prenota_in_gruppo_ps(num_prenota_tmp_ps)#%?=#%?txt#%?1#@?set#%?50#%?=#%?txt#%?  #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>48</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?51#%?=#%?var#%?codice_nazione_ps#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>49</cmp><cmp>cond13</cmp><cmp>rpt#@?or#$?numero_ospite#%?!=#%?txt#%?1#$?prenota_in_gruppo_ps(num_prenota_tmp_ps)#%?=#%?txt#%?1#@?set#%?51#%?=#%?txt#%?         #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>50</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?52#%?=#%?var#%?via_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>51</cmp><cmp>cond13</cmp><cmp>rpt#@?#$?numcivico_ospite#%?!=#%?txt#%?#@?set#%?52#%?.=#%?txt#%? #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>52</cmp><cmp>cond13</cmp><cmp>rpt#@?#$?numcivico_ospite#%?!=#%?txt#%?#@?set#%?52#%?.=#%?var#%?numcivico_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>53</cmp><cmp>cond13</cmp><cmp>rpt#@?or#$?numero_ospite#%?!=#%?txt#%?1#$?prenota_in_gruppo_ps(num_prenota_tmp_ps)#%?=#%?txt#%?1#@?set#%?52#%?=#%?txt#%? #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>54</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?trunc#%?52#%?50#%? #%?fin</cmp></riga>
<riga><cmp>55</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?53#%?=#%?var#%?codice_tipo_documento_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>56</cmp><cmp>cond13</cmp><cmp>rpt#@?or#$?numero_ospite#%?!=#%?txt#%?1#$?prenota_in_gruppo_ps(num_prenota_tmp_ps)#%?=#%?txt#%?1#@?set#%?53#%?=#%?txt#%?     #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>57</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?54#%?=#%?var#%?documento_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>58</cmp><cmp>cond13</cmp><cmp>rpt#@?or#$?numero_ospite#%?!=#%?txt#%?1#$?prenota_in_gruppo_ps(num_prenota_tmp_ps)#%?=#%?txt#%?1#@?set#%?54#%?=#%?txt#%? #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>59</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?trunc#%?54#%?20#%? #%?fin</cmp></riga>
<riga><cmp>60</cmp><cmp>cond13</cmp><cmp>rpt#@?#$?codice_nazione_documento_ps#%?!=#%?txt#%?100000100#@?set#%?55#%?=#%?var#%?codice_nazione_documento_ps#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>62</cmp><cmp>cond13</cmp><cmp>rpt#@?#$?codice_nazione_documento_ps#%?=#%?txt#%?100000100#@?set#%?55#%?=#%?var#%?codice_citta_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>63</cmp><cmp>cond13</cmp><cmp>rpt#@?and#$?codice_nazione_documento_ps#%?=#%?txt#%?100000100#$?codice_citta_documento_ospite#%?!=#%?txt#%?#@?set#%?55#%?=#%?var#%?codice_citta_documento_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>64</cmp><cmp>cond13</cmp><cmp>rpt#@?or#$?numero_ospite#%?!=#%?txt#%?1#$?prenota_in_gruppo_ps(num_prenota_tmp_ps)#%?=#%?txt#%?1#@?set#%?55#%?=#%?txt#%?         #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>65</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?56#%?=#%?var#%?ritorno_a_capo#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>66</cmp><cmp>cond13</cmp><cmp>rpt#@?and#$?numero_ripetizione_prenotazioni#%?=#%?txt#%?1#$?numero_ospite#%?=#%?txt#%?1#@?set#%?56#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>67</cmp><cmp>cond13</cmp><cmp>rpt#@?#$?acapo_ps#%?!=#%?txt#%?#@?set#%?56#%?.=#%?var#%?avanzamento_riga#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>68</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?63#%?=#%?var#%?data_inizio#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>69</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?64#%?=#%?var#%?data_fine#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>70</cmp><cmp>cond13</cmp><cmp>rpt#@?and#$?cognome_prec_ps#%?=#%?var#%?cognome#$?nome_prec_ps#%?=#%?var#%?nome#$?dataini_prec_ps#%?=#%?var#%?dataini_corr_ps#$?datafine_prec_ps#%?=#%?var#%?datafine_corr_ps#$?numero_ospite#%?=#%?txt#%?1#@?set#%?a33#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>71</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?62#%?=#%?var#%?num_prenota_prec_ps#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>72</cmp><cmp>cond13</cmp><cmp>rpt#@?and#$?cognome_prec_ps#%?=#%?var#%?cognome#$?nome_prec_ps#%?=#%?var#%?nome#$?dataini_prec_ps#%?=#%?var#%?dataini_corr_ps#$?datafine_prec_ps#%?=#%?var#%?datafine_corr_ps#$?prenota_in_gruppo_ps(num_prenota_tmp_ps)#%?!=#%?txt#%?1#$?numero_ospite#%?=#%?txt#%?1#@?set#%?a32#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>73</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?57#%?=#%?var#%?cognome#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>74</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?58#%?=#%?var#%?nome#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>75</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?59#%?=#%?var#%?data_inizio#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>76</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?60#%?=#%?var#%?data_fine#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>77</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?61#%?=#%?var#%?numero_prenotazione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>78</cmp><cmp>cond13</cmp><cmp>inr#@?#@?set#%?57#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>79</cmp><cmp>cond13</cmp><cmp>rpt#@?#$?num_ripetizione_ps#%?>#%?txt#%?1#@?break#%?</cmp></riga>
<riga><cmp>80</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?62#%?=#%?var#%?numero_prenotazione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>81</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?154#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>82</cmp><cmp>cond13</cmp><cmp>rpt#@?#$?nome_ospite#%?=#%?txt#%?#@?set#%?154#%?.=#%?txt#%?nome mancante,#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>83</cmp><cmp>cond13</cmp><cmp>rpt#@?or#$?data_nascita_ps#%?=#%?txt#%?#$?data_nascita_ps#%?=#%?txt#%?//#@?set#%?154#%?.=#%?txt#%?data nascita mancante, #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>84</cmp><cmp>cond13</cmp><cmp>ind#@?#@?set#%?153#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>85</cmp><cmp>cond13</cmp><cmp>inr#@?#@?oper#%?153#%?num_ripetizione_ps#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>86</cmp><cmp>cond13</cmp><cmp>rpt#@?#$?codice_cittadinanza_ps#%?=#%?txt#%?#@?set#%?154#%?.=#%?txt#%?nazione di cittadinanza mancante, #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>87</cmp><cmp>cond13</cmp><cmp>rpt#@?#$?codice_nazione_nascita_ps#%?=#%?txt#%?#@?set#%?154#%?.=#%?txt#%?nazione di nascita mancante, #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>88</cmp><cmp>cond13</cmp><cmp>rpt#@?and#$?codice_nazione_nascita_ps#%?=#%?txt#%?100000100#$?codice_regione_nascita_ospite#%?=#%?txt#%?#@?set#%?154#%?.=#%?txt#%?provincia di nascita mancante, #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>89</cmp><cmp>cond13</cmp><cmp>rpt#@?and#$?codice_nazione_nascita_ps#%?=#%?txt#%?100000100#$?codice_citta_nascita_ospite#%?=#%?txt#%?#@?set#%?154#%?.=#%?txt#%?città di nascita mancante, #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>90</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?break#%?cont</cmp></riga>
<riga><cmp>91</cmp><cmp>cond13</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?codice_nazione_ps#%?=#%?txt#%?#@?set#%?154#%?.=#%?txt#%?nazione di residenza mancante, #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>92</cmp><cmp>cond13</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?codice_nazione_ps#%?=#%?txt#%?100000100#$?codice_regione_ospite#%?=#%?txt#%?#@?set#%?154#%?.=#%?txt#%?provincia di residenza mancante, #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>93</cmp><cmp>cond13</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?codice_nazione_ps#%?=#%?txt#%?100000100#$?codice_citta_ospite#%?=#%?txt#%?#@?set#%?154#%?.=#%?txt#%?città di residenza mancante, #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>94</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?cont</cmp></riga>
<riga><cmp>95</cmp><cmp>cond13</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?codice_tipo_documento_ospite#%?=#%?txt#%?#$?prenota_in_gruppo_ps(num_prenota_tmp_ps)#%?!=#%?txt#%?1#@?set#%?154#%?.=#%?txt#%?tipo di documento mancante, #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>96</cmp><cmp>cond13</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?documento_ospite#%?=#%?txt#%?#$?prenota_in_gruppo_ps(num_prenota_tmp_ps)#%?!=#%?txt#%?1#@?set#%?154#%?.=#%?txt#%?numero del documento mancante, #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>97</cmp><cmp>cond13</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?codice_nazione_documento_ps#%?=#%?txt#%?#$?prenota_in_gruppo_ps(num_prenota_tmp_ps)#%?!=#%?txt#%?1#@?set#%?154#%?.=#%?txt#%?nazione del documento mancante, #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>98</cmp><cmp>cond13</cmp><cmp>rpt#@?and#$?numero_ospite#%?=#%?txt#%?1#$?codice_nazione_documento_ps#%?=#%?txt#%?100000100#$?codice_citta_documento_ospite#%?=#%?txt#%?#$?prenota_in_gruppo_ps(num_prenota_tmp_ps)#%?!=#%?txt#%?1#@?set#%?154#%?.=#%?txt#%?città del documento mancante, #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>99</cmp><cmp>cond13</cmp><cmp>rpt#@?#$?mess_errore_ps#%?=#%?txt#%?#@?break#%?</cmp></riga>
<riga><cmp>100</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?-1#%?.=#%?txt#%?Prenotazione <b>#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>101</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?-1#%?.=#%?var#%?numero_prenotazione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>102</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?-1#%?.=#%?txt#%?</b> ospite <b>#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>103</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?-1#%?.=#%?var#%?numero_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>104</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?-1#%?.=#%?txt#%?</b>: #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>105</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?-1#%?.=#%?var#%?mess_errore_ps#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>106</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?-1#%?.=#%?txt#%?<br>#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>107</cmp><cmp>cond13</cmp><cmp>rpt#@?#@?set#%?162#%?=#%?var#%?mess_errore_ps#%?txt#%?città#%?txt#%?#%?</cmp></riga>
<riga><cmp>108</cmp><cmp>cond13</cmp><cmp>rpt#@?#$?tmp_ps#%?!=#%?var#%?mess_errore_ps#@?set#%?-1#%?.=#%?txt#%?<br>Si ricorda che per usare questo documento vanno prima ripristinate le <b>città predefinite</b> in "<em>configura e personalizza</em>", selezionando poi la città dal menù a tendina per ogni ospite italiano.<br>#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>1</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?ultima_prenota_sa#%?=#%?var#%?numero_prenotazione#@?break#%?cont</cmp></riga>
<riga><cmp>2</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?unset#%?a14</cmp></riga>
<riga><cmp>6</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?27#%?=#%?txt#%?________________#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>9</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?28#%?=#%?txt#%?________________#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>10</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?29#%?=#%?txt#%?________________ (________________)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>11</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?30#%?=#%?txt#%?________________#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>42</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?31#%?=#%?txt#%?________________#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>45</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?32#%?=#%?txt#%?________________ - ______________ (______________)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>46</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?33#%?=#%?txt#%?________________#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>47</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?34#%?=#%?txt#%?________________#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>48</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?35#%?=#%?txt#%?________________#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>49</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?36#%?=#%?txt#%?________________#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>50</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?103#%?=#%?var#%?data_inizio#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>51</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?104#%?=#%?var#%?data_fine#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>53</cmp><cmp>cond12</cmp><cmp>rpt#@?and#$?cognome_prec_sa#%?=#%?var#%?cognome#$?nome_prec_sa#%?=#%?var#%?nome#$?dataini_prec_sa#%?=#%?var#%?dataini_corr_sa#$?datafine_prec_sa#%?=#%?var#%?datafine_corr_sa#@?set#%?-2#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>54</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?99#%?=#%?var#%?cognome#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>55</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?100#%?=#%?var#%?nome#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>56</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?101#%?=#%?var#%?dataini_corr_sa#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>57</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?102#%?=#%?var#%?datafine_corr_sa#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>58</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?errore_ripetizione#%?=#%?txt#%?1#@?set#%?a38#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>59</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?errore_ripetizione#%?=#%?txt#%?1#@?break#%?cont</cmp></riga>
<riga><cmp>60</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?oper#%?105#%?numero_sa#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>61</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?107#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>62</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?20#%?=#%?txt#%?capo famiglia#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>63</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?26#%?=#%?txt#%?nucleo familiare#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>64</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?gruppo_sa(numero_sa)#%?=#%?txt#%?1#@?set#%?20#%?=#%?txt#%?capo gruppo#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>65</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?gruppo_sa(numero_sa)#%?=#%?txt#%?1#@?set#%?26#%?=#%?txt#%?gruppo#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>66</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?numero_sa#%?!=#%?txt#%?1#@?set#%?21#%?=#%?txt#%?\par \page#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>67</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?numero_sa#%?=#%?txt#%?1#@?set#%?21#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>68</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?cont</cmp></riga>
<riga><cmp>69</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?25#%?=#%?var#%?numero_prenotazione#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>70</cmp><cmp>cond12</cmp><cmp>ind#@?#@?set#%?24#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>71</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?23#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>72</cmp><cmp>cond12</cmp><cmp>rpt#@?or#$?lista_ospiti_sa(num_ospite_sa)#%?<#%?var#%?num_persone_tot#$?linea_ospite_sa(num_ospite_sa)#%?!=#%?txt#%?#@?set#%?23#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>73</cmp><cmp>cond12</cmp><cmp>rpt#@?and#$?num_ospite_sa#%?=#%?txt#%?1#$?errore_ripetizione#%?!=#%?txt#%?1#@?set#%?23#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>74</cmp><cmp>cond12</cmp><cmp>rpt#@?and#$?mostra_ospite_sa#%?=#%?txt#%?1#$?linea_ospite_sa(num_ospite_sa)#%?=#%?txt#%?#@?set#%?a14#%?=#%?txt#%?______________ ______________, ______________ (____________) - __________#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>75</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?cognome_ospite#%?=#%?txt#%?#@?break#%?cont</cmp></riga>
<riga><cmp>76</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?22#%?=#%?var#%?numero_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>77</cmp><cmp>cond12</cmp><cmp>inr#@?#@?set#%?25#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>78</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?a14#%?=#%?var#%?cognome_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>79</cmp><cmp>cond12</cmp><cmp>ind#@?#@?array#%?a13#%?val#%?0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40</cmp></riga>
<riga><cmp>80</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?a14#%?.=#%?txt#%? #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>81</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?nome_ospite#%?!=#%?txt#%?#@?set#%?a14#%?.=#%?var#%?nome_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>82</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?nome_ospite#%?=#%?txt#%?#@?set#%?a14#%?.=#%?txt#%?______________#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>83</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?a14#%?.=#%?txt#%?, #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>84</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?citta_nascita_ospite#%?!=#%?txt#%?#@?set#%?a14#%?.=#%?var#%?citta_nascita_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>85</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?citta_nascita_ospite#%?=#%?txt#%?#@?set#%?a14#%?.=#%?txt#%?______________#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>86</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?a14#%?.=#%?txt#%? (#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>87</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?nazione_nascita_ospite#%?!=#%?txt#%?#@?set#%?a14#%?.=#%?var#%?nazione_nascita_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>88</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?nazione_nascita_ospite#%?=#%?txt#%?#@?set#%?a14#%?.=#%?txt#%?____________#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>89</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?a14#%?.=#%?txt#%?) - #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>90</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?data_nascita_ospite#%?!=#%?txt#%?#@?set#%?a14#%?.=#%?var#%?data_nascita_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>91</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?data_nascita_ospite#%?=#%?txt#%?#@?set#%?a14#%?.=#%?txt#%?__________#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>92</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?parentela_ospite#%?=#%?txt#%?Membro Gruppo#@?set#%?a38#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>93</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?gruppo_sa(numero_sa)#%?=#%?txt#%?1#@?set#%?20#%?=#%?txt#%?capo gruppo#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>94</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?capofamiglia_sa#%?=#%?txt#%?capo gruppo#@?set#%?26#%?=#%?txt#%?gruppo#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>95</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?cont</cmp></riga>
<riga><cmp>96</cmp><cmp>cond12</cmp><cmp>rpt#@?or#$?mostra_ospite_sa#%?!=#%?txt#%?1#$?numero_ripetizione_sa#%?!=#%?txt#%?1#$?numero_ospite#%?!=#%?txt#%?0#@?break#%?cont</cmp></riga>
<riga><cmp>97</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?oper#%?107#%?num_altri_ospiti_sa#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>98</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?a37#%?.=#%?txt#%? #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>99</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?a37#%?.=#%?var#%?num_altri_ospiti_sa#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>100</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?a37#%?.=#%?txt#%? - #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>101</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?a37#%?.=#%?var#%?linea_ospite_sa(num_ospite_sa)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>102</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?a37#%?.=#%?txt#%?\line #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>103</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?cont</cmp></riga>
<riga><cmp>104</cmp><cmp>cond12</cmp><cmp>rpt#@?or#$?numero_ospite#%?!=#%?txt#%?1#$?cognome_ospite#%?=#%?txt#%?#@?break#%?</cmp></riga>
<riga><cmp>105</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?cognome_ospite#%?!=#%?txt#%?#@?set#%?27#%?=#%?var#%?cognome_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>106</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?nome_ospite#%?!=#%?txt#%?#@?set#%?28#%?=#%?var#%?nome_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>107</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?citta_nascita_ospite#%?!=#%?txt#%?#@?set#%?29#%?=#%?var#%?citta_nascita_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>108</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?citta_nascita_ospite#%?=#%?txt#%?#@?set#%?29#%?=#%?txt#%?________________#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>109</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?29#%?.=#%?txt#%? (#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>110</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?37#%?=#%?txt#%?________________#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>111</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?nazione_nascita_ospite#%?!=#%?txt#%?#@?set#%?37#%?=#%?var#%?nazione_nascita_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>112</cmp><cmp>cond12</cmp><cmp>rpt#@?and#$?nazione_nascita_ospite#%?=#%?txt#%?Italia#$?regione_nascita_ospite#%?!=#%?txt#%?#@?set#%?37#%?=#%?var#%?regione_nascita_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>113</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?29#%?.=#%?var#%?var_tmp_sa#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>114</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?29#%?.=#%?txt#%?)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>115</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?data_nascita_ospite#%?!=#%?txt#%?#@?set#%?30#%?=#%?var#%?data_nascita_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>116</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?cittadinanza_ospite#%?!=#%?txt#%?#@?set#%?31#%?=#%?var#%?cittadinanza_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>117</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?via_ospite#%?!=#%?txt#%?#@?set#%?32#%?=#%?var#%?via_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>118</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?via_ospite#%?=#%?txt#%?#@?set#%?32#%?=#%?txt#%?________________#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>119</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?numcivico_ospite#%?!=#%?txt#%?#@?set#%?32#%?.=#%?txt#%? #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>120</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?numcivico_ospite#%?!=#%?txt#%?#@?set#%?32#%?.=#%?var#%?numcivico_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>121</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?32#%?.=#%?txt#%? - #%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>122</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?citta_ospite#%?!=#%?txt#%?#@?set#%?32#%?.=#%?var#%?citta_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>123</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?citta_ospite#%?=#%?txt#%?#@?set#%?32#%?.=#%?txt#%?______________#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>124</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?32#%?.=#%?txt#%? (#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>125</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?37#%?=#%?txt#%?______________#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>126</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?nazione_ospite#%?!=#%?txt#%?#@?set#%?37#%?=#%?var#%?nazione_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>127</cmp><cmp>cond12</cmp><cmp>rpt#@?and#$?nazione_ospite#%?=#%?txt#%?Italia#$?regione_ospite#%?!=#%?txt#%?#@?set#%?37#%?=#%?var#%?regione_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>128</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?32#%?.=#%?var#%?var_tmp_sa#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>129</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?32#%?.=#%?txt#%?)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>130</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?tipo_documento_ospite#%?!=#%?txt#%?#@?set#%?33#%?=#%?var#%?tipo_documento_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>131</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?documento_ospite#%?!=#%?txt#%?#@?set#%?34#%?=#%?var#%?documento_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>132</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?scadenza_documento_ospite#%?!=#%?txt#%?#@?set#%?35#%?=#%?var#%?scadenza_documento_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>133</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?36#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>134</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?citta_documento_ospite#%?!=#%?txt#%?#@?set#%?36#%?=#%?var#%?citta_documento_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>135</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?citta_documento_ospite#%?!=#%?txt#%?#@?set#%?36#%?.=#%?txt#%? (#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>136</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?37#%?=#%?txt#%?______________#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>137</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?nazione_documento_ospite#%?!=#%?txt#%?#@?set#%?37#%?=#%?var#%?nazione_documento_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>138</cmp><cmp>cond12</cmp><cmp>rpt#@?and#$?nazione_documento_ospite#%?=#%?txt#%?Italia#$?regione_documento_ospite#%?!=#%?txt#%?#@?set#%?37#%?=#%?var#%?regione_documento_ospite#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>139</cmp><cmp>cond12</cmp><cmp>rpt#@?#@?set#%?36#%?.=#%?var#%?var_tmp_sa#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>140</cmp><cmp>cond12</cmp><cmp>rpt#@?#$?citta_documento_ospite#%?!=#%?txt#%?#@?set#%?36#%?.=#%?txt#%?)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>141</cmp><cmp>cond12</cmp><cmp>inr#@?#@?set#%?99#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>142</cmp><cmp>cond12</cmp><cmp>inr#@?#@?set#%?105#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>143</cmp><cmp>cond12</cmp><cmp>ind#@?#@?set#%?106#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>144</cmp><cmp>cond12</cmp><cmp>inr#@?#@?oper#%?106#%?numero_ripetizione_sa#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>5</cmp><cmp>cond11</cmp><cmp>ind#@?#@?set#%?350#%?=#%?txt#%?30#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>6</cmp><cmp>cond11</cmp><cmp>ind#@?#@?date#%?343#%?data_inizio_selezione#%?is#%?2#%?g</cmp></riga>
<riga><cmp>7</cmp><cmp>cond11</cmp><cmp>ind#@?or#$?data_inizio_selezione#%?=#%?txt#%?#$?var_tmp_pulizie#%?>#%?var#%?data_fine_selezione#@?set#%?-1#%?=#%?txt#%?Questo documento deve essere visualizzato dalla tabella con le partenze e le prenotazioni correnti (voce "prenotazioni" nel menù in alto --&gt; "partenze e correnti") oppure si devono selezionare almeno 2 giorni.#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>8</cmp><cmp>cond11</cmp><cmp>ind#@?#@?date#%?332#%?data_inizio_selezione#%?is#%?1#%?g</cmp></riga>
<riga><cmp>9</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?set#%?335#%?=#%?var#%?unita_occupata#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>10</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?set#%?333#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>15</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?set#%?334#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>16</cmp><cmp>cond11</cmp><cmp>rpt#@?#$?data_inizio#%?=#%?var#%?data_riepilogo_pulizie#@?set#%?333#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>17</cmp><cmp>cond11</cmp><cmp>rpt#@?#$?data_fine#%?=#%?var#%?data_riepilogo_pulizie#@?set#%?334#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>18</cmp><cmp>cond11</cmp><cmp>run#@?#@?set#%?335#%?=#%?var#%?nome_unita#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>19</cmp><cmp>cond11</cmp><cmp>rpt#@?and#$?arrivo_pulizie#%?=#%?txt#%?1#$?situazione_pulizie(unita_pulizie)#%?!=#%?txt#%?#@?set#%?a4638#%?=#%?txt#%?PART+ARR#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>20</cmp><cmp>cond11</cmp><cmp>rpt#@?and#$?partenza_pulizie#%?=#%?txt#%?1#$?situazione_pulizie(unita_pulizie)#%?!=#%?txt#%?#@?set#%?a4638#%?=#%?txt#%?PART+ARR#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>31</cmp><cmp>cond11</cmp><cmp>rpt#@?and#$?data_inizio#%?<#%?var#%?data_riepilogo_pulizie#$?data_fine#%?>#%?var#%?data_riepilogo_pulizie#@?set#%?a4638#%?=#%?txt#%?PERMANENZA#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>33</cmp><cmp>cond11</cmp><cmp>rpt#@?and#$?arrivo_pulizie#%?=#%?txt#%?1#$?situazione_pulizie(unita_pulizie)#%?=#%?txt#%?#@?set#%?a4638#%?=#%?txt#%?ARRIVO#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>34</cmp><cmp>cond11</cmp><cmp>rpt#@?and#$?partenza_pulizie#%?=#%?txt#%?1#$?situazione_pulizie(unita_pulizie)#%?=#%?txt#%?#@?set#%?a4638#%?=#%?txt#%?PARTENZA#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>35</cmp><cmp>cond11</cmp><cmp>ind#@?#@?date#%?337#%?data_riepilogo_pulizie#%?da#%?0#%?g</cmp></riga>
<riga><cmp>36</cmp><cmp>cond11</cmp><cmp>rpt#@?#@?set#%?343#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>37</cmp><cmp>cond11</cmp><cmp>rpt#@?or#$?data_inizio#%?=#%?var#%?data_riepilogo_pulizie#$?data_inizio#%?<#%?var#%?data_riepilogo_pulizie#@?set#%?343#%?=#%?var#%?num_persone#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>38</cmp><cmp>cond11</cmp><cmp>rpt#@?or#$?data_fine#%?=#%?var#%?data_riepilogo_pulizie#$?data_fine#%?<#%?var#%?data_riepilogo_pulizie#@?set#%?343#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>39</cmp><cmp>cond11</cmp><cmp>rpt#@?#$?var_tmp_pulizie#%?!=#%?txt#%?#@?set#%?a4639#%?=#%?var#%?var_tmp_pulizie#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>40</cmp><cmp>cond11</cmp><cmp>rpt#@?and#$?var_tmp_pulizie#%?!=#%?txt#%?#$?n_letti_agg#%?!=#%?txt#%?#@?set#%?a4639#%?.=#%?txt#%?+#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>41</cmp><cmp>cond11</cmp><cmp>rpt#@?and#$?var_tmp_pulizie#%?!=#%?txt#%?#$?n_letti_agg#%?!=#%?txt#%?#@?set#%?a4639#%?.=#%?var#%?n_letti_agg#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>42</cmp><cmp>cond11</cmp><cmp>rpt#@?#$?var_tmp_pulizie#%?!=#%?txt#%?#@?set#%?a4641#%?=#%?var#%?num_persone_tot#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>43</cmp><cmp>cond11</cmp><cmp>rpt#@?#$?data_fine#%?=#%?var#%?data_riepilogo_pulizie#@?set#%?a4640#%?=#%?var#%?num_persone#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>44</cmp><cmp>cond11</cmp><cmp>rpt#@?and#$?data_fine#%?=#%?var#%?data_riepilogo_pulizie#$?n_letti_agg#%?!=#%?txt#%?#@?set#%?a4640#%?.=#%?txt#%?+#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>45</cmp><cmp>cond11</cmp><cmp>rpt#@?and#$?data_fine#%?=#%?var#%?data_riepilogo_pulizie#$?n_letti_agg#%?!=#%?txt#%?#@?set#%?a4640#%?.=#%?var#%?n_letti_agg#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>46</cmp><cmp>cond11</cmp><cmp>run#@?#@?oper#%?338#%?tot_persone_pulizie#%?+#%?var#%?num_persone_pulizie(unita_pulizie)#%?</cmp></riga>
<riga><cmp>47</cmp><cmp>cond11</cmp><cmp>rpt#@?#$?data_fine#%?=#%?var#%?data_riepilogo_pulizie#@?set#%?a4642#%?=#%?var#%?num_persone_tot#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>48</cmp><cmp>cond11</cmp><cmp>run#@?#@?oper#%?339#%?tot_persone_part_pulizie#%?+#%?var#%?num_persone_part_pulizie(unita_pulizie)#%?</cmp></riga>
<riga><cmp>49</cmp><cmp>cond11</cmp><cmp>rpt#@?#$?data_inizio#%?=#%?var#%?data_riepilogo_pulizie#@?set#%?a4643#%?=#%?var#%?num_persone_tot#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>50</cmp><cmp>cond11</cmp><cmp>run#@?#@?oper#%?340#%?tot_persone_arr_pulizie#%?+#%?var#%?num_persone_arr_pulizie(unita_pulizie)#%?</cmp></riga>
<riga><cmp>51</cmp><cmp>cond11</cmp><cmp>rpt#@?#$?data_inizio#%?=#%?var#%?data_riepilogo_pulizie#@?set#%?a4644#%?=#%?var#%?orario_entrata_stimato#%?var#%?data_riepilogo_pulizie#%?txt#%?#%?</cmp></riga>
<riga><cmp>52</cmp><cmp>cond11</cmp><cmp>ind#@?#@?set#%?341#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>53</cmp><cmp>cond11</cmp><cmp>rca#@?#$?numero_ripetizione_pulizie#%?!=#%?txt#%?1#@?break#%?cont</cmp></riga>
<riga><cmp>54</cmp><cmp>cond11</cmp><cmp>rca#@?#$?giorni_costo_agg#%?=#%?txt#%?#@?break#%?cont</cmp></riga>
<riga><cmp>55</cmp><cmp>cond11</cmp><cmp>rca#@?#$?pos_ca_pulizie(nome_costo_agg)#%?=#%?txt#%?#@?oper#%?341#%?num_ca_pulizie#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>56</cmp><cmp>cond11</cmp><cmp>rca#@?#$?pos_ca_pulizie(nome_costo_agg)#%?=#%?txt#%?#@?set#%?a4645#%?=#%?var#%?nome_costo_agg#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>57</cmp><cmp>cond11</cmp><cmp>ind#@?#@?set#%?342#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>58</cmp><cmp>cond11</cmp><cmp>inr#@?#@?oper#%?342#%?numero_ripetizione_pulizie#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>59</cmp><cmp>cond11</cmp><cmp>rca#@?#$?pos_ca_pulizie(nome_costo_agg)#%?=#%?txt#%?#@?set#%?a4646#%?=#%?var#%?num_ca_pulizie#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>60</cmp><cmp>cond11</cmp><cmp>rca#@?#@?cont</cmp></riga>
<riga><cmp>61</cmp><cmp>cond11</cmp><cmp>run#@?#@?set#%?343#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>62</cmp><cmp>cond11</cmp><cmp>run#@?#$?classe_riga_pulizie#%?!=#%?txt#%?#@?set#%?343#%?=#%?txt#%?1#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>63</cmp><cmp>cond11</cmp><cmp>run#@?#$?var_tmp_pulizie#%?!=#%?txt#%?1#@?set#%?336#%?=#%?txt#%? class="bgclr"#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>64</cmp><cmp>cond11</cmp><cmp>run#@?#$?var_tmp_pulizie#%?=#%?txt#%?1#@?set#%?336#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>65</cmp><cmp>cond11</cmp><cmp>rar4645#@?#@?set#%?344#%?.=#%?txt#%?<td><small><small>#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>66</cmp><cmp>cond11</cmp><cmp>rar4645#@?#@?set#%?344#%?.=#%?var#%?costi_aggiuntivi_pulizie(num_ca_pulizie)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>67</cmp><cmp>cond11</cmp><cmp>rar4645#@?#@?set#%?344#%?.=#%?txt#%?</small></small></td>#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>68</cmp><cmp>cond11</cmp><cmp>rar4645#@?#@?set#%?345#%?.=#%?txt#%?<td><!-- cost#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>69</cmp><cmp>cond11</cmp><cmp>rar4645#@?#@?set#%?345#%?.=#%?var#%?num_ca_pulizie#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>71</cmp><cmp>cond11</cmp><cmp>rar4645#@?#@?set#%?345#%?.=#%?txt#%? --></td>#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>72</cmp><cmp>cond11</cmp><cmp>rca#@?#$?numero_ripetizione_pulizie#%?<#%?txt#%?2#@?break#%?cont</cmp></riga>
<riga><cmp>73</cmp><cmp>cond11</cmp><cmp>rca#@?#$?array_date_pulizie(giorno_pulizie)#%?!=#%?var#%?data_riepilogo_pulizie#@?break#%?cont</cmp></riga>
<riga><cmp>74</cmp><cmp>cond11</cmp><cmp>rca#@?#$?pos_ca_pulizie(nome_costo_agg)#%?=#%?txt#%?#@?break#%?cont</cmp></riga>
<riga><cmp>75</cmp><cmp>cond11</cmp><cmp>rca#@?#@?set#%?335#%?=#%?var#%?unita_occupata#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>76</cmp><cmp>cond11</cmp><cmp>rca#@?#$?riga_unita_ca_pulizie(unita_pulizie)#%?=#%?txt#%?#@?set#%?a4648#%?=#%?var#%?riga_ca_tabella_pulizie#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>77</cmp><cmp>cond11</cmp><cmp>ind#@?#@?array#%?a4649#%?dat#%?</cmp></riga>
<riga><cmp>78</cmp><cmp>cond11</cmp><cmp>rca#@?#@?set#%?343#%?=#%?txt#%?<!-- cost#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>79</cmp><cmp>cond11</cmp><cmp>rca#@?#@?set#%?343#%?.=#%?var#%?pos_ca_pulizie(nome_costo_agg)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>80</cmp><cmp>cond11</cmp><cmp>rca#@?#@?set#%?343#%?.=#%?txt#%? -->#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>82</cmp><cmp>cond11</cmp><cmp>rca#@?#@?set#%?a4648#%?=#%?var#%?riga_unita_ca_pulizie(unita_pulizie)#%?var#%?var_tmp_pulizie#%?var#%?moltiplica_max_costo_agg#%?</cmp></riga>
<riga><cmp>83</cmp><cmp>cond11</cmp><cmp>rca#@?#@?set#%?341#%?=#%?var#%?pos_ca_pulizie(nome_costo_agg)#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>84</cmp><cmp>cond11</cmp><cmp>rca#@?#@?oper#%?a4650#%?totale_ca_pulizie(num_ca_pulizie)#%?+#%?var#%?moltiplica_max_costo_agg#%?</cmp></riga>
<riga><cmp>85</cmp><cmp>cond11</cmp><cmp>rca#@?#@?cont</cmp></riga>
<riga><cmp>86</cmp><cmp>cond11</cmp><cmp>run#@?#$?riga_unita_ca_pulizie(unita_pulizie)#%?=#%?txt#%?#@?set#%?a4648#%?=#%?var#%?riga_ca_tabella_pulizie#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>87</cmp><cmp>cond11</cmp><cmp>rpt#@?#$?data_inizio#%?=#%?var#%?data_riepilogo_pulizie#@?trunc#%?a4644#%?-3#%?#%?ini</cmp></riga>
<riga><cmp>88</cmp><cmp>cond11</cmp><cmp>rar4645#@?#@?set#%?a4650#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>89</cmp><cmp>cond11</cmp><cmp>ind#@?#@?set#%?347#%?=#%?txt#%?<tr class="headrow"><td>Camera</td><td>Persone</td><td>Situazione</td><td><small><small>Persone in<br>partenza</small></small></td><td><small><small>Orario di<br>arrivo</small></small></td>#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>90</cmp><cmp>cond11</cmp><cmp>run#@?#@?oper#%?348#%?numero_ripetizione_unita_pulizie#%?+#%?txt#%?1#%?</cmp></riga>
<riga><cmp>91</cmp><cmp>cond11</cmp><cmp>run#@?#@?set#%?349#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>92</cmp><cmp>cond11</cmp><cmp>run#@?#$?numero_ripetizione_unita_pulizie#%?=#%?var#%?numero_ripetizione_riga_intestazione_pulizie#@?set#%?349#%?=#%?var#%?riga_intestazione_tabella_pulizie#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>93</cmp><cmp>cond11</cmp><cmp>run#@?#$?numero_ripetizione_unita_pulizie#%?=#%?var#%?numero_ripetizione_riga_intestazione_pulizie#@?set#%?349#%?.=#%?var#%?intestazione_ca_tabella_pulizie#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>94</cmp><cmp>cond11</cmp><cmp>run#@?#$?numero_ripetizione_unita_pulizie#%?=#%?var#%?numero_ripetizione_riga_intestazione_pulizie#@?set#%?349#%?.=#%?txt#%?</tr>#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>95</cmp><cmp>cond11</cmp><cmp>run#@?#$?numero_ripetizione_unita_pulizie#%?=#%?var#%?numero_ripetizione_riga_intestazione_pulizie#@?set#%?348#%?=#%?txt#%?0#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>1</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?436#%?=#%?var#%?cognome#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>2</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?437#%?=#%?var#%?cognome#%?txt#%? #%?txt#%?#%?</cmp></riga>
<riga><cmp>3</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?trunc#%?437#%?6#%?#%?ini</cmp></riga>
<riga><cmp>4</cmp><cmp>cond10</cmp><cmp>rpt#@?#@?set#%?437#%?=#%?var#%?cogn_no_sp_eb#%?txt#%?#%?txt#%?#%?url</cmp></riga>
<riga><cmp>1</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?=#%?txt#%?f#@?set#%?1#%?=#%?txt#%?s#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>3</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?!=#%?txt#%?f#@?set#%?2#%?=#%?txt#%?il#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>4</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?=#%?txt#%?f#@?set#%?2#%?=#%?txt#%?la#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>5</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?!=#%?txt#%?f#@?set#%?3#%?=#%?txt#%?Il#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>6</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?=#%?txt#%?f#@?set#%?3#%?=#%?txt#%?La#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>7</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?!=#%?txt#%?f#@?set#%?4#%?=#%?txt#%?al#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>8</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?=#%?txt#%?f#@?set#%?4#%?=#%?txt#%?alla#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>9</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?!=#%?txt#%?f#@?set#%?5#%?=#%?txt#%?e#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>10</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?=#%?txt#%?f#@?set#%?5#%?=#%?txt#%?a#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>11</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?!=#%?txt#%?f#@?set#%?6#%?=#%?txt#%?o#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>12</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?=#%?txt#%?f#@?set#%?6#%?=#%?txt#%?a#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>23</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?!=#%?txt#%?f#@?set#%?7#%?=#%?txt#%?el#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>24</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?=#%?txt#%?f#@?set#%?7#%?=#%?txt#%?la#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>25</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?!=#%?txt#%?f#@?set#%?8#%?=#%?txt#%?El#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>26</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?=#%?txt#%?f#@?set#%?8#%?=#%?txt#%?La#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>27</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?!=#%?txt#%?f#@?set#%?9#%?=#%?txt#%?al#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>28</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?=#%?txt#%?f#@?set#%?9#%?=#%?txt#%?a la#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>29</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?!=#%?txt#%?f#@?set#%?10#%?=#%?txt#%?#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>30</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?=#%?txt#%?f#@?set#%?10#%?=#%?txt#%?a#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>31</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?!=#%?txt#%?f#@?set#%?11#%?=#%?txt#%?o#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>32</cmp><cmp>cond</cmp><cmp>rpt#@?#$?sesso#%?=#%?txt#%?f#@?set#%?11#%?=#%?txt#%?a#%?txt#%?#%?txt#%?#%?</cmp></riga>
<riga><cmp>2</cmp><cmp>compress</cmp><cmp>gz</cmp></riga>
<riga><cmp>3</cmp><cmp>compress</cmp><cmp>gz</cmp></riga>
<riga><cmp>4</cmp><cmp>compress</cmp><cmp>gz</cmp></riga>
<riga><cmp>7</cmp><cmp>compress</cmp><cmp>gz</cmp></riga>
<riga><cmp>8</cmp><cmp>allegato</cmp><cmp>0</cmp></riga>
<riga><cmp>9</cmp><cmp>allegato</cmp><cmp>0</cmp></riga>
<riga><cmp>10</cmp><cmp>allegato</cmp><cmp>0</cmp></riga>
</righetabella>
</tabella>
</database>
</backup>