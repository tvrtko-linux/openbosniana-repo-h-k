<?php

switch ($messaggio) {

case "Tabelle Mesi":  				$messaggio = "Months Tables"; break;
case "situazione alle":  			$messaggio = "situation at"; break;
case "del":  					$messaggio = "of"; break;
case "Tabella prenotazioni del":  		$messaggio = "Reservations table of"; break;
case "ERRORE":  				$messaggio = "ERROR"; break;
case "Torna al menù principale":  		$messaggio = "Back to main menu"; break;
case "Visualizza la tabella normale":  		$messaggio = "View the normal table"; break;
case "Visualizza tutti i mesi":  		$messaggio = "View all months"; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;

} # fine switch ($messaggio)

?>