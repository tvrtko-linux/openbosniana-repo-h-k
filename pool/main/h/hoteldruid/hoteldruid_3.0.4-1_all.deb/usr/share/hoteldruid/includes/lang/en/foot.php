<?php

switch ($messaggio) {

case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;

} # fine switch ($messaggio)

?>