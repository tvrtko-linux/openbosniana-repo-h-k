<?php

switch ($messaggio) {

case "Storico Entrate":  			$messaggio = "Historial de Pagos"; break;
case "Vedi le modifiche":  			$messaggio = "Mira las modificaciones"; break;
case "dal":  					$messaggio = "desde"; break;
case "al":  					$messaggio = "hasta"; break;
case "Senza colori":  				$messaggio = "Sin colores"; break;
case "Con colori":  				$messaggio = "Con colores"; break;
case "fino al":  				$messaggio = "hasta el"; break;
case "Storia delle entate e uscite delle prenotazioni inserite nel":	$messaggio = "Historial de pagos de las reservas insertadas en el"; break;
case "Dati della prenotazione":  		$messaggio = "Datos de la reserva"; break;
case "Pagato prima":  				$messaggio = "Pagado antes"; break;
case "Pagato dopo":  				$messaggio = "Pagado después"; break;
case "Saldo":  					$messaggio = "Diferencia"; break;
case "Data_della modifica":  			$messaggio = "Fecha de la modificación"; break;
case "Cognome_cliente":  			$messaggio = "Apellido_cliente"; break;
case "Data_iniziale":  				$messaggio = "Fecha_inicial"; break;
case "Data_finale":  				$messaggio = "Fecha_final"; break;
case "TOTALE":  				$messaggio = "TOTAL"; break;
case "Torna indietro":  			$messaggio = "Vuelve atrás"; break;
case "Trasferito in cassa":  			$messaggio = "Transferido en caja"; break;
case "RESTO":  					$messaggio = "RESTO"; break;
case "pagine":  				$messaggio = "páginas"; break;
case "Cliente":  				$messaggio = "Cliente"; break;
case "Utente":  				$messaggio = "Usuario"; break;
case "Si è sicuri di voler <div style=\"display: inline; color: red;\"><b>azzerare</b></div> tutte le entrate e le uscite delle prenotazioni e i soldi trasferiti in cassa del":	$messaggio = "Estas seguro de querer <div style=\"display: inline; color: red;\"><b>borrar</b></div> todos los pagos de las reservas y el dinero transferido en caja del"; break;
case "SI":  					$messaggio = "SI"; break;
case "NO":  					$messaggio = "NO"; break;
case "Azzera entrate e uscite prenotazioni":  	$messaggio = "Borra todos los pagos de las reservas"; break;
case "Metodo":  				$messaggio = "Método"; break;
case "Vedi solo le entrate-uscite":  		$messaggio = "Mira solo los pagos"; break;
case "con metodo":  				$messaggio = "con método"; break;
case "N°":  					$messaggio = "N°"; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;

} # fine switch ($messaggio)

?>