<?php

$lista_parentele = array();
$cod_parentele = array();
$cod2_parentele = array();
$cod3_parentele = array();

$lista_parentele[0] = "Familiare";
$cod_parentele[0] = "19";
$lista_parentele[1] = "Membro Gruppo";
$cod_parentele[1] = "20";


?>