<?php


# Set to 1 if street name comes before "street" word, 2 if it comes after
$ordine_strada = 2;


?>