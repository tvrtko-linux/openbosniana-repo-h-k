<?php

$lista_parentele = array();
$cod_parentele = array();
$cod2_parentele = array();
$cod3_parentele = array();

#$lista_parentele[0] = "Husband/Wife";
#$cod_parentele[0] = "001";
#$lista_parentele[1] = "Father/Mother";
#$cod_parentele[1] = "002";

?>