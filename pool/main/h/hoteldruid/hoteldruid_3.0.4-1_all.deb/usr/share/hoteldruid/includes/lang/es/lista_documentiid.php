<?php

$lista_documentiid = array();
$cod_documentiid = array();
$cod2_documentiid = array();
$cod3_documentiid = array();

#$lista_documentiid[0] = "Pasaporte";
#$cod_documentiid[0] = "001";
#$lista_documentiid[1] = "D.N.I.";
#$cod_documentiid[1] = "002";

?>