<?php

switch ($messaggio) {

case "contiene prenotazione future, non si può cancellare":	$messaggio = "contains reservations in the future, it can't be deleted"; break;
case "SI":  					$messaggio = "YES"; break;
case "NO":  					$messaggio = "NO"; break;
case "Torna indietro":  			$messaggio = "Go back"; break;
case "La casa verrà cambiata da":  		$messaggio = "The house will be changed from"; break;
case "a":  					$messaggio = "to"; break;
case "Il piano verrà cambiato da":  		$messaggio = "The floor will be changed from"; break;
case "Il massimo numero di occupanti verrà cambiato da":	$messaggio = "The maximum number of people that it can host will be changed from"; break;
case "La priorità verrà cambiata da":  		$messaggio = "The priority will be changed from"; break;
case "Il commento verrà cambiato":  		$messaggio = "The comment will be changed"; break;
case "Continua":  				$messaggio = "Continue"; break;
case "Casa":  					$messaggio = "House"; break;
case "Cambia in":  				$messaggio = "Change to"; break;
case "Piano":  					$messaggio = "Floor"; break;
case "Capienza":  				$messaggio = "Capacity"; break;
case "Priorità":  				$messaggio = "Priority"; break;
case "Commento":  				$messaggio = "Comment"; break;
case "Persone":  				$messaggio = "People"; break;
case "anche se le loro caratteristiche non sono più compatibili":	$messaggio = "even if their characteristics are not compatible anymore"; break;
case "Nome":  					$messaggio = "Name"; break;
case "esiste già":  				$messaggio = "already exists"; break;
case "non esiste più":  			$messaggio = "does not exist any more"; break;
case "la nuova foto è stata aggiunta":  	$messaggio = "the new photo has been added"; break;
case "l'url della foto è sbagliata":  		$messaggio = "the photo url is wrong"; break;
case "foto eliminata":  			$messaggio = "photo deleted"; break;
case "elimina":  				$messaggio = "delete"; break;
case "url di una nuova foto":  			$messaggio = "new photo url"; break;
case "aggiungi":  				$messaggio = "add"; break;
case "commento della foto":  			$messaggio = "comment of photo"; break;
case "aggiornato":  				$messaggio = "updated"; break;
case "aggiornata":  				$messaggio = "updated"; break;
case "modifica":  				$messaggio = "modify"; break;
case "commento":  				$messaggio = "comment"; break;
case "Persona":  				$messaggio = "Person"; break;
case "più bassa viene assegnata prima":  	$messaggio = "lower assigned first"; break;
case "Rimane solo":  				$messaggio = "It remains only"; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;

} # fine switch ($messaggio)

?>