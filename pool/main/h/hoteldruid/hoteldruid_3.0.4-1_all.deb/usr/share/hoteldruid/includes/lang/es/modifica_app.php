<?php

switch ($messaggio) {

case "contiene prenotazione future, non si può cancellare":	$messaggio = "contiene reservas futuras, no se puede borrar"; break;
case "SI":  					$messaggio = "SI"; break;
case "NO":  					$messaggio = "NO"; break;
case "Torna indietro":  			$messaggio = "Volver atrás"; break;
case "La casa verrà cambiata da":  		$messaggio = "La casa será cambiada de"; break;
case "a":  					$messaggio = "a"; break;
case "Il piano verrà cambiato da":  		$messaggio = "El piso será cambiado de"; break;
case "Il massimo numero di occupanti verrà cambiato da":	$messaggio = "El máximo número de ocupantes será cambiado de"; break;
case "La priorità verrà cambiata da":  		$messaggio = "La prioridad será cambiada de"; break;
case "Il commento verrà cambiato":  		$messaggio = "El comentario será cambiado"; break;
case "Continua":  				$messaggio = "Continuar"; break;
case "Casa":  					$messaggio = "Casa"; break;
case "Cambia in":  				$messaggio = "Cambiar a"; break;
case "Piano":  					$messaggio = "Piso"; break;
case "Capienza":  				$messaggio = "Capacidad"; break;
case "Priorità":  				$messaggio = "Prioridad"; break;
case "Commento":  				$messaggio = "Comentario"; break;
case "Persone":  				$messaggio = "Personas"; break;
case "anche se le loro caratteristiche non sono più compatibili":	$messaggio = "aunque sus características no sean más compatibles"; break;
case "Nome":  					$messaggio = "Nombre"; break;
case "esiste già":  				$messaggio = "ya existe"; break;
case "non esiste più":  			$messaggio = "ya no existe más"; break;
case "la nuova foto è stata aggiunta":  	$messaggio = "la nueva foto ha sido añadida"; break;
case "l'url della foto è sbagliata":  		$messaggio = "la url de la foto está equivocada"; break;
case "foto eliminata":  			$messaggio = "foto eliminada"; break;
case "elimina":  				$messaggio = "eliminar"; break;
case "url di una nuova foto":  			$messaggio = "url de una nueva foto"; break;
case "aggiungi":  				$messaggio = "añadir"; break;
case "commento della foto":  			$messaggio = "comentario de la foto"; break;
case "aggiornato":  				$messaggio = "modificado"; break;
case "aggiornata":  				$messaggio = "modificada"; break;
case "modifica":  				$messaggio = "modificar"; break;
case "commento":  				$messaggio = "comentario"; break;
case "Persona":  				$messaggio = "Persona"; break;
case "più bassa viene assegnata prima":  	$messaggio = "la más baja es asignada antes"; break;
case "Rimane solo":  				$messaggio = "Solo queda"; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;

} # fine switch ($messaggio)

?>