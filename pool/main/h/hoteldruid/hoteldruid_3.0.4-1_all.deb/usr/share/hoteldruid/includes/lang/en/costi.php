<?php

switch ($messaggio) {

case "Costi Gestione":  			$messaggio = "Management Costs"; break;
case "Si deve inserire un nome per l' entrata":	$messaggio = "You must inset a reason for the cashbox income"; break;
case "Si deve inserire il valore dell' entrata":	$messaggio = "You must inset the value of the cashbox income"; break;
case "L'entrata è stata inserita":  		$messaggio = "Cashbox income has been inserted"; break;
case "Si deve inserire un nome per la spesa":	$messaggio = "You must inset a reason for the cashbox expense"; break;
case "Si deve inserire il valore della spesa":	$messaggio = "You must inset the value of the cashbox expense"; break;
case "La spesa è stata inserita":  		$messaggio = "Cashbox expense has been inserted"; break;
case "Inserisci i costi di gestione per l'anno":	$messaggio = "Insert cashbox expenses for year"; break;
case "Natura spesa":  				$messaggio = "Reason for expense"; break;
case "Importo":  				$messaggio = "Amount"; break;
case "Persona che inserisce":  			$messaggio = "Person inserting"; break;
case "opzionale":  				$messaggio = "optional"; break;
case "Inserisci la spesa":  			$messaggio = "Insert the cashbox expense"; break;
case "Inserisci le entrate in cassa per l'anno":	$messaggio = "Insert cashbox incomes for year"; break;
case "Natura entrata":  			$messaggio = "Reason for income"; break;
case "Inserisci l' entrata":  			$messaggio = "Insert the cashbox income"; break;
case "Sottrai l'importo dal totale delle prenotazioni":	$messaggio = "Subtract the amount from total of the reservations"; break;
case "Visualizza la tabella con tutte le spese e le entrate":	$messaggio = "View table with all cashbox incomes and expenses"; break;
case "Torna al menù principale":  		$messaggio = "Back to main menu"; break;
case "Il valore dell' entrata è sbagliato":  	$messaggio = "The value of the cashbox income is wrong"; break;
case "Il valore della spesa è sbagliato":  	$messaggio = "The value of the cashbox expense is wrong"; break;
case "Nessuna cassa disponibile":  		$messaggio = "No cashbox available"; break;
case "Cassa":  					$messaggio = "Cashbox"; break;
case "cassa principale":  			$messaggio = "main cashbox"; break;
case "Metodo di pagamento":  			$messaggio = "Payment method"; break;
case "OK":  					$messaggio = "OK"; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;

} # fine switch ($messaggio)

?>