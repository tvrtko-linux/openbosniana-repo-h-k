<?php

switch ($messaggio) {

case "Punto Vendita":  				$messaggio = "Punto de Venta"; break;
case "Torna al menù principale":  		$messaggio = "Volver al menú principal"; break;
case "Altri costi prenotazione":  		$messaggio = "Otros costes reserva"; break;
case "TOTALE":  				$messaggio = "TOTAL"; break;
case "in cassa":  				$messaggio = "en caja"; break;
case "su prenotazione":  			$messaggio = "sobre reserva"; break;
case "senza categoria":  			$messaggio = "sin categoria"; break;
case "tariffa incompatibile":  			$messaggio = "tarifa incompatible"; break;
case "Scegliere i giorni in cui applicare il costo aggiuntivo":	$messaggio = "Escoger los días en los que aplicar el coste añadido"; break;
case "Scegliere le settimane in cui applicare il costo aggiuntivo":	$messaggio = "Escoger las semanas en las que el coste añadido"; break;
case "dal":  					$messaggio = "desde"; break;
case "al":  					$messaggio = "hasta"; break;
case "Continua":  				$messaggio = "Continua"; break;
case "manca numero di persone":  		$messaggio = "falta número de personas"; break;
case "periodo non permesso":  			$messaggio = "período no permitido"; break;
case "numero massimo raggiunto":  		$messaggio = "número máximo alcanzado"; break;
case "bene non presente in inventario":  	$messaggio = "bién no presente en inventario"; break;
case "OK":  					$messaggio = "OK"; break;
case "Calcola":  				$messaggio = "Calcular"; break;
case "Inserisci i costi ora":  			$messaggio = "Insertar los costes ahora"; break;
case "Annulla":  				$messaggio = "Anular"; break;
case "Attualmente non ci sono prenotazioni che abbiano registrato l'entrata":	$messaggio = "Actualmente no hay reservas que hayan registrado la entrada"; break;
case "Oggi non ci sono prenotazioni":  		$messaggio = "Hoy no hay reservas"; break;
case "Metodo pagamento":  			$messaggio = "Método de pago"; break;
case "in cassa principale":  			$messaggio = "en caja principal"; break;
case "I costi sono stati inseriti":		$messaggio = "Los costes han sido insertados"; break;
case "nella cassa":  				$messaggio = "en la caja"; break;
case "nella cassa principale":  		$messaggio = "en la caja principal"; break;
case "moltiplicato per più di":  		$messaggio = "multiplicado por más de"; break;
case "documento":  				$messaggio = "documento"; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;

} # fine switch ($messaggio)

?>