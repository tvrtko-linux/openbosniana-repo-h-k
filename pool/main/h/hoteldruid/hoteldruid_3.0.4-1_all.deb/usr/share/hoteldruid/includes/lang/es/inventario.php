<?php

switch ($messaggio) {

case "Inventario":  				$messaggio = "Inventario"; break;
case "Inventario del magazzino":  		$messaggio = "Inventario del almacén"; break;
case "Nome bene":  				$messaggio = "Nombre del bien"; break;
case "Quantità minima predefinita":  		$messaggio = "Cantidad mínima predefinida"; break;
case "Quantità attuale":  			$messaggio = "Cantidad actual"; break;
case "Nuova quantità":  			$messaggio = "Nueva cantidad"; break;
case "Modifica":  				$messaggio = "Modificar"; break;
case "Torna indietro":  			$messaggio = "Volver atrás"; break;
case "Modifica le quantità attuali":  		$messaggio = "Modificar las cantidades actuales"; break;
case "aggiungi":  				$messaggio = "añadir"; break;
case "cancella":  				$messaggio = "borrar"; break;
case "Bene":  					$messaggio = "Bien"; break;
case "cancellato":  				$messaggio = "borrado"; break;
case "Quantità aggiornate":  			$messaggio = "Cantidad actualizada"; break;
case "Nuovo bene":  				$messaggio = "Nuevo bien"; break;
case "aggiunto":  				$messaggio = "añadido"; break;
case "ricarica":  				$messaggio = "recargar"; break;
case "Si è sicuri di voler eliminare il bene":	$messaggio = "Estás seguro de querer borrar el bien"; break;
case "dall'inventario":  			$messaggio = "del inventario"; break;
case "del magazzino":  				$messaggio = "del almacén"; break;
case "SI":  					$messaggio = "SI"; break;
case "NO":  					$messaggio = "NO"; break;
case "Bene ricaricato":  			$messaggio = "Bien recargado"; break;
case "Ricarica il bene":  			$messaggio = "Recargar el bien"; break;
case "da":  					$messaggio = "desde"; break;
case "magazzino":  				$messaggio = "almacén"; break;
case "Nessun posto da cui ricaricare":  	$messaggio = "Ningún sitio desde donde recargar"; break;
case "mancanti":  				$messaggio = "faltantes"; break;
case "Continua":  				$messaggio = "Continuar"; break;
case "richiesto_per registrare entrata":  	$messaggio = "necesario_para registrar entrada"; break;
case "si":  					$messaggio = "si"; break;
case "no":  					$messaggio = "no"; break;
case "Aggiungi":  				$messaggio = "Añadir"; break;
case "Sottrai":  				$messaggio = "Restar"; break;
case "crea un <em>costo aggiuntivo</em>":  	$messaggio = "crear un <em>coste añadido</em>"; break;
case "per il punto vendita":  			$messaggio = "para el punto venta"; break;
case "<em>Nome</em> del costo aggiuntivo":  	$messaggio = "<em>Nombre</em> del coste añadido"; break;
case "Categoria":  				$messaggio = "Categoría"; break;
case "nuova":  					$messaggio = "nueva"; break;
case "esistente":  				$messaggio = "existente"; break;
case "<em>Prezzo</em> del costo aggiuntivo":	$messaggio = "<em>Precio</em> del coste añadido"; break;
case "Costo aggiuntivo non inserito":  		$messaggio = "Coste añadido no insertado"; break;
case "costo già esistente":  			$messaggio = "coste ya existente"; break;
case "prezzo sbagliato":  			$messaggio = "precio equivocado"; break;
case "Attenzione":  				$messaggio = "Aviso"; break;
case "esiste già un costo aggiuntivo associato a questo bene in questo magazzino":	$messaggio = "ya existe un coste añadido asociado a este bien en este almacén"; break;
case "Vai a fondo pagina":  			$messaggio = "Ir al fondo de la página"; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;

} # fine switch ($messaggio)

?>