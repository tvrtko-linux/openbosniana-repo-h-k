<?php

switch ($messaggio) {

case "Tariffe":  				$messaggio = "Rates"; break;
case "Tabella tariffe del":  			$messaggio = "Rates table of"; break;
case "Torna indietro":  			$messaggio = "Go back"; break;
case "tariffa":  				$messaggio = "rate"; break;
case "aggiungi":  				$messaggio = "add"; break;
case "settimane":  				$messaggio = "weeks"; break;
case "giorni":  				$messaggio = "days"; break;
case "la nuova foto è stata aggiunta":  	$messaggio = "the new photo has been added"; break;
case "l'url della foto è sbagliata":  		$messaggio = "the photo url is wrong"; break;
case "foto eliminata":  			$messaggio = "photo deleted"; break;
case "foto della tariffa":  			$messaggio = "photos of rate"; break;
case "elimina":  				$messaggio = "delete"; break;
case "url di una nuova foto":  			$messaggio = "new photo url"; break;
case "descrizione della tariffa":  		$messaggio = "description of rate"; break;
case "modifica":  				$messaggio = "modify"; break;
case "aggiornata":  				$messaggio = "updated"; break;
case "commento":  				$messaggio = "comment"; break;
case "commento della foto":  			$messaggio = "comment of photo"; break;
case "aggiornato":  				$messaggio = "updated"; break;
case "disponibilità":  				$messaggio = "availability"; break;
case "permanenza min.":  			$messaggio = "minimum stay"; break;
case "permanenza mass.":  			$messaggio = "maximum stay"; break;
case "mostra disponibilità":  			$messaggio = "show availability"; break;
case "mostra permanenza minima":  		$messaggio = "show minimum stay"; break;
case "raggruppa le date":  			$messaggio = "group dates"; break;
case "in modo predefinito per la tariffa":  	$messaggio = "by default for rate"; break;
case "Numero di persone predefinito per la tariffa":	$messaggio = "Default number of people for rate"; break;
case "Modifica i valori":  			$messaggio = "Modify values"; break;
case "non definito":  				$messaggio = "undefined"; break;
case "Fai l'upload di":  			$messaggio = "Upload"; break;
case "Eesiste già un file chiamato":  		$messaggio = "There is already a file called"; break;
case "La dimensione del file eccede il limite":	$messaggio = "The dimension of the file exceeds the limit"; break;
case "Attenzione: l'indirizzo usato potrà essere raggiungibile solo da questo computer":	$messaggio = "Warning: the address used will be reachable only from this computer"; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;

} # fine switch ($messaggio)

?>