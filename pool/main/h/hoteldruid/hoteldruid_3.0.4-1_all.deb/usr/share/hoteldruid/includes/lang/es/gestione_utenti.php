<?php

switch ($messaggio) {

case "Gestione Utenti":  			$messaggio = "Gestión Usuarios"; break;
case "Il <b>nome</b> dell'utente":  		$messaggio = "El <b>nombre</b> del usuario"; break;
case "verrà cambiato da":  			$messaggio = "se cambiará de"; break;
case "a":  					$messaggio = "a"; break;
case "Il <b>login</b> dell'utente":  		$messaggio = "El <b>login</b> del usuario"; break;
case "password conservata in chiaro":  		$messaggio = "contraseña guardada en claro"; break;
case "password conservata criptata con md5":  	$messaggio = "contraseña guardada encriptada con md5"; break;
case "password conservata criptata con mcrypt":	$messaggio = "contraseña guardada encriptada con mcrypt"; break;
case "password conservata criptata con mhash":	$messaggio = "contraseña guardada encriptada con mhash"; break;
case "disabilitato":  				$messaggio = "no habilitado"; break;
case "Inserisci una nuova password":  		$messaggio = "Insertar una nueva contraseña"; break;
case "Ripeti la password":  			$messaggio = "Repetir la contraseña"; break;
case "Continua":  				$messaggio = "Continuar"; break;
case "Torna indietro":  			$messaggio = "Volver atrás"; break;
case "<div style=\"display: inline; color: red;\">Esiste già</div> un utente chiamato":	$messaggio = "<div style=\"display: inline; color: red;\">Existe ya</div> un usuario llamado"; break;
case "Nuova password dell'utente":  		$messaggio = "Nueva contraseña del usuario"; break;
case "<div style=\"display: inline; color: red;\">non</div> inserita correttamente":	$messaggio = "<div style=\"display: inline; color: red;\">no</div> insertada correctamente"; break;
case "<b>Non</b> è stato effettuato nessun cambiamento":	$messaggio = "<b>No</b> se ha efectuado ningún cambio"; break;
case "Esiste già un utente chiamato":  		$messaggio = "Existe ya un usuario llamado"; break;
case "Le nuove password non coincidono":  	$messaggio = "Las nuevas contraseñas no coincíden"; break;
case "Inserisci una nuova password per l'utente":	$messaggio = "Inserta una nueva contraseña para el usuario"; break;
case "Nuova password":  			$messaggio = "Nueva contraseña"; break;
case "Gestione degli utenti di hoteldruid":	$messaggio = "Gestión de usuarios de hoteldruid"; break;
case "Gestione degli utenti":			$messaggio = "Gestión de usuarios"; break;
case "N°":  					$messaggio = "N°"; break;
case "nome":  					$messaggio = "nombre"; break;
case "login":  					$messaggio = "login"; break;
case "modifica":  				$messaggio = "modificar"; break;
case "password criptata con md5":  		$messaggio = "contraseña encriptada con md5"; break;
case "password criptata con mcrypt":  		$messaggio = "contraseña encriptada con mcrypt"; break;
case "password criptata con mhash":  		$messaggio = "contraseña encriptada con mhash"; break;
case "password":  				$messaggio = "contraseña"; break;
case "privilegi":  				$messaggio = "privilegios"; break;
case "Amministratore":  			$messaggio = "Administrador"; break;
case "Abilitare per usare altri utenti":  	$messaggio = "Habilitar para utilizar otros usuarios"; break;
case "Modifica gli utenti":  			$messaggio = "Modificar los usuarios"; break;
case "Aggiungi":  				$messaggio = "Añadir"; break;
case "un nuovo utente chiamato":  		$messaggio = "un nuevo usuario llamado"; break;
case "dell'utente":  				$messaggio = "del usuario"; break;
case "del gruppo":  				$messaggio = "del grupo"; break;
case "dall'utente":  				$messaggio = "desde el usuario"; break;
case "Privilegi importati":  			$messaggio = "Privilegios importados"; break;
case "Importa":  				$messaggio = "Importar"; break;
case "gruppi":  				$messaggio = "grupos"; break;
case "Aggiornati i gruppi dell'utente":  	$messaggio = "Actualizados los grupos del usuario"; break;
case "Gruppi dell'utente":  			$messaggio = "Grupos del usuario"; break;
case "Nuovo gruppo":  				$messaggio = "Nuevo grupo"; break;
case "Esiste già un gruppo chiamato":  		$messaggio = "Existe ya un grupo llamado"; break;
case "Modifica":  				$messaggio = "Modificar"; break;
case "cancella":  				$messaggio = "borrar"; break;
case "Si è sicuri di voler <b style=\"font-weight: normal; color: red;\">cancellare</b> l'utente":	$messaggio = "Estás seguro de querer <b style=\"font-weight: normal; color: red;\">borrar</b> el usuario"; break;
case "SI":  					$messaggio = "SI"; break;
case "NO":  					$messaggio = "NO"; break;
case "privilegi e personalizzazioni":  		$messaggio = "privilegios y personalizaciones"; break;
case "solo i privilegi":  			$messaggio = "solo los previlegios"; break;
case "solo le personalizzazioni":  		$messaggio = "solo las personalizaciones"; break;
case "Personalizzazioni importate":  		$messaggio = "Personalizaciones importadas"; break;
case "privilegi, personalizzazioni e gruppi":	$messaggio = "privilegios, personalizaciones y grupos"; break;
case "privilegi e gruppi":  			$messaggio = "privilegios y grupos"; break;
case "personalizzazioni e gruppi":  		$messaggio = "personalizaciones y grupos"; break;
case "solo i gruppi":  				$messaggio = "solo grupos"; break;
case "Gruppi importati":  			$messaggio = "Grupos importados"; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;

} # fine switch ($messaggio)

?>