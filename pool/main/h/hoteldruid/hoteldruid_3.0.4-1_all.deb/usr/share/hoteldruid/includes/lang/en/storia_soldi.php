<?php

switch ($messaggio) {

case "Storico Entrate":  			$messaggio = "Payments History"; break;
case "Vedi le modifiche":  			$messaggio = "View the changes"; break;
case "dal":  					$messaggio = "from"; break;
case "al":  					$messaggio = "to"; break;
case "Senza colori":  				$messaggio = "Without colors"; break;
case "Con colori":  				$messaggio = "With colors"; break;
case "fino al":  				$messaggio = "to"; break;
case "Storia delle entate e uscite delle prenotazioni inserite nel":	$messaggio = "Payments history of reservations inserted in"; break;
case "Dati della prenotazione":  		$messaggio = "Reservation data"; break;
case "Pagato prima":  				$messaggio = "Paid before"; break;
case "Pagato dopo":  				$messaggio = "Paid after"; break;
case "Saldo":  					$messaggio = "Difference"; break;
case "Data_della modifica":  			$messaggio = "Modification date"; break;
case "Cognome_cliente":  			$messaggio = "Client_surname"; break;
case "Data_iniziale":  				$messaggio = "Starting_date"; break;
case "Data_finale":  				$messaggio = "Ending_date"; break;
case "TOTALE":  				$messaggio = "TOTAL"; break;
case "Torna indietro":  			$messaggio = "Go back"; break;
case "Trasferito in cassa":  			$messaggio = "Transferred in cash box"; break;
case "RESTO":  					$messaggio = "REST"; break;
case "pagine":  				$messaggio = "pages"; break;
case "Cliente":  				$messaggio = "Client"; break;
case "Utente":  				$messaggio = "User"; break;
case "Si è sicuri di voler <div style=\"display: inline; color: red;\"><b>azzerare</b></div> tutte le entrate e le uscite delle prenotazioni e i soldi trasferiti in cassa del":	$messaggio = "Are you sure you want to <div style=\"display: inline; color: red;\"><b>delete</b></div> all reservations payments and money transferred in cash box of"; break;
case "SI":  					$messaggio = "YES"; break;
case "NO":  					$messaggio = "NO"; break;
case "Azzera entrate e uscite prenotazioni":  	$messaggio = "Delete all reservations payments"; break;
case "Metodo":  				$messaggio = "Method"; break;
case "Vedi solo le entrate-uscite":  		$messaggio = "View only payments"; break;
case "con metodo":  				$messaggio = "with method"; break;
case "N°":  					$messaggio = "N."; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;

} # fine switch ($messaggio)

?>