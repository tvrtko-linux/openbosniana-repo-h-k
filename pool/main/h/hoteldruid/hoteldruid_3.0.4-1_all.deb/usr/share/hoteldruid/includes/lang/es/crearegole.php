<?php

switch ($messaggio) {

case "Crea Regole":  				$messaggio = "Crear Reglas"; break;
case "Inserisci le regole di assegnazione per le prenotazioni dell'anno":	$messaggio = "Insertar las reglas de asignación para las reservas del año"; break;
case "Regola di assegnazione":  		$messaggio = "Regla de asignación"; break;
case "nel periodo dal":  			$messaggio = "en el período desde"; break;
case "al":  					$messaggio = "hasta"; break;
case "motivazione":  				$messaggio = "motivación"; break;
case "Inserisci la regola":  			$messaggio = "Insertar la regla"; break;
case "Inserisci o modifica la regola":  	$messaggio = "Insertar o modificar la regla"; break;
case "Cancella tutte le regole di questo tipo":	$messaggio = "Borra todas las reglas de este tipo"; break;
case "Quando si sceglie la tariffa":  		$messaggio = "Cuando se escoge la tarifa"; break;
case "se non si inserisce nessun altro metodo di assegnazione":	$messaggio = "si no se inserta ningún otro método de asignación"; break;
case "Vedi le regole già inserite":  		$messaggio = "Mirar las reglas ya insertadas"; break;
case "Torna al menù principale":  		$messaggio = "Volver al menú principal"; break;
case "Non sono stati inseriti tutti i dati necessari":	$messaggio = "No han sido insertados todos los datos necesarios"; break;
case "Le date sono sbagliate":  		$messaggio = "Las fechas están equivocadas"; break;
case "opzionale":  				$messaggio = "opcionál"; break;
case "La regola è stata inserita":  		$messaggio = "La regla ha sido insertada"; break;
case "Sei sicuro di voler cancellare tutte le regole del tipo 1":	$messaggio = "Estás seguro de que qeieres borrar todas las reglas de tipo 1"; break;
case "SI":  					$messaggio = "SI"; break;
case "Le regole sono state cancellate":  	$messaggio = "Las reglas han sido borradas"; break;
case "Si deve scegliere la tariffa":  		$messaggio = "Hay que escoger la tarifa"; break;
case " non esiste":  				$messaggio = " no existe"; break;
case "La regola di assegnazione":		$messaggio = "La regla de asignación"; break;
case "è stata inserita":			$messaggio = "ha sido insertada"; break;
case "è stata modificata":			$messaggio = "ha sido modificada"; break;
case "Torna indietro":  			$messaggio = "Volver atrás"; break;
case "Motivazione non valida":  		$messaggio = "Motivación no válida"; break;
case "La tariffa scelta ha già un utente associato, cancella la regola prima di inserirne una nuova":	$messaggio = "La tarifa escogida ya tiene un usuario asociado, borra la regla antes de insertar una nueva"; break;
case "Quando l'utente amministratore":  	$messaggio = "Cuando el usuario administrador"; break;
case "sceglie la tariffa":  			$messaggio = "escoge la tarifa"; break;
case "fai risultare come se l'utente":  	$messaggio = "haz resultar como si el usuario"; break;
case "avesse inserito la prenotazione e l'eventuale cliente":	$messaggio = "hubiese insertado la reserva y el eventual cliente"; break;
case "Si deve inserire l'utente da associare":	$messaggio = "Hay que insertar el usuario a asociar"; break;
case "L'utente ":  				$messaggio = "El usuario "; break;
case "assegna automaticamente come numero di persone":	$messaggio = "asignar automaticamente como número de personas"; break;
case "se non si inserisce nessun altro numero":	$messaggio = "si no se inserta ningún otro número"; break;
case "La tariffa scelta ha già un numero di persone associato, cancella la regola prima di inserirne una nuova":	$messaggio = "La tarifa escogida ya tiene número de personas asociado, borra la regla antes de insertar una nueva"; break;
case "Si deve inserire il numero di persone da associare":	$messaggio = "Hay que insertar el número de personas a asociar"; break;
case "Eccezioni alla regola":  			$messaggio = "excepciones a la regla"; break;
case "e mancano meno di":  			$messaggio = "y faltan menos de"; break;
case "giorni":					$messaggio = "dias"; break;
case "dall'inizio":				$messaggio = "al principio"; break;
case "dalla fine":				$messaggio = "al final"; break;
case "della prenotazione quando essa viene inserita, allora":	$messaggio = "de la reserva cuando esta es insertada, entonces"; break;
case "Inserisci o modifica questa eccezione alla regola":	$messaggio = "Insertar o modificar esta excepción a la regla"; break;
case "Si deve inserire il numero di giorni":  	$messaggio = "Hay que insertar el número de dias"; break;
case "Chiedi prima di assegnare":		$messaggio = "Preguntar antes de asignar"; break;
case "Chiudi":  				$messaggio = "Cerrar"; break;
case "Il periodo chiuso è stato liberato dalle prenotazioni":	$messaggio = "El período cerrado ha sido liberado de reservas"; break;
case "<span class=\"colred\">Non è stato possibile</span> liberare dalle prenotazioni il periodo chiuso":	$messaggio = "<span class=\"colred\">No ha sido posible</span> liberar de reservas el período cerrado"; break;
case "per le tariffe":  			$messaggio = "para las tarifas"; break;
case "Esiste già una regola di questo tipo nel periodo selezionato":	$messaggio = "Existe ya una regla de este tipo en el período seleccionado"; break;
case "assegna automaticamente":  		$messaggio = "asignar automaticamente"; break;
case "tra":  					$messaggio = "entre"; break;
case "da assegnare troppo alto, supera quello presente nella lista":	$messaggio = "a asignar demasiado alto, supera el número presente en la lista"; break;
case "Attenzione":  				$messaggio = "Cuidado"; break;
case "della regola 2 mancanti nella eccezione alla regola":	$messaggio = "de la regla 2 que faltan en la excepción a la regla"; break;
case "nella regola 2 di questa tariffa che non possono ospitare":	$messaggio = "en la regla 2 de esta tarifa que puedan hospedar"; break;
case "persone":  				$messaggio = "personas"; break;
case "nella regola di assegnazione 2 di questa tariffa":	$messaggio = "en la regla de asignación 2 de esta tarifa"; break;
case "Regole esistenti":  			$messaggio = "Reglas existentes"; break;
case "Cancella o ridimensiona queste regole":  	$messaggio = "Borrar o reducir estas reglas"; break;
case "Cancella":  				$messaggio = "Borrar"; break;
case "Ridimensiona":  				$messaggio = "Reducir"; break;
case "Modifica la regola":  			$messaggio = "Modificar la regla"; break;
case "chiusure":  				$messaggio = "cierres"; break;
case "numero di persone":  			$messaggio = "número de personas"; break;
case "utente inserimento":  			$messaggio = "usuario que inserta"; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;

} # fine switch ($messaggio)

?>