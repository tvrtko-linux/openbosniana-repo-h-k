<?php

switch ($messaggio) {

case "Gestione Utenti":  			$messaggio = "Users Management"; break;
case "Il <b>nome</b> dell'utente":  		$messaggio = "The <b>name</b> of user"; break;
case "verrà cambiato da":  			$messaggio = "will be changed from"; break;
case "a":  					$messaggio = "to"; break;
case "Il <b>login</b> dell'utente":  		$messaggio = "The <b>login</b> of user"; break;
case "password conservata in chiaro":  		$messaggio = "password stored in plain text"; break;
case "password conservata criptata con md5":  	$messaggio = "password stored encripted with md5"; break;
case "password conservata criptata con mcrypt":	$messaggio = "password stored encripted with mcrypt"; break;
case "password conservata criptata con mhash":	$messaggio = "password stored encripted with mhash"; break;
case "disabilitato":  				$messaggio = "disabled"; break;
case "Inserisci una nuova password":  		$messaggio = "Insert a new password"; break;
case "Ripeti la password":  			$messaggio = "Repeat the password"; break;
case "Continua":  				$messaggio = "Continue"; break;
case "Torna indietro":  			$messaggio = "Go back"; break;
case "<div style=\"display: inline; color: red;\">Esiste già</div> un utente chiamato":	$messaggio = "<div style=\"display: inline; color: red;\">Already exists</div> an user called"; break;
case "Nuova password dell'utente":  		$messaggio = "New password of user"; break;
case "<div style=\"display: inline; color: red;\">non</div> inserita correttamente":	$messaggio = "<div style=\"display: inline; color: red;\">not</div> inserted correctly"; break;
case "<b>Non</b> è stato effettuato nessun cambiamento":	$messaggio = "<b>No</b> changes have been done"; break;
case "Esiste già un utente chiamato":  		$messaggio = "Already exists an user called"; break;
case "Le nuove password non coincidono":  	$messaggio = "New passwrds do not coincide"; break;
case "Inserisci una nuova password per l'utente":	$messaggio = "Insert a new password for user"; break;
case "Nuova password":  			$messaggio = "New password"; break;
case "Gestione degli utenti di hoteldruid":	$messaggio = "HotelDruid users management"; break;
case "Gestione degli utenti":			$messaggio = "Users management"; break;
case "N°":  					$messaggio = "N°"; break;
case "nome":  					$messaggio = "name"; break;
case "login":  					$messaggio = "login"; break;
case "modifica":  				$messaggio = "modify"; break;
case "password criptata con md5":  		$messaggio = "password encripted with md5"; break;
case "password criptata con mcrypt":  		$messaggio = "password encripted with mcrypt"; break;
case "password criptata con mhash":  		$messaggio = "password encripted with mhash"; break;
case "password":  				$messaggio = "password"; break;
case "privilegi":  				$messaggio = "privileges"; break;
case "Amministratore":  			$messaggio = "Administrator"; break;
case "Abilitare per usare altri utenti":  	$messaggio = "Enable to use other users"; break;
case "Modifica gli utenti":  			$messaggio = "Modify users"; break;
case "Aggiungi":  				$messaggio = "Add"; break;
case "un nuovo utente chiamato":  		$messaggio = "a new user called"; break;
case "dell'utente":  				$messaggio = "to user"; break;
case "del gruppo":  				$messaggio = "to group"; break;
case "dall'utente":  				$messaggio = "from user"; break;
case "Privilegi importati":  			$messaggio = "Privileges imported"; break;
case "Importa":  				$messaggio = "Import"; break;
case "gruppi":  				$messaggio = "groups"; break;
case "Aggiornati i gruppi dell'utente":  	$messaggio = "Updated groups of user"; break;
case "Gruppi dell'utente":  			$messaggio = "Groups of user"; break;
case "Nuovo gruppo":  				$messaggio = "New group"; break;
case "Esiste già un gruppo chiamato":  		$messaggio = "Already exists a group called"; break;
case "Modifica":  				$messaggio = "Modify"; break;
case "cancella":  				$messaggio = "delete"; break;
case "Si è sicuri di voler <b style=\"font-weight: normal; color: red;\">cancellare</b> l'utente":	$messaggio = "Are you sure you want to <b style=\"font-weight: normal; color: red;\">delete</b> user"; break;
case "SI":  					$messaggio = "YES"; break;
case "NO":  					$messaggio = "NO"; break;
case "privilegi e personalizzazioni":  		$messaggio = "privileges and customizations"; break;
case "solo i privilegi":  			$messaggio = "only privileges"; break;
case "solo le personalizzazioni":  		$messaggio = "only customizations"; break;
case "Personalizzazioni importate":  		$messaggio = "Customizations imported"; break;
case "privilegi, personalizzazioni e gruppi":	$messaggio = "privileges, customizations and groups"; break;
case "privilegi e gruppi":  			$messaggio = "privileges and groups"; break;
case "personalizzazioni e gruppi":  		$messaggio = "customizations and groups"; break;
case "solo i gruppi":  				$messaggio = "only groups"; break;
case "Gruppi importati":  			$messaggio = "Groups imported"; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;

} # fine switch ($messaggio)

?>