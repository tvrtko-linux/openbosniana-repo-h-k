<?php

switch ($messaggio) {

case " Do":  					$messaggio = " Su"; break;
case " Lu":  					$messaggio = " Mo"; break;
case " Ma":  					$messaggio = " Tu"; break;
case " Me":  					$messaggio = " We"; break;
case " Gi":  					$messaggio = " Th"; break;
case " Ve":  					$messaggio = " Fr"; break;
case " Sa":  					$messaggio = " Sa"; break;
case "Gen":  					$messaggio = "Jan"; break;
case "Feb":  					$messaggio = "Feb"; break;
case "Mar":  					$messaggio = "Mar"; break;
case "Apr":  					$messaggio = "Apr"; break;
case "Mag":  					$messaggio = "May"; break;
case "Giu":  					$messaggio = "Jun"; break;
case "Lug":  					$messaggio = "Jul"; break;
case "Ago":  					$messaggio = "Aug"; break;
case "Set":  					$messaggio = "Sep"; break;
case "Ott":  					$messaggio = "Oct"; break;
case "Nov":  					$messaggio = "Nov"; break;
case "Dic":  					$messaggio = "Dec"; break;
case "Gennaio":  				$messaggio = "January"; break;
case "Febbraio":  				$messaggio = "February"; break;
case "Marzo":  					$messaggio = "March"; break;
case "Aprile":  				$messaggio = "April"; break;
case "Maggio":  				$messaggio = "May"; break;
case "Giugno":  				$messaggio = "June"; break;
case "Luglio":  				$messaggio = "July"; break;
case "Agosto":  				$messaggio = "August"; break;
case "Settembre":  				$messaggio = "September"; break;
case "Ottobre":  				$messaggio = "October"; break;
case "Novembre":  				$messaggio = "November"; break;
case "Dicembre":  				$messaggio = "December"; break;
case "Domenica":  				$messaggio = "Sunday"; break;
case "Lunedì":  				$messaggio = "Monday"; break;
case "Martedì":  				$messaggio = "Tuesday"; break;
case "Mercoledì":  				$messaggio = "Wednesday"; break;
case "Giovedì":  				$messaggio = "Thursday"; break;
case "Venerdì":  				$messaggio = "Friday"; break;
case "Sabato":  				$messaggio = "Saturday"; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;

} # fine switch ($messaggio)

?>
