<?php

switch ($messaggio) {

case "Disponibilità":  				$messaggio = "Disponibilidad"; break;
case "Le date sono sbagliate":  		$messaggio = "Las fechas están equivocadas"; break;
case "persone":  				$messaggio = "personas"; break;
case "La settimana dal":  			$messaggio = "La semana desde"; break;
case "Il giorno dal":  				$messaggio = "El día desde"; break;
case "al":  					$messaggio = "hasta"; break;
case "è piena":  				$messaggio = "está llena"; break;
case "è pieno":  				$messaggio = "está lleno"; break;
case "<b>C'è</b> ancora disponibilità nel periodo richiesto":	$messaggio = "<b>Hay</b> todavía disponibilidad en el período pedido"; break;
case ", ma si dovranno fare degli spostamenti nei periodi della <div style=\"display: inline; color: blue;\">regola di assegnazione 1</div>":	$messaggio = ", pero habrá que hacer algunos movimientos en los períodos de la <div style=\"display: inline; color: blue;\">regla de asignación 1</div>"; break;
case "<b>Non c'è</b> più disponibilità nel periodo richiesto":	$messaggio = "<b>No hay</b> más disponibilidad en el período pedido"; break;
case "Si potrebbe inserire la prenotazione dividendola in":	$messaggio = "Se podria insertar la reserva dividiendola en"; break;
case "parti":  					$messaggio = "trozos"; break;
case "Periodo di":  				$messaggio = "Período de"; break;
case "dal":  					$messaggio = "desde"; break;
case "settimane":  				$messaggio = "semanas"; break;
case "giorni":  				$messaggio = "días"; break;
case "Tariffa":  				$messaggio = "Tarifa"; break;
case "compresi":  				$messaggio = "incluyendo"; break;
case "di costi aggiuntivi fissi":  		$messaggio = "de costes añadidos fijos"; break;
case "Ricontrolla":  				$messaggio = "Volver a controlar"; break;
case "Torna al menù principale":  		$messaggio = "Volver al menú principal"; break;
case "documento di tipo":  			$messaggio = "documento tipo"; break;
case "visualizza":  				$messaggio = "Ver"; break;
case "con la tariffa":  			$messaggio = "con la tarifa"; break;
case "Inserisci la prenotazione":  		$messaggio = "Insertar la reserva"; break;
case "settimana":  				$messaggio = "semana"; break;
case "giorno":  				$messaggio = "día"; break;
case "TOTALE":  				$messaggio = "TOTAL"; break;
case "Non c'è nussun periodo delle regole 1 in cui sia consentito inserire prenotazioni per l'utente":	$messaggio = "No hay ningun período de las reglas 1 en el que esté consentido insertar reservas para el usuario"; break;
case "costo aggiuntivo unico":  		$messaggio = "coste añadido único"; break;
case "costo aggiuntivo settimanale":  		$messaggio = "coste añadido semanal"; break;
case "costo aggiuntivo giornaliero":  		$messaggio = "coste añadido diario"; break;
case "nº di settimane da applicare":  		$messaggio = "nº de semanas a aplicar"; break;
case "nº di giorni da applicare":  		$messaggio = "nº de días a aplicar"; break;
case "di costi aggiuntivi":  			$messaggio = "de costes añadidos"; break;
case "Aggiungi":  				$messaggio = "Añadir"; break;
case "da moltiplicare per":  			$messaggio = "a multiplicar por"; break;
case "Non si sono potuti applicare alla tariffa uno o più costi":	$messaggio = "No se han podido aplicar uno o más costes a la tarifa"; break;
case "Scegliere le settimane in cui applicare il costo aggiuntivo":	$messaggio = "Escoger las semanas en las que aplicar el coste añadido"; break;
case "Continua":  				$messaggio = "Continua"; break;
case "tariffa":  				$messaggio = "tarifa"; break;
case "Quadro indicativo disponibilità":  	$messaggio = "Cuadro indicativo de disponibilidad"; break;
case "potrebbe non essere preciso":  		$messaggio = "podría no ser exacto"; break;
case "persona":  				$messaggio = "persona"; break;
case "Caparra":  				$messaggio = "Fianza"; break;
case "con i costi aggiuntivi selezionati":  	$messaggio = "con los costes añadidos seleccionados"; break;
case "per":  					$messaggio = "para"; break;
case "Commissioni":  				$messaggio = "Comisiones"; break;
case "Non c'è nessuna tariffa disponibile in questo periodo":	$messaggio = "No hay ninguna tarifa disponible en este período"; break;
case "Mostra le tariffe non disponibili":  	$messaggio = "Enseñar tarifas no disponibles"; break;
case "Scegliere le settimane in cui applicare il costo aggiuntivo":	$messaggio = "Escoger las semanas en las que aplicar el coste añadido"; break;
case "Scegliere i giorni in cui applicare il costo aggiuntivo":	$messaggio = "Escoger los días en las que aplicar el coste añadido"; break;
case "costo aggiuntivo":  			$messaggio = "coste añadido"; break;
case "":  		$messaggio = ""; break;
case "":  		$messaggio = ""; break;


} # fine switch ($messaggio)

?>