module ParsecExpr
{-# DEPRECATED "This module has moved to Text.ParserCombinators.Parsec.Expr" #-}
(module Text.ParserCombinators.Parsec.Expr) where
import Text.ParserCombinators.Parsec.Expr
