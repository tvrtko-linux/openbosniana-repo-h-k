module CVHAssert(
	module Hugs.CVHAssert,
    ) where

import Hugs.CVHAssert
