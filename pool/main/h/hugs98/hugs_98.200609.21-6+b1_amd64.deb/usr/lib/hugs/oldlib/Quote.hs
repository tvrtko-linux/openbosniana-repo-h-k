module Quote(
	module Hugs.Quote,
    ) where

import Hugs.Quote
