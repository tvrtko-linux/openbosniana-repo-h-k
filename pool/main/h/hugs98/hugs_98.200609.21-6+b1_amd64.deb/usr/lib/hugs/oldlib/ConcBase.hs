module ConcBase(
	module Hugs.ConcBase,
    ) where

import Hugs.ConcBase
