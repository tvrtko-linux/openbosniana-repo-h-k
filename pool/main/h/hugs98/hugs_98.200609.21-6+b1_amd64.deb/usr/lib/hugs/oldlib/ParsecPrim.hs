module ParsecPrim
{-# DEPRECATED "This module has moved to Text.ParserCombinators.Parsec.Prim" #-}
(module Text.ParserCombinators.Parsec.Prim) where
import Text.ParserCombinators.Parsec.Prim
