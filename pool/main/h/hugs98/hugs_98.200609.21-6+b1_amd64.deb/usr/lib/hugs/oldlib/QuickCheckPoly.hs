module QuickCheckPoly
{-# DEPRECATED "This module has moved to Debug.QuickCheck.Poly" #-}
(module Debug.QuickCheck.Poly) where
import Debug.QuickCheck.Poly
