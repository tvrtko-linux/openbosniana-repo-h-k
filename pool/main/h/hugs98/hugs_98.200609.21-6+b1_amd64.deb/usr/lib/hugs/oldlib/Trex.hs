module Trex(
	module Hugs.Trex,
    ) where

import Hugs.Trex
