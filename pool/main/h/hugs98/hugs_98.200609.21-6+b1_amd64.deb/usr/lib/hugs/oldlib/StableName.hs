module StableName
  {-# DEPRECATED "This module has moved to System.Mem.StableName" #-} 
  (module System.Mem.StableName) where
import System.Mem.StableName
