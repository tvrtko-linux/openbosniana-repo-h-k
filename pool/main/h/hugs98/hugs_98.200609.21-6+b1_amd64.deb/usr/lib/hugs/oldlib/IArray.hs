module IArray
  {-# DEPRECATED "This module has moved to Data.Array.IArray" #-} 
  (module Data.Array.IArray) where
import Data.Array.IArray
