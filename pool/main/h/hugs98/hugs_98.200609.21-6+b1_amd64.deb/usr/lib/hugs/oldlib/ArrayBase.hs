module ArrayBase
{-# DEPRECATED "This module has moved to Data.Array.Base" #-}
(module Data.Array.Base) where
import Data.Array.Base
