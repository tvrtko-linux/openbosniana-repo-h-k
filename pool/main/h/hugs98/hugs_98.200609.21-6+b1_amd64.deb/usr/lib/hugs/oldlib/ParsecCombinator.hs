module ParsecCombinator
{-# DEPRECATED "This module has moved to Text.ParserCombinators.Parsec.Combinator" #-}
(module Text.ParserCombinators.Parsec.Combinator) where
import Text.ParserCombinators.Parsec.Combinator
