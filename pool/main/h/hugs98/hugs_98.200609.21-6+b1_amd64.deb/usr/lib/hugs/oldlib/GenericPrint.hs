module GenericPrint(
	module Hugs.GenericPrint,
    ) where

import Hugs.GenericPrint
