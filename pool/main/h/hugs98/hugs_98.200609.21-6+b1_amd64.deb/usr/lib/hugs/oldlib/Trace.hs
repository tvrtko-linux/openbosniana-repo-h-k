module Trace(
	module Debug.Trace,
    ) where

import Debug.Trace
