module HsSyn
{-# DEPRECATED "This module has moved to Language.Haskell.Syntax" #-}
(module Language.Haskell.Syntax) where
import Language.Haskell.Syntax
