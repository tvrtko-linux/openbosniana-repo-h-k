-- Empty module to serve as the default current module.
module Hugs where
