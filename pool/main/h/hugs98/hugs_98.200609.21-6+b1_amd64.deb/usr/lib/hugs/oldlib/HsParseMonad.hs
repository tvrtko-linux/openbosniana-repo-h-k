module HsParseMonad
{-# DEPRECATED "This module has moved to Language.Haskell.ParseMonad" #-}
(module Language.Haskell.ParseMonad) where
import Language.Haskell.ParseMonad
