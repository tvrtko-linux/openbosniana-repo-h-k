module CForeign ( module Foreign.C ) where
import Foreign.C
