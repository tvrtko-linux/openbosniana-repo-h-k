module Ix (
    Ix(range, index, inRange), rangeSize
  ) where

import Data.Ix
