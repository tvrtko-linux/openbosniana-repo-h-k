-----------------------------------------------------------------------------
-- |
-- Module      :  Debug.QuickCheck
-- Copyright   :  (c) Koen Claessen, John Hughes 2001
-- License     :  BSD-style (see the file libraries/base/LICENSE)
-- 
-- Maintainer  :  libraries@haskell.org
-- Stability   :  deprecated
-- Portability :  portable
--
-- implementation moved to Test.QuickCheck
-----------------------------------------------------------------------------

module Debug.QuickCheck
{-# DEPRECATED "Use module Test.QuickCheck instead" #-}
  ( module Test.QuickCheck
  )
 where

import Test.QuickCheck

