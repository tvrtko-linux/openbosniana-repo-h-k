{-# OPTIONS_GHC -cpp #-}
-- #hide
module Distribution.Compat.Map (
   Map,
   member, lookup, findWithDefault,
   empty,
   insert, insertWith,
   union, unionWith, unions,
   elems, keys,
   fromList, fromListWith,
   toAscList
) where

import Prelude hiding ( lookup )


import Data.Map


















































